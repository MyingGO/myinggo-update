// MyingGo - khung giao diện: menu, nạp tính năng, theme, tiện ích MG.*
const MG = {
  settings: {},
  _localRun: new Set(),
  _srvRun: new Set(),
  _srvWin: new Set(),
  _activeId: null,
  _refreshIndicators: null,
  setRunning(fid, on) {
    if (on) MG._localRun.add(fid);
    else MG._localRun.delete(fid);
    if (MG._refreshIndicators) MG._refreshIndicators();
  },
  async api(path, data) {
    const r = await fetch('/api/' + path, data === undefined ? {} : {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    return r.json();
  },
  call(fid, action, data) { return MG.api(fid + '/' + action, data || {}); },
  // Đọc log của tính năng liên tục. onLines(mảng dòng mới), onState(running). Trả về hàm dừng.
  watchLog(fid, onLines, onState) {
    let next = 0, alive = true, idle = 0;
    const tick = async () => {
      if (!alive) return;
      try {
        const r = await (await fetch(`/api/${fid}/log?since=${next}`)).json();
        next = r.next;
        if (r.lines.length) onLines(r.lines);
        MG.setRunning(fid, !!r.running);
        if (onState) onState(r.running);
        idle = r.running || r.lines.length ? 0 : idle + 1;
      } catch (e) { }
      if (alive && idle < 4) setTimeout(tick, 500);
    };
    tick();
    return () => { alive = false; };
  },
  toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(MG._tt); MG._tt = setTimeout(() => t.classList.remove('show'), 2600);
  },
  hex2rgb(h) { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)); },
  // Áp dụng theme lên CSS
  applyTheme(s) {
    MG.settings = s;
    const r = document.documentElement.style, rgb = MG.hex2rgb;
    r.setProperty('--bg', s.bg_color); r.setProperty('--btn', s.btn_color); r.setProperty('--text', s.text_color);
    r.setProperty('--bg-rgb', rgb(s.bg_color).join(',')); r.setProperty('--text-rgb', rgb(s.text_color).join(','));
    r.setProperty('--btn-rgb', rgb(s.btn_color).join(','));
    const [br, bg, bb] = rgb(s.btn_color);
    r.setProperty('--btn-text', (0.299 * br + 0.587 * bg + 0.114 * bb) > 150 ? '#000' : '#fff');
    r.setProperty('--panel-a', Math.max(0.02, 1 - s.glass / 100));
    r.setProperty('--blur', s.blur + 'px'); r.setProperty('--radius', s.radius + 'px');
    r.setProperty('--dim', s.dim / 100);
    r.setProperty('--bgimg', s.bg_image ? `url("/assets/${s.bg_image}?v=${s.ver}")` : 'none');
  },
  async saveTheme(patch) { MG.applyTheme(await MG.api('settings', patch)); },
};

(async function init() {
  if (!sessionStorage.getItem('mg_hr_106l')) {
    sessionStorage.setItem('mg_hr_106l', '1');
    try {
      const p = await MG.api('ping', {});
      if (!p.running || !p.running.length) await MG.api('hot_reload', {});
    } catch (e) { }
  }
  MG.applyTheme(await MG.api('settings'));
  const feats = await MG.api('features');
  const ARTCRAFT_IDS = new Set(['photocraft', 'filmcraft', 'effectcraft']);
  const BOTTOM_IDS = new Set(['appearance', 'trash_logs']);
  feats.forEach(f => {
    if (!f.group && ARTCRAFT_IDS.has(f.id)) f.group = 'ArtCraft';
    if (!f.dock && BOTTOM_IDS.has(f.id)) f.dock = 'bottom';
  });

  const main = document.getElementById('main');
  const appEl = document.getElementById('app') || document.querySelector('.app');
  const sideEl = document.getElementById('side') || document.querySelector('.side');
  const sideToggle = document.getElementById('side-toggle');
  const FEAT_ICONS = {
    thumbnail_copier: '🖼️', downloader: '🎬', converter: '🔁',
    video_picker: '🎞️', yugioh_combo: '🃏', appearance: '🎨', trash_logs: '🧹',
  };
  const FEAT_IMG_ICONS = {
    yugioh_combo: '/assets/yugioh_combo.png?v=2',
  };
  function splitTitleIcon(fid, title) {
    const m = String(title || '').match(/^(\p{Extended_Pictographic}[\uFE0F\u200D\p{Extended_Pictographic}]*)\s*(.+)$/u);
    if (m) return { emo: m[1], txt: m[2] };
    return { emo: FEAT_ICONS[fid] || '⚡', txt: title };
  }
  if (sideToggle && appEl && sideEl) {
    const syncSideBtn = () => {
      const col = appEl.classList.contains('side-collapsed');
      sideToggle.innerHTML = col
        ? '<span>»</span><span class="side-pin-txt">Mở cố định</span>'
        : '<span>«</span><span class="side-pin-txt">Thu gọn</span>';
      sideToggle.title = col
        ? 'Bấm để mở hết thanh công cụ cố định (Hiện tại: tự động mở khi di chuột vào)'
        : 'Thu gọn thanh công cụ (di chuột vào sẽ tự mở ra)';
    };
    if (localStorage.getItem('mg_side_collapsed') === '1') appEl.classList.add('side-collapsed');
    syncSideBtn();
    sideToggle.onclick = (e) => {
      e.stopPropagation();
      const willCollapse = !appEl.classList.contains('side-collapsed');
      appEl.classList.toggle('side-collapsed', willCollapse);
      localStorage.setItem('mg_side_collapsed', willCollapse ? '1' : '0');
      if (willCollapse) sideEl.classList.add('just-collapsed');
      else sideEl.classList.remove('just-collapsed');
      syncSideBtn();
    };
    sideEl.addEventListener('mouseleave', () => sideEl.classList.remove('just-collapsed'));
  }
  const views = {}, btns = {}, pops = {}, groups = {};

  function refreshIndicators() {
    const groupRunning = {};
    feats.forEach(f => {
      const isRun = (f.id === MG._activeId && f.dock !== 'bottom')
        || MG._localRun.has(f.id)
        || MG._srvRun.has(f.id)
        || MG._srvWin.has(f.id);
      if (btns[f.id]) btns[f.id].classList.toggle('is-running', isRun);
      if (pops[f.id]) pops[f.id].classList.toggle('win-open', MG._srvWin.has(f.id));
      if (f.group && isRun) groupRunning[f.group] = true;
    });
    Object.entries(groups).forEach(([gname, g]) => {
      g.wrap.classList.toggle('is-running', !!groupRunning[gname]);
    });
  }
  MG._refreshIndicators = refreshIndicators;

  async function show(f) {
    MG._activeId = f.id;
    if (f.group !== 'ArtCraft') document.body.classList.remove('pc-maximize');
    Object.values(views).forEach(v => v.style.display = 'none');
    Object.values(btns).forEach(b => b.classList.remove('active'));
    Object.values(groups).forEach(g => g.wrap.classList.remove('has-active'));
    btns[f.id].classList.add('active');
    if (f.group && groups[f.group]) {
      groups[f.group].wrap.classList.add('open', 'has-active');
    }
    if (!views[f.id]) {
      const div = document.createElement('div');
      main.appendChild(div);
      views[f.id] = div;
      const tpl = document.createElement('template');
      tpl.innerHTML = await (await fetch(`/api/feature/${f.id}/html?t=${Date.now()}`)).text();
      const scripts = [...tpl.content.querySelectorAll('script')].map(s => { const c = s.textContent; s.remove(); return c; });
      div.appendChild(tpl.content);
      scripts.forEach(code => new Function('root', 'fid', code)(div, f.id));
    }
    views[f.id].style.display = '';
    refreshIndicators();
  }

  feats.forEach(f => {
    const host = document.getElementById(f.dock === 'bottom' ? 'nav-bottom' : 'nav-top');
    const insertBeforeEl = f.dock === 'bottom' ? document.getElementById('btn-publish') : null;
    const appendToHost = (el) => {
      if (insertBeforeEl && insertBeforeEl.parentNode === host) host.insertBefore(el, insertBeforeEl);
      else host.appendChild(el);
    };

    if (f.group) {
      if (!groups[f.group]) {
        const wrap = document.createElement('div');
        wrap.className = 'nav-group';
        const gbtn = document.createElement('button');
        gbtn.className = 'nav nav-group-btn';
        const gIco = f.group === 'ArtCraft' ? '<img class="nav-ico" src="/assets/artcraft.png" alt="">' : '<span class="nav-emo">📂</span>';
        gbtn.title = f.group;
        gbtn.innerHTML = `<span class="nav-label">${gIco}<span class="nav-txt">${f.group}</span></span><span class="nav-right"><span class="run-dot" title="Đang chạy"></span><span class="caret">▾</span></span>`;
        gbtn.onclick = () => wrap.classList.toggle('open');
        const sub = document.createElement('div');
        sub.className = 'nav-sub';
        wrap.appendChild(gbtn);
        wrap.appendChild(sub);
        appendToHost(wrap);
        groups[f.group] = { wrap, sub };
      }
      const row = document.createElement('div');
      row.className = 'nav-sub-row';
      const b = document.createElement('button');
      b.className = 'nav nav-sub-item';
      b.title = f.title;
      const subIco = f.group === 'ArtCraft' ? `<img class="nav-ico" src="/assets/${f.id}.png" alt="" onerror="this.style.display='none'">` : '';
      b.innerHTML = `<span class="nav-label">${subIco}<span class="nav-txt">${f.title}</span></span><span class="run-dot" title="Đang chạy"></span>`;
      b.onclick = () => show(f);
      btns[f.id] = b;
      row.appendChild(b);

      if (f.group === 'ArtCraft') {
        const pop = document.createElement('button');
        pop.className = 'btn nav-pop';
        pop.textContent = '🗖';
        pop.title = `Mở ${f.title} ở màn hình riêng (cửa sổ lớn)`;
        pop.onclick = async (e) => {
          e.stopPropagation();
          if (views[f.id]) {
            window.dispatchEvent(new CustomEvent('mg-open-standalone', { detail: { fid: f.id } }));
            return;
          }
          MG.toast(`Đang mở ${f.title} ở màn hình riêng (đồng bộ)...`);
          try {
            const r = await MG.call(f.id, 'open_window');
            if (r && r.error) window.open(`/web/${f.id}/index.html?standalone=1`, '_blank', 'width=1600,height=950');
            else { MG._srvWin.add(f.id); refreshIndicators(); }
          } catch (err) {
            window.open(`/web/${f.id}/index.html?standalone=1`, '_blank', 'width=1600,height=950');
          }
        };
        pops[f.id] = pop;
        row.appendChild(pop);
      }
      groups[f.group].sub.appendChild(row);
    } else {
      const b = document.createElement('button');
      b.className = 'nav';
      b.title = f.title;
      const { emo, txt } = splitTitleIcon(f.id, f.title);
      const icoHtml = FEAT_IMG_ICONS[f.id]
        ? `<img class="nav-ico emblem" src="${FEAT_IMG_ICONS[f.id]}" alt="">`
        : `<span class="nav-emo">${emo}</span>`;
      b.innerHTML = `<span class="nav-label">${icoHtml}<span class="nav-txt">${txt}</span></span><span class="run-dot" title="Đang chạy"></span>`;
      b.onclick = () => show(f);
      btns[f.id] = b;
      appendToHost(b);
    }
  });
  if (feats.length) show(feats[0]);

  // Nút đóng gói bản mang sang máy khác (mặc định kèm đủ yt-dlp + ffmpeg + deno để máy khác không bị lỗi thiếu công cụ)
  const pk = document.getElementById('pack');
  pk.onclick = async () => {
    pk.disabled = true; MG.toast('Đang đóng gói đầy đủ (kèm yt-dlp, ffmpeg, deno)...');
    try {
      const r = await MG.api('pack', { tools: true });
      if (r.error) MG.toast('Lỗi: ' + r.error);
      else MG.toast(`Đã tạo ${r.size_mb} MB trên Desktop` + (r.notes.length ? ' (' + r.notes.join('; ') + ')' : ''));
    } catch (e) { MG.toast('Lỗi khi nén'); }
    pk.disabled = false;
  };

  // Hệ thống cập nhật qua GitHub (Máy chính: Đẩy cập nhật | Máy phụ: Kiểm tra & Cập nhật)
  const verBadge = document.getElementById('ver-badge');
  const btnPub = document.getElementById('btn-publish');
  const btnUpd = document.getElementById('btn-update');

  async function refreshUpdateStatus() {
    try {
      const st = await MG.api('update/status');
      verBadge.textContent = `v${st.version}` + (st.is_master ? ' • Máy chính' : '');
      if (st.is_master) btnPub.style.display = '';
      const chk = await MG.api('update/check');
      const updTxt = btnUpd.querySelector('.nav-txt');
      if (chk && chk.has_update && chk.remote) {
        if (updTxt) updTxt.textContent = `Có bản mới v${chk.remote.version}!`;
        else btnUpd.textContent = `🔄 Có bản mới v${chk.remote.version}!`;
        btnUpd.classList.add('has-update');
        btnUpd.title = chk.remote.note || `Có bản mới v${chk.remote.version}!`;
      } else {
        if (updTxt) updTxt.textContent = 'Kiểm tra cập nhật';
        else btnUpd.textContent = '🔄 Kiểm tra cập nhật';
        btnUpd.classList.remove('has-update');
        btnUpd.title = 'Kiểm tra cập nhật';
      }
    } catch (e) { }
  }

  btnPub.onclick = async () => {
    const note = prompt('Ghi chú bản cập nhật (để trống cũng được):', '');
    if (note === null) return;
    btnPub.disabled = true; MG.toast('Đang đẩy bản cập nhật lên GitHub...');
    try {
      const r = await MG.api('update/publish', { note });
      if (r.error) MG.toast('Lỗi: ' + r.error);
      else {
        verBadge.textContent = `v${r.version} • Máy chính`;
        MG.toast(`Đã đẩy v${r.version} (${r.size_kb} KB) lên GitHub (${r.repo})!`);
      }
    } catch (e) { MG.toast('Lỗi kết nối GitHub'); }
    btnPub.disabled = false;
  };

  btnUpd.onclick = async () => {
    btnUpd.disabled = true; MG.toast('Đang kiểm tra bản cập nhật trên GitHub...');
    try {
      const chk = await MG.api('update/check');
      if (chk.error) { MG.toast('Lỗi kiểm tra: ' + chk.error); btnUpd.disabled = false; return; }
      const remoteVer = chk.remote ? chk.remote.version : null;
      if (!chk.has_update) {
        if (!remoteVer) {
          MG.toast('Chưa có bản cập nhật nào trên GitHub. Hãy bấm "⬆️ Đẩy bản cập nhật" ở máy chính trước.');
          btnUpd.disabled = false; return;
        }
        if (!confirm(`Máy đang ở bản v${chk.local.version} (trên GitHub là v${remoteVer}).\nBạn có muốn tải và cài đè lại bản v${remoteVer} không?`)) {
          btnUpd.disabled = false; return;
        }
      }
      MG.toast(`Đang tải và áp dụng bản v${remoteVer}...`);
      const res = await MG.api('update/pull', {});
      if (res.error) MG.toast('Lỗi cập nhật: ' + res.error);
      else {
        MG.toast(`Đã cập nhật lên v${res.version}! Đang nạp lại toàn bộ giao diện...`);
        setTimeout(() => location.replace('/?v=' + Date.now()), 800);
      }
    } catch (e) { MG.toast('Lỗi khi cập nhật'); }
    btnUpd.disabled = false;
  };

  refreshUpdateStatus();

  const ping = async () => {
    try {
      const r = await MG.api('ping', {});
      MG._srvRun = new Set(r.running || []);
      MG._srvWin = new Set(r.windows || []);
      refreshIndicators();
    } catch (e) { }
  };
  ping(); setInterval(ping, 2000);
  addEventListener('pagehide', () => navigator.sendBeacon('/api/bye', '{}'));
})();
