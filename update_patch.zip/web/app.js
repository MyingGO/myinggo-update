// MyingGo - khung giao diện: menu, nạp tính năng, theme, tiện ích MG.*
const MG = {
  settings: {},
  _localRun: new Set(),
  _srvRun: new Set(),
  _srvWin: new Set(),
  _activeId: null,
  _refreshIndicators: null,
  setRunning(fid, on) {
    if (on) MG._localRun.add(fid);
    else MG._localRun.delete(fid);
    if (MG._refreshIndicators) MG._refreshIndicators();
  },
  async api(path, data) {
    const r = await fetch('/api/' + path, data === undefined ? {} : {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    return r.json();
  },
  call(fid, action, data) { return MG.api(fid + '/' + action, data || {}); },
  // Đọc log của tính năng liên tục. onLines(mảng dòng mới), onState(running). Trả về hàm dừng.
  watchLog(fid, onLines, onState) {
    let next = 0, alive = true, idle = 0;
    const tick = async () => {
      if (!alive) return;
      try {
        const r = await (await fetch(`/api/${fid}/log?since=${next}`)).json();
        next = r.next;
        if (r.lines.length) onLines(r.lines);
        MG.setRunning(fid, !!r.running);
        if (onState) onState(r.running);
        idle = r.running || r.lines.length ? 0 : idle + 1;
      } catch (e) { }
      if (alive && idle < 4) setTimeout(tick, 500);
    };
    tick();
    return () => { alive = false; };
  },
  toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(MG._tt); MG._tt = setTimeout(() => t.classList.remove('show'), 2600);
  },
  hex2rgb(h) { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)); },
  // Áp dụng theme lên CSS
  applyTheme(s) {
    MG.settings = s;
    const r = document.documentElement.style, rgb = MG.hex2rgb;
    r.setProperty('--bg', s.bg_color); r.setProperty('--btn', s.btn_color); r.setProperty('--text', s.text_color);
    r.setProperty('--bg-rgb', rgb(s.bg_color).join(',')); r.setProperty('--text-rgb', rgb(s.text_color).join(','));
    r.setProperty('--btn-rgb', rgb(s.btn_color).join(','));
    const [br, bg, bb] = rgb(s.btn_color);
    r.setProperty('--btn-text', (0.299 * br + 0.587 * bg + 0.114 * bb) > 150 ? '#000' : '#fff');
    r.setProperty('--panel-a', Math.max(0.02, 1 - s.glass / 100));
    r.setProperty('--blur', s.blur + 'px'); r.setProperty('--radius', s.radius + 'px');
    r.setProperty('--dim', s.dim / 100);
    r.setProperty('--bgimg', s.bg_image ? `url("/assets/${s.bg_image}?v=${s.ver}")` : 'none');
  },
  async saveTheme(patch) { MG.applyTheme(await MG.api('settings', patch)); },
};

(async function init() {
  if (!sessionStorage.getItem('mg_hr_111_dy')) {
    sessionStorage.setItem('mg_hr_111_dy', '1');
    try {
      const p = await MG.api('ping', {});
      if (!p.running || !p.running.length) await MG.api('hot_reload', {});
    } catch (e) { }
  }
  try {
    const appInfo = await (await fetch('/api/app_info')).json();
    if (appInfo && appInfo.app_name) {
      document.title = appInfo.app_name;
      const h1 = document.querySelector('.brand h1');
      if (h1) h1.textContent = appInfo.app_name;
    }
  } catch (e) { }
  MG.applyTheme(await MG.api('settings'));
  const feats = await MG.api('features');
  const ARTCRAFT_IDS = new Set(['photocraft', 'filmcraft', 'effectcraft']);
  const BOTTOM_IDS = new Set(['appearance', 'trash_logs']);
  feats.forEach(f => {
    if (!f.group && ARTCRAFT_IDS.has(f.id)) f.group = 'ArtCraft';
    if (!f.dock && BOTTOM_IDS.has(f.id)) f.dock = 'bottom';
  });

  const main = document.getElementById('main');
  const appEl = document.getElementById('app') || document.querySelector('.app');
  const sideEl = document.getElementById('side') || document.querySelector('.side');
  const sideToggle = document.getElementById('side-toggle');

  // Hệ thống biểu tượng SVG nét mảnh tối giản (Minimalist Vector Line Icons phong cách Feather / Lucide)
  const FEAT_SVGS = {
    // 🖼️ Thumbnail Copier: 2 khung ảnh xếp chồng
    thumbnail_copier: `<svg class="nav-svg" viewBox="0 0 24 24"><rect width="14" height="14" x="7" y="7" rx="2"/><path d="M3 15V5a2 2 0 0 1 2-2h10"/><circle cx="12" cy="12" r="1.5"/><path d="m21 16-3.5-3.5L11 19"/></svg>`,
    // ✨ Thumbnail Studio: Ngôi sao AI 4 cánh thanh thoát
    thumbnail_studio: `<svg class="nav-svg" viewBox="0 0 24 24"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3z"/><path d="M19 3v4M21 5h-4"/></svg>`,
    // 📊 Quản lý Kênh & Audio: Biểu đồ cột phân tích / Trung tâm điều khiển
    yt_studio_hub: `<svg class="nav-svg" viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`,
    // ☁️ Tải lên Drive: Đám mây & mũi tên đẩy lên
    drive_uploader: `<svg class="nav-svg" viewBox="0 0 24 24"><path d="M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2"/><path d="M12 12v9"/><path d="m16 16-4-4-4 4"/></svg>`,
    // 🎬 Tải video / MP3: Khay tải xuống & mũi tên
    downloader: `<svg class="nav-svg" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    // ✂️ Cắt video: Cây kéo hình học hiện đại
    video_splitter: `<svg class="nav-svg" viewBox="0 0 24 24"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/></svg>`,
    // 🔁 Chuyển định dạng: 2 mũi tên lặp xoay vòng tròn
    converter: `<svg class="nav-svg" viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>`,
    // 🎞️ Bốc video: Thư viện video / nút Play phim
    video_picker: `<svg class="nav-svg" viewBox="0 0 24 24"><rect width="18" height="15" x="3" y="4.5" rx="3"/><polygon points="10 8.5 15 12 10 15.5"/></svg>`,
    // 🃏 Yu-Gi-Oh! Academy: Bộ bài đôi tối giản
    yugioh_combo: `<svg class="nav-svg" viewBox="0 0 24 24"><rect width="11" height="16" x="2.5" y="4" rx="2"/><rect width="11" height="16" x="9.5" y="4" rx="2"/><path d="M15 9.5a2.5 2.5 0 0 0-2.5-2.5"/></svg>`,
    // 🧹 File rác & Log: Thùng rác outline
    trash_logs: `<svg class="nav-svg" viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>`,
    // 🎨 Giao diện: Thanh trượt tinh chỉnh cài đặt (Sliders)
    appearance: `<svg class="nav-svg" viewBox="0 0 24 24"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>`,
    // Nhóm ArtCraft: Các lớp đồ họa (Layers stack)
    artcraft: `<svg class="nav-svg" viewBox="0 0 24 24"><path d="m12 2 10 6.5-10 6.5L2 8.5z"/><path d="m2 15.5 10 6.5 10-6.5"/><path d="m2 12 10 6.5 10-6.5"/></svg>`,
    // Nhánh PhotoCraft: Máy ảnh
    photocraft: `<svg class="nav-svg" viewBox="0 0 24 24"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>`,
    // Nhánh FilmCraft: Cuộn phim điện ảnh
    filmcraft: `<svg class="nav-svg" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4M7 12h10"/></svg>`,
    // Nhánh EffectCraft: Đũa phép hiệu ứng
    effectcraft: `<svg class="nav-svg" viewBox="0 0 24 24"><path d="m3 21 10-10"/><path d="m12 5 1.5 3.5L17 10l-3.5 1.5L12 15l-1.5-3.5L7 10l3.5-1.5z"/><path d="M19 3v4M21 5h-4"/></svg>`,
    // Mặc định
    default: `<svg class="nav-svg" viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`
  };

  function cleanTitle(title) {
    return String(title || '')
      .replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, '')
      .trim() || title;
  }

  function getNavIconHtml(fid, groupName) {
    if (groupName && FEAT_SVGS[groupName.toLowerCase()]) {
      return FEAT_SVGS[groupName.toLowerCase()];
    }
    if (fid && FEAT_SVGS[fid]) return FEAT_SVGS[fid];
    return FEAT_SVGS.default;
  }
  if (sideToggle && appEl && sideEl) {
    const syncSideBtn = () => {
      const col = appEl.classList.contains('side-collapsed');
      sideToggle.innerHTML = col
        ? '<svg viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m14 9 3 3-3 3"/></svg>'
        : '<svg viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m16 15-3-3 3-3"/></svg>';
      sideToggle.title = col
        ? 'Bấm để mở hết thanh công cụ cố định (Hiện tại: tự động mở khi di chuột vào)'
        : 'Thu gọn thanh công cụ (di chuột vào sẽ tự mở ra)';
    };
    if (localStorage.getItem('mg_side_collapsed') === '1') appEl.classList.add('side-collapsed');
    syncSideBtn();
    sideToggle.onclick = (e) => {
      e.stopPropagation();
      const willCollapse = !appEl.classList.contains('side-collapsed');
      appEl.classList.toggle('side-collapsed', willCollapse);
      localStorage.setItem('mg_side_collapsed', willCollapse ? '1' : '0');
      if (willCollapse) sideEl.classList.add('just-collapsed');
      else sideEl.classList.remove('just-collapsed');
      syncSideBtn();
    };
    sideEl.addEventListener('mouseleave', () => sideEl.classList.remove('just-collapsed'));
  }
  const views = {}, btns = {}, pops = {}, groups = {};

  function refreshIndicators() {
    const groupRunning = {};
    feats.forEach(f => {
      const isRun = (f.id === MG._activeId && f.dock !== 'bottom')
        || MG._localRun.has(f.id)
        || MG._srvRun.has(f.id)
        || MG._srvWin.has(f.id);
      if (btns[f.id]) btns[f.id].classList.toggle('is-running', isRun);
      if (pops[f.id]) pops[f.id].classList.toggle('win-open', MG._srvWin.has(f.id));
      if (f.group && isRun) groupRunning[f.group] = true;
    });
    Object.entries(groups).forEach(([gname, g]) => {
      g.wrap.classList.toggle('is-running', !!groupRunning[gname]);
    });
  }
  MG._refreshIndicators = refreshIndicators;

  async function show(f) {
    MG._activeId = f.id;
    document.querySelectorAll('.ts-portal .ts-modal.show').forEach(m => m.classList.remove('show', 'gallery'));
    if (f.group !== 'ArtCraft') document.body.classList.remove('pc-maximize');
    Object.values(views).forEach(v => v.style.display = 'none');
    Object.values(btns).forEach(b => b.classList.remove('active'));
    Object.values(groups).forEach(g => g.wrap.classList.remove('has-active'));
    btns[f.id].classList.add('active');
    if (f.group && groups[f.group]) {
      groups[f.group].wrap.classList.add('open', 'has-active');
    }
    if (!views[f.id]) {
      const div = document.createElement('div');
      main.appendChild(div);
      views[f.id] = div;
      const tpl = document.createElement('template');
      tpl.innerHTML = await (await fetch(`/api/feature/${f.id}/html?t=${Date.now()}`)).text();
      const scripts = [...tpl.content.querySelectorAll('script')].map(s => { const c = s.textContent; s.remove(); return c; });
      div.appendChild(tpl.content);
      scripts.forEach(code => new Function('root', 'fid', code)(div, f.id));
    }
    views[f.id].style.display = '';
    refreshIndicators();
  }
  MG.showFeature = (fid) => { const f = feats.find(x => x.id === fid); if (f) show(f); };

  // Phân nhóm các tính năng thanh bên theo mục (giúp menu gọn gàng, dễ tìm)
  const SECTIONS = [
    { key: 'design', label: 'Thiết kế', ids: ['thumbnail_copier', 'ArtCraft', 'thumbnail_studio'] },
    { key: 'channel', label: 'Kênh & Lưu trữ', ids: ['yt_studio_hub', 'drive_uploader'] },
    { key: 'video', label: 'Video', ids: ['downloader', 'video_splitter', 'converter', 'video_picker'] },
    { key: 'fun', label: 'Giải trí', ids: ['yugioh_combo'] },
    { key: 'other', label: 'Khác', ids: [] },
  ];
  const navTop = document.getElementById('nav-top');
  const secLists = {};
  SECTIONS.forEach(s => {
    const sec = document.createElement('div');
    sec.className = 'nav-sec';
    sec.innerHTML = `<div class="nav-section">${s.label}</div><div class="nav-sec-list"></div>`;
    navTop.appendChild(sec);
    secLists[s.key] = sec.querySelector('.nav-sec-list');
  });
  const sectionHost = (f) => {
    const k = f.group || f.id;
    const s = SECTIONS.find(x => x.ids.includes(k)) || SECTIONS[SECTIONS.length - 1];
    return secLists[s.key];
  };

  feats.forEach(f => {
    const host = f.dock === 'bottom' ? document.getElementById('nav-bottom') : sectionHost(f);
    const insertBeforeEl = f.dock === 'bottom' ? document.getElementById('btn-publish') : null;
    const appendToHost = (el) => {
      if (insertBeforeEl && insertBeforeEl.parentNode === host) host.insertBefore(el, insertBeforeEl);
      else host.appendChild(el);
    };

    if (f.group) {
      if (!groups[f.group]) {
        const wrap = document.createElement('div');
        wrap.className = 'nav-group';
        const gbtn = document.createElement('button');
        gbtn.className = 'nav nav-group-btn';
        const gIco = getNavIconHtml(null, f.group);
        gbtn.title = f.group;
        gbtn.innerHTML = `<span class="nav-label">${gIco}<span class="nav-txt">${f.group}</span></span><span class="nav-right"><span class="run-dot" title="Đang chạy"></span><span class="caret">▾</span></span>`;
        gbtn.onclick = () => wrap.classList.toggle('open');
        const sub = document.createElement('div');
        sub.className = 'nav-sub';
        wrap.appendChild(gbtn);
        wrap.appendChild(sub);
        appendToHost(wrap);
        groups[f.group] = { wrap, sub };
      }
      const row = document.createElement('div');
      row.className = 'nav-sub-row';
      const b = document.createElement('button');
      b.className = 'nav nav-sub-item';
      const subTxt = cleanTitle(f.title);
      b.title = subTxt;
      const subIco = getNavIconHtml(f.id);
      b.innerHTML = `<span class="nav-label">${subIco}<span class="nav-txt">${subTxt}</span></span><span class="run-dot" title="Đang chạy"></span>`;
      b.onclick = () => show(f);
      btns[f.id] = b;
      row.appendChild(b);

      if (f.group === 'ArtCraft') {
        const pop = document.createElement('button');
        pop.className = 'btn nav-pop';
        pop.innerHTML = '<svg viewBox="0 0 24 24"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>';
        pop.title = `Mở ${subTxt} ở màn hình riêng (cửa sổ lớn)`;
        pop.onclick = async (e) => {
          e.stopPropagation();
          if (views[f.id]) {
            window.dispatchEvent(new CustomEvent('mg-open-standalone', { detail: { fid: f.id } }));
            return;
          }
          MG.toast(`Đang mở ${subTxt} ở màn hình riêng (đồng bộ)...`);
          try {
            const r = await MG.call(f.id, 'open_window');
            if (r && r.error) window.open(`/web/${f.id}/index.html?standalone=1`, '_blank', 'width=1600,height=950');
            else { MG._srvWin.add(f.id); refreshIndicators(); }
          } catch (err) {
            window.open(`/web/${f.id}/index.html?standalone=1`, '_blank', 'width=1600,height=950');
          }
        };
        pops[f.id] = pop;
        row.appendChild(pop);
      }
      groups[f.group].sub.appendChild(row);
    } else {
      const b = document.createElement('button');
      b.className = 'nav';
      const cleanTxt = cleanTitle(f.title);
      b.title = cleanTxt;
      const icoHtml = getNavIconHtml(f.id);
      b.innerHTML = `<span class="nav-label">${icoHtml}<span class="nav-txt">${cleanTxt}</span></span><span class="run-dot" title="Đang chạy"></span>`;
      b.onclick = () => show(f);
      btns[f.id] = b;
      appendToHost(b);
    }
  });
  Object.values(secLists).forEach(l => { if (!l.children.length) l.parentElement.remove(); });
  if (feats.length) show(feats[0]);

  // Nút đóng gói bản mang sang máy khác (mặc định kèm đủ yt-dlp + ffmpeg + deno để máy khác không bị lỗi thiếu công cụ)
  const pk = document.getElementById('pack');
  pk.onclick = async () => {
    pk.disabled = true; MG.toast('Đang đóng gói đầy đủ (kèm yt-dlp, ffmpeg, deno)...');
    try {
      const r = await MG.api('pack', { tools: true });
      if (r.error) MG.toast('Lỗi: ' + r.error);
      else MG.toast(`Đã tạo ${r.size_mb} MB trên Desktop` + (r.notes.length ? ' (' + r.notes.join('; ') + ')' : ''));
    } catch (e) { MG.toast('Lỗi khi nén'); }
    pk.disabled = false;
  };

  // Hệ thống cập nhật qua GitHub (Máy chính: Đẩy cập nhật | Máy phụ: Kiểm tra & Cập nhật)
  const verBadge = document.getElementById('ver-badge');
  const btnPub = document.getElementById('btn-publish');
  const btnUpd = document.getElementById('btn-update');

  async function refreshUpdateStatus() {
    try {
      const st = await MG.api('update/status');
      if (st.app_name) {
        document.title = st.app_name;
        const brandH1 = document.querySelector('.brand h1');
        if (brandH1) brandH1.textContent = st.app_name;
      }
      if (st.hide_pack_button && pk) {
        pk.style.display = 'none';
      }
      verBadge.textContent = `v${st.version}` + (st.is_master ? ' • Máy chính' : (st.app_name ? ` • ${st.app_name}` : ''));
      if (st.is_master) btnPub.style.display = '';
      const chk = await MG.api('update/check');
      const updTxt = btnUpd.querySelector('.nav-txt');
      if (chk && chk.has_update && chk.remote) {
        if (updTxt) updTxt.textContent = `Có bản mới v${chk.remote.version}!`;
        else btnUpd.textContent = `🔄 Có bản mới v${chk.remote.version}!`;
        btnUpd.classList.add('has-update');
        btnUpd.title = chk.remote.note || `Có bản mới v${chk.remote.version}!`;
      } else {
        if (updTxt) updTxt.textContent = 'Kiểm tra cập nhật';
        else btnUpd.textContent = '🔄 Kiểm tra cập nhật';
        btnUpd.classList.remove('has-update');
        btnUpd.title = 'Kiểm tra cập nhật';
      }
    } catch (e) { }
  }

  btnPub.onclick = async () => {
    const note = prompt('Ghi chú bản cập nhật (để trống cũng được):', '');
    if (note === null) return;
    btnPub.disabled = true; MG.toast('Đang đẩy bản cập nhật lên GitHub...');
    try {
      const r = await MG.api('update/publish', { note });
      if (r.error) MG.toast('Lỗi: ' + r.error);
      else {
        verBadge.textContent = `v${r.version} • Máy chính`;
        MG.toast(`Đã đẩy v${r.version} (${r.size_kb} KB) lên GitHub (${r.repo})!`);
      }
    } catch (e) { MG.toast('Lỗi kết nối GitHub'); }
    btnPub.disabled = false;
  };

  btnUpd.onclick = async () => {
    btnUpd.disabled = true; MG.toast('Đang kiểm tra bản cập nhật trên GitHub...');
    try {
      const chk = await MG.api('update/check');
      if (chk.error) { MG.toast('Lỗi kiểm tra: ' + chk.error); btnUpd.disabled = false; return; }
      const remoteVer = chk.remote ? chk.remote.version : null;
      if (!chk.has_update) {
        if (!remoteVer) {
          MG.toast('Chưa có bản cập nhật nào trên GitHub. Hãy bấm "⬆️ Đẩy bản cập nhật" ở máy chính trước.');
          btnUpd.disabled = false; return;
        }
        if (!confirm(`Máy đang ở bản v${chk.local.version} (trên GitHub là v${remoteVer}).\nBạn có muốn tải và cài đè lại bản v${remoteVer} không?`)) {
          btnUpd.disabled = false; return;
        }
      }
      MG.toast(`Đang tải và áp dụng bản v${remoteVer}...`);
      const res = await MG.api('update/pull', {});
      if (res.error) MG.toast('Lỗi cập nhật: ' + res.error);
      else {
        MG.toast(`Đã cập nhật lên v${res.version}! Đang nạp lại toàn bộ giao diện...`);
        setTimeout(() => location.replace('/?v=' + Date.now()), 800);
      }
    } catch (e) { MG.toast('Lỗi khi cập nhật'); }
    btnUpd.disabled = false;
  };

  refreshUpdateStatus();

  const ping = async () => {
    try {
      const r = await MG.api('ping', {});
      MG._srvRun = new Set(r.running || []);
      MG._srvWin = new Set(r.windows || []);
      refreshIndicators();
    } catch (e) { }
  };
  ping(); setInterval(ping, 2000);
  addEventListener('pagehide', () => navigator.sendBeacon('/api/bye', '{}'));
})();
