// Dữ liệu mẫu (viết lại bằng lời riêng, mang tính minh họa). Hãy tự kiểm tra text lá bài thật trong khung xem bài (lấy từ YGOPRODeck)
// và thêm/sửa combo của bạn ở tab "Quản lý". Dữ liệu bạn nhập được lưu trên trình duyệt, có thể Xuất/Nhập JSON.
window.YGO_SEED = {
  decks: [
    {
      id: 'basics-synchro',
      name_vi: 'Nhập môn: Synchro cơ bản',
      name_en: 'Basics: Synchro Summon',
      desc_vi: 'Làm quen cách triệu hồi Synchro: 1 Tuner + quái không-Tuner, tổng Level bằng Level của quái Synchro.',
      desc_en: 'Learn Synchro Summoning: 1 Tuner + non-Tuner monsters whose total Level equals the Synchro monster Level.',
      cards: ['Junk Synchron', 'Junk Warrior'],
      combos: [
        {
          id: 'synchro-101',
          level: 1,
          title_vi: 'Combo 1 — Synchro đầu tiên',
          title_en: 'Combo 1 — Your first Synchro',
          starter: ['Junk Synchron'],
          steps: [
            { vi: 'Kiểm tra tay bài: cần 1 Tuner và 1 quái không-Tuner có tổng Level phù hợp với quái Synchro trong Extra Deck.', en: 'Check your hand: you need a Tuner plus non-Tuner monster(s) whose total Level matches a Synchro in your Extra Deck.', cards: ['Junk Synchron'] },
            { vi: 'Đưa các nguyên liệu ra sân (Triệu hồi/Triệu hồi Đặc biệt theo hiệu ứng).', en: 'Get the materials onto the field (Normal/Special Summon using effects).', cards: [] },
            { vi: 'Ở Main Phase, tuyên bố Synchro Summon: gửi Tuner + quái không-Tuner xuống Mộ.', en: 'In the Main Phase, declare a Synchro Summon: send the Tuner and non-Tuner(s) to the GY.', cards: [] },
            { vi: 'Triệu hồi quái Synchro từ Extra Deck, rồi xem hiệu ứng của nó.', en: 'Summon the Synchro monster from the Extra Deck, then read its effect.', cards: ['Junk Warrior'] }
          ],
          result_vi: 'Bạn có 1 quái Synchro trên sân.',
          result_en: 'You have 1 Synchro monster on the field.'
        }
      ]
    },
    {
      id: 'basics-xyz',
      name_vi: 'Nhập môn: Xyz cơ bản',
      name_en: 'Basics: Xyz Summon',
      desc_vi: 'Triệu hồi Xyz: chồng 2+ quái cùng Level làm nguyên liệu, tạo quái Xyz có Rank bằng Level đó.',
      desc_en: 'Xyz Summon: overlay 2+ monsters of the same Level to make an Xyz monster with that Rank.',
      cards: ['Number 39: Utopia'],
      combos: [
        {
          id: 'xyz-101',
          level: 1,
          title_vi: 'Combo 1 — Xyz đầu tiên',
          title_en: 'Combo 1 — Your first Xyz',
          starter: [],
          steps: [
            { vi: 'Đưa 2 quái cùng Level ra sân.', en: 'Get 2 monsters of the same Level onto the field.', cards: [] },
            { vi: 'Chồng cả hai lên nhau và Triệu hồi Xyz quái có Rank tương ứng.', en: 'Overlay both and Xyz Summon a monster of the matching Rank.', cards: ['Number 39: Utopia'] },
            { vi: 'Nguyên liệu nằm dưới quái Xyz; dùng chúng để kích hoạt hiệu ứng khi cần.', en: 'Materials sit under the Xyz monster; detach them to activate effects when needed.', cards: [] }
          ],
          result_vi: 'Bạn có 1 quái Xyz với nguyên liệu gắn kèm.',
          result_en: 'You have 1 Xyz monster with attached materials.'
        }
      ]
    }
  ],
  glossary: [
    { vi: 'Triệu hồi Thường (Normal Summon)', en: 'Normal Summon', d_vi: 'Mỗi lượt thường được Triệu hồi/Úp 1 quái từ tay (trừ khi có hiệu ứng cho thêm).', d_en: 'Normally you may Normal Summon or Set 1 monster from your hand per turn (unless an effect allows more).' },
    { vi: 'Triệu hồi Đặc biệt (Special Summon)', en: 'Special Summon', d_vi: 'Triệu hồi bằng hiệu ứng hoặc quy tắc riêng, không tính vào lượt Triệu hồi Thường.', d_en: 'Summoning via an effect or special rule; it does not use your Normal Summon.' },
    { vi: 'Chain (Dây chuyền)', en: 'Chain', d_vi: 'Các hiệu ứng được kích hoạt nối tiếp nhau và thực thi theo thứ tự ngược (cái sau giải quyết trước).', d_en: 'Effects activated in sequence resolve in reverse order (last in, first out).' },
    { vi: 'Extra Deck', en: 'Extra Deck', d_vi: 'Nơi chứa quái Fusion, Synchro, Xyz, Link (tối đa 15 lá).', d_en: 'Holds Fusion, Synchro, Xyz and Link monsters (max 15 cards).' },
    { vi: 'Tuner', en: 'Tuner', d_vi: 'Quái đặc biệt dùng cùng quái không-Tuner để Synchro Summon.', d_en: 'A special monster used with non-Tuner monsters for Synchro Summons.' },
    { vi: 'Nguyên liệu (Material)', en: 'Material', d_vi: 'Quái được dùng/hy sinh để triệu hồi quái từ Extra Deck.', d_en: 'Monsters used up to Summon a monster from the Extra Deck.' },
    { vi: 'Mộ (Graveyard)', en: 'Graveyard (GY)', d_vi: 'Nơi chứa bài đã bị phá hủy, bỏ, hoặc dùng xong.', d_en: 'Where destroyed, discarded or used cards go.' },
    { vi: 'Hand trap', en: 'Hand trap', d_vi: 'Quái kích hoạt hiệu ứng ngay từ tay, thường để cản đối thủ.', d_en: 'A monster that activates its effect from your hand, usually to interrupt the opponent.' }
  ]
};
