// Trình xây dựng deck (Deck Builder): tìm bài thông minh (bỏ qua ký hiệu, chịu sai chính tả, gợi ý đích danh tên đầy đủ),
// đa hệ Banlist chuẩn xác (TCG, OCG, AE Asian-English, Master Duel, World, Genesys, OCG-CN, Edison, GOAT), đổi Alt Art/Overframe/Manga, rút thử & .ydk.
(function () {
  'use strict';
  const LS = 'ygo_decks_v1', LS_CUR = 'ygo_cur_deck_v1';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const isExtra = c => /Fusion|Synchro|XYZ|Link/i.test(c.type || '');
  const cat = c => /Spell/i.test(c.type) ? 'spell' : /Trap/i.test(c.type) ? 'trap' : 'monster';
  const slotId = x => (x && typeof x === 'object') ? x.id : x;
  const slotSpec = x => (x && typeof x === 'object') ? x.spec : null;
  const LIMITS = { main: [40, 60], extra: [0, 15], side: [0, 15] };

  const binom = (n, k) => { if (k < 0 || k > n) return 0; let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return r; };
  const pAtLeast1 = (N, K, n) => N <= 0 || K <= 0 ? 0 : 1 - binom(N - K, n) / binom(N, n);

  async function render(box, api) {
    box.innerHTML = '<p class="muted">Đang nạp kho bài &amp; Banlist... / Loading card database…</p>';
    const BAN = window.YGO_BAN, SMART = window.YGO_SMART, ART = window.YGO_ART, EFF = window.YGO_EFFECTS;
    const [cards] = await Promise.all([
      api.loadCards(),
      ART ? ART.loadSpecial() : Promise.resolve(),
      BAN ? BAN.loadBanMeta() : Promise.resolve(),
    ]);
    if (!cards || !cards.length) {
      box.innerHTML = `<h2>Xây dựng deck / Deck Builder</h2><div class="card">
        <p>Chưa có kho bài offline trên máy. Bấm <b>🗄 Kho bài &amp; luật → Cập nhật</b> ở thanh trên của MyingGo để lưu vĩnh viễn trên ổ đĩa, hoặc nạp trực tuyến ngay:</p>
        <p class="muted">No local card database yet. Update it from "Kho bài &amp; luật" for offline use, or load online from YGOPRODeck now:</p>
        <button class="primary" id="dbOnline">🌐 Nạp trực tuyến từ YGOPRODeck (~14.600 lá)</button>
      </div>`;
      const btn = box.querySelector('#dbOnline');
      if (btn && api.loadOnlineCards) {
        btn.onclick = async () => {
          btn.disabled = true; btn.textContent = '⏳ Đang tải kho bài từ YGOPRODeck...';
          const online = await api.loadOnlineCards();
          if (online && online.length) render(box, api);
          else { btn.disabled = false; btn.textContent = '🌐 Thử tải lại từ YGOPRODeck'; api.toast('Không kết nối được YGOPRODeck'); }
        };
      }
      return;
    }

    const byId = new Map();
    cards.forEach(c => { byId.set(c.id, c); (c.img || []).forEach(i => { if (!byId.has(i)) byId.set(i, c); }); });
    const cardOf = x => byId.get(slotId(x));
    const ruleName = c => (c && (c.alias || c.name)) || '';
    const playable = cards.filter(c => !/Skill Card|Token/i.test(c.type || ''));

    let decks = []; try { decks = JSON.parse(localStorage.getItem(LS)) || []; } catch (e) { }
    if (!decks.length) decks = [{ id: 'd' + Date.now(), name: 'Deck mới / New deck', format: 'tcg', main: [], extra: [], side: [] }];
    const savedCur = localStorage.getItem(LS_CUR);
    let cur = decks.some(d => d.id === savedCur) ? savedCur : decks[0].id;
    let shown = 96, hand = [], deckRem = [], lastFuzzy = false;
    const D = () => decks.find(d => d.id === cur) || decks[0];
    const persist = () => {
      try { localStorage.setItem(LS, JSON.stringify(decks)); localStorage.setItem(LS_CUR, cur); }
      catch (e) { api.toast('Bộ nhớ trình duyệt đầy'); }
    };

    const archetypes = [...new Set(playable.map(c => c.archetype).filter(Boolean))].sort();
    const attrs = [...new Set(playable.map(c => c.attribute).filter(Boolean))].sort();
    const races = [...new Set(playable.map(c => c.race).filter(Boolean))].sort();
    const fmtOpts = BAN ? BAN.FORMATS : [{ id: 'tcg', label: 'TCG' }, { id: 'ocg', label: 'OCG' }, { id: 'ae', label: 'AE' }, { id: 'goat', label: 'GOAT' }];

    box.innerHTML = `<h2>Xây dựng deck / Deck Builder</h2>
    <div class="row">
      <select id="dSel" style="min-width:210px"></select>
      <button id="dNew" class="small">+ Mới</button><button id="dRen" class="small">Đổi tên</button><button id="dDup" class="small">Nhân bản</button><button id="dSort" class="small" title="Sắp xếp chuẩn Quái → Phép → Bẫy">↕ Sắp xếp</button><button id="dClr" class="small">🧹 Làm trống</button><button id="dDel" class="small danger">Xóa deck</button>
      <select id="dFmt" title="Banlist áp dụng">
        ${fmtOpts.map(f => `<option value="${esc(f.id)}">Banlist ${esc(BAN ? BAN.formatLabel(f.id) : f.label)}</option>`).join('')}
        <option value="none">Không giới hạn (Unlimited)</option>
      </select>
      <button id="dImp" class="small">⬆ Nhập .ydk</button><button id="dExp" class="small">⬇ Xuất .ydk</button><button id="dTxt" class="small">📋 Copy list</button>${api.openTab ? '<button id="dCombo" class="small primary" title="Mở Sơ đồ combo với Deck này để dựng nhánh combo">🕸️ Tạo Combo từ Deck</button>' : ''}<input type="file" id="dFile" accept=".ydk,.txt" style="display:none">
    </div>
    <div class="dbgrid">
      <div class="card" id="dbLeft">
        <div class="row" style="justify-content:space-between;margin-top:0"><h3 style="margin:0">Tìm bài nhanh / Quick Search</h3>${api.openTab ? '<button id="goAdv" class="small">🔎 Lọc nâng cao</button>' : ''}</div>
        <div class="row"><input id="fName" placeholder="Gõ tên bài (vd: blue eyes, maxx c, sai chính tả vẫn nhận)…" style="flex:1;min-width:180px"></div>
        <div class="row">
          <select id="fType">
            <option value="">Mọi loại</option>
            <option value="Monster">Monster (Mọi quái)</option>
            <option value="Main Monster">Quái Main</option>
            <option value="Extra Deck">Extra Deck</option>
            <option value="Spell">Spell (Phép)</option>
            <option value="Trap">Trap (Bẫy)</option>
          </select>
          <select id="fAttr"><option value="">Thuộc tính</option>${attrs.map(t => `<option>${esc(t)}</option>`).join('')}</select>
          <select id="fRace"><option value="">Chủng tộc</option>${races.map(t => `<option>${esc(t)}</option>`).join('')}</select>
          <input id="fLv" type="number" min="0" max="13" placeholder="Lv/Link" style="width:76px">
        </div>
        <div class="row"><input id="fArc" list="arcList" placeholder="Archetype (vd: Blue-Eyes, Maliss)" style="flex:1"><datalist id="arcList">${archetypes.map(a => `<option value="${esc(a)}">`).join('')}</datalist></div>
        <div class="row" style="margin:6px 0">
          <label class="hint" style="cursor:pointer"><input type="checkbox" id="fSide"> Cho vào Side</label>
          <label class="hint" style="cursor:pointer"><input type="checkbox" id="fMulti"> 🎨 Chỉ lá có Alt Art</label>
          <button type="button" id="fReset" class="small" style="margin-left:auto">↺ Xóa lọc</button>
        </div>
        <div id="dbEffHost" class="eff-host"></div>
        <div class="hint" id="fCount"></div>
        <div id="results" class="resgrid"></div>
        <div class="row"><button id="more" class="small">Xem thêm / Show more</button></div>
        <div class="hint">Bấm ảnh = thêm/gỡ • 🔍 = xem chi tiết • 🎨 = đổi Alt Art / Overframe / Manga.</div>
      </div>
      <div id="dbRight">
        <div class="card"><div id="dStats"></div></div>
        <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Main Deck <span id="cM" class="badge"></span></h3><div id="zMain" class="zone"></div></div>
        <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Extra Deck <span id="cE" class="badge"></span></h3><div id="zExtra" class="zone"></div></div>
        <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Side Deck <span id="cS" class="badge"></span></h3><div id="zSide" class="zone"></div></div>
        <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Rút thử tay bài / Test Hand Simulator</h3>
          <div class="row"><button id="drawBtn" class="primary small">🎲 Rút 5 lá (Đi trước)</button><button id="draw6" class="small">🎲 Rút 6 lá (Đi sau)</button><button id="drawPlus" class="small">+1 Rút thêm</button><span class="hint" id="drawInfo"></span></div><div id="hand" class="zone"></div></div>
        <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Xác suất có ≥1 lá trong tay đầu (5 lá) / P(≥1 in opening hand)</h3><div id="probs" class="hint"></div></div>
      </div>
    </div>`;
    const $ = s => box.querySelector(s);
    const effCtrl = EFF ? EFF.mountEffectFilter($('#dbEffHost'), {
      compact: true,
      onChange: () => { shown = 96; drawResults(); },
    }) : null;

    function banInfoFor(c) {
      const f = D().format;
      if (!BAN || !f || f === 'none') return { limit: 3, status: '', points: 0 };
      return BAN.getCardBan(c, f);
    }
    const limitFor = c => banInfoFor(c).limit;

    // Đếm tổng số bản sao trong Main + Extra + Side (tính gộp cả các lá treated_as cùng tên theo luật chính thức)
    const countOfCard = targetCard => {
      const d = D(), rName = ruleName(targetCard);
      return d.main.concat(d.extra, d.side).filter(x => {
        const c = cardOf(x);
        return c && (c.id === targetCard.id || (rName && ruleName(c) === rName));
      }).length;
    };

    function addCard(c) {
      const d = D();
      const toSide = $('#fSide').checked;
      const zone = toSide ? 'side' : (isExtra(c) ? 'extra' : 'main');
      const lim = limitFor(c);
      if (lim === 0) return api.toast(`🚫 "${c.name}" đang bị CẤM (Forbidden) trong ${d.format.toUpperCase()}!`);
      if (countOfCard(c) >= lim) return api.toast(`"${c.name}": tối đa ${lim} lá trong ${d.format.toUpperCase()}`);
      if (d[zone].length >= LIMITS[zone][1]) return api.toast(`${zone.toUpperCase()} đã đầy / full (${LIMITS[zone][1]})`);
      const defSpec = ART ? ART.getDefaultSpec(c.id) : null;
      d[zone].push(defSpec ? { id: c.id, spec: { ...defSpec } } : c.id);
      persist(); draw();
    }
    function removeCard(zone, idx) { D()[zone].splice(idx, 1); persist(); draw(); }

    function applySpecAllCopies(canonicalId, spec) {
      const d = D();
      ['main', 'extra', 'side'].forEach(z => {
        d[z] = d[z].map(x => {
          const c = cardOf(x);
          if (!c || c.id !== canonicalId) return x;
          return spec ? { id: c.id, spec: { ...spec } } : c.id;
        });
      });
      persist(); draw(); updateHandUI();
    }

    function sortDeck() {
      const d = D();
      const rankMain = c => !c ? 9 : cat(c) === 'monster' ? 1 : cat(c) === 'spell' ? 2 : 3;
      const rankExtra = c => !c ? 9 : /Fusion/i.test(c.type) ? 1 : /Synchro/i.test(c.type) ? 2 : /XYZ/i.test(c.type) ? 3 : 4;
      const cmp = (rankFn) => (a, b) => {
        const ca = cardOf(a), cb = cardOf(b);
        const ra = rankFn(ca), rb = rankFn(cb);
        if (ra !== rb) return ra - rb;
        if (!ca || !cb) return 0;
        const la = ca.level != null ? ca.level : (ca.linkval || 0);
        const lb = cb.level != null ? cb.level : (cb.linkval || 0);
        if (la !== lb) return lb - la;
        if ((cb.atk || 0) !== (ca.atk || 0)) return (cb.atk || 0) - (ca.atk || 0);
        return String(ca.name).localeCompare(String(cb.name));
      };
      d.main.sort(cmp(rankMain));
      d.extra.sort(cmp(rankExtra));
      d.side.sort(cmp(rankMain));
      persist(); draw(); api.toast('Đã sắp xếp deck / Deck sorted');
    }

    function filtered() {
      const rawQ = $('#fName').value.trim(), t = $('#fType').value, a = $('#fAttr').value, r = $('#fRace').value, lv = $('#fLv').value;
      const arc = SMART ? SMART.normSpaced($('#fArc').value) : $('#fArc').value.trim().toLowerCase();
      const onlyMulti = $('#fMulti').checked;
      const pre = playable.filter(c => {
        if (onlyMulti && (!ART || ART.variantCount(c) <= 1)) return false;
        if (t) {
          const isM = cat(c) === 'monster';
          if (t === 'Extra Deck' ? !isExtra(c) : t === 'Main Monster' ? !(isM && !isExtra(c)) : t === 'Monster' ? !isM : t === 'Spell' ? cat(c) !== 'spell' : cat(c) !== 'trap') return false;
        }
        if (a && c.attribute !== a) return false;
        if (r && c.race !== r) return false;
        const clv = c.level != null ? c.level : c.linkval;
        if (lv !== '' && Number(clv) !== Number(lv)) return false;
        if (arc) {
          const ca = SMART ? SMART.normSpaced(c.archetype || '') : String(c.archetype || '').toLowerCase();
          if (!ca.includes(arc)) return false;
        }
        if (EFF && effCtrl && effCtrl.hasActive() && !EFF.matchesFilter(c, effCtrl.getState())) return false;
        return true;
      });
      lastFuzzy = false;
      if (rawQ && SMART) {
        const sr = SMART.searchCards(pre, rawQ, 'both');
        lastFuzzy = sr.fuzzyUsed;
        return sr.items;
      }
      return pre;
    }

    function cardTile(c, onClick, badge, spec, onArtClick, showAltCount) {
      const el = document.createElement('div'); el.className = 'tile';
      el.appendChild(ART ? ART.renderCardVisual(c, spec, 'sm') : document.createElement('img'));
      const z = document.createElement('span'); z.className = 'tzoom'; z.title = 'Xem chi tiết / Inspect'; z.textContent = '🔍';
      z.onclick = e => { e.stopPropagation(); api.showCard(c.name, spec); };
      el.appendChild(z);
      if (ART && onArtClick) {
        const ab = document.createElement('span'); ab.className = 'tart'; ab.title = 'Đổi Alt Art / Overframe / Manga'; ab.textContent = '🎨';
        ab.onclick = e => { e.stopPropagation(); onArtClick(); };
        el.appendChild(ab);
      }
      if (ART && showAltCount) {
        const nArt = ART.variantCount(c);
        if (nArt > 1) { const m = document.createElement('span'); m.className = 'talt'; m.textContent = '🎨' + nArt; el.appendChild(m); }
      }
      if (badge) { const b = document.createElement('span'); b.className = 'tb ' + (badge.cls || ''); b.textContent = badge.text; el.appendChild(b); }
      el.onclick = onClick; el.oncontextmenu = e => { e.preventDefault(); api.showCard(c.name, spec); };
      return el;
    }

    function drawResults() {
      const list = filtered(); const res = $('#results'); res.innerHTML = '';
      const fzTxt = lastFuzzy && list.length ? ` • 💡 Khớp gần đúng "${list[0].name}"` : '';
      $('#fCount').textContent = `${list.length} lá phù hợp${fzTxt}`;
      list.slice(0, shown).forEach(c => {
        const bi = banInfoFor(c), lim = bi.limit, n = countOfCard(c);
        let badge = null;
        if (lim < 3) badge = { text: lim === 0 ? '✖' : String(lim), cls: lim === 0 ? 'red' : 'amber' };
        else if (bi.points) badge = { text: `${bi.points}p`, cls: n ? '' : 'amber' };
        else if (n) badge = { text: 'x' + n, cls: '' };
        const onArt = () => ART.openPicker(c, {
          toast: api.toast,
          onApplyAll: spec => applySpecAllCopies(c.id, spec),
        });
        res.appendChild(cardTile(c, () => addCard(c), badge, null, onArt, true));
      });
      $('#more').style.display = list.length > shown ? '' : 'none';
    }

    function drawZone(zone, el) {
      const d = D(); el.innerHTML = '';
      d[zone].forEach((entry, i) => {
        const c = cardOf(entry);
        if (!c) { const m = document.createElement('div'); m.className = 'tile'; m.title = 'Không có trong kho: ' + slotId(entry); m.textContent = '?'; m.onclick = () => removeCard(zone, i); el.appendChild(m); return; }
        const spec = slotSpec(entry);
        const bi = banInfoFor(c);
        const bad = countOfCard(c) > bi.limit || bi.limit === 0;
        const onArt = () => ART.openPicker(c, {
          currentSpec: spec,
          toast: api.toast,
          onApplySingle: newSpec => {
            d[zone][i] = newSpec ? { id: c.id, spec: { ...newSpec } } : c.id;
            persist(); draw();
            if (newSpec) api.toast(`Đã đổi Art riêng cho bản sao #${i + 1} của "${c.name}"`);
          },
          onApplyAll: newSpec => applySpecAllCopies(c.id, newSpec),
        });
        const badge = bad ? { text: '!', cls: 'red' } : (bi.points ? { text: `${bi.points}p`, cls: '' } : null);
        el.appendChild(cardTile(c, () => removeCard(zone, i), badge, spec, onArt, false));
      });
      if (!d[zone].length) el.innerHTML = '<span class="hint">Trống — bấm lá bài ở cột trái để thêm (rê chuột lên lá bài và bấm 🎨 để đổi Overframe / Manga / Alt Art).</span>';
    }

    function drawStats() {
      const d = D(); const mc = { monster: 0, spell: 0, trap: 0 }; let lvSum = 0, lvN = 0, totalPoints = 0;
      let nHandtrap = 0, nConsist = 0, nDisrupt = 0, nSelfLock = 0;
      d.main.forEach(x => {
        const c = cardOf(x); if (!c) return;
        mc[cat(c)]++;
        if (cat(c) === 'monster' && c.level != null) { lvSum += c.level; lvN++; }
        if (EFF) {
          const { tags } = EFF.analyzeCard(c);
          if (tags.has('mod_handtrap')) nHandtrap++;
          if (tags.has('res_search') || tags.has('res_draw') || tags.has('res_set_deck')) nConsist++;
          if (tags.has('neg_omni') || tags.has('neg_monster') || tags.has('neg_st') || tags.has('neg_summon') || tags.has('rm_destroy') || tags.has('rm_banish') || tags.has('rm_tribute')) nDisrupt++;
          if (tags.has('lock_self')) nSelfLock++;
        }
      });
      const warns = [];
      if (d.main.length < LIMITS.main[0]) warns.push(`Main thiếu: cần tối thiểu ${LIMITS.main[0]} lá (hiện ${d.main.length}) / Main needs ≥ ${LIMITS.main[0]}`);
      const seenRule = new Set();
      d.main.concat(d.extra, d.side).forEach(x => {
        const c = cardOf(x); if (!c) return;
        const bi = banInfoFor(c);
        if (bi.points) totalPoints += bi.points;
        const rk = ruleName(c) || String(c.id);
        if (seenRule.has(rk)) return;
        seenRule.add(rk);
        const lim = bi.limit, n = countOfCard(c);
        if (lim === 0) warns.push(`"${c.name}": bị CẤM (Forbidden) trong ${d.format.toUpperCase()}`);
        else if (n > lim) warns.push(`"${rk}": đang có ${n} lá, giới hạn tối đa ${lim} lá`);
      });
      if (d.format === 'genesys' && totalPoints > 100) {
        warns.push(`Genesys vượt trần điểm: ${totalPoints}/100 pts`);
      }
      const ptsBadge = (d.format === 'genesys' || totalPoints > 0) ? `<span class="badge">Điểm Genesys: ${totalPoints}/100 pts</span>` : '';
      const roleBadges = (EFF && d.main.length > 0)
        ? `<span class="badge" style="color:#fde047" title="Số lá Handtrap trong Main Deck">🖐️ Handtrap ${nHandtrap}</span><span class="badge" style="color:#7dd3fc" title="Số lá Rút / Search / Đặt thẳng từ Deck trong Main">🔍 Mở bài ${nConsist}</span><span class="badge" style="color:#fda4af" title="Số lá Negate / Phá bàn trong Main">🛑 Cản/Gỡ ${nDisrupt}</span>${nSelfLock ? `<span class="badge" style="color:#e9d5ff" title="Số lá có điều kiện tự khóa trong Main">⚠️ Tự khóa ${nSelfLock}</span>` : ''}`
        : '';
      $('#dStats').innerHTML = `<b>${esc(d.name)}</b> — Main <b>${d.main.length}</b> • Extra <b>${d.extra.length}</b> • Side <b>${d.side.length}</b><br>
        <span class="badge">Quái ${mc.monster}</span><span class="badge">Phép ${mc.spell}</span><span class="badge">Bẫy ${mc.trap}</span>${lvN ? `<span class="badge">Level TB ${(lvSum / lvN).toFixed(1)}</span>` : ''}${ptsBadge}${roleBadges}
        ${warns.length ? `<div class="warn">${warns.map(w => '⚠ ' + esc(w)).join('<br>')}</div>` : `<div style="color:#4ade80;margin-top:6px">✔ Deck hợp lệ theo Banlist ${esc((BAN && d.format !== 'none') ? BAN.formatLabel(d.format) : 'Unlimited')}</div>`}`;
      $('#cM').textContent = `${d.main.length}/${LIMITS.main[1]}`; $('#cE').textContent = `${d.extra.length}/15`; $('#cS').textContent = `${d.side.length}/15`;
      const N = d.main.length, cnt = {};
      d.main.forEach(x => { const c = cardOf(x); if (c) cnt[c.id] = (cnt[c.id] || 0) + 1; });
      const rows = Object.entries(cnt).map(([id, k]) => ({ c: byId.get(+id), k, p: pAtLeast1(N, k, Math.min(5, N)) })).filter(r => r.c).sort((a, b) => b.p - a.p);
      $('#probs').innerHTML = N < 5 ? 'Cần ít nhất 5 lá trong Main. / Need ≥ 5 cards in Main.' :
        `<table class="ptab">${rows.map(r => `<tr><td>${esc(r.c.name)}</td><td>x${r.k}</td><td>${(r.p * 100).toFixed(1)}%</td></tr>`).join('')}</table>`;
    }

    function updateHandUI() {
      const h = $('#hand'); h.innerHTML = '';
      hand.forEach(entry => {
        const c = cardOf(entry);
        if (c) h.appendChild(cardTile(c, () => api.showCard(c.name, slotSpec(entry)), null, slotSpec(entry), null, false));
      });
      const mons = hand.filter(entry => { const c = cardOf(entry); return c && cat(c) === 'monster'; }).length;
      $('#drawInfo').textContent = hand.length ? `${hand.length} lá trên tay (${mons} quái • ${hand.length - mons} phép/bẫy • còn ${deckRem.length} lá trong Main)` : '';
    }
    function drawN(n) {
      const pool = D().main.slice(); if (pool.length < n) return api.toast('Main chưa đủ lá / not enough cards');
      for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
      hand = pool.slice(0, n); deckRem = pool.slice(n); updateHandUI();
    }

    function draw() {
      const d = D();
      if ([...$('#dFmt').options].some(o => o.value === d.format)) $('#dFmt').value = d.format;
      else { d.format = 'tcg'; $('#dFmt').value = 'tcg'; }
      $('#dSel').innerHTML = decks.map(x => `<option value="${esc(x.id)}" ${x.id === cur ? 'selected' : ''}>${esc(x.name)} (${x.main.length}/${x.extra.length}/${x.side.length})</option>`).join('');
      drawZone('main', $('#zMain')); drawZone('extra', $('#zExtra')); drawZone('side', $('#zSide'));
      drawStats(); drawResults();
    }

    // Gắn gợi ý đích danh tên đầy đủ của lá bài cho ô Tìm bài nhanh trong Deck Builder
    if (SMART) {
      SMART.attachAutocomplete($('#fName'), {
        getCards: () => playable,
        onSelect: () => { shown = 96; drawResults(); },
      });
    }

    if ($('#goAdv')) $('#goAdv').onclick = () => api.openTab('search');
    if ($('#dCombo')) $('#dCombo').onclick = () => {
      persist();
      sessionStorage.setItem('ygo_combo_deck_id', cur);
      api.openTab('map');
    };
    $('#fReset').onclick = () => {
      ['#fName', '#fLv', '#fArc'].forEach(s => $(s).value = '');
      ['#fType', '#fAttr', '#fRace'].forEach(s => $(s).selectedIndex = 0);
      $('#fMulti').checked = false;
      if (effCtrl) effCtrl.reset();
      else { shown = 96; drawResults(); }
    };
    let tm; ['#fName', '#fLv', '#fArc'].forEach(s => $(s).oninput = () => { clearTimeout(tm); tm = setTimeout(() => { shown = 96; drawResults(); }, 160); });
    ['#fType', '#fAttr', '#fRace', '#fMulti'].forEach(s => $(s).onchange = () => { shown = 96; drawResults(); });
    $('#more').onclick = () => { shown += 96; drawResults(); };
    $('#dSel').onchange = e => {
      cur = e.target.value; localStorage.setItem(LS_CUR, cur); hand = []; deckRem = []; updateHandUI();
      (BAN ? BAN.loadBanlist(D().format) : Promise.resolve()).then(draw);
    };
    $('#dFmt').onchange = async e => {
      D().format = e.target.value;
      if (BAN) await BAN.loadBanlist(e.target.value);
      persist(); draw();
    };
    $('#dNew').onclick = () => { const n = prompt('Tên deck / Deck name:', 'Deck mới'); if (!n) return; const d = { id: 'd' + Date.now(), name: n, format: D().format, main: [], extra: [], side: [] }; decks.push(d); cur = d.id; persist(); draw(); };
    $('#dRen').onclick = () => { const n = prompt('Đổi tên / Rename:', D().name); if (n) { D().name = n; persist(); draw(); } };
    $('#dDup').onclick = () => { const s = D(); const d = JSON.parse(JSON.stringify(s)); d.id = 'd' + Date.now(); d.name = s.name + ' (copy)'; decks.push(d); cur = d.id; persist(); draw(); };
    $('#dSort').onclick = sortDeck;
    $('#dClr').onclick = () => { if (!confirm('Xóa toàn bộ lá bài trong deck hiện tại? / Clear all cards in this deck?')) return; const d = D(); d.main = []; d.extra = []; d.side = []; hand = []; deckRem = []; updateHandUI(); persist(); draw(); };
    $('#dDel').onclick = () => { if (!confirm('Xóa deck này? / Delete this deck?')) return; decks = decks.filter(x => x.id !== cur); if (!decks.length) decks = [{ id: 'd' + Date.now(), name: 'Deck mới', format: 'tcg', main: [], extra: [], side: [] }]; cur = decks[0].id; persist(); draw(); };
    $('#drawBtn').onclick = () => drawN(5);
    $('#draw6').onclick = () => drawN(6);
    $('#drawPlus').onclick = () => { if (!hand.length) return drawN(5); if (!deckRem.length) return api.toast('Đã hết bài trong Main'); hand.push(deckRem.shift()); updateHandUI(); };
    $('#dExp').onclick = () => {
      const d = D();
      const ydkCode = x => {
        const sp = slotSpec(x) || (ART && cardOf(x) ? ART.getDefaultSpec(cardOf(x).id) : null);
        if (sp && sp.imgId && !sp.src) return sp.imgId;
        const c = cardOf(x);
        return c ? c.id : slotId(x);
      };
      const txt = ['#created by MyingGo', '#main', ...d.main.map(ydkCode), '#extra', ...d.extra.map(ydkCode), '!side', ...d.side.map(ydkCode)].join('\r\n') + '\r\n';
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'text/plain' })); a.download = (d.name || 'deck').replace(/[^\w\- ]+/g, '_') + '.ydk'; a.click();
    };
    $('#dTxt').onclick = () => {
      const d = D();
      const fmtZone = (title, arr) => {
        const m = new Map();
        arr.forEach(x => { const c = cardOf(x); const k = c ? c.id : slotId(x); m.set(k, (m.get(k) || 0) + 1); });
        const lines = [...m.entries()].map(([id, k]) => `${k}x ${(byId.get(id) || { name: id }).name}`);
        return `${title} (${arr.length}):\n` + (lines.join('\n') || '(trống)');
      };
      const out = `=== ${d.name} [${d.format.toUpperCase()}] ===\n\n` + [fmtZone('Main Deck', d.main), fmtZone('Extra Deck', d.extra), fmtZone('Side Deck', d.side)].join('\n\n');
      navigator.clipboard.writeText(out).then(() => api.toast('Đã copy danh sách bài vào clipboard!')).catch(() => api.toast('Không copy được'));
    };
    $('#dImp').onclick = () => $('#dFile').click();
    $('#dFile').onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      const lines = (await f.text()).split(/\r?\n/).map(s => s.trim()); const d = { id: 'd' + Date.now(), name: f.name.replace(/\.(ydk|txt)$/i, ''), format: D().format, main: [], extra: [], side: [] };
      let zone = 'main', miss = 0;
      lines.forEach(l => {
        if (/^#main/i.test(l)) zone = 'main';
        else if (/^#extra/i.test(l)) zone = 'extra';
        else if (/^!side/i.test(l)) zone = 'side';
        else if (/^\d+$/.test(l)) {
          const code = +l, c = byId.get(code);
          if (c) {
            d[zone].push(code !== c.id ? { id: c.id, spec: { style: 'standard', imgId: code, label: 'Alt Art' } } : c.id);
          } else miss++;
        }
      });
      decks.push(d); cur = d.id; persist(); draw(); api.toast(`Đã nhập ${d.main.length + d.extra.length + d.side.length} lá` + (miss ? ` (${miss} lá không có trong kho)` : ''));
      e.target.value = '';
    };

    if (BAN) await BAN.loadBanlist(D().format);
    draw();
  }
  window.YGO_DECK = { render };
})();
