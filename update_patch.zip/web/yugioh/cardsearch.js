// Tìm kiếm lá bài thông minh (bỏ qua ký hiệu '-', '"', ':', tự sửa lỗi chính tả, gợi ý tên đầy đủ ngay khi gõ)
// + Đa hệ Banlist chuẩn xác (TCG, OCG, AE Asian-English, Master Duel, World, Genesys, OCG-CN, Edison, GOAT) + Đổi Art / Thêm vào Deck.
(function () {
  'use strict';
  const LS = 'ygo_decks_v1', LS_CUR = 'ygo_cur_deck_v1';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const isExtra = c => /Fusion|Synchro|XYZ|Link/i.test(c.type || '');
  const slotId = x => (x && typeof x === 'object') ? x.id : x;
  const fmtStat = v => v < 0 ? '?' : v;
  const SUBTYPES = ['Normal', 'Effect', 'Ritual', 'Fusion', 'Synchro', 'XYZ', 'Pendulum', 'Link', 'Tuner', 'Flip', 'Toon', 'Spirit', 'Union', 'Gemini',
    'Quick-Play', 'Continuous', 'Equip', 'Field', 'Counter'];

  async function render(box, api) {
    box.innerHTML = '<p class="muted">Đang nạp kho bài &amp; Banlist... / Loading card database…</p>';
    const BAN = window.YGO_BAN, SMART = window.YGO_SMART, ART = window.YGO_ART, EFF = window.YGO_EFFECTS;
    const [cards] = await Promise.all([
      api.loadCards(),
      ART ? ART.loadSpecial() : Promise.resolve(),
      BAN ? BAN.loadBanMeta() : Promise.resolve(),
    ]);
    if (!cards || !cards.length) {
      box.innerHTML = `<h2>Tìm bài / Card Search</h2><div class="card">
        <p>Chưa có kho bài offline trên máy. Bấm <b>🗄 Kho bài &amp; luật → Cập nhật</b> ở thanh trên của MyingGo để lưu vĩnh viễn trên ổ đĩa, hoặc nạp trực tuyến ngay bây giờ:</p>
        <p class="muted">No local card database yet. Update it from "Kho bài &amp; luật" for instant offline use, or load online from YGOPRODeck now:</p>
        <button class="primary" id="sOnline">🌐 Nạp trực tuyến từ YGOPRODeck (~14.600 lá)</button>
      </div>`;
      const btn = box.querySelector('#sOnline');
      if (btn && api.loadOnlineCards) {
        btn.onclick = async () => {
          btn.disabled = true; btn.textContent = '⏳ Đang tải kho bài từ YGOPRODeck...';
          const online = await api.loadOnlineCards();
          if (online && online.length) render(box, api);
          else { btn.disabled = false; btn.textContent = '🌐 Thử tải lại từ YGOPRODeck'; api.toast('Không kết nối được YGOPRODeck'); }
        };
      }
      return;
    }

    const all = cards.filter(c => !/Skill Card|Token/i.test(c.type || ''));
    const archetypes = [...new Set(all.map(c => c.archetype).filter(Boolean))].sort();
    const attrs = [...new Set(all.map(c => c.attribute).filter(Boolean))].sort();
    const races = [...new Set(all.map(c => c.race).filter(Boolean))].sort();
    const setNames = [...new Set(all.flatMap(c => (c.sets || []).map(s => s.n)).filter(Boolean))].sort();

    if (BAN) {
      await Promise.all(['tcg', 'ocg', 'ae', 'md'].map(f => BAN.loadBanlist(f)));
    }
    const fmtOpts = BAN ? BAN.FORMATS : [{ id: 'tcg', label: 'TCG' }, { id: 'ocg', label: 'OCG' }, { id: 'ae', label: 'AE' }, { id: 'goat', label: 'GOAT' }];
    let shown = 72, sel = null, list = [], lastFuzzy = false;

    box.innerHTML = `<h2>Tìm kiếm lá bài / Card Search</h2>
    <div class="searchgrid">
      <div>
        <div class="card">
          <div class="row">
            <input id="sq" placeholder="Gõ tên bài (vd: blue eyes, maxx c, ip masq, sai chính tả vẫn nhận)…" style="flex:1;min-width:220px">
            <select id="sm"><option value="both">Tên + hiệu ứng</option><option value="name">Chỉ tên</option><option value="text">Chỉ hiệu ứng</option></select>
          </div>
          <div class="row">
            <select id="sT">
              <option value="">Mọi loại / All Types</option>
              <option value="Monster">Monster (Mọi quái)</option>
              <option value="Main Monster">Quái Main Deck</option>
              <option value="Extra Deck">Quái Extra Deck</option>
              <option value="Spell">Spell (Phép)</option>
              <option value="Trap">Trap (Bẫy)</option>
            </select>
            <select id="sS"><option value="">Phân loại / Subtype</option>${SUBTYPES.map(s => `<option>${s}</option>`).join('')}</select>
            <select id="sA"><option value="">Thuộc tính / Attribute</option>${attrs.map(s => `<option>${esc(s)}</option>`).join('')}</select>
            <select id="sR"><option value="">Chủng tộc / Race</option>${races.map(s => `<option>${esc(s)}</option>`).join('')}</select>
          </div>
          <div class="row">
            Lv/Rank/Link <input id="lvA" type="number" min="0" max="13" style="width:62px" placeholder="từ"> – <input id="lvB" type="number" min="0" max="13" style="width:62px" placeholder="đến">
            ATK <input id="atA" type="number" style="width:78px" placeholder="từ"> – <input id="atB" type="number" style="width:78px" placeholder="đến">
            DEF <input id="dfA" type="number" style="width:78px" placeholder="từ"> – <input id="dfB" type="number" style="width:78px" placeholder="đến">
          </div>
          <div class="row">
            <input id="sArc" list="sArcL" placeholder="Tộc bài / Archetype (vd: Blue-Eyes, Maliss, Ryzeal)" style="flex:1;min-width:170px"><datalist id="sArcL">${archetypes.map(a => `<option value="${esc(a)}">`).join('')}</datalist>
            <input id="sSet" list="sSetL" placeholder="Bộ bài / Pack (vd: Legend of Blue Eyes)" style="flex:1;min-width:190px"><datalist id="sSetL">${setNames.map(a => `<option value="${esc(a)}">`).join('')}</datalist>
          </div>
          <div class="row">
            <select id="sBF" title="Chọn hệ Banlist">${fmtOpts.map(f => `<option value="${esc(f.id)}">Banlist ${esc(BAN ? BAN.formatLabel(f.id) : f.label)}</option>`).join('')}</select>
            <select id="sBS">
              <option value="">Mọi trạng thái</option>
              <option value="Forbidden">🚫 Cấm / Forbidden (0)</option>
              <option value="Limited">1️⃣ Giới hạn 1 / Limited (1)</option>
              <option value="Semi-Limited">2️⃣ Giới hạn 2 / Semi-Limited (2)</option>
              <option value="any">⚖️ Toàn bộ lá trong Banlist này</option>
            </select>
            <select id="sSort"><option value="rel">Sắp xếp: Sát tên nhất</option><option value="name">Tên A–Z</option><option value="atk">ATK</option><option value="def">DEF</option><option value="level">Level / Link</option></select>
            <select id="sDir"><option value="asc">Tăng ↑</option><option value="desc">Giảm ↓</option></select>
            <label class="hint" style="cursor:pointer"><input type="checkbox" id="sMulti"> 🎨 Có Alt Art</label>
            <button id="sClear" class="small">↺ Xóa lọc</button>
          </div>
          <div id="sEffHost" class="eff-host"></div>
          <div class="hint" id="sCount"></div>
        </div>
        <div id="sRes" class="resgrid" style="max-height:none;margin-top:12px"></div>
        <div class="row"><button id="sMore" class="small">Xem thêm / Show more</button></div>
      </div>
      <div class="card" id="sDetail" style="position:sticky;top:76px"><p class="muted">Bấm vào một lá bài để xem chi tiết. / Click a card for details.</p></div>
    </div>`;
    const $ = s => box.querySelector(s);
    const effCtrl = EFF ? EFF.mountEffectFilter($('#sEffHost'), {
      compact: false,
      onChange: () => { shown = 72; draw(); },
    }) : null;

    const getDecks = () => {
      let ds = []; try { ds = JSON.parse(localStorage.getItem(LS)) || []; } catch (e) { }
      if (!ds.length) {
        ds = [{ id: 'd' + Date.now(), name: 'Deck mới / New deck', format: 'tcg', main: [], extra: [], side: [] }];
        try { localStorage.setItem(LS, JSON.stringify(ds)); } catch (e) { }
      }
      return ds;
    };

    const num = id => { const v = $(id).value; return v === '' ? null : Number(v); };
    function filter() {
      const rawQ = $('#sq').value.trim(), mode = $('#sm').value, t = $('#sT').value, sub = $('#sS').value.toLowerCase(), a = $('#sA').value, r = $('#sR').value;
      const lvA = num('#lvA'), lvB = num('#lvB'), atA = num('#atA'), atB = num('#atB'), dfA = num('#dfA'), dfB = num('#dfB');
      const arc = SMART ? SMART.normSpaced($('#sArc').value) : $('#sArc').value.trim().toLowerCase();
      const set = SMART ? SMART.normSpaced($('#sSet').value) : $('#sSet').value.trim().toLowerCase();
      const bf = $('#sBF').value, bs = $('#sBS').value, onlyMulti = $('#sMulti').checked;

      // Bước 1: Lọc theo thuộc tính / loại / chỉ số / banlist trước
      const pre = all.filter(c => {
        if (onlyMulti && (!ART || ART.variantCount(c) <= 1)) return false;
        if (t) {
          const isM = !/Spell|Trap/i.test(c.type);
          if (t === 'Extra Deck' ? !isExtra(c) : t === 'Main Monster' ? !(isM && !isExtra(c)) : t === 'Monster' ? !isM : !new RegExp(t, 'i').test(c.type)) return false;
        }
        if (sub && !(String(c.type).toLowerCase().includes(sub) || String(c.race).toLowerCase() === sub)) return false;
        if (a && c.attribute !== a) return false;
        if (r && c.race !== r) return false;
        const lv = c.level != null ? c.level : (c.linkval != null ? c.linkval : null);
        if ((lvA != null || lvB != null) && (lv == null || (lvA != null && lv < lvA) || (lvB != null && lv > lvB))) return false;
        if ((atA != null || atB != null) && (c.atk == null || c.atk < 0 || (atA != null && c.atk < atA) || (atB != null && c.atk > atB))) return false;
        if ((dfA != null || dfB != null) && (c.def == null || c.def < 0 || (dfA != null && c.def < dfA) || (dfB != null && c.def > dfB))) return false;
        if (arc) {
          const ca = SMART ? SMART.normSpaced(c.archetype || '') : String(c.archetype || '').toLowerCase();
          if (!ca.includes(arc)) return false;
        }
        if (set) {
          const hasSet = (c.sets || []).some(s => (SMART ? SMART.normSpaced(s.n || '') : String(s.n || '').toLowerCase()).includes(set) || String(s.c || '').toLowerCase().includes(set));
          if (!hasSet) return false;
        }
        if (bs && BAN) {
          const bi = BAN.getCardBan(c, bf);
          if (bs === 'any') { if (!bi.status) return false; }
          else if (bi.status !== bs) return false;
        }
        if (EFF && effCtrl && effCtrl.hasActive() && !EFF.matchesFilter(c, effCtrl.getState())) return false;
        return true;
      });

      // Bước 2: Tìm kiếm từ khóa thông minh (chịu sai dấu gạch/ký hiệu & sai chính tả)
      let out = pre;
      lastFuzzy = false;
      if (rawQ && SMART) {
        const sr = SMART.searchCards(pre, rawQ, mode);
        out = sr.items;
        lastFuzzy = sr.fuzzyUsed;
      }

      const key = $('#sSort').value, dir = $('#sDir').value === 'desc' ? -1 : 1;
      if (key === 'rel') {
        if (!rawQ) {
          out.sort((x, y) => dir * String(x.name).localeCompare(String(y.name)));
        } else if (dir === -1) {
          out.reverse();
        }
      } else {
        out.sort((x, y) => {
          if (key === 'name') return dir * String(x.name).localeCompare(String(y.name));
          const gx = key === 'level' ? (x.level != null ? x.level : x.linkval) : x[key];
          const gy = key === 'level' ? (y.level != null ? y.level : y.linkval) : y[key];
          if (gx == null && gy == null) return 0; if (gx == null) return 1; if (gy == null) return -1;
          return dir * (gx - gy);
        });
      }
      return out;
    }

    async function addToDeck(c, toSide) {
      const decks = getDecks();
      const id = $('#dkSel') ? $('#dkSel').value : '';
      const d = decks.find(x => x.id === id) || decks[0];
      localStorage.setItem(LS_CUR, d.id);
      if (BAN && d.format && d.format !== 'none') await BAN.loadBanlist(d.format);
      const zone = toSide ? 'side' : (isExtra(c) ? 'extra' : 'main');
      const max = zone === 'main' ? 60 : 15;
      const targetName = c.alias || c.name;
      const have = d.main.concat(d.extra, d.side).filter(x => {
        const cid = slotId(x);
        if (cid === c.id) return true;
        const other = all.find(k => k.id === cid);
        return other && (other.alias || other.name) === targetName;
      }).length;
      const bi = (BAN && d.format && d.format !== 'none') ? BAN.getCardBan(c, d.format) : { limit: 3 };
      const lim = bi.limit;
      if (lim === 0) return api.toast(`${c.name}: bị CẤM / Forbidden (${d.format.toUpperCase()})`);
      if (have >= lim) return api.toast(`${c.name}: tối đa ${lim} lá / max ${lim}`);
      if (d[zone].length >= max) return api.toast(`${zone.toUpperCase()} đã đầy (${max})`);
      const defSpec = ART ? ART.getDefaultSpec(c.id) : null;
      d[zone].push(defSpec ? { id: c.id, spec: { ...defSpec } } : c.id);
      localStorage.setItem(LS, JSON.stringify(decks));
      api.toast(`Đã thêm vào ${zone.toUpperCase()} của "${d.name}" (${have + 1}/${lim})`);
      showDetail(c);
    }

    function openCardArt(c) {
      if (!ART) return;
      ART.openPicker(c, {
        toast: api.toast,
        onApplyAll: () => { draw(); showDetail(c); },
      });
    }

    function showDetail(c) {
      sel = c; const d = $('#sDetail');
      const decks = getDecks();
      const curId = localStorage.getItem(LS_CUR) || decks[0].id;
      const curDeck = decks.find(x => x.id === curId) || decks[0];
      const have = curDeck ? curDeck.main.concat(curDeck.extra, curDeck.side).filter(x => slotId(x) === c.id).length : 0;
      const stats = [c.type, c.attribute, c.race, c.level != null ? 'Level ' + c.level : '', c.linkval != null ? 'Link-' + c.linkval : '', c.scale != null ? 'Scale ' + c.scale : '',
        c.atk != null ? 'ATK ' + fmtStat(c.atk) : '', c.def != null ? 'DEF ' + fmtStat(c.def) : ''].filter(Boolean).join(' • ');
      const arrows = (c.linkmarkers || []).length ? `<div class="hint">Link Arrows: ${esc(c.linkmarkers.join(', '))}</div>` : '';

      const checkFmts = [...new Set(['tcg', 'ocg', 'ae', 'md', $('#sBF').value])];
      const bans = BAN ? checkFmts.map(f => {
        const bi = BAN.getCardBan(c, f);
        if (!bi.status) return '';
        const col = bi.limit === 0 ? '#fca5a5' : bi.limit === 1 ? '#fde047' : '#93c5fd';
        return `<span class="badge" style="color:${col}">${esc(f.toUpperCase())}: ${esc(bi.status)}</span>`;
      }).filter(Boolean).join('') : '';

      const nArt = ART ? ART.variantCount(c) : 1;
      const effBadges = EFF ? EFF.renderBadgesHTML(c, true) : '';
      d.innerHTML = `<div style="display:flex;gap:14px;flex-wrap:wrap"><div id="dImgBox" title="Bấm để phóng to / Click to zoom" style="cursor:zoom-in"></div><div style="flex:1;min-width:165px">
        <h3 style="margin:0 0 4px">${esc(c.name)}</h3><div class="muted" style="font-size:13px">${esc(stats)}</div>${arrows}
        ${c.archetype ? `<div class="hint">Archetype: <b>${esc(c.archetype)}</b></div>` : ''}
        ${c.alias ? `<div class="hint">Luôn tính tên là: <b>${esc(c.alias)}</b></div>` : ''}
        <div style="margin:6px 0">${bans || '<span class="hint">Không bị giới hạn (3 lá) / Unlimited</span>'}</div>
        <button id="btnArt" class="small" style="margin-top:4px">🎨 Đổi Art / Overframe / Manga (${nArt})</button>
        </div></div>
        ${effBadges}
        <div id="artStrip" style="display:flex;gap:5px;overflow-x:auto;margin-top:8px"></div>
        <p style="white-space:pre-wrap;font-size:13.5px;max-height:190px;overflow:auto;background:#14151c;padding:10px;border-radius:10px;margin:10px 0 6px">${esc(c.desc)}</p>
        <div id="sViBox"></div>
        <div class="row" style="margin:8px 0">
          <select id="dkSel" style="flex:1;min-width:140px">${decks.map(x => `<option value="${esc(x.id)}" ${x.id === curDeck.id ? 'selected' : ''}>${esc(x.name)} (${x.main.length}/${x.extra.length}/${x.side.length})</option>`).join('')}</select>
          <span class="badge" id="dkHave">Đang có: x${have}</span>
        </div>
        <div class="row" style="margin:6px 0">
          <button id="dkAdd" class="primary small">+ ${isExtra(c) ? 'Extra' : 'Main'}</button>
          <button id="dkSide" class="small">+ Side</button>
          <button id="cpName" class="small">📋 Copy tên</button>
          ${api.openTab ? '<button id="goDeck" class="small">→ Mở Xây deck</button>' : ''}
        </div>
        <div class="hint">Có trong ${(c.sets || []).length} bản in: ${esc((c.sets || []).slice(0, 6).map(s => `${s.c} (${s.r})`).join(', '))}${(c.sets || []).length > 6 ? '…' : ''}</div>
        <div class="hint">Mã bài / Passcode: ${esc(c.id)}${c.kid ? ` • Konami ID: ${esc(c.kid)}` : ''}</div>`;

      const vis = ART ? ART.renderCardVisual(c, null, 'lg') : document.createElement('img');
      vis.style.height = '224px';
      if (api.showCard) vis.onclick = () => api.showCard(c.name);
      $('#dImgBox').appendChild(vis);

      if (ART && nArt > 1) {
        const strip = $('#artStrip');
        const curSpec = ART.resolveSpec(c);
        ART.getArtOptions(c).forEach(o => {
          const th = document.createElement('img');
          th.src = o.small; th.title = o.label;
          if (o.remoteSmall && o.small !== o.remoteSmall) th.onerror = () => { th.onerror = null; th.src = o.remoteSmall; };
          const act = o.isSpecial ? (curSpec.src === o.src && o.src) : (!curSpec.src && Number(curSpec.imgId) === Number(o.imgId));
          th.style.cssText = `height:54px;border-radius:4px;cursor:pointer;border:2px solid ${act ? '#2dd4bf' : 'transparent'};opacity:${act ? '1' : '.72'}`;
          th.onclick = () => {
            if (o.isSpecial) ART.setDefaultSpec(c.id, { style: 'standard', imgId: c.id, src: o.src || o.remoteSmall, remoteSrc: o.remoteSrc || '', label: o.label });
            else ART.setDefaultSpec(c.id, { style: curSpec.style || 'standard', imgId: o.imgId, src: '', remoteSrc: '', label: o.label });
            draw(); showDetail(c);
          };
          strip.appendChild(th);
        });
      }

      $('#btnArt').onclick = () => openCardArt(c);
      if (window.YGO_VI) window.YGO_VI.mountTranslationBox($('#sViBox'), c, { toast: api.toast });
      d.querySelectorAll('.eff-cbadge.clickable').forEach(el => {
        el.onclick = () => {
          if (!effCtrl) return;
          effCtrl.selectTag(el.dataset.effId, 1);
          api.toast('⚡ Đã lọc theo hiệu ứng: ' + el.textContent.trim());
        };
      });
      $('#dkSel').onchange = e => { localStorage.setItem(LS_CUR, e.target.value); showDetail(c); };
      $('#dkAdd').onclick = () => addToDeck(c, false);
      $('#dkSide').onclick = () => addToDeck(c, true);
      if ($('#goDeck')) $('#goDeck').onclick = () => api.openTab('deck');
      $('#cpName').onclick = () => { navigator.clipboard.writeText(c.name).then(() => api.toast('Đã copy: ' + c.name)).catch(() => api.toast('Không copy được')); };
    }

    function draw() {
      list = filter(); const res = $('#sRes'); res.innerHTML = '';
      const fzNote = lastFuzzy && list.length ? ` • 💡 Đã tự động khớp gần đúng tên bài gần giống nhất (vd: "${list[0].name}")` : '';
      $('#sCount').textContent = `${list.length} / ${all.length} lá phù hợp${fzNote}`;
      const activeFmt = $('#sBF').value;
      list.slice(0, shown).forEach(c => {
        const el = document.createElement('div'); el.className = 'tile';
        el.appendChild(ART ? ART.renderCardVisual(c, null, 'sm') : document.createElement('img'));
        if (ART) {
          const ab = document.createElement('span'); ab.className = 'tart'; ab.title = 'Đổi Art / Overframe / Manga'; ab.textContent = '🎨';
          ab.onclick = e => { e.stopPropagation(); openCardArt(c); };
          el.appendChild(ab);
          const nArt = ART.variantCount(c);
          if (nArt > 1) { const m = document.createElement('span'); m.className = 'talt'; m.textContent = '🎨' + nArt; el.appendChild(m); }
        }
        if (BAN) {
          const bi = BAN.getCardBan(c, activeFmt);
          if (bi.status) {
            const b = document.createElement('span');
            b.className = 'tb ' + (bi.limit === 0 ? 'red' : bi.points ? '' : 'amber');
            b.textContent = bi.points ? `${bi.points}p` : (bi.limit === 0 ? '✖' : String(bi.limit));
            el.appendChild(b);
          }
        }
        el.onclick = () => showDetail(c);
        if (api.showCard) el.oncontextmenu = e => { e.preventDefault(); api.showCard(c.name); };
        res.appendChild(el);
      });
      if (!list.length) res.innerHTML = '<span class="hint">Không có lá nào khớp bộ lọc. / No matches.</span>';
      else if (!sel || !list.includes(sel)) showDetail(list[0]);
      $('#sMore').style.display = list.length > shown ? '' : 'none';
    }

    // Gắn gợi ý đích danh tên đầy đủ của lá bài ngay dưới ô tìm kiếm
    if (SMART) {
      SMART.attachAutocomplete($('#sq'), {
        getCards: () => all,
        onSelect: card => {
          shown = 72;
          sel = card;
          draw();
          showDetail(card);
        },
      });
    }

    let tm;
    ['#sq', '#lvA', '#lvB', '#atA', '#atB', '#dfA', '#dfB', '#sArc', '#sSet'].forEach(s => $(s).oninput = () => { clearTimeout(tm); tm = setTimeout(() => { shown = 72; draw(); }, 180); });
    ['#sm', '#sT', '#sS', '#sA', '#sR', '#sBS', '#sSort', '#sDir', '#sMulti'].forEach(s => $(s).onchange = () => { shown = 72; draw(); });
    $('#sBF').onchange = async () => {
      if (BAN) await BAN.loadBanlist($('#sBF').value);
      shown = 72; draw();
      if (sel) showDetail(sel);
    };
    $('#sMore').onclick = () => { shown += 72; draw(); };
    $('#sClear').onclick = () => {
      box.querySelectorAll('#sq,#lvA,#lvB,#atA,#atB,#dfA,#dfB,#sArc,#sSet').forEach(i => i.value = '');
      $('#sMulti').checked = false;
      ['#sm', '#sT', '#sS', '#sA', '#sR', '#sBS', '#sSort'].forEach(s => $(s).selectedIndex = 0);
      if (effCtrl) effCtrl.reset();
      else { shown = 72; draw(); }
    };
    draw();
  }
  window.YGO_SEARCH = { render };
})();
