// Hệ thống Dịch Hiệu ứng Lá bài sang Tiếng Việt chuẩn thuật ngữ Yu-Gi-Oh! (window.YGO_VI)
// Kết hợp 2 tầng:
//   1. Dịch tức thì Offline (0ms) theo cấu trúc PSCT Konami (Condition : Cost/Target ; Effect) + đảo trật tự cụm danh từ Tiếng Anh -> Tiếng Việt
//   2. Tự động nâng cấp & lưu vĩnh viễn vào vi_translations.json qua Backend Glossary-Protected Translator khi có mạng + cho phép người chơi tự sửa bản dịch
(function () {
  'use strict';

  const LS_CUSTOM_VI = 'ygo_vi_custom_v1';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let diskCache = null;
  let diskLoading = null;
  const inflight = new Map();

  function getCustomMap() {
    try { return JSON.parse(localStorage.getItem(LS_CUSTOM_VI)) || {}; } catch (e) { return {}; }
  }
  function setCustomEntry(cid, text) {
    const m = getCustomMap();
    const k = String(cid);
    if (text && text.trim()) m[k] = text.trim();
    else delete m[k];
    try { localStorage.setItem(LS_CUSTOM_VI, JSON.stringify(m)); } catch (e) { }
  }

  function loadViCache(force) {
    if (diskCache && !force) return Promise.resolve(diskCache);
    if (diskLoading && !force) return diskLoading;
    diskLoading = fetch('/ygodata/vi_translations.json?t=' + (force ? Date.now() : '1'))
      .then(r => (r.ok ? r.json() : {}))
      .then(j => { diskCache = (j && typeof j === 'object') ? j : {}; return diskCache; })
      .catch(() => { diskCache = diskCache || {}; return diskCache; });
    return diskLoading;
  }

  // Bảo vệ tên lá bài / Archetype / Token trong dấu ngoặc kép "..."
  function stashQuotes(text) {
    const quotes = [];
    const stash = m => {
      const id = quotes.length;
      quotes.push(m);
      return `\uE000Q${id}\uE001`;
    };
    let s = String(text || '');
    s = s.replace(/""[^"\r\n]{1,60}"[^"\r\n]{0,60}"/g, stash);
    s = s.replace(/"[^"\r\n]{1,60}"[^"\r\n]{1,30}""/g, stash);
    s = s.replace(/"[^"\r\n]{1,90}"/g, stash);
    return { text: s, quotes };
  }

  function unstashQuotes(text, quotes) {
    return String(text || '').replace(/\uE000Q(\d+)\uE001/g, (_, idx) => quotes[Number(idx)] || '');
  }

  const RACE_VI = {
    'Dragon': 'Rồng', 'Spellcaster': 'Pháp Sư', 'Zombie': 'Thây Ma', 'Warrior': 'Chiến Binh',
    'Beast-Warrior': 'Thú Chiến Binh', 'Beast': 'Thú', 'Winged Beast': 'Thú Có Cánh', 'Fiend': 'Ác Quỷ',
    'Fairy': 'Tiên', 'Insect': 'Côn Trùng', 'Dinosaur': 'Khủng Long', 'Reptile': 'Bò Sát', 'Fish': 'Cá',
    'Sea Serpent': 'Hải Long', 'Aqua': 'Thủy Sinh', 'Pyro': 'Hỏa Tộc', 'Thunder': 'Lôi Tộc', 'Rock': 'Đá',
    'Plant': 'Thực Vật', 'Machine': 'Máy Móc', 'Psychic': 'Tâm Linh', 'Divine-Beast': 'Thần Thú',
    'Wyrm': 'Huyễn Long', 'Cyberse': 'Mạng (Cyberse)', 'Illusion': 'Ảo Ảnh',
  };
  const ATTR_VI = {
    'LIGHT': 'QUANG (LIGHT)', 'DARK': 'ÁM (DARK)', 'WATER': 'THỦY (WATER)',
    'FIRE': 'HỎA (FIRE)', 'EARTH': 'ĐỊA (EARTH)', 'WIND': 'PHONG (WIND)', 'DIVINE': 'THẦN (DIVINE)',
  };

  // Quy tắc dịch PSCT theo thứ tự từ cụm câu dài đến từ đơn
  const PSCT_RULES = [
    // Đầu mục Pendulum / Flavor
    [/\[\s*Pendulum Effect\s*\]/gi, '[ Hiệu ứng Pendulum ]'],
    [/\[\s*Monster Effect\s*\]/gi, '[ Hiệu ứng Quái thú ]'],
    [/\[\s*Flavor Text\s*\]/gi, '[ Mô tả ]'],

    // Các câu giới hạn lượt dùng (HOPT / SOPT) cực phổ biến
    [/You can only use each of the following effects of (\uE000Q\d+\uE001) once per turn, and only once that turn\./gi, 'Bạn chỉ có thể sử dụng một trong các hiệu ứng sau của $1 mỗi lượt, và chỉ một lần trong lượt đó.'],
    [/You can only use 1 (\uE000Q\d+\uE001) effect per turn, and only once that turn\./gi, 'Bạn chỉ có thể sử dụng 1 hiệu ứng của $1 mỗi lượt, và chỉ một lần trong lượt đó.'],
    [/You can only use each effect of (\uE000Q\d+\uE001) once per turn\./gi, 'Bạn chỉ có thể sử dụng mỗi hiệu ứng của $1 một lần mỗi lượt.'],
    [/You can only use this effect of (\uE000Q\d+\uE001) once per turn\./gi, 'Bạn chỉ có thể sử dụng hiệu ứng này của $1 một lần mỗi lượt.'],
    [/You can only use the following effect of (\uE000Q\d+\uE001) once per turn\./gi, 'Bạn chỉ có thể sử dụng hiệu ứng sau của $1 một lần mỗi lượt.'],
    [/You can only use the previous effect of (\uE000Q\d+\uE001) once per turn\./gi, 'Bạn chỉ có thể sử dụng hiệu ứng phía trên của $1 một lần mỗi lượt.'],
    [/You can only activate 1 (\uE000Q\d+\uE001) per turn\./gi, 'Bạn chỉ có thể kích hoạt 1 lá $1 mỗi lượt.'],
    [/You can only Special Summon (\uE000Q\d+\uE001\(s\)|\uE000Q\d+\uE001) once per turn\./gi, 'Bạn chỉ có thể Triệu hồi Đặc biệt $1 một lần mỗi lượt.'],
    [/Once per turn, during the End Phase, if this card is in the (?:Graveyard|GY) because it was sent there this turn:/gi, 'Một lần mỗi lượt, trong End Phase, nếu lá bài này ở trong Mộ vì vừa được gửi xuống đó trong lượt này:'],
    [/Once while face-up on the field, when a card or effect is activated/gi, 'Một lần khi còn ngửa trên sân, khi một lá bài hoặc hiệu ứng được kích hoạt'],
    [/Once while face-up on the field, when/gi, 'Một lần khi còn ngửa trên sân, khi'],
    [/Once per Chain,/gi, 'Một lần mỗi Chuỗi (Chain),'],
    [/Once per turn:/gi, 'Một lần mỗi lượt:'],
    [/Once per turn,/gi, 'Một lần mỗi lượt,'],
    [/Twice per turn,/gi, 'Hai lần mỗi lượt,'],

    // Điều kiện Triệu hồi (Summoning Conditions)
    [/Cannot be Normal Summoned\/Set\./gi, 'Không thể Triệu hồi Thường/Úp.'],
    [/Must first be Special Summoned/gi, 'Trước tiên phải được Triệu hồi Đặc biệt'],
    [/Must be Special Summoned/gi, 'Phải được Triệu hồi Đặc biệt'],
    [/ Must be Fusion Summoned/gi, ' Phải được Triệu hồi Dung hợp'],
    [/^Must be Fusion Summoned/gim, 'Phải được Triệu hồi Dung hợp'],
    [/^Must be Synchro Summoned/gim, 'Phải được Triệu hồi Synchro'],
    [/^Must be Xyz Summoned/gim, 'Phải được Triệu hồi Xyz'],
    [/^Must be Link Summoned/gim, 'Phải được Triệu hồi Link'],
    [/^Must be Ritual Summoned/gim, 'Phải được Triệu hồi Nghi thức'],
    [/Cannot be Special Summoned\./gi, 'Không thể được Triệu hồi Đặc biệt.'],
    [/Cannot be Special Summoned from the (?:Graveyard|GY)\./gi, 'Không thể được Triệu hồi Đặc biệt từ Mộ.'],
    [/and cannot be Special Summoned by other ways/gi, 'và không thể được Triệu hồi Đặc biệt bằng cách khác'],

    // Dòng nguyên liệu Extra Deck ở đầu thẻ
    [/(\d+)\+\s+non-Tuner\s+monsters/gi, '$1+ quái thú không phải Tuner'],
    [/(\d+)\s+non-Tuner\s+monsters?/gi, '$1 quái thú không phải Tuner'],
    [/(\d+)\+\s+Tuner\s+monsters?/gi, '$1+ quái thú Tuner'],
    [/(\d+)\s+Tuners?\b/gi, '$1 Tuner'],
    [/(\d+)\+\s+Effect\s+Monsters/gi, '$1+ Quái thú Hiệu ứng'],
    [/(\d+)\s+Effect\s+Monsters/gi, '$1 Quái thú Hiệu ứng'],
    [/(\d+)\+\s+monsters\s+with\s+different\s+names/gi, '$1+ quái thú có tên khác nhau'],
    [/(\d+)\s+monsters\s+with\s+different\s+names/gi, '$1 quái thú có tên khác nhau'],
    [/including\s+a\s+(\uE000Q\d+\uE001)\s+monster/gi, 'bao gồm 1 quái thú $1'],
    [/including\s+an?\s+([A-Za-z\-]+)\s+monster/gi, 'bao gồm 1 quái thú $1'],

    // Đảo trật tự cụm danh từ Tiếng Anh phổ biến sang Tiếng Việt tự nhiên
    [/(\d+|an?|each|all|other|any)\s+face-up\s+(\uE000Q\d+\uE001)\s+monsters?/gi, '$1 quái thú $2 đang ngửa'],
    [/(\d+|an?|each|all|other|any)\s+(\uE000Q\d+\uE001)\s+Spell\/Trap(?:\s+Cards?)?/gi, '$1 Phép/Bẫy $2'],
    [/(\d+|an?|each|all|other|any)\s+(\uE000Q\d+\uE001)\s+Spells?(?:\s+Cards?)?/gi, '$1 Bài Phép $2'],
    [/(\d+|an?|each|all|other|any)\s+(\uE000Q\d+\uE001)\s+Traps?(?:\s+Cards?)?/gi, '$1 Bài Bẫy $2'],
    [/(\d+|an?|each|all|other|any)\s+(\uE000Q\d+\uE001)\s+monsters?/gi, '$1 quái thú $2'],
    [/(\d+|an?|each|all|other|any)\s+(\uE000Q\d+\uE001)\s+cards?/gi, '$1 lá bài $2'],
    [/(\uE000Q\d+\uE001)\s+monsters/gi, 'các quái thú $1'],
    [/(\uE000Q\d+\uE001)\s+monster/gi, 'quái thú $1'],
    [/(\uE000Q\d+\uE001)\s+Spell\/Trap(?:\s+Cards?)?/gi, 'Phép/Bẫy $1'],
    [/(\uE000Q\d+\uE001)\s+cards/gi, 'các lá bài $1'],
    [/(\uE000Q\d+\uE001)\s+card/gi, 'lá bài $1'],
    [/(\d+)\s+face-up\s+monsters?\s+your\s+opponent\s+controls/gi, '$1 quái thú ngửa do đối thủ điều khiển'],
    [/(\d+)\s+face-up\s+monsters?\s+you\s+control/gi, '$1 quái thú ngửa do bạn điều khiển'],
    [/(\d+)\s+face-up\s+monsters?\s+on\s+the\s+field/gi, '$1 quái thú ngửa trên sân'],
    [/(\d+)\s+face-up\s+cards?\s+on\s+the\s+field/gi, '$1 lá bài ngửa trên sân'],
    [/(\d+)\s+Set\s+cards?\s+on\s+the\s+field/gi, '$1 lá bài đang úp trên sân'],
    [/face-up\s+monsters?\b/gi, 'quái thú ngửa'],
    [/face-down\s+monsters?\b/gi, 'quái thú úp'],
    [/Level\s+(\d+)\s+or\s+lower\s+([A-Za-z\-]+)\s+monsters?/gi, 'quái thú $2 Level $1 trở xuống'],
    [/Level\s+(\d+)\s+or\s+higher\s+([A-Za-z\-]+)\s+monsters?/gi, 'quái thú $2 Level $1 trở lên'],
    [/Level\s+(\d+)\s+or\s+lower\s+monsters?/gi, 'quái thú Level $1 trở xuống'],
    [/Level\s+(\d+)\s+or\s+higher\s+monsters?/gi, 'quái thú Level $1 trở lên'],

    // Điều kiện & Thời điểm (Timing / Trigger / Quick Effect)
    [/\(\s*Quick Effect\s*\)/gi, '(Hiệu ứng Nhanh)'],
    [/During\s+the\s+Main\s+Phase\s*\(Quick Effect\):/gi, 'Trong Main Phase (Hiệu ứng Nhanh):'],
    [/During\s+your\s+Main\s+Phase,\s+except\s+the\s+turn\s+this\s+card\s+was\s+sent\s+to\s+the\s+(?:Graveyard|GY):/gi, 'Trong Main Phase của bạn, trừ lượt lá bài này được gửi xuống Mộ:'],
    [/except\s+the\s+turn\s+this\s+card\s+was\s+sent\s+to\s+the\s+(?:Graveyard|GY)/gi, 'trừ lượt lá bài này được gửi xuống Mộ'],
    [/During\s+your\s+Main\s+Phase:/gi, 'Trong Main Phase của bạn:'],
    [/During\s+either\s+player's\s+turn:/gi, 'Trong lượt của bất kỳ người chơi nào:'],
    [/During\s+your\s+opponent's\s+turn/gi, 'Trong lượt của đối thủ'],
    [/During\s+the\s+End\s+Phase:/gi, 'Trong End Phase:'],
    [/During\s+the\s+Standby\s+Phase:/gi, 'Trong Standby Phase:'],
    [/During\s+the\s+Battle\s+Phase/gi, 'Trong Battle Phase'],
    [/At\s+the\s+start\s+of\s+the\s+Damage\s+Step,/gi, 'Vào đầu Damage Step,'],
    [/During\s+damage\s+calculation,/gi, 'Trong bước tính sát thương,'],
    [/If\s+this\s+card\s+is\s+Normal\s+or\s+Special\s+Summoned:/gi, 'Nếu lá bài này được Triệu hồi Thường hoặc Đặc biệt:'],
    [/When\s+this\s+card\s+is\s+Normal\s+or\s+Special\s+Summoned:/gi, 'Khi lá bài này được Triệu hồi Thường hoặc Đặc biệt:'],
    [/If\s+this\s+card\s+is\s+Special\s+Summoned:/gi, 'Nếu lá bài này được Triệu hồi Đặc biệt:'],
    [/If\s+this\s+card\s+is\s+Normal\s+Summoned:/gi, 'Nếu lá bài này được Triệu hồi Thường:'],
    [/If\s+this\s+card\s+is\s+sent\s+to\s+the\s+(?:Graveyard|GY):/gi, 'Nếu lá bài này được gửi xuống Mộ:'],
    [/If\s+this\s+card\s+is\s+destroyed\s+by\s+battle\s+or\s+card\s+effect:/gi, 'Nếu lá bài này bị phá hủy bởi chiến đấu hoặc hiệu ứng bài:'],
    [/When\s+a\s+card\s+or\s+effect\s+is\s+activated\s+that\s+includes\s+any\s+of\s+these\s+effects/gi, 'Khi một lá bài hoặc hiệu ứng được kích hoạt có bao gồm bất kỳ hiệu ứng nào sau đây'],
    [/When\s+a\s+monster\(s\)\s+would\s+be\s+Special\s+Summoned,\s+OR\s+a\s+monster\s+effect\s+is\s+activated:/gi, 'Khi quái thú sắp được Triệu hồi Đặc biệt, HOẶC hiệu ứng quái thú được kích hoạt:'],
    [/When\s+a\s+monster\(s\)\s+would\s+be\s+Normal\s+or\s+Special\s+Summoned,\s+OR\s+a\s+Spell\/Trap\s+Card\s+is\s+activated:/gi, 'Khi quái thú sắp được Triệu hồi Thường/Đặc biệt, HOẶC Bài Phép/Bẫy được kích hoạt:'],
    [/When\s+your\s+opponent\s+activates\s+a\s+card\s+or\s+effect/gi, 'Khi đối thủ kích hoạt một lá bài hoặc hiệu ứng'],
    [/When\s+a\s+card\s+or\s+effect\s+is\s+activated/gi, 'Khi một lá bài hoặc hiệu ứng được kích hoạt'],
    [/when\s+a\s+card\s+or\s+effect\s+is\s+activated/gi, 'khi một lá bài hoặc hiệu ứng được kích hoạt'],
    [/When\s+a\s+Spell\/Trap\s+Card,\s+or\s+monster\s+effect,\s+is\s+activated/gi, 'Khi Bài Phép/Bẫy hoặc hiệu ứng quái thú được kích hoạt'],
    [/When\s+a\s+monster\s+would\s+be\s+Summoned,/gi, 'Khi một quái thú sắp được Triệu hồi,'],
    [/If\s+you\s+control\s+no\s+cards,/gi, 'Nếu bạn không điều khiển lá bài nào,'],
    [/If\s+you\s+control\s+no\s+monsters,/gi, 'Nếu bạn không điều khiển quái thú nào,'],
    [/If\s+only\s+your\s+opponent\s+controls\s+a\s+monster,/gi, 'Nếu chỉ có đối thủ điều khiển quái thú,'],
    [/For\s+the\s+rest\s+of\s+this\s+Duel,\s+apply\s+the\s+following\s+effects\./gi, 'Trong phần còn lại của Trận đấu này, áp dụng các hiệu ứng sau:'],
    [/During\s+the\s+End\s+Phase\s+of\s+this\s+turn,/gi, 'Trong End Phase của lượt này,'],

    // Cost & Target (Trước dấu chấm phẩy ;)
    [/You\s+can\s+discard\s+this\s+card;/gi, 'Bạn có thể vứt bỏ lá bài này trên tay;'],
    [/You\s+can\s+send\s+this\s+card\s+from\s+your\s+hand\s+to\s+the\s+(?:Graveyard|GY);/gi, 'Bạn có thể gửi lá bài này từ tay xuống Mộ;'],
    [/You\s+can\s+banish\s+this\s+card\s+from\s+your\s+(?:Graveyard|GY);/gi, 'Bạn có thể trục xuất lá bài này từ Mộ của bạn;'],
    [/You\s+can\s+Tribute\s+this\s+card;/gi, 'Bạn có thể Hiến tế lá bài này;'],
    [/You\s+can\s+detach\s+(\d+)\s+materials?\s+from\s+this\s+card;/gi, 'Bạn có thể tách $1 nguyên liệu khỏi lá bài này;'],
    [/pay\s+half\s+your\s+LP;/gi, 'trả một nửa LP của bạn;'],
    [/pay\s+(\d+)\s+LP;/gi, 'trả $1 LP;'],
    [/discard\s+(\d+)\s+cards?;/gi, 'bỏ $1 lá trên tay;'],
    [/(^|[.:]\s*)Target\s+/gm, '$1Chỉ định '],
    [/(:\s*)You\s+can\s+target\s+/gi, '$1Bạn có thể chỉ định '],
    [/;\s*target\s+/gi, '; chỉ định '],
    [/You\s+can\s+reveal\s+this\s+card\s+in\s+your\s+hand;/gi, 'Bạn có thể tiết lộ lá bài này trên tay;'],

    // Liên từ nối hệ quả chuẩn PSCT Konami (cực kỳ quan trọng cho phán quyết!)
    [/,\s*and\s+if\s+you\s+do,\s*/gi, ', và nếu làm vậy, '],
    [/,\s*also,\s*after\s+that,\s*/gi, ', đồng thời sau đó, '],
    [/,\s*also\s+you\s+cannot\s+/gi, ', đồng thời bạn không thể '],
    [/,\s*also\s+/gi, ', đồng thời '],
    [/,\s*then,\s*if\s+/gi, ', sau đó, nếu '],
    [/,\s*then\s+you\s+can\s+/gi, ', sau đó bạn có thể '],
    [/,\s*then\s+/gi, ', sau đó '],
    [/,\s*or\s+if\s+/gi, ', hoặc nếu '],

    // Hành động giải quyết hiệu ứng (Resolution)
    [/●\s*Add\s+a\s+card\s+from\s+the\s+Deck\s+to\s+the\s+hand\./gi, '● Thêm 1 lá bài từ Deck lên tay.'],
    [/●\s*Special\s+Summon\s+from\s+the\s+Deck\./gi, '● Triệu hồi Đặc biệt từ Deck.'],
    [/●\s*Send\s+a\s+card\s+from\s+the\s+Deck\s+to\s+the\s+(?:Graveyard|GY)\./gi, '● Gửi 1 lá bài từ Deck xuống Mộ.'],
    [/conduct\s+(\d+)\s+Normal\s+Summons\/Sets\s+per\s+turn,\s+not\s+just\s+1/gi, 'thực hiện $1 lần Triệu hồi Thường/Úp mỗi lượt, thay vì chỉ 1'],
    [/instead\s+of\s+1\s+for\s+your\s+normal\s+draw\s+during\s+your\s+Draw\s+Phase/gi, 'thay vì 1 lá cho lượt rút bài thường trong Draw Phase của bạn'],
    [/Draw\s+until\s+you\s+have\s+(\d+)\s+cards\s+in\s+your\s+hand/gi, 'Rút bài cho đến khi bạn có $1 lá trên tay'],
    [/send\s+your\s+entire\s+hand\s+to\s+the\s+(?:Graveyard|GY)/gi, 'gửi toàn bộ bài trên tay bạn xuống Mộ'],
    [/after\s+this\s+card\s+resolves,\s+your\s+opponent\s+takes\s+no\s+damage/gi, 'sau khi lá bài này phân giải, đối thủ không nhận sát thương'],
    [/during\s+the\s+turn\s+you\s+activate\s+this\s+card/gi, 'trong lượt bạn kích hoạt lá bài này'],
    [/when\s+you\s+Normal\s+Summon\s+this\s+turn/gi, 'khi bạn Triệu hồi Thường trong lượt này'],
    [/activate\s+monster\s+effects\s+in\s+the\s+hand/gi, 'kích hoạt hiệu ứng quái thú trên tay'],
    [/activate\s+monster\s+effects/gi, 'kích hoạt hiệu ứng quái thú'],
    [/activate\s+this\s+card\s+from\s+your\s+hand/gi, 'kích hoạt lá bài này trực tiếp từ tay bạn'],
    [/was\s+Set\s+before\s+activation\s+and\s+is\s+on\s+the\s+field\s+at\s+resolution/gi, 'đã được Úp trước khi kích hoạt và vẫn ở trên sân lúc phân giải'],
    [/all\s+other\s+Spell\/Trap\s+effects\s+in\s+this\s+column\s+are\s+negated/gi, 'mọi hiệu ứng Phép/Bẫy khác trên cùng cột dọc này bị vô hiệu hóa'],
    [/its\s+effects\s+are\s+negated,\s+as\s+well\s+as\s+the\s+activated\s+effects\s+and\s+effects\s+on\s+the\s+field\s+of\s+monsters\s+with\s+the\s+same\s+original\s+name/gi, 'hiệu ứng của nó bị vô hiệu hóa, cùng với hiệu ứng kích hoạt và hiệu ứng trên sân của các quái thú có cùng tên gốc'],
    [/negate\s+the\s+Summon\s+or\s+activation,\s+and\s+if\s+you\s+do,\s+destroy\s+that\s+card/gi, 'vô hiệu hóa việc Triệu hồi hoặc kích hoạt đó, và nếu làm vậy, phá hủy lá bài đó'],
    [/negate\s+the\s+activation,\s+and\s+if\s+you\s+do,\s+destroy\s+that\s+card/gi, 'vô hiệu hóa việc kích hoạt đó, và nếu làm vậy, phá hủy lá bài đó'],
    [/negate\s+the\s+activation,\s+and\s+if\s+you\s+do,\s+destroy\s+it/gi, 'vô hiệu hóa việc kích hoạt đó, và nếu làm vậy, phá hủy nó'],
    [/negate\s+that\s+effect,\s+and\s+if\s+you\s+do,\s+destroy\s+that\s+card/gi, 'vô hiệu hóa hiệu ứng đó, và nếu làm vậy, phá hủy lá bài đó'],
    [/negate\s+the\s+Summon\s+or\s+activation/gi, 'vô hiệu hóa việc Triệu hồi hoặc kích hoạt đó'],
    [/negate\s+that\s+effect/gi, 'vô hiệu hóa hiệu ứng đó'],
    [/negate\s+the\s+activation/gi, 'vô hiệu hóa việc kích hoạt'],
    [/negate\s+its\s+effects\s*\(until\s+the\s+end\s+of\s+this\s+turn\)/gi, 'vô hiệu hóa hiệu ứng của nó (cho đến hết lượt này)'],
    [/negate\s+its\s+effects\s+until\s+the\s+end\s+of\s+this\s+turn/gi, 'vô hiệu hóa hiệu ứng của nó cho đến hết lượt này'],
    [/negate\s+its\s+effects/gi, 'vô hiệu hóa hiệu ứng của nó'],
    [/Special\s+Summon\s+this\s+card\s+\(from\s+your\s+hand\)/gi, 'Triệu hồi Đặc biệt lá bài này (từ tay bạn)'],
    [/Special\s+Summon\s+this\s+card\s+from\s+your\s+hand/gi, 'Triệu hồi Đặc biệt lá bài này từ tay bạn'],
    [/Special\s+Summon\s+this\s+card\s+from\s+your\s+(?:Graveyard|GY)/gi, 'Triệu hồi Đặc biệt lá bài này từ Mộ của bạn'],
    [/Special\s+Summon\s+it/gi, 'Triệu hồi Đặc biệt nó'],
    [/Special\s+Summon\s+/gi, 'Triệu hồi Đặc biệt '],
    [/Normal\s+Summon\/Set/gi, 'Triệu hồi Thường/Úp'],
    [/Normal\s+Summon/gi, 'Triệu hồi Thường'],
    [/Fusion\s+Summon/gi, 'Triệu hồi Dung hợp'],
    [/Synchro\s+Summon/gi, 'Triệu hồi Synchro'],
    [/Xyz\s+Summon/gi, 'Triệu hồi Xyz'],
    [/Link\s+Summon/gi, 'Triệu hồi Link'],
    [/Ritual\s+Summon/gi, 'Triệu hồi Nghi thức'],
    [/Pendulum\s+Summon/gi, 'Triệu hồi Pendulum'],
    [/add\s+it\s+to\s+your\s+hand/gi, 'thêm nó lên tay bạn'],
    [/add\s+/gi, 'thêm '],
    [/from\s+your\s+Deck\s+to\s+your\s+hand/gi, 'từ Deck của bạn lên tay'],
    [/from\s+your\s+(?:Graveyard|GY)\s+to\s+your\s+hand/gi, 'từ Mộ của bạn lên tay'],
    [/from\s+your\s+Deck\s+to\s+the\s+(?:Graveyard|GY)/gi, 'từ Deck của bạn xuống Mộ'],
    [/from\s+your\s+Extra\s+Deck\s+to\s+the\s+(?:Graveyard|GY)/gi, 'từ Extra Deck của bạn xuống Mộ'],
    [/from\s+your\s+hand\s+or\s+Deck\s+to\s+the\s+(?:Graveyard|GY)/gi, 'từ tay hoặc Deck của bạn xuống Mộ'],
    [/to\s+your\s+hand/gi, 'lên tay bạn'],
    [/to\s+the\s+hand/gi, 'về tay'],
    [/return\s+this\s+card\s+to\s+the\s+Extra\s+Deck/gi, 'trả lá bài này về Extra Deck'],
    [/return\s+it\s+to\s+the\s+hand/gi, 'trả nó về tay'],
    [/discard\s+(\d+)\s+(\uE000Q\d+\uE001)/gi, 'bỏ $1 $2 trên tay'],
    [/shuffle\s+it\s+into\s+the\s+Deck/gi, 'xào nó về lại Deck'],
    [/shuffle\s+them\s+into\s+the\s+Deck/gi, 'xào chúng về lại Deck'],
    [/draw\s+(\d+)\s+cards?/gi, 'rút $1 lá bài'],
    [/destroy\s+that\s+target/gi, 'phá hủy mục tiêu đó'],
    [/destroy\s+those\s+targets/gi, 'phá hủy các mục tiêu đó'],
    [/destroy\s+all\s+monsters\s+your\s+opponent\s+controls/gi, 'phá hủy toàn bộ quái thú đối thủ điều khiển'],
    [/destroy\s+all\s+monsters\s+on\s+the\s+field/gi, 'phá hủy toàn bộ quái thú trên sân'],
    [/destroy\s+them/gi, 'phá hủy chúng'],
    [/destroy\s+it/gi, 'phá hủy nó'],
    [/destroy\s+/gi, 'phá hủy '],
    [/banish\s+it\s+face-down/gi, 'trục xuất úp nó'],
    [/banish\s+that\s+target/gi, 'trục xuất mục tiêu đó'],
    [/banish\s+it/gi, 'trục xuất nó'],
    [/banished\s+face-down/gi, 'bị trục xuất úp'],
    [/banished/gi, 'bị trục xuất'],
    [/banish\s+/gi, 'trục xuất '],
    [/send\s+(\d+|it|them|that\s+[a-z\- ]+|this\s+card)/gi, 'gửi $1'],
    [/sent\s+monster/gi, 'quái thú đã gửi'],
    [/sent\s+to\s+the\s+(?:Graveyard|GY)/gi, 'được gửi xuống Mộ'],
    [/to\s+the\s+(?:Graveyard|GY)/gi, 'xuống Mộ'],
    [/in\s+your\s+opponent's\s+(?:Graveyard|GY)/gi, 'trong Mộ của đối thủ'],
    [/in\s+your\s+(?:Graveyard|GY)/gi, 'trong Mộ của bạn'],
    [/in\s+either\s+(?:Graveyard|GY)/gi, 'trong Mộ hai bên'],
    [/in\s+the\s+(?:Graveyard|GY)/gi, 'trong Mộ'],
    [/from\s+your\s+(?:Graveyard|GY)/gi, 'từ Mộ của bạn'],
    [/from\s+either\s+(?:Graveyard|GY)/gi, 'từ Mộ hai bên'],
    [/from\s+the\s+(?:Graveyard|GY)/gi, 'từ Mộ'],
    [/take\s+control\s+of\s+/gi, 'giành quyền điều khiển '],
    [/Unaffected\s+by\s+other\s+cards'\s+effects/gi, 'Không bị ảnh hưởng bởi hiệu ứng của các lá bài khác'],
    [/Unaffected\s+by\s+activated\s+effects/gi, 'Không bị ảnh hưởng bởi các hiệu ứng kích hoạt'],
    [/Cannot\s+be\s+destroyed\s+by\s+battle\s+or\s+card\s+effects/gi, 'Không thể bị phá hủy bởi chiến đấu hoặc hiệu ứng bài'],
    [/Cannot\s+be\s+destroyed\s+by\s+battle/gi, 'Không thể bị phá hủy bởi chiến đấu'],
    [/Cannot\s+be\s+destroyed\s+by\s+card\s+effects/gi, 'Không thể bị phá hủy bởi hiệu ứng bài'],
    [/cannot\s+target\s+this\s+card\s+with\s+card\s+effects/gi, 'không thể chỉ định lá bài này bằng hiệu ứng bài'],
    [/Neither\s+player\s+can\s+/gi, 'Cả hai người chơi đều không thể '],
    [/Your\s+opponent\s+cannot\s+/gi, 'Đối thủ không thể '],
    [/you\s+cannot\s+/gi, 'bạn không thể '],
    [/for\s+the\s+rest\s+of\s+this\s+turn/gi, 'trong phần còn lại của lượt này'],
    [/until\s+the\s+end\s+of\s+this\s+turn/gi, 'cho đến hết lượt này'],
    [/until\s+the\s+end\s+of\s+the\s+next\s+turn/gi, 'cho đến hết lượt tiếp theo'],
    [/place\s+([A-Za-z0-9\-]+)-Counters?\s+on\s+that\s+monster/gi, 'đặt $1-Counter lên quái thú đó'],
    [/place\s+(\d+)\s+([A-Za-z0-9\-]+)\s+Counters?\s+on\s+/gi, 'đặt $1 $2 Counter lên '],
    [/equal\s+to\s+the\s+Level\s+of\s+the\s+/gi, 'bằng với Level của '],
    [/equal\s+to\s+its\s+original\s+ATK/gi, 'bằng với ATK gốc của nó'],
    [/gains\s+(\d+)\s+ATK/gi, 'tăng $1 ATK'],
    [/loses\s+(\d+)\s+ATK/gi, 'giảm $1 ATK'],
    [/inflict\s+(\d+)\s+damage\s+to\s+your\s+opponent/gi, 'gây $1 sát thương hiệu ứng cho đối thủ'],
    [/piercing\s+battle\s+damage/gi, 'sát thương xuyên thủ'],

    // Vùng sân, Tư thế & Thuật ngữ cơ bản còn lại
    [/in\s+Defense\s+Position/gi, 'ở tư thế Thủ'],
    [/in\s+Attack\s+Position/gi, 'ở tư thế Công'],
    [/face-down\s+Defense\s+Position/gi, 'tư thế Thủ úp'],
    [/Spell\s*&\s*Trap\s+Zones?/gi, 'Vùng Phép & Bẫy'],
    [/Main\s+Monster\s+Zones?/gi, 'Vùng Quái thú Chính'],
    [/Extra\s+Monster\s+Zones?/gi, 'Vùng Quái thú Extra'],
    [/Pendulum\s+Zones?/gi, 'Vùng Pendulum'],
    [/Field\s+Zones?/gi, 'Vùng Môi trường'],
    [/Spell\/Trap\s+Cards?/gi, 'Bài Phép/Bẫy'],
    [/Spell\/Traps?/gi, 'Phép/Bẫy'],
    [/Spell\s+Cards?/gi, 'Bài Phép'],
    [/Trap\s+Cards?/gi, 'Bài Bẫy'],
    [/on\s+the\s+field/gi, 'trên sân'],
    [/from\s+the\s+field/gi, 'từ trên sân'],
    [/leaves\s+the\s+field/gi, 'rời sân'],
    [/from\s+your\s+Deck/gi, 'từ Deck của bạn'],
    [/from\s+your\s+hand/gi, 'từ tay bạn'],
    [/from\s+your\s+Extra\s+Deck/gi, 'từ Extra Deck của bạn'],
    [/your\s+opponent\s+controls/gi, 'do đối thủ điều khiển'],
    [/you\s+control/gi, 'do bạn điều khiển'],
    [/You\s+can\s+/g, 'Bạn có thể '],
    [/you\s+can\s+/g, 'bạn có thể '],
    [/\bIf\s+/g, 'Nếu '],
    [/\bWhen\s+/g, 'Khi '],
    [/\bexcept\s+/gi, 'ngoại trừ '],
    [/\bGraveyard\b/gi, 'Mộ'],
    [/\bGY\b/g, 'Mộ'],
    [/\bTribute\b/g, 'Hiến tế'],
    [/\bmonsters\b/gi, 'các quái thú'],
    [/\bmonster\b/gi, 'quái thú'],
    [/\bthis\s+card\b/gi, 'lá bài này'],
    [/\bthat\s+card\b/gi, 'lá bài đó'],
    [/(\d+)\s+cards\b/gi, '$1 lá bài'],
    [/(\d+)\s+card\b/gi, '$1 lá bài'],
    [/\bthat\s+quái\s+thú/gi, 'quái thú đó'],
    [/\bthe\s+quái\s+thú/gi, 'quái thú'],
  ];

  function translateOfflinePSCT(card) {
    const desc = (card && card.desc) ? String(card.desc).trim() : '';
    if (!desc) return '';
    const { text: stashed, quotes } = stashQuotes(desc);
    let s = stashed;

    for (const [rx, rep] of PSCT_RULES) {
      s = s.replace(rx, rep);
    }

    // Dịch Chủng tộc & Thuộc tính khi đi kèm quái thú
    for (const [en, vi] of Object.entries(RACE_VI)) {
      const rx = new RegExp('\\b' + en.replace('-', '\\-') + '\\s+quái thú', 'gi');
      s = s.replace(rx, 'quái thú ' + vi);
    }
    for (const [en, vi] of Object.entries(ATTR_VI)) {
      const rx = new RegExp('\\b' + en + '\\s+quái thú', 'g');
      s = s.replace(rx, 'quái thú hệ ' + vi);
    }

    // Dọn các mạo từ tiếng Anh thừa đứng độc lập trước danh từ đã Việt hóa (không chạm vào từ Tiếng Việt kết thúc bằng 'a' như 'của')
    s = s.replace(/(^|[\s([•●;:,])(?:an?|the)\s+(?=quái thú|lá bài|Bài Phép|Bài Bẫy|Phép\/Bẫy|Mộ\b)/gi, '$1');
    s = unstashQuotes(s, quotes);
    return s;
  }

  function requestBackendTranslation(cid, desc, force) {
    const key = String(cid || '') + (force ? ':f' : '');
    if (!force && inflight.has(key)) return inflight.get(key);
    const p = fetch('/api/yugioh_combo/translate_card', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: cid || '', desc, force: !!force }),
    })
      .then(r => (r.ok ? r.json() : { ok: 0 }))
      .then(res => {
        inflight.delete(key);
        if (res && res.ok && res.vi && cid && diskCache) {
          diskCache[String(cid)] = res.vi;
        }
        return res;
      })
      .catch(() => {
        inflight.delete(key);
        return { ok: 0, offline: 1 };
      });
    inflight.set(key, p);
    return p;
  }

  function saveBackendTranslation(cid, viText) {
    setCustomEntry(cid, viText);
    if (diskCache && cid) {
      if (viText && viText.trim()) diskCache[String(cid)] = viText.trim();
      else delete diskCache[String(cid)];
    }
    return fetch('/api/yugioh_combo/save_card_vi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: cid, vi: viText }),
    }).catch(() => null);
  }

  // Gắn khung Bản dịch Tiếng Việt ngay bên dưới phần hiệu ứng Tiếng Anh
  function mountTranslationBox(hostEl, card, opts) {
    if (!hostEl || !card || !card.desc) return;
    const o = opts || {};
    const raw = card.raw || card;
    const cid = raw.id || card.id || card.name || '';
    const token = String(cid) + ':' + Date.now();
    hostEl.dataset.viToken = token;

    const customMap = getCustomMap();
    const customVi = cid ? customMap[String(cid)] : '';
    const cachedVi = (!customVi && diskCache && cid) ? diskCache[String(cid)] : '';
    const offlineVi = translateOfflinePSCT(raw);
    const initialVi = customVi || cachedVi || offlineVi;
    const initialBadge = customVi
      ? 'Đã tùy chỉnh'
      : cachedVi
        ? 'Chuẩn thuật ngữ • Đã lưu'
        : 'PSCT Offline tức thì';

    function renderView(viText, badgeLabel) {
      if (hostEl.dataset.viToken !== token) return;
      hostEl.innerHTML = `
        <div class="vi-trans-box">
          <div class="vi-trans-hdr">
            <span class="vi-trans-title">🇻🇳 Bản dịch Tiếng Việt <span class="vi-trans-tag">${esc(badgeLabel)}</span></span>
            <span class="vi-trans-acts">
              <button type="button" class="vi-btn" data-act="retrans" title="Dịch lại tự động mượt câu (cần mạng)">🔄 Dịch mượt</button>
              <button type="button" class="vi-btn" data-act="edit" title="Tự chỉnh sửa & lưu bản dịch riêng cho lá này">✏️ Sửa dịch</button>
            </span>
          </div>
          <div class="vi-trans-body">${esc(viText)}</div>
        </div>`;

      const btnRe = hostEl.querySelector('[data-act="retrans"]');
      const btnEd = hostEl.querySelector('[data-act="edit"]');

      if (btnRe) {
        btnRe.onclick = async e => {
          e.stopPropagation();
          btnRe.disabled = true;
          btnRe.textContent = '⏳ Đang dịch...';
          const res = await requestBackendTranslation(cid, raw.desc, true);
          if (res && res.ok && res.vi) {
            if (cid) setCustomEntry(cid, '');
            renderView(res.vi, 'Chuẩn thuật ngữ • Đã lưu');
            if (o.toast) o.toast('Đã cập nhật & lưu bản dịch Tiếng Việt');
          } else {
            btnRe.disabled = false;
            btnRe.textContent = '🔄 Dịch mượt';
            if (o.toast) o.toast('Đang ngoại tuyến — giữ bản dịch PSCT Offline');
          }
        };
      }

      if (btnEd) {
        btnEd.onclick = e => {
          e.stopPropagation();
          openEditor(viText);
        };
      }
    }

    function openEditor(currentVi) {
      hostEl.innerHTML = `
        <div class="vi-trans-box editing">
          <div class="vi-trans-hdr">
            <span class="vi-trans-title">🇻🇳 Chỉnh sửa bản dịch Tiếng Việt</span>
          </div>
          <textarea class="vi-edit-area">${esc(currentVi)}</textarea>
          <div class="row" style="margin:6px 0 0;justify-content:flex-end">
            <button type="button" class="small" data-ed="auto">↺ Khôi phục tự động</button>
            <button type="button" class="small" data-ed="cancel">Hủy</button>
            <button type="button" class="small primary" data-ed="save">💾 Lưu bản dịch</button>
          </div>
        </div>`;
      const ta = hostEl.querySelector('.vi-edit-area');
      hostEl.querySelector('[data-ed="cancel"]').onclick = () => renderView(currentVi, initialBadge);
      hostEl.querySelector('[data-ed="auto"]').onclick = async () => {
        await saveBackendTranslation(cid, '');
        renderView(offlineVi, 'PSCT Offline tức thì');
        if (o.toast) o.toast('Đã khôi phục bản dịch tự động');
      };
      hostEl.querySelector('[data-ed="save"]').onclick = async () => {
        const val = ta.value.trim();
        if (!val) return;
        await saveBackendTranslation(cid, val);
        renderView(val, 'Đã tùy chỉnh');
        if (o.toast) o.toast('Đã lưu bản dịch Tiếng Việt cho lá bài này');
      };
    }

    renderView(initialVi, initialBadge);

    // Nếu chưa có trong cache đĩa thì tự động nạp vi_translations.json và nâng cấp ngầm khi có mạng
    if (!customVi && !cachedVi && cid) {
      loadViCache().then(cache => {
        if (hostEl.dataset.viToken !== token) return;
        if (cache[String(cid)]) {
          renderView(cache[String(cid)], 'Chuẩn thuật ngữ • Đã lưu');
          return;
        }
        requestBackendTranslation(cid, raw.desc, false).then(res => {
          if (hostEl.dataset.viToken !== token) return;
          if (res && res.ok && res.vi) {
            renderView(res.vi, 'Chuẩn thuật ngữ • Đã lưu');
          }
        });
      });
    }
  }

  window.YGO_VI = {
    loadViCache,
    translateOfflinePSCT,
    mountTranslationBox,
    getCustomMap,
  };
})();
