// Hệ thống tìm kiếm thông minh (bỏ qua dấu gạch/ký hiệu, chịu lỗi chính tả Damerau-Levenshtein, gợi ý đích danh tên đầy đủ)
// + Quản lý đa hệ Banlist chuẩn (TCG, OCG, AE Asian-English, Master Duel, World, Genesys, OCG-CN, Edison, GOAT).
(function () {
  'use strict';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ---------------- 1. HỆ THỐNG ĐA BANLIST CHUẨN XÁC ----------------
  const FORMATS = [
    { id: 'tcg', label: 'TCG (Quốc tế)' },
    { id: 'ocg', label: 'OCG (Nhật / Châu Á)' },
    { id: 'ae', label: 'AE (OCG Asian-English)' },
    { id: 'md', label: 'Master Duel' },
    { id: 'world', label: 'World Championship' },
    { id: 'genesys', label: 'Genesys' },
    { id: 'ocg_cn', label: 'OCG China (CN)' },
    { id: 'edison', label: 'Edison (2010.03)' },
    { id: 'goat', label: 'GOAT (2005)' },
  ];

  const banCache = {};
  let banMeta = null, banMetaLoading = null;

  function loadBanMeta(force) {
    if (banMeta && !force) return Promise.resolve(banMeta);
    if (banMetaLoading && !force) return banMetaLoading;
    banMetaLoading = fetch('/ygodata/banlists_meta.json?t=' + Date.now())
      .then(r => r.ok ? r.json() : [])
      .then(arr => { banMeta = Array.isArray(arr) ? arr : []; return banMeta; })
      .catch(() => { banMeta = banMeta || []; return banMeta; });
    return banMetaLoading;
  }

  function loadBanlist(fmt, force) {
    if (!fmt || fmt === 'none') return Promise.resolve({});
    if (banCache[fmt] && !force) return Promise.resolve(banCache[fmt]);
    return fetch(`/ygodata/banlist_${fmt}.json?t=` + Date.now())
      .then(r => r.ok ? r.json() : {})
      .then(j => { banCache[fmt] = (j && typeof j === 'object') ? j : {}; return banCache[fmt]; })
      .catch(() => { banCache[fmt] = banCache[fmt] || {}; return banCache[fmt]; });
  }

  function clearBanCache() {
    Object.keys(banCache).forEach(k => delete banCache[k]);
    banMeta = null; banMetaLoading = null;
  }

  // Chuẩn hóa mọi giá trị trạng thái ("Forbidden", "Banned", 0, "Limited", 1, "Semi-Limited", 2) -> { limit, status, points }
  function normalizeBanEntry(raw) {
    if (!raw) return { limit: 3, status: '', points: 0 };
    if (typeof raw === 'object') {
      if (raw.points && Number(raw.points) > 0 && (raw.limit == null || raw.limit >= 3)) {
        return { limit: 3, status: `${raw.points} pts`, points: Number(raw.points) };
      }
      if (raw.limit != null) {
        const l = Number(raw.limit);
        if (l <= 0) return { limit: 0, status: 'Forbidden', points: 0 };
        if (l === 1) return { limit: 1, status: 'Limited', points: 0 };
        if (l === 2) return { limit: 2, status: 'Semi-Limited', points: 0 };
      }
      return normalizeBanEntry(raw.status);
    }
    const s = String(raw).trim().toLowerCase();
    if (s === '0' || s === 'forbidden' || s === 'banned' || s === 'ban') return { limit: 0, status: 'Forbidden', points: 0 };
    if (s === '1' || s === 'limited' || s === 'limit') return { limit: 1, status: 'Limited', points: 0 };
    if (s === '2' || s === 'semi-limited' || s === 'semi limited' || s === 'semilimited') return { limit: 2, status: 'Semi-Limited', points: 0 };
    return { limit: 3, status: '', points: 0 };
  }

  function getCardBan(card, fmt) {
    if (!card || !fmt || fmt === 'none') return { limit: 3, status: '', points: 0 };
    const m = banCache[fmt];
    if (m && m[String(card.id)]) return normalizeBanEntry(m[String(card.id)]);
    if (card.banlist_info && card.banlist_info['ban_' + fmt]) return normalizeBanEntry(card.banlist_info['ban_' + fmt]);
    return { limit: 3, status: '', points: 0 };
  }

  function formatLabel(fmtId) {
    const f = FORMATS.find(x => x.id === fmtId);
    const base = f ? f.label : fmtId.toUpperCase();
    const m = (banMeta || []).find(x => x.id === fmtId);
    return (m && m.effective) ? `${base} [${m.effective}]` : base;
  }

  // ---------------- 2. HỆ THỐNG CHUẨN HÓA & TÌM KIẾM MỜ (FUZZY + SYMBOL-INSENSITIVE) ----------------
  function stripAccents(s) {
    return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
  }

  // Chuẩn hóa thành các từ cách nhau bằng khoảng trắng, bỏ mọi dấu gạch ngang/nháy/ký hiệu đặc biệt:
  // "Blue-Eyes White Dragon" -> "blue eyes white dragon"
  // "Maxx \"C\"" -> "maxx c"
  // "Magician's Rod" -> "magicians rod"
  // "I:P Masquerena" -> "i p masquerena"
  // "Live☆Twin Ki-sikil" -> "live twin ki sikil"
  function normSpaced(s) {
    return stripAccents(s)
      .toLowerCase()
      .replace(/&/g, ' and ')
      .replace(/([a-z0-9])['’`´]([a-z0-9])/g, '$1$2')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim()
      .replace(/\s+/g, ' ');
  }

  function normCollapsed(s) {
    return stripAccents(s).toLowerCase().replace(/[^a-z0-9]+/g, '');
  }

  function ensureCardIndex(c) {
    if (c._sidx) return c._sidx;
    const spaced = normSpaced(c.name);
    const collapsed = normCollapsed(c.name);
    // Tách thêm cả phiên bản tách rời dấu nháy đơn (vd Magician's -> magician) để gõ "magician rod" hay "magicians rod" đều trúng
    const rawWords = stripAccents(c.name).toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').trim().split(/\s+/).filter(Boolean);
    const spacedWords = spaced ? spaced.split(' ') : [];
    const tokens = [...new Set([...spacedWords, ...rawWords])];
    const acronym = spacedWords.map(w => w[0]).join('');
    const betaSpaced = c.beta ? normSpaced(c.beta) : '';
    const betaCollapsed = c.beta ? normCollapsed(c.beta) : '';
    const descSpaced = normSpaced(c.desc || '');
    const popBonus = Math.min(18, Math.round(Math.log2(1 + ((c.sets && c.sets.length) || 0) + ((c.img && c.img.length) || 0)) * 3.2));
    c._sidx = { spaced, collapsed, spacedWords, tokens, acronym, betaSpaced, betaCollapsed, descSpaced, popBonus };
    return c._sidx;
  }

  // Khoảng cách Damerau-Levenshtein có ngưỡng cắt sớm (nhận diện gõ nhầm, thiếu/thừa chữ và đảo vị trí 2 chữ liền kề: "drgaon" -> "dragon" = 1 lỗi)
  function damerauLevenshtein(a, b, maxDist) {
    const la = a.length, lb = b.length;
    if (Math.abs(la - lb) > maxDist) return maxDist + 1;
    if (a === b) return 0;
    if (!la) return lb <= maxDist ? lb : maxDist + 1;
    if (!lb) return la <= maxDist ? la : maxDist + 1;

    let prevPrev = new Array(lb + 1);
    let prev = new Array(lb + 1);
    let cur = new Array(lb + 1);
    for (let j = 0; j <= lb; j++) prev[j] = j;

    for (let i = 1; i <= la; i++) {
      cur[0] = i;
      let rowMin = cur[0];
      const ca = a.charCodeAt(i - 1);
      for (let j = 1; j <= lb; j++) {
        const cost = ca === b.charCodeAt(j - 1) ? 0 : 1;
        let v = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
        if (i > 1 && j > 1 && ca === b.charCodeAt(j - 2) && a.charCodeAt(i - 2) === b.charCodeAt(j - 1)) {
          v = Math.min(v, prevPrev[j - 2] + 1);
        }
        cur[j] = v;
        if (v < rowMin) rowMin = v;
      }
      if (rowMin > maxDist) return maxDist + 1;
      const tmp = prevPrev; prevPrev = prev; prev = cur; cur = tmp;
    }
    return prev[lb];
  }

  function allowedEdits(len) {
    if (len <= 2) return 0;
    if (len <= 4) return 1;
    if (len <= 7) return 2;
    return 3;
  }

  // Chấm điểm mức độ khớp tên lá bài (0 = không khớp; điểm càng cao càng sát tên lá bài nhất)
  function scoreNameMatch(c, qObj) {
    const idx = ensureCardIndex(c);
    const { qSpaced, qCollapsed, qTokens } = qObj;
    if (!qCollapsed) return 0;

    // 1. Khớp chính xác 100% (kể cả khác dấu gạch ngang/ngoặc kép/hai chấm: "blue eyes" == "Blue-Eyes", "ip masquerena" == "I:P Masquerena")
    if (idx.spaced === qSpaced || idx.collapsed === qCollapsed) return 1000;
    if (idx.betaSpaced && (idx.betaSpaced === qSpaced || idx.betaCollapsed === qCollapsed)) return 975;

    // 2. Khớp đầu tên (Prefix): "blue eyes" -> "Blue-Eyes White Dragon"
    if (idx.spaced.startsWith(qSpaced + ' ') || idx.spaced.startsWith(qSpaced)) {
      const lenPen = Math.min(22, Math.floor(Math.max(0, idx.spaced.length - qSpaced.length) * 0.6));
      return 945 - lenPen + idx.popBonus;
    }
    if (idx.collapsed.startsWith(qCollapsed)) {
      const lenPen = Math.min(22, Math.floor(Math.max(0, idx.collapsed.length - qCollapsed.length) * 0.6));
      return 930 - lenPen + idx.popBonus;
    }

    // 3. Khớp cụm từ con bên trong tên hoặc viết tắt chữ cái đầu (vd "bewd", "rota")
    if (idx.spaced.includes(' ' + qSpaced)) return 885 - Math.min(22, Math.floor((idx.spaced.length - qSpaced.length) * 0.5)) + idx.popBonus;
    if (idx.spaced.includes(qSpaced) || idx.collapsed.includes(qCollapsed)) return 855 - Math.min(22, Math.floor((idx.collapsed.length - qCollapsed.length) * 0.5)) + idx.popBonus;
    if (idx.betaSpaced && (idx.betaSpaced.includes(qSpaced) || idx.betaCollapsed.includes(qCollapsed))) return 840;
    if (qCollapsed.length >= 3 && idx.acronym === qCollapsed) return 835 + idx.popBonus;
    if (qCollapsed.length >= 3 && idx.acronym.startsWith(qCollapsed)) return 795 + idx.popBonus;

    // 4. Khớp toàn bộ các từ theo bất kỳ thứ tự nào (exact hoặc prefix của từ)
    if (qTokens.length > 1) {
      let allPrefix = true, exactCnt = 0;
      for (let i = 0; i < qTokens.length; i++) {
        const qt = qTokens[i];
        let hit = 0;
        for (let j = 0; j < idx.tokens.length; j++) {
          const wt = idx.tokens[j];
          if (wt === qt) { hit = 2; break; }
          if (wt.startsWith(qt)) hit = 1;
        }
        if (!hit) { allPrefix = false; break; }
        if (hit === 2) exactCnt++;
      }
      if (allPrefix) return 800 + exactCnt * 8 - Math.min(20, idx.tokens.length * 2) + idx.popBonus;
    }

    // 5. Khớp mờ chịu lỗi chính tả (Fuzzy Typo Tolerance):
    // VD: "blu eys", "bleue eyes", "drak magican", "ash blosom", "barone de fleur", "apollusa"
    if (qCollapsed.length < 3) return 0;

    let bestFuzzy = 0;

    // 5a. So khớp chuỗi gộp (dành cho trường hợp người chơi viết dính liền 1 cụm không cách như "bleueyes", "ipmasquerana", "apollusa")
    if (qTokens.length === 1 || Math.abs(idx.collapsed.length - qCollapsed.length) <= 2) {
      if (Math.abs(idx.collapsed.length - qCollapsed.length) <= 2) {
        const maxD = allowedEdits(qCollapsed.length);
        const dFull = damerauLevenshtein(qCollapsed, idx.collapsed, maxD);
        if (dFull <= maxD) bestFuzzy = Math.max(bestFuzzy, 755 - dFull * 55 + idx.popBonus);
      }
      if (qTokens.length === 1 && idx.collapsed.length > qCollapsed.length && qCollapsed.length >= 4) {
        const maxD = qCollapsed.length <= 5 ? 1 : 2;
        for (const sliceLen of [qCollapsed.length, qCollapsed.length + 1]) {
          if (sliceLen > idx.collapsed.length) continue;
          const head = idx.collapsed.slice(0, sliceLen);
          const dHead = damerauLevenshtein(qCollapsed, head, maxD);
          if (dHead <= maxD) bestFuzzy = Math.max(bestFuzzy, 735 - dHead * 58 + idx.popBonus);
        }
      }
    }

    // 5b. So khớp từng từ (token-by-token) với sai số chính tả cho phép
    let totalPenalty = 0;
    let matchedAll = true;
    let inOrderHits = 0;
    for (let i = 0; i < qTokens.length; i++) {
      const qt = qTokens[i];
      const maxEd = allowedEdits(qt.length);
      let bestPen = 99;
      let bestPos = -1;

      for (let j = 0; j < idx.tokens.length; j++) {
        const wt = idx.tokens[j];
        if (wt === qt) { bestPen = 0; bestPos = j; break; }
        if (qt.length >= 2 && wt.startsWith(qt)) {
          const p = qt.length >= 3 ? 0.25 : 0.45;
          if (p < bestPen) { bestPen = p; bestPos = j; }
          continue;
        }
        if (maxEd === 0) continue;

        // So khớp toàn bộ từ wt
        if (Math.abs(wt.length - qt.length) <= maxEd) {
          const d = damerauLevenshtein(qt, wt, maxEd);
          if (d <= maxEd) {
            const firstCharPen = qt[0] === wt[0] ? 0 : 0.35;
            const pen = d + firstCharPen;
            if (pen < bestPen) { bestPen = pen; bestPos = j; }
          }
        }
        // Hoặc khớp đầu từ dài (khi người chơi đang gõ dở 1 từ dài mà gõ nhầm, vd "masqure" -> "masquerena")
        if (qt.length >= 4 && wt.length > qt.length + 1) {
          const head = wt.slice(0, qt.length);
          const subMax = Math.min(maxEd, qt.length <= 5 ? 1 : 2);
          const dH = damerauLevenshtein(qt, head, subMax);
          if (dH <= subMax) {
            const pen = dH + 0.45 + (qt[0] === wt[0] ? 0 : 0.35);
            if (pen < bestPen) { bestPen = pen; bestPos = j; }
          }
        }
      }
      if (bestPen >= 50) { matchedAll = false; break; }
      if (bestPos === i) inOrderHits++;
      totalPenalty += bestPen;
    }

    if (matchedAll) {
      const avgPen = totalPenalty / qTokens.length;
      if (avgPen <= 2.1) {
        const orderBonus = inOrderHits * 8;
        const tokScore = Math.round(715 - totalPenalty * 58 + orderBonus - Math.min(20, Math.max(0, idx.spacedWords.length - qTokens.length) * 3) + idx.popBonus);
        bestFuzzy = Math.max(bestFuzzy, tokScore);
      }
    }

    return bestFuzzy;
  }

  function parseQuery(rawQuery) {
    const qSpaced = normSpaced(rawQuery);
    const qCollapsed = normCollapsed(rawQuery);
    const qTokens = qSpaced ? qSpaced.split(' ').filter(Boolean) : [];
    return { raw: rawQuery, qSpaced, qCollapsed, qTokens };
  }

  // Trả về danh sách lá bài khớp (đã gắn điểm khớp _matchScore để sắp xếp lá gần giống nhất lên đầu)
  function searchCards(cards, rawQuery, mode) {
    const qObj = parseQuery(rawQuery);
    if (!qObj.qCollapsed) return { items: cards.slice(), fuzzyUsed: false, hasQuery: false };

    const exactOrClose = [];
    const fuzzyCandidates = [];
    const textMatches = [];

    for (let i = 0; i < cards.length; i++) {
      const c = cards[i];
      const idx = ensureCardIndex(c);
      let nScore = 0;
      if (mode !== 'text') {
        nScore = scoreNameMatch(c, qObj);
      }
      if (nScore >= 780) {
        exactOrClose.push({ c, s: nScore });
        continue;
      }
      if (nScore >= 500) {
        fuzzyCandidates.push({ c, s: nScore });
        continue;
      }
      if (mode === 'text' || mode === 'both') {
        if (idx.descSpaced.includes(qObj.qSpaced) || (qObj.qTokens.length > 1 && qObj.qTokens.every(t => idx.descSpaced.includes(t)))) {
          textMatches.push({ c, s: 350 });
        }
      }
    }

    // Nếu đã có nhiều kết quả khớp chuẩn tên (>= 12), chỉ giữ thêm các kết quả fuzzy rất sát (>= 630);
    // Nếu người chơi gõ sai chính tả khiến khớp chuẩn ít/không có, bung đầy đủ danh sách gần giống nhất!
    const minFuzzy = exactOrClose.length >= 12 ? 640 : (exactOrClose.length > 0 ? 575 : 500);
    const keptFuzzy = fuzzyCandidates.filter(x => x.s >= minFuzzy);

    const combined = [...exactOrClose, ...keptFuzzy, ...textMatches];
    combined.sort((a, b) => b.s - a.s || String(a.c.name).localeCompare(String(b.c.name)));

    return {
      items: combined.map(x => x.c),
      scores: new Map(combined.map(x => [x.c.id, x.s])),
      fuzzyUsed: exactOrClose.length === 0 && keptFuzzy.length > 0,
      hasQuery: true,
    };
  }

  // Gợi ý nhanh đích danh tên đầy đủ của lá bài khi đang gõ
  function suggestCards(cards, rawQuery, limit) {
    const maxN = limit || 9;
    const qObj = parseQuery(rawQuery);
    if (!qObj.qCollapsed) return [];
    const scored = [];
    for (let i = 0; i < cards.length; i++) {
      const c = cards[i];
      const s = scoreNameMatch(c, qObj);
      if (s >= 510) scored.push({ c, s });
    }
    scored.sort((a, b) => b.s - a.s || a.c.name.length - b.c.name.length || String(a.c.name).localeCompare(String(b.c.name)));
    return scored.slice(0, maxN).map(x => x.c);
  }

  function highlightMatch(cardName, rawQuery) {
    const qTokens = parseQuery(rawQuery).qTokens.filter(t => t.length >= 2);
    if (!qTokens.length) return esc(cardName);
    // Tô sáng các từ trong tên bài khớp (hoặc gần giống) từ người chơi gõ
    return String(cardName).split(/([A-Za-z0-9]+)/).map(part => {
      if (!/^[A-Za-z0-9]+$/.test(part)) return esc(part);
      const low = stripAccents(part).toLowerCase();
      const matched = qTokens.some(qt => low.startsWith(qt) || low === qt || (qt.length >= 4 && damerauLevenshtein(qt, low.slice(0, qt.length), 1) <= 1));
      return matched ? `<mark>${esc(part)}</mark>` : esc(part);
    }).join('');
  }

  // Gắn menu gợi ý tên lá bài trực tiếp bên dưới ô input
  function attachAutocomplete(inputEl, opts) {
    if (!inputEl) return;
    const getCards = opts.getCards || (() => []);
    const onPick = opts.onSelect || (() => {});

    // Bọc input trong .ac-wrap nếu chưa bọc
    let wrap = inputEl.parentElement;
    if (!wrap || !wrap.classList.contains('ac-wrap')) {
      wrap = document.createElement('div');
      wrap.className = 'ac-wrap';
      if (inputEl.style.flex) wrap.style.flex = inputEl.style.flex;
      if (inputEl.style.minWidth) wrap.style.minWidth = inputEl.style.minWidth;
      inputEl.parentNode.insertBefore(wrap, inputEl);
      wrap.appendChild(inputEl);
    }
    inputEl.setAttribute('autocomplete', 'off');
    inputEl.setAttribute('spellcheck', 'false');

    const pop = document.createElement('div');
    pop.className = 'ygo-ac-pop';
    wrap.appendChild(pop);

    let items = [], activeIdx = -1;

    function close() {
      pop.classList.remove('open');
      activeIdx = -1;
    }

    function updateHighlight() {
      [...pop.children].forEach((el, idx) => {
        el.classList.toggle('active', idx === activeIdx);
        if (idx === activeIdx) el.scrollIntoView({ block: 'nearest' });
      });
    }

    function choose(card) {
      if (!card) return;
      inputEl.value = card.name;
      close();
      onPick(card);
    }

    function refresh() {
      const q = inputEl.value.trim();
      if (!q) { close(); return; }
      items = suggestCards(getCards(), q, 9);
      if (!items.length || (items.length === 1 && items[0].name.toLowerCase() === q.toLowerCase())) {
        close();
        return;
      }
      activeIdx = -1;
      pop.innerHTML = '';
      items.forEach((c, idx) => {
        const row = document.createElement('div');
        row.className = 'ygo-ac-item';
        const iid = (c.img || [])[0] || c.id;
        const sub = [c.type, c.attribute, c.race, c.atk != null ? 'ATK ' + (c.atk < 0 ? '?' : c.atk) : ''].filter(Boolean).join(' • ');
        row.innerHTML = `<img alt=""><div class="ygo-ac-main"><div class="ygo-ac-name">${highlightMatch(c.name, q)}</div><div class="ygo-ac-sub">${esc(sub)}</div></div>`;
        const im = row.querySelector('img');
        im.src = `/ygodata/images/small/${iid}.jpg`;
        im.onerror = () => { im.onerror = null; im.src = c.small || `https://images.ygoprodeck.com/images/cards_small/${iid}.jpg`; };
        row.onmouseenter = () => { activeIdx = idx; updateHighlight(); };
        row.onmousedown = e => { e.preventDefault(); choose(c); };
        pop.appendChild(row);
      });
      pop.classList.add('open');
    }

    let deb;
    inputEl.addEventListener('input', () => { clearTimeout(deb); deb = setTimeout(refresh, 90); });
    inputEl.addEventListener('focus', () => { if (inputEl.value.trim()) refresh(); });
    inputEl.addEventListener('blur', () => setTimeout(close, 140));
    inputEl.addEventListener('keydown', e => {
      if (!pop.classList.contains('open')) return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        activeIdx = (activeIdx + 1) % items.length;
        updateHighlight();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        activeIdx = (activeIdx - 1 + items.length) % items.length;
        updateHighlight();
      } else if (e.key === 'Enter' && activeIdx >= 0 && items[activeIdx]) {
        e.preventDefault();
        choose(items[activeIdx]);
      } else if (e.key === 'Escape') {
        close();
      }
    });
  }

  window.YGO_BAN = {
    FORMATS,
    loadBanMeta,
    loadBanlist,
    clearBanCache,
    normalizeBanEntry,
    getCardBan,
    formatLabel,
  };

  window.YGO_SMART = {
    normSpaced,
    normCollapsed,
    searchCards,
    suggestCards,
    attachAutocomplete,
  };
})();
