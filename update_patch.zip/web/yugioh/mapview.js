// Trình dựng Sơ đồ Combo chuyên sâu theo Deck (Multi-Starter + Handtrap Pivot + Inline Rich Editor)
// Hỗ trợ:
//  - Tạo nhiều chuỗi Mở bài (Starter 1, Starter 2, Starter 3...) xếp tầng từ trên xuống đúng chuẩn sơ đồ thực chiến
//  - Rẽ nhánh xử lý khi dính Handtrap (Ash, Imperm/Veiler, Maxx "C", Nibiru, Droll, Impulse...) sang phương án B hoặc nhảy xuống chuỗi Starter khác bên dưới, hoặc hội tụ nhiều Starter về chung Sân cuối
//  - Chỉnh sửa trực tiếp (Inline Popover, không dùng hộp thoại prompt thô) trên từng mũi tên nối tiếp & từng nút bước (nhãn chính, chi tiết phụ/cost, màu nhánh, icon Handtrap đính kèm)
//  - Kéo-thả dây nối trực tiếp từ chấm cổng (●) của nút này sang nút khác
(function () {
  'use strict';

  const LS_DECKS = 'ygo_decks_v1';
  const LS_CUR_DECK = 'ygo_cur_deck_v1';
  const LS_CUSTOM_ACTS = 'ygo_combo_custom_acts_v1';
  const SS_COMBO_DECK = 'ygo_combo_deck_id';

  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const slotId = x => (x && typeof x === 'object') ? x.id : x;
  const slotSpec = x => (x && typeof x === 'object') ? x.spec : null;
  const isExtraCard = c => /Fusion|Synchro|XYZ|Link/i.test((c && c.type) || '');

  const NODE_W = 296, GAP_X = 205, GAP_Y = 78;

  // Các nhóm nhãn hành động nối tiếp chi tiết
  const ACTION_GROUPS = {
    basic: {
      title: '⚡ Cơ bản',
      items: [
        { label: 'Normal Summon', stepTitle: 'Normal Summon', kind: 'normal' },
        { label: 'Special Summon', stepTitle: 'Special Summon', kind: 'normal' },
        { label: 'Kích hiệu ứng', stepTitle: 'Kích hiệu ứng', kind: 'normal' },
        { label: 'Search lên tay', stepTitle: 'Tìm lên tay', kind: 'normal' },
        { label: 'Đặt/Úp từ Deck', stepTitle: 'Đặt từ Deck', kind: 'normal' },
        { label: 'Gửi xuống Mộ', stepTitle: 'Gửi xuống Mộ', kind: 'normal' },
        { label: 'Trục xuất', stepTitle: 'Trục xuất', kind: 'normal' },
        { label: 'Úp bài (Set)', stepTitle: 'Úp Phép/Bẫy', kind: 'normal' },
        { label: 'Rút bài (Draw)', stepTitle: 'Rút bài', kind: 'normal' },
        { label: 'Sân cuối / End Board', stepTitle: 'Sân cuối / End Board', kind: 'endboard' },
      ],
    },
    extra: {
      title: '🌀 Triệu hồi & Nâng cao',
      items: [
        { label: 'Fusion Summon', stepTitle: 'Fusion Summon', kind: 'normal' },
        { label: 'Contact Fusion', stepTitle: 'Contact Fusion', kind: 'normal' },
        { label: 'Synchro Summon', stepTitle: 'Synchro Summon', kind: 'normal' },
        { label: 'Xyz Summon', stepTitle: 'Xyz Summon', kind: 'normal' },
        { label: 'Đè Xyz (Rank-Up)', stepTitle: 'Xyz Rank-Up', kind: 'normal' },
        { label: 'Link Summon', stepTitle: 'Link Summon', kind: 'normal' },
        { label: 'Pendulum Summon', stepTitle: 'Pendulum Summon', kind: 'normal' },
        { label: 'Ritual Summon', stepTitle: 'Ritual Summon', kind: 'normal' },
        { label: 'Tribute Summon', stepTitle: 'Tribute Summon', kind: 'normal' },
        { label: 'Hồi sinh từ Mộ', stepTitle: 'Hồi sinh từ Mộ', kind: 'normal' },
        { label: 'SS từ vùng Banish', stepTitle: 'SS từ Banish', kind: 'normal' },
        { label: 'Kích eff dưới Mộ', stepTitle: 'Kích eff Mộ', kind: 'normal' },
        { label: 'Kích eff trên tay', stepTitle: 'Kích eff Tay', kind: 'normal' },
        { label: 'Cost: Bỏ bài trên tay', stepTitle: 'Trả Cost bỏ bài', kind: 'normal' },
        { label: 'Đổ Deck (Mill)', stepTitle: 'Mill Deck', kind: 'normal' },
        { label: 'Gửi Extra xuống Mộ', stepTitle: 'Gửi từ Extra', kind: 'normal' },
        { label: 'Đặt Pendulum Scale', stepTitle: 'Đặt Scale', kind: 'normal' },
        { label: 'Gọi Token', stepTitle: 'Triệu hồi Token', kind: 'normal' },
      ],
    },
    handtrap: {
      title: '🛑 Dính Handtrap / Đổi hướng',
      items: [
        { label: 'Dính Ash Blossom', stepTitle: 'Phương án B (Vượt Ash)', kind: 'handtrap', htCard: 'Ash Blossom & Joyous Spring' },
        { label: 'Dính Imperm / Veiler', stepTitle: 'Phương án B (Vượt Imperm)', kind: 'handtrap', htCard: 'Infinite Impermanence' },
        { label: 'Dính Maxx "C" / Fuwalos', stepTitle: 'Dừng ngắn (Né Maxx "C")', kind: 'handtrap', htCard: 'Maxx "C"' },
        { label: 'Dính Nibiru (5 Summon)', stepTitle: 'Phục hồi sau Nibiru', kind: 'handtrap', htCard: 'Nibiru, the Primal Being' },
        { label: 'Dính Droll & Lock Bird', stepTitle: 'Đường đánh dưới Droll', kind: 'handtrap', htCard: 'Droll & Lock Bird' },
        { label: 'Dính Dominus Impulse', stepTitle: 'Phương án B (Vượt Impulse)', kind: 'handtrap', htCard: 'Dominus Impulse' },
        { label: 'Dính Called by / Bystial', stepTitle: 'Đổi hướng khi mất Mộ', kind: 'handtrap', htCard: 'Called by the Grave' },
        { label: 'Dính Ghost Ogre / Phá bài', stepTitle: 'Phương án B (Khi bị nổ)', kind: 'handtrap', htCard: 'Ghost Ogre & Snow Rabbit' },
        { label: 'Bị Negate / Bị cản', stepTitle: 'Phương án dự phòng', kind: 'handtrap' },
        { label: 'Đổi sang Starter dưới', stepTitle: 'Chuyển sang Starter phụ', kind: 'pivot' },
        { label: 'Chain chống HT (Called/Crossout)', stepTitle: 'Chain bảo kê combo', kind: 'counter', htCard: 'Called by the Grave' },
        { label: 'Hội tụ về nhánh chính', stepTitle: 'Nhập chung nhánh chính', kind: 'converge' },
      ],
    },
  };

  const HANDTRAP_CARDS = [
    { label: 'Ash Blossom', name: 'Ash Blossom & Joyous Spring', edgeText: 'Dính Ash Blossom' },
    { label: 'Imperm', name: 'Infinite Impermanence', edgeText: 'Dính Imperm / Veiler' },
    { label: 'Effect Veiler', name: 'Effect Veiler', edgeText: 'Dính Effect Veiler' },
    { label: 'Maxx "C"', name: 'Maxx "C"', edgeText: 'Dính Maxx "C"' },
    { label: 'Fuwalos', name: 'Mulcharmy Fuwalos', edgeText: 'Dính Fuwalos' },
    { label: 'Nibiru', name: 'Nibiru, the Primal Being', edgeText: 'Dính Nibiru' },
    { label: 'Droll', name: 'Droll & Lock Bird', edgeText: 'Dính Droll & Lock Bird' },
    { label: 'Impulse', name: 'Dominus Impulse', edgeText: 'Dính Dominus Impulse' },
    { label: 'Purge', name: 'Dominus Purge', edgeText: 'Dính Dominus Purge' },
    { label: 'Ghost Ogre', name: 'Ghost Ogre & Snow Rabbit', edgeText: 'Dính Ghost Ogre' },
    { label: 'Ghost Belle', name: 'Ghost Belle & Haunted Mansion', edgeText: 'Dính Ghost Belle' },
    { label: 'Called by', name: 'Called by the Grave', edgeText: 'Dính Called by' },
  ];

  const EDGE_KINDS = {
    normal: { label: '🟢 Combo chuẩn', stroke: '#2dd4bf', bg: '#152530', border: '#2dd4bf', text: '#e2f8f5', dash: '' },
    handtrap: { label: '🔴 Bị dính Handtrap / Cản', stroke: '#fb7185', bg: '#2c1420', border: '#fb7185', text: '#ffe4e6', dash: '6,4' },
    pivot: { label: '🟡 Đổi phương án / Sang Starter dưới', stroke: '#fbbf24', bg: '#2b2112', border: '#fbbf24', text: '#fef3c7', dash: '5,3' },
    counter: { label: '🟣 Chain bảo kê / Hội tụ nhánh', stroke: '#a78bfa', bg: '#221b38', border: '#a78bfa', text: '#ede9fe', dash: '' },
    converge: { label: '🟣 Hội tụ về nhánh chính', stroke: '#a78bfa', bg: '#221b38', border: '#a78bfa', text: '#ede9fe', dash: '' },
    endboard: { label: '🏁 Chốt Sân cuối', stroke: '#34d399', bg: '#122b22', border: '#34d399', text: '#d1fae5', dash: '' },
  };

  const EDGE_ROUTES = {
    curve: '🌊 Uốn mềm tự do (Kéo dây tùy ý)',
    ortho: '╭─╯ Gấp khúc vuông bo góc',
    'loop-left': '⊂ Vòng cung ngoài hông Trái',
    'loop-right': '⊃ Vòng cung ngoài hông Phải',
  };

  const PORT_SIDES = {
    auto: 'Tự động',
    right: 'Cạnh Phải',
    bottom: 'Cạnh Dưới',
    left: 'Cạnh Trái',
    top: 'Cạnh Trên',
  };

  const NODE_ROLES = {
    starter: { label: '🌟 Starter (Mở bài)', cls: 'role-starter' },
    step: { label: '🔹 Bước trung gian', cls: 'role-step' },
    planb: { label: '🟠 Phương án B (Vượt HT)', cls: 'role-planb' },
    endboard: { label: '🏁 Sân cuối (End Board)', cls: 'role-end' },
  };

  window.YGO_MAP_SEED = [{
    id: 'demo-structure',
    name_vi: 'Mẫu cấu trúc Đa Starter & Chữa cháy Handtrap (minh họa)',
    name_en: 'Multi-Starter & Handtrap Backup demo',
    nodes: [
      { id: 'n1', role: 'starter', title: 'Starter 1: Junk Synchron', cards: ['Junk Synchron'], x: 84, y: 28, note: 'NS Junk Synchron → kích eff kéo quái Lv2 từ Mộ lên sân' },
      { id: 'n2', role: 'step', title: 'B1: Synchro chủ lực', cards: ['Junk Warrior'], x: 544, y: 28, note: 'Synchro Lv5 → kích eff cộng ATK trên sân' },
      { id: 'n3', role: 'endboard', title: 'Sân cuối A / End Board', cards: ['Baronne de Fleur', 'Junk Warrior'], x: 1004, y: 28, note: '1 Omni-Negate + bắn phá bài mỗi lượt' },
      { id: 'n4', role: 'starter', title: 'Starter 2: Mở bài phụ', cards: ['Number 39: Utopia'], x: 84, y: 225, note: 'Đi độc lập hoặc nhảy tiếp khi Starter 1 bị Imperm chặn' },
      { id: 'n5', role: 'planb', title: 'Phương án B (Chữa cháy)', cards: ['Accesscode Talker'], x: 544, y: 225, note: 'Dùng xác quái trên sân Link lên chốt hạ hoặc hội tụ về sân cuối' },
    ],
    edges: [
      { from: 'n1', to: 'n2', label: 'Synchro Summon', sub: 'Không bị cản', kind: 'normal' },
      { from: 'n2', to: 'n3', label: 'Sân cuối / End Board', kind: 'endboard' },
      { from: 'n1', to: 'n4', label: 'Dính Imperm / Veiler', sub: 'Đổi sang Starter 2 trên tay', kind: 'handtrap', htCard: 'Infinite Impermanence' },
      { from: 'n4', to: 'n5', label: 'Special Summon', sub: 'Nối tiếp bằng Extender', kind: 'pivot' },
      { from: 'n5', to: 'n3', label: 'Hội tụ về nhánh chính', sub: 'Vẫn lên được Sân cuối', kind: 'converge' },
    ],
  }];

  const entryName = item => (item && typeof item === 'object') ? (item.name || '') : String(item || '');
  const entrySpec = item => (item && typeof item === 'object') ? (item.spec || null) : null;
  const entryId = item => (item && typeof item === 'object') ? (item.id || null) : null;

  const nodeHeight = n => {
    const nCards = (n.cards || []).length;
    const noteLines = n.note ? Math.max(1, String(n.note).split(/\n/).reduce((s, l) => s + Math.max(1, Math.ceil(l.length / 22)), 0)) : 0;
    if (nCards <= 1) {
      return 52 + Math.max(114, noteLines * 19 + 18);
    }
    const cardRows = Math.ceil(nCards / 3);
    return 52 + cardRows * 114 + Math.max(54, noteLines * 19 + 16);
  };

  // Bố cục thông minh giữ nguyên cột Starter bên trái (Starter 1, Starter 2, Starter 3...) xếp từ trên xuống
  function autoLayout(map, forceReset) {
    if (!map || !Array.isArray(map.nodes) || !map.nodes.length) return;
    if (forceReset) map.nodes.forEach(n => { delete n.x; delete n.y; });

    const byId = Object.fromEntries(map.nodes.map(n => [n.id, n]));
    const incomingNonVertical = {};
    (map.edges || []).forEach(e => {
      // Nếu đích là 1 nút được đánh dấu rõ là Starter thì vẫn giữ nút đó ở cột 0 (cột Starter bên trái)!
      const dst = byId[e.to];
      if (dst && dst.role === 'starter') return;
      (incomingNonVertical[e.to] = incomingNonVertical[e.to] || []).push(e.from);
    });

    const roots = map.nodes.filter(n => n.role === 'starter' || !(incomingNonVertical[n.id] || []).length);
    const startNodes = roots.length ? roots : [map.nodes[0]];
    const depth = {};
    const laneOf = {};
    startNodes.forEach((r, idx) => {
      depth[r.id] = 0;
      laneOf[r.id] = idx;
    });

    const q = startNodes.map(r => r.id);
    while (q.length) {
      const id = q.shift();
      (map.edges || []).filter(e => e.from === id).forEach(e => {
        const dst = byId[e.to];
        if (!dst || dst.role === 'starter') return;
        const d = (depth[id] || 0) + 1;
        if (!(e.to in depth && depth[e.to] >= d) && d < 40) {
          depth[e.to] = d;
          if (!(e.to in laneOf)) laneOf[e.to] = laneOf[id] ?? 0;
          q.push(e.to);
        }
      });
    }

    // Xếp theo từng dải ngang (lane) của từng Starter để các chuỗi Starter 1, Starter 2, Starter 3 nằm thành hàng ngang rõ ràng
    const laneCount = Math.max(1, startNodes.length);
    let laneBaseY = 28;
    for (let ln = 0; ln < laneCount; ln++) {
      const inLane = map.nodes.filter(n => (laneOf[n.id] ?? 0) === ln);
      const byCol = {};
      inLane.forEach(n => {
        const c = depth[n.id] || 0;
        (byCol[c] = byCol[c] || []).push(n);
      });
      let maxLaneBottom = laneBaseY + 150;
      Object.entries(byCol).forEach(([col, arr]) => {
        let cy = laneBaseY;
        arr.forEach(n => {
          if (n.x == null || n.y == null) {
            n.x = 84 + Number(col) * (NODE_W + GAP_X);
            n.y = cy;
          }
          const btm = (n.y || cy) + nodeHeight(n);
          if (btm > maxLaneBottom) maxLaneBottom = btm;
          cy += nodeHeight(n) + 28;
        });
      });
      laneBaseY = maxLaneBottom + GAP_Y;
    }

    // Các nút rời chưa thuộc lane nào
    map.nodes.filter(n => n.x == null || n.y == null).forEach(n => {
      n.x = 84 + (depth[n.id] || 0) * (NODE_W + GAP_X);
      n.y = laneBaseY;
      laneBaseY += nodeHeight(n) + GAP_Y;
    });
  }

  function loadBuiltDecks() {
    try { return JSON.parse(localStorage.getItem(LS_DECKS)) || []; } catch (e) { return []; }
  }
  function saveBuiltDecks(decks, curId) {
    try {
      localStorage.setItem(LS_DECKS, JSON.stringify(decks));
      if (curId) localStorage.setItem(LS_CUR_DECK, curId);
    } catch (e) { }
  }
  function loadCustomActs() {
    try { return JSON.parse(localStorage.getItem(LS_CUSTOM_ACTS)) || []; } catch (e) { return []; }
  }
  function saveCustomActs(arr) {
    try { localStorage.setItem(LS_CUSTOM_ACTS, JSON.stringify(arr)); } catch (e) { }
  }

  async function render(box, api) {
    box.innerHTML = '<p class="muted">Đang nạp kho bài &amp; sơ đồ combo...</p>';
    const ART = window.YGO_ART, SMART = window.YGO_SMART;
    const [cards] = await Promise.all([
      api.loadCards ? api.loadCards() : Promise.resolve(window.__ygoCards || []),
      ART ? ART.loadSpecial() : Promise.resolve(),
    ]);

    const byId = new Map();
    const byName = new Map();
    (cards || []).forEach(c => {
      byId.set(c.id, c);
      (c.img || []).forEach(iid => { if (!byId.has(iid)) byId.set(iid, c); });
      byName.set(String(c.name).toLowerCase(), c);
    });

    const cardThumbSrc = nameOrId => {
      const c = typeof nameOrId === 'number' ? byId.get(nameOrId) : byName.get(String(nameOrId || '').toLowerCase());
      if (!c) return '';
      const iid = (c.img && c.img[0]) || c.id;
      return {
        local: `/ygodata/images/small/${iid}.jpg`,
        remote: c.small || `https://images.ygoprodeck.com/images/cards_small/${iid}.jpg`,
        name: c.name,
      };
    };

    let decks = loadBuiltDecks();
    let customActs = loadCustomActs();
    const requestedDeckId = sessionStorage.getItem(SS_COMBO_DECK) || '';
    if (requestedDeckId) sessionStorage.removeItem(SS_COMBO_DECK);

    const savedUserMaps = (api.getUser().maps || []).map(m => JSON.parse(JSON.stringify(m)));
    const state = {
      maps: [
        ...window.YGO_MAP_SEED.map(m => ({ ...JSON.parse(JSON.stringify(m)), _seed: true })),
        ...savedUserMaps,
      ],
      idx: 0,
      deckId: '',
      zoneTab: 'all',
      trayQuery: '',
      // 3 chế độ bấm thẻ cực trực quan:
      // 'starter' = tạo Starter mới ở hàng dưới | 'step' = nối bước tiếp theo | 'into' = gộp vào nút đang chọn
      addMode: 'step',
      actGroup: 'basic',
      actionLabel: 'Special Summon',
      actionSub: '',
      actionKind: 'normal',
      actionHtCard: '',
      // Nếu vừa bấm nút ⚡ trên 1 bước để chuẩn bị rẽ nhánh chữa cháy Handtrap bằng lá tiếp theo trong Deck:
      pendingBranch: null, // { fromId, label, sub, kind, htCard }
      selectedNodeId: null,
      selectedEdgeIdx: null,
      linkFrom: null,
      cutMode: false,
      mergeMode: false,
      mergeFirstIdx: null,
      dragMergeHoverIdx: null,
      undoStack: [],
      locked: false,
      trayCollapsed: false,
      actPanelCollapsed: true,
      expandedCanvas: false,
      scale: 1,
      panX: 256,
      panY: 88,
    };

    const savedCurDeck = localStorage.getItem(LS_CUR_DECK) || '';
    if (requestedDeckId && decks.some(d => d.id === requestedDeckId)) {
      state.deckId = requestedDeckId;
    } else if (savedCurDeck && decks.some(d => d.id === savedCurDeck)) {
      state.deckId = savedCurDeck;
    } else if (decks.length) {
      state.deckId = decks[0].id;
    }

    if (requestedDeckId && state.deckId) {
      const existingIdx = state.maps.findIndex(m => !m._seed && m.deckId === state.deckId);
      if (existingIdx >= 0) {
        state.idx = existingIdx;
      } else {
        const dk = decks.find(d => d.id === state.deckId);
        if (dk) {
          state.maps.push({
            id: 'm' + Date.now(),
            name_vi: 'Combo: ' + dk.name,
            name_en: 'Combo: ' + dk.name,
            deckId: dk.id,
            nodes: [],
            edges: [],
          });
          state.idx = state.maps.length - 1;
        }
      }
    } else if (savedUserMaps.length) {
      state.idx = 1;
      if (state.maps[1].deckId && decks.some(d => d.id === state.maps[1].deckId)) {
        state.deckId = state.maps[1].deckId;
      }
    }

    const curMap = () => state.maps[state.idx];
    const curDeck = () => decks.find(d => d.id === state.deckId) || null;

    const persistMaps = () => {
      const u = api.getUser();
      u.maps = state.maps.filter(m => !m._seed).map(m => {
        const { _seed, ...rest } = m;
        return rest;
      });
      api.setUser(u);
    };

    if (requestedDeckId) persistMaps();

    box.innerHTML = `
      <div class="cmap-layout" id="cmapLayout">
        <div id="mapWrap" class="mapwrap">
          <div id="mapStage" class="mapstage">
            <svg id="mapSvg" class="mapsvg"></svg>
            <div id="mapNodes"></div>
          </div>
          <div id="cmPopHost"></div>
          <div class="cm-zoom-hud" onpointerdown="event.stopPropagation()">
            <button type="button" id="cmZoomOut" title="Thu nhỏ sơ đồ">➖</button>
            <button type="button" id="cmZoomReset" title="Bấm để đặt lại kích thước chuẩn 100% to rõ nhất">100%</button>
            <button type="button" id="cmZoomIn" title="Phóng to sơ đồ">➕</button>
            <button type="button" id="cmZoomFit" title="Tự căn vừa khít toàn bộ các bước vào khung nhìn">⊡ Vừa khung</button>
            <button type="button" id="cmFullCanvas" title="Mở rộng khung sơ đồ tràn toàn màn hình (hoặc phím Esc để thu lại)">⛶ Toàn màn hình</button>
          </div>
        </div>

        <aside class="card cmap-tray" id="cmapTray">
          <div class="cmap-tray-hdr">
            <b>🃏 Deck dùng để tạo Combo</b>
            <button type="button" class="small" id="cmToggleTray" title="Thu gọn khay bài">«</button>
          </div>

          <div class="row" style="margin:6px 0">
            <select id="cmDeckSel" style="flex:1;min-width:140px"></select>
          </div>
          <div class="row" style="margin:6px 0;gap:6px">
            <button type="button" id="cmImpYdk" class="small primary" style="flex:1" title="Nạp file Deck (.ydk hoặc .txt) từ máy tính vào để tạo combo">📂 Nạp file .ydk</button>
            <button type="button" id="cmDraw5" class="small" title="Rút ngẫu nhiên 5 lá từ Main Deck thành 1 Starter Tay mở bài">🎲 Mở 5 lá</button>
            ${api.openTab ? '<button type="button" id="cmGoDeck" class="small" title="Chỉnh sửa Deck này trong Xây deck">🛠 Sửa Deck</button>' : ''}
            <input type="file" id="cmYdkFile" accept=".ydk,.txt" style="display:none">
          </div>

          <div class="cmap-mode-switch three">
            <button type="button" id="cmModeStarter" title="Bấm vào từng lá bài trong Deck để tạo lần lượt nhiều chuỗi Mở bài (Starter 1, Starter 2, Starter 3...) xếp dọc từ trên xuống">🌟 + Starter mới</button>
            <button type="button" id="cmModeStep" class="active" title="Bấm vào lá bài sẽ tạo bước ngang tiếp theo nối từ nút đang chọn">➕ Nối bước tiếp</button>
            <button type="button" id="cmModeInto" title="Bấm vào lá bài sẽ gộp chung lá đó vào trong nút đang chọn (vd: Starter 2 lá hoặc Sân cuối nhiều quái)">📥 Gộp chung nút</button>
          </div>

          <div class="cmap-zone-tabs" id="cmZoneTabs"></div>
          <div class="row" style="margin:6px 0">
            <input id="cmFilter" placeholder="Lọc nhanh lá bài trong deck..." style="width:100%;padding:6px 10px;font-size:13px">
          </div>

          <div id="cmDeckCards" class="cmap-deck-grid"></div>

          <div class="cmap-ext-box">
            <div class="hint" style="font-weight:700;margin-bottom:4px">➕ Thêm Token / Lá ngoài Deck:</div>
            <div class="row" style="margin:0"><input id="cmExtSearch" placeholder="Gõ tên Token hoặc lá bất kỳ..." style="width:100%;padding:6px 10px;font-size:13px"></div>
          </div>
          <div class="hint" style="margin-top:6px">💡 <b>🌟 + Starter mới</b>: xếp nhiều mở bài từ trên xuống • <b>⚡ trên mỗi nút</b>: rẽ phương án khác khi dính Handtrap • <b>Chuột phải vào dây</b> (hoặc nút <b>× / ✂️</b>): xóa dây nối nhầm!</div>
        </aside>

        <div class="cmap-hud-top" id="cmapHudTop">
          <div class="cmap-top">
            <h2 style="margin:0;font-size:16.5px;white-space:nowrap">🕸️ Sơ đồ Combo theo Deck</h2>
            <div class="row" style="margin:0;flex:1;justify-content:flex-end;gap:6px">
              <select id="mapSel" style="min-width:200px;max-width:310px;padding:5px 10px;font-size:13px"></select>
              <button id="mNew" class="small primary">+ Sơ đồ mới</button>
              <button id="mRen" class="small">✎ Đổi tên</button>
              <button id="mAuto" class="small" title="Tự động căn thẳng cột các Starter bên trái và các tầng bước sang phải">📐 Tự căn tầng</button>
              <button id="mFit" class="small" title="Tự thu phóng &amp; căn vừa khít toàn bộ sơ đồ vào khung nhìn">⊡ Vừa khung</button>
              <button id="mFull" class="small" title="Mở rộng khung sơ đồ tràn toàn bộ màn hình để nhìn to rõ nhất">⛶ Phóng to khung</button>
              <button id="mLock" class="small" title="Khóa kéo/xóa để chỉ xem & bấm đọc hiệu ứng">🔓 Đang mở sửa</button>
              <button id="mClrNodes" class="small" title="Xóa hết các bước trong sơ đồ hiện tại để vẽ lại">🧹 Làm trống</button>
              <button id="mDel" class="small danger">Xóa sơ đồ</button>
              <button id="mExp" class="small">⬇ JSON</button>
              <button id="mImp" class="small">⬆ JSON</button>
              <input type="file" id="mFile" accept=".json" style="display:none">
            </div>
          </div>

          <div class="cmap-actbar">
            <button type="button" class="small" id="cmExpandTray" style="display:none">🃏 Mở khay Deck »</button>
            <span class="cmap-sel-status" id="cmSelStatus"></span>
            <button type="button" class="small starter-btn" id="cmQuickStarter" title="Tạo chuỗi Starter mới ở hàng bên dưới (lá bài tiếp theo bấm từ Deck sẽ làm Starter mới)">🌟 + Chuỗi Starter dưới</button>
            <button type="button" class="small ht-btn" id="cmQuickHt" title="Tạo nhánh xử lý khi bước đang chọn bị dính Handtrap / đổi sang Starter bên dưới">⚡ Bị dính Handtrap...</button>
            <button type="button" class="small merge-btn" id="cmMergeMode" title="Hợp nhất 2 dây cùng đi vào 1 bước (vd: 2 quái cùng Synchro/Link/Fusion) hoặc cùng xuất phát thành 1 nhánh chữ Y gọn đẹp! (Mẹo: bạn cũng có thể kéo thả hộp nhãn của dây này đè lên hộp nhãn dây kia)">🔀 Hợp nhất dây</button>
            <button type="button" class="small cut-btn" id="cmCutMode" title="Bật chế độ Cắt dây: bấm vào sợi dây nào là xóa ngay sợi dây đó (Mẹo: bạn cũng có thể bấm Chuột phải hoặc nút × đỏ trên dây bất kỳ lúc nào!)">✂️ Xóa dây nối</button>
            <button type="button" class="small" id="cmUndo" disabled title="Hoàn tác thao tác vừa xóa / nối nhầm (Ctrl+Z)">↶ Hoàn tác</button>
            <button type="button" class="small" id="cmAddEmpty">+ Nút trống</button>
            <button type="button" class="small" id="cmToggleActPanel" title="Ẩn / Hiện bảng chọn nhãn hành động bên dưới">🏷️ Hiện bảng nhãn ▾</button>
          </div>

          <div class="cmap-act-panel" id="cmActPanel" style="display:none">
            <div class="cmap-act-top">
              <div class="cmap-act-tabs" id="cmActTabs">
                <button type="button" class="active" data-grp="basic">⚡ Cơ bản</button>
                <button type="button" data-grp="extra">🌀 Triệu hồi &amp; Nâng cao</button>
                <button type="button" data-grp="handtrap">🛑 Bị Handtrap / Đổi hướng</button>
                <button type="button" data-grp="custom">⭐ Nhãn tự lưu (<span id="cmCusCnt">0</span>)</button>
              </div>
              <div class="cmap-act-inputs">
                <select id="cmActKind" title="Màu & kiểu mũi tên nối tiếp" style="padding:4px 8px;font-size:12px;border-radius:99px">
                  ${Object.entries(EDGE_KINDS).map(([k, v]) => `<option value="${k}">${esc(v.label)}</option>`).join('')}
                </select>
                <input id="cmCustomAct" value="${esc(state.actionLabel)}" placeholder="Nhãn chính (vd: Search lên tay, Dính Ash...)" style="padding:4px 10px;font-size:12.5px;min-width:155px;border-radius:99px">
                <input id="cmCustomSub" value="" placeholder="Chi tiết phụ / Cost / Điều kiện (tùy chọn)..." style="padding:4px 10px;font-size:12px;min-width:185px;border-radius:99px">
                <button type="button" class="small" id="cmSaveAct" title="Lưu nhãn đang gõ vào mục ⭐ Nhãn tự lưu để dùng lại 1 chạm">+ Lưu mẫu</button>
              </div>
            </div>
            <div class="cmap-presets" id="cmPresets"></div>
          </div>
        </div>
      </div>`;

    const $ = s => box.querySelector(s);
    const popHost = $('#cmPopHost');

    function closePopover() {
      popHost.innerHTML = '';
    }

    function clampPopoverInWrap() {
      const pop = popHost.querySelector('.cm-popover');
      const wrapEl = $('#mapWrap');
      if (!pop || !wrapEl) return;
      const wr = wrapEl.getBoundingClientRect();
      if (!wr.width || !wr.height) return;
      const pw = pop.offsetWidth || 356;
      const ph = pop.offsetHeight || 340;
      const curL = parseFloat(pop.style.left) || 12;
      const curT = parseFloat(pop.style.top) || 12;
      pop.style.left = Math.max(10, Math.min(curL, wr.width - pw - 10)) + 'px';
      pop.style.top = Math.max(10, Math.min(curT, wr.height - ph - 10)) + 'px';
    }

    function syncUndoBtn() {
      const btn = $('#cmUndo');
      if (btn) btn.disabled = !state.undoStack.length;
    }

    function syncCutBtn() {
      const btn = $('#cmCutMode');
      const mBtn = $('#cmMergeMode');
      const wrapEl = $('#mapWrap');
      if (btn) btn.classList.toggle('active', !!state.cutMode);
      if (mBtn) mBtn.classList.toggle('active', !!state.mergeMode);
      if (wrapEl) {
        wrapEl.classList.toggle('cut-mode', !!state.cutMode);
        wrapEl.classList.toggle('merge-mode', !!state.mergeMode);
      }
    }

    function edgeSpecificity(e) {
      if (!e || !e.label || e.label === 'Bấm để sửa') return 0;
      if (e.label === 'Hội tụ về nhánh chính' || e.label === 'Đổi sang Starter dưới') return 1;
      if (e.label === 'Special Summon') return 2;
      return 3;
    }

    function getMergeGroupIndices(m, edgeIdx) {
      if (!m || !Array.isArray(m.edges) || !m.edges[edgeIdx]) return [];
      const targetEdge = m.edges[edgeIdx];
      if (!targetEdge.mergeId) return [edgeIdx];
      const idxs = [];
      m.edges.forEach((e, idx) => {
        if (e && e.mergeId === targetEdge.mergeId) idxs.push(idx);
      });
      if (idxs.length < 2) return [edgeIdx];
      const sameTo = idxs.every(idx => m.edges[idx].to === targetEdge.to);
      const sameFrom = idxs.every(idx => m.edges[idx].from === targetEdge.from);
      return (sameTo || sameFrom) ? idxs : [edgeIdx];
    }

    function mergeTwoEdges(idxA, idxB, opts) {
      if (state.locked) {
        api.toast('Đang bật khóa sửa — hãy mở khóa trước');
        return false;
      }
      const m = cloneSeedIfNeeded();
      if (!m || !Array.isArray(m.edges) || idxA === idxB) return false;
      const eA = m.edges[idxA], eB = m.edges[idxB];
      if (!eA || !eB) return false;
      if (eA.to !== eB.to && eA.from !== eB.from) {
        api.toast('⚠️ Chỉ hợp nhất được 2 dây CÙNG ĐÍCH ĐẾN (vd: 2 lá cùng Synchro/Link vào 1 quái) hoặc CÙNG GỐC XUẤT PHÁT!');
        return false;
      }
      if (!(opts && opts.skipUndo)) pushUndo(m);

      const best = edgeSpecificity(eA) > edgeSpecificity(eB) ? eA : eB;
      const other = best === eA ? eB : eA;
      const mergedMeta = {
        label: best.label || other.label || '',
        sub: best.sub || other.sub || '',
        kind: best.kind || 'normal',
        htCard: best.htCard || other.htCard || '',
      };

      // Nếu 2 dây nối trùng hệt cùng gốc & cùng đích (A -> B) -> gộp gọn thành 1 sợi duy nhất
      if (eA.from === eB.from && eA.to === eB.to) {
        eB.label = mergedMeta.label;
        eB.sub = mergedMeta.sub;
        eB.kind = mergedMeta.kind;
        if (mergedMeta.htCard) eB.htCard = mergedMeta.htCard; else delete eB.htCard;
        m.edges.splice(idxA, 1);
        state.mergeMode = false;
        state.mergeFirstIdx = null;
        state.dragMergeHoverIdx = null;
        state.selectedEdgeIdx = null;
        closePopover();
        persistMaps();
        drawCanvas();
        api.toast(`🔀 Đã gộp 2 dây trùng nhau thành 1 dây "${mergedMeta.label || 'Hợp nhất'}"!`);
        return true;
      }

      const sharedTo = eA.to === eB.to ? eA.to : null;
      const sharedFrom = !sharedTo ? eA.from : null;
      const mgId = 'mg_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
      const oldMgA = eA.mergeId, oldMgB = eB.mergeId;

      m.edges.forEach((em, idx) => {
        const inPick = idx === idxA || idx === idxB || (oldMgA && em.mergeId === oldMgA) || (oldMgB && em.mergeId === oldMgB);
        if (!inPick) return;
        if (sharedTo && em.to !== sharedTo) return;
        if (sharedFrom && em.from !== sharedFrom) return;
        em.mergeId = mgId;
        em.label = mergedMeta.label;
        em.sub = mergedMeta.sub;
        em.kind = mergedMeta.kind;
        if (mergedMeta.htCard) em.htCard = mergedMeta.htCard;
        else delete em.htCard;
        delete em.bendX;
        delete em.bendY;
        if (sharedTo) {
          if (eB.toPort) em.toPort = eB.toPort; else delete em.toPort;
        } else if (sharedFrom) {
          if (eB.fromPort) em.fromPort = eB.fromPort; else delete em.fromPort;
        }
      });

      // Dọn dẹp mergeId mồ côi nếu nhóm cũ chỉ còn 1 dây
      const mgCounts = {};
      m.edges.forEach(em => { if (em && em.mergeId) mgCounts[em.mergeId] = (mgCounts[em.mergeId] || 0) + 1; });
      m.edges.forEach(em => { if (em && em.mergeId && mgCounts[em.mergeId] < 2) delete em.mergeId; });

      state.mergeMode = false;
      state.mergeFirstIdx = null;
      state.dragMergeHoverIdx = null;
      state.selectedEdgeIdx = null;
      closePopover();
      persistMaps();
      drawCanvas();
      api.toast(`🔀 Đã hợp nhất thành nhánh chung "${mergedMeta.label || 'Hợp nhất'}"! (Kéo nhãn để uốn dây • Bấm để sửa hoặc Tách riêng)`);
      return true;
    }

    function unmergeGroup(mergeId) {
      const m = cloneSeedIfNeeded();
      if (!m || !mergeId) return;
      pushUndo(m);
      m.edges.forEach(e => {
        if (e.mergeId === mergeId) {
          delete e.mergeId;
          delete e.bendX;
          delete e.bendY;
        }
      });
      state.selectedEdgeIdx = null;
      closePopover();
      persistMaps();
      drawCanvas();
      api.toast('⛓️‍💥 Đã tách thành các sợi dây riêng biệt!');
    }

    function deleteMergeGroup(mergeId) {
      if (state.locked) return;
      const m = cloneSeedIfNeeded();
      if (!m || !mergeId) return;
      pushUndo(m);
      m.edges = m.edges.filter(e => e.mergeId !== mergeId);
      state.selectedEdgeIdx = null;
      closePopover();
      persistMaps();
      drawCanvas();
      api.toast('🗑 Đã xóa nhánh dây hợp nhất • Bấm ↶ Hoàn tác (Ctrl+Z) nếu xóa nhầm');
    }

    function cloneSeedIfNeeded() {
      const m = curMap();
      if (!m) return null;
      if (!m._seed) return m;
      const copy = JSON.parse(JSON.stringify(m));
      delete copy._seed;
      copy.id = 'm' + Date.now();
      copy.name_vi = (copy.name_vi || 'Sơ đồ') + ' (Của tôi)';
      state.maps.push(copy);
      state.idx = state.maps.length - 1;
      persistMaps();
      refreshMapSelect();
      return copy;
    }

    function pushUndo(m) {
      if (!m || m._seed) return;
      state.undoStack.push({
        mapId: m.id,
        nodes: JSON.parse(JSON.stringify(m.nodes || [])),
        edges: JSON.parse(JSON.stringify(m.edges || [])),
      });
      if (state.undoStack.length > 30) state.undoStack.shift();
      syncUndoBtn();
    }

    function performUndo() {
      if (!state.undoStack.length) return;
      const snap = state.undoStack.pop();
      syncUndoBtn();
      const targetIdx = state.maps.findIndex(x => x.id === snap.mapId);
      if (targetIdx >= 0) state.idx = targetIdx;
      const m = curMap();
      if (!m || m._seed) return;
      m.nodes = snap.nodes;
      m.edges = snap.edges;
      state.selectedEdgeIdx = null;
      closePopover();
      persistMaps();
      drawAll();
      api.toast('↶ Đã hoàn tác thao tác vừa rồi!');
    }

    function deleteEdgeAt(edgeIdx) {
      if (state.locked) {
        api.toast('Đang bật khóa sửa — hãy mở khóa ở thanh trên trước');
        return;
      }
      const m = cloneSeedIfNeeded();
      if (!m || !Array.isArray(m.edges) || !m.edges[edgeIdx]) return;
      pushUndo(m);
      const removed = m.edges.splice(edgeIdx, 1)[0];
      state.selectedEdgeIdx = null;
      closePopover();
      persistMaps();
      drawCanvas();
      api.toast(`🗑 Đã xóa dây nối${removed && removed.label ? ' "' + removed.label + '"' : ''} • Bấm ↶ Hoàn tác (Ctrl+Z) nếu xóa nhầm`);
    }

    // Tự động chuyển từ bản mẫu sang Sơ đồ riêng của Deck ngay khi thao tác
    function ensureEditableMap() {
      const m = curMap();
      if (!m) return null;
      if (!m._seed) return m;
      const dk = curDeck();
      const mapName = dk ? `Combo: ${dk.name}` : 'Sơ đồ Combo mới';
      const fresh = {
        id: 'm' + Date.now(),
        name_vi: mapName,
        name_en: mapName,
        deckId: dk ? dk.id : '',
        nodes: [],
        edges: [],
      };
      state.maps.push(fresh);
      state.idx = state.maps.length - 1;
      state.selectedNodeId = null;
      state.locked = false;
      syncLockBtn();
      persistMaps();
      refreshMapSelect();
      api.toast(`Đã tạo sơ đồ "${mapName}" để bắt đầu dựng combo!`);
      return fresh;
    }

    function resolveCardRecord(item) {
      const cid = entryId(item);
      if (cid && byId.has(cid)) return byId.get(cid);
      const nm = entryName(item).trim().toLowerCase();
      if (nm && byName.has(nm)) return byName.get(nm);
      return null;
    }

    function makeCardEntry(card, spec) {
      if (!card) return null;
      const cleanSpec = spec || (ART ? ART.getDefaultSpec(card.id) : null);
      return cleanSpec
        ? { id: card.id, name: card.name, spec: { ...cleanSpec } }
        : { id: card.id, name: card.name };
    }

    function renderActionPills() {
      const wrap = $('#cmPresets');
      $('#cmCusCnt').textContent = String(customActs.length);
      $('#cmActTabs').querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.grp === state.actGroup));

      let list = [];
      if (state.actGroup === 'custom') {
        list = customActs.map((it, idx) => ({ ...it, _cusIdx: idx }));
      } else {
        list = (ACTION_GROUPS[state.actGroup] && ACTION_GROUPS[state.actGroup].items) || [];
      }

      if (!list.length) {
        wrap.innerHTML = '<span class="hint">Chưa có nhãn tự lưu nào — hãy gõ nhãn bất kỳ vào ô bên phải rồi bấm <b>+ Lưu mẫu</b>!</span>';
        return;
      }

      wrap.innerHTML = list.map((p, i) => {
        const active = state.actionLabel === p.label && state.actionKind === (p.kind || 'normal');
        const kindCls = p.kind === 'handtrap' ? ' is-ht' : (p.kind === 'pivot' ? ' is-pivot' : (p.kind === 'counter' || p.kind === 'converge' ? ' is-cnt' : ''));
        const delHtml = p._cusIdx != null ? `<span class="cpill-del" data-del="${p._cusIdx}" title="Xóa mẫu này">×</span>` : '';
        return `<button type="button" class="cmap-pill${kindCls}${active ? ' active' : ''}" data-idx="${i}">${esc(p.label)}${p.sub ? ` <small style="opacity:.75">(${esc(p.sub)})</small>` : ''}${delHtml}</button>`;
      }).join('');

      wrap.querySelectorAll('.cmap-pill').forEach(btn => {
        btn.onclick = e => {
          const del = e.target.closest('.cpill-del');
          if (del) {
            e.stopPropagation();
            customActs.splice(Number(del.dataset.del), 1);
            saveCustomActs(customActs);
            renderActionPills();
            return;
          }
          const item = list[Number(btn.dataset.idx)];
          if (!item) return;
          state.actionLabel = item.label;
          state.actionKind = item.kind || 'normal';
          state.actionHtCard = item.htCard || '';
          if (item.sub !== undefined) {
            state.actionSub = item.sub || '';
            $('#cmCustomSub').value = state.actionSub;
          }
          $('#cmCustomAct').value = state.actionLabel;
          $('#cmActKind').value = state.actionKind;
          renderActionPills();
        };
      });
    }

    function countStarters(m) {
      if (!m || !Array.isArray(m.nodes)) return 0;
      return m.nodes.filter(n => n.role === 'starter' || !(m.edges || []).some(e => e.to === n.id)).length;
    }

    function buildStarterOwnershipMap(m) {
      const ownerOf = {};
      if (!m || !Array.isArray(m.nodes) || !m.nodes.length) return ownerOf;
      const byNodeId = Object.fromEntries(m.nodes.map(n => [n.id, n]));
      const firstParentOf = {};
      (m.edges || []).forEach(e => {
        if (byNodeId[e.from] && byNodeId[e.to] && !firstParentOf[e.to] && e.from !== e.to) {
          firstParentOf[e.to] = e.from;
        }
      });

      const starters = m.nodes.filter(n => n.role === 'starter' || !firstParentOf[n.id]);
      const validStarterIds = new Set(starters.map(s => s.id));

      m.nodes.forEach(n => {
        if (n.role === 'starter') {
          ownerOf[n.id] = n.id;
          return;
        }
        if (n.starterId && validStarterIds.has(n.starterId)) {
          ownerOf[n.id] = n.starterId;
          return;
        }
        let cur = n.id;
        const seen = new Set([cur]);
        while (firstParentOf[cur] && !seen.has(firstParentOf[cur])) {
          cur = firstParentOf[cur];
          seen.add(cur);
          if (byNodeId[cur] && byNodeId[cur].role === 'starter') break;
        }
        ownerOf[n.id] = cur;
      });

      return ownerOf;
    }

    function findOwnerStarterId(m, nodeId) {
      if (!m || !nodeId) return null;
      const n = (m.nodes || []).find(x => x.id === nodeId);
      if (n && n.role === 'starter') return n.id;
      const ownerOf = buildStarterOwnershipMap(m);
      return ownerOf[nodeId] || nodeId;
    }

    function nextStepNumForStarter(m, parentNode) {
      if (!m || !parentNode) return 1;
      const ownerOf = buildStarterOwnershipMap(m);
      const ownerId = parentNode.role === 'starter' ? parentNode.id : (ownerOf[parentNode.id] || parentNode.id);
      const stepsInStarter = (m.nodes || []).filter(n =>
        n.id !== ownerId &&
        n.role !== 'starter' &&
        n.role !== 'planb' &&
        ownerOf[n.id] === ownerId
      );
      if (!stepsInStarter.length) return 1;
      let maxB = 0;
      stepsInStarter.forEach(s => {
        const mB = String(s.title || '').match(/^B(\d+):/i);
        if (mB) maxB = Math.max(maxB, Number(mB[1]));
      });
      return Math.max(stepsInStarter.length + 1, maxB + 1);
    }

    // Tự động chuẩn hóa lại số thứ tự B1, B2, B3... riêng cho từng chuỗi Starter (sửa cả các bước B38 cũ đã lưu)
    function normalizeStarterStepNumbers(m) {
      if (!m || !Array.isArray(m.nodes) || !m.nodes.length) return false;
      const ownerOf = buildStarterOwnershipMap(m);
      const byStarter = {};
      m.nodes.forEach(n => {
        const stId = ownerOf[n.id];
        if (!stId) return;
        n.starterId = stId;
        if (n.id === stId || n.role === 'starter') return;
        if (/^B\d+:\s*/i.test(String(n.title || ''))) {
          (byStarter[stId] = byStarter[stId] || []).push(n);
        }
      });

      let changed = false;
      Object.values(byStarter).forEach(stepArr => {
        if (!stepArr.length) return;
        const sorted = stepArr.slice().sort((a, b) => {
          const ma = String(a.title || '').match(/^B(\d+):/i);
          const mb = String(b.title || '').match(/^B(\d+):/i);
          const na = ma ? Number(ma[1]) : 9999;
          const nb = mb ? Number(mb[1]) : 9999;
          if (na !== nb) return na - nb;
          return (a.x || 0) - (b.x || 0);
        });
        const needsFix = sorted.some((n, i) => {
          const mNum = String(n.title || '').match(/^B(\d+):/i);
          return !mNum || Number(mNum[1]) !== i + 1;
        });
        if (needsFix) {
          sorted.forEach((n, i) => {
            const nextTitle = String(n.title || '').replace(/^B\d+:\s*/i, `B${i + 1}: `);
            if (nextTitle !== n.title) {
              n.title = nextTitle;
              changed = true;
            }
          });
        }
      });
      return changed;
    }

    function nextBottomLaneY(m) {
      if (!m || !m.nodes.length) return 32;
      const maxBottom = Math.max(...m.nodes.map(n => (n.y || 0) + nodeHeight(n)));
      return maxBottom + GAP_Y + 6;
    }

    function inferActionForCard(card) {
      if (state.pendingBranch) {
        const pb = state.pendingBranch;
        return {
          edge: pb.label,
          sub: pb.sub || '',
          kind: pb.kind || 'handtrap',
          htCard: pb.htCard || '',
          title: 'Phương án B: ' + card.name.slice(0, 16),
          nodeRole: 'planb',
        };
      }
      const chosen = ($('#cmCustomAct').value || state.actionLabel || '').trim();
      const sub = ($('#cmCustomSub').value || '').trim();
      const kind = $('#cmActKind').value || state.actionKind || 'normal';
      const htCard = state.actionHtCard || '';

      if (card && isExtraCard(card) && chosen === 'Special Summon' && kind === 'normal') {
        if (/Fusion/i.test(card.type)) return { edge: 'Fusion Summon', sub, kind, htCard: '', title: 'Fusion Summon', nodeRole: 'step' };
        if (/Synchro/i.test(card.type)) return { edge: 'Synchro Summon', sub, kind, htCard: '', title: 'Synchro Summon', nodeRole: 'step' };
        if (/XYZ/i.test(card.type)) return { edge: 'Xyz Summon', sub, kind, htCard: '', title: 'Xyz Summon', nodeRole: 'step' };
        if (/Link/i.test(card.type)) return { edge: 'Link Summon', sub, kind, htCard: '', title: 'Link Summon', nodeRole: 'step' };
      }

      const nodeRole = kind === 'handtrap' || kind === 'pivot' ? 'planb' : (kind === 'endboard' ? 'endboard' : 'step');
      return {
        edge: chosen,
        sub,
        kind,
        htCard,
        title: chosen || 'Bước tiếp theo',
        nodeRole,
      };
    }

    function addCardToCombo(card, spec, opts) {
      if (!card) return;
      if (state.locked) {
        api.toast('Đang bật khóa sửa — bấm "🔒 Đang khóa sửa" ở thanh trên để mở khóa');
        return;
      }
      closePopover();
      const o = opts || {};
      const m = ensureEditableMap();
      if (!m) return;
      pushUndo(m);
      if (state.deckId) m.deckId = state.deckId;

      const entry = makeCardEntry(card, spec);
      const intoNodeId = o.intoNodeId || (state.addMode === 'into' && !state.pendingBranch ? state.selectedNodeId : null);

      // 1. Gộp chung lá bài vào nút đang chọn
      if (intoNodeId) {
        const targetNode = m.nodes.find(n => n.id === intoNodeId);
        if (targetNode) {
          targetNode.cards = targetNode.cards || [];
          targetNode.cards.push(entry);
          state.selectedNodeId = targetNode.id;
          persistMaps();
          drawAll();
          return;
        }
      }

      // 2. Tạo chuỗi Starter mới xếp ở hàng bên dưới (Multi-Starter!)
      const isStarterMode = o.asStarter || (!state.pendingBranch && state.addMode === 'starter') || (!state.pendingBranch && !state.selectedNodeId);
      const nid = 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);

      if (isStarterMode) {
        const stIdx = countStarters(m) + 1;
        const nx = o.x != null ? o.x : 84;
        const ny = o.y != null ? o.y : nextBottomLaneY(m);
        const starterNode = {
          id: nid,
          role: 'starter',
          starterId: nid,
          title: `Starter ${stIdx}: ${card.name.slice(0, 18)}`,
          cards: [entry],
          x: Math.round(nx),
          y: Math.round(ny),
        };
        m.nodes.push(starterNode);
        state.selectedNodeId = nid;
        // Nếu người chơi bấm từ nút nhanh "🌟 + Chuỗi Starter dưới" (chứ không khóa cố định tab Starter mới) thì tự chuyển sang Nối bước tiếp để bấm mạch ngang luôn!
        if (o.autoSwitchToStep) {
          state.addMode = 'step';
          syncAddModeBtns();
        }
        persistMaps();
        drawAll();
        return;
      }

      // 3. Tạo bước nối tiếp hoặc nhánh chữa cháy Handtrap từ parentNode (mỗi Starter bắt đầu đếm từ B1, B2, B3...)
      const fromId = state.pendingBranch ? state.pendingBranch.fromId : state.selectedNodeId;
      const parentNode = fromId ? m.nodes.find(n => n.id === fromId) : null;
      const info = inferActionForCard(card);
      const ownerStId = parentNode ? findOwnerStarterId(m, parentNode.id) : nid;
      const stepNum = nextStepNumForStarter(m, parentNode);

      let nx = o.x, ny = o.y;
      if (nx == null || ny == null) {
        if (parentNode && parentNode.x != null) {
          const siblings = m.edges.filter(e => e.from === parentNode.id)
            .map(e => m.nodes.find(nn => nn.id === e.to))
            .filter(Boolean);
          nx = parentNode.x + NODE_W + GAP_X;
          if (!siblings.length && info.kind !== 'handtrap' && info.kind !== 'pivot') {
            ny = parentNode.y;
          } else {
            const baseBottom = siblings.length
              ? Math.max(...siblings.map(s => (s.y || 0) + nodeHeight(s)))
              : (parentNode.y || 0) + nodeHeight(parentNode);
            ny = baseBottom + 34;
          }
        } else {
          nx = 84;
          ny = nextBottomLaneY(m);
        }
      }

      const newNode = {
        id: nid,
        role: info.nodeRole || 'step',
        starterId: ownerStId,
        title: info.nodeRole === 'planb' ? info.title : `B${stepNum}: ${info.title}`,
        cards: [entry],
        x: Math.round(nx),
        y: Math.round(ny),
      };
      m.nodes.push(newNode);
      if (parentNode) {
        const edgeObj = { from: parentNode.id, to: nid, label: info.edge, kind: info.kind };
        if (info.sub) edgeObj.sub = info.sub;
        if (info.htCard) edgeObj.htCard = info.htCard;
        m.edges.push(edgeObj);
      }

      state.pendingBranch = null;
      state.selectedNodeId = nid;
      persistMaps();
      drawAll();
    }

    // Hộp chỉnh sửa trực tiếp Mũi tên nối tiếp ngay trên sơ đồ (Inline Edge Popover)
    function openEdgePopover(edgeIdx, anchorX, anchorY) {
      if (state.locked) return;
      const m = cloneSeedIfNeeded();
      if (!m || !m.edges[edgeIdx]) return;
      state.selectedEdgeIdx = edgeIdx;
      const edge = m.edges[edgeIdx];
      const grpIdxs = getMergeGroupIndices(m, edgeIdx);
      const isMerged = grpIdxs.length > 1;
      const byNodeId = Object.fromEntries((m.nodes || []).map(nn => [nn.id, nn]));

      const compatibleOthers = [];
      m.edges.forEach((oe, oi) => {
        if (grpIdxs.includes(oi)) return;
        if (oe.to === edge.to || oe.from === edge.from) {
          const sameTo = oe.to === edge.to;
          const peerNode = byNodeId[sameTo ? oe.from : oe.to];
          const peerName = peerNode ? (peerNode.title || 'Bước khác') : (sameTo ? oe.from : oe.to);
          compatibleOthers.push({
            idx: oi,
            sameTo,
            desc: `${oe.label || 'Dây nối'} (${sameTo ? 'từ ' : 'tới '}${peerName})`,
          });
        }
      });

      const wrapRect = $('#mapWrap').getBoundingClientRect();
      const left = Math.min(Math.max(12, anchorX - wrapRect.left - 170), Math.max(12, wrapRect.width - 366));
      const top = Math.max(12, anchorY - wrapRect.top + 14);

      const mergeSectionHtml = (isMerged || compatibleOthers.length)
        ? `<div class="cm-pop-row" style="background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.28);border-radius:10px;padding:7px 9px">
             <label style="color:#fde68a">🔀 Hợp nhất / Tách nhánh dây:</label>
             <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:3px">
               ${isMerged ? `<button type="button" class="cmap-pill mini is-pivot" id="epUnmerge">⛓️‍💥 Tách riêng ${grpIdxs.length} dây đang gộp</button>` : ''}
               ${compatibleOthers.map(co => `<button type="button" class="cmap-pill mini is-pivot" data-merge-idx="${co.idx}">🔀 Gộp với: ${esc(co.desc)}</button>`).join('')}
               ${compatibleOthers.filter(c => c.sameTo).length >= 2 ? `<button type="button" class="cmap-pill mini active" id="epMergeAllTo">🔀 Gộp tất cả dây cùng vào bước này</button>` : ''}
             </div>
           </div>`
        : '';

      const quickChips = [
        { label: 'Normal Summon', kind: 'normal' },
        { label: 'Special Summon', kind: 'normal' },
        { label: 'Kích hiệu ứng', kind: 'normal' },
        { label: 'Search lên tay', kind: 'normal' },
        { label: 'Gửi xuống Mộ', kind: 'normal' },
        { label: 'Trục xuất', kind: 'normal' },
        { label: 'Fusion Summon', kind: 'normal' },
        { label: 'Synchro Summon', kind: 'normal' },
        { label: 'Xyz Summon', kind: 'normal' },
        { label: 'Link Summon', kind: 'normal' },
        { label: 'Đổi sang Starter dưới', kind: 'pivot' },
        { label: 'Hội tụ về nhánh chính', kind: 'converge' },
        { label: 'Sân cuối / End Board', kind: 'endboard' },
      ];

      popHost.innerHTML = `
        <div class="cm-popover" style="left:${left}px;top:${top}px" onclick="event.stopPropagation()">
          <div class="cm-pop-hdr">
            <b>✏️ ${isMerged ? `Chỉnh sửa nhánh hợp nhất (${grpIdxs.length} dây)` : 'Chỉnh sửa dây nối'}</b>
            <div style="display:inline-flex;gap:5px;align-items:center">
              <button type="button" class="small danger" id="epDelTop" style="padding:3px 9px;font-size:11.5px" title="Xóa ${isMerged ? 'nhánh hợp nhất' : 'sợi dây nối'} này (Phím Delete)">🗑 Xóa dây</button>
              <button type="button" class="mnbtn" id="epClose">✕</button>
            </div>
          </div>
          ${mergeSectionHtml}
          <div class="cm-pop-row">
            <label>Nhãn hành động / Tình huống chính:</label>
            <input id="epLabel" value="${esc(edge.label || '')}" placeholder="vd: Search lên tay, Dính Ash Blossom...">
          </div>
          <div class="cm-pop-row">
            <label>Chi tiết phụ (Cost, điều kiện, CL1/CL2, ghi chú ngắn):</label>
            <input id="epSub" value="${esc(edge.sub || '')}" placeholder="vd: Bỏ 1 lá trên tay • Đổi sang Starter 2...">
          </div>
          <div class="cm-pop-row">
            <label>Loại nhánh / Màu hiển thị:</label>
            <select id="epKind">
              ${Object.entries(EDGE_KINDS).map(([k, v]) => `<option value="${k}" ${(edge.kind || 'normal') === k ? 'selected' : ''}>${esc(v.label)}</option>`).join('')}
            </select>
          </div>
          <div class="cm-pop-row">
            <label>Kiểu dáng dây &amp; Cổng nối (hoặc nắm kéo dây trực tiếp trên sơ đồ):</label>
            <select id="epRoute">
              ${Object.entries(EDGE_ROUTES).map(([k, lbl]) => `<option value="${k}" ${(edge.route || 'curve') === k ? 'selected' : ''}>${esc(lbl)}</option>`).join('')}
            </select>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:4px">
              <select id="epFromPort" title="Cổng xuất phát">
                ${Object.entries(PORT_SIDES).map(([k, lbl]) => `<option value="${k}" ${(edge.fromPort || 'auto') === k ? 'selected' : ''}>Đi từ: ${esc(lbl)}</option>`).join('')}
              </select>
              <select id="epToPort" title="Cổng đích">
                ${Object.entries(PORT_SIDES).map(([k, lbl]) => `<option value="${k}" ${(edge.toPort || 'auto') === k ? 'selected' : ''}>Vào: ${esc(lbl)}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="cm-pop-row">
            <label>Chọn nhanh hành động:</label>
            <div class="cm-pop-chips" id="epQuick">
              ${quickChips.map((q, idx) => `<button type="button" class="cmap-pill mini" data-qi="${idx}">${esc(q.label)}</button>`).join('')}
            </div>
          </div>
          <div class="cm-pop-row">
            <label>🛑 Hoặc gắn lá Handtrap gây đổi hướng lên mũi tên:</label>
            <div class="cm-ht-strip" id="epHtStrip">
              <button type="button" class="cmap-pill mini ${!edge.htCard ? 'active' : ''}" data-ht="">Không gắn</button>
              ${HANDTRAP_CARDS.map((h, idx) => `<button type="button" class="cmap-pill mini is-ht ${edge.htCard === h.name ? 'active' : ''}" data-hi="${idx}">${esc(h.label)}</button>`).join('')}
            </div>
          </div>
          <div class="row" style="margin:8px 0 0;justify-content:space-between">
            <div style="display:flex;gap:5px">
              <button type="button" class="small danger" id="epDel" title="Xóa sợi dây nối này">🗑 Xóa dây</button>
              <button type="button" class="small" id="epFlip" title="Đảo ngược chiều mũi tên A ↔ B">⇄ Đảo chiều</button>
              <button type="button" class="small" id="epResetBend" title="Đặt lại độ uốn mặc định của dây">↺ Dáng chuẩn</button>
            </div>
            <div style="display:flex;gap:6px">
              <button type="button" class="small" id="epCancel">Đóng</button>
              <button type="button" class="small primary" id="epSave">💾 Lưu</button>
            </div>
          </div>
        </div>`;
      clampPopoverInWrap();

      let pickedHt = edge.htCard || '';
      const commit = () => {
        pushUndo(m);
        const newLab = $('#epLabel').value.trim();
        const newSub = $('#epSub').value.trim();
        const newKind = $('#epKind').value || 'normal';
        const newRoute = $('#epRoute').value || 'curve';
        const fp = $('#epFromPort').value || 'auto';
        const tp = $('#epToPort').value || 'auto';
        grpIdxs.forEach(gi => {
          const ge = m.edges[gi];
          if (!ge) return;
          ge.label = newLab;
          ge.sub = newSub;
          ge.kind = newKind;
          ge.route = newRoute;
          if (!isMerged || ge === edge) {
            if (fp === 'auto') delete ge.fromPort; else ge.fromPort = fp;
          }
          if (tp === 'auto') delete ge.toPort; else ge.toPort = tp;
          if (pickedHt) ge.htCard = pickedHt;
          else delete ge.htCard;
        });
        state.selectedEdgeIdx = null;
        closePopover();
        persistMaps();
        drawCanvas();
      };

      const dismiss = () => {
        state.selectedEdgeIdx = null;
        closePopover();
        drawEdges();
      };

      $('#epClose').onclick = dismiss;
      $('#epCancel').onclick = dismiss;
      $('#epSave').onclick = commit;
      $('#epLabel').onkeydown = e => { if (e.key === 'Enter') commit(); };
      $('#epSub').onkeydown = e => { if (e.key === 'Enter') commit(); };
      $('#epRoute').onchange = e => {
        if (e.target.value === 'loop-left') { $('#epFromPort').value = 'left'; $('#epToPort').value = 'left'; }
        else if (e.target.value === 'loop-right') { $('#epFromPort').value = 'right'; $('#epToPort').value = 'right'; }
      };
      $('#epFlip').onclick = () => {
        pushUndo(m);
        grpIdxs.forEach(gi => {
          const ge = m.edges[gi];
          if (!ge) return;
          const tmp = ge.from; ge.from = ge.to; ge.to = tmp;
          const pTmp = ge.fromPort; ge.fromPort = ge.toPort; ge.toPort = pTmp;
        });
        state.selectedEdgeIdx = null;
        persistMaps();
        drawCanvas();
        closePopover();
      };
      $('#epResetBend').onclick = () => {
        pushUndo(m);
        grpIdxs.forEach(gi => {
          const ge = m.edges[gi];
          if (!ge) return;
          delete ge.bendX;
          delete ge.bendY;
          ge.route = 'curve';
          delete ge.fromPort;
          delete ge.toPort;
        });
        state.selectedEdgeIdx = null;
        persistMaps();
        drawCanvas();
        closePopover();
      };

      if ($('#epUnmerge')) {
        $('#epUnmerge').onclick = () => unmergeGroup(edge.mergeId);
      }
      popHost.querySelectorAll('[data-merge-idx]').forEach(mb => {
        mb.onclick = () => mergeTwoEdges(edgeIdx, Number(mb.dataset.mergeIdx));
      });
      if ($('#epMergeAllTo')) {
        $('#epMergeAllTo').onclick = () => {
          pushUndo(m);
          const sameToIdxs = m.edges.map((oe, oi) => oe.to === edge.to ? oi : -1).filter(oi => oi >= 0 && oi !== edgeIdx);
          let curTarget = edgeIdx;
          sameToIdxs.forEach(oi => {
            mergeTwoEdges(oi, curTarget, { skipUndo: true });
            curTarget = m.edges.findIndex(x => x.to === edge.to && x.mergeId);
            if (curTarget < 0) curTarget = 0;
          });
        };
      }

      $('#epQuick').querySelectorAll('button').forEach(b => {
        b.onclick = () => {
          const q = quickChips[Number(b.dataset.qi)];
          $('#epLabel').value = q.label;
          $('#epKind').value = q.kind;
        };
      });

      $('#epHtStrip').querySelectorAll('button').forEach(b => {
        b.onclick = () => {
          if (b.dataset.ht === '') {
            pickedHt = '';
          } else {
            const h = HANDTRAP_CARDS[Number(b.dataset.hi)];
            pickedHt = h.name;
            $('#epLabel').value = h.edgeText;
            $('#epKind').value = 'handtrap';
          }
          $('#epHtStrip').querySelectorAll('button').forEach(x => x.classList.toggle('active', x === b));
        };
      });

      const doDel = () => isMerged ? deleteMergeGroup(edge.mergeId) : deleteEdgeAt(edgeIdx);
      $('#epDelTop').onclick = doDel;
      $('#epDel').onclick = doDel;
      setTimeout(() => { if ($('#epLabel')) $('#epLabel').focus(); }, 20);
    }

    // Hộp rẽ nhánh nhanh khi một bước trong chuỗi Starter bị dính Handtrap (nhảy sang chuỗi Starter dưới hoặc tạo nhánh Plan B)
    function openHandtrapPivotPopover(sourceNode, anchorX, anchorY) {
      if (!sourceNode || state.locked) return;
      const m = cloneSeedIfNeeded();
      if (!m) return;
      const wrapRect = $('#mapWrap').getBoundingClientRect();
      const left = Math.min(Math.max(12, anchorX - wrapRect.left - 140), Math.max(12, wrapRect.width - 370));
      const top = Math.max(12, anchorY - wrapRect.top + 12);

      const otherNodes = m.nodes.filter(n => n.id !== sourceNode.id);
      const starterTargets = otherNodes.filter(n => n.role === 'starter');
      const stepTargets = otherNodes.filter(n => n.role !== 'starter');

      popHost.innerHTML = `
        <div class="cm-popover" style="left:${left}px;top:${top}px" onclick="event.stopPropagation()">
          <div class="cm-pop-hdr">
            <b>⚡ Khi "${esc(sourceNode.title || 'Bước này')}" bị dính Handtrap:</b>
            <button type="button" class="mnbtn" id="hpClose">✕</button>
          </div>
          <div class="cm-pop-row">
            <label>1. Chọn Handtrap / Tình huống bị chặn:</label>
            <div class="cm-ht-strip" id="hpHtList">
              ${HANDTRAP_CARDS.map((h, idx) => `<button type="button" class="cmap-pill mini is-ht ${idx === 0 ? 'active' : ''}" data-hi="${idx}">${esc(h.label)}</button>`).join('')}
              <button type="button" class="cmap-pill mini is-pivot" data-hi="-1">Bị Negate bất kỳ</button>
            </div>
          </div>
          <div class="cm-pop-row">
            <label>Ghi chú xử lý (tùy chọn):</label>
            <input id="hpSub" value="Đổi sang phương án khác" placeholder="vd: Nhảy tiếp Extender trên tay / Chuyển qua Starter 2...">
          </div>
          <div class="cm-pop-row">
            <label>2. Chọn hướng đi tiếp theo:</label>
            <button type="button" class="small primary" id="hpNewBranch" style="width:100%;text-align:left;padding:7px 12px;border-radius:10px">
              ➕ Bấm lá bài trong Deck để tạo <b>Nhánh chữa cháy (Plan B)</b> ở hàng dưới
            </button>
          </div>
          ${starterTargets.length ? `
          <div class="cm-pop-row">
            <label>↪️ Hoặc chuyển thẳng sang <b>Chuỗi Starter khác bên dưới</b> đã có:</label>
            <div class="cm-target-list" id="hpStarters">
              ${starterTargets.map(t => `<button type="button" class="cm-target-btn" data-tid="${esc(t.id)}">🌟 ${esc(t.title)} <span class="muted">(${(t.cards || []).map(entryName).join(', ')})</span></button>`).join('')}
            </div>
          </div>` : ''}
          ${stepTargets.length ? `
          <div class="cm-pop-row">
            <label>🔗 Hoặc nối vào một bước có sẵn khác trên sơ đồ:</label>
            <div class="cm-target-list" id="hpSteps">
              ${stepTargets.map(t => `<button type="button" class="cm-target-btn" data-tid="${esc(t.id)}">🔹 ${esc(t.title)}</button>`).join('')}
            </div>
          </div>` : ''}
        </div>`;
      clampPopoverInWrap();

      let selectedHi = 0;
      $('#hpClose').onclick = closePopover;
      $('#hpHtList').querySelectorAll('button').forEach(b => {
        b.onclick = () => {
          selectedHi = Number(b.dataset.hi);
          $('#hpHtList').querySelectorAll('button').forEach(x => x.classList.toggle('active', x === b));
        };
      });

      const getBranchMeta = () => {
        const h = selectedHi >= 0 ? HANDTRAP_CARDS[selectedHi] : null;
        return {
          label: h ? h.edgeText : 'Bị Negate / Cản',
          sub: $('#hpSub').value.trim(),
          kind: 'handtrap',
          htCard: h ? h.name : '',
        };
      };

      $('#hpNewBranch').onclick = () => {
        const meta = getBranchMeta();
        state.pendingBranch = { fromId: sourceNode.id, ...meta };
        state.selectedNodeId = sourceNode.id;
        state.addMode = 'step';
        syncAddModeBtns();
        closePopover();
        drawCanvas();
        api.toast(`⚡ Hãy bấm vào lá bài chữa cháy ở cột Deck bên trái để tạo nhánh vượt "${meta.label}"!`);
      };

      popHost.querySelectorAll('[data-tid]').forEach(btn => {
        btn.onclick = () => {
          const meta = getBranchMeta();
          const targetId = btn.dataset.tid;
          pushUndo(m);
          m.edges.push({
            from: sourceNode.id,
            to: targetId,
            label: meta.label,
            sub: meta.sub,
            kind: 'handtrap',
            ...(meta.htCard ? { htCard: meta.htCard } : {}),
          });
          state.selectedNodeId = targetId;
          closePopover();
          persistMaps();
          drawCanvas();
          api.toast('⚡ Đã nối phương án chuyển hướng khi dính Handtrap!');
        };
      });
    }

    // Hộp chỉnh sửa trực tiếp Tiêu đề, Vai trò (Starter / Plan B / Sân cuối) & Ghi chú của Nút (không dùng prompt!)
    function openNodePopover(node, anchorX, anchorY) {
      if (!node || state.locked) return;
      const m = cloneSeedIfNeeded();
      if (!m) return;
      const realNode = m.nodes.find(x => x.id === node.id) || node;
      const wrapRect = $('#mapWrap').getBoundingClientRect();
      const left = Math.min(Math.max(12, anchorX - wrapRect.left - 120), Math.max(12, wrapRect.width - 330));
      const top = Math.max(12, anchorY - wrapRect.top + 12);

      popHost.innerHTML = `
        <div class="cm-popover" style="left:${left}px;top:${top}px;width:310px" onclick="event.stopPropagation()">
          <div class="cm-pop-hdr">
            <b>⚙️ Chỉnh sửa nút bước combo</b>
            <button type="button" class="mnbtn" id="npClose">✕</button>
          </div>
          <div class="cm-pop-row">
            <label>Tiêu đề nút (vd: Starter 2, B2: Search, Sân cuối):</label>
            <input id="npTitle" value="${esc(realNode.title || '')}">
          </div>
          <div class="cm-pop-row">
            <label>Vai trò nút trên sơ đồ:</label>
            <select id="npRole">
              ${Object.entries(NODE_ROLES).map(([k, v]) => `<option value="${k}" ${(realNode.role || 'step') === k ? 'selected' : ''}>${esc(v.label)}</option>`).join('')}
            </select>
          </div>
          <div class="cm-pop-row">
            <label>Ghi chú chi tiết tại bước này:</label>
            <input id="npNote" value="${esc(realNode.note || '')}" placeholder="vd: Còn lượt Normal Summon • Cần 1 bài mồi...">
          </div>
          <div class="row" style="margin:8px 0 0;justify-content:flex-end">
            <button type="button" class="small" id="npCancel">Hủy</button>
            <button type="button" class="small primary" id="npSave">💾 Lưu</button>
          </div>
        </div>`;
      clampPopoverInWrap();

      const saveNode = () => {
        pushUndo(m);
        realNode.title = $('#npTitle').value.trim() || 'Bước combo';
        realNode.role = $('#npRole').value || 'step';
        realNode.note = $('#npNote').value.trim();
        closePopover();
        persistMaps();
        drawCanvas();
      };
      $('#npClose').onclick = closePopover;
      $('#npCancel').onclick = closePopover;
      $('#npSave').onclick = saveNode;
      $('#npTitle').onkeydown = e => { if (e.key === 'Enter') saveNode(); };
      $('#npNote').onkeydown = e => { if (e.key === 'Enter') saveNode(); };
      setTimeout(() => { if ($('#npTitle')) { $('#npTitle').focus(); $('#npTitle').select(); } }, 20);
    }

    function refreshMapSelect() {
      const sel = $('#mapSel');
      sel.innerHTML = state.maps.map((m, i) => {
        const stCnt = countStarters(m);
        const tag = m._seed ? ' [Mẫu]' : ` (${stCnt} Starter • ${(m.nodes || []).length} nút)`;
        return `<option value="${i}" ${i === state.idx ? 'selected' : ''}>${esc((m.name_vi || m.name_en || ('Sơ đồ #' + (i + 1))) + tag)}</option>`;
      }).join('');
    }

    function refreshDeckSelect() {
      decks = loadBuiltDecks();
      if (state.deckId && !decks.some(d => d.id === state.deckId)) {
        state.deckId = decks[0] ? decks[0].id : '';
      } else if (!state.deckId && decks.length) {
        state.deckId = decks[0].id;
      }
      const sel = $('#cmDeckSel');
      if (!decks.length) {
        sel.innerHTML = '<option value="">-- Chưa có Deck nào (Hãy nạp .ydk hoặc vào Xây deck) --</option>';
      } else {
        sel.innerHTML = decks.map(d =>
          `<option value="${esc(d.id)}" ${d.id === state.deckId ? 'selected' : ''}>${esc(d.name)} (${(d.main || []).length}/${(d.extra || []).length}/${(d.side || []).length})</option>`
        ).join('');
      }
    }

    function countUsedInMap() {
      const m = curMap();
      const used = new Map();
      if (!m || !Array.isArray(m.nodes)) return used;
      m.nodes.forEach(n => {
        (n.cards || []).forEach(it => {
          const c = resolveCardRecord(it);
          if (c) used.set(c.id, (used.get(c.id) || 0) + 1);
        });
      });
      return used;
    }

    function renderDeckTray() {
      const dk = curDeck();
      const tabsEl = $('#cmZoneTabs');
      const gridEl = $('#cmDeckCards');

      if (!dk) {
        tabsEl.innerHTML = '';
        gridEl.innerHTML = `<div class="muted" style="padding:12px;text-align:center;font-size:13px">
          Chưa có Deck nào được chọn.<br>Bấm <b>📂 Nạp file .ydk</b> ở trên hoặc sang tab <b>Xây deck</b> để tạo bộ bài!
        </div>`;
        return;
      }

      const counts = {
        all: (dk.main || []).length + (dk.extra || []).length + (dk.side || []).length,
        main: (dk.main || []).length,
        extra: (dk.extra || []).length,
        side: (dk.side || []).length,
      };
      tabsEl.innerHTML = [
        ['all', `Tất cả (${counts.all})`],
        ['main', `Main (${counts.main})`],
        ['extra', `Extra (${counts.extra})`],
        ['side', `Side (${counts.side})`],
      ].map(([z, lbl]) => `<button type="button" class="${state.zoneTab === z ? 'active' : ''}" data-z="${z}">${lbl}</button>`).join('');
      tabsEl.querySelectorAll('button').forEach(b => {
        b.onclick = () => { state.zoneTab = b.dataset.z; renderDeckTray(); };
      });

      const rawSlots = state.zoneTab === 'all'
        ? [
          ...(dk.main || []).map(x => ({ x, z: 'main' })),
          ...(dk.extra || []).map(x => ({ x, z: 'extra' })),
          ...(dk.side || []).map(x => ({ x, z: 'side' })),
        ]
        : (dk[state.zoneTab] || []).map(x => ({ x, z: state.zoneTab }));

      const groups = new Map();
      rawSlots.forEach(({ x, z }) => {
        const c = byId.get(slotId(x));
        if (!c) return;
        const sp = slotSpec(x);
        const key = c.id + '::' + (sp ? JSON.stringify(sp) : '');
        if (!groups.has(key)) groups.set(key, { card: c, spec: sp, qty: 0, zone: z });
        groups.get(key).qty++;
      });

      const q = state.trayQuery.trim();
      let items = [...groups.values()];
      if (q) {
        if (SMART) {
          const matchedIds = new Set(SMART.searchCards(items.map(g => g.card), q, 'both').items.map(c => c.id));
          items = items.filter(g => matchedIds.has(g.card.id));
        } else {
          const ql = q.toLowerCase();
          items = items.filter(g => g.card.name.toLowerCase().includes(ql));
        }
      }

      gridEl.innerHTML = '';
      if (!items.length) {
        gridEl.innerHTML = `<div class="hint" style="padding:10px">${counts.all === 0 ? 'Deck này đang trống — hãy thêm bài ở tab Xây deck hoặc nạp file .ydk.' : 'Không có lá bài nào khớp bộ lọc.'}</div>`;
        return;
      }

      const usedMap = countUsedInMap();
      items.forEach(({ card: c, spec, qty }) => {
        const tile = document.createElement('div');
        tile.className = 'tile cmap-dk-tile';
        tile.draggable = true;
        tile.title = `${c.name}\n• Bấm trái: thêm vào sơ đồ theo chế độ đang chọn\n• Kéo-thả: thả vào nút hoặc vị trí bất kỳ\n• Chuột phải / 🔍: xem hiệu ứng Anh - Việt`;

        const vis = ART ? ART.renderCardVisual(c, spec, 'sm') : api.cardImg(c.name);
        vis.onclick = null;
        tile.appendChild(vis);

        const zBtn = document.createElement('span');
        zBtn.className = 'tzoom';
        zBtn.textContent = '🔍';
        zBtn.title = 'Xem hiệu ứng Tiếng Anh + Tiếng Việt';
        zBtn.onclick = e => {
          e.stopPropagation();
          if (api.showCard) api.showCard(c.name, spec);
        };
        tile.appendChild(zBtn);

        const usedCnt = usedMap.get(c.id) || 0;
        const badge = document.createElement('span');
        badge.className = 'tb';
        badge.textContent = usedCnt ? `${usedCnt}/${qty}` : `x${qty}`;
        if (usedCnt) badge.style.background = '#059669';
        tile.appendChild(badge);

        tile.onclick = () => addCardToCombo(c, spec);
        tile.oncontextmenu = e => {
          e.preventDefault();
          if (api.showCard) api.showCard(c.name, spec);
        };
        tile.ondragstart = e => {
          e.dataTransfer.setData('application/x-ygo-card', JSON.stringify({ id: c.id, spec: spec || null }));
          e.dataTransfer.effectAllowed = 'copy';
        };
        gridEl.appendChild(tile);
      });
    }

    function updateStatusHeader() {
      const m = curMap();
      const stEl = $('#cmSelStatus');
      const htBtn = $('#cmQuickHt');
      syncCutBtn();
      syncUndoBtn();
      if (!m) { stEl.textContent = ''; htBtn.style.display = 'none'; return; }

      if (state.cutMode) {
        stEl.innerHTML = `<span style="color:#fca5a5">✂️ <b>Chế độ Xóa dây nối</b>: bấm vào bất kỳ sợi dây hoặc nhãn nào để cắt bỏ ngay!</span> <button type="button" class="mnbtn" id="cmExitCut">Thoát (Esc)</button>`;
        htBtn.style.display = 'none';
        const ex = $('#cmExitCut');
        if (ex) ex.onclick = () => { state.cutMode = false; updateStatusHeader(); drawEdges(); };
        return;
      }

      if (state.mergeMode) {
        if (state.mergeFirstIdx != null && m.edges[state.mergeFirstIdx]) {
          const fe = m.edges[state.mergeFirstIdx];
          stEl.innerHTML = `<span style="color:#fde68a">🔀 Đã chọn dây 1 (<b>${esc(fe.label || 'Dây 1')}</b>) → bấm tiếp vào <b>DÂY THỨ 2</b> (cùng đích hoặc cùng gốc) để hợp nhất thành 1 nhánh!</span> <button type="button" class="mnbtn" id="cmExitMerge">Hủy</button>`;
        } else {
          stEl.innerHTML = `<span style="color:#fde68a">🔀 <b>Chế độ Hợp nhất dây</b>: bấm chọn <b>sợi dây thứ 1</b>, rồi bấm <b>sợi dây thứ 2</b> để gộp chung!</span> <button type="button" class="mnbtn" id="cmExitMerge">Thoát (Esc)</button>`;
        }
        htBtn.style.display = 'none';
        const exM = $('#cmExitMerge');
        if (exM) exM.onclick = () => { state.mergeMode = false; state.mergeFirstIdx = null; updateStatusHeader(); drawEdges(); };
        return;
      }

      if (state.pendingBranch) {
        const src = m.nodes.find(n => n.id === state.pendingBranch.fromId);
        stEl.innerHTML = `<span style="color:#fda4af">⚡ Đang tạo nhánh vượt <b>${esc(state.pendingBranch.label)}</b> từ <b>${esc(src ? src.title : '')}</b> → hãy bấm lá bài chữa cháy ở cột Deck!</span> <button type="button" class="mnbtn" id="cmCancelPb">Hủy</button>`;
        htBtn.style.display = 'none';
        const cb = $('#cmCancelPb');
        if (cb) cb.onclick = () => { state.pendingBranch = null; updateStatusHeader(); };
        return;
      }

      if (state.linkFrom) {
        const src = m.nodes.find(n => n.id === state.linkFrom);
        stEl.innerHTML = `<span style="color:#5eead4">🔗 Đang nối dây từ <b>${esc(src ? src.title : state.linkFrom)}</b> → bấm vào bất kỳ nút đích nào (Starter dưới hoặc Sân cuối trên)!</span> <button type="button" class="mnbtn" id="cmCancelLnk">Hủy</button>`;
        htBtn.style.display = 'none';
        const cb = $('#cmCancelLnk');
        if (cb) cb.onclick = () => { state.linkFrom = null; drawCanvas(); };
        return;
      }

      if (state.addMode === 'starter') {
        stEl.innerHTML = `<span style="color:#fde047">🌟 <b>Chế độ Tạo Starter mới</b>: mỗi lần bấm lá bài bên trái sẽ tạo thêm 1 <b>Starter (Mở bài)</b> ở hàng dưới!</span>`;
        htBtn.style.display = state.selectedNodeId ? '' : 'none';
        return;
      }

      const selNode = state.selectedNodeId ? m.nodes.find(n => n.id === state.selectedNodeId) : null;
      if (selNode) {
        const modeTxt = state.addMode === 'into' ? '📥 Gộp chung bài vào' : '➕ Đang nối bước tiếp từ';
        stEl.innerHTML = `${modeTxt}: <b>${esc(selNode.title || 'Nút đang chọn')}</b>`;
        htBtn.style.display = '';
      } else {
        stEl.innerHTML = `<span class="muted">Lá bài tiếp theo bấm từ Deck sẽ tạo <b>🌟 Starter mới</b> ở hàng dưới.</span>`;
        htBtn.style.display = 'none';
      }
    }

    function renderNodeCardVisual(item, onRemove) {
      const wrap = document.createElement('div');
      wrap.className = 'mcard-item';
      const c = resolveCardRecord(item);
      const sp = entrySpec(item);
      const name = c ? c.name : entryName(item);

      if (c && ART) {
        const vis = ART.renderCardVisual(c, sp, 'sm');
        vis.style.cursor = 'zoom-in';
        vis.title = name + ' — Bấm để xem hiệu ứng Anh / Việt';
        vis.onclick = e => {
          e.stopPropagation();
          if (api.showCard) api.showCard(c.name, sp);
        };
        wrap.appendChild(vis);
      } else {
        const img = api.cardImg(name);
        const origClick = img.onclick;
        img.onclick = e => { e.stopPropagation(); if (origClick) origClick(e); };
        wrap.appendChild(img);
      }

      if (!state.locked && onRemove) {
        const rm = document.createElement('button');
        rm.type = 'button';
        rm.className = 'mcard-rm';
        rm.title = 'Gỡ lá này khỏi nút';
        rm.textContent = '×';
        rm.onclick = e => { e.stopPropagation(); onRemove(); };
        wrap.appendChild(rm);
      }
      return wrap;
    }

    function selectNodeQuietly(nodeId) {
      state.linkFrom = null;
      state.pendingBranch = null;
      state.selectedNodeId = nodeId;
      if (state.addMode === 'starter') {
        state.addMode = 'step';
        syncAddModeBtns();
      } else {
        updateStatusHeader();
      }
      box.querySelectorAll('.mnode').forEach(nodeEl => {
        nodeEl.classList.toggle('selected', nodeEl.dataset.id === nodeId);
        nodeEl.classList.remove('linking');
      });
    }

    function drawCanvas() {
      const m = curMap();
      const nodesEl = $('#mapNodes');
      const svg = $('#mapSvg');
      if (!m) { nodesEl.innerHTML = ''; svg.innerHTML = ''; updateStatusHeader(); return; }

      if (state.selectedNodeId && !m.nodes.some(n => n.id === state.selectedNodeId)) {
        state.selectedNodeId = m.nodes.length ? m.nodes[m.nodes.length - 1].id : null;
      }

      autoLayout(m, false);
      const stage = $('#mapStage');
      stage.style.transform = `translate(${state.panX}px,${state.panY}px) scale(${state.scale})`;
      nodesEl.innerHTML = '';

      if (!m.nodes.length) {
        nodesEl.innerHTML = `<div class="cmap-empty-guide">
          <h3>✨ Tạo Sơ đồ Đa Starter &amp; Chữa cháy Handtrap!</h3>
          <p>1. Chọn <b>🌟 + Starter mới</b> ở cột trái để đặt lần lượt <b>Starter 1, Starter 2, Starter 3...</b> từ trên xuống dưới.</p>
          <p>2. Gõ trực tiếp mô tả vào <b>ô trống bên cạnh lá bài</b> (vd: <i>"NS lá này → add lá kia lên tay"</i>) và bấm <b>➕ Nối bước tiếp</b> để dựng combo.</p>
          <p>3. Nếu bước nào dễ dính <b>Handtrap (Ash, Imperm, Nibiru...)</b>, bấm nút <b>⚡</b> ngay trên bước đó để nối sang chuỗi Starter bên dưới hoặc tạo nhánh Phương án B!</p>
        </div>`;
      }

      m.nodes.forEach(n => {
        const isSel = state.selectedNodeId === n.id;
        const isLnk = state.linkFrom === n.id;
        const roleKey = n.role || (!(m.edges || []).some(e => e.to === n.id) ? 'starter' : 'step');
        const roleCls = (NODE_ROLES[roleKey] && NODE_ROLES[roleKey].cls) || 'role-step';
        const cardsArr = n.cards || [];
        const isSideLayout = cardsArr.length <= 1;

        const el = document.createElement('div');
        el.className = `mnode ${roleCls}` + (isSel ? ' selected' : '') + (isLnk ? ' linking' : '');
        el.style.left = (n.x || 28) + 'px';
        el.style.top = (n.y || 28) + 'px';
        el.style.width = NODE_W + 'px';
        el.dataset.id = n.id;

        const toolsHtml = !state.locked
          ? `<span class="mnode-btns">
              <button type="button" class="mnbtn ht" title="Rẽ phương án khác / nhảy sang Starter dưới khi bước này bị dính Handtrap">⚡</button>
              <button type="button" class="mnbtn edit" title="Sửa tiêu đề & vai trò nút">✎</button>
              <button type="button" class="mnbtn lnk" title="Nối dây sang bước khác (vd: hội tụ về Sân cuối hoặc sang chuỗi dưới)">🔗</button>
              <button type="button" class="mnbtn danger del" title="Xóa bước này">✕</button>
            </span>`
          : '';

        const portHtml = !state.locked
          ? `<span class="mport mport-t" data-side="top" title="Kéo từ cạnh Trên"></span>
             <span class="mport mport-r" data-side="right" title="Kéo từ cạnh Phải sang bước tiếp"></span>
             <span class="mport mport-b" data-side="bottom" title="Kéo từ cạnh Dưới xuống Starter/nhánh dưới"></span>
             <span class="mport mport-l" data-side="left" title="Kéo từ cạnh Trái (tạo vòng cung bên hông)"></span>`
          : '';

        const noteHtml = !state.locked
          ? `<textarea class="mnode-side-text${isSideLayout ? '' : ' stacked'}" spellcheck="false" placeholder="${cardsArr.length ? 'Ghi mô tả cạnh bài (vd: Khi NS lá này → add lá kia lên tay)...' : 'Gõ ghi chú bước này hoặc kéo bài thả vào đây...'}">${esc(n.note || '')}</textarea>`
          : (n.note ? `<div class="mnode-side-read${isSideLayout ? '' : ' stacked'}">${esc(n.note)}</div>` : '');

        el.innerHTML = `
          <div class="mhead" title="Kéo để di chuyển • Bấm ✎ hoặc nhấp đúp tiêu đề để sửa chi tiết">
            <span class="mtitle">${esc(n.title || 'Bước combo')}</span>
            ${toolsHtml}
          </div>
          <div class="mbody ${isSideLayout ? 'side' : 'stack'}">
            <div class="mcards"></div>
            ${noteHtml}
          </div>
          ${portHtml}`;

        const cc = el.querySelector('.mcards');
        cardsArr.forEach((item, cIdx) => {
          cc.appendChild(renderNodeCardVisual(item, () => {
            if (m._seed) return api.toast('Đây là sơ đồ mẫu — hãy bấm "+ Sơ đồ mới" để tạo sơ đồ riêng');
            n.cards.splice(cIdx, 1);
            persistMaps();
            drawAll();
          }));
        });
        if (!cardsArr.length) cc.style.display = 'none';

        const ta = el.querySelector('.mnode-side-text');
        if (ta) {
          const minH = isSideLayout ? 88 : 48;
          const fitTa = () => {
            ta.style.height = '0px';
            ta.style.height = Math.max(minH, ta.scrollHeight + 2) + 'px';
          };
          requestAnimationFrame(fitTa);

          ta.onpointerdown = ev => {
            if (state.linkFrom && state.linkFrom !== n.id) return;
            ev.stopPropagation();
          };
          ta.onclick = ev => {
            if (!state.locked && state.linkFrom && state.linkFrom !== n.id) {
              ev.stopPropagation();
              ta.blur();
              connectTwoNodes(state.linkFrom, n.id, ev.clientX, ev.clientY);
              return;
            }
            ev.stopPropagation();
            closePopover();
            selectNodeQuietly(n.id);
          };
          ta.oninput = () => {
            if (m._seed) {
              // Tự nhân bản bản mẫu thành sơ đồ riêng của người dùng để gõ thoải mái không mất chữ
              const copy = JSON.parse(JSON.stringify(m));
              delete copy._seed;
              copy.id = 'm' + Date.now();
              copy.name_vi = (copy.name_vi || 'Sơ đồ') + ' (Của tôi)';
              state.maps.push(copy);
              state.idx = state.maps.length - 1;
              const clonedNode = copy.nodes.find(x => x.id === n.id);
              if (clonedNode) clonedNode.note = ta.value;
              persistMaps();
              refreshMapSelect();
              fitTa();
              requestAnimationFrame(drawEdges);
              return;
            }
            n.note = ta.value;
            fitTa();
            persistMaps();
            requestAnimationFrame(drawEdges);
          };
          ta.onwheel = ev => {
            if (ta.scrollHeight > ta.clientHeight) ev.stopPropagation();
          };
        }

        if (!state.locked) {
          el.querySelector('.ht').onclick = e => {
            e.stopPropagation();
            openHandtrapPivotPopover(n, e.clientX, e.clientY);
          };
          el.querySelector('.edit').onclick = e => {
            e.stopPropagation();
            openNodePopover(n, e.clientX, e.clientY);
          };
          el.querySelector('.mtitle').ondblclick = e => {
            e.stopPropagation();
            openNodePopover(n, e.clientX, e.clientY);
          };
          el.querySelector('.lnk').onclick = e => {
            e.stopPropagation();
            closePopover();
            state.linkFrom = state.linkFrom === n.id ? null : n.id;
            drawCanvas();
          };
          el.querySelector('.del').onclick = e => {
            e.stopPropagation();
            const targetMap = cloneSeedIfNeeded();
            if (!targetMap) return;
            pushUndo(targetMap);
            closePopover();
            targetMap.nodes = targetMap.nodes.filter(x => x.id !== n.id);
            targetMap.edges = targetMap.edges.filter(x => x.from !== n.id && x.to !== n.id);
            if (state.selectedNodeId === n.id) state.selectedNodeId = null;
            state.selectedEdgeIdx = null;
            persistMaps();
            drawAll();
          };

          // Kéo thả trực tiếp từ 1 trong 4 chấm cổng (Trên / Phải / Dưới / Trái) sang nút khác!
          el.querySelectorAll('.mport').forEach(port => {
            port.onpointerdown = ev => {
              ev.stopPropagation();
              if (m._seed) return api.toast('Hãy tạo sơ đồ riêng để nối dây');
              closePopover();
              const fromSide = port.dataset.side || 'auto';
              state.linkFrom = n.id;
              const onUp = upEv => {
                window.removeEventListener('pointerup', onUp);
                const hitEl = document.elementFromPoint(upEv.clientX, upEv.clientY);
                const targetPill = hitEl?.closest('.cm-edge-pill');
                if (targetPill && targetPill.dataset.e != null) {
                  const eIdx = Number(targetPill.dataset.e);
                  const curM = cloneSeedIfNeeded();
                  const exEdge = curM && curM.edges[eIdx];
                  if (exEdge && exEdge.from !== n.id && exEdge.to !== n.id) {
                    pushUndo(curM);
                    curM.edges.push({
                      from: n.id,
                      to: exEdge.to,
                      label: exEdge.label || '',
                      sub: exEdge.sub || '',
                      kind: exEdge.kind || 'normal',
                      ...(fromSide !== 'auto' ? { fromPort: fromSide } : {}),
                    });
                    state.linkFrom = null;
                    mergeTwoEdges(curM.edges.length - 1, eIdx, { skipUndo: true });
                    return;
                  }
                }
                const targetPort = hitEl?.closest('.mport');
                const targetEl = hitEl?.closest('.mnode');
                if (targetEl && targetEl.dataset.id && targetEl.dataset.id !== n.id) {
                  let toSide = targetPort ? (targetPort.dataset.side || 'auto') : 'auto';
                  // Nếu thả vào nửa trái của nút khi kéo từ cổng Trái -> tự tạo vòng cung hông Trái đẹp mắt!
                  if (!targetPort && fromSide === 'left') {
                    const tr = targetEl.getBoundingClientRect();
                    if (upEv.clientX < tr.left + tr.width * 0.45) toSide = 'left';
                  } else if (!targetPort && fromSide === 'right') {
                    const tr = targetEl.getBoundingClientRect();
                    if (upEv.clientX > tr.left + tr.width * 0.65) toSide = 'right';
                  }
                  connectTwoNodes(n.id, targetEl.dataset.id, upEv.clientX, upEv.clientY, { fromPort: fromSide, toPort: toSide });
                } else {
                  drawCanvas();
                }
              };
              window.addEventListener('pointerup', onUp);
            };
          });

          // Kéo di chuyển vị trí nút trên sơ đồ
          el.querySelector('.mhead').onpointerdown = ev => {
            if (ev.target.closest('button')) return;
            ev.stopPropagation();
            closePopover();
            const sx = ev.clientX, sy = ev.clientY, ox = n.x || 0, oy = n.y || 0;
            let moved = false;
            el.setPointerCapture(ev.pointerId);
            el.onpointermove = e2 => {
              if (Math.abs(e2.clientX - sx) > 3 || Math.abs(e2.clientY - sy) > 3) moved = true;
              n.x = Math.round(ox + (e2.clientX - sx) / state.scale);
              n.y = Math.round(oy + (e2.clientY - sy) / state.scale);
              el.style.left = n.x + 'px';
              el.style.top = n.y + 'px';
              drawEdges();
            };
            el.onpointerup = () => {
              el.onpointermove = el.onpointerup = null;
              if (moved && !m._seed) persistMaps();
            };
          };

          // Nhận kéo-thả lá bài gộp thẳng vào nút
          el.ondragover = ev => {
            if (ev.dataTransfer.types.includes('application/x-ygo-card')) {
              ev.preventDefault();
              ev.stopPropagation();
              el.classList.add('drop-hover');
            }
          };
          el.ondragleave = () => el.classList.remove('drop-hover');
          el.ondrop = ev => {
            ev.preventDefault();
            ev.stopPropagation();
            el.classList.remove('drop-hover');
            try {
              const payload = JSON.parse(ev.dataTransfer.getData('application/x-ygo-card'));
              const c = byId.get(payload.id);
              if (c) {
                if (m._seed) addCardToCombo(c, payload.spec);
                else addCardToCombo(c, payload.spec, { intoNodeId: n.id });
              }
            } catch (err) { }
          };
        }

        el.onclick = e => {
          e.stopPropagation();
          closePopover();
          if (!state.locked && state.linkFrom && state.linkFrom !== n.id) {
            connectTwoNodes(state.linkFrom, n.id, e.clientX, e.clientY);
            return;
          }
          state.linkFrom = null;
          state.pendingBranch = null;
          state.selectedNodeId = n.id;
          // Khi người chơi bấm chọn 1 Starter trên sơ đồ để đi tiếp nhánh của Starter đó, nếu đang ở tab '+ Starter mới' thì tự chuyển về '+ Nối bước tiếp' cho mượt!
          if (state.addMode === 'starter') {
            state.addMode = 'step';
            syncAddModeBtns();
          }
          drawCanvas();
        };

        nodesEl.appendChild(el);
      });

      updateStatusHeader();
      requestAnimationFrame(drawEdges);
    }

    function connectTwoNodes(fromId, toId, clientX, clientY, portOpts) {
      if (fromId === toId) { state.linkFrom = null; drawCanvas(); return; }
      const m = cloneSeedIfNeeded();
      if (!m) { state.linkFrom = null; drawCanvas(); return; }
      pushUndo(m);
      const po = portOpts || {};
      const fromNode = m.nodes.find(x => x.id === fromId);
      const toNode = m.nodes.find(x => x.id === toId);
      const isDownToStarter = fromNode && toNode && toNode.role === 'starter' && (toNode.y || 0) > (fromNode.y || 0);
      const isConvergeUp = fromNode && toNode && (toNode.x || 0) > (fromNode.x || 0) && Math.abs((toNode.y || 0) - (fromNode.y || 0)) > 70 && toNode.role !== 'planb';

      const defLabel = ($('#cmCustomAct').value || state.actionLabel || '').trim();
      const defSub = ($('#cmCustomSub').value || '').trim();
      const defKind = isDownToStarter
        ? 'pivot'
        : isConvergeUp
          ? 'converge'
          : ($('#cmActKind').value || state.actionKind || 'normal');

      const newEdge = {
        from: fromId,
        to: toId,
        label: isDownToStarter && defLabel === 'Special Summon' ? 'Đổi sang Starter dưới' : (isConvergeUp && defLabel === 'Special Summon' ? 'Hội tụ về nhánh chính' : defLabel),
        sub: defSub,
        kind: defKind,
      };
      if (po.fromPort && po.fromPort !== 'auto') newEdge.fromPort = po.fromPort;
      if (po.toPort && po.toPort !== 'auto') newEdge.toPort = po.toPort;
      if (po.fromPort === 'left' && po.toPort === 'left') newEdge.route = 'loop-left';
      else if (po.fromPort === 'right' && po.toPort === 'right') newEdge.route = 'loop-right';
      if (state.actionHtCard && defKind === 'handtrap') newEdge.htCard = state.actionHtCard;
      m.edges.push(newEdge);
      const newIdx = m.edges.length - 1;
      state.linkFrom = null;
      state.selectedNodeId = toId;
      persistMaps();
      drawCanvas();
      openEdgePopover(newIdx, clientX, clientY);
    }

    function getPortCoord(r, side, offset) {
      const off = offset || 0;
      if (side === 'left') return { x: r.x, y: r.y + r.h / 2 + off, nx: -1, ny: 0 };
      if (side === 'top') return { x: r.x + r.w / 2 + off, y: r.y, nx: 0, ny: -1 };
      if (side === 'bottom') return { x: r.x + r.w / 2 + off, y: r.y + r.h, nx: 0, ny: 1 };
      return { x: r.x + r.w, y: r.y + r.h / 2 + off, nx: 1, ny: 0 };
    }

    function roundedPolyline(pts, radius) {
      if (!pts.length) return '';
      if (pts.length === 2) return `M${pts[0].x},${pts[0].y} L${pts[1].x},${pts[1].y}`;
      let d = `M${pts[0].x},${pts[0].y}`;
      for (let i = 1; i < pts.length - 1; i++) {
        const prev = pts[i - 1], cur = pts[i], next = pts[i + 1];
        const v1x = cur.x - prev.x, v1y = cur.y - prev.y;
        const v2x = next.x - cur.x, v2y = next.y - cur.y;
        const len1 = Math.hypot(v1x, v1y), len2 = Math.hypot(v2x, v2y);
        if (len1 < 1 || len2 < 1) { d += ` L${cur.x},${cur.y}`; continue; }
        const r = Math.min(radius, len1 * 0.45, len2 * 0.45);
        const pA = { x: cur.x - (v1x / len1) * r, y: cur.y - (v1y / len1) * r };
        const pB = { x: cur.x + (v2x / len2) * r, y: cur.y + (v2y / len2) * r };
        d += ` L${pA.x},${pA.y} Q${cur.x},${cur.y} ${pB.x},${pB.y}`;
      }
      const last = pts[pts.length - 1];
      d += ` L${last.x},${last.y}`;
      return d;
    }

    function drawEdges() {
      const m = curMap();
      const svg = $('#mapSvg');
      if (!m || !svg) return;
      let maxX = 1080, maxY = 680;
      const rect = {};
      m.nodes.forEach(n => {
        const el = box.querySelector(`.mnode[data-id="${n.id}"]`);
        const h = el ? el.offsetHeight : nodeHeight(n);
        rect[n.id] = { x: n.x || 0, y: n.y || 0, w: NODE_W, h };
        maxX = Math.max(maxX, (n.x || 0) + NODE_W + 220);
        maxY = Math.max(maxY, (n.y || 0) + h + 180);
      });

      let defs = '<defs>';
      Object.entries(EDGE_KINDS).forEach(([k, style]) => {
        defs += `<marker id="arr-${k}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="${style.stroke}"/></marker>`;
      });
      defs += '</defs>';

      // Gom nhóm theo CẶP NÚT không phân biệt chiều (A↔B) để khi nối 2 dây qua lại giữa 2 lá bài sẽ tự động tách thành 2 vòng cung đối xứng tuyệt đẹp, không bao giờ đè lên nhau!
      const pairGroups = {};
      const outPortGroups = {};
      const getRouteBucket = e => {
        if (e.route === 'loop-left' || (e.fromPort === 'left' && e.toPort === 'left')) return 'll';
        if (e.route === 'loop-right' || (e.fromPort === 'right' && e.toPort === 'right')) return 'lr';
        return 'std';
      };
      (m.edges || []).forEach((e, idx) => {
        const basePk = e.from < e.to ? `${e.from}::${e.to}` : `${e.to}::${e.from}`;
        const pk = `${basePk}::${getRouteBucket(e)}`;
        (pairGroups[pk] = pairGroups[pk] || []).push(idx);
        (outPortGroups[e.from] = outPortGroups[e.from] || []).push(idx);
      });

      let pathsHtml = '';
      let labelsHtml = '';
      const pillBoxes = [];

      // Nhận diện các nhóm Hợp nhất dây (Y-Merge cùng đích A1,A2 -> C hoặc Y-Split cùng gốc A -> B1,B2)
      const rawMergeMap = {};
      (m.edges || []).forEach((e, idx) => {
        if (e && e.mergeId && rect[e.from] && rect[e.to]) {
          (rawMergeMap[e.mergeId] = rawMergeMap[e.mergeId] || []).push(idx);
        }
      });
      const mergedIdxSet = new Set();
      const mergeGroupsList = [];
      Object.entries(rawMergeMap).forEach(([mgId, idxs]) => {
        if (idxs.length < 2) return;
        const first = m.edges[idxs[0]];
        const sameTo = idxs.every(idx => m.edges[idx].to === first.to);
        const sameFrom = !sameTo && idxs.every(idx => m.edges[idx].from === first.from);
        if (sameTo || sameFrom) {
          idxs.forEach(idx => mergedIdxSet.add(idx));
          mergeGroupsList.push({ mgId, idxs, isConverge: sameTo });
        }
      });

      const computeSmoothTangent = (sx, sy, mx, my, ex, ey) => {
        const v1x = mx - sx, v1y = my - sy;
        const v2x = ex - mx, v2y = ey - my;
        const d1 = Math.max(1, Math.hypot(v1x, v1y));
        const d2 = Math.max(1, Math.hypot(v2x, v2y));
        const u1x = v1x / d1, u1y = v1y / d1;
        const u2x = v2x / d2, u2y = v2y / d2;
        let tx = u1x + u2x, ty = u1y + u2y;
        const tLen = Math.hypot(tx, ty);
        if (tLen > 1e-3) { tx /= tLen; ty /= tLen; }
        else {
          const ch = Math.max(1, Math.hypot(ex - sx, ey - sy));
          tx = (ex - sx) / ch; ty = (ey - sy) / ch;
        }
        return { tx, ty, d1, d2, u1x, u1y, u2x, u2y, v1x, v1y, v2x, v2y };
      };

      const calcPillMetrics = (e, kind) => {
        const rawLab = e.label || '';
        const rawSub = e.sub || '';
        const htThumb = e.htCard ? cardThumbSrc(e.htCard) : null;
        const prefix = kind === 'handtrap' && !htThumb ? '⚡ ' : (kind === 'pivot' ? '↪ ' : '');
        const dispLab = esc(prefix + (rawLab || 'Bấm để sửa'));
        const dispSub = esc(rawSub);
        const hasSub = !!rawSub;
        const imgPad = htThumb ? 24 : 0;
        const textLen = Math.max(dispLab.length * 7.2, dispSub.length * 6.2);
        const pillW = Math.max(66, 26 + textLen + imgPad);
        const pillH = hasSub ? 40 : 28;
        return { rawLab, rawSub, htThumb, dispLab, dispSub, hasSub, pillW, pillH };
      };

      const appendPill = ({ edgeIdx, grpIdxs, mergeId, kind, st, pm, mx, my }) => {
        const { rawLab, rawSub, htThumb, dispLab, dispSub, hasSub, pillW, pillH } = pm;
        if (!rawLab && !rawSub && state.locked) return;
        const rx = mx - pillW / 2;
        const ry = my - pillH / 2;
        const isSel = grpIdxs.includes(state.selectedEdgeIdx);
        const isMergeFirst = grpIdxs.includes(state.mergeFirstIdx);
        const isMergeHover = grpIdxs.includes(state.dragMergeHoverIdx);

        pillBoxes.push({
          edgeIdx,
          grpIdxs,
          mx,
          my,
          w: pillW,
          h: pillH,
          from: m.edges[edgeIdx].from,
          to: m.edges[edgeIdx].to,
        });

        const clipId = `htc-${edgeIdx}`;
        const imgSvg = htThumb
          ? `<clipPath id="${clipId}"><rect x="${rx + 4}" y="${ry + 3}" width="18" height="${pillH - 6}" rx="4"/></clipPath>
             <image href="${esc(htThumb.local)}" x="${rx + 4}" y="${ry + 3}" width="18" height="${pillH - 6}" preserveAspectRatio="xMidYMid slice" clip-path="url(#${clipId})"/>`
          : '';
        const tx = mx + (htThumb ? 9 : 0);
        const delAttr = mergeId ? `data-del-mg="${esc(mergeId)}"` : `data-del-e="${edgeIdx}"`;
        const delBadgeSvg = !state.locked
          ? `<g class="cm-edge-del" ${delAttr}>
               <title>Xóa ${mergeId ? 'nhánh hợp nhất' : 'sợi dây nối'} này (hoặc bấm Chuột phải vào dây)</title>
               <circle cx="${rx + pillW - 2}" cy="${ry + 2}" r="8.5" fill="#dc2626" stroke="#0d0e14" stroke-width="1.5"/>
               <text x="${rx + pillW - 2}" y="${ry + 5.8}" fill="#ffffff" font-size="12" font-weight="900" text-anchor="middle">×</text>
             </g>`
          : '';
        const mergeCntBadge = mergeId
          ? `<g pointer-events="none">
               <circle cx="${rx + 2}" cy="${ry + 2}" r="8" fill="#0f766e" stroke="#2dd4bf" stroke-width="1.2"/>
               <text x="${rx + 2}" y="${ry + 5.5}" fill="#ccfbf1" font-size="9.5" font-weight="800" text-anchor="middle">${grpIdxs.length}</text>
             </g>`
          : '';

        const pillStroke = (isMergeFirst || isMergeHover) ? '#fbbf24' : st.border;
        const pillSw = (isMergeFirst || isMergeHover) ? '2.6' : (isSel ? '2.2' : '1.4');
        const extraCls = (isSel ? ' selected' : '') + (isMergeFirst || isMergeHover ? ' merge-target' : '');
        const mgAttr = mergeId ? ` data-mg="${esc(mergeId)}"` : '';

        labelsHtml += `<g class="cm-edge-pill${extraCls}" data-e="${edgeIdx}"${mgAttr} style="cursor:${!state.locked ? (state.cutMode || state.mergeMode ? 'pointer' : 'grab') : 'default'}">
          <title>${state.cutMode ? '✂️ Bấm để xóa dây này' : (state.mergeMode ? '🔀 Bấm để chọn hợp nhất dây' : 'Nắm kéo để tạo dáng (kéo đè lên nhãn dây khác để hợp nhất!) • Bấm để sửa • Chuột phải xóa dây')}</title>
          <rect class="cm-pill-bg" x="${rx}" y="${ry}" width="${pillW}" height="${pillH}" rx="${pillH / 2}" fill="${st.bg}" stroke="${pillStroke}" stroke-width="${pillSw}"/>
          ${imgSvg}
          <text x="${tx}" y="${hasSub ? ry + 16 : ry + 18.5}" fill="${st.text}" font-size="12.8" font-weight="800" text-anchor="middle">${dispLab}</text>
          ${hasSub ? `<text x="${tx}" y="${ry + 31.5}" fill="#cbd5e1" font-size="11" text-anchor="middle">${dispSub}</text>` : ''}
          ${mergeCntBadge}
          ${delBadgeSvg}
        </g>`;
      };

      // 1) Vẽ các Nhánh Hợp Nhất (Y-Merge / Y-Split) chỉ với 1 hộp nhãn chung & 1 thân chính mượt mà!
      mergeGroupsList.forEach(({ mgId, idxs, isConverge }) => {
        const leadIdx = idxs[0];
        const lead = m.edges[leadIdx];
        const kind = EDGE_KINDS[lead.kind] ? lead.kind : 'normal';
        const st = EDGE_KINDS[kind];
        const route = lead.route || 'curve';
        const dashAttr = st.dash ? ` stroke-dasharray="${st.dash}"` : '';
        const isSelGrp = idxs.includes(state.selectedEdgeIdx) || idxs.includes(state.mergeFirstIdx);
        const visStroke = idxs.includes(state.mergeFirstIdx) ? '#fbbf24' : st.stroke;
        const visSw = isSelGrp ? '3.8' : '2.8';
        const pm = calcPillMetrics(lead, kind);

        if (isConverge) {
          // Nhiều lá bài (A1, A2...) cùng hội tụ về 1 bước đích C (vd: Synchro / Fusion / Xyz / Link Summon)
          const b = rect[lead.to];
          const avgAx = idxs.reduce((s, idx) => s + rect[m.edges[idx].from].x, 0) / idxs.length;
          const avgAy = idxs.reduce((s, idx) => s + rect[m.edges[idx].from].y, 0) / idxs.length;
          const sameColAll = Math.abs(b.x - avgAx) < b.w * 0.65;
          const toSide = (lead.toPort && lead.toPort !== 'auto')
            ? lead.toPort
            : (sameColAll ? (b.y >= avgAy ? 'top' : 'bottom') : (b.x >= avgAx ? 'left' : 'right'));
          const pEnd = getPortCoord(b, toSide, 0);

          const pStarts = idxs.map(idx => {
            const e = m.edges[idx];
            const a = rect[e.from];
            const sc = Math.abs(b.x - a.x) < a.w * 0.65;
            const fs = (e.fromPort && e.fromPort !== 'auto')
              ? e.fromPort
              : (sc ? (b.y >= a.y ? 'bottom' : 'top') : (b.x >= a.x ? 'right' : 'left'));
            return { idx, fromSide: fs, p: getPortCoord(a, fs, 0) };
          });

          const avgSx = pStarts.reduce((s, o) => s + o.p.x, 0) / pStarts.length;
          const avgSy = pStarts.reduce((s, o) => s + o.p.y, 0) / pStarts.length;
          const mx = avgSx + (pEnd.x - avgSx) * 0.58 + (lead.bendX || 0);
          const my = avgSy + (pEnd.y - avgSy) * 0.58 + (lead.bendY || 0);

          const tg = computeSmoothTangent(avgSx, avgSy, mx, my, pEnd.x, pEnd.y);
          const pillHalfT = Math.min((pm.pillW / 2) / Math.max(0.18, Math.abs(tg.tx)), (pm.pillH / 2) / Math.max(0.18, Math.abs(tg.ty)));
          const stem = Math.min(46, Math.max(14, (tg.d1 - pillHalfT) * 0.35));
          const backDist = Math.min(tg.d1 * 0.64, pillHalfT + stem);
          const jx = mx - tg.tx * backDist;
          const jy = my - tg.ty * backDist;

          // Từng nhánh con từ A_r -> điểm hội tụ J (Chuột phải lên nhánh nào thì tách/xóa riêng nhánh đó!)
          pStarts.forEach(({ idx, fromSide, p }) => {
            let brD = '';
            if (route === 'ortho') {
              const pts = (fromSide === 'left' || fromSide === 'right')
                ? [p, { x: jx, y: p.y }, { x: jx, y: jy }]
                : [p, { x: p.x, y: jy }, { x: jx, y: jy }];
              brD = roundedPolyline(pts, 12);
            } else {
              const dB = Math.max(1, Math.hypot(jx - p.x, jy - p.y));
              const k1 = Math.max(16, Math.min(78, dB * 0.48));
              const k2 = Math.max(14, Math.min(72, dB * 0.44));
              brD = `M${p.x},${p.y} C${p.x + p.nx * k1},${p.y + p.ny * k1} ${jx - tg.tx * k2},${jy - tg.ty * k2} ${jx},${jy}`;
            }
            if (!state.locked) {
              pathsHtml += `<path class="cm-edge-hit" data-e="${idx}" data-mg="${esc(mgId)}" d="${brD}" fill="none" stroke="transparent" stroke-width="18"><title>Nhánh hợp nhất • Chuột phải vào nhánh này để xóa riêng nhánh này</title></path>`;
            }
            pathsHtml += `<path class="cm-edge-vis${isSelGrp ? ' selected' : ''}" data-ev="${idx}" d="${brD}" fill="none" stroke="${visStroke}" stroke-width="${visSw}"${dashAttr}/>`;
          });

          // Thân chung J -> M -> pEnd với duy nhất 1 đầu mũi tên cắm vuông góc vào đích
          let trunkD = '';
          if (route === 'ortho') {
            const pts = (toSide === 'left' || toSide === 'right')
              ? [{ x: jx, y: jy }, { x: mx, y: pEnd.y }, pEnd]
              : [{ x: jx, y: jy }, { x: pEnd.x, y: my }, pEnd];
            trunkD = roundedPolyline(pts, 12);
          } else {
            const span2 = tg.d2 * Math.max(0.28, tg.u2x * tg.tx + tg.u2y * tg.ty);
            const fwd2 = -tg.v2x * pEnd.nx - tg.v2y * pEnd.ny;
            const kPort2 = fwd2 > 8 ? Math.max(15, Math.min(68, fwd2 * 0.56)) : Math.max(18, Math.min(48, tg.d2 * 0.3));
            const kMid2 = Math.max(10, Math.min(76, span2 * 0.52));
            trunkD = `M${jx},${jy} L${mx},${my} C${mx + tg.tx * kMid2},${my + tg.ty * kMid2} ${pEnd.x + pEnd.nx * kPort2},${pEnd.y + pEnd.ny * kPort2} ${pEnd.x},${pEnd.y}`;
          }
          if (!state.locked) {
            pathsHtml += `<path class="cm-edge-hit" data-e="${leadIdx}" data-mg="${esc(mgId)}" d="${trunkD}" fill="none" stroke="transparent" stroke-width="18"><title>Thân nhánh hợp nhất • Nắm kéo để uốn • Bấm để sửa hoặc Tách riêng</title></path>`;
          }
          pathsHtml += `<path class="cm-edge-vis${isSelGrp ? ' selected' : ''}" data-ev="${leadIdx}" d="${trunkD}" fill="none" stroke="${visStroke}" stroke-width="${visSw}"${dashAttr} marker-end="url(#arr-${kind})"/>`;
          pathsHtml += `<circle class="cm-merge-dot" cx="${jx}" cy="${jy}" r="4.2" fill="${visStroke}" stroke="#0d0e14" stroke-width="1.6"/>`;

          appendPill({ edgeIdx: leadIdx, grpIdxs: idxs, mergeId: mgId, kind, st, pm, mx, my });
        } else {
          // 1 lá gốc A tách ra nhiều bước đích B1, B2... chung 1 hành động gốc (Y-Split)
          const a = rect[lead.from];
          const avgBx = idxs.reduce((s, idx) => s + rect[m.edges[idx].to].x, 0) / idxs.length;
          const avgBy = idxs.reduce((s, idx) => s + rect[m.edges[idx].to].y, 0) / idxs.length;
          const sameColAll = Math.abs(avgBx - a.x) < a.w * 0.65;
          const fromSide = (lead.fromPort && lead.fromPort !== 'auto')
            ? lead.fromPort
            : (sameColAll ? (avgBy >= a.y ? 'bottom' : 'top') : (avgBx >= a.x ? 'right' : 'left'));
          const pStart = getPortCoord(a, fromSide, 0);

          const pEnds = idxs.map(idx => {
            const e = m.edges[idx];
            const b = rect[e.to];
            const sc = Math.abs(b.x - a.x) < a.w * 0.65;
            const ts = (e.toPort && e.toPort !== 'auto')
              ? e.toPort
              : (sc ? (b.y >= a.y ? 'top' : 'bottom') : (b.x >= a.x ? 'left' : 'right'));
            return { idx, toSide: ts, p: getPortCoord(b, ts, 0) };
          });

          const avgEx = pEnds.reduce((s, o) => s + o.p.x, 0) / pEnds.length;
          const avgEy = pEnds.reduce((s, o) => s + o.p.y, 0) / pEnds.length;
          const mx = pStart.x + (avgEx - pStart.x) * 0.42 + (lead.bendX || 0);
          const my = pStart.y + (avgEy - pStart.y) * 0.42 + (lead.bendY || 0);

          const tg = computeSmoothTangent(pStart.x, pStart.y, mx, my, avgEx, avgEy);
          const pillHalfT = Math.min((pm.pillW / 2) / Math.max(0.18, Math.abs(tg.tx)), (pm.pillH / 2) / Math.max(0.18, Math.abs(tg.ty)));
          const stem = Math.min(46, Math.max(14, (tg.d2 - pillHalfT) * 0.35));
          const fwdDist = Math.min(tg.d2 * 0.64, pillHalfT + stem);
          const jx = mx + tg.tx * fwdDist;
          const jy = my + tg.ty * fwdDist;

          let trunkD = '';
          if (route === 'ortho') {
            const pts = (fromSide === 'left' || fromSide === 'right')
              ? [pStart, { x: mx, y: pStart.y }, { x: jx, y: jy }]
              : [pStart, { x: pStart.x, y: my }, { x: jx, y: jy }];
            trunkD = roundedPolyline(pts, 12);
          } else {
            const span1 = tg.d1 * Math.max(0.28, tg.u1x * tg.tx + tg.u1y * tg.ty);
            const fwd1 = tg.v1x * pStart.nx + tg.v1y * pStart.ny;
            const kPort1 = fwd1 > 8 ? Math.max(15, Math.min(68, fwd1 * 0.56)) : Math.max(18, Math.min(48, tg.d1 * 0.3));
            const kMid1 = Math.max(10, Math.min(76, span1 * 0.52));
            trunkD = `M${pStart.x},${pStart.y} C${pStart.x + pStart.nx * kPort1},${pStart.y + pStart.ny * kPort1} ${mx - tg.tx * kMid1},${my - tg.ty * kMid1} ${mx},${my} L${jx},${jy}`;
          }

          if (!state.locked) {
            pathsHtml += `<path class="cm-edge-hit" data-e="${leadIdx}" data-mg="${esc(mgId)}" d="${trunkD}" fill="none" stroke="transparent" stroke-width="18"></path>`;
          }
          pathsHtml += `<path class="cm-edge-vis${isSelGrp ? ' selected' : ''}" data-ev="${leadIdx}" d="${trunkD}" fill="none" stroke="${visStroke}" stroke-width="${visSw}"${dashAttr}/>`;

          pEnds.forEach(({ idx, toSide, p }) => {
            let brD = '';
            if (route === 'ortho') {
              const pts = (toSide === 'left' || toSide === 'right')
                ? [{ x: jx, y: jy }, { x: jx, y: p.y }, p]
                : [{ x: jx, y: jy }, { x: p.x, y: jy }, p];
              brD = roundedPolyline(pts, 12);
            } else {
              const dB = Math.max(1, Math.hypot(p.x - jx, p.y - jy));
              const k1 = Math.max(14, Math.min(72, dB * 0.44));
              const k2 = Math.max(16, Math.min(78, dB * 0.48));
              brD = `M${jx},${jy} C${jx + tg.tx * k1},${jy + tg.ty * k1} ${p.x + p.nx * k2},${p.y + p.ny * k2} ${p.x},${p.y}`;
            }
            if (!state.locked) {
              pathsHtml += `<path class="cm-edge-hit" data-e="${idx}" data-mg="${esc(mgId)}" d="${brD}" fill="none" stroke="transparent" stroke-width="18"><title>Nhánh tách • Chuột phải để xóa riêng nhánh này</title></path>`;
            }
            pathsHtml += `<path class="cm-edge-vis${isSelGrp ? ' selected' : ''}" data-ev="${idx}" d="${brD}" fill="none" stroke="${visStroke}" stroke-width="${visSw}"${dashAttr} marker-end="url(#arr-${kind})"/>`;
          });
          pathsHtml += `<circle class="cm-merge-dot" cx="${jx}" cy="${jy}" r="4.2" fill="${visStroke}" stroke="#0d0e14" stroke-width="1.6"/>`;

          appendPill({ edgeIdx: leadIdx, grpIdxs: idxs, mergeId: mgId, kind, st, pm, mx, my });
        }
      });

      // 2) Vẽ các sợi dây đơn lẻ
      (m.edges || []).forEach((e, i) => {
        if (mergedIdxSet.has(i)) return;
        const a = rect[e.from], b = rect[e.to];
        if (!a || !b) return;
        const kind = EDGE_KINDS[e.kind] ? e.kind : 'normal';
        const st = EDGE_KINDS[kind];
        const route = e.route || 'curve';

        const basePk = e.from < e.to ? `${e.from}::${e.to}` : `${e.to}::${e.from}`;
        const pk = `${basePk}::${getRouteBucket(e)}`;
        const pGrp = pairGroups[pk] || [i];
        const pairPos = pGrp.indexOf(i) - (pGrp.length - 1) / 2; // vd 2 dây: -0.5 và +0.5

        const sameColumn = Math.abs(b.x - a.x) < a.w * 0.65;
        let fromSide = e.fromPort || 'auto';
        let toSide = e.toPort || 'auto';
        if (route === 'loop-left') { fromSide = 'left'; toSide = 'left'; }
        else if (route === 'loop-right') { fromSide = 'right'; toSide = 'right'; }
        else {
          if (fromSide === 'auto') {
            if (sameColumn) fromSide = b.y >= a.y ? 'bottom' : 'top';
            else fromSide = b.x >= a.x ? 'right' : 'left';
          }
          if (toSide === 'auto') {
            if (sameColumn) toSide = b.y >= a.y ? 'top' : 'bottom';
            else toSide = b.x >= a.x ? 'left' : 'right';
          }
        }

        // Tách cổng tự động khi có >= 2 dây nối giữa cùng 2 nút (hoặc nhiều nhánh xuất phát từ 1 nút)
        let portOffA = 0, portOffB = 0;
        if (pGrp.length > 1 && route !== 'loop-left' && route !== 'loop-right') {
          const sep = sameColumn ? 64 : 30;
          portOffA = pairPos * 2 * sep;
          portOffB = pairPos * 2 * sep;
        } else {
          const outs = outPortGroups[e.from] || [i];
          if (outs.length > 1) portOffA = (outs.indexOf(i) - (outs.length - 1) / 2) * 18;
        }

        const p1 = getPortCoord(a, fromSide, portOffA);
        const p2 = getPortCoord(b, toSide, portOffB);

        // Điểm neo cơ sở của đường dây & nhãn (trước khi cộng độ kéo tay bendX, bendY của người dùng)
        let baseMx = (p1.x + p2.x) / 2;
        let baseMy = (p1.y + p2.y) / 2;

        if (route === 'loop-left' || (fromSide === 'left' && toSide === 'left')) {
          baseMx = Math.min(p1.x, p2.x) - (62 + Math.max(0, pGrp.indexOf(i)) * 42);
        } else if (route === 'loop-right' || (fromSide === 'right' && toSide === 'right')) {
          baseMx = Math.max(p1.x, p2.x) + (62 + Math.max(0, pGrp.indexOf(i)) * 42);
        } else if (pGrp.length > 1 && e.bendX == null && e.bendY == null) {
          // Tự động uốn vòm đối xứng Trái / Phải và lùi nhẹ về cổng xuất phát để nhường chỗ thoáng cho đầu mũi tên!
          if (sameColumn) {
            baseMx += pairPos * 2 * 30;
            baseMy += (p2.y >= p1.y ? -9 : 9);
          } else {
            baseMy += pairPos * 2 * 48;
          }
        }

        const mx = baseMx + (e.bendX || 0);
        const my = baseMy + (e.bendY || 0);
        let pathD = '';

        if (route === 'loop-left' || (fromSide === 'left' && toSide === 'left')) {
          const dirY = p2.y >= p1.y ? 1 : -1;
          const kY = Math.max(20, Math.abs(p2.y - p1.y) * 0.28);
          const ctrlX = Math.min(mx, p1.x - 24, p2.x - 24);
          pathD = `M${p1.x},${p1.y} C${ctrlX},${p1.y} ${mx},${my - dirY * kY} ${mx},${my} C${mx},${my + dirY * kY} ${ctrlX},${p2.y} ${p2.x},${p2.y}`;
        } else if (route === 'loop-right' || (fromSide === 'right' && toSide === 'right')) {
          const dirY = p2.y >= p1.y ? 1 : -1;
          const kY = Math.max(20, Math.abs(p2.y - p1.y) * 0.28);
          const ctrlX = Math.max(mx, p1.x + 24, p2.x + 24);
          pathD = `M${p1.x},${p1.y} C${ctrlX},${p1.y} ${mx},${my - dirY * kY} ${mx},${my} C${mx},${my + dirY * kY} ${ctrlX},${p2.y} ${p2.x},${p2.y}`;
        } else if (route === 'ortho') {
          let pts;
          const midPortX = (p1.x + p2.x) / 2;
          if (fromSide === 'left' || fromSide === 'right') {
            pts = [p1, { x: mx, y: p1.y }, { x: mx, y: p2.y }, p2];
          } else if (Math.abs(mx - midPortX) > 10) {
            const stub1 = p1.y + p1.ny * 16;
            const stub2 = p2.y + p2.ny * 16;
            pts = [p1, { x: p1.x, y: stub1 }, { x: mx, y: stub1 }, { x: mx, y: stub2 }, { x: p2.x, y: stub2 }, p2];
          } else if (Math.abs(p1.x - p2.x) > 4) {
            pts = [p1, { x: p1.x, y: my }, { x: p2.x, y: my }, p2];
          } else {
            pts = [p1, p2];
          }
          pathD = roundedPolyline(pts, 12);
        } else {
          // Đường cong đôi G1 không vặn xoắn (overshoot-free) đi chính xác qua tâm nhãn/tay nắm (mx, my) và vuông góc 90° tại cả 2 cổng ra/vào!
          const v1x = mx - p1.x, v1y = my - p1.y;
          const v2x = p2.x - mx, v2y = p2.y - my;
          const d1 = Math.max(1, Math.hypot(v1x, v1y));
          const d2 = Math.max(1, Math.hypot(v2x, v2y));
          const u1x = v1x / d1, u1y = v1y / d1;
          const u2x = v2x / d2, u2y = v2y / d2;
          let tx = u1x + u2x, ty = u1y + u2y;
          const tLen = Math.hypot(tx, ty);
          if (tLen > 1e-3) {
            tx /= tLen; ty /= tLen;
          } else {
            const chord = Math.max(1, Math.hypot(p2.x - p1.x, p2.y - p1.y));
            tx = (p2.x - p1.x) / chord; ty = (p2.y - p1.y) / chord;
          }

          const span1 = d1 * Math.max(0.28, u1x * tx + u1y * ty);
          const span2 = d2 * Math.max(0.28, u2x * tx + u2y * ty);
          const fwd1 = v1x * p1.nx + v1y * p1.ny;
          const fwd2 = -v2x * p2.nx - v2y * p2.ny;
          const kPort1 = fwd1 > 8 ? Math.max(15, Math.min(68, fwd1 * 0.56)) : Math.max(18, Math.min(48, d1 * 0.3));
          const kPort2 = fwd2 > 8 ? Math.max(15, Math.min(68, fwd2 * 0.56)) : Math.max(18, Math.min(48, d2 * 0.3));
          const kMid1 = Math.max(10, Math.min(76, span1 * 0.52));
          const kMid2 = Math.max(10, Math.min(76, span2 * 0.52));

          const c1x = p1.x + p1.nx * kPort1, c1y = p1.y + p1.ny * kPort1;
          const c2x = mx - tx * kMid1, c2y = my - ty * kMid1;
          const c3x = mx + tx * kMid2, c3y = my + ty * kMid2;
          const c4x = p2.x + p2.nx * kPort2, c4y = p2.y + p2.ny * kPort2;
          pathD = `M${p1.x},${p1.y} C${c1x},${c1y} ${c2x},${c2y} ${mx},${my} C${c3x},${c3y} ${c4x},${c4y} ${p2.x},${p2.y}`;
        }

        const isSelEdge = state.selectedEdgeIdx === i || state.mergeFirstIdx === i;
        const singleStroke = state.mergeFirstIdx === i ? '#fbbf24' : st.stroke;
        const dashAttr = st.dash ? ` stroke-dasharray="${st.dash}"` : '';
        if (!state.locked) {
          pathsHtml += `<path class="cm-edge-hit" data-e="${i}" d="${pathD}" fill="none" stroke="transparent" stroke-width="18"><title>${state.cutMode ? '✂️ Bấm để xóa sợi dây này ngay' : (state.mergeMode ? '🔀 Bấm để chọn hợp nhất dây' : 'Nắm kéo dây để uốn cong • Bấm để sửa • Chuột phải để xóa dây')}</title></path>`;
        }
        pathsHtml += `<path class="cm-edge-vis${isSelEdge ? ' selected' : ''}" data-ev="${i}" d="${pathD}" fill="none" stroke="${singleStroke}" stroke-width="${isSelEdge ? '3.8' : '2.8'}"${dashAttr} marker-end="url(#arr-${kind})"/>`;

        const pm = calcPillMetrics(e, kind);
        appendPill({ edgeIdx: i, grpIdxs: [i], mergeId: '', kind, st, pm, mx, my });
      });

      svg.setAttribute('width', maxX);
      svg.setAttribute('height', maxY);
      svg.innerHTML = defs + pathsHtml + labelsHtml;

      if (!state.locked) {
        svg.querySelectorAll('[data-del-e]').forEach(delEl => {
          delEl.onpointerdown = ev => { ev.stopPropagation(); };
          delEl.onclick = ev => {
            ev.stopPropagation();
            deleteEdgeAt(Number(delEl.dataset.delE));
          };
        });

        svg.querySelectorAll('[data-del-mg]').forEach(delMgEl => {
          delMgEl.onpointerdown = ev => { ev.stopPropagation(); };
          delMgEl.onclick = ev => {
            ev.stopPropagation();
            deleteMergeGroup(delMgEl.dataset.delMg);
          };
        });

        svg.querySelectorAll('[data-e]').forEach(el => {
          el.oncontextmenu = ev => {
            ev.preventDefault();
            ev.stopPropagation();
            if (el.classList.contains('cm-edge-pill') && el.dataset.mg) {
              deleteMergeGroup(el.dataset.mg);
            } else {
              deleteEdgeAt(Number(el.dataset.e));
            }
          };

          el.onpointerdown = ev => {
            if (ev.button !== 0) return;
            if (ev.target && ev.target.closest && (ev.target.closest('[data-del-e]') || ev.target.closest('[data-del-mg]'))) return;
            ev.stopPropagation();
            closePopover();
            const edgeIdx = Number(el.dataset.e);

            if (state.cutMode) {
              if (el.classList.contains('cm-edge-pill') && el.dataset.mg) {
                deleteMergeGroup(el.dataset.mg);
              } else {
                deleteEdgeAt(edgeIdx);
              }
              return;
            }

            if (state.linkFrom) {
              const curM = cloneSeedIfNeeded();
              const exEdge = curM && curM.edges[edgeIdx];
              if (exEdge && exEdge.from !== state.linkFrom && exEdge.to !== state.linkFrom) {
                pushUndo(curM);
                curM.edges.push({
                  from: state.linkFrom,
                  to: exEdge.to,
                  label: exEdge.label || '',
                  sub: exEdge.sub || '',
                  kind: exEdge.kind || 'normal',
                });
                state.linkFrom = null;
                mergeTwoEdges(curM.edges.length - 1, edgeIdx, { skipUndo: true });
                return;
              }
            }

            if (state.mergeMode) {
              const mNow = curMap();
              if (!mNow || !mNow.edges[edgeIdx]) return;
              if (state.mergeFirstIdx == null) {
                state.mergeFirstIdx = edgeIdx;
                updateStatusHeader();
                drawEdges();
              } else if (getMergeGroupIndices(mNow, state.mergeFirstIdx).includes(edgeIdx)) {
                state.mergeFirstIdx = null;
                updateStatusHeader();
                drawEdges();
              } else {
                mergeTwoEdges(state.mergeFirstIdx, edgeIdx);
              }
              return;
            }

            let activeMap = curMap();
            if (!activeMap || !activeMap.edges[edgeIdx]) return;
            let dragGrpIdxs = getMergeGroupIndices(activeMap, edgeIdx);

            const sx = ev.clientX, sy = ev.clientY;
            const origBx = activeMap.edges[dragGrpIdxs[0]].bendX || 0;
            const origBy = activeMap.edges[dragGrpIdxs[0]].bendY || 0;
            let moved = false;

            const onMove = e2 => {
              const dist = Math.hypot(e2.clientX - sx, e2.clientY - sy);
              if (dist > 4 && !moved) {
                moved = true;
                activeMap = cloneSeedIfNeeded();
                pushUndo(activeMap);
                dragGrpIdxs = getMergeGroupIndices(activeMap, edgeIdx);
              }
              if (!moved) return;
              const newBx = Math.round(origBx + (e2.clientX - sx) / state.scale);
              const newBy = Math.round(origBy + (e2.clientY - sy) / state.scale);
              dragGrpIdxs.forEach(gi => {
                if (activeMap.edges[gi]) {
                  activeMap.edges[gi].bendX = newBx;
                  activeMap.edges[gi].bendY = newBy;
                }
              });

              // Kiểm tra nếu kéo thả hộp nhãn của dây này chạm lên hộp nhãn dây khác cùng đích / cùng gốc -> báo sáng vàng sẵn sàng Hợp nhất!
              const wr = $('#mapWrap').getBoundingClientRect();
              const stX = (e2.clientX - wr.left - state.panX) / state.scale;
              const stY = (e2.clientY - wr.top - state.panY) / state.scale;
              const leadE = activeMap.edges[dragGrpIdxs[0]];
              let hoverTarget = null;
              if (leadE) {
                for (const pb of pillBoxes) {
                  if (dragGrpIdxs.includes(pb.edgeIdx)) continue;
                  if (pb.to !== leadE.to && pb.from !== leadE.from) continue;
                  if (Math.abs(stX - pb.mx) <= pb.w / 2 + 12 && Math.abs(stY - pb.my) <= pb.h / 2 + 12) {
                    hoverTarget = pb.edgeIdx;
                    break;
                  }
                }
              }
              state.dragMergeHoverIdx = hoverTarget;
              drawEdges();
            };

            const onUp = upEv => {
              window.removeEventListener('pointermove', onMove);
              window.removeEventListener('pointerup', onUp);
              const dropMergeTarget = state.dragMergeHoverIdx;
              state.dragMergeHoverIdx = null;
              if (moved && dropMergeTarget != null) {
                dragGrpIdxs.forEach(gi => {
                  if (activeMap.edges[gi]) {
                    activeMap.edges[gi].bendX = origBx;
                    activeMap.edges[gi].bendY = origBy;
                  }
                });
                mergeTwoEdges(edgeIdx, dropMergeTarget, { skipUndo: true });
              } else if (moved) {
                persistMaps();
                drawEdges();
              } else {
                state.selectedEdgeIdx = edgeIdx;
                drawEdges();
                openEdgePopover(edgeIdx, upEv.clientX, upEv.clientY);
              }
            };

            window.addEventListener('pointermove', onMove);
            window.addEventListener('pointerup', onUp);
          };

          el.ondblclick = ev => {
            if (state.cutMode || state.mergeMode) return;
            ev.stopPropagation();
            const edgeIdx = Number(el.dataset.e);
            const activeMap = cloneSeedIfNeeded();
            if (!activeMap || !activeMap.edges[edgeIdx]) return;
            pushUndo(activeMap);
            getMergeGroupIndices(activeMap, edgeIdx).forEach(gi => {
              if (activeMap.edges[gi]) {
                delete activeMap.edges[gi].bendX;
                delete activeMap.edges[gi].bendY;
              }
            });
            state.selectedEdgeIdx = null;
            closePopover();
            persistMaps();
            drawEdges();
            api.toast('↺ Đã đặt lại độ cong mặc định của dây');
          };
        });
      }
    }

    function drawAll() {
      refreshMapSelect();
      refreshDeckSelect();
      renderActionPills();
      renderDeckTray();
      drawCanvas();
    }

    function syncLockBtn() {
      const b = $('#mLock');
      b.textContent = state.locked ? '🔒 Đang khóa sửa' : '🔓 Đang mở sửa';
      b.classList.toggle('primary', state.locked);
    }

    const syncAddModeBtns = () => {
      $('#cmModeStarter').classList.toggle('active', state.addMode === 'starter');
      $('#cmModeStep').classList.toggle('active', state.addMode === 'step');
      $('#cmModeInto').classList.toggle('active', state.addMode === 'into');
      updateStatusHeader();
    };

    // Kéo nền Pan + Cuộn chuột Zoom + Thả lá bài ra vị trí bất kỳ trên nền
    const wrap = $('#mapWrap');

    function syncZoomHud() {
      const zBtn = $('#cmZoomReset');
      if (zBtn) zBtn.textContent = Math.round(state.scale * 100) + '%';
      const fBtn = $('#cmFullCanvas');
      if (fBtn) fBtn.textContent = state.expandedCanvas ? '🗗 Thu nhỏ khung' : '⛶ Toàn màn hình';
      const topFull = $('#mFull');
      if (topFull) {
        topFull.textContent = state.expandedCanvas ? '🗗 Thu nhỏ khung' : '⛶ Phóng to khung';
        topFull.classList.toggle('primary', state.expandedCanvas);
      }
    }

    function applyZoomAt(newScale, clientX, clientY) {
      const clamped = Math.min(2.4, Math.max(0.32, Math.round(newScale * 100) / 100));
      const wr = wrap.getBoundingClientRect();
      const ox = clientX != null ? (clientX - wr.left) : (wr.width || 960) / 2;
      const oy = clientY != null ? (clientY - wr.top) : (wr.height || 640) / 2;
      const worldX = (ox - state.panX) / state.scale;
      const worldY = (oy - state.panY) / state.scale;
      state.scale = clamped;
      state.panX = Math.round(ox - worldX * state.scale);
      state.panY = Math.round(oy - worldY * state.scale);
      $('#mapStage').style.transform = `translate(${state.panX}px,${state.panY}px) scale(${state.scale})`;
      syncZoomHud();
    }

    const defaultPan = () => ({
      x: state.trayCollapsed ? 16 : 256,
      y: 88,
    });

    function fitAllNodes(showToast) {
      const m = curMap();
      if (!m || !m.nodes || !m.nodes.length) {
        const dp = defaultPan();
        state.panX = dp.x;
        state.panY = dp.y;
        state.scale = 1;
        drawCanvas();
        syncZoomHud();
        return;
      }
      const wr = wrap.getBoundingClientRect();
      const viewW = wr.width || 1280;
      const viewH = wr.height || 740;
      const clearLeft = state.trayCollapsed ? 18 : 324;
      const clearTop = 104;
      const clearRight = 18;
      const clearBottom = 56;
      const availW = Math.max(320, viewW - clearLeft - clearRight);
      const availH = Math.max(240, viewH - clearTop - clearBottom);

      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      m.nodes.forEach(n => {
        const el = box.querySelector(`.mnode[data-id="${n.id}"]`);
        const h = el ? el.offsetHeight : nodeHeight(n);
        const nx = n.x || 0, ny = n.y || 0;
        if (nx < minX) minX = nx;
        if (ny < minY) minY = ny;
        if (nx + NODE_W > maxX) maxX = nx + NODE_W;
        if (ny + h > maxY) maxY = ny + h;
      });
      const pad = 28;
      const contentW = Math.max(280, maxX - minX + pad * 2);
      const contentH = Math.max(200, maxY - minY + pad * 2);
      const fitScale = Math.min(1.2, Math.max(0.42, Math.min(availW / contentW, availH / contentH)));
      state.scale = Math.round(fitScale * 100) / 100;
      state.panX = Math.round(clearLeft + (availW - (maxX - minX) * state.scale) / 2 - minX * state.scale);
      state.panY = Math.round(clearTop + Math.max(10, (availH - (maxY - minY) * state.scale) / 2) - minY * state.scale);
      drawCanvas();
      syncZoomHud();
      if (showToast) api.toast(`⊡ Đã căn vừa toàn bộ sơ đồ (${Math.round(state.scale * 100)}%)`);
    }

    function toggleExpandedCanvas(force) {
      state.expandedCanvas = force !== undefined ? !!force : !state.expandedCanvas;
      $('#cmapLayout').classList.toggle('canvas-expanded', state.expandedCanvas);
      syncZoomHud();
      requestAnimationFrame(() => drawEdges());
    }

    wrap.onpointerdown = e => {
      if (e.target.closest('.mnode') || e.target.closest('.cm-popover') || e.target.closest('.cm-edge-pill') || e.target.closest('.cm-edge-hit') || e.target.closest('.cm-zoom-hud')) return;
      closePopover();
      if (state.selectedEdgeIdx != null) {
        state.selectedEdgeIdx = null;
        drawEdges();
      }
      const sx = e.clientX, sy = e.clientY, ox = state.panX, oy = state.panY;
      let dragged = false;
      wrap.setPointerCapture(e.pointerId);
      wrap.onpointermove = e2 => {
        if (Math.abs(e2.clientX - sx) > 4 || Math.abs(e2.clientY - sy) > 4) dragged = true;
        state.panX = ox + e2.clientX - sx;
        state.panY = oy + e2.clientY - sy;
        $('#mapStage').style.transform = `translate(${state.panX}px,${state.panY}px) scale(${state.scale})`;
      };
      wrap.onpointerup = () => {
        wrap.onpointermove = wrap.onpointerup = null;
        if (!dragged && state.linkFrom) {
          state.linkFrom = null;
          drawCanvas();
        }
      };
    };
    wrap.onwheel = e => {
      if (e.target.closest('.cm-popover')) return;
      e.preventDefault();
      applyZoomAt(state.scale * (e.deltaY < 0 ? 1.12 : 0.89), e.clientX, e.clientY);
    };
    $('#cmZoomIn').onclick = () => applyZoomAt(state.scale + 0.15);
    $('#cmZoomOut').onclick = () => applyZoomAt(state.scale - 0.15);
    $('#cmZoomReset').onclick = () => {
      const dp = defaultPan();
      state.scale = 1;
      state.panX = dp.x;
      state.panY = dp.y;
      drawCanvas();
      syncZoomHud();
      api.toast('🔍 Đã đưa về kích thước chuẩn 100% to rõ nhất!');
    };
    $('#cmZoomFit').onclick = () => fitAllNodes(true);
    $('#cmFullCanvas').onclick = () => toggleExpandedCanvas();
    $('#mFull').onclick = () => toggleExpandedCanvas();
    wrap.ondragover = ev => {
      if (ev.dataTransfer.types.includes('application/x-ygo-card')) ev.preventDefault();
    };
    wrap.ondrop = ev => {
      if (ev.target.closest('.mnode')) return;
      ev.preventDefault();
      try {
        const payload = JSON.parse(ev.dataTransfer.getData('application/x-ygo-card'));
        const c = byId.get(payload.id);
        if (!c) return;
        const r = wrap.getBoundingClientRect();
        const dropX = (ev.clientX - r.left - state.panX) / state.scale - NODE_W / 2;
        const dropY = (ev.clientY - r.top - state.panY) / state.scale - 40;
        // Nếu thả ở sát cột bên trái (x < 120) thì tự hiểu là tạo Starter mới tại vị trí thả!
        const dropAsStarter = dropX < 120 && !state.pendingBranch;
        addCardToCombo(c, payload.spec, { x: Math.max(12, dropX), y: Math.max(12, dropY), asStarter: dropAsStarter });
      } catch (err) { }
    };

    // Nạp file Deck (.ydk hoặc .txt) trực tiếp
    function parseDeckFileText(filename, text) {
      const lines = String(text || '').split(/\r?\n/).map(s => s.trim());
      const newDeck = {
        id: 'd' + Date.now(),
        name: filename.replace(/\.(ydk|txt)$/i, '') || 'Deck nhập',
        format: 'tcg',
        main: [],
        extra: [],
        side: [],
      };
      let zone = 'main', miss = 0;
      lines.forEach(l => {
        if (!l || l.startsWith('#created')) return;
        if (/^#main/i.test(l) || /^main\s*deck/i.test(l)) { zone = 'main'; return; }
        if (/^#extra/i.test(l) || /^extra\s*deck/i.test(l)) { zone = 'extra'; return; }
        if (/^!side/i.test(l) || /^side\s*deck/i.test(l)) { zone = 'side'; return; }
        if (/^\d+$/.test(l)) {
          const code = Number(l);
          const c = byId.get(code);
          if (c) {
            newDeck[zone].push(code !== c.id ? { id: c.id, spec: { style: 'standard', imgId: code, label: 'Alt Art' } } : c.id);
          } else miss++;
          return;
        }
        const mTxt = l.match(/^(\d+)\s*x?\s+(.+)$/i);
        if (mTxt) {
          const qty = Math.min(3, Math.max(1, Number(mTxt[1])));
          const rawName = mTxt[2].trim();
          let c = byName.get(rawName.toLowerCase());
          if (!c && SMART) {
            const sug = SMART.suggestCards(cards, rawName, 1);
            if (sug.length) c = sug[0];
          }
          if (c) {
            const targetZ = zone === 'side' ? 'side' : (isExtraCard(c) ? 'extra' : 'main');
            for (let k = 0; k < qty; k++) newDeck[targetZ].push(c.id);
          } else miss++;
        }
      });
      return { deck: newDeck, miss };
    }

    $('#cmDeckSel').onchange = e => {
      state.deckId = e.target.value;
      if (state.deckId) localStorage.setItem(LS_CUR_DECK, state.deckId);
      const m = curMap();
      if (m && !m._seed) { m.deckId = state.deckId; persistMaps(); }
      renderDeckTray();
    };

    $('#cmImpYdk').onclick = () => $('#cmYdkFile').click();
    $('#cmYdkFile').onchange = async e => {
      const f = e.target.files[0];
      if (!f) return;
      const { deck: newDk, miss } = parseDeckFileText(f.name, await f.text());
      const total = newDk.main.length + newDk.extra.length + newDk.side.length;
      if (!total) {
        api.toast('Không đọc được lá bài nào từ file này');
        e.target.value = '';
        return;
      }
      decks = loadBuiltDecks();
      decks.push(newDk);
      saveBuiltDecks(decks, newDk.id);
      state.deckId = newDk.id;

      const m = curMap();
      if (!m || m._seed || (m.nodes && m.nodes.length > 0 && m.deckId && m.deckId !== newDk.id)) {
        state.maps.push({
          id: 'm' + Date.now(),
          name_vi: 'Combo: ' + newDk.name,
          name_en: 'Combo: ' + newDk.name,
          deckId: newDk.id,
          nodes: [],
          edges: [],
        });
        state.idx = state.maps.length - 1;
        state.selectedNodeId = null;
        persistMaps();
      } else if (m && !m._seed) {
        m.deckId = newDk.id;
        persistMaps();
      }

      drawAll();
      api.toast(`Đã nạp Deck "${newDk.name}" (${total} lá)` + (miss ? ` • thiếu ${miss} mã` : ''));
      e.target.value = '';
    };

    $('#cmDraw5').onclick = () => {
      const dk = curDeck();
      if (!dk || (dk.main || []).length < 5) return api.toast('Main Deck cần có ít nhất 5 lá để rút thử tay mở bài!');
      const pool = dk.main.slice();
      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      const hand5 = pool.slice(0, 5).map(x => {
        const c = byId.get(slotId(x));
        return c ? makeCardEntry(c, slotSpec(x)) : null;
      }).filter(Boolean);
      const m = ensureEditableMap();
      if (!m) return;
      const nid = 'n' + Date.now().toString(36);
      const stIdx = countStarters(m) + 1;
      m.nodes.push({ id: nid, role: 'starter', starterId: nid, title: `Starter ${stIdx}: Tay 5 lá`, cards: hand5, x: 84, y: nextBottomLaneY(m) });
      state.selectedNodeId = nid;
      state.addMode = 'step';
      syncAddModeBtns();
      persistMaps();
      drawAll();
      api.toast('Đã thêm chuỗi Starter 5 lá mở bài ở hàng dưới!');
    };

    if ($('#cmGoDeck')) {
      $('#cmGoDeck').onclick = () => {
        if (state.deckId) localStorage.setItem(LS_CUR_DECK, state.deckId);
        api.openTab('deck');
      };
    }

    // 3 chế độ bấm thẻ trong khay Deck
    $('#cmModeStarter').onclick = () => {
      state.pendingBranch = null;
      state.addMode = 'starter';
      syncAddModeBtns();
    };
    $('#cmModeStep').onclick = () => {
      state.addMode = 'step';
      syncAddModeBtns();
    };
    $('#cmModeInto').onclick = () => {
      state.pendingBranch = null;
      if (!state.selectedNodeId && curMap() && curMap().nodes.length) {
        state.selectedNodeId = curMap().nodes[curMap().nodes.length - 1].id;
      }
      state.addMode = 'into';
      syncAddModeBtns();
      drawCanvas();
    };

    // Nút tạo nhanh Chuỗi Starter mới ở hàng dưới & Nút Bị dính Handtrap ngay trên thanh công cụ Canvas
    $('#cmQuickStarter').onclick = () => {
      state.pendingBranch = null;
      state.linkFrom = null;
      state.selectedNodeId = null;
      state.addMode = 'starter';
      syncAddModeBtns();
      drawCanvas();
      api.toast('🌟 Hãy bấm các lá mở bài ở cột Deck để tạo thêm các chuỗi Starter bên dưới!');
    };

    $('#cmQuickHt').onclick = e => {
      const m = curMap();
      const selNode = (m && state.selectedNodeId) ? m.nodes.find(n => n.id === state.selectedNodeId) : null;
      if (!selNode) return api.toast('Hãy bấm chọn 1 bước trên sơ đồ trước');
      openHandtrapPivotPopover(selNode, e.clientX, e.clientY);
    };

    $('#cmMergeMode').onclick = () => {
      if (state.locked) return api.toast('Đang bật khóa sửa — hãy mở khóa trước');
      state.mergeMode = !state.mergeMode;
      state.mergeFirstIdx = null;
      state.cutMode = false;
      state.linkFrom = null;
      state.pendingBranch = null;
      state.selectedEdgeIdx = null;
      closePopover();
      updateStatusHeader();
      drawEdges();
      if (state.mergeMode) api.toast('🔀 Bấm chọn sợi dây thứ 1, rồi bấm tiếp sợi dây thứ 2 để hợp nhất!');
    };

    $('#cmCutMode').onclick = () => {
      if (state.locked) return api.toast('Đang bật khóa sửa — hãy mở khóa trước');
      state.cutMode = !state.cutMode;
      state.mergeMode = false;
      state.mergeFirstIdx = null;
      state.linkFrom = null;
      state.pendingBranch = null;
      state.selectedEdgeIdx = null;
      closePopover();
      updateStatusHeader();
      drawEdges();
      if (state.cutMode) api.toast('✂️ Bấm vào bất kỳ sợi dây nào trên sơ đồ để xóa ngay!');
    };

    $('#cmUndo').onclick = () => performUndo();

    if (window.__ygoMapKeyHandler) window.removeEventListener('keydown', window.__ygoMapKeyHandler);
    window.__ygoMapKeyHandler = ev => {
      if (typeof document !== 'undefined' && document.body && document.body.contains && !document.body.contains(box)) return;
      const t = ev.target;
      const inField = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
      if ((ev.ctrlKey || ev.metaKey) && !ev.shiftKey && ev.key.toLowerCase() === 'z' && !inField) {
        ev.preventDefault();
        performUndo();
        return;
      }
      if (ev.key === 'Escape') {
        if (state.cutMode || state.mergeMode || state.linkFrom || state.pendingBranch || state.selectedEdgeIdx != null || popHost.innerHTML) {
          state.cutMode = false;
          state.mergeMode = false;
          state.mergeFirstIdx = null;
          state.linkFrom = null;
          state.pendingBranch = null;
          state.selectedEdgeIdx = null;
          closePopover();
          drawCanvas();
        } else if (state.expandedCanvas) {
          toggleExpandedCanvas(false);
        }
        return;
      }
      if ((ev.key === 'Delete' || ev.key === 'Backspace') && !inField && state.selectedEdgeIdx != null && !state.locked) {
        ev.preventDefault();
        const curM = curMap();
        const selE = curM && curM.edges[state.selectedEdgeIdx];
        if (selE && selE.mergeId && getMergeGroupIndices(curM, state.selectedEdgeIdx).length > 1) {
          deleteMergeGroup(selE.mergeId);
        } else {
          deleteEdgeAt(state.selectedEdgeIdx);
        }
      }
    };
    window.addEventListener('keydown', window.__ygoMapKeyHandler);

    let trayTm;
    $('#cmFilter').oninput = e => {
      clearTimeout(trayTm);
      trayTm = setTimeout(() => { state.trayQuery = e.target.value; renderDeckTray(); }, 120);
    };

    if (SMART && cards && cards.length) {
      SMART.attachAutocomplete($('#cmExtSearch'), {
        getCards: () => cards,
        onSelect: picked => {
          $('#cmExtSearch').value = '';
          addCardToCombo(picked, null);
        },
      });
    }

    const syncTrayCollapse = () => {
      $('#cmapLayout').classList.toggle('tray-collapsed', state.trayCollapsed);
      $('#cmExpandTray').style.display = state.trayCollapsed ? '' : 'none';
    };
    $('#cmToggleTray').onclick = () => { state.trayCollapsed = true; syncTrayCollapse(); };
    $('#cmExpandTray').onclick = () => { state.trayCollapsed = false; syncTrayCollapse(); };

    const syncActPanelCollapse = () => {
      const p = $('#cmActPanel');
      const b = $('#cmToggleActPanel');
      if (p) p.style.display = state.actPanelCollapsed ? 'none' : '';
      if (b) b.textContent = state.actPanelCollapsed ? '🏷️ Hiện bảng nhãn ▾' : '🏷️ Ẩn bảng nhãn ▴';
    };
    $('#cmToggleActPanel').onclick = () => {
      state.actPanelCollapsed = !state.actPanelCollapsed;
      syncActPanelCollapse();
    };

    // Chuyển nhóm tab Hành động nối tiếp & ô nhập trực tiếp
    $('#cmActTabs').querySelectorAll('button').forEach(btn => {
      btn.onclick = () => {
        state.actGroup = btn.dataset.grp;
        renderActionPills();
      };
    });
    $('#cmActKind').onchange = e => {
      state.actionKind = e.target.value;
      if (state.actionKind !== 'handtrap') state.actionHtCard = '';
      renderActionPills();
    };
    $('#cmCustomAct').oninput = e => {
      state.actionLabel = e.target.value;
      renderActionPills();
    };
    $('#cmCustomSub').oninput = e => {
      state.actionSub = e.target.value;
    };
    $('#cmSaveAct').onclick = () => {
      const lbl = $('#cmCustomAct').value.trim();
      if (!lbl) return api.toast('Hãy nhập nhãn chính vào ô trước khi lưu mẫu');
      const sub = $('#cmCustomSub').value.trim();
      const kind = $('#cmActKind').value || 'normal';
      customActs.push({ label: lbl, sub, kind });
      saveCustomActs(customActs);
      state.actGroup = 'custom';
      renderActionPills();
      api.toast(`⭐ Đã lưu nhãn "${lbl}" vào danh sách mẫu riêng!`);
    };

    $('#cmAddEmpty').onclick = e => {
      if (state.locked) return api.toast('Đang khóa sửa');
      const m = ensureEditableMap();
      if (!m) return;
      const nid = 'n' + Date.now().toString(36);
      const isStarter = state.addMode === 'starter' || !state.selectedNodeId;
      const parent = (!isStarter && state.selectedNodeId) ? m.nodes.find(n => n.id === state.selectedNodeId) : null;
      const stIdx = countStarters(m) + 1;
      const stepNum = parent ? nextStepNumForStarter(m, parent) : 1;
      const ownerStId = parent ? findOwnerStarterId(m, parent.id) : nid;
      const newNode = {
        id: nid,
        role: isStarter ? 'starter' : 'step',
        starterId: isStarter ? nid : ownerStId,
        title: isStarter ? `Starter ${stIdx}` : `B${stepNum}: Bước mới`,
        cards: [],
        x: parent ? (parent.x || 0) + NODE_W + GAP_X : 84,
        y: parent ? (parent.y || 28) : nextBottomLaneY(m),
      };
      m.nodes.push(newNode);
      if (parent) {
        m.edges.push({
          from: parent.id,
          to: nid,
          label: ($('#cmCustomAct').value || state.actionLabel || '').trim(),
          sub: ($('#cmCustomSub').value || '').trim(),
          kind: $('#cmActKind').value || 'normal',
        });
      }
      state.selectedNodeId = nid;
      persistMaps();
      drawAll();
      openNodePopover(newNode, e.clientX, e.clientY);
    };

    // Quản lý Sơ đồ Combo trên thanh tiêu đề
    $('#mapSel').onchange = e => {
      closePopover();
      state.idx = Number(e.target.value);
      state.selectedNodeId = null;
      state.linkFrom = null;
      state.pendingBranch = null;
      const dp = defaultPan();
      state.panX = dp.x;
      state.panY = dp.y;
      state.scale = 1;
      const m = curMap();
      if (m && m.deckId && decks.some(d => d.id === m.deckId)) {
        state.deckId = m.deckId;
      }
      drawAll();
      syncZoomHud();
    };

    $('#mNew').onclick = () => {
      const dk = curDeck();
      const defName = dk ? `Combo: ${dk.name}` : 'Sơ đồ Combo mới';
      const name = prompt('Tên sơ đồ combo mới:', defName);
      if (!name) return;
      state.maps.push({
        id: 'm' + Date.now(),
        name_vi: name.trim(),
        name_en: name.trim(),
        deckId: dk ? dk.id : '',
        nodes: [],
        edges: [],
      });
      state.idx = state.maps.length - 1;
      state.selectedNodeId = null;
      state.pendingBranch = null;
      state.locked = false;
      syncLockBtn();
      persistMaps();
      drawAll();
    };

    $('#mRen').onclick = () => {
      const m = curMap();
      if (!m || m._seed) return api.toast('Không đổi tên sơ đồ mẫu có sẵn');
      const v = prompt('Đổi tên sơ đồ:', m.name_vi || m.name_en || '');
      if (v && v.trim()) {
        m.name_vi = m.name_en = v.trim();
        persistMaps();
        refreshMapSelect();
      }
    };

    $('#mAuto').onclick = () => {
      const m = curMap();
      if (!m) return;
      normalizeStarterStepNumbers(m);
      autoLayout(m, true);
      const dp = defaultPan();
      state.panX = dp.x;
      state.panY = dp.y;
      if (!m._seed) persistMaps();
      drawCanvas();
      api.toast('Đã căn thẳng cột các Starter bên trái & đánh lại số bước B1, B2... theo từng Starter!');
    };

    $('#mFit').onclick = () => fitAllNodes(true);

    $('#mLock').onclick = () => {
      closePopover();
      state.locked = !state.locked;
      state.linkFrom = null;
      state.pendingBranch = null;
      syncLockBtn();
      drawCanvas();
    };

    $('#mClrNodes').onclick = () => {
      const m = curMap();
      if (!m || m._seed) return api.toast('Không làm trống sơ đồ mẫu');
      if (!confirm('Xóa toàn bộ các bước & mũi tên trong sơ đồ này để vẽ lại từ đầu?')) return;
      closePopover();
      m.nodes = [];
      m.edges = [];
      state.selectedNodeId = null;
      state.linkFrom = null;
      state.pendingBranch = null;
      persistMaps();
      drawAll();
    };

    $('#mDel').onclick = () => {
      const m = curMap();
      if (!m || m._seed) return api.toast('Không xóa được sơ đồ mẫu có sẵn');
      if (!confirm(`Xóa sơ đồ "${m.name_vi || m.name_en}"?`)) return;
      closePopover();
      state.maps.splice(state.idx, 1);
      state.idx = Math.max(0, state.maps.length - 1);
      state.selectedNodeId = null;
      persistMaps();
      drawAll();
    };

    $('#mExp').onclick = () => {
      const m = curMap();
      if (!m) return;
      const { _seed, ...r } = m;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(r, null, 2)], { type: 'application/json' }));
      a.download = ((r.name_vi || r.id || 'combo-map').replace(/[^\w\- ]+/g, '_')) + '.json';
      a.click();
    };

    $('#mImp').onclick = () => $('#mFile').click();
    $('#mFile').onchange = async e => {
      const f = e.target.files[0];
      if (!f) return;
      try {
        const j = JSON.parse(await f.text());
        if (!Array.isArray(j.nodes) || !Array.isArray(j.edges)) throw new Error('format');
        j.id = 'm' + Date.now();
        j.name_vi = j.name_vi || j.name_en || f.name.replace(/\.json$/i, '') || 'Sơ đồ nhập';
        normalizeStarterStepNumbers(j);
        state.maps.push(j);
        state.idx = state.maps.length - 1;
        state.selectedNodeId = null;
        persistMaps();
        drawAll();
        api.toast('Đã nhập sơ đồ combo thành công');
      } catch (err) {
        api.toast('File JSON sơ đồ không hợp lệ');
      }
      e.target.value = '';
    };

    let anyNormalized = false;
    state.maps.forEach(mp => {
      if (normalizeStarterStepNumbers(mp) && !mp._seed) anyNormalized = true;
    });
    if (anyNormalized) persistMaps();

    drawAll();
  }

  window.YGO_MAP = { render };
})();
