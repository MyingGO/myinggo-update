(function () {
  'use strict';
  const LS_USER = 'ygo_user_data_v1', LS_CACHE = 'ygo_card_cache_v1', LS_DECKS = 'ygo_decks_v1', LS_ART = 'ygo_card_art_v1', LS_ACTS = 'ygo_map_custom_acts_v1', LS_VI = 'ygo_vi_custom_v1', LS_DEL = 'ygo_deleted_ids_v1';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { toast('Bộ nhớ trình duyệt đầy / Storage full'); } };

  let tab = 'search';
  const cache = load(LS_CACHE, {});
  let user = load(LS_USER, { maps: [] });

  function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 2400); }

  // ---------- Dữ liệu lá bài: ưu tiên kho offline (/ygodata/cards.json), thiếu thì hỏi YGOPRODeck ----------
  let localDB = null, localLoading = null, onlineLoading = null;
  function indexCards(arr) {
    window.__ygoCards = arr;
    const m = new Map();
    arr.forEach(c => m.set(String(c.name).toLowerCase(), c));
    localDB = m; return m;
  }
  function loadLocalDB() {
    if (window.__ygoCards && window.__ygoCards.length) return Promise.resolve(localDB);
    if (localLoading) return localLoading;
    localLoading = fetch('/ygodata/cards.json').then(r => r.ok ? r.json() : null).then(arr => {
      if (!Array.isArray(arr) || !arr.length) return null;
      return indexCards(arr);
    }).catch(() => null);
    return localLoading;
  }
  function loadOnlineDB() {
    if (window.__ygoCards && window.__ygoCards.length) return Promise.resolve(window.__ygoCards);
    if (onlineLoading) return onlineLoading;
    onlineLoading = fetch('https://db.ygoprodeck.com/api/v7/cardinfo.php').then(r => r.json()).then(j => {
      const arr = (j.data || []).map(c => {
        const imgs = c.card_images || [{}];
        return {
          id: c.id, name: c.name, type: c.type, frameType: c.frameType, desc: c.desc,
          atk: c.atk, def: c.def, level: c.level, race: c.race, attribute: c.attribute, archetype: c.archetype,
          linkval: c.linkval, scale: c.scale, linkmarkers: c.linkmarkers,
          banlist_info: c.banlist_info || null,
          sets: (c.card_sets || []).map(s => ({ n: s.set_name, c: s.set_code, r: s.set_rarity })),
          img: [], small: imgs[0].image_url_small, big: imgs[0].image_url,
        };
      });
      if (arr.length) indexCards(arr);
      return arr;
    }).catch(() => { onlineLoading = null; return []; });
    return onlineLoading;
  }
  function fromLocalRecord(name) {
    if (!localDB) return null;
    const k = name.trim().toLowerCase();
    let c = localDB.get(k);
    if (!c && window.YGO_SMART && window.__ygoCards) {
      const sug = window.YGO_SMART.suggestCards(window.__ygoCards, name, 1);
      if (sug.length) c = sug[0];
    }
    if (!c) { for (const [n, v] of localDB) { if (n.includes(k)) { c = v; break; } } }
    return c || null;
  }
  function fromLocal(name) {
    const c = fromLocalRecord(name);
    if (!c) return null;
    const defSpec = window.YGO_ART ? window.YGO_ART.getDefaultSpec(c.id) : null;
    const iid = (defSpec && defSpec.imgId) || (c.img || [])[0];
    const customSrc = defSpec && (defSpec.src || defSpec.remoteSrc);
    return {
      raw: c, id: c.id, name: c.name, type: c.type, desc: c.desc, atk: c.atk, def: c.def,
      level: c.level, linkval: c.linkval, scale: c.scale, attribute: c.attribute, race: c.race,
      small: customSrc || (iid ? '/ygodata/images/small/' + iid + '.jpg' : c.small),
      remoteSmall: customSrc || (iid ? `https://images.ygoprodeck.com/images/cards_small/${iid}.jpg` : c.small),
      big: customSrc || (iid ? `https://images.ygoprodeck.com/images/cards/${iid}.jpg` : (c.big || c.small)),
    };
  }
  window.addEventListener('message', e => {
    if (e.data && e.data.type === 'ygo_data_updated') {
      window.__ygoCards = null; localDB = null; localLoading = null;
      if (window.YGO_BAN) window.YGO_BAN.clearBanCache();
      const jobs = [loadLocalDB()];
      if (window.YGO_ART) jobs.push(window.YGO_ART.loadSpecial(true));
      if (window.YGO_BAN) jobs.push(window.YGO_BAN.loadBanMeta(true));
      if (window.YGO_VI) jobs.push(window.YGO_VI.loadViCache(true));
      Promise.all(jobs).then(() => { toast('Đã nạp kho bài, Banlist & gói Art mới'); render(); });
    }
  });

  const queue = []; let busy = false;
  function fetchCard(name) {
    const key = name.trim().toLowerCase();
    return loadLocalDB().then(() => {
      const l = fromLocal(name); if (l) return l;
      if (cache[key]) return cache[key];
      return new Promise(res => { queue.push({ name, key, res }); pump(); });
    });
  }
  async function pump() {
    if (busy) return; busy = true;
    while (queue.length) {
      const { name, key, res } = queue.shift();
      if (cache[key]) { res(cache[key]); continue; }
      let card = null;
      for (const q of ['name=' + encodeURIComponent(name), 'fname=' + encodeURIComponent(name)]) {
        try {
          const r = await fetch('https://db.ygoprodeck.com/api/v7/cardinfo.php?' + q);
          if (r.ok) { const j = await r.json(); if (j.data && j.data[0]) { card = j.data[0]; break; } }
        } catch (e) { }
      }
      if (card) {
        const im = (card.card_images || [])[0] || {};
        cache[key] = { id: card.id, name: card.name, type: card.type, desc: card.desc, atk: card.atk, def: card.def, level: card.level, attribute: card.attribute, race: card.race, small: im.image_url_small, big: im.image_url };
        save(LS_CACHE, cache);
      }
      res(cache[key] || null);
      await new Promise(r => setTimeout(r, 70)); // giữ dưới giới hạn 20 req/giây của API
    }
    busy = false;
  }
  function cardImg(name, big) {
    const img = document.createElement('img');
    img.alt = name; img.title = name; img.loading = 'lazy';
    img.src = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="63" height="92"><rect width="100%" height="100%" fill="#222633"/><text x="50%" y="50%" fill="#889" font-size="9" text-anchor="middle">...</text></svg>');
    fetchCard(name).then(c => {
      if (c && c.small) {
        if (c.remoteSmall) img.onerror = () => { img.onerror = null; img.src = c.remoteSmall; };
        img.src = big ? c.big : c.small;
      } else img.title = name + ' (không tìm thấy / not found)';
    });
    img.onclick = () => showCard(name);
    return img;
  }
  async function showCard(name, overrideSpec) {
    const box = $('#modalBox'); box.innerHTML = '<p class="muted">Đang tải / Loading…</p>'; $('#modal').classList.add('show');
    if (window.YGO_ART) await window.YGO_ART.loadSpecial();
    const c = await fetchCard(name);
    if (!c) { box.innerHTML = `<p>Không tìm thấy lá bài <b>${esc(name)}</b>. Kiểm tra lại tên tiếng Anh chính xác.<br>Card not found.</p>`; return; }
    const fmtStat = v => v < 0 ? '?' : v;
    const stats = [c.type, c.attribute, c.race, c.level != null ? 'Lv ' + c.level : '', c.linkval != null ? 'Link ' + c.linkval : '', c.scale != null ? 'Scale ' + c.scale : '', c.atk != null ? 'ATK ' + fmtStat(c.atk) : '', c.def != null ? 'DEF ' + fmtStat(c.def) : ''].filter(Boolean).join(' • ');
    const effBadges = (c.raw && window.YGO_EFFECTS) ? window.YGO_EFFECTS.renderBadgesHTML(c.raw, false) : '';
    box.innerHTML = `<div id="mcVisual"></div><div style="flex:1;min-width:240px"><h2 style="margin-top:0">${esc(c.name)}</h2><p class="muted">${esc(stats)}</p>${effBadges}<p style="white-space:pre-wrap;margin-bottom:8px">${esc(c.desc)}</p><div id="mcViBox"></div>
      ${c.raw && window.YGO_ART ? '<div class="row"><button class="small primary" id="mcArt">🎨 Đổi Art / Overframe / Manga</button></div>' : ''}
      <p class="hint">Dữ liệu &amp; hình ảnh: YGOPRODeck / Wiki. Hãy luôn đối chiếu text chính thức.</p></div>`;
    if (window.YGO_VI) window.YGO_VI.mountTranslationBox($('#mcViBox', box), c, { toast });
    const visHost = $('#mcVisual', box);
    if (c.raw && window.YGO_ART) {
      visHost.appendChild(window.YGO_ART.renderCardVisual(c.raw, overrideSpec, 'lg'));
      $('#mcArt', box).onclick = () => window.YGO_ART.openPicker(c.raw, {
        currentSpec: overrideSpec,
        toast,
        onApplyAll: () => render(),
      });
    } else {
      const im = document.createElement('img'); im.src = c.big || c.small; im.alt = c.name; visHost.appendChild(im);
    }
  }
  $('#modal').onclick = e => { if (e.target.id === 'modal') $('#modal').classList.remove('show'); };

  // ---------- Hệ thống Tự động Đồng bộ 2 chiều (Cloud + Ổ đĩa + Gộp thông minh Smart Merge) ----------
  let syncState = {
    busy: false,
    lastHash: '',
    status: {
      repo: '',
      can_push: false,
      can_pull: false,
      auto_sync: true,
      cipher: '',
      last_sync_at: '',
      last_error: '',
    },
  };
  let pushTimer = null;

  function isEmptyPlaceholderDeck(d) {
    if (!d || typeof d !== 'object') return true;
    if ((d.main && d.main.length) || (d.extra && d.extra.length) || (d.side && d.side.length)) return false;
    const nm = String(d.name || '').trim();
    return nm === '' || nm === 'Deck mới / New deck';
  }

  function collectLocalWorkspace() {
    const builtDecks = load(LS_DECKS, []);
    const curUser = load(LS_USER, { maps: [] });
    const maps = (curUser.maps || user.maps || []).filter(m => m && !m._seed);
    const customActs = load(LS_ACTS, []);
    const artPrefs = { ...load('ygo_art_prefs_v1', {}), ...load(LS_ART, {}) };
    const viCustom = load(LS_VI, {});
    const deleted = load(LS_DEL, {});
    return {
      version: 2,
      built_decks: builtDecks,
      maps,
      custom_acts: customActs,
      art_prefs: artPrefs,
      vi_custom: viCustom,
      deleted,
    };
  }

  function mergeWorkspacesClient(w1, w2) {
    const a = w1 || {};
    const b = w2 || {};
    const deleted = { ...(a.deleted || {}), ...(b.deleted || {}) };
    Object.keys(deleted).forEach(k => {
      deleted[k] = Math.max(Number((a.deleted || {})[k] || 0), Number((b.deleted || {})[k] || 0));
    });

    const decksA = Array.isArray(a.built_decks) ? a.built_decks : [];
    const decksB = Array.isArray(b.built_decks) ? b.built_decks : [];
    const hasRealDeck = [...decksA, ...decksB].some(d => !isEmptyPlaceholderDeck(d));
    const deckMap = new Map();
    [...decksA, ...decksB].forEach(d => {
      if (!d || !d.id) return;
      if (hasRealDeck && isEmptyPlaceholderDeck(d)) return;
      const upd = Number(d.updatedAt || 0);
      if ((deleted[d.id] || 0) > upd) return;
      const prev = deckMap.get(d.id);
      if (!prev) {
        deckMap.set(d.id, d);
      } else {
        const pUpd = Number(prev.updatedAt || 0);
        if (upd > pUpd) deckMap.set(d.id, d);
        else if (upd === pUpd) {
          const cLen = (d.main || []).length + (d.extra || []).length + (d.side || []).length;
          const pLen = (prev.main || []).length + (prev.extra || []).length + (prev.side || []).length;
          if (cLen > pLen) deckMap.set(d.id, d);
        }
      }
    });

    const mapsA = (Array.isArray(a.maps) ? a.maps : []).filter(m => m && m.id && !m._seed);
    const mapsB = (Array.isArray(b.maps) ? b.maps : []).filter(m => m && m.id && !m._seed);
    const mapDict = new Map();
    [...mapsA, ...mapsB].forEach(m => {
      const upd = Number(m.updatedAt || 0);
      if ((deleted[m.id] || 0) > upd) return;
      const prev = mapDict.get(m.id);
      if (!prev) {
        mapDict.set(m.id, m);
      } else {
        const pUpd = Number(prev.updatedAt || 0);
        if (upd > pUpd) mapDict.set(m.id, m);
        else if (upd === pUpd) {
          const cScore = (m.nodes || []).length + (m.edges || []).length;
          const pScore = (prev.nodes || []).length + (prev.edges || []).length;
          if (cScore > pScore) mapDict.set(m.id, m);
        }
      }
    });

    const actSet = new Set();
    const mergedActs = [];
    [...(a.custom_acts || []), ...(b.custom_acts || [])].forEach(act => {
      if (!act || !act.label) return;
      const k = `${act.label.trim()}|${(act.sub || '').trim()}|${act.kind || 'normal'}`;
      if (!actSet.has(k)) {
        actSet.add(k);
        mergedActs.push({ label: act.label.trim(), sub: (act.sub || '').trim(), kind: act.kind || 'normal' });
      }
    });

    return {
      version: 2,
      built_decks: [...deckMap.values()],
      maps: [...mapDict.values()],
      custom_acts: mergedActs,
      art_prefs: { ...(b.art_prefs || {}), ...(a.art_prefs || {}) },
      vi_custom: { ...(b.vi_custom || {}), ...(a.vi_custom || {}) },
      deleted,
    };
  }

  function applyWorkspaceToClient(ws) {
    if (!ws || typeof ws !== 'object') return;
    if (Array.isArray(ws.built_decks)) save(LS_DECKS, ws.built_decks);
    if (Array.isArray(ws.maps)) {
      user.maps = ws.maps;
      save(LS_USER, user);
    }
    if (Array.isArray(ws.custom_acts)) save(LS_ACTS, ws.custom_acts);
    if (ws.art_prefs && typeof ws.art_prefs === 'object') {
      save(LS_ART, ws.art_prefs);
      if (window.YGO_ART && window.YGO_ART.reloadDefaults) window.YGO_ART.reloadDefaults();
    }
    if (ws.vi_custom && typeof ws.vi_custom === 'object') save(LS_VI, ws.vi_custom);
    if (ws.deleted && typeof ws.deleted === 'object') save(LS_DEL, ws.deleted);
  }

  function updateSyncPillUI(customText) {
    const pill = $('#ygoSyncPill');
    const txt = $('#ygoSyncTxt');
    if (!pill || !txt) return;
    pill.classList.toggle('syncing', !!syncState.busy);
    pill.classList.toggle('offline', !syncState.busy && !syncState.status.can_pull);
    if (customText) {
      txt.textContent = customText;
      return;
    }
    if (syncState.busy) {
      txt.textContent = '⏳ Đang đồng bộ...';
    } else if (syncState.status.can_push) {
      const t = syncState.status.last_sync_at ? ` (${syncState.status.last_sync_at})` : '';
      txt.textContent = `☁️ Tự động đồng bộ${t}`;
    } else if (syncState.status.can_pull) {
      txt.textContent = '☁️ Đã nối Cloud (Bấm để bật đẩy 2 chiều)';
    } else {
      txt.textContent = '💾 Đã lưu trên máy';
    }
  }

  async function runWorkspaceSync(mode = 'auto', forceCloud = false, silent = true) {
    if (syncState.busy && !forceCloud) return;
    syncState.busy = true;
    updateSyncPillUI();
    try {
      const localWs = collectLocalWorkspace();
      const prevDeckCnt = (localWs.built_decks || []).filter(d => !isEmptyPlaceholderDeck(d)).length;
      const prevMapCnt = (localWs.maps || []).length;
      const prevJson = JSON.stringify({ d: localWs.built_decks, m: localWs.maps });

      const resp = await fetch('/api/yugioh_combo/sync_workspace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspace: localWs, mode, force_cloud: forceCloud }),
      });
      if (resp.ok) {
        const res = await resp.json();
        if (res && res.ok && res.workspace) {
          if (res.sync_status) syncState.status = res.sync_status;
          syncState.lastHash = res.content_hash || '';
          const nextJson = JSON.stringify({ d: res.workspace.built_decks, m: res.workspace.maps });
          if (nextJson !== prevJson) {
            applyWorkspaceToClient(res.workspace);
            const newDeckCnt = (res.workspace.built_decks || []).filter(d => !isEmptyPlaceholderDeck(d)).length;
            const newMapCnt = (res.workspace.maps || []).length;
            // Không vẽ đè lại nếu người dùng đang giữ chuột kéo nút trên sơ đồ
            const isDraggingOnMap = document.querySelector('.mnode.linking') || (document.activeElement && /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName));
            if (!isDraggingOnMap) render();
            if (newDeckCnt > prevDeckCnt || newMapCnt > prevMapCnt || !silent) {
              toast(`☁️ Đã đồng bộ (${newDeckCnt} Deck • ${newMapCnt} Sơ đồ Combo)!`);
            }
          } else if (!silent) {
            toast(`☁️ Đã đồng bộ mới nhất (${syncState.status.deck_count || prevDeckCnt} Deck • ${syncState.status.map_count || prevMapCnt} Sơ đồ Combo)!`);
          }
        }
      }
    } catch (e) {
      if (!silent) toast('Chưa kết nối được máy chủ đồng bộ');
    } finally {
      syncState.busy = false;
      updateSyncPillUI();
    }
  }

  window.YGO_SYNC = {
    markChanged() {
      clearTimeout(pushTimer);
      updateSyncPillUI('⏳ Chờ lưu đồng bộ...');
      pushTimer = setTimeout(() => runWorkspaceSync('push', false, true), 1800);
    },
    markDeleted(itemId) {
      if (!itemId) return;
      const del = load(LS_DEL, {});
      del[String(itemId)] = Date.now();
      save(LS_DEL, del);
      this.markChanged('delete');
    },
    syncNow(force = true) {
      clearTimeout(pushTimer);
      return runWorkspaceSync('sync', force, false);
    },
  };

  // Tự động đồng bộ khi mở trang, khi chuyển lại cửa sổ (focus/visibility) và định kỳ mỗi 20 giây
  setTimeout(() => runWorkspaceSync('pull', true, true), 400);
  setInterval(() => {
    if (!document.hidden && !syncState.busy) runWorkspaceSync('pull', false, true);
  }, 20000);
  window.addEventListener('focus', () => {
    if (!syncState.busy) runWorkspaceSync('pull', false, true);
  });
  window.addEventListener('storage', e => {
    if (e.key === LS_DECKS || e.key === LS_USER) {
      user = load(LS_USER, { maps: [] });
      render();
    }
  });
  if ($('#ygoSyncPill')) {
    $('#ygoSyncPill').onclick = () => {
      if (tab !== 'manage') {
        tab = 'manage';
        render();
      }
      window.YGO_SYNC.syncNow(true);
    };
  }

  // ---------- Giao diện ----------
  function render() {
    document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    const v = $('#view');
    const sharedApi = {
      toast, showCard,
      openTab: t => { tab = t; render(); },
      loadCards: () => loadLocalDB().then(() => window.__ygoCards || []),
      loadOnlineCards: () => loadOnlineDB(),
    };
    if (tab === 'search') window.YGO_SEARCH.render(v, sharedApi);
    else if (tab === 'deck') window.YGO_DECK.render(v, sharedApi);
    else if (tab === 'map') window.YGO_MAP.render(v, { ...sharedApi, cardImg, getUser: () => user, setUser: u => { user = u; save(LS_USER, user); } });
    else renderManage(v);
  }

  // ---------- Quản lý: Đồng bộ tự động 2 máy + Sao lưu / Khôi phục gộp thông minh ----------
  function renderManage(v) {
    const builtDecks = load(LS_DECKS, []);
    const maps = user.maps || [];
    const artPrefs = load(LS_ART, {});
    const artCnt = Object.keys(artPrefs).length;
    const st = syncState.status || {};

    const syncStatusHtml = st.can_push
      ? `<span style="color:#4ade80;font-weight:700">✅ Đang bật Tự động Đồng bộ 2 chiều qua Cloud (${esc(st.repo)}) &amp; Ổ đĩa</span>`
      : (st.can_pull
        ? `<span style="color:#fbbf24;font-weight:700">⚠️ Đang ở chế độ Nhận dữ liệu từ Cloud (${esc(st.repo)}) — Hãy dán Mã đồng bộ bên dưới để máy này cũng tự đẩy Deck/Combo mới lên!</span>`
        : `<span style="color:#94a3b8">💾 Đang lưu cục bộ trên ổ đĩa — Dán Mã đồng bộ bên dưới để nối nhiều máy qua mạng</span>`);

    v.innerHTML = `<h2>Quản lý &amp; Đồng bộ tự động giữa các máy</h2>
    <div class="card" style="border-color:rgba(52,211,153,.45);background:linear-gradient(180deg,rgba(6,78,59,.18),rgba(30,32,41,.95))">
      <div class="row" style="justify-content:space-between;margin-top:0">
        <h3 style="margin:0">☁️ Đồng bộ Tự động 2 chiều (Build Deck &amp; Combo nhiều máy)</h3>
        <button class="primary" id="btnSyncNow">🔄 Đồng bộ &amp; Gộp ngay</button>
      </div>
      <p style="margin:8px 0">${syncStatusHtml}${st.last_sync_at ? ` • Cập nhật lúc <b>${esc(st.last_sync_at)}</b>` : ''}</p>
      <p class="hint" style="margin:4px 0 10px">💡 <b>Cơ chế Gộp thông minh (Smart Merge)</b>: Bạn build <b>Deck A</b> ở máy này, sang máy khác build <b>Deck B</b> và dựng <b>Sơ đồ Combo B</b> — hệ thống sẽ <b>tự động gộp cả hai</b> lại và hiển thị trên tất cả các máy sau vài giây mà không bao giờ ghi đè mất bài của nhau!</p>
      <div class="row" style="gap:8px">
        ${st.cipher ? `<button class="small" id="btnCopySyncKey" title="Copy mã này đem sang máy khác dán vào ô bên cạnh là 2 máy tự động đồng bộ 2 chiều">🔑 Copy Mã đồng bộ cho máy khác</button>` : ''}
        <input id="inpSyncKey" placeholder="Dán Mã đồng bộ (YGS1_...) từ máy chính vào đây nếu là máy mới..." style="flex:1;min-width:220px;padding:6px 12px;font-size:13px">
        <button class="small primary" id="btnSaveSyncKey">🔗 Kết nối máy này</button>
      </div>
    </div>

    <div class="card" style="margin-top:16px">
      <h3 style="margin-top:0">Deck đã xây của bạn / Built Decks (${builtDecks.length})</h3>
      ${builtDecks.length ? builtDecks.map(d => `<div class="row"><b style="flex:1">${esc(d.name)} <span class="badge">${esc((d.format || 'tcg').toUpperCase())}</span> <span class="badge">Main ${(d.main || []).length} • Extra ${(d.extra || []).length} • Side ${(d.side || []).length}</span></b><button class="small primary" data-combo-dk="${esc(d.id)}">🕸️ Tạo Combo</button><button class="small" data-open-dk="${esc(d.id)}">→ Xây deck</button><button class="small danger" data-del-dk="${esc(d.id)}">Xóa</button></div>`).join('') : '<p class="muted">Chưa có deck nào. Vào tab <b>Xây deck</b> để tạo.</p>'}
    </div>

    <div class="card" style="margin-top:16px">
      <h3 style="margin-top:0">Sơ đồ combo của bạn / Custom Combo Maps (${maps.length})</h3>
      ${maps.length ? maps.map((m, idx) => `<div class="row"><b style="flex:1">${esc(m.name_vi || m.name_en || ('Sơ đồ #' + (idx + 1)))} <span class="badge">${(m.nodes || []).length} nút</span></b><button class="small primary" data-open-map="${idx}">🕸️ Mở sơ đồ</button><button class="small danger" data-del-map="${idx}">Xóa</button></div>`).join('') : '<p class="muted">Chưa có sơ đồ riêng. Vào tab <b>Sơ đồ combo</b> để vẽ.</p>'}
    </div>

    <div class="card" style="margin-top:16px">
      <h3 style="margin-top:0">Sao lưu &amp; Nhập gộp bằng File JSON / Backup &amp; Smart Merge</h3>
      <p class="muted" style="margin-top:0">Gói sao lưu bao gồm: <b>${builtDecks.length}</b> Deck đã xây, <b>${maps.length}</b> Sơ đồ combo và <b>${artCnt}</b> thiết lập Alt Art / Overframe / Manga mặc định.</p>
      <div class="row">
        <button class="primary" id="exp">⬇ Xuất file sao lưu JSON</button>
        <button id="imp" title="Gộp thêm các Deck &amp; Sơ đồ trong file JSON vào máy này (không xóa Deck đang có)">⬆ Nhập &amp; Gộp (Merge) file JSON</button>
        <input type="file" id="file" accept=".json" style="display:none">
      </div>
      <p class="hint">Khi nhập file JSON, hệ thống sẽ <b>gộp chung (Merge)</b> các Deck và Sơ đồ mới từ file vào máy hiện tại, không làm mất các Deck bạn đã tạo riêng trên máy này.</p>
    </div>`;

    $('#btnSyncNow', v).onclick = () => window.YGO_SYNC.syncNow(true);
    if ($('#btnCopySyncKey', v)) {
      $('#btnCopySyncKey', v).onclick = () => {
        navigator.clipboard.writeText(st.cipher || '').then(() => {
          toast('🔑 Đã copy Mã đồng bộ! Hãy dán vào ô Kết nối ở máy kia (hoặc bấm Cập nhật MyingGo trên máy kia).');
        }).catch(() => toast('Không copy được'));
      };
    }
    $('#btnSaveSyncKey', v).onclick = async () => {
      const k = ($('#inpSyncKey', v).value || '').trim();
      if (!k) return toast('Hãy dán Mã đồng bộ (YGS1_...) vào ô trước');
      try {
        const resp = await fetch('/api/yugioh_combo/config_sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sync_key: k, workspace: collectLocalWorkspace() }),
        });
        const r = await resp.json();
        if (r.error) return toast(r.error);
        if (r.sync_status) syncState.status = r.sync_status;
        if (r.workspace) applyWorkspaceToClient(r.workspace);
        updateSyncPillUI();
        toast('✅ Đã kết nối & đồng bộ 2 chiều thành công!');
        render();
      } catch (e) {
        toast('Lỗi kết nối cấu hình đồng bộ');
      }
    };

    v.querySelectorAll('[data-combo-dk]').forEach(b => b.onclick = () => {
      localStorage.setItem('ygo_cur_deck_v1', b.dataset.comboDk);
      sessionStorage.setItem('ygo_combo_deck_id', b.dataset.comboDk);
      tab = 'map';
      render();
    });
    v.querySelectorAll('[data-open-dk]').forEach(b => b.onclick = () => {
      localStorage.setItem('ygo_cur_deck_v1', b.dataset.openDk);
      tab = 'deck';
      render();
    });
    v.querySelectorAll('[data-open-map]').forEach(b => b.onclick = () => {
      const m = maps[Number(b.dataset.openMap)];
      if (m && m.deckId) {
        localStorage.setItem('ygo_cur_deck_v1', m.deckId);
        sessionStorage.setItem('ygo_combo_deck_id', m.deckId);
      }
      tab = 'map';
      render();
    });
    v.querySelectorAll('[data-del-dk]').forEach(b => b.onclick = () => {
      if (!confirm('Xóa deck này? / Delete this deck?')) return;
      const delId = b.dataset.delDk;
      const next = builtDecks.filter(d => d.id !== delId);
      save(LS_DECKS, next);
      if (window.YGO_SYNC && delId) window.YGO_SYNC.markDeleted(delId);
      render();
    });
    v.querySelectorAll('[data-del-map]').forEach(b => b.onclick = () => {
      if (!confirm('Xóa sơ đồ combo này?')) return;
      const idx = Number(b.dataset.delMap);
      const delMap = (user.maps || [])[idx];
      user.maps = (user.maps || []).filter((_, i) => i !== idx);
      save(LS_USER, user);
      if (window.YGO_SYNC && delMap && delMap.id) window.YGO_SYNC.markDeleted(delMap.id);
      render();
    });
    $('#exp', v).onclick = () => {
      const payload = {
        version: 2,
        exported_at: new Date().toISOString(),
        ...collectLocalWorkspace(),
      };
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
      a.download = 'ygo-academy-backup.json';
      a.click();
    };
    $('#imp', v).onclick = () => $('#file', v).click();
    $('#file', v).onchange = async e => {
      const f = e.target.files[0];
      if (!f) return;
      try {
        const j = JSON.parse(await f.text());
        const merged = mergeWorkspacesClient(collectLocalWorkspace(), j);
        applyWorkspaceToClient(merged);
        if (window.YGO_SYNC) window.YGO_SYNC.markChanged('import');
        toast(`✅ Đã gộp dữ liệu thành công (${merged.built_decks.length} Deck • ${merged.maps.length} Sơ đồ Combo)`);
        render();
      } catch (err) {
        toast('File JSON không hợp lệ / Invalid JSON');
      }
      e.target.value = '';
    };
  }

  document.querySelectorAll('#nav button').forEach(b => b.onclick = () => { tab = b.dataset.tab; render(); });
  render();
})();
