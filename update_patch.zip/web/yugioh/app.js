(function () {
  'use strict';
  const LS_USER = 'ygo_user_data_v1', LS_CACHE = 'ygo_card_cache_v1', LS_DECKS = 'ygo_decks_v1', LS_ART = 'ygo_art_prefs_v1';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { toast('Bộ nhớ trình duyệt đầy / Storage full'); } };

  let tab = 'search';
  const cache = load(LS_CACHE, {});
  let user = load(LS_USER, { maps: [] });

  function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 2400); }

  // ---------- Dữ liệu lá bài: ưu tiên kho offline (/ygodata/cards.json), thiếu thì hỏi YGOPRODeck ----------
  let localDB = null, localLoading = null, onlineLoading = null;
  function indexCards(arr) {
    window.__ygoCards = arr;
    const m = new Map();
    arr.forEach(c => m.set(String(c.name).toLowerCase(), c));
    localDB = m; return m;
  }
  function loadLocalDB() {
    if (window.__ygoCards && window.__ygoCards.length) return Promise.resolve(localDB);
    if (localLoading) return localLoading;
    localLoading = fetch('/ygodata/cards.json').then(r => r.ok ? r.json() : null).then(arr => {
      if (!Array.isArray(arr) || !arr.length) return null;
      return indexCards(arr);
    }).catch(() => null);
    return localLoading;
  }
  function loadOnlineDB() {
    if (window.__ygoCards && window.__ygoCards.length) return Promise.resolve(window.__ygoCards);
    if (onlineLoading) return onlineLoading;
    onlineLoading = fetch('https://db.ygoprodeck.com/api/v7/cardinfo.php').then(r => r.json()).then(j => {
      const arr = (j.data || []).map(c => {
        const imgs = c.card_images || [{}];
        return {
          id: c.id, name: c.name, type: c.type, frameType: c.frameType, desc: c.desc,
          atk: c.atk, def: c.def, level: c.level, race: c.race, attribute: c.attribute, archetype: c.archetype,
          linkval: c.linkval, scale: c.scale, linkmarkers: c.linkmarkers,
          banlist_info: c.banlist_info || null,
          sets: (c.card_sets || []).map(s => ({ n: s.set_name, c: s.set_code, r: s.set_rarity })),
          img: [], small: imgs[0].image_url_small, big: imgs[0].image_url,
        };
      });
      if (arr.length) indexCards(arr);
      return arr;
    }).catch(() => { onlineLoading = null; return []; });
    return onlineLoading;
  }
  function fromLocalRecord(name) {
    if (!localDB) return null;
    const k = name.trim().toLowerCase();
    let c = localDB.get(k);
    if (!c && window.YGO_SMART && window.__ygoCards) {
      const sug = window.YGO_SMART.suggestCards(window.__ygoCards, name, 1);
      if (sug.length) c = sug[0];
    }
    if (!c) { for (const [n, v] of localDB) { if (n.includes(k)) { c = v; break; } } }
    return c || null;
  }
  function fromLocal(name) {
    const c = fromLocalRecord(name);
    if (!c) return null;
    const defSpec = window.YGO_ART ? window.YGO_ART.getDefaultSpec(c.id) : null;
    const iid = (defSpec && defSpec.imgId) || (c.img || [])[0];
    const customSrc = defSpec && (defSpec.src || defSpec.remoteSrc);
    return {
      raw: c, id: c.id, name: c.name, type: c.type, desc: c.desc, atk: c.atk, def: c.def,
      level: c.level, linkval: c.linkval, scale: c.scale, attribute: c.attribute, race: c.race,
      small: customSrc || (iid ? '/ygodata/images/small/' + iid + '.jpg' : c.small),
      remoteSmall: customSrc || (iid ? `https://images.ygoprodeck.com/images/cards_small/${iid}.jpg` : c.small),
      big: customSrc || (iid ? `https://images.ygoprodeck.com/images/cards/${iid}.jpg` : (c.big || c.small)),
    };
  }
  window.addEventListener('message', e => {
    if (e.data && e.data.type === 'ygo_data_updated') {
      window.__ygoCards = null; localDB = null; localLoading = null;
      if (window.YGO_BAN) window.YGO_BAN.clearBanCache();
      const jobs = [loadLocalDB()];
      if (window.YGO_ART) jobs.push(window.YGO_ART.loadSpecial(true));
      if (window.YGO_BAN) jobs.push(window.YGO_BAN.loadBanMeta(true));
      if (window.YGO_VI) jobs.push(window.YGO_VI.loadViCache(true));
      Promise.all(jobs).then(() => { toast('Đã nạp kho bài, Banlist & gói Art mới'); render(); });
    }
  });

  const queue = []; let busy = false;
  function fetchCard(name) {
    const key = name.trim().toLowerCase();
    return loadLocalDB().then(() => {
      const l = fromLocal(name); if (l) return l;
      if (cache[key]) return cache[key];
      return new Promise(res => { queue.push({ name, key, res }); pump(); });
    });
  }
  async function pump() {
    if (busy) return; busy = true;
    while (queue.length) {
      const { name, key, res } = queue.shift();
      if (cache[key]) { res(cache[key]); continue; }
      let card = null;
      for (const q of ['name=' + encodeURIComponent(name), 'fname=' + encodeURIComponent(name)]) {
        try {
          const r = await fetch('https://db.ygoprodeck.com/api/v7/cardinfo.php?' + q);
          if (r.ok) { const j = await r.json(); if (j.data && j.data[0]) { card = j.data[0]; break; } }
        } catch (e) { }
      }
      if (card) {
        const im = (card.card_images || [])[0] || {};
        cache[key] = { id: card.id, name: card.name, type: card.type, desc: card.desc, atk: card.atk, def: card.def, level: card.level, attribute: card.attribute, race: card.race, small: im.image_url_small, big: im.image_url };
        save(LS_CACHE, cache);
      }
      res(cache[key] || null);
      await new Promise(r => setTimeout(r, 70)); // giữ dưới giới hạn 20 req/giây của API
    }
    busy = false;
  }
  function cardImg(name, big) {
    const img = document.createElement('img');
    img.alt = name; img.title = name; img.loading = 'lazy';
    img.src = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="63" height="92"><rect width="100%" height="100%" fill="#222633"/><text x="50%" y="50%" fill="#889" font-size="9" text-anchor="middle">...</text></svg>');
    fetchCard(name).then(c => {
      if (c && c.small) {
        if (c.remoteSmall) img.onerror = () => { img.onerror = null; img.src = c.remoteSmall; };
        img.src = big ? c.big : c.small;
      } else img.title = name + ' (không tìm thấy / not found)';
    });
    img.onclick = () => showCard(name);
    return img;
  }
  async function showCard(name, overrideSpec) {
    const box = $('#modalBox'); box.innerHTML = '<p class="muted">Đang tải / Loading…</p>'; $('#modal').classList.add('show');
    if (window.YGO_ART) await window.YGO_ART.loadSpecial();
    const c = await fetchCard(name);
    if (!c) { box.innerHTML = `<p>Không tìm thấy lá bài <b>${esc(name)}</b>. Kiểm tra lại tên tiếng Anh chính xác.<br>Card not found.</p>`; return; }
    const fmtStat = v => v < 0 ? '?' : v;
    const stats = [c.type, c.attribute, c.race, c.level != null ? 'Lv ' + c.level : '', c.linkval != null ? 'Link ' + c.linkval : '', c.scale != null ? 'Scale ' + c.scale : '', c.atk != null ? 'ATK ' + fmtStat(c.atk) : '', c.def != null ? 'DEF ' + fmtStat(c.def) : ''].filter(Boolean).join(' • ');
    const effBadges = (c.raw && window.YGO_EFFECTS) ? window.YGO_EFFECTS.renderBadgesHTML(c.raw, false) : '';
    box.innerHTML = `<div id="mcVisual"></div><div style="flex:1;min-width:240px"><h2 style="margin-top:0">${esc(c.name)}</h2><p class="muted">${esc(stats)}</p>${effBadges}<p style="white-space:pre-wrap;margin-bottom:8px">${esc(c.desc)}</p><div id="mcViBox"></div>
      ${c.raw && window.YGO_ART ? '<div class="row"><button class="small primary" id="mcArt">🎨 Đổi Art / Overframe / Manga</button></div>' : ''}
      <p class="hint">Dữ liệu &amp; hình ảnh: YGOPRODeck / Wiki. Hãy luôn đối chiếu text chính thức.</p></div>`;
    if (window.YGO_VI) window.YGO_VI.mountTranslationBox($('#mcViBox', box), c, { toast });
    const visHost = $('#mcVisual', box);
    if (c.raw && window.YGO_ART) {
      visHost.appendChild(window.YGO_ART.renderCardVisual(c.raw, overrideSpec, 'lg'));
      $('#mcArt', box).onclick = () => window.YGO_ART.openPicker(c.raw, {
        currentSpec: overrideSpec,
        toast,
        onApplyAll: () => render(),
      });
    } else {
      const im = document.createElement('img'); im.src = c.big || c.small; im.alt = c.name; visHost.appendChild(im);
    }
  }
  $('#modal').onclick = e => { if (e.target.id === 'modal') $('#modal').classList.remove('show'); };

  // ---------- Giao diện ----------
  function render() {
    document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    const v = $('#view');
    const sharedApi = {
      toast, showCard,
      openTab: t => { tab = t; render(); },
      loadCards: () => loadLocalDB().then(() => window.__ygoCards || []),
      loadOnlineCards: () => loadOnlineDB(),
    };
    if (tab === 'search') window.YGO_SEARCH.render(v, sharedApi);
    else if (tab === 'deck') window.YGO_DECK.render(v, sharedApi);
    else if (tab === 'map') window.YGO_MAP.render(v, { ...sharedApi, cardImg, getUser: () => user, setUser: u => { user = u; save(LS_USER, user); } });
    else renderManage(v);
  }

  // ---------- Quản lý: sao lưu / khôi phục toàn bộ Deck đã xây, Sơ đồ combo & Art mặc định ----------
  function renderManage(v) {
    const builtDecks = load(LS_DECKS, []);
    const maps = user.maps || [];
    const artPrefs = load(LS_ART, {});
    const artCnt = Object.keys(artPrefs).length;

    v.innerHTML = `<h2>Quản lý &amp; Sao lưu / Manage &amp; Backup</h2>
    <div class="card">
      <h3 style="margin-top:0">Deck đã xây của bạn / Built Decks (${builtDecks.length})</h3>
      ${builtDecks.length ? builtDecks.map(d => `<div class="row"><b style="flex:1">${esc(d.name)} <span class="badge">${esc((d.format || 'tcg').toUpperCase())}</span> <span class="badge">Main ${(d.main || []).length} • Extra ${(d.extra || []).length} • Side ${(d.side || []).length}</span></b><button class="small primary" data-combo-dk="${esc(d.id)}">🕸️ Tạo Combo</button><button class="small" data-open-dk="${esc(d.id)}">→ Xây deck</button><button class="small danger" data-del-dk="${esc(d.id)}">Xóa</button></div>`).join('') : '<p class="muted">Chưa có deck nào. Vào tab <b>Xây deck</b> để tạo.</p>'}
    </div>

    <div class="card" style="margin-top:16px">
      <h3 style="margin-top:0">Sơ đồ combo của bạn / Custom Combo Maps (${maps.length})</h3>
      ${maps.length ? maps.map((m, idx) => `<div class="row"><b style="flex:1">${esc(m.name_vi || m.name_en || ('Sơ đồ #' + (idx + 1)))} <span class="badge">${(m.nodes || []).length} nút</span></b><button class="small danger" data-del-map="${idx}">Xóa</button></div>`).join('') : '<p class="muted">Chưa có sơ đồ riêng. Vào tab <b>Sơ đồ combo</b> để vẽ.</p>'}
    </div>

    <div class="card" style="margin-top:16px">
      <h3 style="margin-top:0">Sao lưu &amp; Khôi phục toàn bộ / Full Backup &amp; Restore</h3>
      <p class="muted" style="margin-top:0">Gói sao lưu bao gồm: <b>${builtDecks.length}</b> Deck đã xây, <b>${maps.length}</b> Sơ đồ combo và <b>${artCnt}</b> thiết lập Alt Art / Overframe / Manga mặc định.</p>
      <div class="row">
        <button class="primary" id="exp">⬇ Xuất file sao lưu JSON</button>
        <button id="imp">⬆ Nhập file sao lưu JSON</button>
        <input type="file" id="file" accept=".json" style="display:none">
      </div>
      <p class="hint">Xuất file JSON để cất giữ an toàn hoặc chuyển toàn bộ Deck &amp; Sơ đồ sang máy khác.</p>
    </div>`;

    v.querySelectorAll('[data-combo-dk]').forEach(b => b.onclick = () => {
      localStorage.setItem('ygo_cur_deck_v1', b.dataset.comboDk);
      sessionStorage.setItem('ygo_combo_deck_id', b.dataset.comboDk);
      tab = 'map';
      render();
    });
    v.querySelectorAll('[data-open-dk]').forEach(b => b.onclick = () => {
      localStorage.setItem('ygo_cur_deck_v1', b.dataset.openDk);
      tab = 'deck';
      render();
    });
    v.querySelectorAll('[data-del-dk]').forEach(b => b.onclick = () => {
      if (!confirm('Xóa deck này? / Delete this deck?')) return;
      const next = builtDecks.filter(d => d.id !== b.dataset.delDk);
      save(LS_DECKS, next);
      render();
    });
    v.querySelectorAll('[data-del-map]').forEach(b => b.onclick = () => {
      if (!confirm('Xóa sơ đồ combo này?')) return;
      user.maps = (user.maps || []).filter((_, i) => i !== Number(b.dataset.delMap));
      save(LS_USER, user);
      render();
    });
    $('#exp', v).onclick = () => {
      const payload = {
        version: 2,
        exported_at: new Date().toISOString(),
        built_decks: builtDecks,
        maps: user.maps || [],
        art_prefs: artPrefs,
        vi_custom: load('ygo_vi_custom_v1', {}),
      };
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
      a.download = 'ygo-academy-backup.json';
      a.click();
    };
    $('#imp', v).onclick = () => $('#file', v).click();
    $('#file', v).onchange = async e => {
      try {
        const j = JSON.parse(await e.target.files[0].text());
        if (Array.isArray(j.built_decks)) save(LS_DECKS, j.built_decks);
        if (Array.isArray(j.maps)) { user.maps = j.maps; save(LS_USER, user); }
        if (j.art_prefs && typeof j.art_prefs === 'object') save(LS_ART, j.art_prefs);
        if (j.vi_custom && typeof j.vi_custom === 'object') save('ygo_vi_custom_v1', j.vi_custom);
        toast('Đã khôi phục dữ liệu thành công');
        render();
      } catch (err) {
        toast('File JSON không hợp lệ / Invalid JSON');
      }
    };
  }

  document.querySelectorAll('#nav button').forEach(b => b.onclick = () => { tab = b.dataset.tab; render(); });
  render();
})();
