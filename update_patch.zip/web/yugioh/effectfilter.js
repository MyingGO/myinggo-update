// Bộ phân tích cơ chế PSCT (Problem-Solving Card Text) & Bộ lọc Hiệu ứng chuyên sâu cho Yu-Gi-Oh! Academy.
// Phân tách mệnh đề Điều kiện (:) — Chi phí / Chỉ định (;) — Hiệu ứng giải quyết để lọc chuẩn xác:
// Rút bài, Search, Đặt thẳng lách Ash, Chôn bài, Triệu hồi, Negate, Gỡ bàn (Non-target / Kaiju / Đẩy về hàng S&T),
// Floodgate (Cấm triệu hồi / Cấm kích hoạt / Khóa mộ / Tự khóa bản thân), Giáp bảo vệ, OTK & Handtrap.
(function () {
  'use strict';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ---------------- 1. DANH MỤC ĐẶC TÍNH PSCT & 7 NHÓM HIỆU ỨNG ----------------
  const MODIFIERS = [
    { id: 'mod_handtrap', icon: '🖐️', label: 'Handtrap (Kích từ tay cản đối thủ)', tip: 'Ném/kích hoạt từ trên tay ngay trong lượt đối phương (Ash, Imperm, Veiler, Nibiru, Droll, Bystial, Impulse…)' },
    { id: 'mod_quick', icon: '⚡', label: 'Quick Effect (Chơi trong lượt đối thủ)', tip: 'Hiệu ứng tốc độ 2 (Quick Effect) hoặc Phép Nhanh (Quick-Play) dùng được trong lượt đối phương' },
    { id: 'mod_nontarget', icon: '🎯', label: 'Không Target (Non-Targeting)', tip: 'Xử lý bài trên sân/mộ mà KHÔNG có từ khóa "target" trước dấu ";" — xuyên giáp chống chỉ định (Mirrorjade, Zeus, Droplet…)' },
    { id: 'mod_nohopt', icon: '♾️', label: 'Không giới hạn HOPT (Xả nhiều lần)', tip: 'Không bị ràng buộc "You can only use/activate ... once per turn" cứng — có thể dùng lặp lại hoặc Once per Chain' },
    { id: 'mod_going2nd', icon: '🔥', label: 'Đi sau gỡ bàn (Going-2nd)', tip: 'Mạnh hơn hoặc tự mở khóa điều kiện khi đối phương đang điều khiển quái thú/nhiều bài hơn (Thrust, Evenly, Ty-Phon, Kaiju…)' },
  ];

  const GROUPS = [
    {
      id: 'res',
      label: '📦 Tài nguyên',
      fullLabel: '📦 1. Gia tăng tài nguyên (Rút, Tìm kiếm, Chôn bài & Hồi bài)',
      tags: [
        { id: 'res_draw', label: 'Rút bài (Draw)', tip: 'Rút thêm bài từ Deck (Pot of Greed, Maxx "C", Fuwalos, Allure…)' },
        { id: 'res_search', label: 'Tìm bài lên tay (Search Deck)', tip: 'Lấy quái / phép / bẫy từ Deck lên tay (ROTA, Bonfire, Fenrir…)' },
        { id: 'res_set_deck', label: 'Đặt/Úp thẳng từ Deck (Lách Ash)', tip: 'Set hoặc đặt ngửa Phép/Bẫy thẳng từ Deck lên sân, không bị Ash Blossom chặn (Diabellstar, Turbulence, True Light…)' },
        { id: 'res_mill', label: 'Đổ Deck xuống Mộ (Foolish / Mill)', tip: 'Gửi đích danh 1 lá hoặc xay đỉnh Deck xuống Mộ (Foolish Burial, Circular, Tearlaments…)' },
        { id: 'res_send_ed', label: 'Gửi Extra Deck xuống Mộ', tip: 'Gửi thẳng quái từ Extra Deck xuống Mộ để kích hiệu ứng (Nadir Servant, Ext Ryzeal, Mirrorjade…)' },
        { id: 'res_banish_deck', label: 'Trục xuất từ Deck / Extra', tip: 'Trục xuất đích danh bài từ Deck hoặc Extra Deck để mở combo (Gold Sarcophagus, Maliss, Unicorn…)' },
        { id: 'res_recover', label: 'Hồi Mộ/Banish về Tay hoặc Deck', tip: 'Nhặt lại tài nguyên từ Mộ hoặc vùng Banish về Tay / xào lại vào Deck' },
        { id: 'res_excavate', label: 'Lật đỉnh Deck / Xem bài đối thủ', tip: 'Excavate lật đỉnh Deck chọn bài (Prosperity) hoặc nhìn Tay / Extra Deck đối phương (Talent)' },
      ],
    },
    {
      id: 'sum',
      label: '🚀 Triệu hồi',
      fullLabel: '🚀 2. Triệu hồi & Mở rộng sân (Summon & Extenders)',
      tags: [
        { id: 'sum_self', label: 'Tự nhảy từ Tay / Mộ (Extender)', tip: 'Tự Triệu hồi Đặc biệt bản thân từ Tay hoặc Mộ không tốn Normal Summon (Fenrir, Diabellstar, Bystial…)' },
        { id: 'sum_deck', label: 'Triệu hồi Đặc biệt từ Deck', tip: 'Gọi thẳng quái thú từ Deck ra sân (Emergency Teleport, Snake-Eye Ash, Lonefire…)' },
        { id: 'sum_revive', label: 'Hồi sinh từ Mộ / Banish', tip: 'Triệu hồi Đặc biệt quái thú từ Mộ hoặc vùng Trục xuất lên sân (Monster Reborn, Promethean Princess, Selene…)' },
        { id: 'sum_extra_quick', label: 'Gọi Extra Deck / Quick Summon', tip: 'Triệu hồi thẳng từ Extra Deck hoặc cho phép Fusion / Synchro / XYZ / Link ngay trong lượt đối phương (I:P, Crimson Dragon, Super Poly…)' },
        { id: 'sum_normal', label: 'Thêm lượt Normal Summon', tip: 'Cho phép thực hiện thêm lượt Triệu hồi Thường trong cùng lượt (Double Summon, Floowandereeze…)' },
        { id: 'sum_token', label: 'Tạo Token / Quái Bẫy', tip: 'Sinh Token lên sân hoặc Bẫy tự triệu hồi thành quái thú' },
      ],
    },
    {
      id: 'neg',
      label: '🛑 Negate',
      fullLabel: '🛑 3. Vô hiệu hóa & Chặn chuỗi (Negate & Interruption)',
      tags: [
        { id: 'neg_omni', label: 'Omni-Negate (Mọi loại bài)', tip: 'Vô hiệu hóa bất kỳ kích hoạt Quái / Phép / Bẫy nào (Baronne, Borreload Savage, Dragoon, Varudras…)' },
        { id: 'neg_monster', label: 'Vô hiệu Quái thú (Monster Negate)', tip: 'Chặn kích hoạt hoặc làm câm hiệu ứng quái thú (Imperm, Veiler, Apollousa, Ash Blossom, Droplet, Dark Ruler…)' },
        { id: 'neg_st', label: 'Vô hiệu Phép / Bẫy (S/T Negate)', tip: 'Chặn kích hoạt hoặc vô hiệu hiệu ứng Phép / Bẫy (Hope Harbinger, Naturia Beast, Red Reboot…)' },
        { id: 'neg_summon', label: 'Vô hiệu Triệu hồi (Summon Negate)', tip: 'Đập tan lượt Normal / Special Summon ngay ở cửa sổ triệu hồi (Solemn Strike, Judgment, Warning, Sauravis…)' },
        { id: 'neg_norespond', label: 'Cấm phản đòn (Spell Speed 4)', tip: 'Đối phương không thể kích bài đáp trả chuỗi này (Super Polymerization, Forbidden Droplet, Accesscode Talker…)' },
      ],
    },
    {
      id: 'rm',
      label: '💥 Gỡ bàn',
      fullLabel: '💥 4. Dọn sân & Xử lý bài đối thủ (Removal & Board Breakers)',
      tags: [
        { id: 'rm_destroy', label: 'Phá hủy / Quét sân (Destroy)', tip: 'Phá hủy quái thú, phép/bẫy hoặc nổ toàn sân (Raigeki, Feather Duster, Accesscode…)' },
        { id: 'rm_banish', label: 'Trục xuất (Banish)', tip: 'Loại bỏ bài trên sân hoặc trong Mộ đối phương ra vùng Banish (S:P Little Knight, Mirrorjade, Bystial…)' },
        { id: 'rm_banish_fd', label: 'Trục xuất Úp mặt (Face-down)', tip: 'Trục xuất úp mặt khiến đối thủ gần như không thể hồi lại (Kashtira Fenrir, Evenly Matched, Karma Cannon…)' },
        { id: 'rm_send_gy', label: 'Gửi thẳng xuống Mộ (Không nổ)', tip: 'Đưa bài trên sân thẳng xuống Mộ không qua phá hủy — lách giáp chống nổ (AA-ZEUS, Dingirsu, Herald of the Abyss…)' },
        { id: 'rm_bounce', label: 'Đẩy về Tay / Xào về Deck / Úp mặt', tip: 'Trả bài về Tay/Deck, lật úp mặt (Book of Moon) hoặc trục xuất tạm thời (Unicorn, Compulsory, Noir, S:P…)' },
        { id: 'rm_tribute', label: 'Hiến tế / Ăn quái đối thủ (Kaiju)', tip: 'Hiến tế hoặc dùng quái đối phương làm nguyên liệu Fusion/Link — xuyên giáp Miễn nhiễm (Kaiju, Lava Golem, Nibiru, Underworld Goddess…)' },
        { id: 'rm_control', label: 'Chiếm quái / Hút XYZ / Đẩy về hàng S&T', tip: 'Chiếm quyền điều khiển, hút làm nguyên liệu XYZ hoặc ép quái thành Continuous Spell/Trap ở hàng sau (Talent, Infinity, Subversion - Snake-Eye…)' },
        { id: 'rm_handrip', label: 'Giật bài trên Tay đối thủ', tip: 'Đốt, trục xuất hoặc xào bài trên tay đối phương (Omega, Lovely Labrynth, Trishula…)' },
      ],
    },
    {
      id: 'lock',
      label: '🔒 Khóa sân',
      fullLabel: '🔒 5. Khóa sân & Cấm người chơi hành động (Floodgates / Locks)',
      tags: [
        { id: 'lock_summon', label: 'Cấm / Giới hạn Triệu hồi', tip: 'Cấm Special Summon hoặc khóa số lần triệu hồi (Barrier Statue, Vanity, Winda, Summon Limit, Artifact Scythe…)' },
        { id: 'lock_activate', label: 'Cấm Kích hoạt hiệu ứng', tip: 'Cấm kích hoạt hoặc vô hiệu diện rộng Quái / Phép / Bẫy (Skill Drain, Majesty, Inspector Boarder, Kali Yuga, Anti-Spell, Jinzo…)' },
        { id: 'lock_search_draw', label: 'Cấm Tìm bài / Cấm Rút bài', tip: 'Cấm lấy bài từ Deck lên tay hoặc rút thêm bài (Droll & Lock Bird, Thunder Dragon Colossus, Mistake, Rai-Oh…)' },
        { id: 'lock_gy', label: 'Khóa Mộ / Đổi Mộ thành Banish', tip: 'Mọi bài xuống Mộ bị trục xuất hoặc khóa hiệu ứng trong Mộ (Dimension Shifter, Macro Cosmos, Abyss Dweller, Necrovalley…)' },
        { id: 'lock_banish', label: 'Cấm Trục xuất bài (No Banish)', tip: 'Cấm người chơi trục xuất bài (Artifact Lancea, Imperial Iron Wall, Chaos Hunter)' },
        { id: 'lock_type_attr', label: 'Khóa Hệ / Chủng tộc trên sân', tip: 'Giới hạn Hệ/Tộc được điều khiển hoặc đổi toàn bộ Hệ/Tộc trên sân (TCBOO, Gozen Match, Rivalry, Zombie World…)' },
        { id: 'lock_attack', label: 'Cấm Tấn công / Ép tư thế', tip: 'Cấm quái đối thủ tuyên bố tấn công hoặc ép nằm thủ (Bagooska, Scareclaw Tri-Heart, Threatening Roar…)' },
        { id: 'lock_self', label: '⚠️ Tự khóa bản thân (Self-Lock)', tip: 'Có ràng buộc tự khóa lượt triệu hồi/Extra Deck/Hệ của chính mình (bấm 1 lần để kiểm tra, bấm lần 2 màu ĐỎ để LOẠI TRỪ khi phối nhiều tộc!)' },
      ],
    },
    {
      id: 'prot',
      label: '🛡️ Bảo vệ',
      fullLabel: '🛡️ 6. Giáp bảo vệ & Kháng hiệu ứng (Protection / Towers)',
      tags: [
        { id: 'prot_unaffected', label: 'Miễn nhiễm hiệu ứng (Unaffected)', tip: 'Không bị ảnh hưởng bởi hiệu ứng bài khác (Expurrely Noir, Ultimate Falcon, Sangen Summoning, Arrival Cyberse…)' },
        { id: 'prot_untarget', label: 'Không thể bị Target', tip: 'Đối phương không thể chỉ định mục tiêu vào bài này / đồng đội (Chaos MAX, Dragoon, Avramax, Spright Elf…)' },
        { id: 'prot_indestruct', label: 'Chống nổ / Bảo kê thế mạng', tip: 'Không thể bị phá hủy bởi chiến đấu/hiệu ứng, hoặc tự loại bỏ để bảo vệ bài trên sân khỏi bị nổ (Balelynx, Hugin, Dingirsu…)' },
      ],
    },
    {
      id: 'otk',
      label: '⚔️ OTK / Khác',
      fullLabel: '⚔️ 7. Sát thương, OTK & Biến đổi đặc biệt',
      tags: [
        { id: 'otk_battle', label: 'Tăng/Giảm ATK • Đánh nhiều lần • Xuyên thủ', tip: 'Công cụ dứt điểm trận đấu (OTK): nhân đôi sát thương, đánh nhiều đòn, xuyên thủ, đánh trực tiếp, đổi ATK' },
        { id: 'otk_lp', label: 'Trừ điểm gốc (Burn) / Hồi LP', tip: 'Gây sát thương hiệu ứng trực tiếp (Burn LP) hoặc hồi Điểm Gốc' },
        { id: 'otk_mod', label: 'Đổi Level / Hệ / Tộc / Thành Tuner', tip: 'Thay đổi Cấp độ, Thuộc tính, Chủng tộc hoặc biến thành Tuner để căn Synchro / XYZ' },
        { id: 'otk_special', label: 'Đặt Counter / Thắng đặc biệt (Alt Win)', tip: 'Tích lũy Counter (Spell Counter…) hoặc điều kiện thắng đặc biệt (Exodia, Destiny Board…)' },
      ],
    },
  ];

  const ALL_TAGS = [...MODIFIERS, ...GROUPS.flatMap(g => g.tags.map(t => ({ ...t, group: g.id, groupLabel: g.label })))];
  const TAG_BY_ID = new Map(ALL_TAGS.map(t => [t.id, t]));
  const ACTION_NON_TARGET_IDS = new Set([
    'rm_destroy', 'rm_banish', 'rm_banish_fd', 'rm_send_gy', 'rm_bounce', 'rm_tribute', 'rm_control', 'neg_monster', 'neg_st',
  ]);

  // ---------------- 2. BỘ PHÂN TÍCH NGỮ PHÁP PSCT (CONDITION : COST ; EFFECT) ----------------
  function extractEffectBody(c) {
    if (!c || !c.desc) return '';
    const ft = String(c.frameType || '').toLowerCase();
    const tp = String(c.type || '');
    // Quái Normal thuần chỉ chứa văn bản cốt truyện (Flavor Text), tuyệt đối không phân tích hiệu ứng
    if (ft === 'normal' || (/Normal Monster/i.test(tp) && !/Pendulum/i.test(tp))) return '';

    let txt = String(c.desc).replace(/\r\n/g, '\n');

    // Quái Pendulum Normal: chỉ lấy phần [ Pendulum Effect ], bỏ phần Flavor Text bên dưới
    if (ft === 'normal_pendulum' || /Pendulum Normal/i.test(tp)) {
      const m = txt.match(/\[\s*Pendulum Effect\s*\]([\s\S]*?)(?:\[\s*(?:Monster Effect|Flavor Text)\s*\]|$)/i);
      txt = m ? m[1] : '';
    } else {
      txt = txt.replace(/\[\s*(?:Pendulum Effect|Monster Effect|Flavor Text)\s*\]/gi, '\n');
    }

    // Bỏ dòng nguyên liệu triệu hồi đầu tiên của quái Extra Deck (vd: "1 Tuner + 1+ non-Tuner monsters")
    const lines = txt.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length > 1 && /Fusion|Synchro|XYZ|Link/i.test(tp)) {
      const first = lines[0];
      if (!/[.;:]/.test(first) && (/^\d+\+?\s/.test(first) || /\s\+\s/.test(first)) && !/\b(?:if|when|you can|once per|must|cannot|unaffected|gain|lose)\b/i.test(first)) {
        lines.shift();
      }
    }

    // Loại bỏ danh sách gạch đầu dòng mô tả hiệu ứng của đối phương sau "includes any of these effects" (vd Ash Blossom, Ghost Belle)
    const cleanedLines = [];
    let skipBullets = false;
    for (const ln of lines) {
      if (/includes any of these effects/i.test(ln)) {
        skipBullets = true;
        cleanedLines.push(ln);
        continue;
      }
      if (skipBullets && /^[●•▪*-]/.test(ln)) continue;
      skipBullets = false;
      cleanedLines.push(ln.replace(/^[●•]\s*/, ''));
    }
    return cleanedLines.join('\n');
  }

  function splitClauses(body) {
    // Tách theo xuống dòng và dấu chấm câu kết thúc mệnh đề PSCT
    return body
      .split(/\n+|(?<=\.)\s+(?=[A-Z("●•0-9])/)
      .map(s => s.trim())
      .filter(Boolean);
  }

  function parseClause(raw) {
    let s = raw.replace(/^FLIP:\s*/i, '');
    const semiIdx = s.indexOf(';');
    const colonIdx = s.indexOf(':');
    let cond = '', cost = '', eff = s;

    if (semiIdx !== -1) {
      eff = s.slice(semiIdx + 1).trim();
      const pre = s.slice(0, semiIdx);
      if (colonIdx !== -1 && colonIdx < semiIdx) {
        cond = pre.slice(0, colonIdx).trim();
        cost = pre.slice(colonIdx + 1).trim();
      } else {
        cost = pre.trim();
      }
    } else if (colonIdx !== -1) {
      cond = s.slice(0, colonIdx).trim();
      eff = s.slice(colonIdx + 1).trim();
    }
    return { raw, cond, cost, eff };
  }

  function analyzeCard(c) {
    if (c._eff) return c._eff;
    const tags = new Set();
    const nonTargetTags = new Set();
    const body = extractEffectBody(c);
    if (!body) {
      c._eff = { tags, nonTargetTags };
      return c._eff;
    }

    const tp = String(c.type || '');
    const isMonster = !/Spell|Trap/i.test(tp);
    const isSpell = /Spell/i.test(tp);
    const isTrap = /Trap/i.test(tp);
    const isEquip = c.race === 'Equip';
    const fullLower = body.toLowerCase();
    const clauses = splitClauses(body).map(parseClause);

    let hasActivatedClause = false;
    const hasHardOPT = /you can only (?:use|activate|apply) (?:this effect|each effect|each of the following effects|1 "|".*?" once)|once per duel/i.test(fullLower);

    // Kiểm tra toàn văn bản cho các hiệu ứng Continuous / Floodgate / Bảo vệ / Đặc tính chung
    if (isSpell && c.race === 'Quick-Play') tags.add('mod_quick');
    if (/this is a quick effect|\(quick effect\)|during either player's (?:turn|main phase|battle phase)|during your opponent's (?:turn|main phase|battle phase)/i.test(fullLower)) {
      tags.add('mod_quick');
    }
    if (isTrap && /activate this card from your hand/i.test(fullLower)) {
      tags.add('mod_handtrap');
    }
    if (/(?:if|while) your opponent controls (?:a |more |\d+\+? |[a-z-]+ )?(?:monster|card|spell|trap)|if only your opponent controls a monster|more cards than you do|by tributing \d+\+? monsters? (?:they|your opponent) controls?/i.test(fullLower)) {
      tags.add('mod_going2nd');
    }

    // Spell Speed 4 (Cấm phản đòn)
    if (/(?:neither player can|your opponent cannot) activate [^.;]*?in response|in response to [^.;]*?(?:neither player can|your opponent cannot) activate|cards and effects cannot be activated in response/i.test(fullLower)) {
      tags.add('neg_norespond');
    }

    // Kaiju / Super Poly / Underworld Goddess (Hiến tế hoặc ăn quái đối phương làm nguyên liệu)
    if (/by tributing \d+\+? monsters? (?:they|your opponent) controls?|\btribute (?:\d+|as many|all) [^.;]*?monsters? (?:on the field|your opponent controls)|using (?:1 |\d+\+? )?monsters? (?:from either field|your opponent controls) as (?:fusion|link|synchro|xyz) material|use 1 monster your opponent controls as material/i.test(fullLower)) {
      tags.add('rm_tribute');
      nonTargetTags.add('rm_tribute');
    }

    // ---------------- NHÓM 5: FLOODGATES & LOCKS ----------------
    // Tự khóa bản thân (Self-Lock)
    const hasSelfSummonLock = /\byou cannot (?:normal or )?special summon [^.;]*?(?:for the rest of this turn|the turn you activate|this turn|while you control)|also you cannot special summon/i.test(fullLower)
      || /\byou cannot activate monster effects for the rest of this duel, except\b/i.test(fullLower);
    if (hasSelfSummonLock) tags.add('lock_self');

    // Cấm / Giới hạn Triệu hồi đối phương hoặc cả 2 bên
    if (/(?:neither player can|your opponent cannot|each player can only|your opponent can only) (?:normal,? |flip,? |or )*(?:normal|special|tribute|flip|pendulum|fusion|synchro|xyz|link) summon|players cannot special summon|no monsters can be special summoned|monsters cannot be special summoned/i.test(fullLower)) {
      tags.add('lock_summon');
    }
    // Cấm kích hoạt hiệu ứng (Skill Drain, Majesty, Kali Yuga, Anti-Spell, Jinzo, Mystic Mine...)
    const hasActivationLock = clauses.some(cl => {
      const s = cl.raw.toLowerCase();
      if (/in response/i.test(s)) return false;
      return /(?:neither player can|your opponent cannot|monsters? your opponent controls cannot) activate |monster effects cannot be activated|negate the effects of all face-up monsters while|negate the activated effects of monsters|must first set spell cards before activating|trap cards,? and their effects on the field,? cannot be activated|negate all trap effects on the field|cards and effects on the field cannot be activated/.test(s);
    });
    if (hasActivationLock) {
      tags.add('lock_activate');
    }
    // Cấm Tìm bài / Cấm Rút bài
    if (/cards cannot be added from (?:the |either player's |their |your opponent's )?(?:main )?deck to (?:the|their|your opponent's|either player's) hand|(?:neither player can|your opponent cannot) add cards from (?:the|their) (?:main )?deck to (?:the|their) hand|(?:neither player can|your opponent cannot) draw cards/i.test(fullLower)) {
      tags.add('lock_search_draw');
    }
    // Khóa Mộ / Đổi đường vào Mộ thành Banish
    if (/any (?:card|monster) sent to the (?:gy|graveyard) is banished instead|cards sent to your opponent's (?:gy|graveyard) are banished instead|(?:neither player can|your opponent cannot) activate (?:any )?(?:card |monster )?effects in (?:the|their) (?:gy|graveyard)|monsters in the (?:gy|graveyard) cannot activate their effects|cards in the (?:gy|graveyard) cannot be banished|negate any card effect that would move a card in the (?:gy|graveyard)/i.test(fullLower)) {
      tags.add('lock_gy');
    }
    // Cấm Trục xuất
    if (/(?:neither player can|your opponent cannot|players cannot) banish cards/i.test(fullLower)) {
      tags.add('lock_banish');
    }
    // Khóa Hệ / Chủng tộc
    if (/each player can only control 1 monster of each|each player can only control 1 (?:type|attribute)|all face-up monsters on the field become |all monsters on the field (?:and in (?:every|the) gys? )?become /i.test(fullLower)) {
      tags.add('lock_type_attr');
    }
    // Cấm Tấn công / Ép tư thế
    if (/(?:monsters? your opponent controls |your opponent |opponent's monsters? |neither player )can(?:not)? declare an attack|cannot attack (?:while|as long as|any monster)|change all face-up monsters (?:on the field )?to defense position|all face-up monsters on the field are changed to defense position/i.test(fullLower)
        && !/this card cannot attack|your monsters cannot attack|monsters you control cannot attack|you cannot declare an attack/i.test(fullLower)) {
      tags.add('lock_attack');
    }

    // ---------------- NHÓM 6: GIÁP BẢO VỆ (PROTECTION) ----------------
    if (/unaffected by (?:the |other |your opponent's )*(?:cards'|card|activated|spell|trap|monster|spell\/trap) effects/i.test(fullLower)) {
      tags.add('prot_unaffected');
    }
    if (/(?:neither player can|your opponent cannot) target (?:this|[^.;]*?you control)|cannot be targeted by (?:an opponent's |opponent's )?(?:card|spell|trap|monster) effects/i.test(fullLower)) {
      tags.add('prot_untarget');
    }
    if (/cannot be destroyed by (?:battle|card effects|an opponent's card effects|your opponent's card effects)|if (?:this card|(?:a |another )?[^.;]*?you control) would be destroyed [^.;]*?you can [^.;]*?instead/i.test(fullLower)) {
      tags.add('prot_indestruct');
    }

    // Đặt Counter / Alt Win
    if (/place \d+ [a-z -]+ counter|\byou win the duel\b/i.test(fullLower)) {
      tags.add('otk_special');
    }

    // ---------------- PHÂN TÍCH TỪNG MỆNH ĐỀ (CLAUSE-BY-CLAUSE) ----------------
    for (const cl of clauses) {
      const { raw, cond, cost, eff } = cl;
      const cCond = cond.toLowerCase();
      const cCost = cost.toLowerCase();
      const cEff = eff.toLowerCase();
      const costAndEff = (cCost + '; ' + cEff).trim();
      const preAndEff = (cCost + '; ' + cEff).trim();

      if (cond || cost || /^flip:/i.test(raw)) hasActivatedClause = true;

      const clauseTargets = isEquip
        || /\btarget\b/.test(cCond + ' ' + cCost)
        || /\b(?:select|designate) (?:\d+|up to \d+|1|a) [^.;]*?(?:on the field|your opponent controls|in (?:either|your opponent's) (?:gy|graveyard))\b/.test(cEff);

      const addAct = id => {
        tags.add(id);
        if (!clauseTargets && ACTION_NON_TARGET_IDS.has(id)) nonTargetTags.add(id);
      };

      // Handtrap trên Quái thú: có tốc độ Quick / kích trong lượt đối thủ + dùng trực tiếp từ trên tay
      if (isMonster) {
        const isQuickClause = /\(quick effect\)|during either player's|during your opponent's|when your opponent declares a(?:n| direct)? attack/.test(cCond + ' ' + cCost + ' ' + cEff);
        const fromHandCostOrSS = /\b(?:discard this card|send this card from your hand|banish this card from your hand|tribute this card from your hand|reveal this card in your hand)|special summon (?:both )?this card (?:from your hand|\(from your hand\))/.test(cCost + ' ' + cEff);
        if (isQuickClause && fromHandCostOrSS) tags.add('mod_handtrap');
      }

      // --- 1. TÀI NGUYÊN ---
      if (/\bdraw (?:\d+|a |1 |cards|until)\b/.test(cEff) && (!/\byour opponent draws\b/.test(cEff) || /\byou draw|each player draws|both players draw\b/.test(cEff))) {
        tags.add('res_draw');
      }
      if (/\b(?:add|take)\b[^.;]*?\bfrom your (?:main )?deck\b[^.;]*?\bto your hand\b|\bsearch your deck for\b/.test(cEff)
          || (/\bexcavate\b[^.;]*?\bdeck\b/.test(cEff) && /\badd [^.;]*?to your hand\b/.test(cEff))) {
        tags.add('res_search');
      }
      if (/\b(?:set|place)\b[^.;]*?\b(?:directly )?from your (?:hand,? )?deck\b[^.;]*?(?:spell & trap zone|pendulum zone|on your field|face-up|spell\/trap|trap|spell)?|\bactivate 1\b[^.;]*?\bdirectly from your deck\b/.test(cEff)
          && !/\bspecial summon\b[^.;]*?\bin face-down defense position\b/.test(cEff)
          && (/\bset\b[^.;]*?\bfrom your (?:hand,? )?deck\b/.test(cEff) || /\b(?:place|activate)\b[^.;]*?\bfrom your (?:hand,? )?deck\b[^.;]*?(?:spell|trap|zone|field)/.test(cEff))) {
        tags.add('res_set_deck');
      }
      if (/\bsend(?:ing)?\b[^.;]*?\bfrom (?:your |the top of your )(?:main )?deck to the (?:gy|graveyard)\b|\bsend(?:ing)? the top (?:\d+ )?cards? of your deck to the (?:gy|graveyard)\b/.test(costAndEff)) {
        tags.add('res_mill');
      }
      if (/\bsend(?:ing)?\b[^.;]*?\bfrom (?:your |either )?extra deck to the (?:gy|graveyard)\b/.test(costAndEff)) {
        tags.add('res_send_ed');
      }
      if (/\bbanish(?:ing)?\b[^.;]*?\bfrom your (?:deck|extra deck)\b/.test(costAndEff) && !/\bbanish \d+ cards from the top of your deck, face-down\b/.test(cCost)) {
        tags.add('res_banish_deck');
      }
      if (/\b(?:add|return|shuffle|place)\b[^.;]*?\b(?:in|from) your (?:gy|graveyard|banished)\b[^.;]*?\b(?:to|into|on) (?:your |the )?(?:hand|deck|extra deck|top of the deck|bottom of the deck)\b/.test(cEff)
          || (/\b(?:in|of) your (?:gy|graveyard)\b|\byour banished\b/.test(cCost) && /\b(?:add|return|shuffle|place) (?:it|them|that target|those targets|1 of them) (?:to|into|on) (?:your |the )?(?:hand|deck|extra deck|top of|bottom of)\b/.test(cEff))) {
        tags.add('res_recover');
      }
      if (/\bexcavate\b|\blook at (?:your opponent's (?:hand|extra deck)|the top \d+ cards of your deck)\b/.test(cEff)) {
        tags.add('res_excavate');
      }

      // --- 2. TRIỆU HỒI ---
      // Bỏ vế tự khóa ("also you cannot Special Summon...") ở cuối câu để không chặn nhầm hiệu ứng triệu hồi đứng trước nó
      const cEffPos = cEff
        .replace(/(?:,\s*(?:also\s*)?|\balso\s+)?(?:you|neither player|your opponent|each player|players) can(?:not|'t| only) (?:normal or )?special summon[^.;]*/g, '')
        .replace(/\bno monsters can be special summoned[^.;]*/g, '');
      if (isMonster && /\bspecial summon (?:both )?this card\b/.test(cEffPos)
          && !/^must be special summoned\b/.test(cEffPos)
          && !/\b(?:the turn|if|when) you special summon this card\b/.test(cEffPos)
          && !/\bspecial summon this card [^.;]*?\bto your opponent's field\b/.test(cEffPos)) {
        tags.add('sum_self');
      }
      if (/\bspecial summon (?!this card\b)[^.;]*?\bfrom your (?:hand,? )?(?:main )?deck\b|\bspecial summon (?!this card\b)[^.;]*?\bfrom your hand or deck\b|\bspecial summon (?!this card\b)[^.;]*?\bfrom your hand,? deck,? or (?:gy|graveyard)\b/.test(cEffPos)) {
        tags.add('sum_deck');
      }
      if (/\bspecial summon (?!this card\b)[^.;]*?\bfrom (?:your |either |their )?(?:hand,? )?(?:deck,? or )?(?:gy|graveyard|banished)\b/.test(cEffPos)
          || (/\b(?:in|of) (?:your |either |their )?(?:gy|graveyard)\b|\bbanished\b/.test(cCost) && /\bspecial summon (?:it|them|that target|those targets|that monster|1 of them)\b/.test(cEffPos))) {
        tags.add('sum_revive');
      }
      if (/\bspecial summon (?!this card\b)[^.;]*?\bfrom (?:your |the )?extra deck\b/.test(cEffPos)
          || (/\(quick effect\)|during (?:your opponent's|either player's)/.test(cCond + ' ' + cCost + ' ' + cEffPos) && /\b(?:fusion|synchro|xyz|link) summon\b/.test(cEffPos))
          || /\bfusion summon\b[^.;]*?\busing monsters from either field\b/.test(cEffPos)) {
        tags.add('sum_extra_quick');
      }
      if (/immediately after this effect resolves, normal summon|you can normal summon \d+ [^.;]*?in addition to your normal summon|gain an additional normal summon|conduct \d+ normal summon/.test(cEff)) {
        tags.add('sum_normal');
      }
      if (/\bspecial summon\b[^.;]*?\btoken\b/.test(cEff) || (isTrap && /\bspecial summon this card as a(?:n effect| normal)? monster\b/.test(cEff))) {
        tags.add('sum_token');
      }

      // --- 3. VÔ HIỆU HÓA (NEGATE) ---
      if (/when (?:(?:a|an opponent's) (?:spell\/trap card,? or monster effect,?|card or effect) is activated|your opponent activates a (?:spell\/trap card,? or monster effect|card or effect))(?!\s*that includes)/.test(cCond)
          && /\bnegate (?:the (?:summon or )?activation|that (?:activation|effect)|it)\b/.test(cEff)) {
        tags.add('neg_omni');
      }
      if (((/\bmonster(?:'s)? effect is activated\b|\bactivates a(?: [a-z-]+)? monster(?:'s)? effect\b/.test(cCond)) && /\bnegate\b/.test(cEff))
          || (/includes (?:any of these effects|an effect that special summons)/.test(cCond) && /\bnegate\b/.test(cEff))
          || (/\bmonster/.test(preAndEff) && /\bnegate (?:its|their|that monster's|those monsters'|the) (?:activated )?effects?\b/.test(cEff) && !/\bspecial summon\b[^.;]*?\b(?:its|their) effects? (?:is|are) negated\b/.test(cEff))
          || (/\bnegate the (?:activated )?effects of (?:all )?(?:face-up )?monsters\b|\btheir effects are negated\b/.test(cEff) && !/\bspecial summon\b/.test(cEff))) {
        addAct('neg_monster');
      }
      if (((/\b(?:spell|trap)(?:\/trap)? (?:card|effect|card or effect) is activated\b|\bactivates a (?:spell|trap)(?:\/trap)? (?:card|effect|card or effect)\b/.test(cCond)) && !/\bmonster effect\b/.test(cCond) && /\bnegate\b/.test(cEff))
          || (/includes (?:any of these effects|an effect that special summons)/.test(cCond) && /\bnegate\b/.test(cEff))
          || /\bnegate\b[^.;]*?\b(?:spell|trap)(?:\/trap)? (?:card|effect)\b|\b(?:spell|trap)(?:\/trap)? effects? [^.;]*?\bare negated\b/.test(cEff)) {
        addAct('neg_st');
      }
      if ((/would be (?:(?:normal|special|flip|[a-z]+ or [a-z]+)\s+)?summoned|would (?:normal|special|flip) summon/.test(cCond))
          && /\bnegate the (?:summon(?:\s+or activation)?|(?:normal|special|flip) summon)\b/.test(cEff)) {
        tags.add('neg_summon');
      }

      // --- 4. DỌN SÂN & GỠ BÀN (REMOVAL — chỉ xét trong cEff để không nhầm với Cost!) ---
      if (/\bdestroy (?:it|them|that |those |all |up to \d+ |\d+ |as many )/.test(cEff) && !/^destroy this card\.?$/.test(cEff) && !/^if you cannot,?\s*destroy it\.?$/.test(cEff)) {
        // Loại trừ câu chỉ tự hủy bài của mình hoặc hủy từ tay/deck mình để mở combo nếu không đụng sân
        if (!/\bdestroy (?:1|this) [^.;]*?(?:in your hand|you control)\b/.test(cEff) || /\bon the field|your opponent controls|all /.test(preAndEff)) {
          addAct('rm_destroy');
        }
      }
      if (/\bbanish (?:it|them|that |those |all |up to \d+ |\d+ |both )/.test(cEff) && !/^banish this card\b/.test(cEff)) {
        if (!/\bbanish [^.;]*?from your (?:deck|extra deck|hand|gy|graveyard)\b/.test(cEff) || /\bon the field|your opponent|either gy\b/.test(preAndEff)) {
          addAct('rm_banish');
        }
      }
      if (/\bbanish\b[^.;]*?\bface-down\b/.test(cEff) && !/\bfrom the top of your deck, face-down\b/.test(cEff)) {
        addAct('rm_banish_fd');
        addAct('rm_banish');
      }
      if (/\bsend (?:it|them|that |those |all |\d+ |up to \d+ )[^.;]*?\bto the (?:gy|graveyard)\b/.test(cEff)
          && !/\bsend [^.;]*?\bfrom (?:your |their |the )?(?:main )?(?:deck|extra deck|hand)\b/.test(cEff)
          && (/\bon the field|from the field|your opponent controls|other cards\b/.test(preAndEff) || /\bmust send\b[^.;]*?\bto the (?:gy|graveyard)\b/.test(cEff))) {
        addAct('rm_send_gy');
      }
      if ((/\b(?:return|shuffle|place)\b[^.;]*?\b(?:to|into|on (?:the )?(?:top|bottom) of) (?:the |its owner's |their owner's )?(?:hand|deck|extra deck)\b/.test(cEff)
            && /\bon the field|your opponent controls|in (?:either|their|your opponent's) (?:gy|graveyard)|target (?:\d+|up to \d+) (?:face-up )?(?:card|monster|spell|trap)/.test(preAndEff)
            && !/\breturn this card to the (?:hand|extra deck)\b/.test(cEff))
          || /\bchange (?:it|them|that monster|those monsters|all face-up monsters|up to \d+ [^.;]*?monsters?|\d+ [^.;]*?monsters?) to face-down defense position\b/.test(cEff)
          || /\bbanish [^.;]*?until the end phase\b/.test(cEff)) {
        addAct('rm_bounce');
      }
      if (/\btake control of\b/.test(cEff)
          || (/\battach\b[^.;]*?\bas material\b/.test(cEff) && /\byour opponent|on the field|either gy|opponent's gy\b/.test(preAndEff))
          || /\bplace (?:it|them|that target|1 [^.;]*?monster) face-up in (?:its owner's |your |their )?spell & trap zone as a continuous (?:spell|trap)\b/.test(cEff)) {
        addAct('rm_control');
      }
      if (/your opponent discards|\b(?:discard|banish|send|destroy|shuffle) (?:\d+ |1 )?(?:random )?cards? (?:from|in) your opponent's hand\b|look at your opponent's hand[^.;]*?\b(?:discard|banish|shuffle|send)\b/.test(cEff)) {
        tags.add('rm_handrip');
      }

      // --- 7. OTK & BIẾN ĐỔI ---
      if (/can make a second attack|can attack all monsters|can attack up to \d+|inflict piercing battle damage|battle damage your opponent takes[^.;]*?is doubled|can attack directly|gains? [1-9]\d{2,} atk|atk (?:is halved|becomes 0|becomes double|becomes twice)/.test(cEff)) {
        tags.add('otk_battle');
      }
      if (/inflict \d+ damage to your opponent|inflict damage to your opponent equal to|gain \d+ lp|gain lp equal to/.test(cEff)) {
        tags.add('otk_lp');
      }
      if (/increase or decrease (?:its|their) level|level becomes \d+|levels? of [^.;]*?become|treated as a tuner|becomes? (?:light|dark|fire|water|earth|wind)|becomes? [a-z-]+-type/.test(cEff)) {
        tags.add('otk_mod');
      }
    }

    if (hasActivatedClause && !hasHardOPT) {
      tags.add('mod_nohopt');
    }

    c._eff = { tags, nonTargetTags };
    return c._eff;
  }

  // Kiểm tra 1 lá bài có thỏa trạng thái bộ lọc { selected: Map<tagId, 1|-1>, mode: 'and'|'or' } hay không
  function matchesFilter(c, state) {
    if (!state || !state.selected || !state.selected.size) return true;
    const { tags, nonTargetTags } = analyzeCard(c);

    const posEffects = [];
    const posMods = [];
    for (const [id, sign] of state.selected.entries()) {
      if (sign === -1) {
        // Loại trừ (NOT): nếu lá bài có tag này thì loại ngay
        if (id === 'mod_nontarget') {
          if (nonTargetTags.size > 0) return false;
        } else if (tags.has(id)) {
          return false;
        }
      } else if (sign === 1) {
        if (id.startsWith('mod_')) posMods.push(id);
        else posEffects.push(id);
      }
    }

    // Các đặc tính PSCT (Modifiers) dương luôn đóng vai trò điều kiện bắt buộc đi kèm (AND)
    for (const mid of posMods) {
      if (mid === 'mod_nontarget') {
        const relActions = posEffects.filter(id => ACTION_NON_TARGET_IDS.has(id));
        if (relActions.length) {
          if (!relActions.some(id => nonTargetTags.has(id))) return false;
        } else if (nonTargetTags.size === 0) {
          return false;
        }
      } else if (!tags.has(mid)) {
        return false;
      }
    }

    if (!posEffects.length) return true;
    if (state.mode === 'or') {
      return posEffects.some(id => tags.has(id));
    }
    return posEffects.every(id => tags.has(id));
  }

  // Trả về danh sách các huy hiệu hiệu ứng nổi bật của 1 lá bài (để gắn lên khung Chi tiết lá bài)
  function getCardBadges(c) {
    const { tags, nonTargetTags } = analyzeCard(c);
    const out = [];
    for (const t of ALL_TAGS) {
      if (t.id === 'mod_nohopt') continue; // tránh nhiễu trên thẻ chi tiết, chỉ hiện khi lọc
      if (t.id === 'mod_nontarget') {
        if (nonTargetTags.size > 0) out.push({ id: t.id, label: '🎯 Không Target', cls: 'mod' });
        continue;
      }
      if (tags.has(t.id)) {
        const cls = t.id.startsWith('mod_') ? 'mod' : t.id === 'lock_self' ? 'warn' : (t.group || '');
        out.push({ id: t.id, label: (t.icon ? t.icon + ' ' : '') + t.label, tip: t.tip, cls });
      }
    }
    return out;
  }

  function renderBadgesHTML(c, clickable) {
    const b = getCardBadges(c);
    if (!b.length) return '';
    return `<div class="eff-card-badges">${b.map(x => `<span class="eff-cbadge ${esc(x.cls)}${clickable ? ' clickable' : ''}" data-eff-id="${esc(x.id)}" title="${esc((x.tip || '') + (clickable ? ' — Bấm để lọc các lá có cùng hiệu ứng này!' : ''))}">${esc(x.label)}</span>`).join('')}</div>`;
  }

  // ---------------- 3. COMPONENT GIAO DIỆN BỘ LỌC HIỆU ỨNG DÙNG CHUNG ----------------
  function mountEffectFilter(hostEl, opts) {
    if (!hostEl) return { getState: () => ({ selected: new Map(), mode: 'and' }), reset: () => {} };
    const onChange = (opts && opts.onChange) || (() => {});
    const compact = !!(opts && opts.compact);

    const state = {
      selected: new Map(), // tagId -> 1 (Phải có) | -1 (Loại trừ)
      mode: 'and',
      open: false,
      activeTab: 'all',
      search: '',
    };

    hostEl.innerHTML = `
      <div class="eff-bar">
        <button type="button" class="small eff-toggle-btn" id="effToggle">⚡ Lọc theo Hiệu ứng / Cơ chế PSCT <span class="eff-cnt" id="effCnt" style="display:none">0</span> ▾</button>
        <div class="eff-quick-presets">
          <button type="button" class="eff-preset" data-tag="mod_handtrap" title="Lọc nhanh toàn bộ Handtrap">🖐️ Handtrap</button>
          <button type="button" class="eff-preset" data-tag="res_search" title="Lọc bài Search từ Deck lên tay">🔍 Search bài</button>
          <button type="button" class="eff-preset" data-tag="res_draw" title="Lọc bài Rút thêm bài">🃏 Rút bài</button>
          <button type="button" class="eff-preset" data-tag="neg_omni" title="Lọc các boss Omni-Negate">🛑 Omni-Negate</button>
          ${compact ? '' : '<button type="button" class="eff-preset" data-tag="rm_tribute" title="Kaiju / Lava Golem / Super Poly / Goddess">🐢 Kaiju / Ăn quái</button><button type="button" class="eff-preset" data-tag="lock_summon" title="Cấm hoặc khóa Special Summon">🔒 Khóa Summon</button>'}
        </div>
        <button type="button" class="small eff-reset-btn" id="effResetTop" style="display:none">↺ Xóa hiệu ứng</button>
      </div>
      <div class="eff-active-strip" id="effActiveStrip" style="display:none"></div>
      <div class="eff-drawer" id="effDrawer" style="display:none">
        <div class="eff-drawer-top">
          <input type="text" id="effSearch" placeholder="Tìm nhanh hiệu ứng (vd: rút bài, lách ash, khóa mộ, kaiju, miễn nhiễm, tự khóa)..." style="flex:1;min-width:190px">
          <select id="effMode" title="Cách kết hợp nhiều hiệu ứng được chọn">
            <option value="and">Ghép: CÓ TẤT CẢ (AND)</option>
            <option value="or">Ghép: CÓ ÍT NHẤT 1 (OR)</option>
          </select>
          <button type="button" class="small" id="effClearIn">↺ Bỏ chọn hết</button>
        </div>
        <div class="eff-legend">💡 Mẹo: Bấm <b>1 lần</b> = <span class="lg-pos">+ Bắt buộc có</span> • Bấm <b>lần 2</b> = <span class="lg-neg">− Loại trừ (NOT)</span> • Bấm lần 3 = Tắt. Rê chuột lên từng mục để xem giải thích &amp; ví dụ!</div>
        <div class="eff-mods-box">
          <div class="eff-sec-title">⚡ Đặc tính PSCT Thông Minh (bật kèm với bất kỳ hiệu ứng nào bên dưới):</div>
          <div class="eff-chips" id="effMods"></div>
        </div>
        <div class="eff-tabs" id="effTabs"></div>
        <div class="eff-groups-body" id="effBody"></div>
      </div>
    `;

    const $ = s => hostEl.querySelector(s);

    function cycleTag(id) {
      const cur = state.selected.get(id) || 0;
      if (cur === 0) state.selected.set(id, 1);
      else if (cur === 1) state.selected.set(id, -1);
      else state.selected.delete(id);
      syncUI();
      onChange(state);
    }

    function syncUI() {
      const n = state.selected.size;
      const cntEl = $('#effCnt');
      cntEl.style.display = n ? 'inline-block' : 'none';
      cntEl.textContent = String(n);
      $('#effResetTop').style.display = n ? '' : 'none';
      $('#effToggle').classList.toggle('has-sel', n > 0);
      $('#effDrawer').style.display = state.open ? 'block' : 'none';

      // Đồng bộ nút preset nhanh
      hostEl.querySelectorAll('.eff-preset').forEach(btn => {
        const v = state.selected.get(btn.dataset.tag) || 0;
        btn.classList.toggle('pos', v === 1);
        btn.classList.toggle('neg', v === -1);
      });

      // Dải chip đang chọn (luôn hiển thị kể cả khi thu gọn bảng hiệu ứng)
      const strip = $('#effActiveStrip');
      if (!n) {
        strip.style.display = 'none';
        strip.innerHTML = '';
      } else {
        strip.style.display = 'flex';
        strip.innerHTML = `<span class="hint" style="margin-right:2px">Đang lọc (${state.mode.toUpperCase()}):</span>` +
          [...state.selected.entries()].map(([id, v]) => {
            const t = TAG_BY_ID.get(id) || { label: id };
            const cls = v === 1 ? 'pos' : 'neg';
            const pfx = v === 1 ? '+' : '−';
            return `<span class="eff-chip ${cls} mini" data-id="${esc(id)}" title="Bấm để đổi trạng thái / gỡ">${pfx} ${esc((t.icon ? t.icon + ' ' : '') + t.label)} <b class="x" data-rm="${esc(id)}">×</b></span>`;
          }).join('');
        strip.querySelectorAll('.eff-chip').forEach(el => {
          el.onclick = e => {
            const rm = e.target.getAttribute('data-rm');
            if (rm) { e.stopPropagation(); state.selected.delete(rm); syncUI(); onChange(state); }
            else cycleTag(el.dataset.id);
          };
        });
      }

      if (!state.open) return;

      // Render Modifiers
      const q = state.search.trim().toLowerCase();
      const matchSearch = t => !q || (t.label + ' ' + (t.tip || '')).toLowerCase().includes(q);

      const modsEl = $('#effMods');
      modsEl.innerHTML = MODIFIERS.filter(matchSearch).map(m => {
        const v = state.selected.get(m.id) || 0;
        const cls = v === 1 ? 'pos' : v === -1 ? 'neg' : '';
        const pfx = v === 1 ? '+ ' : v === -1 ? '− ' : '';
        return `<button type="button" class="eff-chip mod ${cls}" data-id="${esc(m.id)}" title="${esc(m.tip)}">${pfx}${esc(m.icon)} ${esc(m.label)}</button>`;
      }).join('') || '<span class="hint">Không có đặc tính khớp từ khóa.</span>';
      modsEl.querySelectorAll('.eff-chip').forEach(b => b.onclick = () => cycleTag(b.dataset.id));

      // Render Tabs
      const tabsEl = $('#effTabs');
      const allTabs = [{ id: 'all', label: 'Tất cả nhóm (7)' }, ...GROUPS.map(g => {
        const selInGrp = g.tags.filter(t => state.selected.has(t.id)).length;
        return { id: g.id, label: g.label + (selInGrp ? ` (${selInGrp})` : '') };
      })];
      tabsEl.innerHTML = allTabs.map(t => `<button type="button" class="eff-tab ${state.activeTab === t.id ? 'active' : ''}" data-tab="${esc(t.id)}">${esc(t.label)}</button>`).join('');
      tabsEl.querySelectorAll('.eff-tab').forEach(b => b.onclick = () => { state.activeTab = b.dataset.tab; syncUI(); });

      // Render Groups
      const bodyEl = $('#effBody');
      const visGroups = GROUPS.filter(g => q ? g.tags.some(matchSearch) : (state.activeTab === 'all' || state.activeTab === g.id));
      bodyEl.innerHTML = visGroups.map(g => {
        const visTags = g.tags.filter(matchSearch);
        return `<div class="eff-group">
          <div class="eff-group-hdr">${esc(g.fullLabel)}</div>
          <div class="eff-chips">
            ${visTags.map(t => {
              const v = state.selected.get(t.id) || 0;
              const cls = v === 1 ? 'pos' : v === -1 ? 'neg' : '';
              const pfx = v === 1 ? '+ ' : v === -1 ? '− ' : '';
              return `<button type="button" class="eff-chip ${cls}" data-id="${esc(t.id)}" title="${esc(t.tip)}">${pfx}${esc(t.label)}</button>`;
            }).join('')}
          </div>
        </div>`;
      }).join('') || '<div class="hint" style="padding:8px 0">Không tìm thấy hiệu ứng nào khớp từ khóa.</div>';
      bodyEl.querySelectorAll('.eff-chip').forEach(b => b.onclick = () => cycleTag(b.dataset.id));
    }

    $('#effToggle').onclick = () => { state.open = !state.open; syncUI(); };
    $('#effMode').onchange = e => { state.mode = e.target.value; syncUI(); onChange(state); };
    $('#effSearch').oninput = e => { state.search = e.target.value; syncUI(); };
    const clearAll = () => { state.selected.clear(); syncUI(); onChange(state); };
    $('#effResetTop').onclick = clearAll;
    $('#effClearIn').onclick = clearAll;
    hostEl.querySelectorAll('.eff-preset').forEach(btn => {
      btn.onclick = () => cycleTag(btn.dataset.tag);
    });

    syncUI();
    return {
      getState: () => state,
      hasActive: () => state.selected.size > 0,
      reset: clearAll,
      selectTag: (id, sign = 1) => { state.selected.set(id, sign); syncUI(); onChange(state); },
    };
  }

  window.YGO_EFFECTS = {
    MODIFIERS,
    GROUPS,
    ALL_TAGS,
    analyzeCard,
    matchesFilter,
    getCardBadges,
    renderBadgesHTML,
    mountEffectFilter,
  };
})();
