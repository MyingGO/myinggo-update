// Quản lý phiên bản hình ảnh lá bài (Alt Art chính thức, bản in Overframe LOCH/LOCR, Manga YAC1, khung Overframe/Manga & ảnh tự chọn).
(function () {
  'use strict';
  const LS_ART = 'ygo_card_art_v1';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtStat = v => v == null ? '' : (v < 0 ? '?' : String(v));

  let specialMap = null, specialLoading = null;
  let defaults = {};
  try { defaults = JSON.parse(localStorage.getItem(LS_ART)) || {}; } catch (e) { defaults = {}; }

  function saveDefaults() {
    try {
      localStorage.setItem(LS_ART, JSON.stringify(defaults));
      if (window.YGO_SYNC) window.YGO_SYNC.markChanged('art');
    } catch (e) { }
  }
  function reloadDefaults() {
    try { defaults = JSON.parse(localStorage.getItem(LS_ART)) || {}; } catch (e) { defaults = {}; }
  }

  function loadSpecial(force) {
    if (specialMap && !force) return Promise.resolve(specialMap);
    if (specialLoading && !force) return specialLoading;
    specialLoading = fetch('/ygodata/special_arts.json?t=' + Date.now())
      .then(r => r.ok ? r.json() : {})
      .then(j => { specialMap = (j && typeof j === 'object') ? j : {}; return specialMap; })
      .catch(() => { specialMap = specialMap || {}; return specialMap; });
    return specialLoading;
  }

  function getDefaultSpec(cardId) {
    return defaults[String(cardId)] || null;
  }

  function setDefaultSpec(cardId, spec) {
    const k = String(cardId);
    if (!spec || (spec.style === 'standard' && !spec.src && (!spec.imgId || Number(spec.imgId) === Number(cardId)))) {
      delete defaults[k];
    } else {
      defaults[k] = spec;
    }
    saveDefaults();
  }

  function getArtOptions(card) {
    const ids = (card.img && card.img.length) ? card.img : [card.id];
    const opts = ids.map((iid, idx) => ({
      key: 'id_' + iid,
      imgId: iid,
      label: idx === 0 ? 'Art gốc (#1)' : `Alt Art #${idx + 1}`,
      tag: idx === 0 ? '' : 'alt',
      small: `/ygodata/images/small/${iid}.jpg`,
      remoteSmall: `https://images.ygoprodeck.com/images/cards_small/${iid}.jpg`,
      big: `https://images.ygoprodeck.com/images/cards/${iid}.jpg`,
      crop: `https://images.ygoprodeck.com/images/cards_cropped/${iid}.jpg`,
    }));
    const sp = (specialMap || {})[String(card.id)] || [];
    sp.forEach(s => {
      const src = s.url || s.remote_url || '';
      if (!src) return;
      opts.push({
        key: s.key || src,
        src: s.url || '',
        remoteSrc: s.remote_url || '',
        label: s.label || 'Special Art',
        tag: s.tag || 'alt',
        small: s.url || s.remote_url,
        remoteSmall: s.remote_url || s.url,
        big: s.url || s.remote_url,
        crop: s.url || s.remote_url,
        isSpecial: true,
      });
    });
    return opts;
  }

  function variantCount(card) {
    const base = (card.img && card.img.length) ? card.img.length : 1;
    const sp = ((specialMap || {})[String(card.id)] || []).length;
    return base + sp;
  }

  function resolveSpec(card, overrideSpec) {
    const base = overrideSpec || getDefaultSpec(card.id) || {};
    const defId = (card.img && card.img[0]) || card.id;
    return {
      style: base.style || 'standard',
      imgId: base.imgId || defId,
      src: base.src || '',
      remoteSrc: base.remoteSrc || '',
      label: base.label || '',
    };
  }

  function attachCropImg(img, spec, card) {
    const iid = spec.imgId || (card.img && card.img[0]) || card.id;
    if (spec.src || spec.remoteSrc) {
      img.src = spec.src || spec.remoteSrc;
      if (spec.src && spec.remoteSrc) img.onerror = () => { img.onerror = null; img.src = spec.remoteSrc; };
      return;
    }
    const cropUrl = `https://images.ygoprodeck.com/images/cards_cropped/${iid}.jpg`;
    const localSmall = `/ygodata/images/small/${iid}.jpg`;
    const remoteSmall = `https://images.ygoprodeck.com/images/cards_small/${iid}.jpg`;
    img.src = cropUrl;
    img.onerror = () => {
      img.classList.add('fallback-zoom');
      img.onerror = () => { img.onerror = null; img.src = remoteSmall; };
      img.src = localSmall;
    };
  }

  // Tạo phần tử hiển thị lá bài (hỗ trợ cả ảnh chuẩn/Alt Art/Scan thực tế VÀ khung Overframe / Manga YAC1)
  function renderCardVisual(card, overrideSpec, size) {
    const sz = size || 'sm';
    const spec = resolveSpec(card, overrideSpec);
    const isSpell = /Spell/i.test(card.type || ''), isTrap = /Trap/i.test(card.type || '');
    const lv = card.level != null ? card.level : null;
    const stars = lv ? '★'.repeat(Math.min(13, Math.max(0, lv))) : (card.linkval != null ? `LINK-${card.linkval}` : (isSpell ? 'SPELL' : isTrap ? 'TRAP' : ''));

    if (spec.style === 'overframe') {
      const wrap = document.createElement('div');
      wrap.className = `ygo-frame ygo-overframe sz-${sz}`;
      wrap.title = `${card.name} [Overframe]`;
      const bg = document.createElement('img'); bg.className = 'of-bg'; bg.loading = 'lazy'; bg.alt = card.name;
      attachCropImg(bg, spec, card);
      const statTxt = (!isSpell && !isTrap)
        ? `ATK ${fmtStat(card.atk)}${card.def != null ? ' / DEF ' + fmtStat(card.def) : ''}`
        : (isSpell ? 'SPELL CARD' : 'TRAP CARD');
      wrap.innerHTML = `<div class="of-top"><div class="of-name">${esc(card.name)}</div><div class="of-stars">${esc(stars)}</div></div>
        <div class="of-bot"><span>${esc(statTxt)}</span><span class="of-tag">OVERFRAME</span></div>`;
      wrap.prepend(bg);
      return wrap;
    }

    if (spec.style === 'manga_bw' || spec.style === 'manga_color') {
      const wrap = document.createElement('div');
      const modeCls = spec.style === 'manga_bw' ? 'bw' : 'color';
      wrap.className = `ygo-frame ygo-manga ${modeCls} sz-${sz}`;
      wrap.title = `${card.name} [${spec.style === 'manga_bw' ? 'Manga B&W' : 'Manga Color'}]`;
      const artBox = document.createElement('div'); artBox.className = 'mg-art';
      const im = document.createElement('img'); im.loading = 'lazy'; im.alt = card.name;
      attachCropImg(im, spec, card);
      artBox.appendChild(im);
      const botHtml = (!isSpell && !isTrap)
        ? `<div class="mg-bot"><span>ATK ${esc(fmtStat(card.atk))}</span><span>${card.def != null ? 'DEF ' + esc(fmtStat(card.def)) : 'LINK-' + esc(card.linkval || '')}</span></div>`
        : `<div class="mg-bot single"><span>${isSpell ? 'MAGIC CARD' : 'TRAP CARD'}</span></div>`;
      wrap.innerHTML = `<div class="mg-name">${esc(card.name)}</div><div class="mg-stars">${esc(stars)}</div>`;
      wrap.appendChild(artBox);
      wrap.insertAdjacentHTML('beforeend', botHtml);
      return wrap;
    }

    // Khung chuẩn (Standard / Alt Art / Bản in thực tế / Custom Art)
    const img = document.createElement('img');
    img.loading = 'lazy'; img.alt = card.name; img.title = card.name;
    if (sz === 'lg') { img.style.height = '268px'; img.style.borderRadius = '10px'; }
    else if (sz === 'md') { img.style.height = '142px'; img.style.borderRadius = '7px'; }
    if (spec.src || spec.remoteSrc) {
      img.src = spec.src || spec.remoteSrc;
      if (spec.src && spec.remoteSrc) img.onerror = () => { img.onerror = null; img.src = spec.remoteSrc; };
    } else {
      const iid = spec.imgId || (card.img && card.img[0]) || card.id;
      const localSmall = `/ygodata/images/small/${iid}.jpg`;
      const remoteSmall = `https://images.ygoprodeck.com/images/cards_small/${iid}.jpg`;
      const remoteBig = `https://images.ygoprodeck.com/images/cards/${iid}.jpg`;
      if (sz === 'lg') {
        img.src = remoteBig;
        img.onerror = () => { img.onerror = () => { img.onerror = null; img.src = remoteSmall; }; img.src = localSmall; };
      } else {
        img.src = localSmall;
        img.onerror = () => { img.onerror = null; img.src = remoteSmall; };
      }
    }
    return img;
  }

  // Mở hộp thoại chọn Alt Art / Overframe / Manga / Ảnh tự chọn
  async function openPicker(card, opts) {
    opts = opts || {};
    await loadSpecial();
    const modal = document.getElementById('modal'), box = document.getElementById('modalBox');
    if (!modal || !box) return;
    let cur = resolveSpec(card, opts.currentSpec);

    function renderModal() {
      const artOpts = getArtOptions(card);
      const styles = [
        { id: 'standard', lbl: '🃏 Khung chuẩn / Bản gốc' },
        { id: 'overframe', lbl: '✨ Overframe (Tràn viền)' },
        { id: 'manga_bw', lbl: '📖 Manga Trắng Đen (YAC1)' },
        { id: 'manga_color', lbl: '🎨 Manga Màu (YAC1)' },
      ];
      box.innerHTML = `<div style="display:flex;flex-direction:column;align-items:center;gap:10px;min-width:190px">
          <div id="apPrev"></div>
          <div class="hint" style="text-align:center;max-width:190px"><b>${esc(card.name)}</b><br>${esc(cur.label || (cur.style === 'standard' ? 'Khung chuẩn' : cur.style.toUpperCase()))}</div>
        </div>
        <div style="flex:1;min-width:290px">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
            <h3 style="margin:0">🎨 Đổi Artwork &amp; Phong cách bài</h3>
            <button class="small" id="apClose">✕ Đóng</button>
          </div>
          <div class="hint" style="margin-top:6px">1. Chọn kiểu khung hiển thị (Frame Style):</div>
          <div class="style-pills" id="apStyles">
            ${styles.map(s => `<button class="small ${cur.style === s.id ? 'active' : ''}" data-st="${s.id}">${s.lbl}</button>`).join('')}
          </div>
          <div class="hint">2. Chọn phiên bản hình minh họa (${artOpts.length} bản có sẵn — Alt Art, Overframe, Manga, Custom):</div>
          <div class="art-grid" id="apGrid"></div>
          <div class="row" style="margin-top:12px">
            <button class="small" id="apScan" title="Quét trực tiếp trang Gallery của lá bài này để lấy thêm các bản in Overframe (LOCH/LOCR), Manga (YAC1), Collector OCG/TCG">🌐 Quét thêm bản in Overframe / Manga / OCG</button>
            <button class="small" id="apUpload" title="Tải ảnh Overframe / Manga / Custom Art từ máy tính vào kho lưu trữ">📁 Thêm ảnh từ máy</button>
            <input type="file" id="apFile" accept="image/*" style="display:none">
          </div>
          <div class="row" style="margin-top:12px;border-top:1px solid #2f3342;padding-top:12px">
            ${opts.onApplySingle ? '<button class="primary" id="apOne">✔ Áp dụng cho riêng lá này</button>' : ''}
            <button class="${opts.onApplySingle ? '' : 'primary'}" id="apAll">✔ ${opts.onApplySingle ? 'Áp dụng tất cả bản sao & đặt mặc định' : 'Đặt làm Art mặc định'}</button>
            <button class="small" id="apReset">↺ Về mặc định gốc</button>
          </div>
        </div>`;

      box.querySelector('#apPrev').appendChild(renderCardVisual(card, cur, 'lg'));

      const grid = box.querySelector('#apGrid');
      artOpts.forEach(o => {
        const isAct = o.src || o.remoteSrc
          ? ((cur.src && cur.src === o.src) || (cur.remoteSrc && cur.remoteSrc === o.remoteSrc))
          : (!cur.src && !cur.remoteSrc && Number(cur.imgId) === Number(o.imgId));
        const d = document.createElement('div');
        d.className = 'art-opt' + (isAct ? ' active' : '');
        const tagBadge = o.tag ? `<span class="atag ${esc(o.tag)}">${esc(o.tag.toUpperCase())}</span>` : '';
        const delBtn = o.isSpecial ? `<span class="adel" title="Xóa bản này">✕</span>` : '';
        d.innerHTML = `${tagBadge}${delBtn}<img alt=""><div class="albl" title="${esc(o.label)}">${esc(o.label)}</div>`;
        const im = d.querySelector('img');
        im.src = o.small;
        if (o.remoteSmall && o.small !== o.remoteSmall) im.onerror = () => { im.onerror = null; im.src = o.remoteSmall; };
        d.onclick = async () => {
          if (o.isSpecial) {
            let localUrl = o.src;
            if (!localUrl && o.remoteSrc) {
              try {
                const r = await fetch('/api/yugioh_combo/cache_variant', {
                  method: 'POST', headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ id: card.id, remote_url: o.remoteSrc, label: o.label, tag: o.tag, key: o.key }),
                }).then(x => x.json());
                if (r && r.entry && r.entry.url) { localUrl = r.entry.url; await loadSpecial(true); }
              } catch (e) { }
            }
            // Bản in thực tế (đã có khung Overframe/Manga sẵn trên bản scan) -> mặc định để style 'standard' để thấy nguyên bản scan gốc!
            cur = { style: 'standard', imgId: card.id, src: localUrl || '', remoteSrc: o.remoteSrc || '', label: o.label };
          } else {
            cur = { style: cur.style, imgId: o.imgId, src: '', remoteSrc: '', label: o.label };
          }
          renderModal();
        };
        if (o.isSpecial) {
          d.querySelector('.adel').onclick = async e => {
            e.stopPropagation();
            await fetch('/api/yugioh_combo/delete_special_art', {
              method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: card.id, key: o.key }),
            }).catch(() => null);
            await loadSpecial(true);
            if (cur.src === o.src) cur = { style: 'standard', imgId: (card.img && card.img[0]) || card.id, src: '', remoteSrc: '', label: '' };
            renderModal();
          };
        }
        grid.appendChild(d);
      });

      box.querySelectorAll('#apStyles button').forEach(b => {
        b.onclick = () => { cur = { ...cur, style: b.dataset.st }; renderModal(); };
      });
      box.querySelector('#apClose').onclick = () => modal.classList.remove('show');

      box.querySelector('#apScan').onclick = async e => {
        const btn = e.currentTarget;
        btn.disabled = true; btn.textContent = '⏳ Đang quét bản in từ Gallery...';
        try {
          const r = await fetch('/api/yugioh_combo/fetch_card_arts', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: card.id, name: card.name }),
          }).then(x => x.json());
          await loadSpecial(true);
          const n = (r && r.variants) ? r.variants.length : 0;
          if (opts.toast) opts.toast(n ? `Đã tìm thấy ${n} phiên bản đặc biệt!` : 'Không tìm thấy thêm bản in đặc biệt nào khác.');
        } catch (err) {
          if (opts.toast) opts.toast('Không quét được (kiểm tra kết nối mạng / máy chủ MyingGo).');
        }
        renderModal();
      };

      box.querySelector('#apUpload').onclick = () => box.querySelector('#apFile').click();
      box.querySelector('#apFile').onchange = ev => {
        const f = ev.target.files[0]; if (!f) return;
        const lbl = prompt('Đặt tên phiên bản (vd: Overframe, Manga Color, Custom):', f.name.replace(/\.[^.]+$/, '')) || 'Custom Art';
        const tagGuess = /overframe/i.test(lbl) ? 'overframe' : /manga/i.test(lbl) ? 'manga' : 'custom';
        const rd = new FileReader();
        rd.onload = async () => {
          const dataB64 = String(rd.result || '');
          try {
            const r = await fetch('/api/yugioh_combo/upload_custom_art', {
              method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: card.id, filename: f.name, data_b64: dataB64, label: lbl, tag: tagGuess }),
            }).then(x => x.json());
            if (r && r.entry) {
              await loadSpecial(true);
              cur = { style: 'standard', imgId: card.id, src: r.entry.url, remoteSrc: '', label: r.entry.label };
              if (opts.toast) opts.toast('Đã lưu ảnh riêng vào kho Yu-Gi-Oh!');
              renderModal();
              return;
            }
          } catch (err) { }
          cur = { style: 'standard', imgId: card.id, src: dataB64, remoteSrc: '', label: lbl };
          renderModal();
        };
        rd.readAsDataURL(f);
      };

      if (box.querySelector('#apOne')) {
        box.querySelector('#apOne').onclick = () => {
          modal.classList.remove('show');
          opts.onApplySingle({ ...cur });
        };
      }
      box.querySelector('#apAll').onclick = () => {
        setDefaultSpec(card.id, { ...cur });
        modal.classList.remove('show');
        if (opts.onApplyAll) opts.onApplyAll({ ...cur });
        if (opts.toast) opts.toast(`Đã áp dụng art cho "${card.name}"`);
      };
      box.querySelector('#apReset').onclick = () => {
        const def = { style: 'standard', imgId: (card.img && card.img[0]) || card.id, src: '', remoteSrc: '', label: '' };
        setDefaultSpec(card.id, null);
        modal.classList.remove('show');
        if (opts.onApplyAll) opts.onApplyAll(null);
        else if (opts.onApplySingle) opts.onApplySingle(null);
        if (opts.toast) opts.toast('Đã khôi phục Art gốc');
      };
    }

    modal.classList.add('show');
    renderModal();
  }

  window.YGO_ART = {
    loadSpecial,
    reloadDefaults,
    getDefaultSpec,
    setDefaultSpec,
    getArtOptions,
    variantCount,
    resolveSpec,
    renderCardVisual,
    openPicker,
  };
})();
