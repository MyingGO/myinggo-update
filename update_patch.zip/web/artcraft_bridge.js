/**
 * MyingGo ArtCraft Bridge (PhotoCraft, FilmCraft, EffectCraft)
 * 1. Hỗ trợ Ctrl+V / Dán ảnh trực tiếp từ Clipboard bên ngoài vào Canvas (qua cầu nối Drop File).
 * 2. Đồng bộ hóa phiên làm việc (Session Handover) giữa Khung trong MyingGo và Cửa sổ mở riêng (🗖).
 * 3. Thu thập Log lỗi, trạng thái GPU/WASM, Console Error/Warn theo thời gian thực gửi về Bảng Log AI.
 */
(function () {
  if (window.__MG_ARTCRAFT_BRIDGE__) return;
  window.__MG_ARTCRAFT_BRIDGE__ = true;

  const path = location.pathname.toLowerCase();
  const fid = path.includes('photocraft')
    ? 'photocraft'
    : path.includes('filmcraft')
    ? 'filmcraft'
    : path.includes('effectcraft')
    ? 'effectcraft'
    : 'artcraft';

  const isStandalone = window.parent === window || location.search.includes('standalone=1');
  const modeLabel = isStandalone ? 'Màn hình riêng (🗖)' : 'Khung trong MyingGo';
  const bc = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('myinggo_artcraft') : null;

  // =========================================================================
  // 1. GỬI LOG CHẨN ĐOÁN VỀ SERVER & KHUNG MYINGGO
  // =========================================================================
  function sendLog(level, message, detail) {
    const payload = {
      source: fid,
      level: level || 'INFO',
      message: `[${modeLabel}] ${message}`,
      detail: detail ? String(detail) : '',
    };
    try {
      fetch('/api/logs/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).catch(() => {});
    } catch (e) {}
    try {
      if (bc) bc.postMessage({ type: 'log', fid, entry: payload });
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'mg_artcraft_log', fid, entry: payload }, '*');
      }
    } catch (e) {}
  }

  function showMiniToast(msg, isErr) {
    let el = document.getElementById('mg-bridge-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'mg-bridge-toast';
      el.style.cssText =
        'position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:999999;' +
        'padding:8px 18px;border-radius:999px;font:600 13px/1.4 system-ui,sans-serif;' +
        'color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.45);pointer-events:none;transition:opacity .25s;opacity:0;';
      document.body.appendChild(el);
    }
    el.style.background = isErr ? 'rgba(220,38,38,.94)' : 'rgba(37,99,235,.94)';
    el.textContent = msg;
    el.style.opacity = '1';
    clearTimeout(el._t);
    el._t = setTimeout(() => {
      el.style.opacity = '0';
    }, 2600);
  }

  // Bắt console.error, console.warn, console.info và lỗi toàn cục
  const origError = console.error.bind(console);
  const origWarn = console.warn.bind(console);
  const origInfo = console.info.bind(console);

  function fmtArgs(args) {
    return args
      .map((a) => {
        if (a instanceof Error) return a.stack || a.message;
        if (typeof a === 'object' && a !== null) {
          try {
            return JSON.stringify(a);
          } catch {
            return String(a);
          }
        }
        return String(a);
      })
      .join(' ');
  }

  console.error = (...args) => {
    origError(...args);
    const txt = fmtArgs(args);
    if (txt) sendLog('ERROR', txt.slice(0, 350), txt.length > 350 ? txt : '');
  };

  console.warn = (...args) => {
    origWarn(...args);
    const txt = fmtArgs(args);
    if (txt && !txt.includes('deprecated parameters for')) {
      sendLog('WARN', txt.slice(0, 350), txt.length > 350 ? txt : '');
    }
  };

  console.info = (...args) => {
    origInfo(...args);
    const txt = fmtArgs(args);
    if (txt && /backend|wgpu|webgl|adapter|served font|ready|opfs/i.test(txt)) {
      sendLog('RUNTIME', txt.slice(0, 350));
    }
  };

  window.addEventListener('error', (ev) => {
    const msg = ev.message || String(ev.error || 'Lỗi Runtime');
    const stack = ev.error && ev.error.stack ? ev.error.stack : `${ev.filename || ''}:${ev.lineno || ''}`;
    sendLog('ERROR', `Lỗi JS/WASM: ${msg}`, stack);
  });

  window.addEventListener('unhandledrejection', (ev) => {
    const reason = ev.reason && (ev.reason.stack || ev.reason.message) ? ev.reason.stack || ev.reason.message : String(ev.reason);
    sendLog('ERROR', `Lỗi Promise (Unhandled Rejection): ${ String(ev.reason).slice(0, 200) }`, reason);
  });

  sendLog('RUNTIME', `Đang khởi tạo bộ nhân ${fid.toUpperCase()}...`, `URL: ${location.href}`);

  // =========================================================================
  // 2. INDEXEDDB LƯU TRỮ SNAPSHOT ĐỒNG BỘ GIỮA KHUNG TRONG & CỬA SỔ RIÊNG
  // =========================================================================
  const DB_NAME = 'myinggo_artcraft_sync_v1';
  const STORE_NAME = 'snapshots';

  function openSyncDB() {
    return new Promise((resolve, reject) => {
      if (typeof indexedDB === 'undefined') return reject(new Error('no indexedDB'));
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function saveSyncSnapshot(key, data) {
    try {
      const db = await openSyncDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).put(data, key);
        tx.oncomplete = () => {
          db.close();
          resolve(true);
        };
        tx.onerror = () => {
          db.close();
          reject(tx.error);
        };
      });
    } catch (e) {
      return false;
    }
  }

  async function loadSyncSnapshot(key) {
    try {
      const db = await openSyncDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const req = tx.objectStore(STORE_NAME).get(key);
        req.onsuccess = () => {
          db.close();
          resolve(req.result || null);
        };
        req.onerror = () => {
          db.close();
          reject(req.error);
        };
      });
    } catch (e) {
      return null;
    }
  }

  // Bắt URL.createObjectURL và HTMLAnchorElement.prototype.click trong PhotoCraft để chụp file .psd/.pcraft khi đồng bộ
  const blobUrlMap = new WeakMap();
  const urlStringMap = new Map();
  const origCreateObjectURL = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (obj) {
    const url = origCreateObjectURL(obj);
    if (obj instanceof Blob) {
      urlStringMap.set(url, obj);
      setTimeout(() => urlStringMap.delete(url), 60000);
    }
    return url;
  };

  let silentSaveResolver = null;
  const origAnchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function (...args) {
    try {
      const dlName = this.getAttribute('download') || this.download;
      const href = this.getAttribute('href') || this.href;
      if (dlName && href && urlStringMap.has(href)) {
        const blob = urlStringMap.get(href);
        // Lưu bản snapshot mới nhất vào IndexedDB chung để hai cửa sổ luôn đồng bộ
        saveSyncSnapshot(fid + '_doc', {
          name: dlName,
          blob: blob,
          type: blob.type || 'application/octet-stream',
          ts: Date.now(),
          from: isStandalone ? 'standalone' : 'embedded',
        }).then(() => {
          if (bc) bc.postMessage({ type: 'snapshot_updated', fid, name: dlName, ts: Date.now() });
        });

        if (silentSaveResolver) {
          const r = silentSaveResolver;
          silentSaveResolver = null;
          r({ ok: true, name: dlName, size: blob.size });
          sendLog('SYNC', `Đã đồng bộ tự động tài liệu "${dlName}" (${Math.round(blob.size / 1024)} KB) giữa 2 chế độ màn hình.`);
          return; // Không bật hộp thoại tải file xuống trình duyệt khi đang chuyển màn hình tự động
        } else {
          sendLog('INFO', `Đã xuất / lưu file "${dlName}" (${Math.round(blob.size / 1024)} KB).`);
        }
      }
    } catch (e) {}
    return origAnchorClick.apply(this, args);
  };

  // Bắt sự kiện chọn file qua <input type="file"> để lưu lại file gốc vào snapshot đồng bộ
  window.addEventListener(
    'change',
    (e) => {
      const t = e.target;
      if (t && t.tagName === 'INPUT' && t.type === 'file' && t.files && t.files.length > 0) {
        const f = t.files[0];
        sendLog('INFO', `Đã mở file từ máy tính: "${f.name}" (${Math.round(f.size / 1024)} KB)`);
        if (fid === 'photocraft' && f.size < 150 * 1024 * 1024) {
          saveSyncSnapshot(fid + '_doc', {
            name: f.name,
            blob: f.slice(0, f.size, f.type),
            type: f.type,
            ts: Date.now(),
            from: isStandalone ? 'standalone' : 'embedded',
          });
        }
      }
    },
    true
  );

  // =========================================================================
  // 3. CẦU NỐI DÁN ẢNH TỪ CLIPBOARD (CTRL+V) & NẠP FILE VÀO CANVAS
  // =========================================================================
  function getCanvas() {
    return (
      document.getElementById('photocraft_canvas') ||
      document.getElementById('filmcraft_canvas') ||
      document.getElementById('effectcraft_canvas') ||
      document.querySelector('canvas')
    );
  }

  function dropFileIntoApp(file, placeOnActiveCanvas = true) {
    const canvas = getCanvas();
    if (!canvas) {
      sendLog('WARN', 'Chưa tìm thấy khung Canvas để nạp ảnh.');
      return false;
    }
    try {
      // Nếu là FilmCraft và có sẵn API window.filmcraft.importFiles thì gọi trực tiếp
      if (fid === 'filmcraft' && window.filmcraft && typeof window.filmcraft.importFiles === 'function') {
        window.filmcraft.importFiles([file]);
        sendLog('INFO', `📋 Đã nạp "${file.name}" (${Math.round(file.size / 1024)} KB) vào FilmCraft.`);
        showMiniToast(`📋 Đã dán "${file.name}" vào FilmCraft`);
        return true;
      }

      const dt = new DataTransfer();
      dt.items.add(file);
      const rect = canvas.getBoundingClientRect();
      // Trong PhotoCraft:
      // - Nếu thả ở giữa vùng vẽ (0.42 * width, 0.52 * height): khi đang mở 1 ảnh thì sẽ chèn thành Layer mới; khi ở màn hình chính sẽ mở thành Document mới.
      // - Nếu thả ở góc trên cùng (12, 12): luôn mở thành Document độc lập (dùng khi khôi phục file .psd đồng bộ).
      const cx = placeOnActiveCanvas ? Math.round(rect.left + rect.width * 0.42) : Math.round(rect.left + 12);
      const cy = placeOnActiveCanvas ? Math.round(rect.top + rect.height * 0.52) : Math.round(rect.top + 12);

      const overEv = new DragEvent('dragover', {
        bubbles: true,
        cancelable: true,
        clientX: cx,
        clientY: cy,
        dataTransfer: dt,
      });
      const dropEv = new DragEvent('drop', {
        bubbles: true,
        cancelable: true,
        clientX: cx,
        clientY: cy,
        dataTransfer: dt,
      });
      if (!dropEv.dataTransfer) {
        Object.defineProperty(dropEv, 'dataTransfer', { value: dt });
      }
      canvas.dispatchEvent(overEv);
      canvas.dispatchEvent(dropEv);

      // Lưu vào snapshot nếu là PhotoCraft
      if (fid === 'photocraft' && file.size < 150 * 1024 * 1024) {
        saveSyncSnapshot(fid + '_doc', {
          name: file.name,
          blob: file.slice(0, file.size, file.type),
          type: file.type,
          ts: Date.now(),
          from: isStandalone ? 'standalone' : 'embedded',
        });
      }
      return true;
    } catch (err) {
      sendLog('ERROR', `Lỗi khi nạp ảnh từ Clipboard: ${err.message || err}`);
      return false;
    }
  }

  // Theo dõi xem người dùng vừa bấm Ctrl+C / Ctrl+X nội bộ trong PhotoCraft hay vừa Copy ảnh từ bên ngoài
  let internalCopyActive = false;
  let suppressNextVKeyUp = false;
  let pendingCtrlVTimer = null;

  window.addEventListener('blur', () => {
    // Khi người dùng chuyển ra ngoài (Snipping Tool, trình duyệt, Zalo, Explorer...) để copy ảnh mới
    internalCopyActive = false;
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) internalCopyActive = false;
  });

  function isTypingInHtmlInput() {
    const el = document.activeElement;
    if (!el) return false;
    const tag = el.tagName;
    if (tag === 'TEXTAREA' || el.isContentEditable) return true;
    if (tag === 'INPUT') {
      const t = (el.type || '').toLowerCase();
      // eframe tạo 1 ô input ẩn để hứng sự kiện IME/Paste trên web; không tính ô ẩn đó là ô nhập liệu văn bản thông thường
      if (el.offsetWidth > 20 && el.offsetHeight > 10 && t !== 'file' && t !== 'button') return true;
    }
    return false;
  }

  function dispatchSyntheticCtrlV() {
    const canvas = getCanvas() || window;
    const kd = new KeyboardEvent('keydown', {
      key: 'v',
      code: 'KeyV',
      keyCode: 86,
      which: 86,
      ctrlKey: true,
      bubbles: true,
      cancelable: true,
    });
    const ku = new KeyboardEvent('keyup', {
      key: 'v',
      code: 'KeyV',
      keyCode: 86,
      which: 86,
      ctrlKey: true,
      bubbles: true,
      cancelable: true,
    });
    kd._mgBypass = true;
    ku._mgBypass = true;
    canvas.dispatchEvent(kd);
    setTimeout(() => canvas.dispatchEvent(ku), 16);
  }

  // Chặn trước sự kiện keydown Ctrl+V trong PhotoCraft để tránh eframe báo "Paste is not available: the clipboard is empty"
  // trước khi sự kiện paste (chứa dữ liệu ảnh từ OS Clipboard) kịp nổ ra ngay sau đó.
  window.addEventListener(
    'keydown',
    (e) => {
      if (e._mgBypass) return;
      const ctrl = e.ctrlKey || e.metaKey;
      if (!ctrl || e.altKey) return;
      const k = (e.key || '').toLowerCase();
      if (k === 'c' || k === 'x' || e.code === 'KeyC' || e.code === 'KeyX') {
        internalCopyActive = true;
        return;
      }
      if (fid === 'photocraft' && !e.shiftKey && (k === 'v' || e.code === 'KeyV') && !isTypingInHtmlInput()) {
        // Ngăn eframe nhận keydown Ctrl+V ngay lập tức, nhưng KHÔNG gọi e.preventDefault()
        // để trình duyệt vẫn kích hoạt sự kiện 'paste' chứa ảnh Clipboard ngay lập tức!
        e.stopImmediatePropagation();
        clearTimeout(pendingCtrlVTimer);
        pendingCtrlVTimer = setTimeout(() => {
          pendingCtrlVTimer = null;
          dispatchSyntheticCtrlV();
        }, 70);
      }
    },
    true
  );

  window.addEventListener(
    'keyup',
    (e) => {
      if (e._mgBypass) return;
      const k = (e.key || '').toLowerCase();
      if (fid === 'photocraft' && (k === 'v' || e.code === 'KeyV') && suppressNextVKeyUp) {
        e.stopImmediatePropagation();
        suppressNextVKeyUp = false;
      }
    },
    true
  );

  window.addEventListener(
    'paste',
    (e) => {
      if (pendingCtrlVTimer) {
        clearTimeout(pendingCtrlVTimer);
        pendingCtrlVTimer = null;
      }
      const cd = e.clipboardData;
      let imageFile = null;
      if (cd && cd.items) {
        for (let i = 0; i < cd.items.length; i++) {
          const item = cd.items[i];
          if (item.kind === 'file' && item.type && item.type.startsWith('image/')) {
            const blob = item.getAsFile();
            if (blob) {
              const ext = (item.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
              imageFile = new File([blob], `Clipboard_${Date.now()}.${ext}`, { type: item.type });
              break;
            }
          }
        }
      }
      if (!imageFile && cd && cd.files && cd.files.length > 0) {
        for (let i = 0; i < cd.files.length; i++) {
          const f = cd.files[i];
          if (f.type && f.type.startsWith('image/')) {
            imageFile = f;
            break;
          }
        }
      }

      if (imageFile && !internalCopyActive) {
        e.preventDefault();
        e.stopImmediatePropagation();
        suppressNextVKeyUp = true;
        setTimeout(() => {
          suppressNextVKeyUp = false;
        }, 400);

        const ok = dropFileIntoApp(imageFile, true);
        if (ok) {
          sendLog(
            'INFO',
            `📋 Đã dán ảnh từ Clipboard (${Math.round(imageFile.size / 1024)} KB, ${imageFile.type}) vào ${fid.toUpperCase()}.`
          );
          showMiniToast(`📋 Đã dán ảnh từ Clipboard (${Math.round(imageFile.size / 1024)} KB)`);
        }
      } else if (fid === 'photocraft') {
        // Không có ảnh ngoài Clipboard (hoặc đang copy layer nội bộ): chuyển tiếp Ctrl+V vào PhotoCraft
        dispatchSyntheticCtrlV();
      }
    },
    true
  );

  // Hàm đọc Clipboard chủ động khi người dùng bấm nút "📋 Dán ảnh" trên thanh công cụ
  async function pasteFromClipboardButton() {
    try {
      if (!navigator.clipboard || !navigator.clipboard.read) {
        showMiniToast('Hãy bấm tổ hợp phím Ctrl + V để dán ảnh!', false);
        return false;
      }
      const items = await navigator.clipboard.read();
      for (const item of items) {
        const imgType = item.types.find((t) => t.startsWith('image/'));
        if (imgType) {
          const blob = await item.getType(imgType);
          const ext = (imgType.split('/')[1] || 'png').replace('jpeg', 'jpg');
          const file = new File([blob], `Clipboard_${Date.now()}.${ext}`, { type: imgType });
          internalCopyActive = false;
          const ok = dropFileIntoApp(file, true);
          if (ok) {
            sendLog('INFO', `📋 Đã dán ảnh bằng nút Dán (${Math.round(file.size / 1024)} KB, ${imgType}).`);
            showMiniToast(`📋 Đã dán ảnh từ Clipboard (${Math.round(file.size / 1024)} KB)`);
            return true;
          }
        }
      }
      // Nếu không có ảnh bên ngoài thì kích hoạt Ctrl+V nội bộ
      dispatchSyntheticCtrlV();
      showMiniToast('Không thấy ảnh mới trong Clipboard hệ thống — đã gọi lệnh Paste nội bộ.', false);
      return false;
    } catch (err) {
      sendLog('WARN', `Không đọc trực tiếp được Clipboard qua nút bấm: ${err.message || err}. Hãy nhấn Ctrl+V.`);
      showMiniToast('Hãy click vào vùng vẽ rồi nhấn Ctrl + V để dán ảnh!', false);
      return false;
    }
  }

  // =========================================================================
  // 4. ĐỒNG BỘ PHIÊN LÀM VIỆC (HANDOVER) GIỮA KHUNG TRONG & MÀN HÌNH RIÊNG
  // =========================================================================
  async function triggerSilentSaveForHandover() {
    try {
      if (fid === 'effectcraft' && window.effectcraft && typeof window.effectcraft.flush === 'function') {
        await window.effectcraft.flush();
        sendLog('SYNC', 'Đã lưu đồng bộ dữ liệu EffectCraft vào bộ nhớ chung.');
        return true;
      }
      if (fid === 'photocraft') {
        const canvas = getCanvas();
        if (!canvas) return false;
        // Nếu đang có hộp biến đổi Free Transform (vừa dán ảnh chưa nhấn Enter), gửi phím Enter để chốt layer trước khi lưu
        const enterDown = new KeyboardEvent('keydown', {
          key: 'Enter',
          code: 'Enter',
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true,
        });
        const enterUp = new KeyboardEvent('keyup', {
          key: 'Enter',
          code: 'Enter',
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true,
        });
        canvas.dispatchEvent(enterDown);
        canvas.dispatchEvent(enterUp);

        await new Promise((r) => setTimeout(r, 40));

        return await new Promise((resolve) => {
          let settled = false;
          const done = (val) => {
            if (settled) return;
            settled = true;
            silentSaveResolver = null;
            resolve(val);
          };
          silentSaveResolver = done;
          setTimeout(() => done(false), 380);

          const sDown = new KeyboardEvent('keydown', {
            key: 's',
            code: 'KeyS',
            keyCode: 83,
            which: 83,
            ctrlKey: true,
            bubbles: true,
            cancelable: true,
          });
          const sUp = new KeyboardEvent('keyup', {
            key: 's',
            code: 'KeyS',
            keyCode: 83,
            which: 83,
            ctrlKey: true,
            bubbles: true,
            cancelable: true,
          });
          canvas.dispatchEvent(sDown);
          setTimeout(() => canvas.dispatchEvent(sUp), 20);
        });
      }
    } catch (e) {}
    return false;
  }

  // Khôi phục tài liệu PhotoCraft đã lưu trong IndexedDB khi chuyển qua lại giữa khung trong và cửa sổ riêng
  async function restoreSyncedDocumentIfNeeded() {
    if (fid !== 'photocraft') return;
    const snap = await loadSyncSnapshot(fid + '_doc');
    if (!snap || !snap.blob) return;
    // Chỉ tự động nạp nếu snapshot vừa được cập nhật trong vòng 12 giờ qua
    if (Date.now() - (snap.ts || 0) > 12 * 3600 * 1000) return;
    try {
      const file = new File([snap.blob], snap.name || 'Project.psd', {
        type: snap.type || 'image/vnd.adobe.photoshop',
      });
      setTimeout(() => {
        dropFileIntoApp(file, false);
        sendLog(
          'SYNC',
          `🔄 Đã đồng bộ & khôi phục phiên làm việc "${file.name}" (${Math.round(file.size / 1024)} KB).`
        );
        showMiniToast(`🔄 Đã đồng bộ phiên làm việc: ${file.name}`);
      }, 280);
    } catch (e) {}
  }

  // Theo dõi khi bộ nhân WASM nạp xong
  let appReady = false;
  const readyCheck = setInterval(() => {
    const loadingEl = document.getElementById('photocraft_loading') || document.getElementById('loading');
    const isGone = !loadingEl || loadingEl.style.display === 'none' || !document.body.contains(loadingEl);
    const ecReady = fid === 'effectcraft' && window.effectcraftLoad && window.effectcraftLoad.readyMs;
    const fcReady = fid === 'filmcraft' && window.filmcraftLoad && window.filmcraftLoad.readyMs;
    if (isGone || ecReady || fcReady) {
      clearInterval(readyCheck);
      if (!appReady) {
        appReady = true;
        sendLog('RUNTIME', `✅ ${fid.toUpperCase()} đã khởi tạo xong trên ${modeLabel} và sẵn sàng thao tác!`);
        restoreSyncedDocumentIfNeeded();
      }
    }
  }, 300);

  // Nhận lệnh từ khung cha MyingGo hoặc từ cửa sổ còn lại qua postMessage / BroadcastChannel
  window.addEventListener('message', async (ev) => {
    const d = ev.data;
    if (!d || typeof d !== 'object') return;
    if (d.type === 'mg_paste_clipboard') {
      await pasteFromClipboardButton();
    } else if (d.type === 'mg_prepare_handover') {
      await triggerSilentSaveForHandover();
      if (ev.source) {
        ev.source.postMessage({ type: 'mg_handover_ready', fid }, '*');
      }
    }
  });

  if (bc) {
    bc.onmessage = async (ev) => {
      const d = ev.data || {};
      if (d.fid !== fid) return;
      if (d.type === 'request_close_standalone' && isStandalone) {
        await triggerSilentSaveForHandover();
        fetch('/api/artcraft/window_state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fid, open: false }),
        }).catch(() => {});
        bc.postMessage({ type: 'standalone_closed', fid });
        window.close();
      } else if (d.type === 'focus_standalone' && isStandalone) {
        window.focus();
      }
    };
  }

  // =========================================================================
  // 5. THANH ĐIỀU KHIỂN NỔI & HEARTBEAT KHI MỞ Ở MÀN HÌNH RIÊNG (STANDALONE)
  // =========================================================================
  if (isStandalone) {
    const notifyOpen = (open) => {
      const body = JSON.stringify({ fid, open });
      if (!open && navigator.sendBeacon) {
        navigator.sendBeacon('/api/artcraft/window_state', body);
      } else {
        fetch('/api/artcraft/window_state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body,
        }).catch(() => {});
      }
    };

    notifyOpen(true);
    if (bc) bc.postMessage({ type: 'standalone_opened', fid });
    const hb = setInterval(() => notifyOpen(true), 2000);

    window.addEventListener('pagehide', () => {
      clearInterval(hb);
      notifyOpen(false);
      if (bc) bc.postMessage({ type: 'standalone_closed', fid });
    });

    // Tạo cụm nút nổi nhỏ gọn ở góc phải dưới để đồng bộ về khung MyingGo hoặc Dán ảnh nhanh
    window.addEventListener('DOMContentLoaded', () => {
      const bar = document.createElement('div');
      bar.id = 'mg-standalone-bar';
      bar.style.cssText =
        'position:fixed;bottom:32px;right:16px;z-index:99999;display:flex;align-items:center;gap:6px;' +
        'background:rgba(24,24,36,.88);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.18);' +
        'padding:5px 10px;border-radius:999px;box-shadow:0 6px 20px rgba(0,0,0,.45);font:600 12px system-ui,sans-serif;color:#f1f1f5;';
      bar.innerHTML = `
        <span style="display:inline-flex;align-items:center;gap:5px;padding:0 6px;color:#60a5fa">
          <span style="width:8px;height:8px;border-radius:50%;background:#2563eb;box-shadow:0 0 8px #3b82f6"></span>
          Đồng bộ MyingGo
        </span>
        ${
          fid === 'photocraft'
            ? '<button id="mg-sa-paste" style="border:0;border-radius:999px;padding:5px 11px;background:#2563eb;color:#fff;cursor:pointer;font:inherit">📋 Dán ảnh (Ctrl+V)</button>'
            : ''
        }
        <button id="mg-sa-dock" style="border:0;border-radius:999px;padding:5px 11px;background:rgba(255,255,255,.14);color:#fff;cursor:pointer;font:inherit" title="Lưu phiên hiện tại và đưa giao diện quay về bên trong khung MyingGo">📥 Đưa về khung MyingGo</button>
      `;
      document.body.appendChild(bar);

      const pasteBtn = document.getElementById('mg-sa-paste');
      if (pasteBtn) {
        pasteBtn.onclick = () => pasteFromClipboardButton();
      }
      const dockBtn = document.getElementById('mg-sa-dock');
      if (dockBtn) {
        dockBtn.onclick = async () => {
          dockBtn.disabled = true;
          dockBtn.textContent = 'Đang đồng bộ về MyingGo...';
          await triggerSilentSaveForHandover();
          notifyOpen(false);
          if (bc) bc.postMessage({ type: 'standalone_closed', fid });
          window.close();
        };
      }
    });
  }
})();
