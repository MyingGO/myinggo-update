/**
 * T2MG ArtCraft Bridge (PhotoCraft, FilmCraft, EffectCraft)
 * 1. Hỗ trợ Ctrl+V / Dán ảnh trực tiếp từ Clipboard bên ngoài vào Canvas (qua cầu nối Drop File).
 * 2. Đồng bộ hóa phiên làm việc (Session Handover) giữa Khung trong T2MG và Cửa sổ mở riêng (🗖).
 * 3. Thu thập Log lỗi, trạng thái GPU/WASM, Console Error/Warn theo thời gian thực gửi về Bảng Log AI.
 * 4. Tích hợp Thanh công cụ nổi AI kiểu Adobe Photoshop (Contextual Task Bar):
 *    [✨ Generative fill] [🩹 Remove] [🖌️/⬚/✏️] [⚙️ Cài đặt 3 Nguồn AI] [Deselect]
 */
(function () {
  if (window.__MG_ARTCRAFT_BRIDGE__) return;
  window.__MG_ARTCRAFT_BRIDGE__ = true;

  const path = location.pathname.toLowerCase();
  const fid = path.includes('photocraft')
    ? 'photocraft'
    : path.includes('filmcraft')
    ? 'filmcraft'
    : path.includes('effectcraft')
    ? 'effectcraft'
    : 'artcraft';

  const isStandalone = window.parent === window || location.search.includes('standalone=1');
  const modeLabel = isStandalone ? 'Màn hình riêng (🗖)' : 'Khung trong T2MG';
  const bc = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('myinggo_artcraft') : null;

  // =========================================================================
  // 0. HOOK CANVAS (WEBGL2 / WEBGPU / RAF) ĐỂ CHỤP ẢNH VÙNG VẼ CHÍNH XÁC 100%
  // =========================================================================
  let pendingRafCaptureResolver = null;
  const origGetContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function (type, attrs) {
    if (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl') {
      attrs = Object.assign({}, attrs || {}, { preserveDrawingBuffer: true });
    }
    return origGetContext.call(this, type, attrs);
  };

  if (typeof GPUCanvasContext !== 'undefined' && GPUCanvasContext.prototype.configure) {
    const origConfigure = GPUCanvasContext.prototype.configure;
    GPUCanvasContext.prototype.configure = function (cfg) {
      if (cfg && typeof cfg === 'object') {
        // 0x10 = RENDER_ATTACHMENT, 0x04 = COPY_SRC (cho phép drawImage đọc texture WebGPU)
        cfg = Object.assign({}, cfg, { usage: (cfg.usage || 0x10) | 0x04 });
      }
      return origConfigure.call(this, cfg);
    };
  }

  const origRAF = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = function (cb) {
    return origRAF((ts) => {
      const res = cb(ts);
      if (pendingRafCaptureResolver) {
        const resolve = pendingRafCaptureResolver;
        pendingRafCaptureResolver = null;
        try {
          const c = document.getElementById('photocraft_canvas') || document.querySelector('canvas');
          if (c && c.width > 0 && c.height > 0) {
            const maxDim = 1600;
            const scale = Math.min(1, maxDim / Math.max(c.width, c.height));
            const off = document.createElement('canvas');
            off.width = Math.max(1, Math.round(c.width * scale));
            off.height = Math.max(1, Math.round(c.height * scale));
            const ctx = off.getContext('2d');
            ctx.drawImage(c, 0, 0, off.width, off.height);
            resolve(off.toDataURL('image/png'));
          } else {
            resolve('');
          }
        } catch (e) {
          resolve('');
        }
      }
      return res;
    });
  };

  async function captureCanvasPngDataUrl() {
    const c = document.getElementById('photocraft_canvas') || document.querySelector('canvas');
    if (!c || !c.width || !c.height) return '';
    // Thử chụp qua requestAnimationFrame (đảm bảo đọc được cả WebGPU lẫn WebGL2 ngay sau lệnh render)
    return await new Promise((resolve) => {
      let settled = false;
      const done = (val) => {
        if (settled) return;
        settled = true;
        pendingRafCaptureResolver = null;
        resolve(val || '');
      };
      pendingRafCaptureResolver = done;
      // Đánh thức eframe vẽ 1 frame bằng sự kiện di chuột nhẹ
      try {
        const r = c.getBoundingClientRect();
        c.dispatchEvent(
          new MouseEvent('mousemove', {
            bubbles: true,
            clientX: Math.round(r.left + 8),
            clientY: Math.round(r.top + 8),
          })
        );
      } catch (e) {}
      setTimeout(() => {
        if (settled) return;
        try {
          const maxDim = 1600;
          const scale = Math.min(1, maxDim / Math.max(c.width, c.height));
          const off = document.createElement('canvas');
          off.width = Math.max(1, Math.round(c.width * scale));
          off.height = Math.max(1, Math.round(c.height * scale));
          off.getContext('2d').drawImage(c, 0, 0, off.width, off.height);
          done(off.toDataURL('image/png'));
        } catch (e) {
          done('');
        }
      }, 95);
    });
  }

  function blobToBase64(blob) {
    return new Promise((resolve) => {
      if (!blob) return resolve('');
      const reader = new FileReader();
      reader.onloadend = () => resolve(typeof reader.result === 'string' ? reader.result : '');
      reader.onerror = () => resolve('');
      reader.readAsDataURL(blob);
    });
  }

  async function base64ToFile(dataUrl, filename) {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([blob], filename, { type: 'image/png' });
  }

  // =========================================================================
  // 1. GỬI LOG CHẨN ĐOÁN VỀ SERVER & KHUNG MYINGGO
  // =========================================================================
  function sendLog(level, message, detail) {
    const payload = {
      source: fid,
      level: level || 'INFO',
      message: `[${modeLabel}] ${message}`,
      detail: detail ? String(detail) : '',
    };
    try {
      fetch('/api/logs/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).catch(() => {});
    } catch (e) {}
    try {
      if (bc) bc.postMessage({ type: 'log', fid, entry: payload });
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'mg_artcraft_log', fid, entry: payload }, '*');
      }
    } catch (e) {}
  }

  function showMiniToast(msg, isErr) {
    let el = document.getElementById('mg-bridge-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'mg-bridge-toast';
      el.style.cssText =
        'position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:999999;' +
        'padding:8px 18px;border-radius:999px;font:600 13px/1.4 system-ui,sans-serif;' +
        'color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.45);pointer-events:none;transition:opacity .25s;opacity:0;';
      document.body.appendChild(el);
    }
    el.style.background = isErr ? 'rgba(220,38,38,.94)' : 'rgba(37,99,235,.94)';
    el.textContent = msg;
    el.style.opacity = '1';
    clearTimeout(el._t);
    el._t = setTimeout(() => {
      el.style.opacity = '0';
    }, 2800);
  }

  const origError = console.error.bind(console);
  const origWarn = console.warn.bind(console);
  const origInfo = console.info.bind(console);

  function fmtArgs(args) {
    return args
      .map((a) => {
        if (a instanceof Error) return a.stack || a.message;
        if (typeof a === 'object' && a !== null) {
          try {
            return JSON.stringify(a);
          } catch {
            return String(a);
          }
        }
        return String(a);
      })
      .join(' ');
  }

  console.error = (...args) => {
    origError(...args);
    const txt = fmtArgs(args);
    if (txt) sendLog('ERROR', txt.slice(0, 350), txt.length > 350 ? txt : '');
  };

  console.warn = (...args) => {
    origWarn(...args);
    const txt = fmtArgs(args);
    if (txt && !txt.includes('deprecated parameters for')) {
      sendLog('WARN', txt.slice(0, 350), txt.length > 350 ? txt : '');
    }
  };

  console.info = (...args) => {
    origInfo(...args);
    const txt = fmtArgs(args);
    if (txt && /backend|wgpu|webgl|adapter|served font|ready|opfs/i.test(txt)) {
      sendLog('RUNTIME', txt.slice(0, 350));
    }
  };

  window.addEventListener('error', (ev) => {
    const msg = ev.message || String(ev.error || 'Lỗi Runtime');
    const stack = ev.error && ev.error.stack ? ev.error.stack : `${ev.filename || ''}:${ev.lineno || ''}`;
    sendLog('ERROR', `Lỗi JS/WASM: ${msg}`, stack);
  });

  window.addEventListener('unhandledrejection', (ev) => {
    const reason =
      ev.reason && (ev.reason.stack || ev.reason.message)
        ? ev.reason.stack || ev.reason.message
        : String(ev.reason);
    sendLog('ERROR', `Lỗi Promise (Unhandled Rejection): ${String(ev.reason).slice(0, 200)}`, reason);
  });

  sendLog('RUNTIME', `Đang khởi tạo bộ nhân ${fid.toUpperCase()}...`, `URL: ${location.href}`);

  // =========================================================================
  // 2. INDEXEDDB LƯU TRỮ SNAPSHOT ĐỒNG BỘ GIỮA KHUNG TRONG & CỬA SỔ RIÊNG
  // =========================================================================
  const DB_NAME = 'myinggo_artcraft_sync_v1';
  const STORE_NAME = 'snapshots';
  let latestDocBlob = null;

  function openSyncDB() {
    return new Promise((resolve, reject) => {
      if (typeof indexedDB === 'undefined') return reject(new Error('no indexedDB'));
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function saveSyncSnapshot(key, data) {
    try {
      if (data && data.blob) latestDocBlob = data.blob;
      const db = await openSyncDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).put(data, key);
        tx.oncomplete = () => {
          db.close();
          resolve(true);
        };
        tx.onerror = () => {
          db.close();
          reject(tx.error);
        };
      });
    } catch (e) {
      return false;
    }
  }

  async function loadSyncSnapshot(key) {
    try {
      const db = await openSyncDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const req = tx.objectStore(STORE_NAME).get(key);
        req.onsuccess = () => {
          db.close();
          if (req.result && req.result.blob) latestDocBlob = req.result.blob;
          resolve(req.result || null);
        };
        req.onerror = () => {
          db.close();
          reject(req.error);
        };
      });
    } catch (e) {
      return null;
    }
  }

  const urlStringMap = new Map();
  const origCreateObjectURL = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (obj) {
    const url = origCreateObjectURL(obj);
    if (obj instanceof Blob) {
      urlStringMap.set(url, obj);
      setTimeout(() => urlStringMap.delete(url), 60000);
    }
    return url;
  };

  let silentSaveResolver = null;
  const origAnchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function (...args) {
    try {
      const dlName = this.getAttribute('download') || this.download;
      const href = this.getAttribute('href') || this.href;
      if (dlName && href && urlStringMap.has(href)) {
        const blob = urlStringMap.get(href);
        latestDocBlob = blob;
        saveSyncSnapshot(fid + '_doc', {
          name: dlName,
          blob: blob,
          type: blob.type || 'application/octet-stream',
          ts: Date.now(),
          from: isStandalone ? 'standalone' : 'embedded',
        }).then(() => {
          if (bc) bc.postMessage({ type: 'snapshot_updated', fid, name: dlName, ts: Date.now() });
        });

        if (silentSaveResolver) {
          const r = silentSaveResolver;
          silentSaveResolver = null;
          r({ ok: true, name: dlName, size: blob.size, blob: blob });
          return; // Không bật hộp thoại tải file xuống trình duyệt khi đang chụp ngầm
        } else {
          sendLog('INFO', `Đã xuất / lưu file "${dlName}" (${Math.round(blob.size / 1024)} KB).`);
        }
      }
    } catch (e) {}
    return origAnchorClick.apply(this, args);
  };

  window.addEventListener(
    'change',
    (e) => {
      const t = e.target;
      if (t && t.tagName === 'INPUT' && t.type === 'file' && t.files && t.files.length > 0) {
        const f = t.files[0];
        sendLog('INFO', `Đã mở file từ máy tính: "${f.name}" (${Math.round(f.size / 1024)} KB)`);
        if (fid === 'photocraft' && f.size < 150 * 1024 * 1024) {
          const cloned = f.slice(0, f.size, f.type);
          latestDocBlob = cloned;
          saveSyncSnapshot(fid + '_doc', {
            name: f.name,
            blob: cloned,
            type: f.type,
            ts: Date.now(),
            from: isStandalone ? 'standalone' : 'embedded',
          });
        }
      }
    },
    true
  );

  // =========================================================================
  // 3. CẦU NỐI DÁN ẢNH TỪ CLIPBOARD (CTRL+V) & NẠP LAYER VÀO CANVAS
  // =========================================================================
  function getCanvas() {
    return (
      document.getElementById('photocraft_canvas') ||
      document.getElementById('filmcraft_canvas') ||
      document.getElementById('effectcraft_canvas') ||
      document.querySelector('canvas')
    );
  }

  function sendEnterKeyToCanvas() {
    const canvas = getCanvas();
    if (!canvas) return;
    const enterDown = new KeyboardEvent('keydown', {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true,
    });
    const enterUp = new KeyboardEvent('keyup', {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true,
    });
    canvas.dispatchEvent(enterDown);
    setTimeout(() => canvas.dispatchEvent(enterUp), 20);
  }

  function dropFileIntoApp(file, placeOnActiveCanvas = true, autoCommitTransform = false) {
    const canvas = getCanvas();
    if (!canvas) {
      sendLog('WARN', 'Chưa tìm thấy khung Canvas để nạp ảnh.');
      return false;
    }
    try {
      if (fid === 'filmcraft' && window.filmcraft && typeof window.filmcraft.importFiles === 'function') {
        window.filmcraft.importFiles([file]);
        sendLog('INFO', `📋 Đã nạp "${file.name}" (${Math.round(file.size / 1024)} KB) vào FilmCraft.`);
        showMiniToast(`📋 Đã dán "${file.name}" vào FilmCraft`);
        return true;
      }

      // Chốt Free Transform cũ (nếu đang mở) trước khi thả Layer mới
      if (placeOnActiveCanvas) sendEnterKeyToCanvas();

      const dt = new DataTransfer();
      dt.items.add(file);
      const rect = canvas.getBoundingClientRect();
      const cx = placeOnActiveCanvas ? Math.round(rect.left + rect.width * 0.42) : Math.round(rect.left + 12);
      const cy = placeOnActiveCanvas ? Math.round(rect.top + rect.height * 0.52) : Math.round(rect.top + 12);

      const overEv = new DragEvent('dragover', {
        bubbles: true,
        cancelable: true,
        clientX: cx,
        clientY: cy,
        dataTransfer: dt,
      });
      const dropEv = new DragEvent('drop', {
        bubbles: true,
        cancelable: true,
        clientX: cx,
        clientY: cy,
        dataTransfer: dt,
      });
      if (!dropEv.dataTransfer) {
        Object.defineProperty(dropEv, 'dataTransfer', { value: dt });
      }
      canvas.dispatchEvent(overEv);
      canvas.dispatchEvent(dropEv);

      if (autoCommitTransform) {
        // Tự động nhấn Enter sau khi PhotoCraft đặt Layer vào vị trí (0,0) để chốt Layer ngay lập tức
        setTimeout(() => sendEnterKeyToCanvas(), 180);
        setTimeout(() => sendEnterKeyToCanvas(), 380);
      }

      if (fid === 'photocraft' && !autoCommitTransform && file.size < 150 * 1024 * 1024) {
        const cloned = file.slice(0, file.size, file.type);
        latestDocBlob = cloned;
        saveSyncSnapshot(fid + '_doc', {
          name: file.name,
          blob: cloned,
          type: file.type,
          ts: Date.now(),
          from: isStandalone ? 'standalone' : 'embedded',
        });
      }
      return true;
    } catch (err) {
      sendLog('ERROR', `Lỗi khi nạp ảnh vào vùng vẽ: ${err.message || err}`);
      return false;
    }
  }

  let internalCopyActive = false;
  let suppressNextVKeyUp = false;
  let pendingCtrlVTimer = null;

  window.addEventListener('blur', () => {
    internalCopyActive = false;
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) internalCopyActive = false;
  });

  function isTypingInHtmlInput() {
    const el = document.activeElement;
    if (!el) return false;
    if (el.id && el.id.startsWith('mg-ai-')) return true;
    const tag = el.tagName;
    if (tag === 'TEXTAREA' || el.isContentEditable) return true;
    if (tag === 'INPUT') {
      const t = (el.type || '').toLowerCase();
      if (el.offsetWidth > 20 && el.offsetHeight > 10 && t !== 'file' && t !== 'button') return true;
    }
    return false;
  }

  function dispatchSyntheticCtrlV() {
    const canvas = getCanvas() || window;
    const kd = new KeyboardEvent('keydown', {
      key: 'v',
      code: 'KeyV',
      keyCode: 86,
      which: 86,
      ctrlKey: true,
      bubbles: true,
      cancelable: true,
    });
    const ku = new KeyboardEvent('keyup', {
      key: 'v',
      code: 'KeyV',
      keyCode: 86,
      which: 86,
      ctrlKey: true,
      bubbles: true,
      cancelable: true,
    });
    kd._mgBypass = true;
    ku._mgBypass = true;
    canvas.dispatchEvent(kd);
    setTimeout(() => canvas.dispatchEvent(ku), 16);
  }

  window.addEventListener(
    'keydown',
    (e) => {
      if (e._mgBypass) return;
      // Phím tắt Alt+A để bật/tắt nhanh chế độ Khoanh vùng AI Generative Fill
      if (fid === 'photocraft' && e.altKey && (e.key === 'a' || e.key === 'A' || e.code === 'KeyA')) {
        e.preventDefault();
        e.stopImmediatePropagation();
        toggleAiSelectMode();
        return;
      }
      if (fid === 'photocraft' && e.key === 'Escape' && aiSelectActive) {
        clearAiSelection(true);
        return;
      }
      const ctrl = e.ctrlKey || e.metaKey;
      if (!ctrl || e.altKey) return;
      const k = (e.key || '').toLowerCase();
      if (k === 'c' || k === 'x' || e.code === 'KeyC' || e.code === 'KeyX') {
        internalCopyActive = true;
        return;
      }
      if (fid === 'photocraft' && !e.shiftKey && (k === 'v' || e.code === 'KeyV') && !isTypingInHtmlInput()) {
        e.stopImmediatePropagation();
        clearTimeout(pendingCtrlVTimer);
        pendingCtrlVTimer = setTimeout(() => {
          pendingCtrlVTimer = null;
          dispatchSyntheticCtrlV();
        }, 70);
      }
    },
    true
  );

  window.addEventListener(
    'keyup',
    (e) => {
      if (e._mgBypass) return;
      const k = (e.key || '').toLowerCase();
      if (fid === 'photocraft' && (k === 'v' || e.code === 'KeyV') && suppressNextVKeyUp) {
        e.stopImmediatePropagation();
        suppressNextVKeyUp = false;
      }
    },
    true
  );

  window.addEventListener(
    'paste',
    (e) => {
      if (isTypingInHtmlInput()) return;
      if (pendingCtrlVTimer) {
        clearTimeout(pendingCtrlVTimer);
        pendingCtrlVTimer = null;
      }
      const cd = e.clipboardData;
      let imageFile = null;
      if (cd && cd.items) {
        for (let i = 0; i < cd.items.length; i++) {
          const item = cd.items[i];
          if (item.kind === 'file' && item.type && item.type.startsWith('image/')) {
            const blob = item.getAsFile();
            if (blob) {
              const ext = (item.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
              imageFile = new File([blob], `Clipboard_${Date.now()}.${ext}`, { type: item.type });
              break;
            }
          }
        }
      }
      if (!imageFile && cd && cd.files && cd.files.length > 0) {
        for (let i = 0; i < cd.files.length; i++) {
          const f = cd.files[i];
          if (f.type && f.type.startsWith('image/')) {
            imageFile = f;
            break;
          }
        }
      }

      if (imageFile && !internalCopyActive) {
        e.preventDefault();
        e.stopImmediatePropagation();
        suppressNextVKeyUp = true;
        setTimeout(() => {
          suppressNextVKeyUp = false;
        }, 400);

        const ok = dropFileIntoApp(imageFile, true);
        if (ok) {
          sendLog(
            'INFO',
            `📋 Đã dán ảnh từ Clipboard (${Math.round(imageFile.size / 1024)} KB, ${imageFile.type}) vào ${fid.toUpperCase()}.`
          );
          showMiniToast(`📋 Đã dán ảnh từ Clipboard (${Math.round(imageFile.size / 1024)} KB)`);
        }
      } else if (fid === 'photocraft') {
        dispatchSyntheticCtrlV();
      }
    },
    true
  );

  async function pasteFromClipboardButton() {
    try {
      if (!navigator.clipboard || !navigator.clipboard.read) {
        showMiniToast('Hãy bấm tổ hợp phím Ctrl + V để dán ảnh!', false);
        return false;
      }
      const items = await navigator.clipboard.read();
      for (const item of items) {
        const imgType = item.types.find((t) => t.startsWith('image/'));
        if (imgType) {
          const blob = await item.getType(imgType);
          const ext = (imgType.split('/')[1] || 'png').replace('jpeg', 'jpg');
          const file = new File([blob], `Clipboard_${Date.now()}.${ext}`, { type: imgType });
          internalCopyActive = false;
          const ok = dropFileIntoApp(file, true);
          if (ok) {
            sendLog('INFO', `📋 Đã dán ảnh bằng nút Dán (${Math.round(file.size / 1024)} KB, ${imgType}).`);
            showMiniToast(`📋 Đã dán ảnh từ Clipboard (${Math.round(file.size / 1024)} KB)`);
            return true;
          }
        }
      }
      dispatchSyntheticCtrlV();
      showMiniToast('Không thấy ảnh mới trong Clipboard hệ thống — đã gọi lệnh Paste nội bộ.', false);
      return false;
    } catch (err) {
      sendLog('WARN', `Không đọc trực tiếp được Clipboard qua nút bấm: ${err.message || err}. Hãy nhấn Ctrl+V.`);
      showMiniToast('Hãy click vào vùng vẽ rồi nhấn Ctrl + V để dán ảnh!', false);
      return false;
    }
  }

  // =========================================================================
  // 4. ĐỒNG BỘ PHIÊN LÀM VIỆC (HANDOVER) & CHỤP TÀI LIỆU GỐC NGẦM
  // =========================================================================
  async function triggerSilentSaveForHandover() {
    try {
      if (fid === 'effectcraft' && window.effectcraft && typeof window.effectcraft.flush === 'function') {
        await window.effectcraft.flush();
        sendLog('SYNC', 'Đã lưu đồng bộ dữ liệu EffectCraft vào bộ nhớ chung.');
        return true;
      }
      if (fid === 'photocraft') {
        const canvas = getCanvas();
        if (!canvas) return null;
        sendEnterKeyToCanvas();
        await new Promise((r) => setTimeout(r, 35));

        return await new Promise((resolve) => {
          let settled = false;
          const done = (val) => {
            if (settled) return;
            settled = true;
            silentSaveResolver = null;
            resolve(val);
          };
          silentSaveResolver = done;
          setTimeout(() => done(null), 420);

          const sDown = new KeyboardEvent('keydown', {
            key: 's',
            code: 'KeyS',
            keyCode: 83,
            which: 83,
            ctrlKey: true,
            bubbles: true,
            cancelable: true,
          });
          const sUp = new KeyboardEvent('keyup', {
            key: 's',
            code: 'KeyS',
            keyCode: 83,
            which: 83,
            ctrlKey: true,
            bubbles: true,
            cancelable: true,
          });
          canvas.dispatchEvent(sDown);
          setTimeout(() => canvas.dispatchEvent(sUp), 20);
        });
      }
    } catch (e) {}
    return null;
  }

  async function restoreSyncedDocumentIfNeeded() {
    if (fid !== 'photocraft') return;
    const snap = await loadSyncSnapshot(fid + '_doc');
    if (!snap || !snap.blob) return;
    if (Date.now() - (snap.ts || 0) > 12 * 3600 * 1000) return;
    try {
      const file = new File([snap.blob], snap.name || 'Project.psd', {
        type: snap.type || 'image/vnd.adobe.photoshop',
      });
      setTimeout(() => {
        dropFileIntoApp(file, false);
        sendLog('SYNC', `🔄 Đã đồng bộ & khôi phục phiên làm việc "${file.name}" (${Math.round(file.size / 1024)} KB).`);
        showMiniToast(`🔄 Đã đồng bộ phiên làm việc: ${file.name}`);
      }, 280);
    } catch (e) {}
  }

  // =========================================================================
  // 5. THANH CÔNG CỤ NỔI AI KIỂU PHOTOSHOP (CONTEXTUAL TASK BAR) CHO PHOTOCRAFT
  //    [✨ Generative fill] [🩹 Remove] [⬚/✏️/🖌️] [⚙️ Cài đặt 3 Nguồn AI] [Deselect]
  // =========================================================================
  let aiSelectActive = false;
  let aiToolMode = 'rect'; // 'rect' | 'lasso' | 'brush'
  let aiBrushSize = 34;
  let aiProvider = 'auto';
  let aiConfigCache = null;
  let isDrawingSel = false;
  let selStart = { x: 0, y: 0 };
  let selRect = null; // { x, y, w, h }
  let lassoPoints = [];
  let hasMaskStroke = false;
  let preCaptureScreenB64 = '';
  let preCaptureDocB64 = '';
  let lastAiResult = null;
  let antsOffset = 0;
  let antsTimer = null;

  let overlayWrap = null;
  let overlayCanvas = null;
  let maskCanvas = null;
  let taskBarEl = null;
  let promptRowEl = null;
  let promptInputEl = null;
  let statusRowEl = null;
  let previewImgEl = null;
  let topModePill = null;
  let settingsModal = null;
  let floatingTriggerBtn = null;

  async function loadAiConfigFromServer() {
    try {
      const r = await (
        await fetch('/api/photocraft/ai_config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({}),
        })
      ).json();
      if (r && r.config) {
        aiConfigCache = r.config;
        aiProvider = r.config.provider || 'auto';
        updateProviderBadge();
      }
    } catch (e) {}
  }

  function updateProviderBadge() {
    const sel = document.getElementById('mg-ai-provider-select');
    if (sel && sel.value !== aiProvider) sel.value = aiProvider;
  }

  function ensurePhotoshopAiOverlay() {
    if (fid !== 'photocraft' || overlayWrap) return;

    const style = document.createElement('style');
    style.textContent = `
      #mg-ai-overlay-wrap {
        position: fixed; inset: 0; z-index: 99980; pointer-events: none; user-select: none;
        font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
      }
      #mg-ai-overlay-wrap.active { pointer-events: auto; cursor: crosshair; }
      #mg-ai-overlay-canvas { position: absolute; inset: 0; width: 100%; height: 100%; }
      #mg-ai-preview-patch {
        position: absolute; display: none; pointer-events: none; z-index: 99982;
        border-radius: 2px; box-shadow: 0 0 0 1px rgba(59,130,246,.85);
      }
      #mg-ai-shimmer {
        position: absolute; display: none; pointer-events: none; z-index: 99983;
        background: linear-gradient(110deg, rgba(59,130,246,0.18) 8%, rgba(168,85,247,0.38) 18%, rgba(59,130,246,0.18) 33%);
        background-size: 200% 100%;
        animation: mg-ai-shimmer-anim 1.3s linear infinite;
        border: 1.5px solid #60a5fa; border-radius: 3px;
        box-shadow: 0 0 22px rgba(59,130,246,.45);
      }
      @keyframes mg-ai-shimmer-anim { to { background-position-x: -200%; } }

      /* Nút bật nhanh trên đỉnh vùng vẽ PhotoCraft */
      #mg-ai-float-trigger {
        position: fixed; top: 6px; right: 275px; z-index: 99989;
        display: inline-flex; align-items: center; gap: 6px;
        background: linear-gradient(135deg, #2563eb, #7c3aed);
        color: #fff; border: 1px solid rgba(255,255,255,.25); border-radius: 999px;
        padding: 5px 13px; font: 600 12.5px system-ui, sans-serif; cursor: pointer;
        box-shadow: 0 4px 16px rgba(37,99,235,.45); transition: transform .15s, filter .15s;
      }
      #mg-ai-float-trigger:hover { filter: brightness(1.12); transform: translateY(-1px); }
      #mg-ai-float-trigger.active {
        background: #dc2626; box-shadow: 0 0 18px rgba(220,38,38,.7);
      }

      /* Thanh chọn kiểu công cụ (Khung chữ nhật / Lasso / Cọ tô) khi đang ở chế độ Khoanh vùng AI */
      #mg-ai-top-pill {
        position: fixed; top: 44px; left: 50%; transform: translateX(-50%); z-index: 99990;
        display: none; align-items: center; gap: 8px;
        background: rgba(30, 32, 40, .95); backdrop-filter: blur(12px);
        border: 1px solid rgba(255,255,255,.2); border-radius: 999px;
        padding: 6px 14px; color: #f1f5f9; font-size: 12.5px;
        box-shadow: 0 10px 30px rgba(0,0,0,.55);
      }
      #mg-ai-top-pill.show { display: inline-flex; }
      .mg-ai-tool-btn {
        border: 1px solid rgba(255,255,255,.15); background: rgba(255,255,255,.08);
        color: #e2e8f0; border-radius: 999px; padding: 4px 11px; font: 600 12px inherit; cursor: pointer;
      }
      .mg-ai-tool-btn.active { background: #2563eb; color: #fff; border-color: #60a5fa; }

      /* Thanh Contextual Task Bar chuẩn phong cách Adobe Photoshop */
      #mg-ai-taskbar {
        position: fixed; z-index: 99991; display: none; flex-direction: column; gap: 7px;
        background: #2c2c2e; border: 1px solid #4a4a4e; border-radius: 8px;
        padding: 6px 10px; color: #f1f1f3;
        box-shadow: 0 12px 34px rgba(0,0,0,.65), 0 0 0 1px rgba(255,255,255,.06);
        min-width: 470px; max-width: 92vw; pointer-events: auto; cursor: default;
      }
      #mg-ai-taskbar.show { display: flex; }
      .mg-ps-row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
      .mg-ps-grip {
        cursor: move; opacity: .55; padding: 2px 4px; font-size: 14px; letter-spacing: -1px;
        user-select: none;
      }
      .mg-ps-btn {
        display: inline-flex; align-items: center; gap: 6px;
        background: #3a3a3d; color: #f3f3f6; border: 1px solid #5a5a5f;
        border-radius: 5px; padding: 5px 12px; font: 600 12.5px inherit;
        cursor: pointer; transition: background .12s, border-color .12s;
      }
      .mg-ps-btn:hover { background: #48484c; border-color: #78787e; }
      .mg-ps-btn.primary { background: #2563eb; border-color: #3b82f6; color: #fff; }
      .mg-ps-btn.primary:hover { background: #1d4ed8; }
      .mg-ps-icon-btn {
        display: inline-flex; align-items: center; justify-content: center;
        background: transparent; color: #d4d4d8; border: 1px solid transparent;
        border-radius: 5px; width: 29px; height: 29px; font-size: 14px; cursor: pointer;
      }
      .mg-ps-icon-btn:hover { background: #3f3f44; border-color: #5a5a5f; color: #fff; }
      .mg-ps-sep { width: 1px; height: 20px; background: #48484d; margin: 0 2px; }
      .mg-ps-select {
        background: #3a3a3d; color: #e4e4e7; border: 1px solid #5a5a5f;
        border-radius: 5px; padding: 4px 8px; font: 600 12px inherit; outline: none; cursor: pointer;
      }
      .mg-ps-prompt-input {
        flex: 1; min-width: 240px; background: #1c1c1e; color: #fff;
        border: 1px solid #5a5a5f; border-radius: 5px; padding: 6px 11px;
        font: 13px inherit; outline: none;
      }
      .mg-ps-prompt-input:focus { border-color: #3b82f6; box-shadow: 0 0 0 2px rgba(59,130,246,.25); }

      /* Hộp thoại cài đặt 3 tầng AI */
      #mg-ai-settings-modal {
        position: fixed; inset: 0; z-index: 99998; display: none;
        align-items: center; justify-content: center;
        background: rgba(0,0,0,.62); backdrop-filter: blur(4px);
      }
      #mg-ai-settings-modal.show { display: flex; }
      .mg-ai-card {
        width: 520px; max-width: 94vw; background: #22232a; color: #f1f5f9;
        border: 1px solid rgba(255,255,255,.18); border-radius: 16px;
        padding: 18px 20px; box-shadow: 0 18px 50px rgba(0,0,0,.7);
        font: 13.5px/1.5 "Segoe UI", system-ui, sans-serif;
      }
      .mg-ai-field { margin: 10px 0; display: flex; flex-direction: column; gap: 4px; }
      .mg-ai-field label { font-weight: 600; font-size: 12.5px; color: #cbd5e1; }
      .mg-ai-field input, .mg-ai-field select {
        background: #14151a; color: #fff; border: 1px solid #3f414d;
        border-radius: 8px; padding: 8px 11px; font: inherit; outline: none;
      }
      .mg-ai-field input:focus, .mg-ai-field select:focus { border-color: #3b82f6; }
    `;
    document.head.appendChild(style);

    // Nút nổi trên đỉnh PhotoCraft để kích hoạt bất cứ lúc nào (cả ở Khung trong lẫn Cửa sổ riêng 🗖)
    floatingTriggerBtn = document.createElement('button');
    floatingTriggerBtn.id = 'mg-ai-float-trigger';
    floatingTriggerBtn.title = 'Khoanh vùng trên ảnh để dùng Generative Fill hoặc Remove bằng AI (Phím tắt: Alt + A)';
    floatingTriggerBtn.innerHTML = '✨ AI Generative Fill / Remove <span style="opacity:.78;font-size:11px">(Alt+A)</span>';
    floatingTriggerBtn.onclick = () => toggleAiSelectMode();
    document.body.appendChild(floatingTriggerBtn);

    // Thanh chọn kiểu công cụ khoanh vùng
    topModePill = document.createElement('div');
    topModePill.id = 'mg-ai-top-pill';
    topModePill.innerHTML = `
      <span style="color:#60a5fa;font-weight:700">✨ Chế độ khoanh vùng AI:</span>
      <button class="mg-ai-tool-btn active" data-tool="rect" title="Kéo khung chữ nhật giống Marquee của Photoshop">⬚ Khung chữ nhật</button>
      <button class="mg-ai-tool-btn" data-tool="lasso" title="Vẽ đường khoanh vùng tự do quanh vật thể">✏️ Khoanh tự do (Lasso)</button>
      <button class="mg-ai-tool-btn" data-tool="brush" title="Tô cọ lên vật thể cần xóa hoặc vị trí cần thêm">🖌️ Cọ bôi vùng</button>
      <span id="mg-ai-brush-wrap" style="display:none;align-items:center;gap:5px;font-size:12px">
        Cỡ cọ: <input id="mg-ai-brush-size" type="range" min="8" max="110" value="34" style="width:75px">
      </span>
      <button class="mg-ai-tool-btn" id="mg-ai-open-cfg-top" title="Cài đặt 3 nguồn AI (Miễn phí / Gemini / OpenAI / Stability)">⚙️ Nguồn AI</button>
      <button class="mg-ai-tool-btn" id="mg-ai-exit-top" style="background:rgba(220,38,38,.25);border-color:#ef4444;color:#fca5a5">✕ Thoát (Esc)</button>
    `;
    document.body.appendChild(topModePill);

    topModePill.querySelectorAll('[data-tool]').forEach((btn) => {
      btn.onclick = () => {
        aiToolMode = btn.getAttribute('data-tool');
        topModePill.querySelectorAll('[data-tool]').forEach((b) => b.classList.toggle('active', b === btn));
        document.getElementById('mg-ai-brush-wrap').style.display = aiToolMode === 'brush' ? 'inline-flex' : 'none';
      };
    });
    document.getElementById('mg-ai-brush-size').oninput = (ev) => {
      aiBrushSize = parseInt(ev.target.value, 10) || 34;
    };
    document.getElementById('mg-ai-open-cfg-top').onclick = () => openAiSettingsModal();
    document.getElementById('mg-ai-exit-top').onclick = () => toggleAiSelectMode(false);

    // Lớp phủ Canvas vẽ đường kiến bò (marching ants) và mask
    overlayWrap = document.createElement('div');
    overlayWrap.id = 'mg-ai-overlay-wrap';
    overlayCanvas = document.createElement('canvas');
    overlayCanvas.id = 'mg-ai-overlay-canvas';
    maskCanvas = document.createElement('canvas');

    previewImgEl = document.createElement('img');
    previewImgEl.id = 'mg-ai-preview-patch';

    const shimmerEl = document.createElement('div');
    shimmerEl.id = 'mg-ai-shimmer';

    overlayWrap.appendChild(overlayCanvas);
    overlayWrap.appendChild(previewImgEl);
    overlayWrap.appendChild(shimmerEl);
    document.body.appendChild(overlayWrap);

    // Thanh Contextual Task Bar giống hệt bức ảnh Photoshop của người dùng
    taskBarEl = document.createElement('div');
    taskBarEl.id = 'mg-ai-taskbar';
    taskBarEl.innerHTML = `
      <div class="mg-ps-row" id="mg-ps-main-row">
        <span class="mg-ps-grip" id="mg-ps-drag-grip" title="Kéo để di chuyển thanh công cụ">⋮⋮</span>
        <button class="mg-ps-btn" id="mg-ps-btn-genfill" title="Điền thêm chi tiết / thay thế vùng chọn bằng AI theo câu lệnh">
          <span>✨</span> <span>Generative fill</span>
        </button>
        <button class="mg-ps-btn" id="mg-ps-btn-remove" title="Xóa sạch vật thể trong vùng chọn và tự động tái tạo nền phía sau">
          <span>🩹</span> <span>Remove</span>
        </button>
        <div class="mg-ps-sep"></div>
        <select class="mg-ps-select" id="mg-ai-provider-select" title="Chọn bộ AI xử lý">
          <option value="auto">⚡ Tự động (Ưu tiên Key / Free)</option>
          <option value="free">🆓 AI Miễn phí (Không cần Key)</option>
          <option value="gemini">💎 Google Gemini AI</option>
          <option value="openai">🚀 OpenAI (DALL-E / GPT-Image)</option>
          <option value="stability">🎨 Stability AI (SD3 Inpaint)</option>
        </select>
        <button class="mg-ps-icon-btn" id="mg-ps-btn-expand" title="Mở rộng vùng chọn thêm 12px">+</button>
        <button class="mg-ps-icon-btn" id="mg-ps-btn-settings" title="Cài đặt API Key cho Gemini / OpenAI / Stability">⚙️</button>
        <div style="flex:1"></div>
        <button class="mg-ps-btn" id="mg-ps-btn-deselect" title="Bỏ vùng chọn (Esc)">Deselect</button>
      </div>

      <div class="mg-ps-row" id="mg-ps-prompt-row" style="display:none;padding-top:4px;border-top:1px solid #3f3f44">
        <input type="text" class="mg-ps-prompt-input" id="mg-ai-prompt-input"
          placeholder="Nhập mô tả tiếng Việt hoặc tiếng Anh (để trống = tự động lấp nền)...">
        <button class="mg-ps-btn primary" id="mg-ps-btn-generate">✨ Generate</button>
      </div>

      <div class="mg-ps-row" id="mg-ps-status-row" style="display:none;padding-top:4px;border-top:1px solid #3f3f44;font-size:12px;color:#93c5fd">
        <span id="mg-ps-status-text">✨ Đang xử lý...</span>
        <div style="flex:1"></div>
        <button class="mg-ps-btn" id="mg-ps-btn-regen" style="display:none;padding:3px 9px;font-size:11.5px">🔄 Tạo lại</button>
        <button class="mg-ps-btn" id="mg-ps-btn-dl" style="display:none;padding:3px 9px;font-size:11.5px">💾 Tải PNG</button>
      </div>
    `;
    document.body.appendChild(taskBarEl);

    promptRowEl = document.getElementById('mg-ps-prompt-row');
    promptInputEl = document.getElementById('mg-ai-prompt-input');
    statusRowEl = document.getElementById('mg-ps-status-row');

    // Hộp thoại cài đặt 3 nguồn AI
    settingsModal = document.createElement('div');
    settingsModal.id = 'mg-ai-settings-modal';
    settingsModal.innerHTML = `
      <div class="mg-ai-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <b style="font-size:16px">⚙️ Cài đặt 3 Tầng Nguồn AI — PhotoCraft Generative Fill</b>
          <button class="mg-ps-icon-btn" id="mg-ai-cfg-close">✕</button>
        </div>
        <p style="margin:0 0 10px;font-size:12.5px;color:#94a3b8">
          Bạn có thể dùng ngay <b>🆓 AI Miễn phí tích hợp sẵn</b> mà không cần nhập Key, hoặc nhập API Key của <b>Google Gemini / OpenAI / Stability</b> để có chất lượng cao nhất như Photoshop Firefly.
        </p>
        <div class="mg-ai-field">
          <label>Nguồn AI mặc định:</label>
          <select id="mg-cfg-provider">
            <option value="auto">⚡ Tự động thông minh (Dùng Gemini/OpenAI nếu có Key, ngược lại dùng AI Miễn phí)</option>
            <option value="free">🆓 Tầng 1: AI Miễn phí tích hợp sẵn (Không cần API Key — Local Remove + Flux Free)</option>
            <option value="gemini">💎 Tầng 2: Google Gemini AI (Nano Banana / Gemini Flash Image — Hiểu tiếng Việt chuẩn)</option>
            <option value="openai">🚀 Tầng 3A: OpenAI API (DALL-E 2 / GPT-Image-1 Inpaint)</option>
            <option value="stability">🎨 Tầng 3B: Stability AI API (Stable Diffusion 3 Inpaint & Erase)</option>
          </select>
        </div>
        <div class="mg-ai-field">
          <label>💎 Google Gemini API Key (Lấy miễn phí tại aistudio.google.com):</label>
          <input type="password" id="mg-cfg-gemini-key" placeholder="AIzaSy...">
        </div>
        <div class="mg-ai-field">
          <label>🚀 OpenAI API Key (Tùy chọn):</label>
          <input type="password" id="mg-cfg-openai-key" placeholder="sk-...">
        </div>
        <div class="mg-ai-field">
          <label>🎨 Stability AI API Key (Tùy chọn):</label>
          <input type="password" id="mg-cfg-stability-key" placeholder="sk-...">
        </div>
        <div class="mg-ai-field">
          <label>Độ mềm viền ghép nối (Feather px): <span id="mg-cfg-feather-val">10</span> px</label>
          <input type="range" id="mg-cfg-feather" min="3" max="35" value="10">
        </div>
        <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
          <button class="mg-ps-btn" id="mg-ai-cfg-cancel">Hủy</button>
          <button class="mg-ps-btn primary" id="mg-ai-cfg-save">💾 Lưu cài đặt AI</button>
        </div>
      </div>
    `;
    document.body.appendChild(settingsModal);

    // Gắn sự kiện cho các nút trên Contextual Task Bar
    document.getElementById('mg-ai-provider-select').onchange = (e) => {
      aiProvider = e.target.value;
    };
    document.getElementById('mg-ps-btn-genfill').onclick = () => {
      promptRowEl.style.display = 'flex';
      setTimeout(() => promptInputEl.focus(), 30);
    };
    document.getElementById('mg-ps-btn-remove').onclick = () => {
      executeAiAction('remove', '');
    };
    document.getElementById('mg-ps-btn-generate').onclick = () => {
      executeAiAction('fill', promptInputEl.value);
    };
    promptInputEl.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') {
        e.preventDefault();
        executeAiAction('fill', promptInputEl.value);
      } else if (e.key === 'Escape') {
        clearAiSelection(false);
      }
    });
    document.getElementById('mg-ps-btn-expand').onclick = () => {
      if (!selRect) return;
      selRect.x = Math.max(0, selRect.x - 12);
      selRect.y = Math.max(0, selRect.y - 12);
      selRect.w = Math.min(window.innerWidth - selRect.x, selRect.w + 24);
      selRect.h = Math.min(window.innerHeight - selRect.y, selRect.h + 24);
      const mctx = maskCanvas.getContext('2d');
      mctx.fillStyle = '#ffffff';
      mctx.fillRect(selRect.x, selRect.y, selRect.w, selRect.h);
      drawSelectionOverlay();
      positionTaskBar();
    };
    document.getElementById('mg-ps-btn-settings').onclick = () => openAiSettingsModal();
    document.getElementById('mg-ps-btn-deselect').onclick = () => clearAiSelection(true);
    document.getElementById('mg-ps-btn-regen').onclick = () => {
      const isRem = promptRowEl.style.display === 'none' && !promptInputEl.value.trim();
      executeAiAction(isRem ? 'remove' : 'fill', promptInputEl.value);
    };
    document.getElementById('mg-ps-btn-dl').onclick = () => {
      if (!lastAiResult || !lastAiResult.patch_png_b64) return;
      const a = document.createElement('a');
      a.href = lastAiResult.layer_png_b64 || lastAiResult.patch_png_b64;
      a.download = lastAiResult.layer_name || `PhotoCraft_AI_${Date.now()}.png`;
      a.click();
    };

    // Kéo di chuyển Contextual Task Bar bằng nút ⋮⋮
    const grip = document.getElementById('mg-ps-drag-grip');
    let barDrag = null;
    grip.onpointerdown = (e) => {
      e.preventDefault();
      const r = taskBarEl.getBoundingClientRect();
      barDrag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      grip.setPointerCapture(e.pointerId);
    };
    grip.onpointermove = (e) => {
      if (!barDrag) return;
      taskBarEl.style.left = Math.max(8, Math.min(window.innerWidth - 200, e.clientX - barDrag.dx)) + 'px';
      taskBarEl.style.top = Math.max(8, Math.min(window.innerHeight - 60, e.clientY - barDrag.dy)) + 'px';
    };
    grip.onpointerup = () => {
      barDrag = null;
    };

    // Sự kiện vẽ vùng chọn trên overlayCanvas
    overlayCanvas.addEventListener('pointerdown', onOverlayPointerDown);
    overlayCanvas.addEventListener('pointermove', onOverlayPointerMove);
    window.addEventListener('pointerup', onOverlayPointerUp);
    window.addEventListener('resize', resizeOverlayCanvases);

    // Sự kiện trong modal cài đặt AI
    document.getElementById('mg-cfg-feather').oninput = (e) => {
      document.getElementById('mg-cfg-feather-val').textContent = e.target.value;
    };
    document.getElementById('mg-ai-cfg-close').onclick = () => settingsModal.classList.remove('show');
    document.getElementById('mg-ai-cfg-cancel').onclick = () => settingsModal.classList.remove('show');
    document.getElementById('mg-ai-cfg-save').onclick = async () => {
      const patch = {
        provider: document.getElementById('mg-cfg-provider').value,
        gemini_key: document.getElementById('mg-cfg-gemini-key').value.trim(),
        openai_key: document.getElementById('mg-cfg-openai-key').value.trim(),
        stability_key: document.getElementById('mg-cfg-stability-key').value.trim(),
        feather_px: parseInt(document.getElementById('mg-cfg-feather').value, 10) || 10,
      };
      try {
        const r = await (
          await fetch('/api/photocraft/ai_config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ save: true, config: patch }),
          })
        ).json();
        if (r && r.config) {
          aiConfigCache = r.config;
          aiProvider = r.config.provider;
          updateProviderBadge();
          showMiniToast('✅ Đã lưu cấu hình Nguồn AI cho PhotoCraft!');
        }
      } catch (e) {
        showMiniToast('Lỗi lưu cấu hình AI', true);
      }
      settingsModal.classList.remove('show');
    };

    resizeOverlayCanvases();
    loadAiConfigFromServer();
  }

  async function openAiSettingsModal() {
    ensurePhotoshopAiOverlay();
    await loadAiConfigFromServer();
    const cfg = aiConfigCache || {};
    document.getElementById('mg-cfg-provider').value = cfg.provider || 'auto';
    document.getElementById('mg-cfg-gemini-key').value = cfg.gemini_key || '';
    document.getElementById('mg-cfg-openai-key').value = cfg.openai_key || '';
    document.getElementById('mg-cfg-stability-key').value = cfg.stability_key || '';
    document.getElementById('mg-cfg-feather').value = cfg.feather_px || 10;
    document.getElementById('mg-cfg-feather-val').textContent = cfg.feather_px || 10;
    settingsModal.classList.add('show');
  }

  function resizeOverlayCanvases() {
    if (!overlayCanvas || !maskCanvas) return;
    const w = window.innerWidth;
    const h = window.innerHeight;
    if (overlayCanvas.width !== w || overlayCanvas.height !== h) {
      overlayCanvas.width = w;
      overlayCanvas.height = h;
      maskCanvas.width = w;
      maskCanvas.height = h;
      drawSelectionOverlay();
    }
  }

  async function toggleAiSelectMode(forceState) {
    ensurePhotoshopAiOverlay();
    const nextState = typeof forceState === 'boolean' ? forceState : !aiSelectActive;
    if (nextState) {
      // Chụp trước màn hình vùng vẽ sạch & tài liệu gốc trước khi vẽ đường chọn
      showMiniToast('✨ Hãy kéo chuột khoanh vùng trên ảnh để dùng Generative Fill hoặc Remove!');
      preCaptureScreenB64 = await captureCanvasPngDataUrl();
      const savedDoc = await triggerSilentSaveForHandover();
      if (savedDoc && savedDoc.blob) {
        preCaptureDocB64 = await blobToBase64(savedDoc.blob);
      } else if (latestDocBlob) {
        preCaptureDocB64 = await blobToBase64(latestDocBlob);
      }
      aiSelectActive = true;
      overlayWrap.classList.add('active');
      topModePill.classList.add('show');
      if (floatingTriggerBtn) {
        floatingTriggerBtn.classList.add('active');
        floatingTriggerBtn.innerHTML = '✕ Thoát chọn vùng AI <span style="opacity:.8;font-size:11px">(Esc)</span>';
      }
      startMarchingAnts();
    } else {
      clearAiSelection(false);
      aiSelectActive = false;
      overlayWrap.classList.remove('active');
      topModePill.classList.remove('show');
      if (floatingTriggerBtn) {
        floatingTriggerBtn.classList.remove('active');
        floatingTriggerBtn.innerHTML = '✨ AI Generative Fill / Remove <span style="opacity:.78;font-size:11px">(Alt+A)</span>';
      }
      stopMarchingAnts();
    }
  }

  function clearAiSelection(exitMode = false) {
    selRect = null;
    lassoPoints = [];
    hasMaskStroke = false;
    lastAiResult = null;
    if (maskCanvas) {
      maskCanvas.getContext('2d').clearRect(0, 0, maskCanvas.width, maskCanvas.height);
    }
    if (overlayCanvas) {
      overlayCanvas.getContext('2d').clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);
    }
    if (previewImgEl) previewImgEl.style.display = 'none';
    const shimmer = document.getElementById('mg-ai-shimmer');
    if (shimmer) shimmer.style.display = 'none';
    if (taskBarEl) taskBarEl.classList.remove('show');
    if (promptRowEl) promptRowEl.style.display = 'none';
    if (statusRowEl) statusRowEl.style.display = 'none';
    if (exitMode && aiSelectActive) {
      toggleAiSelectMode(false);
    }
  }

  function startMarchingAnts() {
    if (antsTimer) return;
    antsTimer = setInterval(() => {
      if (!selRect && !hasMaskStroke) return;
      antsOffset = (antsOffset + 1) % 16;
      drawSelectionOverlay();
    }, 80);
  }

  function stopMarchingAnts() {
    if (antsTimer) {
      clearInterval(antsTimer);
      antsTimer = null;
    }
  }

  function onOverlayPointerDown(e) {
    if (!aiSelectActive || e.button !== 0) return;
    resizeOverlayCanvases();
    isDrawingSel = true;
    if (previewImgEl) previewImgEl.style.display = 'none';
    statusRowEl.style.display = 'none';

    const x = e.clientX;
    const y = e.clientY;
    selStart = { x, y };
    const mctx = maskCanvas.getContext('2d');

    if (aiToolMode === 'rect') {
      mctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
      selRect = { x, y, w: 1, h: 1 };
      hasMaskStroke = false;
    } else if (aiToolMode === 'lasso') {
      mctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
      lassoPoints = [{ x, y }];
      selRect = { x, y, w: 1, h: 1 };
      hasMaskStroke = false;
    } else if (aiToolMode === 'brush') {
      if (!hasMaskStroke) {
        mctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
        selRect = { x: x - aiBrushSize / 2, y: y - aiBrushSize / 2, w: aiBrushSize, h: aiBrushSize };
      }
      hasMaskStroke = true;
      mctx.fillStyle = '#ffffff';
      mctx.beginPath();
      mctx.arc(x, y, aiBrushSize / 2, 0, Math.PI * 2);
      mctx.fill();
      expandSelRectWithPoint(x, y, aiBrushSize / 2);
    }
    taskBarEl.classList.remove('show');
    drawSelectionOverlay();
  }

  function expandSelRectWithPoint(x, y, rad = 0) {
    if (!selRect) {
      selRect = { x: x - rad, y: y - rad, w: rad * 2, h: rad * 2 };
      return;
    }
    const minX = Math.min(selRect.x, x - rad);
    const minY = Math.min(selRect.y, y - rad);
    const maxX = Math.max(selRect.x + selRect.w, x + rad);
    const maxY = Math.max(selRect.y + selRect.h, y + rad);
    selRect = { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
  }

  function onOverlayPointerMove(e) {
    if (!isDrawingSel || !aiSelectActive) return;
    const x = e.clientX;
    const y = e.clientY;
    const mctx = maskCanvas.getContext('2d');

    if (aiToolMode === 'rect') {
      const rx = Math.min(selStart.x, x);
      const ry = Math.min(selStart.y, y);
      const rw = Math.abs(x - selStart.x);
      const rh = Math.abs(y - selStart.y);
      selRect = { x: rx, y: ry, w: rw, h: rh };
    } else if (aiToolMode === 'lasso') {
      lassoPoints.push({ x, y });
      expandSelRectWithPoint(x, y, 2);
    } else if (aiToolMode === 'brush') {
      mctx.strokeStyle = '#ffffff';
      mctx.lineWidth = aiBrushSize;
      mctx.lineCap = 'round';
      mctx.lineJoin = 'round';
      mctx.beginPath();
      mctx.moveTo(selStart.x, selStart.y);
      mctx.lineTo(x, y);
      mctx.stroke();
      selStart = { x, y };
      expandSelRectWithPoint(x, y, aiBrushSize / 2);
    }
    drawSelectionOverlay();
  }

  function onOverlayPointerUp() {
    if (!isDrawingSel) return;
    isDrawingSel = false;
    if (!selRect || selRect.w < 8 || selRect.h < 8) {
      return;
    }
    const mctx = maskCanvas.getContext('2d');
    if (aiToolMode === 'rect') {
      mctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
      mctx.fillStyle = '#ffffff';
      mctx.fillRect(selRect.x, selRect.y, selRect.w, selRect.h);
      hasMaskStroke = true;
    } else if (aiToolMode === 'lasso' && lassoPoints.length > 2) {
      mctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
      mctx.fillStyle = '#ffffff';
      mctx.beginPath();
      mctx.moveTo(lassoPoints[0].x, lassoPoints[0].y);
      for (let i = 1; i < lassoPoints.length; i++) mctx.lineTo(lassoPoints[i].x, lassoPoints[i].y);
      mctx.closePath();
      mctx.fill();
      hasMaskStroke = true;
    }
    drawSelectionOverlay();
    positionTaskBar();
  }

  function drawSelectionOverlay() {
    if (!overlayCanvas) return;
    const ctx = overlayCanvas.getContext('2d');
    ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);
    if (!selRect || (selRect.w < 4 && selRect.h < 4)) return;

    ctx.save();
    if (aiToolMode === 'brush' && hasMaskStroke) {
      // Hiển thị lớp phủ màu đỏ ruby bán trong suốt cho vùng cọ bôi + khung kiến bò bao quanh
      ctx.globalAlpha = 0.28;
      ctx.drawImage(maskCanvas, 0, 0);
      ctx.globalCompositeOperation = 'source-in';
      ctx.fillStyle = '#ec4899';
      ctx.fillRect(0, 0, overlayCanvas.width, overlayCanvas.height);
      ctx.restore();
      ctx.save();
    }

    // Vẽ đường kiến bò (Marching Ants) 2 lớp Đen - Trắng chuẩn Adobe Photoshop
    const drawPath = () => {
      ctx.beginPath();
      if (aiToolMode === 'lasso' && lassoPoints.length > 2) {
        ctx.moveTo(lassoPoints[0].x, lassoPoints[0].y);
        for (let i = 1; i < lassoPoints.length; i++) ctx.lineTo(lassoPoints[i].x, lassoPoints[i].y);
        ctx.closePath();
      } else {
        ctx.rect(selRect.x, selRect.y, selRect.w, selRect.h);
      }
    };

    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.88)';
    ctx.setLineDash([6, 6]);
    ctx.lineDashOffset = -antsOffset;
    drawPath();
    ctx.stroke();

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.96)';
    ctx.setLineDash([6, 6]);
    ctx.lineDashOffset = -(antsOffset + 6);
    drawPath();
    ctx.stroke();
    ctx.restore();
  }

  function positionTaskBar() {
    if (!selRect || !taskBarEl) return;
    taskBarEl.classList.add('show');
    const barW = taskBarEl.offsetWidth || 480;
    const barH = taskBarEl.offsetHeight || 48;
    let left = selRect.x + selRect.w / 2 - barW / 2;
    let top = selRect.y + selRect.h + 12;
    if (top + barH > window.innerHeight - 16) {
      top = Math.max(54, selRect.y - barH - 12);
    }
    left = Math.max(12, Math.min(window.innerWidth - barW - 12, left));
    taskBarEl.style.left = Math.round(left) + 'px';
    taskBarEl.style.top = Math.round(top) + 'px';
  }

  async function executeAiAction(action, promptText) {
    if (!selRect || selRect.w < 6 || selRect.h < 6) {
      showMiniToast('Hãy kéo chuột khoanh vùng trên bức ảnh trước!', true);
      return;
    }

    const shimmer = document.getElementById('mg-ai-shimmer');
    shimmer.style.left = selRect.x + 'px';
    shimmer.style.top = selRect.y + 'px';
    shimmer.style.width = selRect.w + 'px';
    shimmer.style.height = selRect.h + 'px';
    shimmer.style.display = 'block';

    statusRowEl.style.display = 'flex';
    const statusTxt = document.getElementById('mg-ps-status-text');
    const btnRegen = document.getElementById('mg-ps-btn-regen');
    const btnDl = document.getElementById('mg-ps-btn-dl');
    btnRegen.style.display = 'none';
    btnDl.style.display = 'none';

    const label = action === 'remove' ? '🩹 AI Remove (Xóa vật thể & bù nền)' : `✨ Generative Fill ("${promptText || 'Tự động lấp nền'}")`;
    statusTxt.textContent = `⏳ Đang chạy ${label}...`;

    try {
      // Nếu chưa có bản chụp màn hình hoặc tài liệu gốc thì chụp bổ sung
      if (!preCaptureScreenB64) {
        overlayCanvas.style.visibility = 'hidden';
        taskBarEl.style.visibility = 'hidden';
        shimmer.style.visibility = 'hidden';
        preCaptureScreenB64 = await captureCanvasPngDataUrl();
        overlayCanvas.style.visibility = 'visible';
        taskBarEl.style.visibility = 'visible';
        shimmer.style.visibility = 'visible';
      }
      if (!preCaptureDocB64 && latestDocBlob) {
        preCaptureDocB64 = await blobToBase64(latestDocBlob);
      }

      const maskB64 = maskCanvas.toDataURL('image/png');
      const payload = {
        action,
        prompt: promptText || '',
        provider: aiProvider,
        rect: selRect,
        canvas_w: window.innerWidth,
        canvas_h: window.innerHeight,
        screen_b64: preCaptureScreenB64,
        doc_b64: preCaptureDocB64,
        mask_b64: maskB64,
      };

      const resp = await fetch('/api/photocraft/ai_fill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const res = await resp.json();
      shimmer.style.display = 'none';

      if (res.error) {
        statusTxt.innerHTML = `<span style="color:#f87171">❌ ${res.error}</span>`;
        showMiniToast(res.error, true);
        return;
      }

      lastAiResult = res;
      // Hiển thị xem trước ngay tại vùng chọn
      if (res.patch_png_b64 && previewImgEl) {
        previewImgEl.src = res.patch_png_b64;
        previewImgEl.style.left = selRect.x + 'px';
        previewImgEl.style.top = selRect.y + 'px';
        previewImgEl.style.width = selRect.w + 'px';
        previewImgEl.style.height = selRect.h + 'px';
        previewImgEl.style.display = 'block';
      }

      // Tự động đẩy Layer kết quả vào PhotoCraft (khớp tọa độ 0,0 của tài liệu gốc)
      if (res.layer_png_b64) {
        const layerFile = await base64ToFile(res.layer_png_b64, res.layer_name || `AI_Layer_${Date.now()}.png`);
        dropFileIntoApp(layerFile, true, true);
        // Sau khi chèn Layer vào PhotoCraft, ẩn ảnh preview đè để người dùng thấy trực tiếp Layer thật trên Canvas PhotoCraft
        setTimeout(() => {
          if (previewImgEl) previewImgEl.style.display = 'none';
        }, 550);
      }

      statusTxt.innerHTML = `<span style="color:#4ade80">✅ Đã tạo Layer <b>${res.layer_name}</b> bằng ${res.engine} (${res.elapsed_s}s)!</span>`;
      btnRegen.style.display = 'inline-flex';
      btnDl.style.display = 'inline-flex';
      showMiniToast(`✅ Hoàn tất ${res.engine} (${res.elapsed_s}s) — Đã thêm Layer mới!`);
    } catch (err) {
      shimmer.style.display = 'none';
      statusTxt.innerHTML = `<span style="color:#f87171">❌ Lỗi kết nối: ${err.message || err}</span>`;
      showMiniToast('Lỗi khi gọi AI Generative Fill', true);
    }
  }

  // Theo dõi khi bộ nhân WASM nạp xong
  let appReady = false;
  const readyCheck = setInterval(() => {
    const loadingEl = document.getElementById('photocraft_loading') || document.getElementById('loading');
    const isGone = !loadingEl || loadingEl.style.display === 'none' || !document.body.contains(loadingEl);
    const ecReady = fid === 'effectcraft' && window.effectcraftLoad && window.effectcraftLoad.readyMs;
    const fcReady = fid === 'filmcraft' && window.filmcraftLoad && window.filmcraftLoad.readyMs;
    if (isGone || ecReady || fcReady) {
      clearInterval(readyCheck);
      if (!appReady) {
        appReady = true;
        sendLog('RUNTIME', `✅ ${fid.toUpperCase()} đã khởi tạo xong trên ${modeLabel} và sẵn sàng thao tác!`);
        if (fid === 'photocraft') {
          ensurePhotoshopAiOverlay();
        }
        restoreSyncedDocumentIfNeeded();
      }
    }
  }, 300);

  // Nhận lệnh từ khung cha T2MG hoặc từ cửa sổ còn lại qua postMessage / BroadcastChannel
  window.addEventListener('message', async (ev) => {
    const d = ev.data;
    if (!d || typeof d !== 'object') return;
    if (d.type === 'mg_paste_clipboard') {
      await pasteFromClipboardButton();
    } else if (d.type === 'mg_toggle_ai_fill') {
      await toggleAiSelectMode();
    } else if (d.type === 'mg_open_ai_settings') {
      await openAiSettingsModal();
    } else if (d.type === 'mg_prepare_handover') {
      await triggerSilentSaveForHandover();
      if (ev.source) {
        ev.source.postMessage({ type: 'mg_handover_ready', fid }, '*');
      }
    }
  });

  if (bc) {
    bc.onmessage = async (ev) => {
      const d = ev.data || {};
      if (d.fid !== fid) return;
      if (d.type === 'request_close_standalone' && isStandalone) {
        await triggerSilentSaveForHandover();
        fetch('/api/artcraft/window_state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fid, open: false }),
        }).catch(() => {});
        bc.postMessage({ type: 'standalone_closed', fid });
        window.close();
      } else if (d.type === 'focus_standalone' && isStandalone) {
        window.focus();
      }
    };
  }

  // =========================================================================
  // 6. THANH ĐIỀU KHIỂN NỔI & HEARTBEAT KHI MỞ Ở MÀN HÌNH RIÊNG (STANDALONE)
  // =========================================================================
  if (isStandalone) {
    const notifyOpen = (open) => {
      const body = JSON.stringify({ fid, open });
      if (!open && navigator.sendBeacon) {
        navigator.sendBeacon('/api/artcraft/window_state', body);
      } else {
        fetch('/api/artcraft/window_state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body,
        }).catch(() => {});
      }
    };

    notifyOpen(true);
    if (bc) bc.postMessage({ type: 'standalone_opened', fid });
    const hb = setInterval(() => notifyOpen(true), 2000);

    window.addEventListener('pagehide', () => {
      clearInterval(hb);
      notifyOpen(false);
      if (bc) bc.postMessage({ type: 'standalone_closed', fid });
    });

    window.addEventListener('DOMContentLoaded', () => {
      const bar = document.createElement('div');
      bar.id = 'mg-standalone-bar';
      bar.style.cssText =
        'position:fixed;bottom:32px;right:16px;z-index:99995;display:flex;align-items:center;gap:6px;' +
        'background:rgba(24,24,36,.88);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.18);' +
        'padding:5px 10px;border-radius:999px;box-shadow:0 6px 20px rgba(0,0,0,.45);font:600 12px system-ui,sans-serif;color:#f1f1f5;';
      bar.innerHTML = `
        <span style="display:inline-flex;align-items:center;gap:5px;padding:0 6px;color:#60a5fa">
          <span style="width:8px;height:8px;border-radius:50%;background:#2563eb;box-shadow:0 0 8px #3b82f6"></span>
          Đồng bộ T2MG
        </span>
        ${
          fid === 'photocraft'
            ? '<button id="mg-sa-ai" style="border:0;border-radius:999px;padding:5px 11px;background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;cursor:pointer;font:inherit">✨ AI Fill / Xóa (Alt+A)</button>' +
              '<button id="mg-sa-paste" style="border:0;border-radius:999px;padding:5px 11px;background:#2563eb;color:#fff;cursor:pointer;font:inherit">📋 Dán ảnh (Ctrl+V)</button>'
            : ''
        }
        <button id="mg-sa-dock" style="border:0;border-radius:999px;padding:5px 11px;background:rgba(255,255,255,.14);color:#fff;cursor:pointer;font:inherit" title="Lưu phiên hiện tại và đưa giao diện quay về bên trong khung T2MG">📥 Đưa về khung T2MG</button>
      `;
      document.body.appendChild(bar);

      const aiBtn = document.getElementById('mg-sa-ai');
      if (aiBtn) {
        aiBtn.onclick = () => toggleAiSelectMode();
      }
      const pasteBtn = document.getElementById('mg-sa-paste');
      if (pasteBtn) {
        pasteBtn.onclick = () => pasteFromClipboardButton();
      }
      const dockBtn = document.getElementById('mg-sa-dock');
      if (dockBtn) {
        dockBtn.onclick = async () => {
          dockBtn.disabled = true;
          dockBtn.textContent = 'Đang đồng bộ về T2MG...';
          await triggerSilentSaveForHandover();
          notifyOpen(false);
          if (bc) bc.postMessage({ type: 'standalone_closed', fid });
          window.close();
        };
      }
    });
  }
})();
