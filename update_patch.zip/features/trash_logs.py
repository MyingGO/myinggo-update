"""Tính năng: Quản lý File rác, Bộ nhớ đệm (Cache) & Bảng Log chẩn đoán lỗi AI cho MyingGo + ArtCraft.
Cho phép chuyển toàn bộ Cache trình duyệt, File tạm và File Log sang ổ đĩa khác (VD: D:\\MyingGo_Trash_Logs) để không tốn ổ C:."""
import subprocess
from pathlib import Path

from core import dialogs, logger
from core.base import Feature


class TrashAndLogs(Feature):
    title = "🧹 File rác & Log"
    order = 990
    dock = "bottom"

    def act_stats(self, data):
        return logger.disk_and_junk_stats()

    def act_pick_dir(self, data):
        cur = str(logger.get_trash_dir())
        picked = dialogs.pick_dir("Chọn thư mục chứa File rác, Cache & Log (khuyên dùng ổ D: hoặc E:)", cur)
        if not picked:
            return logger.disk_and_junk_stats()
        return logger.set_trash_dir(picked)

    def act_set_dir(self, data):
        p = str(data.get("path") or "").strip()
        if not p:
            return {"error": "Đường dẫn không được để trống"}
        return logger.set_trash_dir(p)

    def act_open_dir(self, data):
        dirs = logger.ensure_dirs()
        sub = str(data.get("sub") or "base")
        target = dirs.get(sub, dirs["base"])
        subprocess.Popen(["explorer", str(target)])
        return {"ok": 1, "path": str(target)}

    def act_clean(self, data):
        clean_logs = bool(data.get("clean_logs", False))
        return logger.clean_junk(clean_logs=clean_logs)

    def act_export_report(self, data):
        src = str(data.get("source") or "")
        res = logger.export_ai_report(src)
        if data.get("reveal", True) and res.get("path") and Path(res["path"]).is_file():
            subprocess.Popen(["explorer", "/select,", res["path"]])
        return res
