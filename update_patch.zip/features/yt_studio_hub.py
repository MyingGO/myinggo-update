"""Tính năng: Studio Manager (Tích hợp từ 3T Master).

Bao gồm 3 phân hệ cốt lõi hoạt động đồng bộ:
1. Tài khoản & Kênh (Account & Channel Profile):
   - Quản lý Mail Google, mã hóa mật khẩu & 2FA bằng Windows DPAPI.
   - Tự động sinh mã OTP 2FA 6 số (RFC 6238 HMAC-SHA1) theo thời gian thực.
   - Quét kênh mới siêu tốc qua HTTP InnerTube (account/accounts_list) không cần mở trình duyệt.
   - Ghim phiên kênh độc lập (Pinned Studio Session), mở Chrome Profile riêng cho từng Mail/Kênh.
2. Channel Monitor & Auto Ops (V1013):
   - Giám sát sức khỏe kênh: Kiếm tiền (Monetization), Bản quyền (Strikes/Claims), Kho video hẹn giờ (Schedule Low Stock), Draft & Audio.
   - 6 Làn tác vụ Studio Operations + Công tắc tự hành Auto Ops (V1013):
     + Xóa nháp bản quyền (delete_draft_copyright)
     + Xóa lịch bản quyền (delete_scheduled_copyright)
     + Xử lý Add Audio lỗi (process_add_audio -> chuyển sang Audio Repair)
     + Chọn ngôn ngữ video (set_video_language)
     + Bật quảng cáo video & Mid-roll Ads (enable_ads)
     + Đặt lịch đều lại (rebalance_schedule)
3. Audio Repair (Sửa & Re-Add Âm thanh):
   - Quét & phát hiện video có track âm thanh bị FAILED / REJECTED / REMOVED.
   - Tra cứu baseline từ Hitmakers (tools.hitmakers.vip) hoặc quét thư mục nguồn Local/LAN.
   - Tự động cắt ghép khớp thời lượng Studio bằng FFmpeg (Trim đuôi, Cut History, hoặc tạo âm 3s/7s xen kẽ).
   - Chốt bảo vệ kênh: Tự động xóa video nếu bị gỡ Audio quá 5 lần (delete_over5).
"""
from __future__ import annotations

import base64
import io
import concurrent.futures
import ctypes
import ctypes.wintypes
import hashlib
import hmac
import html
import json
import os
import random
import re
import uuid
import shutil
import sqlite3
import struct
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from core import dialogs, logger
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

HUB_DB = DATA_DIR / "yt_studio_hub.db"
HUB_CFG = DATA_DIR / "yt_studio_config.json"
PROFILES_DIR = DATA_DIR / "yt_profiles"
COOKIES_DIR = DATA_DIR / "yt_cookies"
AUDIO_TEMP_DIR = DATA_DIR / "audio_repair_temp"

_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_UC_RE = re.compile(r"\b(UC[A-Za-z0-9_-]{22})\b")
_YT_WEB_API_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"

DEFAULT_CONFIG = {
    "t3_root": r"F:\3TMaster",
    "t3_port": 8891,
    "bridge_mode": "standalone",  # standalone = chạy độc lập hoàn toàn trên DB T2MG
    "cm_standalone": True,
    "key_root": "",
    "auto_branding": False,
    "channel_discovery_enabled": False,
    "cookie_sweep_enabled": False,
    # Channel Monitor
    "cm_auto_enabled": False,
    "cm_interval_minutes": 60,
    "cm_hide_money": False,
    "cm_auto_ops": {
        "delete_draft_copyright": False,
        "delete_scheduled_copyright": False,
        "set_video_language": False,
        "enable_ads": False,
        "rebalance_schedule": False,
    },
    # Audio Repair
    "ar_kinds": ["public", "draft", "scheduled"],
    "ar_skip_over5_ok": False,
    "ar_auto_enabled": False,
    "ar_auto_mode": "all",
    "ar_content_type": "global",
    "ar_delete_over5": False,
    "ar_hitmakers_user": "",
    "ar_hitmakers_pass_dpapi": "",
    "ar_hitmakers_url": "https://tools.hitmakers.vip",
    "ar_source_roots": "",
    "ar_duration_tolerance": 1.0,
    # Channel Alerts & Telegram
    "alert_popup_enabled": True,
    "alert_tg_enabled": False,
    "alert_tg_bot_token": "",
    "alert_tg_chat_id": "",
    "alert_types": {
        "YPP_ELIGIBLE": True,
        "MON_ON": True,
        "MON_OFF": True,
        "STRIKE": True,
    },
}


# ==============================================================================
# 1. MÃ HÓA WINDOWS DPAPI & TOTP 2FA (RFC 6238)
# ==============================================================================

def dpapi_protect(plain_text: str) -> str:
    """Mã hóa chuỗi nhạy cảm bằng Windows DPAPI gắn với User hiện tại."""
    raw = (plain_text or "").encode("utf-8")
    if not raw:
        return ""
    if os.name != "nt":
        return "b64:" + base64.b64encode(raw).decode("ascii")
    try:
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
        ):
            raise ctypes.WinError()
        try:
            enc = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
        return "dpapi:" + base64.b64encode(enc).decode("ascii")
    except Exception:
        return "b64:" + base64.b64encode(raw).decode("ascii")


def dpapi_unprotect(token: str) -> str:
    """Giải mã chuỗi đã bảo vệ bằng Windows DPAPI."""
    s = str(token or "").strip()
    if not s:
        return ""
    if s.startswith("b64:"):
        try:
            return base64.b64decode(s[4:]).decode("utf-8", errors="replace")
        except Exception:
            return ""
    if not s.startswith("dpapi:"):
        return s
    raw = base64.b64decode(s[6:])
    if os.name != "nt":
        return ""
    try:
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
        ):
            return ""
        try:
            dec = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
        return dec.decode("utf-8", errors="replace")
    except Exception:
        return ""


def _win_cred_read(target_name: str) -> str:
    """Đọc bí mật đã lưu trong Windows Credential Manager (chỉ đọc)."""
    if os.name != "nt" or not target_name:
        return ""
    try:
        class CREDENTIALW(ctypes.Structure):
            _fields_ = [
                ("Flags", ctypes.wintypes.DWORD),
                ("Type", ctypes.wintypes.DWORD),
                ("TargetName", ctypes.wintypes.LPWSTR),
                ("Comment", ctypes.wintypes.LPWSTR),
                ("LastWritten", ctypes.wintypes.FILETIME),
                ("CredentialBlobSize", ctypes.wintypes.DWORD),
                ("CredentialBlob", ctypes.POINTER(ctypes.c_byte)),
                ("Persist", ctypes.wintypes.DWORD),
                ("AttributeCount", ctypes.wintypes.DWORD),
                ("Attributes", ctypes.c_void_p),
                ("TargetAlias", ctypes.wintypes.LPWSTR),
                ("UserName", ctypes.wintypes.LPWSTR),
            ]

        advapi32 = ctypes.windll.advapi32
        advapi32.CredReadW.argtypes = [
            ctypes.wintypes.LPCWSTR,
            ctypes.wintypes.DWORD,
            ctypes.wintypes.DWORD,
            ctypes.POINTER(ctypes.POINTER(CREDENTIALW)),
        ]
        advapi32.CredReadW.restype = ctypes.wintypes.BOOL
        advapi32.CredFree.argtypes = [ctypes.c_void_p]

        ptr = ctypes.POINTER(CREDENTIALW)()
        if not advapi32.CredReadW(str(target_name), 1, 0, ctypes.byref(ptr)):
            return ""
        try:
            raw = ctypes.string_at(ptr.contents.CredentialBlob, ptr.contents.CredentialBlobSize)
            if len(raw) >= 2 and len(raw) % 2 == 0 and raw[1::2].count(0) >= max(1, len(raw) // 4):
                return raw.decode("utf-16-le", errors="ignore").rstrip("\x00").strip()
            return raw.decode("utf-8", errors="ignore").rstrip("\x00").strip()
        finally:
            advapi32.CredFree(ptr)
    except Exception:
        return ""


def totp_now(secret: str, period: int = 30, digits: int = 6, at_time: int | None = None) -> dict:
    """Sinh mã OTP 6 số từ 2FA Secret chuẩn Google Authenticator (RFC 6238)."""
    clean = re.sub(r"[^A-Z2-7]", "", (secret or "").upper())
    now_ts = int(time.time()) if at_time is None else int(at_time)
    rem = period - (now_ts % period)
    if not clean:
        return {"code": "", "remaining": rem, "valid": False}
    try:
        pad = "=" * ((8 - len(clean) % 8) % 8)
        key = base64.b32decode(clean + pad, casefold=True)
        counter = int(now_ts // period)
        msg = struct.pack(">Q", counter)
        digest = hmac.new(key, msg, hashlib.sha1).digest()
        offset = digest[-1] & 0x0F
        code_int = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
        return {"code": str(code_int).zfill(digits), "remaining": rem, "valid": True}
    except Exception:
        return {"code": "", "remaining": rem, "valid": False}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _find_ffmpeg() -> str:
    for p in (
        ROOT / "bin" / "ffmpeg.exe",
        Path(r"C:\ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin\ffmpeg.exe"),
    ):
        if p.is_file():
            return str(p)
    w = shutil.which("ffmpeg")
    return w or "ffmpeg"


def _find_ffprobe() -> str:
    for p in (
        ROOT / "bin" / "ffprobe.exe",
        Path(r"C:\ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin\ffprobe.exe"),
    ):
        if p.is_file():
            return str(p)
    w = shutil.which("ffprobe")
    return w or "ffprobe"


def _probe_duration(file_path: str | Path) -> float:
    p = Path(file_path)
    if not p.is_file():
        return 0.0
    try:
        cp = subprocess.run(
            [_find_ffprobe(), "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(p)],
            capture_output=True, text=True, timeout=12, creationflags=_NOWIN
        )
        return round(float((cp.stdout or "").strip()), 2)
    except Exception:
        return 0.0


# ==============================================================================
# 2. CƠ SỞ DỮ LIỆU SQLITE NỘI BỘ MYINGGO
# ==============================================================================

_DB_LOCK = threading.RLock()


def _db_conn() -> sqlite3.Connection:
    con = sqlite3.connect(str(HUB_DB), timeout=15.0, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def _init_db():
    with _DB_LOCK:
        con = _db_conn()
        try:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                name TEXT DEFAULT '',
                password_enc TEXT DEFAULT '',
                tfa_secret_enc TEXT DEFAULT '',
                recovery_email TEXT DEFAULT '',
                recovery_phone TEXT DEFAULT '',
                profile_dir TEXT DEFAULT '',
                cookie_path TEXT DEFAULT '',
                enabled INTEGER DEFAULT 1,
                session_status TEXT DEFAULT 'READY',
                session_message TEXT DEFAULT '',
                channel_count INTEGER DEFAULT 0,
                note TEXT DEFAULT '',
                label TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER DEFAULT 0,
                account_email TEXT DEFAULT '',
                youtube_channel_id TEXT UNIQUE NOT NULL,
                title TEXT DEFAULT '',
                handle TEXT DEFAULT '',
                avatar_url TEXT DEFAULT '',
                enabled INTEGER DEFAULT 1,
                session_status TEXT DEFAULT 'OK',
                studio_session_status TEXT DEFAULT 'PINNED',
                session_message TEXT DEFAULT '',
                key_folder TEXT DEFAULT '',
                subscriber_count INTEGER DEFAULT 0,
                video_count INTEGER DEFAULT 0,
                view_count INTEGER DEFAULT 0,
                views_48h INTEGER DEFAULT 0,
                views_28d INTEGER DEFAULT 0,
                revenue_month REAL DEFAULT 0.0,
                revenue_28d REAL DEFAULT 0.0,
                monetization_status TEXT DEFAULT 'UNKNOWN',
                add_audio_feature TEXT DEFAULT 'YES',
                draft_total INTEGER DEFAULT 0,
                draft_audio_ready INTEGER DEFAULT 0,
                draft_no_audio INTEGER DEFAULT 0,
                audio_rejected_count INTEGER DEFAULT 0,
                copyright_strikes INTEGER DEFAULT 0,
                copyright_claims INTEGER DEFAULT 0,
                scheduled_count INTEGER DEFAULT 0,
                schedule_days_left INTEGER DEFAULT 0,
                schedule_level TEXT DEFAULT 'GREEN',
                dup_blocked INTEGER DEFAULT 0,
                sampled_at TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS channel_videos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER NOT NULL,
                youtube_channel_id TEXT DEFAULT '',
                channel_title TEXT DEFAULT '',
                video_id TEXT NOT NULL,
                title TEXT DEFAULT '',
                privacy TEXT DEFAULT 'public',
                is_draft INTEGER DEFAULT 0,
                scheduled_epoch INTEGER DEFAULT 0,
                published_epoch INTEGER DEFAULT 0,
                duration REAL DEFAULT 0.0,
                view_count INTEGER DEFAULT 0,
                audio_state TEXT DEFAULT 'OK',
                copyright_state TEXT DEFAULT 'NONE',
                monetization_state TEXT DEFAULT 'ON',
                updated_at TEXT DEFAULT '',
                UNIQUE(channel_id, video_id)
            );

            CREATE TABLE IF NOT EXISTS audio_repair_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER DEFAULT 0,
                channel_title TEXT DEFAULT '',
                studio_video_id TEXT NOT NULL,
                video_title TEXT DEFAULT '',
                video_kind TEXT DEFAULT 'public',
                studio_duration REAL DEFAULT 0.0,
                hitmakers_duration REAL DEFAULT 0.0,
                hitmakers_local_id TEXT DEFAULT '',
                source_path TEXT DEFAULT '',
                total_views INTEGER DEFAULT 0,
                privacy TEXT DEFAULT 'VIDEO_PRIVACY_PUBLIC',
                issue_code TEXT DEFAULT 'REJECTED',
                issue_label TEXT DEFAULT 'Audio bị từ chối / gỡ',
                audio_processed INTEGER DEFAULT 0,
                audio_rejected INTEGER DEFAULT 1,
                audio_removed INTEGER DEFAULT 0,
                repair_languages TEXT DEFAULT 'es, pt, fr, de, it',
                readd_attempts INTEGER DEFAULT 0,
                status TEXT DEFAULT 'CANDIDATE',
                progress INTEGER DEFAULT 0,
                stage TEXT DEFAULT 'Chờ xử lý',
                error TEXT DEFAULT '',
                scanned_at TEXT DEFAULT '',
                UNIQUE(channel_id, studio_video_id)
            );

            CREATE TABLE IF NOT EXISTS audio_repair_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER DEFAULT 0,
                channel_title TEXT DEFAULT '',
                studio_video_id TEXT NOT NULL,
                video_title TEXT DEFAULT '',
                video_kind TEXT DEFAULT 'public',
                hitmakers_local_id TEXT DEFAULT '',
                studio_duration REAL DEFAULT 0.0,
                source_path TEXT DEFAULT '',
                prepared_path TEXT DEFAULT '',
                prepared_duration REAL DEFAULT 0.0,
                languages_json TEXT DEFAULT '[]',
                mode TEXT DEFAULT 'all',
                content_type TEXT DEFAULT 'global',
                attempt INTEGER DEFAULT 1,
                status TEXT DEFAULT 'DONE',
                progress INTEGER DEFAULT 100,
                stage TEXT DEFAULT 'Hoàn tất Re-Add',
                readd_check_status TEXT DEFAULT 'OK',
                readd_checked_at TEXT DEFAULT '',
                error TEXT DEFAULT '',
                created_at TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS channel_monitor_daily (
                channel_id INTEGER NOT NULL,
                day TEXT NOT NULL,
                views INTEGER,
                revenue REAL,
                fetched_at TEXT DEFAULT '',
                PRIMARY KEY(channel_id, day)
            );

            CREATE TABLE IF NOT EXISTS audio_repair_channel_dirs (
                hitmakers_channel_name TEXT PRIMARY KEY,
                crawl_dir TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS audio_repair_source_index (
                local_id TEXT PRIMARY KEY,
                source_path TEXT DEFAULT '',
                root_path TEXT DEFAULT '',
                hitmakers_channel_name TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS copyright_licenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                license_text TEXT NOT NULL DEFAULT '',
                signature TEXT NOT NULL DEFAULT '',
                include_claimants TEXT DEFAULT '',
                exclude_claimants TEXT DEFAULT '',
                note TEXT DEFAULT '',
                created_at TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS copyright_disputes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER DEFAULT 0,
                youtube_channel_id TEXT DEFAULT '',
                channel_title TEXT DEFAULT '',
                account_email TEXT DEFAULT '',
                video_id TEXT NOT NULL,
                video_title TEXT DEFAULT '',
                claim_id TEXT DEFAULT '',
                claim_title TEXT DEFAULT '',
                claimant TEXT DEFAULT '',
                license_id INTEGER DEFAULT 0,
                license_name TEXT DEFAULT '',
                status TEXT DEFAULT 'PENDING',
                method TEXT DEFAULT '',
                message TEXT DEFAULT '',
                disputed_at TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_cp_disputes_vid ON copyright_disputes(video_id);

            CREATE TABLE IF NOT EXISTS channel_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_key TEXT UNIQUE NOT NULL,
                event_type TEXT NOT NULL,
                channel_id INTEGER DEFAULT 0,
                youtube_channel_id TEXT DEFAULT '',
                channel_title TEXT DEFAULT '',
                account_email TEXT DEFAULT '',
                title TEXT DEFAULT '',
                detail TEXT DEFAULT '',
                dismissed INTEGER DEFAULT 0,
                tg_sent INTEGER DEFAULT 0,
                tg_error TEXT DEFAULT '',
                created_at TEXT DEFAULT '',
                dismissed_at TEXT DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_channel_alerts_dismissed ON channel_alerts(dismissed, id DESC);

            CREATE TABLE IF NOT EXISTS channel_alert_state (
                youtube_channel_id TEXT PRIMARY KEY,
                monetization_status TEXT DEFAULT '',
                subscriber_count INTEGER DEFAULT 0,
                watch_hours_365d REAL,
                copyright_strikes INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT ''
            );
            """)
            # Safe migration of extended Channel Monitor & Audio Repair columns on existing DBs
            existing_cols = {r[1] for r in con.execute("PRAGMA table_info(channels)").fetchall()}
            extra_cols = [
                ("t3_channel_id", "INTEGER DEFAULT 0"),
                ("views_60m", "INTEGER DEFAULT 0"),
                ("views_24h", "INTEGER DEFAULT 0"),
                ("views_24h_change_pct", "REAL"),
                ("views_7d", "INTEGER DEFAULT 0"),
                ("views_48h_series_json", "TEXT DEFAULT '[]'"),
                ("subscribers_net_latest_day", "INTEGER"),
                ("subscribers_7d", "INTEGER"),
                ("subscribers_28d", "INTEGER"),
                ("revenue_latest_day", "REAL"),
                ("revenue_latest_date", "TEXT DEFAULT ''"),
                ("revenue_prev_day", "REAL"),
                ("revenue_prev_month", "REAL"),
                ("rpm_28d", "REAL"),
                ("audio_processing_videos", "INTEGER DEFAULT 0"),
                ("audio_reject_pending", "INTEGER DEFAULT 0"),
                ("draft_audio_failed", "INTEGER DEFAULT 0"),
                ("scheduled_with_audio", "INTEGER DEFAULT 0"),
                ("scheduled_no_audio", "INTEGER DEFAULT 0"),
                ("scheduled_audio_failed", "INTEGER DEFAULT 0"),
                ("copyright_draft", "INTEGER DEFAULT 0"),
                ("copyright_scheduled", "INTEGER DEFAULT 0"),
                ("copyright_public", "INTEGER DEFAULT 0"),
                ("ads_off_total", "INTEGER DEFAULT 0"),
                ("video_language_set", "INTEGER DEFAULT 1"),
                ("video_language_name", "TEXT DEFAULT ''"),
                ("schedule_next_epoch", "INTEGER DEFAULT 0"),
                ("scheduled_until_epoch", "INTEGER DEFAULT 0"),
                ("schedule_gap_count", "INTEGER DEFAULT 0"),
                ("schedule_gap_dates_json", "TEXT DEFAULT '[]'"),
                ("schedule_active_days", "INTEGER DEFAULT 0"),
                ("feature_tiers_json", "TEXT DEFAULT '{}'"),
                ("detail_json", "TEXT DEFAULT '{}'"),
                ("page_id", "TEXT DEFAULT ''"),
                ("is_brand", "INTEGER DEFAULT -1"),
                ("brand_name", "TEXT DEFAULT ''"),
                ("license_id", "INTEGER DEFAULT 0"),
            ]
            for col_name, col_def in extra_cols:
                if col_name not in existing_cols:
                    con.execute(f"ALTER TABLE channels ADD COLUMN {col_name} {col_def}")
            acc_cols = {r[1] for r in con.execute("PRAGMA table_info(accounts)").fetchall()}
            for col_name, col_def in [("only_channels", "TEXT DEFAULT ''"), ("include_main_channel", "INTEGER DEFAULT 0")]:
                if col_name not in acc_cols:
                    con.execute(f"ALTER TABLE accounts ADD COLUMN {col_name} {col_def}")
            ar_cols = {r[1] for r in con.execute("PRAGMA table_info(audio_repair_items)").fetchall()}
            for col_name, col_def in [
                ("bad_tracks_json", "TEXT DEFAULT '[]'"),
                ("good_langs_json", "TEXT DEFAULT '[]'"),
                ("source_duration", "REAL DEFAULT 0.0"),
                ("hitmakers_duration", "REAL DEFAULT 0.0"),
                ("hitmakers_channel_name", "TEXT DEFAULT ''"),
                ("hitmakers_path_hint", "TEXT DEFAULT ''"),
                ("deleted_track_count", "INTEGER DEFAULT 0"),
                ("cut_history_json", "TEXT DEFAULT '[]'"),
                ("cut_event_count", "INTEGER DEFAULT 0"),
                ("cut_removed_seconds", "REAL DEFAULT 0.0"),
            ]:
                if col_name not in ar_cols:
                    con.execute(f"ALTER TABLE audio_repair_items ADD COLUMN {col_name} {col_def}")
            ar_job_cols = {r[1] for r in con.execute("PRAGMA table_info(audio_repair_jobs)").fetchall()}
            for col_name, col_def in [
                ("hitmakers_duration", "REAL DEFAULT 0.0"),
                ("source_duration", "REAL DEFAULT 0.0"),
                ("deleted_track_count", "INTEGER DEFAULT 0"),
                ("hitmakers_channel_name", "TEXT DEFAULT ''"),
                ("hitmakers_path_hint", "TEXT DEFAULT ''"),
                ("cut_removed_seconds", "REAL DEFAULT 0.0"),
            ]:
                if col_name not in ar_job_cols:
                    con.execute(f"ALTER TABLE audio_repair_jobs ADD COLUMN {col_name} {col_def}")
            con.commit()
        finally:
            con.close()


# ==============================================================================
# 3. ĐỒNG BỘ DỮ LIỆU & BRIDGE VỚI 3T MASTER (NẾU CÓ TRÊN MÁY)
# ==============================================================================

def _find_3t_root(cfg: dict) -> Path | None:
    custom = str(cfg.get("t3_root") or "").strip()
    candidates = []
    if custom:
        candidates.append(Path(custom))
    candidates.extend([
        Path(r"F:\3TMaster"),
        Path(r"C:\3TMaster"),
        Path(r"D:\3TMaster"),
        Path(r"E:\3TMaster"),
    ])
    for c in candidates:
        try:
            if c.is_dir() and ((c / "data").is_dir() or (c / "app").is_dir() or (c / "run.py").is_file()):
                return c
        except OSError:
            pass
    return None


def _t3_http(port: int, path: str, method: str = "GET", payload: dict | None = None, timeout: float = 4.0):
    url = f"http://127.0.0.1:{port}/{path.lstrip('/')}"
    data = None
    headers = {"User-Agent": "MyingGo-YTStudioHub/1.0"}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read().decode("utf-8", errors="replace")
        return json.loads(raw) if raw else {}


def _check_t3_live(port: int = 8891) -> dict:
    try:
        res = _t3_http(port, "/api/health", timeout=1.5)
        return {"alive": True, "version": res.get("version") or "2.5.x", "locked": False}
    except urllib.error.HTTPError as e:
        if e.code == 423:
            return {"alive": True, "version": "2.5.x", "locked": True}
        return {"alive": False, "error": f"HTTP {e.code}"}
    except Exception as e:
        return {"alive": False, "error": str(e)}


def _open_external_sqlite(db_path: Path) -> sqlite3.Connection:
    """Mở an toàn file SQLite ngoài (hỗ trợ cả khi 3TMaster đang mở hoặc khóa WAL)."""
    for attempt in range(3):
        try:
            if attempt == 0:
                con = sqlite3.connect(str(db_path), timeout=5.0)
            elif attempt == 1:
                con = sqlite3.connect(f"{db_path.as_uri()}?mode=ro", uri=True, timeout=5.0)
            else:
                con = sqlite3.connect(f"{db_path.as_uri()}?immutable=1", uri=True, timeout=5.0)
            con.row_factory = sqlite3.Row
            return con
        except Exception:
            if attempt == 2:
                raise
    raise RuntimeError(f"Cannot open {db_path}")


def sync_from_3t_sqlite(t3_root: Path | None, port: int = 8891) -> dict:
    """Đồng bộ toàn diện từ 3TMaster (F:\3TMaster, C:\3TMaster, SQLite trực tiếp + HTTP API 127.0.0.1:8891)."""
    stats = {"accounts": 0, "channels": 0, "monitor": 0, "ar_items": 0, "ar_jobs": 0}
    _init_db()

    # Tìm các vị trí có thể chứa hd_master.db và audio_repair_jobs.db
    local_app = Path(os.environ.get("LOCALAPPDATA") or str(Path.home()))
    db_dirs = []
    if t3_root:
        db_dirs.extend([t3_root / "data", t3_root / "data" / "recovery_backups"])
    db_dirs.extend([
        Path(r"F:\3TMaster\data"),
        Path(r"C:\3TMaster\data"),
        Path(r"D:\3TMaster\data"),
        local_app / "3TMaster" / "data",
        local_app / "HDMaster" / "data",
    ])
    hd_db = next((d / "hd_master.db" for d in db_dirs if (d / "hd_master.db").is_file()), None)
    ar_db = next((d / "audio_repair_jobs.db" for d in db_dirs if (d / "audio_repair_jobs.db").is_file()), None)
    if not t3_root and hd_db:
        t3_root = hd_db.parent.parent

    with _DB_LOCK:
        con = _db_conn()
        try:
            # -------------------------------------------------------------
            # A. ĐỒNG BỘ TÀI KHOẢN (ACCOUNTS)
            # -------------------------------------------------------------
            # 1. Từ native_bridge/yatranslator_runtime/auth/storage/google-accounts.json (Tài khoản chính 3T)
            if t3_root:
                ga_f = t3_root / "native_bridge" / "yatranslator_runtime" / "auth" / "storage" / "google-accounts.json"
                if ga_f.is_file():
                    try:
                        ga = json.loads(ga_f.read_text(encoding="utf-8"))
                        for a in ga.get("accounts") or []:
                            em = str(a.get("email") or "").strip().lower()
                            if not em or "@" not in em:
                                continue
                            pw_raw = str(a.get("password") or "").strip()
                            pw_enc = dpapi_protect(pw_raw) if pw_raw else ""
                            tfa_raw = str(a.get("twoFactorSecret") or a.get("totp_secret") or "").strip()
                            tfa_enc = dpapi_protect(tfa_raw) if tfa_raw else ""
                            pdir = str(t3_root / "data" / "profiles" / re.sub(r"[^a-zA-Z0-9_.-]", "_", em))
                            con.execute("""
                                INSERT INTO accounts (
                                    email, name, password_enc, tfa_secret_enc, profile_dir, label, session_status, updated_at
                                ) VALUES (?, ?, ?, ?, ?, 'Tài khoản chính 3T', 'READY', ?)
                                ON CONFLICT(email) DO UPDATE SET
                                    password_enc=CASE WHEN excluded.password_enc!='' THEN excluded.password_enc ELSE accounts.password_enc END,
                                    tfa_secret_enc=CASE WHEN excluded.tfa_secret_enc!='' THEN excluded.tfa_secret_enc ELSE accounts.tfa_secret_enc END,
                                    profile_dir=CASE WHEN excluded.profile_dir!='' THEN excluded.profile_dir ELSE accounts.profile_dir END,
                                    label=excluded.label,
                                    updated_at=excluded.updated_at
                            """, (em, em, pw_enc, tfa_enc, pdir, _now_iso()))
                            stats["accounts"] += 1
                    except Exception:
                        pass

            # 4. Từ HTTP API 127.0.0.1:8891 nếu 3TMaster đang mở
            try:
                http_accs = _t3_http(port, "/api/accounts", timeout=2.0)
                if isinstance(http_accs, dict):
                    http_accs = http_accs.get("accounts") or http_accs.get("items") or []
                if isinstance(http_accs, list):
                    for a in http_accs:
                        if not isinstance(a, dict):
                            continue
                        em = str(a.get("email") or a.get("name") or "").strip().lower()
                        if not em:
                            continue
                        con.execute("""
                            INSERT INTO accounts (email, name, enabled, session_status, channel_count, label, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(email) DO UPDATE SET
                                session_status=excluded.session_status,
                                channel_count=MAX(accounts.channel_count, excluded.channel_count),
                                updated_at=excluded.updated_at
                        """, (
                            em, str(a.get("name") or em), int(a.get("enabled", 1)),
                            str(a.get("session_status") or "READY"),
                            int(a.get("last_channel_load_count") or a.get("channel_count") or 0),
                            str(a.get("label") or ""), _now_iso()
                        ))
                        stats["accounts"] += 1
            except Exception:
                pass

            # -------------------------------------------------------------
            # B. ĐỒNG BỘ KÊNH (CHANNELS) TỪ NATIVE BRIDGE, COOKIES & LOGS
            # -------------------------------------------------------------
            channels_pool = {}  # uc -> dict channel
            primary_email = "themanh@3tagent.com"

            # 1. Native bridge channel-cookies & channel-owners
            if t3_root:
                owners_f = t3_root / "native_bridge" / "yatranslator_runtime" / "auth" / "storage" / "channel-owners.json"
                owners = json.loads(owners_f.read_text(encoding="utf-8")) if owners_f.is_file() else {}

                status_f = t3_root / "native_bridge" / "yamaster_channel_runtime" / "storage" / "channel-session-status.json"
                status_data = json.loads(status_f.read_text(encoding="utf-8")) if status_f.is_file() else {}

                acc_cookies_dir = t3_root / "native_bridge" / "yatranslator_runtime" / "auth" / "channel-cookies" / "accounts"
                if acc_cookies_dir.is_dir():
                    for a_dir in acc_cookies_dir.iterdir():
                        if not a_dir.is_dir():
                            continue
                        owner_mail = a_dir.name.replace("_at_", "@").replace("_", ".")
                        for cf in a_dir.glob("*-channel-code.txt"):
                            slug = cf.name.replace("-channel-code.txt", "")
                            try:
                                uc = cf.read_text(encoding="utf-8").strip()
                            except Exception:
                                continue
                            if not uc:
                                continue
                            clean_t = slug.replace("-", " ").title()
                            st = status_data.get(slug, {})
                            s_stat = "ERROR" if st.get("status") == "error" else "PINNED"
                            s_msg = st.get("message") or "Phiên Studio Pinned"
                            assigned_email = owners.get(slug, {}).get("email") or owner_mail or primary_email
                            channels_pool[uc] = {
                                "youtube_channel_id": uc,
                                "title": clean_t,
                                "account_email": assigned_email,
                                "session_status": s_stat,
                                "studio_session_status": "PINNED",
                                "session_message": s_msg,
                                "key_folder": slug,
                            }

                # 2. Switcher logs (data/logs/channel-switcher)
                sw_dir = t3_root / "data" / "logs" / "channel-switcher"
                if sw_dir.is_dir():
                    for f in sw_dir.glob("*.json"):
                        try:
                            d = json.loads(f.read_text(encoding="utf-8"))
                            uc = d.get("youtube_channel_id") or d.get("channel_id") or ""
                            if not uc:
                                m = re.search(r"(UC[A-Za-z0-9_-]{22})", f.name)
                                if m: uc = m.group(1)
                            title = d.get("channel_title") or d.get("title") or ""
                            if uc:
                                if uc not in channels_pool:
                                    channels_pool[uc] = {
                                        "youtube_channel_id": uc,
                                        "title": title or uc,
                                        "account_email": primary_email,
                                        "session_status": "PINNED",
                                        "studio_session_status": "PINNED",
                                        "session_message": "Ghim từ Channel Switcher",
                                        "key_folder": "",
                                    }
                                elif title and channels_pool[uc]["title"] == uc:
                                    channels_pool[uc]["title"] = title
                        except Exception:
                            pass

            # -------------------------------------------------------------
            # C. ĐỒNG BỘ TỪ SQLITE hd_master.db (Accounts, Channels, Metrics, Audio)
            # -------------------------------------------------------------
            if hd_db and hd_db.is_file():
                src = _open_external_sqlite(hd_db)
                try:
                    # 1. Accounts trong hd_master.db
                    acc_map = {}
                    try:
                        for r in src.execute("SELECT * FROM accounts").fetchall():
                            d = dict(r)
                            email = str(d.get("email") or d.get("name") or "").strip().lower()
                            if not email:
                                continue
                            acc_map[d["id"]] = email
                            con.execute("""
                                INSERT INTO accounts (email, name, profile_dir, cookie_path, enabled, session_status,
                                    session_message, channel_count, recovery_email, recovery_phone, note, label, updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                ON CONFLICT(email) DO UPDATE SET
                                    name=excluded.name,
                                    profile_dir=CASE WHEN excluded.profile_dir!='' THEN excluded.profile_dir ELSE accounts.profile_dir END,
                                    enabled=excluded.enabled,
                                    session_status=excluded.session_status,
                                    session_message=excluded.session_message,
                                    channel_count=MAX(accounts.channel_count, excluded.channel_count),
                                    updated_at=excluded.updated_at
                            """, (
                                email, str(d.get("name") or email), str(d.get("profile_dir") or ""),
                                str(d.get("crawl_cookie_path") or ""), int(d.get("enabled") or 1),
                                str(d.get("session_status") or "READY"), str(d.get("session_message") or ""),
                                int(d.get("last_channel_load_count") or 0), str(d.get("recovery_email") or ""),
                                str(d.get("recovery_phone") or ""), str(d.get("note") or ""), str(d.get("label") or ""),
                                str(d.get("session_checked_at") or _now_iso()),
                            ))
                            stats["accounts"] += 1
                    except Exception:
                        pass

                    # 2. Extract channel activations from logs table
                    try:
                        for r in src.execute("SELECT DISTINCT message FROM logs WHERE message LIKE '%Đã kích hoạt đúng kênh%'").fetchall():
                            m = re.search(r"Đã kích hoạt đúng kênh\s*•\s*(.*?)\s*•\s*actual=(UC[A-Za-z0-9_-]{22})", r[0])
                            if m:
                                t, uc = m.group(1).strip(), m.group(2).strip()
                                if uc not in channels_pool:
                                    channels_pool[uc] = {
                                        "youtube_channel_id": uc,
                                        "title": t,
                                        "account_email": primary_email,
                                        "session_status": "PINNED",
                                        "studio_session_status": "PINNED",
                                        "session_message": "Đã kích hoạt trong phiên Studio",
                                        "key_folder": "",
                                    }
                                else:
                                    channels_pool[uc]["title"] = t
                    except Exception:
                        pass

                    # 3. Extract channels from video_cleanup_history
                    try:
                        for r in src.execute("SELECT DISTINCT youtube_channel_id, channel_title FROM video_cleanup_history WHERE youtube_channel_id != ''").fetchall():
                            uc = r["youtube_channel_id"]
                            t = r["channel_title"]
                            if uc not in channels_pool:
                                channels_pool[uc] = {
                                    "youtube_channel_id": uc,
                                    "title": t,
                                    "account_email": primary_email,
                                    "session_status": "PINNED",
                                    "studio_session_status": "PINNED",
                                    "session_message": "",
                                    "key_folder": "",
                                }
                            elif t:
                                channels_pool[uc]["title"] = t
                    except Exception:
                        pass

                    # 4. Check if channels table exists with rows
                    try:
                        for r in src.execute("SELECT * FROM channels").fetchall():
                            d = dict(r)
                            uc = str(d.get("youtube_channel_id") or "").strip()
                            if not uc:
                                continue
                            email = acc_map.get(d.get("account_id"), "") or primary_email
                            channels_pool[uc] = {
                                "youtube_channel_id": uc,
                                "title": str(d.get("title") or uc),
                                "account_email": email,
                                "subscriber_count": int(d.get("subscriber_count") or 0),
                                "video_count": int(d.get("video_count") or 0),
                                "view_count": int(d.get("view_count") or 0),
                                "monetization_status": str(d.get("monetization_status") or "UNKNOWN"),
                                "session_status": str(d.get("session_status") or "OK"),
                                "studio_session_status": str(d.get("studio_session_status") or "PINNED"),
                                "key_folder": str(d.get("key_folder") or ""),
                            }
                    except Exception:
                        pass

                    # 5. Extract Channel Monitor Metrics from channel_monitor_latest
                    cm_by_title = {}
                    cid_to_name = {}
                    try:
                        for r in src.execute("SELECT DISTINCT channel_id, channel_title FROM audio_repair_scan_items").fetchall():
                            cid_to_name[r["channel_id"]] = r["channel_title"]
                        for r in src.execute("SELECT DISTINCT channel_id, channel_title FROM video_cleanup_history").fetchall():
                            cid_to_name[r["channel_id"]] = r["channel_title"]
                    except Exception:
                        pass

                    try:
                        for mr in src.execute("SELECT * FROM channel_monitor_latest").fetchall():
                            md = dict(mr)
                            cid = md["channel_id"]
                            c_name = cid_to_name.get(cid)
                            if c_name:
                                cm_by_title[c_name.strip().lower()] = md
                            stats["monitor"] += 1
                    except Exception:
                        pass

                    # Write all collected channels to database
                    for uc, c in channels_pool.items():
                        c_title = c.get("title") or uc
                        cm = cm_by_title.get(c_title.strip().lower(), {})
                        subs = int(cm.get("subscriber_count") or c.get("subscriber_count") or 0)
                        vids = int(cm.get("video_count") or c.get("video_count") or 0)
                        views = int(cm.get("total_views") or c.get("view_count") or 0)
                        views_28d = int(cm.get("views_28d") or 0)
                        views_48h = int(cm.get("views_latest_day") or 0)
                        rev_m = float(cm.get("revenue_month") or 0.0)
                        rev_28 = float(cm.get("revenue_28d") or 0.0)
                        mon_st = str(cm.get("monetization_status") or c.get("monetization_status") or "UNKNOWN")
                        draft_tot = int(cm.get("draft_total") or 0)
                        draft_ok = int(cm.get("draft_audio_ready") or 0)
                        draft_no = int(cm.get("draft_no_audio") or 0)
                        sched_cnt = int(cm.get("scheduled_count") or 0)
                        sched_days = int(cm.get("schedule_days_left") if cm.get("schedule_days_left") is not None else 0)
                        sched_lvl = str(cm.get("schedule_level") or ("GREEN" if sched_days > 15 else ("YELLOW" if sched_days >= 6 else "RED")))

                        con.execute("""
                            INSERT INTO channels (
                                account_email, youtube_channel_id, title, key_folder, enabled,
                                session_status, studio_session_status, session_message,
                                subscriber_count, video_count, view_count, views_48h, views_28d,
                                revenue_month, revenue_28d, monetization_status,
                                draft_total, draft_audio_ready, draft_no_audio,
                                scheduled_count, schedule_days_left, schedule_level,
                                sampled_at, updated_at
                            ) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(youtube_channel_id) DO UPDATE SET
                                title=excluded.title,
                                account_email=CASE WHEN excluded.account_email!='' THEN excluded.account_email ELSE channels.account_email END,
                                key_folder=CASE WHEN excluded.key_folder!='' THEN excluded.key_folder ELSE channels.key_folder END,
                                session_status=excluded.session_status,
                                studio_session_status=excluded.studio_session_status,
                                session_message=excluded.session_message,
                                subscriber_count=excluded.subscriber_count,
                                video_count=excluded.video_count,
                                view_count=excluded.view_count,
                                views_48h=excluded.views_48h,
                                views_28d=excluded.views_28d,
                                revenue_month=excluded.revenue_month,
                                revenue_28d=excluded.revenue_28d,
                                monetization_status=excluded.monetization_status,
                                draft_total=excluded.draft_total,
                                draft_audio_ready=excluded.draft_audio_ready,
                                draft_no_audio=excluded.draft_no_audio,
                                scheduled_count=excluded.scheduled_count,
                                schedule_days_left=excluded.schedule_days_left,
                                schedule_level=excluded.schedule_level,
                                sampled_at=excluded.sampled_at,
                                updated_at=excluded.updated_at
                        """, (
                            str(c.get("account_email") or primary_email), uc, c_title, str(c.get("key_folder") or ""),
                            str(c.get("session_status") or "OK"), str(c.get("studio_session_status") or "PINNED"),
                            str(c.get("session_message") or "Phiên Studio Pinned"),
                            subs, vids, views, views_48h, views_28d, rev_m, rev_28, mon_st,
                            draft_tot, draft_ok, draft_no, sched_cnt, sched_days, sched_lvl,
                            str(cm.get("sampled_at") or _now_iso()), _now_iso()
                        ))
                        stats["channels"] += 1

                    # 6. Audio Repair Scan Items (851 items)
                    try:
                        for ar in src.execute("SELECT * FROM audio_repair_scan_items LIMIT 1000").fetchall():
                            ad = dict(ar)
                            vid = str(ad.get("studio_video_id") or "").strip()
                            if not vid:
                                continue
                            ch_t = str(ad.get("channel_title") or "").strip()
                            langs = ad.get("repair_languages_json") or "[]"
                            try:
                                l_arr = json.loads(langs)
                                langs_str = ", ".join(l_arr) if isinstance(l_arr, list) else str(langs)
                            except Exception:
                                langs_str = str(langs)
                            con.execute("""
                                INSERT INTO audio_repair_items (
                                    channel_id, channel_title, studio_video_id, video_title, video_kind,
                                    studio_duration, total_views, privacy, issue_code, issue_label,
                                    audio_processed, audio_rejected, audio_removed, repair_languages, scanned_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                ON CONFLICT(channel_id, studio_video_id) DO UPDATE SET
                                    channel_title=excluded.channel_title,
                                    video_title=excluded.video_title,
                                    total_views=excluded.total_views,
                                    issue_code=excluded.issue_code,
                                    issue_label=excluded.issue_label,
                                    audio_processed=excluded.audio_processed,
                                    audio_rejected=excluded.audio_rejected,
                                    audio_removed=excluded.audio_removed,
                                    scanned_at=excluded.scanned_at
                            """, (
                                int(ad.get("channel_id") or 0), ch_t or "YouTube Channel", vid,
                                str(ad.get("video_title") or vid), str(ad.get("video_kind") or "public"),
                                float(ad.get("studio_duration") or 0.0), int(ad.get("total_views") or 0),
                                str(ad.get("privacy") or "VIDEO_PRIVACY_PUBLIC"),
                                str(ad.get("issue_code") or "FAILED"),
                                str(ad.get("issue_label") or "Không xử lý được"),
                                int(ad.get("audio_processed") or 0),
                                int(ad.get("audio_rejected") or 0),
                                int(ad.get("audio_removed") or 0),
                                langs_str or "es, pt, fr, de, it",
                                str(ad.get("scanned_at") or _now_iso())
                            ))
                            stats["ar_items"] += 1
                    except Exception:
                        pass
                finally:
                    src.close()

            # -------------------------------------------------------------
            # D. ĐỒNG BỘ AUDIO REPAIR JOBS
            # -------------------------------------------------------------
            if ar_db and ar_db.is_file():
                src2 = _open_external_sqlite(ar_db)
                try:
                    for jr in src2.execute("SELECT * FROM audio_repair_jobs ORDER BY id DESC LIMIT 500").fetchall():
                        jd = dict(jr)
                        vid = str(jd.get("studio_video_id") or "").strip()
                        if not vid:
                            continue
                        con.execute("""
                            INSERT INTO audio_repair_jobs (
                                id, channel_id, channel_title, studio_video_id, video_title, video_kind,
                                hitmakers_local_id, studio_duration, source_path, prepared_path,
                                prepared_duration, languages_json, attempt, status, progress, stage,
                                error, created_at, updated_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(id) DO UPDATE SET
                                status=excluded.status,
                                progress=excluded.progress,
                                stage=excluded.stage,
                                attempt=excluded.attempt,
                                error=excluded.error,
                                updated_at=excluded.updated_at
                        """, (
                            int(jd["id"]), int(jd.get("channel_id") or 0),
                            str(jd.get("channel_title") or ""), vid,
                            str(jd.get("video_title") or vid), str(jd.get("video_kind") or "public"),
                            str(jd.get("hitmakers_local_id") or ""), float(jd.get("studio_duration") or 0.0),
                            str(jd.get("source_path") or ""), str(jd.get("prepared_path") or ""),
                            float(jd.get("prepared_duration") or 0.0), str(jd.get("languages_json") or "[]"),
                            int(jd.get("attempt") or 1), str(jd.get("status") or "READY"),
                            int(jd.get("progress") or 0), str(jd.get("stage") or ""),
                            str(jd.get("error") or ""), str(jd.get("created_at") or _now_iso()),
                            str(jd.get("updated_at") or _now_iso())
                        ))
                        stats["ar_jobs"] += 1
                finally:
                    src2.close()

            # Đồng bộ channel_monitor_daily từ hd_master.db (cho biểu đồ Trend khi offline)
            if hd_db and hd_db.is_file():
                src_d = _open_external_sqlite(hd_db)
                try:
                    for dr in src_d.execute("SELECT channel_id, day, views, revenue, fetched_at FROM channel_monitor_daily ORDER BY day DESC LIMIT 8000").fetchall():
                        con.execute("""
                            INSERT INTO channel_monitor_daily (channel_id, day, views, revenue, fetched_at)
                            VALUES (?, ?, ?, ?, ?)
                            ON CONFLICT(channel_id, day) DO UPDATE SET
                                views=COALESCE(excluded.views, channel_monitor_daily.views),
                                revenue=COALESCE(excluded.revenue, channel_monitor_daily.revenue),
                                fetched_at=CASE WHEN excluded.fetched_at!='' THEN excluded.fetched_at ELSE channel_monitor_daily.fetched_at END
                        """, (int(dr["channel_id"]), str(dr["day"]), dr["views"], dr["revenue"], str(dr["fetched_at"] or "")))
                except Exception:
                    pass
                finally:
                    src_d.close()

            # Đồng bộ live snapshot từ 127.0.0.1:{port}/api/channel-monitor/snapshot nếu 3TMaster đang chạy
            try:
                snap = _t3_http(port, "/api/channel-monitor/snapshot", timeout=3.5)
                if isinstance(snap, dict) and isinstance(snap.get("items"), list):
                    for it in snap["items"]:
                        uc = str(it.get("youtube_channel_id") or "").strip()
                        if not uc:
                            continue
                        mta = str(it.get("multi_track_audio_status") or "").upper()
                        add_feat = "YES" if (it.get("multi_track_audio_enabled") is True or mta == "ENABLED") else ("NO" if (it.get("multi_track_audio_enabled") is False or mta == "DISABLED") else "UNKNOWN")
                        sl_days = int(it.get("schedule_days_left") if it.get("schedule_days_left") is not None else 0)
                        sl_lvl = str(it.get("schedule_level") or ("GREEN" if sl_days > 15 else ("YELLOW" if sl_days >= 6 else "RED"))).upper()
                        con.execute("""
                            INSERT INTO channels (
                                t3_channel_id, account_email, youtube_channel_id, title, avatar_url,
                                session_status, studio_session_status,
                                subscriber_count, video_count, view_count, views_48h, views_60m, views_24h,
                                views_24h_change_pct, views_7d, views_28d, views_48h_series_json,
                                subscribers_net_latest_day, subscribers_7d, subscribers_28d,
                                revenue_latest_day, revenue_latest_date, revenue_prev_day, revenue_month,
                                revenue_prev_month, revenue_28d, rpm_28d,
                                monetization_status, add_audio_feature,
                                draft_total, draft_audio_ready, draft_no_audio, draft_audio_failed,
                                audio_rejected_count, audio_processing_videos, audio_reject_pending,
                                copyright_strikes, copyright_claims, copyright_draft, copyright_scheduled, copyright_public,
                                scheduled_count, schedule_days_left, schedule_level,
                                scheduled_with_audio, scheduled_no_audio, scheduled_audio_failed,
                                schedule_next_epoch, scheduled_until_epoch, schedule_gap_count, schedule_gap_dates_json, schedule_active_days,
                                ads_off_total, video_language_set, video_language_name,
                                feature_tiers_json, sampled_at, updated_at
                            ) VALUES (?,?,?,?,?, ?,?, ?,?,?,?,?,?, ?,?,?,?, ?,?,?, ?,?,?,?, ?,?,?, ?,?, ?,?,?,?, ?,?,?, ?,?,?,?,?, ?,?,?, ?,?,?, ?,?,?,?,?, ?,?,?, ?,?,?)
                            ON CONFLICT(youtube_channel_id) DO UPDATE SET
                                t3_channel_id=excluded.t3_channel_id,
                                account_email=CASE WHEN excluded.account_email!='' THEN excluded.account_email ELSE channels.account_email END,
                                title=CASE WHEN excluded.title!='' THEN excluded.title ELSE channels.title END,
                                avatar_url=CASE WHEN excluded.avatar_url!='' THEN excluded.avatar_url ELSE channels.avatar_url END,
                                session_status=excluded.session_status,
                                studio_session_status=excluded.studio_session_status,
                                subscriber_count=excluded.subscriber_count,
                                video_count=excluded.video_count,
                                view_count=excluded.view_count,
                                views_48h=excluded.views_48h,
                                views_60m=excluded.views_60m,
                                views_24h=excluded.views_24h,
                                views_24h_change_pct=excluded.views_24h_change_pct,
                                views_7d=excluded.views_7d,
                                views_28d=excluded.views_28d,
                                views_48h_series_json=excluded.views_48h_series_json,
                                subscribers_net_latest_day=excluded.subscribers_net_latest_day,
                                subscribers_7d=excluded.subscribers_7d,
                                subscribers_28d=excluded.subscribers_28d,
                                revenue_latest_day=excluded.revenue_latest_day,
                                revenue_latest_date=excluded.revenue_latest_date,
                                revenue_prev_day=excluded.revenue_prev_day,
                                revenue_month=excluded.revenue_month,
                                revenue_prev_month=excluded.revenue_prev_month,
                                revenue_28d=excluded.revenue_28d,
                                rpm_28d=excluded.rpm_28d,
                                monetization_status=excluded.monetization_status,
                                add_audio_feature=excluded.add_audio_feature,
                                draft_total=excluded.draft_total,
                                draft_audio_ready=excluded.draft_audio_ready,
                                draft_no_audio=excluded.draft_no_audio,
                                draft_audio_failed=excluded.draft_audio_failed,
                                audio_rejected_count=excluded.audio_rejected_count,
                                audio_processing_videos=excluded.audio_processing_videos,
                                audio_reject_pending=excluded.audio_reject_pending,
                                copyright_strikes=excluded.copyright_strikes,
                                copyright_claims=excluded.copyright_claims,
                                copyright_draft=excluded.copyright_draft,
                                copyright_scheduled=excluded.copyright_scheduled,
                                copyright_public=excluded.copyright_public,
                                scheduled_count=excluded.scheduled_count,
                                schedule_days_left=excluded.schedule_days_left,
                                schedule_level=excluded.schedule_level,
                                scheduled_with_audio=excluded.scheduled_with_audio,
                                scheduled_no_audio=excluded.scheduled_no_audio,
                                scheduled_audio_failed=excluded.scheduled_audio_failed,
                                schedule_next_epoch=excluded.schedule_next_epoch,
                                scheduled_until_epoch=excluded.scheduled_until_epoch,
                                schedule_gap_count=excluded.schedule_gap_count,
                                schedule_gap_dates_json=excluded.schedule_gap_dates_json,
                                schedule_active_days=excluded.schedule_active_days,
                                ads_off_total=excluded.ads_off_total,
                                video_language_set=excluded.video_language_set,
                                video_language_name=excluded.video_language_name,
                                feature_tiers_json=excluded.feature_tiers_json,
                                sampled_at=excluded.sampled_at,
                                updated_at=excluded.updated_at
                        """, (
                            int(it.get("channel_id") or 0),
                            str(it.get("account_email") or ""),
                            uc,
                            str(it.get("title") or uc),
                            str(it.get("avatar_url") or ""),
                            str(it.get("session_status") or "OK"),
                            str(it.get("studio_session_status") or "PINNED"),
                            int(it.get("subscriber_count") or 0),
                            int(it.get("video_count") or 0),
                            int(it.get("total_views") or 0),
                            int(it.get("views_48h") or 0),
                            int(it.get("views_60m") or 0),
                            int(it.get("views_24h") or 0),
                            it.get("views_24h_change_pct"),
                            int(it.get("views_7d") or 0),
                            int(it.get("views_28d") or 0),
                            json.dumps(it.get("views_48h_series") or []),
                            it.get("subscribers_net_latest_day"),
                            it.get("subscribers_7d"),
                            it.get("subscribers_28d"),
                            it.get("revenue_latest_day"),
                            str(it.get("revenue_latest_date") or ""),
                            it.get("revenue_prev_day"),
                            float(it.get("revenue_month") or 0.0),
                            it.get("revenue_prev_month"),
                            float(it.get("revenue_28d") or 0.0),
                            it.get("rpm_28d"),
                            str(it.get("monetization_status") or "UNKNOWN"),
                            add_feat,
                            int(it.get("draft_total") or 0),
                            int(it.get("draft_with_audio") or it.get("draft_audio_ready") or 0),
                            int(it.get("draft_no_audio") or 0),
                            int(it.get("draft_audio_failed") or 0),
                            int(it.get("audio_reject_confirmed") or it.get("audio_reject_candidates") or 0),
                            int(it.get("audio_processing_videos") or 0),
                            int(it.get("audio_reject_pending") or 0),
                            int(it.get("copyright_strikes") or 0),
                            int(it.get("copyright_total") or 0),
                            int(it.get("copyright_draft") or 0),
                            int(it.get("copyright_scheduled") or 0),
                            int(it.get("copyright_public") or 0),
                            int(it.get("scheduled_count") or 0),
                            sl_days,
                            sl_lvl,
                            int(it.get("scheduled_with_audio") or 0),
                            int(it.get("scheduled_no_audio") or 0),
                            int(it.get("scheduled_audio_failed") or 0),
                            int(it.get("schedule_next_epoch") or 0),
                            int(it.get("scheduled_until_epoch") or 0),
                            int(it.get("schedule_gap_count") or 0),
                            json.dumps(it.get("schedule_gap_dates") or []),
                            int(it.get("schedule_active_days") or 0),
                            int(it.get("ads_off_total") or 0),
                            1 if it.get("video_language_set", True) else 0,
                            str(it.get("video_language_name") or ""),
                            str(it.get("feature_tiers_json") or "{}"),
                            str(it.get("sampled_at") or _now_iso()),
                            _now_iso(),
                        ))
                        stats["monitor"] += 1
            except Exception:
                pass

            # Đồng bộ liên kết account_id & channel_count
            email_to_acc_id = {
                row["email"]: row["id"]
                for row in con.execute("SELECT id, email FROM accounts").fetchall()
            }
            for email, aid in email_to_acc_id.items():
                con.execute("UPDATE channels SET account_id=? WHERE account_email=?", (aid, email))
                cnt = con.execute("SELECT COUNT(*) FROM channels WHERE account_id=? OR account_email=?", (aid, email)).fetchone()[0]
                con.execute("UPDATE accounts SET channel_count=? WHERE id=?", (cnt, aid))

            # Cập nhật số lượng audio_rejected_count cho từng kênh (nếu chưa có từ live snapshot)
            con.execute("""
                UPDATE channels SET audio_rejected_count = MAX(
                    audio_rejected_count,
                    (
                        SELECT COUNT(*) FROM audio_repair_items
                        WHERE audio_repair_items.channel_id = channels.id
                           OR audio_repair_items.channel_title = channels.title
                    )
                )
            """)
            con.commit()
        finally:
            con.close()
    return stats


# ==============================================================================
# 4. QUÉT KÊNH QUA HTTP INNERTUBE & FFmpeg AUDIO REPAIR ENGINE
# ==============================================================================

def _parse_netscape_cookies(cookie_text_or_path: str) -> dict[str, str]:
    cookies = {}
    raw = str(cookie_text_or_path or "").strip()
    if not raw:
        return cookies
    p = Path(raw)
    if p.is_file():
        try:
            raw = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return cookies
    # Hỗ trợ cả JSON format và Netscape format — LUÔN ưu tiên domain youtube.com hơn .google.com
    # vì .google.com và .youtube.com có SID / __Secure-1PSIDTS khác nhau!
    if raw.startswith("[") or raw.startswith("{"):
        try:
            obj = json.loads(raw)
            rows = obj if isinstance(obj, list) else (obj.get("cookies") or [])
            other_ck = {}
            yt_ck = {}
            studio_ck = {}
            for c in rows:
                if not isinstance(c, dict) or not c.get("name"):
                    continue
                nm = str(c["name"])
                val = str(c.get("value") or "")
                dom = str(c.get("domain") or "").lower()
                if "studio.youtube.com" in dom:
                    studio_ck[nm] = val
                elif "youtube.com" in dom or not dom:
                    yt_ck[nm] = val
                else:
                    other_ck[nm] = val
            cookies.update(other_ck)
            cookies.update(yt_ck)
            cookies.update(studio_ck)
            return cookies
        except Exception:
            pass
    other_ck = {}
    yt_ck = {}
    studio_ck = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            dom = parts[0].strip().lower()
            nm = parts[5].strip()
            val = parts[6].strip()
            if "studio.youtube.com" in dom:
                studio_ck[nm] = val
            elif "youtube.com" in dom or not dom:
                yt_ck[nm] = val
            else:
                other_ck[nm] = val
    cookies.update(other_ck)
    cookies.update(yt_ck)
    cookies.update(studio_ck)
    return cookies


def _yt_sapisid_headers(cookies: dict[str, str], origin: str = "https://www.youtube.com") -> dict[str, str]:
    sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or ""
    now_sec = int(time.time())
    sapisidhash = hashlib.sha1(f"{now_sec} {sapisid} {origin}".encode("utf-8")).hexdigest()
    return {
        "User-Agent": _UA,
        "Origin": origin,
        "Referer": origin + "/",
        "Cookie": "; ".join(f"{k}={v}" for k, v in cookies.items()),
        "Authorization": f"SAPISIDHASH {now_sec}_{sapisidhash}",
        "X-Origin": origin,
        "Content-Type": "application/json",
    }


def _extract_yt_channel_item(acc_item: dict, headers: dict[str, str], client_ctx: dict) -> dict | None:
    if not isinstance(acc_item, dict):
        return None
    if acc_item.get("hasChannel") is False:
        return None

    name_obj = acc_item.get("accountName") or {}
    title = ""
    if isinstance(name_obj, dict):
        title = name_obj.get("simpleText") or ""
        if not title and isinstance(name_obj.get("runs"), list):
            title = "".join(str(x.get("text") or "") for x in name_obj["runs"])

    h_obj = acc_item.get("channelHandle") or {}
    handle = (h_obj.get("simpleText") or "").strip() if isinstance(h_obj, dict) else ""

    avatar = ""
    thumbs = ((acc_item.get("accountPhoto") or {}).get("thumbnails") or [])
    if thumbs and isinstance(thumbs[-1], dict):
        avatar = str(thumbs[-1].get("url") or "")

    toks = ((acc_item.get("serviceEndpoint") or {}).get("selectActiveIdentityEndpoint") or {}).get("supportedTokens") or []
    ckey = ""
    has_page_id = False
    page_id = ""
    gaia_id = ""
    signin_url = ""
    for t in toks:
        if not isinstance(t, dict):
            continue
        if "pageIdToken" in t and (t["pageIdToken"] or {}).get("pageId"):
            has_page_id = True
            page_id = str((t["pageIdToken"] or {}).get("pageId") or "").strip()
        if "accountStateToken" in t and (t["accountStateToken"] or {}).get("obfuscatedGaiaId"):
            gaia_id = str((t["accountStateToken"] or {}).get("obfuscatedGaiaId") or "").strip()
        if "offlineCacheKeyToken" in t:
            ckey = str((t["offlineCacheKeyToken"] or {}).get("clientCacheKey") or "").strip()
        if "accountSigninToken" in t:
            signin_url = str((t["accountSigninToken"] or {}).get("signinUrl") or "")

    uc = ""
    m = _UC_RE.search(json.dumps(acc_item, ensure_ascii=False))
    if m:
        uc = m.group(1)
    elif re.fullmatch(r"[A-Za-z0-9_-]{22}", ckey):
        uc = "UC" + ckey
    elif handle.startswith("@"):
        try:
            rb = json.dumps({"context": client_ctx, "url": f"https://www.youtube.com/{handle}"}).encode("utf-8")
            req_r = urllib.request.Request(
                f"https://www.youtube.com/youtubei/v1/navigation/resolve_url?key={_YT_WEB_API_KEY}&prettyPrint=false",
                data=rb,
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(req_r, timeout=10) as rr:
                res_r = json.loads(rr.read().decode("utf-8", errors="replace"))
            bid = str((((res_r.get("endpoint") or {}).get("browseEndpoint") or {}).get("browseId")) or "")
            if bid.startswith("UC"):
                uc = bid
        except Exception:
            pass

    if not uc:
        return None
    is_main = (not has_page_id) and ("pageid=" not in signin_url.lower())
    clean_title = html.unescape(title).strip() if title else ""
    return {
        "youtube_channel_id": uc,
        "title": clean_title or uc,
        "handle": handle,
        "avatar_url": avatar,
        "is_main": is_main,
        "page_id": page_id or gaia_id,
    }


def discover_account_channels_http(cookies: dict[str, str]) -> list[dict]:
    """Quét toàn bộ danh sách kênh (Own + Brand + Delegated, có phân trang) qua InnerTube account/accounts_list."""
    sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or ""
    if not sapisid:
        return []

    headers = _yt_sapisid_headers(cookies)
    client_ctx = {
        "client": {
            "clientName": "WEB",
            "clientVersion": "2.20250201.00.00",
            "hl": "vi",
            "gl": "VN",
        }
    }
    url = f"https://www.youtube.com/youtubei/v1/account/accounts_list?key={_YT_WEB_API_KEY}&prettyPrint=false"

    found = []
    seen_uc = set()
    seen_tokens = set()
    continuation_token = None

    for _ in range(25):
        payload = {"context": client_ctx}
        if continuation_token:
            payload["continuation"] = continuation_token
        req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=15) as r:
            data = json.loads(r.read().decode("utf-8", errors="replace"))

        next_token = None

        def _walk(node):
            nonlocal next_token
            if isinstance(node, dict):
                for key in ("accountItem", "accountItemRenderer"):
                    acc_item = node.get(key)
                    if isinstance(acc_item, dict):
                        item = _extract_yt_channel_item(acc_item, headers, client_ctx)
                        if item and item["youtube_channel_id"] not in seen_uc:
                            seen_uc.add(item["youtube_channel_id"])
                            found.append(item)
                cir = node.get("continuationItemRenderer")
                if isinstance(cir, dict) and not next_token:
                    cmd = (
                        ((cir.get("button") or {}).get("buttonRenderer") or {}).get("command")
                        or cir.get("continuationEndpoint")
                        or {}
                    )
                    cc = cmd.get("continuationCommand") or {}
                    tok = str(cc.get("token") or "").strip()
                    if tok and tok not in seen_tokens:
                        next_token = tok
                for v in node.values():
                    _walk(v)
            elif isinstance(node, list):
                for item in node:
                    _walk(item)

        _walk(data)
        if not next_token:
            break
        seen_tokens.add(next_token)
        continuation_token = next_token

    return found


def _track_is_descriptive(trk: dict) -> bool:
    """Phát hiện track âm thanh mô tả (#d) từ phản hồi InnerTube hoặc DB 3TMaster."""
    if not isinstance(trk, dict):
        return False
    if trk.get("isDescriptive") is True:
        return True
    raw_ct = str(
        trk.get("audioContentTypeString")
        or trk.get("contentType")
        or trk.get("content_type")
        or trk.get("trackType")
        or ""
    ).strip().lower()
    if "descriptive" in raw_ct:
        return True
    lg = str(trk.get("language") or "").strip().lower()
    return lg.endswith("#d")


def _canonical_track_lang(lang: str, trk_or_desc: dict | bool = False) -> str:
    """Chuẩn hóa mã ngôn ngữ kèm hậu tố #d khi là Descriptive để không đè Dubbed."""
    s = str(lang or "").strip()
    if not s:
        return ""
    is_desc = bool(s.lower().endswith("#d"))
    base = s.split("#", 1)[0].strip()
    if isinstance(trk_or_desc, dict):
        is_desc = is_desc or _track_is_descriptive(trk_or_desc)
    elif trk_or_desc:
        is_desc = True
    return f"{base}#d" if (base and is_desc) else base


def _parse_cut_segments(raw_cuts) -> list[tuple[float, float]]:
    """Chuyển đổi danh sách các đoạn Copyright CUT (giây hoặc mili-giây) thành [(start_s, end_s), ...]."""
    if isinstance(raw_cuts, str):
        try:
            raw_cuts = json.loads(raw_cuts)
        except Exception:
            return []
    if not isinstance(raw_cuts, list):
        return []
    intervals: list[tuple[float, float]] = []
    for item in raw_cuts:
        if isinstance(item, dict) and isinstance(item.get("segments"), list):
            for seg in item["segments"]:
                if isinstance(seg, dict):
                    s = seg.get("startMs") if "startMs" in seg else (seg.get("start_ms") if "start_ms" in seg else seg.get("start"))
                    e = seg.get("endMs") if "endMs" in seg else (seg.get("end_ms") if "end_ms" in seg else seg.get("end"))
                    try:
                        sf = float(s) / (1000.0 if ("startMs" in seg or "start_ms" in seg or float(s) > 36000) else 1.0)
                        ef = float(e) / (1000.0 if ("endMs" in seg or "end_ms" in seg or float(e) > 36000) else 1.0)
                        if ef > sf >= 0:
                            intervals.append((sf, ef))
                    except Exception:
                        pass
        elif isinstance(item, dict):
            s = item.get("startMs") if "startMs" in item else (item.get("start_ms") if "start_ms" in item else item.get("start"))
            e = item.get("endMs") if "endMs" in item else (item.get("end_ms") if "end_ms" in item else item.get("end"))
            if s is not None and e is not None:
                try:
                    sf = float(s) / (1000.0 if ("startMs" in item or "start_ms" in item or float(s) > 36000) else 1.0)
                    ef = float(e) / (1000.0 if ("endMs" in item or "end_ms" in item or float(e) > 36000) else 1.0)
                    if ef > sf >= 0:
                        intervals.append((sf, ef))
                except Exception:
                    pass
    if not intervals:
        return []
    intervals.sort()
    merged: list[tuple[float, float]] = []
    for st, en in intervals:
        if not merged or st > merged[-1][1] + 0.05:
            merged.append((st, en))
        else:
            merged[-1] = (merged[-1][0], max(merged[-1][1], en))
    return merged


def _prepare_readd_audio_file(
    source_path: str | Path,
    studio_duration: float,
    video_id: str = "",
    mode: str = "all",
    cut_segments=None,
    out_dir: Path = AUDIO_TEMP_DIR,
) -> tuple[str, float, str]:
    """Dựng file audio chuẩn baseline 3TMaster: Cắt Copyright CUT + Tail Trim khớp Studio + hỗ trợ 3s/7s.
    Không bao giờ ghi đè hoặc sửa file gốc (ORIGINAL_SOURCE=UNTOUCHED).
    Trả về (prepared_path, prepared_duration, timeline_note).
    """
    src = Path(source_path)
    if not src.is_file():
        raise FileNotFoundError(f"Không tìm thấy file audio nguồn: {src}")
    out_dir.mkdir(parents=True, exist_ok=True)
    ffmpeg = _find_ffmpeg()
    src_dur = _probe_duration(src)
    target_dur = float(studio_duration or 0.0)
    cuts = _parse_cut_segments(cut_segments)
    vid_tag = re.sub(r"[^a-zA-Z0-9_-]", "_", video_id or src.stem)[:32]
    ts_ms = int(time.time() * 1000)

    is_alt = mode in ("alt_3s_7s", "alternating_pack")
    suffix_tag = "alt3s7s" if is_alt else "renderbaseline"
    out_file = out_dir / f"{vid_tag}_{suffix_tag}_{ts_ms}.m4a"

    # Xây dựng các khoảng giữ lại nếu có Copyright CUT
    keep_filters: list[str] = []
    timeline_note = "DIRECT"
    if cuts and src_dur > 1.0:
        cur = 0.0
        parts: list[str] = []
        idx = 0
        for cs, ce in cuts:
            if cs > cur + 0.05:
                parts.append(f"[0:a]atrim=start={cur:.3f}:end={cs:.3f},asetpts=PTS-STARTPTS[k{idx}]")
                idx += 1
            cur = max(cur, ce)
        if cur < src_dur - 0.05:
            parts.append(f"[0:a]atrim=start={cur:.3f}:end={src_dur:.3f},asetpts=PTS-STARTPTS[k{idx}]")
            idx += 1
        if idx >= 1:
            concat_in = "".join(f"[k{i}]" for i in range(idx))
            post = []
            if is_alt:
                post.append("volume='if(lt(mod(t,10),3),1,0)':eval=frame")
            if target_dur > 1.0:
                post.append("apad")
            post_chain = "," + ",".join(post) if post else ""
            fc = f"{';'.join(parts)};{concat_in}concat=n={idx}:v=0:a=1{post_chain}[outa]"
            cmd = [ffmpeg, "-y", "-i", str(src), "-vn", "-filter_complex", fc, "-map", "[outa]"]
            if target_dur > 1.0:
                cmd.extend(["-t", f"{target_dur:.3f}"])
            cmd.extend(["-c:a", "aac", "-b:a", "192k", str(out_file)])
            cp = subprocess.run(cmd, capture_output=True, text=True, timeout=360, creationflags=_NOWIN)
            if cp.returncode == 0 and out_file.is_file():
                dur = _probe_duration(out_file) or target_dur
                return str(out_file), dur, f"CUT({len(cuts)})+BASELINE"
            keep_filters.clear()

    # Tối ưu tốc độ: nếu file gốc đã là .m4a/.mp4, mode thường và nguồn >= Studio, copy stream -t siêu nhanh
    if (
        not is_alt
        and not cuts
        and src.suffix.lower() in (".m4a", ".mp4", ".aac")
        and target_dur > 1.0
        and src_dur >= target_dur - 0.3
    ):
        cmd_cp = [ffmpeg, "-y", "-i", str(src), "-vn", "-t", f"{target_dur:.3f}", "-c:a", "copy", str(out_file)]
        cp0 = subprocess.run(cmd_cp, capture_output=True, text=True, timeout=180, creationflags=_NOWIN)
        if cp0.returncode == 0 and out_file.is_file() and out_file.stat().st_size > 1024:
            dur = _probe_duration(out_file) or target_dur
            return str(out_file), dur, "RENDER_TAIL_TRIM(COPY)"

    af_filters: list[str] = []
    if is_alt:
        af_filters.append("volume='if(lt(mod(t,10),3),1,0)':eval=frame")
    if target_dur > 1.0:
        af_filters.append("apad")

    cmd = [ffmpeg, "-y", "-i", str(src), "-vn"]
    if af_filters:
        cmd.extend(["-af", ",".join(af_filters)])
    if target_dur > 1.0:
        cmd.extend(["-t", f"{target_dur:.3f}"])
    cmd.extend(["-c:a", "aac", "-b:a", "192k", str(out_file)])

    cp = subprocess.run(cmd, capture_output=True, text=True, timeout=360, creationflags=_NOWIN)
    if cp.returncode != 0 or not out_file.is_file():
        raise RuntimeError(f"FFmpeg lỗi khi chuẩn bị audio: {(cp.stderr or '')[-300:]}")
    dur = _probe_duration(out_file) or target_dur or src_dur
    if is_alt:
        timeline_note = "ALT_3S_7S"
    elif target_dur > 1.0 and src_dur > target_dur + 0.5:
        timeline_note = "RENDER_TAIL_TRIM"
    return str(out_file), dur, timeline_note


def render_aligned_audio_ffmpeg(
    source_path: str | Path,
    target_duration: float,
    mode: str = "all",
    out_dir: Path = AUDIO_TEMP_DIR,
) -> tuple[str, float]:
    """Căn chỉnh thời lượng file audio bằng FFmpeg (Trim đuôi / bù khoảng lặng / chế độ 3s âm + 7s lặng)."""
    out_path, dur, _ = _prepare_readd_audio_file(
        source_path=source_path,
        studio_duration=target_duration,
        mode=mode,
        out_dir=out_dir,
    )
    return out_path, dur


# ==============================================================================
# 5. LỚP FEATURE CHÍNH TRONG MYINGGO
# ==============================================================================

_CM_SCHED_GEN = 0


class YTStudioHub(Feature):
    title = "Studio Manager"
    order = 12

    def __init__(self, start_scheduler: bool = True):
        global _CM_SCHED_GEN
        super().__init__()
        self._cfg_lock = threading.RLock()
        self._lock = threading.RLock()
        self._hitmakers_token_cache: dict[tuple[str, str], tuple[str, float]] = {}
        self._ar_grst_cache: dict[str, tuple[str, float]] = {}
        self._initial_synced = False
        self._ar_stop = threading.Event()
        self._ar_running = False
        self._ar_run_gen = 0
        self._cm_running = False
        self._cm_stop = threading.Event()
        self._cm_auto_wake = threading.Event()
        self._cm_last_scan_ts = 0.0
        self._cm_last_scan_at = ""
        self._cm_next_auto_ts = 0.0
        self._cm_next_auto_at = ""
        self._cm_last_auto_err = ""
        self._cp_running = False
        self._cp_stop = threading.Event()
        self._cp_status = {
            "running": False,
            "total": 0,
            "done": 0,
            "ok": 0,
            "skip": 0,
            "fail": 0,
            "current": "",
            "dry_run": False,
            "logs": [],
        }
        self._cm_run_state = {"running": False, "done": 0, "total": 0, "workers": 6, "current": "", "active": []}
        if start_scheduler:
            _CM_SCHED_GEN += 1
        self._cm_sched_gen = _CM_SCHED_GEN
        self._ar_scan_status = {"running": False, "done": 0, "total": 0, "found": 0, "message": "Chưa quét"}
        self._ar_run_status = {
            "running": False, "phase": "idle", "stage": "Sẵn sàng",
            "percent": 0, "total": 0, "done": 0, "success": 0, "failed": 0,
            "message": "Chưa có tác vụ.", "active": {},
        }
        _init_db()
        self._reset_stuck_ar_items()
        self._try_initial_sync()
        if start_scheduler:
            self._start_cm_auto_scheduler()

    def _reset_stuck_ar_items(self) -> int:
        """Reset các item bị kẹt ở trạng thái đang xử lý trung gian về lại READY/CANDIDATE."""
        try:
            with _DB_LOCK:
                con = _db_conn()
                try:
                    cur = con.execute(
                        """
                        UPDATE audio_repair_items
                        SET status = CASE WHEN COALESCE(source_path, '') != '' THEN 'READY' ELSE 'CANDIDATE' END,
                            progress = 0,
                            stage = 'Đã dừng • Sẵn sàng chạy lại'
                        WHERE status IN ('RUNNING', 'RESOLVING', 'VERIFYING_STUDIO', 'PREPARING_AUDIO', 'UPLOADING', 'DELETING_OLD_AUDIO', 'ADDING')
                        """
                    )
                    con.commit()
                    return int(cur.rowcount or 0)
                finally:
                    con.close()
        except Exception:
            return 0

    def _load_cfg(self) -> dict:
        with self._cfg_lock:
            cfg = dict(DEFAULT_CONFIG)
            if HUB_CFG.is_file():
                try:
                    saved = json.loads(HUB_CFG.read_text(encoding="utf-8"))
                    if isinstance(saved, dict):
                        cfg.update(saved)
                        if isinstance(saved.get("cm_auto_ops"), dict):
                            ops = dict(DEFAULT_CONFIG["cm_auto_ops"])
                            ops.update(saved["cm_auto_ops"])
                            cfg["cm_auto_ops"] = ops
                except Exception:
                    pass
            return cfg

    def _save_cfg(self, patch: dict) -> dict:
        with self._cfg_lock:
            cfg = self._load_cfg()
            for k, v in (patch or {}).items():
                if k == "cm_auto_ops" and isinstance(v, dict):
                    ops = dict(cfg.get("cm_auto_ops") or DEFAULT_CONFIG["cm_auto_ops"])
                    ops.update(v)
                    cfg["cm_auto_ops"] = ops
                elif k == "ar_hitmakers_pass":
                    if v:
                        cfg["ar_hitmakers_pass_dpapi"] = dpapi_protect(str(v))
                else:
                    cfg[k] = v
            HUB_CFG.parent.mkdir(parents=True, exist_ok=True)
            HUB_CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            return cfg

    def _try_initial_sync(self):
        if self._initial_synced:
            return
        self._initial_synced = True
        try:
            cfg = self._load_cfg()
            with _DB_LOCK:
                con = _db_conn()
                try:
                    self._seed_standalone_audio_repair_knowledge(con, cfg=cfg)
                    ch_count = con.execute("SELECT COUNT(*) FROM channels").fetchone()[0]
                    con.commit()
                finally:
                    con.close()
            if ch_count == 0 and not self._is_standalone(cfg):
                t3 = _find_3t_root(cfg)
                if t3:
                    sync_from_3t_sqlite(t3, int(cfg.get("t3_port") or 8891))
        except Exception:
            pass

    def _seed_standalone_audio_repair_knowledge(self, con: sqlite3.Connection, cfg: dict | None = None, force: bool = False) -> dict:
        """Nạp 1 lần toàn bộ tri thức Audio Repair (38 channel_dirs, source_index, roots, local_id, job history)
        vào yt_studio_hub.db để T2MG chạy ĐỘC LẬP 100% mà không phụ thuộc 3TMaster đang mở."""
        stats = {"channel_dirs": 0, "source_index": 0, "items_enriched": 0, "jobs_seeded": 0}
        cur_cfg = cfg if cfg is not None else self._load_cfg()
        if not force and cur_cfg.get("_ar_seeded"):
            try:
                cd_cnt = con.execute("SELECT COUNT(*) FROM audio_repair_channel_dirs").fetchone()[0]
                if cd_cnt > 0:
                    return stats
            except Exception:
                pass

        t3_root = _find_3t_root(cur_cfg)
        if not t3_root:
            # Vẫn kiểm tra Credential Manager để tự điền User/Pass Hitmakers nếu chưa lưu trong T2MG
            patch = {}
            if not cur_cfg.get("ar_hitmakers_user"):
                cu = _win_cred_read("audio-repair:hitmakers:username@HDMaster.GoogleAccounts")
                if cu:
                    patch["ar_hitmakers_user"] = cu
            if not dpapi_unprotect(cur_cfg.get("ar_hitmakers_pass_dpapi") or ""):
                cp = _win_cred_read("audio-repair:hitmakers:password@HDMaster.GoogleAccounts")
                if cp:
                    patch["ar_hitmakers_pass"] = cp
            if patch:
                self._save_cfg(patch)
            return stats

        hd_db = t3_root / "data" / "hd_master.db"
        jobs_db = t3_root / "data" / "audio_repair_jobs.db"
        cfg_patch: dict = {}

        if hd_db.is_file():
            try:
                src = sqlite3.connect(f"file:{hd_db.as_posix()}?mode=ro", uri=True, timeout=5.0)
                src.row_factory = sqlite3.Row
                try:
                    # 1. channel_dirs (38 thư mục kênh)
                    for r in src.execute("SELECT hitmakers_channel_name, crawl_dir, updated_at FROM audio_repair_channel_dirs").fetchall():
                        con.execute(
                            "INSERT OR IGNORE INTO audio_repair_channel_dirs (hitmakers_channel_name, crawl_dir, updated_at) VALUES (?, ?, ?)",
                            (str(r["hitmakers_channel_name"] or ""), str(r["crawl_dir"] or ""), str(r["updated_at"] or _now_iso())),
                        )
                        stats["channel_dirs"] += 1

                    # 2. source_index (445+ ánh xạ local_id -> source_path)
                    for r in src.execute("SELECT local_id, source_path, root_path, hitmakers_channel_name, updated_at FROM audio_repair_source_index").fetchall():
                        con.execute(
                            "INSERT OR IGNORE INTO audio_repair_source_index (local_id, source_path, root_path, hitmakers_channel_name, updated_at) VALUES (?, ?, ?, ?, ?)",
                            (str(r["local_id"] or ""), str(r["source_path"] or ""), str(r["root_path"] or ""), str(r["hitmakers_channel_name"] or ""), str(r["updated_at"] or _now_iso())),
                        )
                        stats["source_index"] += 1

                    # 3. Config roots & Hitmakers user/pass
                    srow = src.execute("SELECT value FROM settings WHERE key='audio_repair_config_v1'").fetchone()
                    if srow and srow["value"]:
                        try:
                            jcfg = json.loads(srow["value"])
                            if not str(cur_cfg.get("ar_source_roots") or "").strip():
                                roots_list = [str(x).strip() for x in (jcfg.get("audio_roots") or []) if str(x).strip()]
                                if roots_list:
                                    cfg_patch["ar_source_roots"] = "\n".join(roots_list)
                            if cur_cfg.get("ar_content_type", "global") == "global" and jcfg.get("add_content_type"):
                                cfg_patch["ar_content_type"] = str(jcfg["add_content_type"])
                            if jcfg.get("hitmakers_base_url") and not cur_cfg.get("ar_hitmakers_url"):
                                cfg_patch["ar_hitmakers_url"] = str(jcfg["hitmakers_base_url"])
                        except Exception:
                            pass

                    # 4. Ngôn ngữ #d + track_details_json từ audio_repair_scan_items
                    for r in src.execute("SELECT studio_video_id, studio_duration, repair_languages_json, track_details_json FROM audio_repair_scan_items").fetchall():
                        vid = str(r["studio_video_id"] or "").strip()
                        if not vid:
                            continue
                        bad_tracks: list[dict] = []
                        good_langs: list[str] = []
                        bad_langs: list[str] = []
                        try:
                            td = json.loads(r["track_details_json"] or "[]")
                            if isinstance(td, list):
                                for t in td:
                                    if not isinstance(t, dict):
                                        continue
                                    st = str(t.get("status") or "").upper()
                                    lg = _canonical_track_lang(t.get("language") or "", t)
                                    tid = str(t.get("audio_track_id") or t.get("audioTrackId") or "").strip()
                                    ct = "AUDIO_TRACK_CONTENT_TYPE_DESCRIPTIVE" if lg.endswith("#d") else "AUDIO_TRACK_CONTENT_TYPE_DUBBED"
                                    if st == "AUDIO_TRACK_STATUS_PROCESSED":
                                        if lg and lg not in good_langs:
                                            good_langs.append(lg)
                                    elif st in ("AUDIO_TRACK_STATUS_REJECTED", "AUDIO_TRACK_STATUS_FAILED", "AUDIO_TRACK_STATUS_REMOVED"):
                                        if lg and lg not in bad_langs:
                                            bad_langs.append(lg)
                                        bad_tracks.append({"audioTrackId": tid, "language": lg, "contentType": ct, "status": st})
                        except Exception:
                            pass
                        if not bad_langs:
                            try:
                                rl = json.loads(r["repair_languages_json"] or "[]")
                                if isinstance(rl, list):
                                    bad_langs = [str(x).strip() for x in rl if str(x).strip()]
                            except Exception:
                                pass
                        if bad_langs or bad_tracks:
                            con.execute(
                                """UPDATE audio_repair_items
                                   SET repair_languages=CASE WHEN ?!='' THEN ? ELSE repair_languages END,
                                       bad_tracks_json=CASE WHEN ?!='' AND bad_tracks_json IN ('','[]','{}') THEN ? ELSE bad_tracks_json END,
                                       good_langs_json=CASE WHEN ?!='' AND good_langs_json IN ('','[]','{}') THEN ? ELSE good_langs_json END,
                                       studio_duration=CASE WHEN studio_duration<=0 AND ?>0 THEN ? ELSE studio_duration END
                                   WHERE studio_video_id=?""",
                                (
                                    ", ".join(bad_langs), ", ".join(bad_langs),
                                    json.dumps(bad_tracks, ensure_ascii=False) if bad_tracks else "",
                                    json.dumps(bad_tracks, ensure_ascii=False),
                                    json.dumps(good_langs, ensure_ascii=False) if good_langs else "",
                                    json.dumps(good_langs, ensure_ascii=False),
                                    float(r["studio_duration"] or 0.0), float(r["studio_duration"] or 0.0),
                                    vid,
                                ),
                            )

                    # 5. Lịch sử Copyright CUT từ central_monitor_cut_events
                    try:
                        cut_map: dict[str, list[dict]] = {}
                        for cr in src.execute("SELECT video_id, segments_json, removed_ms, submitted_at FROM central_monitor_cut_events").fetchall():
                            vid = str(cr["video_id"] or "").strip()
                            if not vid:
                                continue
                            try:
                                segs = json.loads(cr["segments_json"] or "[]")
                            except Exception:
                                segs = []
                            cut_map.setdefault(vid, []).append({
                                "segments": segs,
                                "removed_ms": int(cr["removed_ms"] or 0),
                                "submitted_at": str(cr["submitted_at"] or ""),
                            })
                        for vid, evs in cut_map.items():
                            rem_s = round(sum(float(e.get("removed_ms") or 0) for e in evs) / 1000.0, 3)
                            con.execute(
                                """UPDATE audio_repair_items
                                   SET cut_history_json=?, cut_event_count=?, cut_removed_seconds=?
                                   WHERE studio_video_id=? AND COALESCE(cut_event_count,0)=0""",
                                (json.dumps(evs, ensure_ascii=False), len(evs), rem_s, vid),
                            )
                    except Exception:
                        pass
                finally:
                    src.close()
            except Exception:
                pass

        if jobs_db.is_file():
            try:
                src2 = sqlite3.connect(f"file:{jobs_db.as_posix()}?mode=ro", uri=True, timeout=5.0)
                src2.row_factory = sqlite3.Row
                try:
                    existing_job_vids = {
                        (str(r[0]), str(r[1]))
                        for r in con.execute("SELECT studio_video_id, updated_at FROM audio_repair_jobs").fetchall()
                    }
                    rows = src2.execute("SELECT * FROM audio_repair_jobs ORDER BY id DESC").fetchall()
                    seen_item_vid: set[str] = set()
                    for jr in rows:
                        jd = dict(jr)
                        vid = str(jd.get("studio_video_id") or "").strip()
                        if not vid:
                            continue
                        loc_id = str(jd.get("hitmakers_local_id") or "").strip()
                        spath = str(jd.get("source_path") or "").strip()
                        hch = str(jd.get("hitmakers_channel_name") or "").strip()
                        hhint = str(jd.get("hitmakers_path_hint") or "").strip()
                        hdur = float(jd.get("hitmakers_duration") or 0.0)
                        sdur = float(jd.get("source_duration") or 0.0)
                        st = str(jd.get("status") or "").upper()
                        att = int(jd.get("attempt") or 0)
                        upd = str(jd.get("updated_at") or _now_iso())

                        if loc_id and spath:
                            con.execute(
                                "INSERT OR IGNORE INTO audio_repair_source_index (local_id, source_path, root_path, hitmakers_channel_name, updated_at) VALUES (?, ?, '', ?, ?)",
                                (loc_id, spath, hch, upd),
                            )

                        if vid not in seen_item_vid:
                            seen_item_vid.add(vid)
                            is_ready_file = bool(spath and os.path.isfile(spath))
                            cur = con.execute(
                                """UPDATE audio_repair_items
                                   SET hitmakers_local_id=CASE WHEN hitmakers_local_id='' AND ?!='' THEN ? ELSE hitmakers_local_id END,
                                       hitmakers_channel_name=CASE WHEN COALESCE(hitmakers_channel_name,'')='' AND ?!='' THEN ? ELSE COALESCE(hitmakers_channel_name,'') END,
                                       hitmakers_path_hint=CASE WHEN COALESCE(hitmakers_path_hint,'')='' AND ?!='' THEN ? ELSE COALESCE(hitmakers_path_hint,'') END,
                                       hitmakers_duration=CASE WHEN COALESCE(hitmakers_duration,0)<=0 AND ?>0 THEN ? ELSE COALESCE(hitmakers_duration,0) END,
                                       source_path=CASE WHEN source_path='' AND ? THEN ? ELSE source_path END,
                                       source_duration=CASE WHEN COALESCE(source_duration,0)<=0 AND ?>0 THEN ? ELSE COALESCE(source_duration,0) END,
                                       cut_history_json=CASE WHEN COALESCE(cut_history_json,'') IN ('','[]') AND ?!='' THEN ? ELSE cut_history_json END,
                                       cut_event_count=CASE WHEN COALESCE(cut_event_count,0)=0 AND ?>0 THEN ? ELSE cut_event_count END,
                                       cut_removed_seconds=CASE WHEN COALESCE(cut_removed_seconds,0)<=0 AND ?>0 THEN ? ELSE cut_removed_seconds END,
                                       readd_attempts=MAX(COALESCE(readd_attempts,0), ?),
                                       status=CASE WHEN status IN ('CANDIDATE','NEW') AND ? THEN 'READY' ELSE status END,
                                       stage=CASE WHEN status IN ('CANDIDATE','NEW') AND ? THEN 'Đã Resolve nguồn' ELSE stage END
                                   WHERE studio_video_id=?""",
                                (
                                    loc_id, loc_id,
                                    hch, hch,
                                    hhint, hhint,
                                    hdur, hdur,
                                    is_ready_file, spath,
                                    sdur, sdur,
                                    str(jd.get("cut_history_json") or ""), str(jd.get("cut_history_json") or "[]"),
                                    int(jd.get("cut_event_count") or 0), int(jd.get("cut_event_count") or 0),
                                    float(jd.get("cut_removed_seconds") or 0.0), float(jd.get("cut_removed_seconds") or 0.0),
                                    att,
                                    is_ready_file,
                                    is_ready_file,
                                    vid,
                                ),
                            )
                            stats["items_enriched"] += cur.rowcount

                        if st in ("SUBMITTED_WAIT", "SUBMITTED", "DONE") and (vid, upd) not in existing_job_vids:
                            existing_job_vids.add((vid, upd))
                            con.execute(
                                """INSERT INTO audio_repair_jobs (
                                    channel_id, channel_title, studio_video_id, video_title, video_kind,
                                    hitmakers_local_id, hitmakers_channel_name, hitmakers_path_hint,
                                    hitmakers_duration, studio_duration, source_path, source_duration,
                                    prepared_path, prepared_duration, cut_removed_seconds,
                                    languages_json, mode, content_type, deleted_track_count,
                                    attempt, status, progress, stage, readd_check_status, error, created_at, updated_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'all', 'both', ?, ?, ?, 100, ?, 'OK', ?, ?, ?)""",
                                (
                                    int(jd.get("channel_id") or 0),
                                    str(jd.get("channel_title") or ""),
                                    vid,
                                    str(jd.get("video_title") or vid),
                                    str(jd.get("video_kind") or "public"),
                                    loc_id,
                                    hch,
                                    hhint,
                                    hdur,
                                    float(jd.get("studio_duration") or 0.0),
                                    spath,
                                    sdur,
                                    str(jd.get("prepared_path") or ""),
                                    float(jd.get("prepared_duration") or 0.0),
                                    float(jd.get("cut_removed_seconds") or 0.0),
                                    str(jd.get("languages_json") or "[]"),
                                    int(jd.get("deleted_track_count") or 0),
                                    att or 1,
                                    st,
                                    str(jd.get("stage") or "Đã submit • chờ xử lý"),
                                    str(jd.get("error") or ""),
                                    str(jd.get("created_at") or upd),
                                    upd,
                                ),
                            )
                            stats["jobs_seeded"] += 1
                finally:
                    src2.close()
            except Exception:
                pass

        if not cur_cfg.get("ar_hitmakers_user"):
            cu = _win_cred_read("audio-repair:hitmakers:username@HDMaster.GoogleAccounts")
            if cu:
                cfg_patch["ar_hitmakers_user"] = cu
        if not dpapi_unprotect(cur_cfg.get("ar_hitmakers_pass_dpapi") or ""):
            cp = _win_cred_read("audio-repair:hitmakers:password@HDMaster.GoogleAccounts")
            if cp:
                cfg_patch["ar_hitmakers_pass"] = cp
        cfg_patch["_ar_seeded"] = True
        if cfg_patch:
            self._save_cfg(cfg_patch)
        return stats

    # ------------------------------------------------------------------
    # TRẠNG THÁI TỔNG HỢP (SNAPSHOT CHO CẢ 4 TAB)
    # ------------------------------------------------------------------
    def act_snapshot(self, data):
        cfg = self._load_cfg()
        standalone = bool(cfg.get("cm_standalone", True) or cfg.get("bridge_mode") == "standalone")
        t3_root = None if standalone else _find_3t_root(cfg)
        t3_live = {"alive": False, "version": "", "locked": False} if standalone else _check_t3_live(int(cfg.get("t3_port") or 8891))

        with _DB_LOCK:
            con = _db_conn()
            try:
                accs = []
                for r in con.execute("SELECT * FROM accounts ORDER BY id ASC").fetchall():
                    d = dict(r)
                    pw_plain = dpapi_unprotect(d.get("password_enc") or "")
                    tfa_plain = dpapi_unprotect(d.get("tfa_secret_enc") or "")
                    otp_info = totp_now(tfa_plain) if tfa_plain else {"code": "", "remaining": 30, "valid": False}
                    accs.append({
                        "id": d["id"],
                        "email": d["email"],
                        "name": d.get("name") or d["email"],
                        "has_password": bool(pw_plain),
                        "password": pw_plain if data.get("reveal_secrets") else ("••••••••" if pw_plain else ""),
                        "has_tfa": bool(tfa_plain),
                        "tfa_secret": tfa_plain if data.get("reveal_secrets") else ("••••••••" if tfa_plain else ""),
                        "otp_code": otp_info["code"],
                        "otp_remaining": otp_info["remaining"],
                        "recovery_email": d.get("recovery_email") or "",
                        "recovery_phone": d.get("recovery_phone") or "",
                        "profile_dir": d.get("profile_dir") or "",
                        "cookie_path": d.get("cookie_path") or "",
                        "enabled": bool(d.get("enabled", 1)),
                        "session_status": d.get("session_status") or "READY",
                        "session_message": d.get("session_message") or "",
                        "channel_count": int(d.get("channel_count") or 0),
                        "note": d.get("note") or "",
                        "label": d.get("label") or "",
                        "only_channels": d.get("only_channels") or "",
                        "include_main_channel": bool(d.get("include_main_channel", 0)),
                        "updated_at": d.get("updated_at") or "",
                    })

                # Tự động đồng bộ audio_repair_items & số liệu kênh từ channel_videos nếu bảng AR đang trống hoặc bị reset về 0
                try:
                    ar_cnt = int(con.execute("SELECT COUNT(*) FROM audio_repair_items").fetchone()[0] or 0)
                    rej_sum = int(con.execute("SELECT COALESCE(SUM(audio_rejected_count), 0) FROM channels").fetchone()[0] or 0)
                    cv_broken_cnt = int(con.execute(
                        "SELECT COUNT(*) FROM channel_videos WHERE audio_state IN ('rejected', 'failed', 'failed_rejected')"
                    ).fetchone()[0] or 0)
                    if cv_broken_cnt > 0 and (ar_cnt == 0 or rej_sum == 0):
                        self._sync_audio_repair_from_channel_videos(con)
                        con.commit()
                except Exception:
                    pass

                channels = [dict(r) for r in con.execute("SELECT * FROM channels ORDER BY title COLLATE NOCASE ASC").fetchall()]
                daily_by_cid = {}
                try:
                    tz_pst = timezone(timedelta(hours=-8))
                    today_pst = datetime.now(tz_pst).date()
                    today_pst_iso = today_pst.isoformat()
                    cutoff_start = (today_pst - timedelta(days=28)).isoformat()
                    for dr in con.execute(
                        "SELECT channel_id, day, views, revenue FROM channel_monitor_daily WHERE day >= ? AND day < ? ORDER BY day ASC",
                        (cutoff_start, today_pst_iso),
                    ).fetchall():
                        daily_by_cid.setdefault(int(dr["channel_id"]), []).append({
                            "date": str(dr["day"]),
                            "views": dr["views"],
                            "revenue": dr["revenue"],
                        })
                except Exception:
                    pass
                vid_alert_by_cid = {}
                try:
                    for vr in con.execute("""
                        SELECT channel_id,
                               SUM(CASE WHEN COALESCE(copyright_state, '') != ''
                                         AND UPPER(COALESCE(copyright_state, '')) != 'NONE'
                                         AND (is_draft = 1 OR COALESCE(scheduled_epoch, 0) > 0 OR UPPER(COALESCE(privacy, '')) = 'VIDEO_PRIVACY_PUBLIC')
                                        THEN 1 ELSE 0 END) AS cp_cnt,
                               SUM(CASE WHEN (is_draft = 1 OR COALESCE(scheduled_epoch, 0) > 0 OR UPPER(COALESCE(privacy, '')) = 'VIDEO_PRIVACY_PUBLIC')
                                         AND UPPER(COALESCE(monetization_state, '')) IN ('INELIGIBLE', 'LIMITED', 'UNMONETIZED', 'DISPUTED', 'MONETIZED_STATUS_LIMITED', 'MONETIZED_STATUS_INELIGIBLE')
                                        THEN 1 ELSE 0 END) AS hard_inelig,
                               SUM(CASE WHEN is_draft = 0
                                         AND (COALESCE(scheduled_epoch, 0) > 0 OR UPPER(COALESCE(privacy, '')) = 'VIDEO_PRIVACY_PUBLIC')
                                         AND (UPPER(COALESCE(monetization_state, '')) IN ('OFF', 'INELIGIBLE', 'LIMITED', 'UNMONETIZED', 'DISPUTED', 'MONETIZED_STATUS_INACTIVE', 'MONETIZED_STATUS_LIMITED', 'MONETIZED_STATUS_INELIGIBLE')
                                              OR (COALESCE(copyright_state, '') != '' AND UPPER(COALESCE(copyright_state, '')) != 'NONE'))
                                        THEN 1 ELSE 0 END) AS on_inelig
                        FROM channel_videos
                        GROUP BY channel_id
                    """).fetchall():
                        vid_alert_by_cid[int(vr["channel_id"])] = {
                            "cp_cnt": int(vr["cp_cnt"] or 0),
                            "hard_inelig": int(vr["hard_inelig"] or 0),
                            "on_inelig": int(vr["on_inelig"] or 0),
                        }
                except Exception:
                    pass
                for c in channels:
                    try:
                        c["views_48h_series"] = json.loads(c.get("views_48h_series_json") or "[]")
                    except Exception:
                        c["views_48h_series"] = []
                    t3_cid = int(c.get("t3_channel_id") or 0)
                    c["daily_series"] = daily_by_cid.get(int(c["id"])) or daily_by_cid.get(t3_cid) or []
                    va = vid_alert_by_cid.get(int(c["id"])) or vid_alert_by_cid.get(t3_cid) or {}
                    m_up = str(c.get("monetization_status") or "").upper()
                    c["copyright_videos_count"] = max(
                        int(va.get("cp_cnt") or 0),
                        int(c.get("copyright_claims") or 0),
                        int(c.get("copyright_draft") or 0) + int(c.get("copyright_scheduled") or 0) + int(c.get("copyright_public") or 0),
                    )
                    c["mon_ineligible_count"] = (
                        int(va.get("on_inelig") or 0) if m_up in ("ON", "ACTIVE", "MONETIZED") else int(va.get("hard_inelig") or 0)
                    )
                    raw_ib = c.get("is_brand")
                    if raw_ib is None or int(raw_ib) < 0:
                        c["is_brand"] = 1 if str(c.get("page_id") or "").strip() else 0
                    else:
                        c["is_brand"] = 1 if int(raw_ib) == 1 else 0
                    c["brand_name"] = str(c.get("brand_name") or "").strip()
                    try:
                        det_obj = json.loads(c.get("detail_json") or "{}")
                    except Exception:
                        det_obj = {}
                    if isinstance(det_obj, dict):
                        c["ai_analysis"] = det_obj.get("ai_analysis") or None
                        if det_obj.get("watch_hours_365d") is not None:
                            c["watch_hours_365d"] = det_obj.get("watch_hours_365d")
                    else:
                        c["ai_analysis"] = None
                ar_items = [dict(r) for r in con.execute("SELECT * FROM audio_repair_items ORDER BY total_views DESC, id DESC LIMIT 10000").fetchall()]
                ar_jobs = [dict(r) for r in con.execute("SELECT * FROM audio_repair_jobs ORDER BY id DESC LIMIT 5000").fetchall()]
            finally:
                con.close()

        # Tính toán KPI cho Channel Monitor
        total_ch = len(channels)
        mon_on = sum(1 for c in channels if str(c.get("monetization_status") or "").upper() in ("ON", "ACTIVE", "MONETIZED"))
        mon_bad = sum(1 for c in channels if str(c.get("monetization_status") or "").upper() in ("DISABLED", "DISABLED_ADSENSE", "REJECTED", "SUSPENDED", "APPEAL_REVIEW"))
        sched_red = sum(1 for c in channels if str(c.get("schedule_level") or "").upper() == "RED" or int(c.get("schedule_days_left") or 0) <= 5)
        sched_yellow = sum(1 for c in channels if str(c.get("schedule_level") or "").upper() == "YELLOW" or (5 < int(c.get("schedule_days_left") or 0) <= 15))
        sched_green = max(0, total_ch - sched_red - sched_yellow)
        total_subs = sum(int(c.get("subscriber_count") or 0) for c in channels)
        total_views = sum(int(c.get("view_count") or 0) for c in channels)
        views_48h = sum(int(c.get("views_48h") or 0) for c in channels)
        views_60m = sum(int(c.get("views_60m") or 0) for c in channels)
        views_7d = sum(int(c.get("views_7d") or 0) for c in channels)
        views_28d = sum(int(c.get("views_28d") or 0) for c in channels)
        rev_day = round(sum(float(c.get("revenue_latest_day") or 0.0) for c in channels), 2)
        rev_month = round(sum(float(c.get("revenue_month") or 0.0) for c in channels), 2)
        rev_prev_month = round(sum(float(c.get("revenue_prev_month") or 0.0) for c in channels), 2)
        rev_28d = round(sum(float(c.get("revenue_28d") or 0.0) for c in channels), 2)
        strikes_total = sum(int(c.get("copyright_strikes") or 0) for c in channels)
        claims_total = sum(int(c.get("copyright_claims") or 0) for c in channels)
        cp_draft = sum(int(c.get("copyright_draft") or 0) for c in channels)
        cp_sched = sum(int(c.get("copyright_scheduled") or 0) for c in channels)
        cp_pub = sum(int(c.get("copyright_public") or 0) for c in channels)
        draft_total = sum(int(c.get("draft_total") or 0) for c in channels)
        draft_no_audio_total = sum(int(c.get("draft_no_audio") or 0) for c in channels)
        scheduled_total = sum(int(c.get("scheduled_count") or 0) for c in channels)
        audio_reject_confirmed = sum(int(c.get("audio_rejected_count") or 0) for c in channels)
        audio_processing_total = sum(int(c.get("audio_processing_videos") or 0) for c in channels)
        audio_err_total = max(audio_reject_confirmed, len(ar_items))
        ads_off_total = sum(int(c.get("ads_off_total") or 0) for c in channels)
        video_language_missing = sum(1 for c in channels if int(c.get("video_language_set") if c.get("video_language_set") is not None else 1) == 0)
        add_audio_enabled = sum(1 for c in channels if str(c.get("add_audio_feature") or "YES").upper() in ("YES", "ENABLED"))
        add_audio_disabled = sum(1 for c in channels if str(c.get("add_audio_feature") or "").upper() in ("NO", "DISABLED"))
        schedule_gap_channels = sum(1 for c in channels if int(c.get("schedule_gap_count") or 0) > 0)

        safe_cfg = dict(cfg)
        if not safe_cfg.get("ar_hitmakers_user"):
            safe_cfg["ar_hitmakers_user"] = _win_cred_read("audio-repair:hitmakers:username@HDMaster.GoogleAccounts")
        has_pw = bool(
            dpapi_unprotect(cfg.get("ar_hitmakers_pass_dpapi") or "")
            or _win_cred_read("audio-repair:hitmakers:password@HDMaster.GoogleAccounts")
        )
        safe_cfg["has_hitmakers_pass"] = has_pw
        safe_cfg.pop("ar_hitmakers_pass_dpapi", None)

        try:
            with _DB_LOCK:
                con_al = _db_conn()
                try:
                    st_cnt = int(con_al.execute("SELECT COUNT(*) FROM channel_alert_state").fetchone()[0] or 0)
                finally:
                    con_al.close()
            if st_cnt == 0 and channels:
                self._evaluate_channel_alerts_from_db(send_tg=True)
        except Exception:
            pass

        return {
            "ok": 1,
            "config": safe_cfg,
            "t3_status": {
                "found_root": str(t3_root) if t3_root else "",
                "live": t3_live.get("alive", False),
                "version": t3_live.get("version", ""),
                "locked": t3_live.get("locked", False),
                "port": int(cfg.get("t3_port") or 8891),
            },
            "accounts": accs,
            "channels": channels,
            "cm_summary": {
                "total_channels": total_ch,
                "enabled_channels": sum(1 for c in channels if int(c.get("enabled") or 0) == 1),
                "mon_on": mon_on,
                "mon_bad": mon_bad,
                "sched_green": sched_green,
                "sched_yellow": sched_yellow,
                "sched_red": sched_red,
                "total_subs": total_subs,
                "total_views": total_views,
                "views_48h": views_48h,
                "views_60m": views_60m,
                "views_7d": views_7d,
                "views_28d": views_28d,
                "rev_day": rev_day,
                "rev_month": rev_month,
                "rev_prev_month": rev_prev_month,
                "rev_28d": rev_28d,
                "strikes_total": strikes_total,
                "claims_total": claims_total,
                "copyright_draft": cp_draft,
                "copyright_scheduled": cp_sched,
                "copyright_public": cp_pub,
                "draft_total": draft_total,
                "draft_no_audio_total": draft_no_audio_total,
                "scheduled_total": scheduled_total,
                "audio_err_total": audio_err_total,
                "audio_reject_confirmed": audio_reject_confirmed,
                "audio_processing_total": audio_processing_total,
                "ads_off_total": ads_off_total,
                "video_language_missing": video_language_missing,
                "add_audio_enabled": add_audio_enabled,
                "add_audio_disabled": add_audio_disabled,
                "schedule_gap_channels": schedule_gap_channels,
            },
            "ar_items": ar_items,
            "ar_jobs": ar_jobs,
            "ar_running": self._ar_running,
            "ar_run": self._ar_run_status,
            "cm_running": self._cm_running,
            "cm_auto": self._get_cm_auto_meta(cfg),
            "copyright_licenses": self._cp_list_licenses(),
            "copyright_disputes": self._cp_list_disputes(limit=250),
            "cp_status": dict(self._cp_status),
            "pending_alerts": self._alert_list(dismissed=0, limit=50),
            "recent_alerts": self._alert_list(dismissed=None, limit=80),
            "logs": self._lines[-100:],
        }

    # ------------------------------------------------------------------
    # PHÂN HỆ 1: QUẢN LÝ TÀI KHOẢN & KÊNH
    # ------------------------------------------------------------------
    def act_save_account(self, data):
        acc_id = int(data.get("id") or 0)
        # Cho phép cập nhật nhanh only_channels / include_main_channel theo acc_id
        if acc_id > 0 and data.get("quick_filter_update"):
            only_ch = str(data.get("only_channels") or "").strip()
            inc_main = 1 if data.get("include_main_channel") else 0
            with _DB_LOCK:
                con = _db_conn()
                try:
                    con.execute(
                        "UPDATE accounts SET only_channels=?, include_main_channel=?, updated_at=? WHERE id=?",
                        (only_ch, inc_main, _now_iso(), acc_id),
                    )
                    con.commit()
                finally:
                    con.close()
            return {"ok": 1, "id": acc_id}

        email = str(data.get("email") or "").strip().lower()
        if not email or "@" not in email:
            return {"error": "Email không hợp lệ (cần có ký tự @)."}
        name = str(data.get("name") or email).strip()
        pw = str(data.get("password") or "").strip()
        tfa = str(data.get("tfa_secret") or "").strip()
        rec_mail = str(data.get("recovery_email") or "").strip()
        rec_phone = str(data.get("recovery_phone") or "").strip()
        note = str(data.get("note") or "").strip()
        label = str(data.get("label") or "").strip()
        only_ch = data.get("only_channels")
        inc_main = data.get("include_main_channel")
        cookie_text = str(data.get("cookie_text") or "").strip()

        prof_dir = str(PROFILES_DIR / re.sub(r"[^a-zA-Z0-9_.-]", "_", email))
        Path(prof_dir).mkdir(parents=True, exist_ok=True)

        cookie_path = ""
        if cookie_text:
            COOKIES_DIR.mkdir(parents=True, exist_ok=True)
            cf = COOKIES_DIR / f"{re.sub(r'[^a-zA-Z0-9_.-]', '_', email)}.txt"
            cf.write_text(cookie_text, encoding="utf-8")
            cookie_path = str(cf)

        with _DB_LOCK:
            con = _db_conn()
            try:
                if acc_id > 0:
                    cur_row = con.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
                else:
                    cur_row = con.execute("SELECT * FROM accounts WHERE email=?", (email,)).fetchone()

                if cur_row:
                    cur_d = dict(cur_row)
                    pw_enc = dpapi_protect(pw) if (pw and pw != "••••••••") else (cur_d.get("password_enc") or "")
                    tfa_enc = dpapi_protect(tfa) if (tfa and tfa != "••••••••") else (cur_d.get("tfa_secret_enc") or "")
                    c_path = cookie_path or cur_d.get("cookie_path") or ""
                    con.execute("""
                        UPDATE accounts SET email=?, name=?, password_enc=?, tfa_secret_enc=?,
                            recovery_email=?, recovery_phone=?, cookie_path=?, note=?, label=?, updated_at=?
                        WHERE id=?
                    """, (email, name, pw_enc, tfa_enc, rec_mail, rec_phone, c_path, note, label, _now_iso(), cur_d["id"]))
                    saved_id = cur_d["id"]
                else:
                    pw_enc = dpapi_protect(pw) if pw and pw != "••••••••" else ""
                    tfa_enc = dpapi_protect(tfa) if tfa and tfa != "••••••••" else ""
                    cur = con.execute("""
                        INSERT INTO accounts (email, name, password_enc, tfa_secret_enc, recovery_email,
                            recovery_phone, profile_dir, cookie_path, enabled, session_status, note, label, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 'READY', ?, ?, ?)
                    """, (email, name, pw_enc, tfa_enc, rec_mail, rec_phone, prof_dir, cookie_path, note, label, _now_iso()))
                    saved_id = cur.lastrowid
                con.commit()
            finally:
                con.close()

        self.log(f"✅ Đã lưu tài khoản Google: {email} (DPAPI Encrypted)")
        return {"ok": 1, "id": saved_id, "email": email}

    def act_bulk_import_accounts(self, data):
        raw = str(data.get("text") or "").strip()
        if not raw:
            return {"error": "Chưa nhập danh sách tài khoản."}
        added, updated, skipped = 0, 0, 0
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = re.split(r"[\t|;]+", line)
            email = (parts[0] if len(parts) > 0 else "").strip().lower()
            if not email or "@" not in email:
                skipped += 1
                continue
            pw = (parts[1] if len(parts) > 1 else "").strip()
            tfa = (parts[2] if len(parts) > 2 else "").strip()
            rec = (parts[3] if len(parts) > 3 else "").strip()
            res = self.act_save_account({
                "email": email,
                "password": pw,
                "tfa_secret": tfa,
                "recovery_email": rec,
            })
            if res.get("ok"):
                added += 1
            else:
                skipped += 1
        self.log(f"📥 Đã nhập hàng loạt {added} tài khoản (bỏ qua {skipped} dòng lỗi).")
        return {"ok": 1, "added": added, "updated": updated, "skipped": skipped}

    def act_delete_account(self, data):
        raw_ids = data.get("account_ids") or []
        ids = [int(x) for x in raw_ids if str(x).isdigit()]
        if not ids and data.get("id"):
            ids = [int(data.get("id"))]
        if not ids:
            return {"ok": 0, "error": "Chưa chọn tài khoản để xóa."}
        placeholders = ",".join("?" for _ in ids)
        deleted_emails = []
        with _DB_LOCK:
            con = _db_conn()
            try:
                rows = con.execute(f"SELECT id, email FROM accounts WHERE id IN ({placeholders})", ids).fetchall()
                deleted_emails = [r["email"] for r in rows if r["email"]]
                con.execute(f"DELETE FROM accounts WHERE id IN ({placeholders})", ids)
                if data.get("delete_channels"):
                    con.execute(f"DELETE FROM channels WHERE account_id IN ({placeholders})", ids)
                    if deleted_emails:
                        e_ph = ",".join("?" for _ in deleted_emails)
                        con.execute(f"DELETE FROM channels WHERE account_email IN ({e_ph})", deleted_emails)
                con.commit()
            finally:
                con.close()
        self.log(f"🗑️ Đã xóa {len(ids)} tài khoản ({', '.join(deleted_emails[:5])}{'...' if len(deleted_emails) > 5 else ''})")
        return {"ok": 1, "deleted": len(ids)}

    def act_get_otp(self, data):
        """Trả mã OTP 6 số trực tiếp cho toàn bộ tài khoản có 2FA."""
        res = {}
        with _DB_LOCK:
            con = _db_conn()
            try:
                for r in con.execute("SELECT id, email, tfa_secret_enc FROM accounts").fetchall():
                    tfa = dpapi_unprotect(r["tfa_secret_enc"] or "")
                    if tfa:
                        res[str(r["id"])] = totp_now(tfa)
            finally:
                con.close()
        return {"ok": 1, "otps": res}

    def act_save_channel(self, data):
        uc = str(data.get("youtube_channel_id") or "").strip()
        if not uc:
            return {"error": "Vui lòng nhập mã Channel ID (bắt đầu bằng UC...)."}
        title = str(data.get("title") or uc).strip()
        email = str(data.get("account_email") or "").strip().lower()
        key_folder = str(data.get("key_folder") or "").strip()
        mon = str(data.get("monetization_status") or "ON").strip().upper()
        sched_days = int(data.get("schedule_days_left") or 15)
        sched_lvl = "GREEN" if sched_days > 15 else ("YELLOW" if sched_days >= 6 else "RED")

        with _DB_LOCK:
            con = _db_conn()
            try:
                acc_row = con.execute("SELECT id FROM accounts WHERE email=?", (email,)).fetchone() if email else None
                acc_id = acc_row["id"] if acc_row else 0
                con.execute("""
                    INSERT INTO channels (
                        account_id, account_email, youtube_channel_id, title, key_folder,
                        monetization_status, schedule_days_left, schedule_level,
                        session_status, studio_session_status, enabled, sampled_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'OK', 'PINNED', 1, ?, ?)
                    ON CONFLICT(youtube_channel_id) DO UPDATE SET
                        title=excluded.title,
                        account_email=CASE WHEN excluded.account_email!='' THEN excluded.account_email ELSE channels.account_email END,
                        key_folder=CASE WHEN excluded.key_folder!='' THEN excluded.key_folder ELSE channels.key_folder END,
                        monetization_status=excluded.monetization_status,
                        schedule_days_left=excluded.schedule_days_left,
                        schedule_level=excluded.schedule_level,
                        updated_at=excluded.updated_at
                """, (acc_id, email, uc, title, key_folder, mon, sched_days, sched_lvl, _now_iso(), _now_iso()))
                if acc_id:
                    cnt = con.execute("SELECT COUNT(*) FROM channels WHERE account_id=? OR account_email=?", (acc_id, email)).fetchone()[0]
                    con.execute("UPDATE accounts SET channel_count=? WHERE id=?", (cnt, acc_id))
                con.commit()
            finally:
                con.close()
        self.log(f"✅ Đã lưu kênh: {title} ({uc})")
        return {"ok": 1}

    def act_channel_action(self, data):
        """Thực hiện thao tác trên 1 hoặc nhiều kênh: toggle_enable, delete, reload_cookie, set_key, open_studio."""
        action = str(data.get("action") or "").strip()
        cids = data.get("channel_ids") or ([data.get("channel_id")] if data.get("channel_id") else [])
        cids = [int(x) for x in cids if str(x).isdigit()]
        if not cids:
            return {"error": "Chưa chọn kênh nào."}

        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)

        with _DB_LOCK:
            con = _db_conn()
            try:
                placeholders = ",".join("?" for _ in cids)
                rows = [dict(r) for r in con.execute(f"SELECT * FROM channels WHERE id IN ({placeholders})", cids).fetchall()]

                if action == "delete":
                    con.execute(f"DELETE FROM channels WHERE id IN ({placeholders})", cids)
                    con.commit()
                    self.log(f"🗑️ Đã xóa {len(cids)} kênh khỏi danh sách.")
                    return {"ok": 1, "deleted": len(cids)}

                if action == "enable":
                    val = 1 if data.get("enabled", True) else 0
                    con.execute(f"UPDATE channels SET enabled=?, updated_at=? WHERE id IN ({placeholders})", [val, _now_iso()] + cids)
                    con.commit()
                    self.log(f"🔄 Đã {'BẬT' if val else 'TẮT'} {len(cids)} kênh.")
                    return {"ok": 1}

                if action == "set_key":
                    key_folder = str(data.get("key_folder") or "").strip()
                    con.execute(f"UPDATE channels SET key_folder=?, updated_at=? WHERE id IN ({placeholders})", [key_folder, _now_iso()] + cids)
                    con.commit()
                    return {"ok": 1}

                if action == "set_brand_name":
                    bname = str(data.get("brand_name") or "").strip()
                    con.execute(f"UPDATE channels SET brand_name=?, updated_at=? WHERE id IN ({placeholders})", [bname, _now_iso()] + cids)
                    con.commit()
                    return {"ok": 1, "brand_name": bname}

                if action == "reload_cookie":
                    for r in rows:
                        # Nếu 3TMaster đang chạy thì gửi lệnh reload-session sang 3TMaster
                        try:
                            _t3_http(port, f"/api/channels/{r['id']}/reload-session", method="POST", payload={})
                        except Exception:
                            pass
                        con.execute(
                            "UPDATE channels SET session_status='OK', studio_session_status='PINNED', session_message='Đã ghim lại phiên (Pinned Session)', updated_at=? WHERE id=?",
                            (_now_iso(), r["id"])
                        )
                    con.commit()
                    self.log(f"🍪 Đã làm mới & ghim lại phiên Cookie cho {len(rows)} kênh.")
                    return {"ok": 1, "reloaded": len(rows)}

                if action == "open_studio":
                    r = rows[0]
                    uc = r["youtube_channel_id"]
                    email = r.get("account_email") or "default"
                    url = f"https://studio.youtube.com/channel/{uc}"
                    self._open_isolated_browser(email, url)
                    self.log(f"🌐 Đang mở YouTube Studio cho kênh: {r['title']} ({uc})")
                    return {"ok": 1, "url": url}
            finally:
                con.close()
        return {"ok": 1}

    @staticmethod
    def _find_native_browser_exe() -> str:
        local_app = os.environ.get("LOCALAPPDATA") or ""
        candidates = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        if local_app:
            candidates.append(str(Path(local_app) / "Google" / "Chrome" / "Application" / "chrome.exe"))
        candidates.extend([
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ])
        for exe in candidates:
            if Path(exe).is_file():
                return exe
        return ""

    @staticmethod
    def _copy_text_to_clipboard(text: str) -> bool:
        val = str(text or "").strip()
        if not val:
            return False
        try:
            import pyperclip
            pyperclip.copy(val)
            return True
        except Exception:
            pass
        if os.name == "nt":
            try:
                subprocess.run(
                    ["clip"],
                    input=val.encode("utf-16le"),
                    check=False,
                    timeout=3,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                return True
            except Exception:
                pass
        return False

    @staticmethod
    def _pick_free_debug_port() -> int:
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            return int(s.getsockname()[1])

    def _open_isolated_browser(self, email_or_key: str, url: str):
        prof_dir = None
        acc_row = None
        if email_or_key:
            try:
                with _DB_LOCK:
                    con = _db_conn()
                    row = con.execute(
                        "SELECT id, email, profile_dir, cookie_path, password_enc, tfa_secret_enc FROM accounts WHERE email=? OR name=? LIMIT 1",
                        (email_or_key.strip().lower(), email_or_key.strip())
                    ).fetchone()
                    con.close()
                    if row:
                        acc_row = dict(row)
                        if row["profile_dir"]:
                            p = Path(row["profile_dir"])
                            if p.is_dir():
                                prof_dir = p
            except Exception:
                pass
        if prof_dir is None:
            safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", email_or_key or "default")
            prof_dir = PROFILES_DIR / safe
            prof_dir.mkdir(parents=True, exist_ok=True)
        exe = self._find_native_browser_exe()
        if not exe:
            return
        email_clean = str((acc_row or {}).get("email") or email_or_key or "").strip().lower()
        safe_email = re.sub(r"[^a-zA-Z0-9_.-]", "_", email_clean or "default")
        cf_json = COOKIES_DIR / f"{safe_email}.json"
        has_saved_cookie = cf_json.is_file() and cf_json.stat().st_size > 50
        target_url = url
        if not has_saved_cookie and url.rstrip("/") == "https://studio.youtube.com" and "@" in email_clean:
            from urllib.parse import quote as _url_quote
            target_url = (
                f"https://accounts.google.com/ServiceLogin?service=youtube"
                f"&continue={_url_quote('https://studio.youtube.com/', safe='')}"
                f"&Email={_url_quote(email_clean, safe='')}"
            )
            # Nếu profile chưa có cookie hợp lệ mà từng bị dính cờ --no-sandbox của Playwright cũ thì dọn sạch để Google không chặn
            self._clean_rejected_profile_state(prof_dir)
            pw_plain = dpapi_unprotect((acc_row or {}).get("password_enc") or "")
            if pw_plain and self._copy_text_to_clipboard(pw_plain):
                self.log(f"📋 Đã tự động copy mật khẩu của {email_clean} vào Clipboard — bấm Ctrl+V ở ô mật khẩu Google!")
        debug_port = self._pick_free_debug_port()
        proc = subprocess.Popen([
            exe,
            f"--user-data-dir={prof_dir}",
            f"--remote-debugging-port={debug_port}",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-blink-features=AutomationControlled",
            target_url,
        ])
        if acc_row and "@" in email_clean:
            tfa_plain = dpapi_unprotect((acc_row or {}).get("tfa_secret_enc") or "")
            threading.Thread(
                target=self._watch_native_browser_and_save_cookies,
                args=(proc, debug_port, email_clean, prof_dir, int(acc_row.get("id") or 0), tfa_plain, False),
                daemon=True,
            ).start()

    @staticmethod
    def _clean_rejected_profile_state(prof_dir: Path):
        """Xóa các file trạng thái/cookie bị đánh dấu từ lần mở Playwright --no-sandbox bị Google từ chối."""
        try:
            default_dir = Path(prof_dir) / "Default"
            for rel in (
                Path("Default") / "Network" / "Cookies",
                Path("Default") / "Network" / "Cookies-journal",
                Path("Default") / "Cookies",
                Path("Default") / "Cookies-journal",
                Path("Default") / "Preferences",
                Path("Local State"),
            ):
                p = Path(prof_dir) / rel
                if p.is_file():
                    try:
                        p.unlink()
                    except Exception:
                        pass
            if default_dir.is_dir():
                for sub in ("Sessions", "Session Storage", "Local Storage", "IndexedDB"):
                    sp = default_dir / sub
                    if sp.is_dir():
                        shutil.rmtree(sp, ignore_errors=True)
        except Exception:
            pass

    def _watch_native_browser_and_save_cookies(
        self,
        proc,
        debug_port: int,
        email: str,
        pdir: Path,
        acc_id: int = 0,
        tfa_plain: str = "",
        auto_close_on_capture: bool = False,
        timeout_sec: int = 240,
    ) -> dict[str, str]:
        """Theo dõi thụ động Chrome thật qua /json/list (không gắn CDP khi đang ở accounts.google.com).
        Ngay khi đăng nhập xong vào YouTube / Studio thì trích xuất cookie và lưu lại.
        """
        safe_email = re.sub(r"[^a-zA-Z0-9_.-]", "_", email or "default")
        COOKIES_DIR.mkdir(parents=True, exist_ok=True)
        cf_json = COOKIES_DIR / f"{safe_email}.json"
        deadline = time.time() + max(30, int(timeout_sec))
        last_otp_copied = ""
        cookies: dict[str, str] = {}

        while time.time() < deadline:
            if proc.poll() is not None:
                break
            tabs = []
            try:
                req = urllib.request.Request(f"http://127.0.0.1:{debug_port}/json/list", headers={"Accept": "application/json"})
                with urllib.request.urlopen(req, timeout=1.5) as r:
                    tabs = json.loads(r.read().decode("utf-8", "replace") or "[]")
            except Exception:
                time.sleep(1.0)
                continue

            page_urls = [
                str(t.get("url") or "")
                for t in (tabs if isinstance(tabs, list) else [])
                if str(t.get("type") or "page") == "page"
            ]
            low_urls = [u.lower() for u in page_urls]

            if tfa_plain and any("/challenge/totp" in u for u in low_urls):
                try:
                    otp_code = str(totp_now(tfa_plain).get("code") or "").strip()
                    if otp_code and otp_code != last_otp_copied:
                        last_otp_copied = otp_code
                        if self._copy_text_to_clipboard(otp_code):
                            self.log(f"🔐 Đã tự động copy mã 2FA ({otp_code}) của {email} vào Clipboard — nhấn Ctrl+V vào ô xác minh!")
                except Exception:
                    pass

            on_google_auth = any("accounts.google.com" in u or "signin" in u for u in low_urls)
            on_yt_logged = any(
                ("studio.youtube.com" in u or "www.youtube.com" in u)
                and "accounts.google.com" not in u
                and "signin" not in u
                for u in low_urls
            )
            if on_yt_logged and not on_google_auth:
                time.sleep(2.5)
                try:
                    from playwright.sync_api import sync_playwright
                    with sync_playwright() as p:
                        browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{debug_port}", timeout=8000)
                        try:
                            if browser.contexts:
                                raw_ck = browser.contexts[0].cookies([
                                    "https://www.youtube.com",
                                    "https://studio.youtube.com",
                                    "https://accounts.google.com",
                                    "https://google.com",
                                ])
                                ck_map = {c["name"]: c["value"] for c in raw_ck if c.get("name")}
                                if ck_map.get("SAPISID") or ck_map.get("__Secure-3PAPISID"):
                                    cookies = ck_map
                                    cf_json.write_text(json.dumps(raw_ck, ensure_ascii=False, indent=2), encoding="utf-8")
                        finally:
                            try:
                                browser.close()
                            except Exception:
                                pass
                except Exception:
                    pass
                if cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID"):
                    if acc_id > 0:
                        try:
                            with _DB_LOCK:
                                con = _db_conn()
                                con.execute(
                                    "UPDATE accounts SET cookie_path=?, session_status='READY', updated_at=? WHERE id=?",
                                    (str(cf_json), _now_iso(), acc_id),
                                )
                                con.commit()
                                con.close()
                        except Exception:
                            pass
                    self.log(f"✅ Đã lưu phiên đăng nhập YouTube Studio cho {email} thành công!")
                    if auto_close_on_capture:
                        try:
                            proc.terminate()
                        except Exception:
                            pass
                    return cookies
            time.sleep(1.2)

        return cookies

    def act_open_account_profile(self, data):
        email = str(data.get("email") or "default").strip()
        url = str(data.get("url") or "https://studio.youtube.com").strip()
        self._open_isolated_browser(email, url)
        self.log(f"🌐 Đã mở Chrome thật cho tài khoản: {email} (không dùng cờ automation để tránh Google chặn)")
        return {"ok": 1}

    def _extract_cookies_via_playwright(
        self, email: str, prof_dir: str, pw_plain: str = "", tfa_plain: str = "", force_refresh: bool = False
    ) -> tuple[dict[str, str], str]:
        """Đọc cookie YouTube từ Profile hoặc mở Chrome thật (không cờ --no-sandbox / --enable-automation) để đăng nhập."""
        cookies: dict[str, str] = {}
        safe_email = re.sub(r"[^a-zA-Z0-9_.-]", "_", email or "default")
        pdir = Path(prof_dir) if prof_dir else (PROFILES_DIR / safe_email)
        pdir.mkdir(parents=True, exist_ok=True)
        COOKIES_DIR.mkdir(parents=True, exist_ok=True)
        cf_json = COOKIES_DIR / f"{safe_email}.json"

        # 1. Nếu không ép làm mới và file cookie JSON đã lưu còn SAPISID thì dùng ngay
        if (not force_refresh) and cf_json.is_file():
            try:
                ck_saved = _parse_netscape_cookies(str(cf_json))
                if ck_saved.get("SAPISID") or ck_saved.get("__Secure-3PAPISID"):
                    return ck_saved, ""
            except Exception:
                pass

        def _read_existing_headless() -> tuple[dict[str, str], list[dict], str]:
            cookie_db_1 = pdir / "Default" / "Network" / "Cookies"
            cookie_db_2 = pdir / "Default" / "Cookies"
            if not cookie_db_1.is_file() and not cookie_db_2.is_file():
                return {}, [], ""
            try:
                from playwright.sync_api import sync_playwright
            except Exception as e:
                return {}, [], f"Thiếu thư viện Playwright ({e})."
            with sync_playwright() as p:
                ctx = None
                try:
                    last_err = ""
                    for kwargs in ({"channel": "chrome"}, {"channel": "msedge"}, {}):
                        try:
                            ctx = p.chromium.launch_persistent_context(
                                str(pdir),
                                headless=True,
                                no_viewport=True,
                                ignore_default_args=["--enable-automation", "--no-sandbox"],
                                args=[
                                    "--no-first-run",
                                    "--no-default-browser-check",
                                    "--disable-blink-features=AutomationControlled",
                                ],
                                **kwargs,
                            )
                            break
                        except Exception as ex:
                            last_err = str(ex)
                    if ctx is None:
                        return {}, [], last_err
                    ck_urls = ["https://www.youtube.com", "https://studio.youtube.com", "https://accounts.google.com", "https://www.google.com"]
                    def _to_yt_map(rows_ck):
                        m = {}
                        for dom_pass in (0, 1, 2):
                            for c in rows_ck:
                                if not isinstance(c, dict) or not c.get("name"):
                                    continue
                                d = str(c.get("domain") or "").lower()
                                prio = 2 if "studio.youtube.com" in d else (1 if "youtube.com" in d else 0)
                                if prio == dom_pass:
                                    m[str(c["name"])] = str(c.get("value") or "")
                        return m
                    raw_ck = ctx.cookies(ck_urls)
                    ck_map = _to_yt_map(raw_ck)
                    need_visit = force_refresh or not (ck_map.get("SAPISID") or ck_map.get("__Secure-3PAPISID"))
                    if need_visit:
                        page = ctx.pages[0] if ctx.pages else ctx.new_page()
                        try:
                            page.goto("https://www.youtube.com/channel_switcher", timeout=15000, wait_until="domcontentloaded")
                            time.sleep(2.0)
                        except Exception:
                            pass
                        raw_ck = ctx.cookies(ck_urls)
                        ck_map = _to_yt_map(raw_ck)
                    return ck_map, raw_ck, ""
                except Exception as e:
                    return {}, [], str(e)
                finally:
                    if ctx:
                        try:
                            ctx.close()
                        except Exception:
                            pass

        # 2. Thử đọc ngầm nếu profile đã từng đăng nhập trước đó
        ck_map, raw_ck, launch_err = _read_existing_headless()
        if ck_map.get("SAPISID") or ck_map.get("__Secure-3PAPISID"):
            try:
                cf_json.write_text(json.dumps(raw_ck, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
            return ck_map, ""

        if launch_err:
            low = launch_err.lower()
            if any(k in low for k in ("already in use", "processsingleton", "exitcode=21")):
                err_msg = "Profile Chrome của Mail này đang mở — hãy hoàn tất đăng nhập trên cửa sổ Chrome đó (hoặc đóng lại) rồi bấm tải lại."
                self.log(f"⚠️ ({email}): {err_msg}")
                return {}, err_msg

        # 3. Profile chưa có phiên đăng nhập -> Mở Chrome THẬT (subprocess.Popen, KHÔNG dùng Playwright/automation flags)
        # để Google tuyệt đối không báo "Couldn't sign you in / --no-sandbox".
        exe = self._find_native_browser_exe()
        if not exe:
            return {}, "Không tìm thấy Google Chrome hoặc Microsoft Edge trên máy để mở đăng nhập."

        self._clean_rejected_profile_state(pdir)
        from urllib.parse import quote as _url_quote
        login_url = (
            f"https://accounts.google.com/ServiceLogin?service=youtube"
            f"&continue={_url_quote('https://studio.youtube.com/', safe='')}"
            f"&Email={_url_quote(email, safe='')}"
        ) if (email and "@" in email) else "https://studio.youtube.com"

        if pw_plain and self._copy_text_to_clipboard(pw_plain):
            self.log(f"📋 Đã copy sẵn mật khẩu của {email} vào Clipboard — nhấn Ctrl+V ở ô mật khẩu Google!")

        debug_port = self._pick_free_debug_port()
        self.log(f"🔐 Mở Chrome thật cho {email}: vui lòng hoàn tất đăng nhập Google/YouTube Studio (tự động nhận phiên ngay khi vào Studio)...")
        try:
            proc = subprocess.Popen([
                exe,
                f"--user-data-dir={pdir}",
                f"--remote-debugging-port={debug_port}",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-blink-features=AutomationControlled",
                login_url,
            ])
        except Exception as e:
            return {}, f"Không mở được Chrome thật: {e}"

        cookies = self._watch_native_browser_and_save_cookies(
            proc,
            debug_port=debug_port,
            email=email,
            pdir=pdir,
            acc_id=0,
            tfa_plain=tfa_plain,
            auto_close_on_capture=True,
            timeout_sec=180,
        )
        if cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID"):
            return cookies, ""

        # Nếu người dùng tự đóng cửa sổ Chrome sau khi vừa đăng nhập xong, đọc lại cookie từ ổ đĩa
        if proc.poll() is not None:
            ck_after, raw_after, _ = _read_existing_headless()
            if ck_after.get("SAPISID") or ck_after.get("__Secure-3PAPISID"):
                try:
                    cf_json.write_text(json.dumps(raw_after, ensure_ascii=False, indent=2), encoding="utf-8")
                except Exception:
                    pass
                return ck_after, ""

        return {}, "Chưa nhận được phiên đăng nhập YouTube Studio. Hãy hoàn tất đăng nhập trên cửa sổ Chrome vừa mở rồi bấm Tải danh sách kênh + phiên."

    def act_load_account_channels(self, data):
        """Tải danh sách kênh + ghim phiên Studio cho 1 tài khoản Mail (hỗ trợ missing_only)."""
        acc_id = int(data.get("account_id") or 0)
        missing_only = bool(data.get("missing_only"))
        if not acc_id:
            return {"ok": 0, "error": "Thiếu account_id."}

        with _DB_LOCK:
            con = _db_conn()
            try:
                acc = con.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
                if not acc:
                    return {"ok": 0, "error": "Không tìm thấy tài khoản."}
                acc_d = dict(acc)
            finally:
                con.close()

        email = str(acc_d.get("email") or "").strip().lower()
        safe_email = re.sub(r"[^a-zA-Z0-9_.-]", "_", email or "default")
        cpath = str(acc_d.get("cookie_path") or "").strip()
        pdir = str(acc_d.get("profile_dir") or "").strip()
        only_raw = str(data.get("only_channels") if data.get("only_channels") is not None else (acc_d.get("only_channels") or "")).strip()
        only_tokens = {t.strip().lower() for t in re.split(r"[,;\r\n]+", only_raw) if t.strip()}
        include_main = bool(data["include_main_channel"]) if "include_main_channel" in data else bool(acc_d.get("include_main_channel"))

        self.log(f"⇩ [{'Tải thiếu' if missing_only else 'Tải danh sách kênh + phiên'}] Bắt đầu cho {email}...")
        cookie_candidates = [cpath] if cpath else []
        for ext in ("json", "txt"):
            cand = str(COOKIES_DIR / f"{safe_email}.{ext}")
            if cand not in cookie_candidates:
                cookie_candidates.append(cand)

        ch_list = []
        cookies = {}
        for cand in cookie_candidates:
            if not cand or not Path(cand).is_file():
                continue
            ck = _parse_netscape_cookies(cand)
            if ck and (ck.get("SAPISID") or ck.get("__Secure-3PAPISID")):
                try:
                    ch_list = discover_account_channels_http(ck)
                except Exception:
                    ch_list = []
                if ch_list:
                    cookies = ck
                    break

        pw_err = ""
        if not ch_list:
            pw_plain = dpapi_unprotect(acc_d.get("password_enc") or "")
            tfa_plain = dpapi_unprotect(acc_d.get("tfa_secret_enc") or "")
            cookies, pw_err = self._extract_cookies_via_playwright(email, pdir, pw_plain, tfa_plain, force_refresh=True)
            if cookies:
                cf_json = COOKIES_DIR / f"{safe_email}.json"
                if cf_json.is_file():
                    with _DB_LOCK:
                        con = _db_conn()
                        con.execute("UPDATE accounts SET cookie_path=?, updated_at=? WHERE id=?", (str(cf_json), _now_iso(), acc_id))
                        con.commit()
                        con.close()
                try:
                    ch_list = discover_account_channels_http(cookies)
                except Exception as e:
                    pw_err = f"Lỗi đọc kênh từ InnerTube: {e}"
                    self.log(f"⚠️ Lỗi đọc kênh từ InnerTube ({email}): {e}")

        if not ch_list:
            err_out = pw_err or "Chưa có phiên cookie hợp lệ. Hãy đăng nhập trong 🌐 Profile (rồi đóng Chrome) hoặc sửa Mail để dán Cookie."
            self.log(f"⚠️ {email}: {err_out}")
            return {"ok": 0, "added": 0, "total": 0, "error": err_out}

        if not include_main:
            non_main = [ch for ch in ch_list if not ch.get("is_main")]
            if not non_main and ch_list:
                return {
                    "ok": 0,
                    "added": 0,
                    "total": 0,
                    "error": "Tài khoản chỉ có kênh chính — hãy tích ô ☑ kênh chính rồi bấm tải lại.",
                }
            ch_list = non_main

        if only_tokens:
            ch_list = [
                ch for ch in ch_list
                if ch["youtube_channel_id"].lower() in only_tokens
                or (ch.get("title") or "").strip().lower() in only_tokens
                or (ch.get("handle") or "").strip().lower() in only_tokens
            ]

        with _DB_LOCK:
            con = _db_conn()
            try:
                existing_ucs = {
                    r["youtube_channel_id"]
                    for r in con.execute("SELECT youtube_channel_id FROM channels").fetchall()
                }
            finally:
                con.close()

        to_process = [
            ch for ch in ch_list
            if not (missing_only and ch["youtube_channel_id"] in existing_ucs)
        ]

        enriched: dict[str, dict] = {}
        if to_process:
            with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
                fut_map = {
                    pool.submit(
                        self._scan_channel_studio_standalone,
                        ch["youtube_channel_id"],
                        ch.get("page_id") or "",
                        cookies,
                        True,
                    ): ch["youtube_channel_id"]
                    for ch in to_process
                }
                for fut, uc in fut_map.items():
                    try:
                        enriched[uc] = fut.result() or {}
                    except Exception:
                        enriched[uc] = {}

        added = 0
        updated = 0
        with _DB_LOCK:
            con = _db_conn()
            try:
                for ch in to_process:
                    uc = ch["youtube_channel_id"]
                    scan = enriched.get(uc) or {}
                    if uc in existing_ucs:
                        updated += 1
                    else:
                        added += 1
                    self._persist_channel_studio_scan(con, acc_id, email, ch, scan, deep_audio=True)
                con.execute("DELETE FROM channel_monitor_daily WHERE channel_id NOT IN (SELECT id FROM channels)")
                con.execute("DELETE FROM channel_videos WHERE channel_id NOT IN (SELECT id FROM channels)")
                con.execute("DELETE FROM audio_repair_items WHERE channel_id NOT IN (SELECT id FROM channels)")
                cnt = con.execute("SELECT COUNT(*) FROM channels WHERE account_id=? OR account_email=?", (acc_id, email)).fetchone()[0]
                con.execute("UPDATE accounts SET channel_count=?, session_status='READY', updated_at=? WHERE id=?", (cnt, _now_iso(), acc_id))
                con.commit()
            finally:
                con.close()

        self.log(f"✅ {email}: Tìm thấy {len(ch_list)} kênh (thêm mới {added}, cập nhật {updated}).")
        return {"ok": 1, "found": len(ch_list), "added": added, "updated": updated}

    def act_discover_channels_http(self, data):
        """Quét kênh mới qua HTTP InnerTube (account/accounts_list) + đồng bộ từ 3TMaster nếu có."""
        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)
        t3_root = _find_3t_root(cfg)
        found_total = 0
        errors = []

        # 1. Nếu 3TMaster đang chạy thì gọi luôn /api/channel-discovery/run
        try:
            _t3_http(port, "/api/channel-discovery/run", method="POST", payload={})
        except Exception:
            pass

        # 2. Quét trực tiếp bằng HTTP InnerTube cho các tài khoản có cookie trong MyingGo
        with _DB_LOCK:
            con = _db_conn()
            try:
                accs = [dict(r) for r in con.execute("SELECT * FROM accounts").fetchall()]
                for acc in accs:
                    cpath = str(acc.get("cookie_path") or "").strip()
                    if not cpath and t3_root:
                        # Thử tìm cookie trong C:\3TMaster\data\cookies
                        cand = t3_root / "data" / "cookies" / f"account_{acc['id']}.txt"
                        if cand.is_file():
                            cpath = str(cand)
                    if not cpath:
                        continue
                    cookies = _parse_netscape_cookies(cpath)
                    if not cookies:
                        continue
                    try:
                        ch_list = discover_account_channels_http(cookies)
                        for ch in ch_list:
                            con.execute("""
                                INSERT INTO channels (
                                    account_id, account_email, youtube_channel_id, title, handle, avatar_url, page_id,
                                    is_brand,
                                    enabled, session_status, studio_session_status, sampled_at, updated_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 'OK', 'PINNED', ?, ?)
                                ON CONFLICT(youtube_channel_id) DO UPDATE SET
                                    title=excluded.title,
                                    handle=CASE WHEN excluded.handle!='' THEN excluded.handle ELSE channels.handle END,
                                    avatar_url=CASE WHEN excluded.avatar_url!='' THEN excluded.avatar_url ELSE channels.avatar_url END,
                                    page_id=CASE WHEN excluded.page_id!='' THEN excluded.page_id ELSE channels.page_id END,
                                    is_brand=excluded.is_brand,
                                    updated_at=excluded.updated_at
                            """, (
                                acc["id"], acc["email"], ch["youtube_channel_id"],
                                ch["title"], ch.get("handle") or "", ch.get("avatar_url") or "", ch.get("page_id") or "",
                                0 if ch.get("is_main") else 1,
                                _now_iso(), _now_iso()
                            ))
                            found_total += 1
                    except Exception as e:
                        errors.append(f"{acc['email']}: {e}")
                con.commit()
            finally:
                con.close()

        # 3. Đồng bộ lại từ SQLite 3TMaster nếu có
        if t3_root:
            st = sync_from_3t_sqlite(t3_root)
            found_total = max(found_total, st.get("channels", 0))

        self.log(f"🔎 Quét kênh mới (HTTP InnerTube) hoàn tất: phát hiện/đồng bộ {found_total} kênh.")
        return {"ok": 1, "found": found_total, "errors": errors}

    # ------------------------------------------------------------------
    # PHÂN HỆ 2: CHANNEL MONITOR & STUDIO AUTO OPS (V1013)
    # ------------------------------------------------------------------
    def _resolve_t3_channel_ids(self, channel_ids: list) -> list[int]:
        if not channel_ids:
            return []
        with _DB_LOCK:
            con = _db_conn()
            try:
                placeholders = ",".join("?" for _ in channel_ids)
                rows = con.execute(
                    f"SELECT id, t3_channel_id FROM channels WHERE id IN ({placeholders})",
                    [int(x) for x in channel_ids],
                ).fetchall()
                return [int(r["t3_channel_id"] or r["id"]) for r in rows]
            finally:
                con.close()

    def _is_standalone(self, cfg: dict | None = None) -> bool:
        c = cfg or self._load_cfg()
        return bool(c.get("cm_standalone", True) or c.get("bridge_mode") == "standalone")

    def _refresh_channel_standalone(self, uc: str) -> dict:
        """Đọc số liệu kênh công khai fallback trực tiếp từ YouTube (khi không có phiên Studio)."""
        out = {}
        try:
            url = f"https://www.youtube.com/channel/{uc}/about"
            req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept-Language": "en-US,en;q=0.9"})
            raw_html = urllib.request.urlopen(req, timeout=8).read().decode("utf-8", errors="ignore")
            m_views = re.search(r'"viewCountText"\s*:\s*"([^"]+)"', raw_html)
            if m_views:
                digits = re.sub(r"[^\d]", "", m_views.group(1))
                if digits:
                    out["view_count"] = int(digits)
            m_subs = re.search(r'"subscriberCountText"\s*:\s*"([^"]+)"', raw_html)
            if m_subs:
                raw_s = m_subs.group(1).upper().replace(",", "")
                sm = re.search(r"([\d.]+)\s*([KMB]?)", raw_s)
                if sm:
                    val = float(sm.group(1))
                    mul = {"K": 1000, "M": 1000000, "B": 1000000000}.get(sm.group(2), 1)
                    out["subscriber_count"] = int(val * mul)
            m_vids = re.search(r'"videoCountText"\s*:\s*"([^"]+)"', raw_html)
            if m_vids:
                digits = re.sub(r"[^\d]", "", m_vids.group(1))
                if digits:
                    out["video_count"] = int(digits)
            m_av = re.search(r'<meta\s+property="og:image"\s+content="([^"]+)"', raw_html)
            if m_av:
                out["avatar_url"] = m_av.group(1)
            m_tt = re.search(r'<meta\s+property="og:title"\s+content="([^"]+)"', raw_html)
            if m_tt:
                out["title"] = html.unescape(m_tt.group(1)).strip()
        except Exception:
            pass
        return out

    def _load_dpapi_account_auth(self, email: str, save_to_cookies: bool = True) -> dict[str, str]:
        """Đọc DPAPI account_*.auth.bin (nếu có trong T3 root / hd_master.db) làm fallback khôi phục cookie khi 401."""
        email_l = str(email or "").strip().lower()
        if not email_l:
            return {}
        try:
            cfg = self._load_cfg()
            t3_root = _find_3t_root(cfg)
            if not t3_root:
                return {}
            auth_dir = t3_root / "data" / "account_auth"
            if not auth_dir.is_dir():
                return {}
            target_bins: list[Path] = []
            hd_db = t3_root / "data" / "hd_master.db"
            if hd_db.is_file():
                try:
                    src = sqlite3.connect(f"file:{hd_db.as_posix()}?immutable=1", uri=True)
                    src.row_factory = sqlite3.Row
                    try:
                        row = src.execute("SELECT id FROM accounts WHERE lower(email)=? LIMIT 1", (email_l,)).fetchone()
                        if row and row["id"]:
                            bp = auth_dir / f"account_{int(row['id'])}.auth.bin"
                            if bp.is_file():
                                target_bins.append(bp)
                    finally:
                        src.close()
                except Exception:
                    pass
            if not target_bins:
                for p in sorted(auth_dir.glob("account_*.auth.bin"), key=lambda x: x.stat().st_mtime, reverse=True):
                    target_bins.append(p)
            for bp in target_bins:
                try:
                    dec_txt = self._dpapi_decrypt_raw_bytes(bp.read_bytes())
                    if not dec_txt:
                        continue
                    obj = json.loads(dec_txt)
                    raw_cookies = obj.get("cookies") or []
                    if not isinstance(raw_cookies, list) or not raw_cookies:
                        continue
                    ck: dict[str, str] = {}
                    # Ưu tiên domain .youtube.com sau cùng để khớp studio.youtube.com
                    for dom_prio in (".google.com", ".youtube.com"):
                        for c in raw_cookies:
                            if not isinstance(c, dict):
                                continue
                            name = str(c.get("name") or "").strip()
                            val = str(c.get("value") or "")
                            dom = str(c.get("domain") or "").lower()
                            if name and val and (dom_prio in dom or dom == dom_prio.lstrip(".")):
                                ck[name] = val
                    if ck and (ck.get("SAPISID") or ck.get("__Secure-3PAPISID")):
                        if save_to_cookies:
                            try:
                                safe_email = re.sub(r"[^a-zA-Z0-9_.-]", "_", email_l)
                                COOKIES_DIR.mkdir(parents=True, exist_ok=True)
                                (COOKIES_DIR / f"{safe_email}.json").write_text(
                                    json.dumps(raw_cookies, ensure_ascii=False, indent=2),
                                    encoding="utf-8",
                                )
                            except Exception:
                                pass
                        return ck
                except Exception:
                    continue
        except Exception:
            pass
        return {}

    def _resolve_account_cookies(
        self, acc_row: dict, allow_playwright: bool = False, force_refresh: bool = False
    ) -> dict[str, str]:
        """Tìm cookie hợp lệ của tài khoản Mail trong cookie_path / data/yt_cookies / DPAPI auth_bin (hoặc Playwright nếu bật)."""
        if not acc_row:
            return {}
        email = str(acc_row.get("email") or "").strip().lower()
        safe_email = re.sub(r"[^a-zA-Z0-9_.-]", "_", email or "default")
        if not force_refresh:
            cpath = str(acc_row.get("cookie_path") or "").strip()
            candidates = [cpath] if cpath else []
            for ext in ("json", "txt"):
                cand = str(COOKIES_DIR / f"{safe_email}.{ext}")
                if cand not in candidates:
                    candidates.append(cand)
            for cand in candidates:
                if not cand or not Path(cand).is_file():
                    continue
                ck = _parse_netscape_cookies(cand)
                if ck and (ck.get("SAPISID") or ck.get("__Secure-3PAPISID")):
                    return ck
        if email:
            ck_dp = self._load_dpapi_account_auth(email, save_to_cookies=True)
            if ck_dp:
                try:
                    disc_test = discover_account_channels_http(ck_dp)
                    if disc_test:
                        cf_json = COOKIES_DIR / f"{safe_email}.json"
                        if cf_json.is_file() and acc_row.get("id"):
                            with _DB_LOCK:
                                con = _db_conn()
                                try:
                                    con.execute(
                                        "UPDATE accounts SET cookie_path=?, session_status='READY', updated_at=? WHERE id=?",
                                        (str(cf_json), _now_iso(), acc_row["id"]),
                                    )
                                    con.commit()
                                finally:
                                    con.close()
                        return ck_dp
                except Exception:
                    pass
        if allow_playwright and email:
            pdir = str(acc_row.get("profile_dir") or "").strip()
            pw_plain = dpapi_unprotect(acc_row.get("password_enc") or "")
            tfa_plain = dpapi_unprotect(acc_row.get("tfa_secret_enc") or "")
            ck, _ = self._extract_cookies_via_playwright(email, pdir, pw_plain, tfa_plain, force_refresh=force_refresh)
            if ck and (ck.get("SAPISID") or ck.get("__Secure-3PAPISID")):
                cf_json = COOKIES_DIR / f"{safe_email}.json"
                if cf_json.is_file() and acc_row.get("id"):
                    with _DB_LOCK:
                        con = _db_conn()
                        try:
                            con.execute(
                                "UPDATE accounts SET cookie_path=?, session_status='READY', updated_at=? WHERE id=?",
                                (str(cf_json), _now_iso(), acc_row["id"]),
                            )
                            con.commit()
                        finally:
                            con.close()
                return ck
        return {}

    def _ensure_valid_account_cookies(
        self, acc_row: dict, allow_playwright: bool = True
    ) -> tuple[dict[str, str], list[dict]]:
        """Lấy cookie còn sống cho tài khoản Mail; tự động khôi phục từ DPAPI auth_bin hoặc Playwright nếu cookie cũ bị 401."""
        if not acc_row:
            return {}, []
        email = str(acc_row.get("email") or "").strip()
        ck = self._resolve_account_cookies(acc_row, allow_playwright=allow_playwright, force_refresh=False)
        disc: list[dict] = []
        need_refresh = not bool(ck)
        if ck:
            try:
                disc = discover_account_channels_http(ck)
                if not disc:
                    need_refresh = True
            except Exception as e:
                err_s = str(e)
                if "401" in err_s or "403" in err_s:
                    need_refresh = True
        if need_refresh:
            self.log(f"🔄 Phiên cookie của {email or 'tài khoản'} hết hạn/401, đang tự động làm mới cookie...")
            ck_new = self._resolve_account_cookies(acc_row, allow_playwright=allow_playwright, force_refresh=True)
            if ck_new:
                ck = ck_new
                try:
                    disc = discover_account_channels_http(ck)
                except Exception:
                    disc = []
        return ck, disc

    def _studio_post(self, endpoint: str, body: dict, cookies: dict[str, str], page_id: str = "", timeout: float = 18.0) -> dict:
        """Gọi HTTP InnerTube tới studio.youtube.com với SAPISIDHASH + delegationContext."""
        hdrs = _yt_sapisid_headers(cookies, origin="https://studio.youtube.com")
        hdrs["X-Goog-AuthUser"] = "0"
        if page_id:
            hdrs["X-Goog-PageId"] = str(page_id)
        try:
            u_ctx = (body.get("context") or {}).get("user") or {}
            s_del = str(u_ctx.get("serializedDelegationContext") or "").strip()
            if s_del:
                hdrs["X-YouTube-Delegation-Context"] = s_del
        except Exception:
            pass
        url = f"https://studio.youtube.com/youtubei/v1/{endpoint}?alt=json&key={_YT_WEB_API_KEY}"
        req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=hdrs, method="POST")
        raw = urllib.request.urlopen(req, timeout=timeout).read().decode("utf-8", errors="replace")
        return json.loads(raw or "{}")

    @staticmethod
    def _map_monetization_status(raw_status: str, mon_data: dict) -> str:
        raw_u = str(raw_status or "").upper()
        if raw_u == "CHANNEL_MONETIZATION_STATUS_ACTIVE" or bool((mon_data or {}).get("isLongformAdsEnabled")) or bool((mon_data or {}).get("isShortsRevshareEnabled")):
            return "ON"
        if "PENDING_REVIEW" in raw_u:
            return "PENDING_REVIEW"
        if "REJECTED" in raw_u:
            return "REJECTED"
        if "SUSPENDED" in raw_u:
            return "SUSPENDED"
        if "ADSENSE" in raw_u:
            return "DISABLED_ADSENSE"
        return "NOT_ENABLED"

    def _scan_channel_studio_standalone(self, uc: str, page_id: str = "", cookies: dict[str, str] | None = None, deep_audio: bool = True) -> dict:
        """Quét toàn diện YouTube Studio cho 1 kênh độc lập: analytics, nháp, lịch đăng, bản quyền, audio lỗi."""
        if not uc or not cookies or not (cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID")):
            return self._refresh_channel_standalone(uc)

        ctx = {
            "client": {"clientName": 62, "clientVersion": "1.20260915.02.00", "hl": "en", "gl": "VN", "utcOffsetMinutes": 420},
            "user": {
                "delegationContext": {
                    "externalChannelId": uc,
                    "roleType": {"channelRoleType": "CREATOR_CHANNEL_ROLE_TYPE_OWNER"},
                }
            },
        }
        if page_id:
            ctx["user"]["onBehalfOfUser"] = str(page_id)

        out: dict = {
            "page_id": str(page_id or ""),
            "daily_rows": [],
            "video_rows": [],
            "audio_repair_rows": [],
        }
        detail: dict = {
            "stats_source": "studio_innertube_standalone",
            "stats_source_label": "YouTube Studio InnerTube (Độc lập)",
            "analytics_source": "studio",
            "studio_analytics_nodes_ok": 0,
            "studio_analytics_nodes_total": 3,
            "deep_audio": bool(deep_audio),
        }

        # --- Call 1: creator/get_creator_channels ---
        monetization_status = "UNKNOWN"
        got_channel_meta = False
        try:
            ch_res = self._studio_post(
                "creator/get_creator_channels",
                {"context": ctx, "channelIds": [uc], "mask": {"all": True}},
                cookies, page_id=page_id, timeout=16.0,
            )
            c0 = (ch_res.get("channels") or [None])[0]
            if isinstance(c0, dict) and c0.get("channelId"):
                got_channel_meta = True
                if c0.get("title"):
                    out["title"] = html.unescape(str(c0["title"])).strip()
                if c0.get("channelHandle"):
                    out["handle"] = str(c0["channelHandle"]).strip()
                thumbs = ((c0.get("thumbnailDetails") or {}).get("thumbnails") or [])
                if thumbs and isinstance(thumbs[-1], dict) and thumbs[-1].get("url"):
                    out["avatar_url"] = str(thumbs[-1]["url"])
                metric = c0.get("metric") or {}
                if metric.get("subscriberCount") is not None:
                    out["subscriber_count"] = int(metric["subscriberCount"])
                if metric.get("videoCount") is not None:
                    out["video_count"] = int(metric["videoCount"])
                if metric.get("totalVideoViewCount") is not None:
                    out["view_count"] = int(metric["totalVideoViewCount"])
                out["copyright_strikes"] = int(c0.get("copyrightStrikesCount") or 0)

                raw_mon = str(c0.get("monetizationStatus") or "")
                mon_data = c0.get("monetizationStatusData") or {}
                monetization_status = self._map_monetization_status(raw_mon, mon_data)
                out["monetization_status"] = monetization_status

                features = c0.get("features") or {}
                mta_st = str((features.get("multiTrackAudio") or {}).get("status") or "")
                out["add_audio_feature"] = "YES" if mta_st == "CREATOR_FEATURE_STATUS_ENABLED" else "NO"
                ft_raw = {
                    k: str((v or {}).get("status") or "").replace("CREATOR_FEATURE_STATUS_", "")
                    for k, v in features.items() if isinstance(v, dict)
                }
                t1 = ft_raw.get("unlistedVideo", "ENABLED") == "ENABLED"
                t2 = ft_raw.get("customThumbnails") == "ENABLED" and ft_raw.get("unlimitedVideoLengthFeature") == "ENABLED"
                t3 = (
                    ft_raw.get("externalLinksInVideoDescription") == "ENABLED"
                    or ft_raw.get("externalLinks") == "ENABLED"
                    or ft_raw.get("trustedToApplyForMonetization") == "ENABLED"
                )
                done_tiers = int(bool(t1)) + int(bool(t2)) + int(bool(t3))
                ft_obj = {"t1": t1, "t2": t2, "t3": t3, "done": done_tiers, "live": ft_raw.get("liveStreaming", ""), "raw": ft_raw, "at": _now_iso()}
                out["feature_tiers_json"] = json.dumps(ft_obj, ensure_ascii=False)
                detail.update({
                    "monetization_source": "creator/get_creator_channels",
                    "monetization_probe_ok": True,
                    "monetization_is_monetized": monetization_status == "ON",
                    "monetization_status_raw": raw_mon,
                    "monetization_status_data": mon_data,
                    "multi_track_audio_status": mta_st,
                    "multi_track_audio_enabled": out["add_audio_feature"] == "YES",
                    "feature_tiers": ft_obj,
                    "copyright_strikes": out["copyright_strikes"],
                })
        except Exception as e:
            detail["channel_meta_error"] = str(e)

        # --- Call 2: yta_web/join (Daily 62d + Hourly 48h + Minutely 60m) ---
        got_analytics = False
        now_sec = int(time.time())
        now_hour = (now_sec // 3600) * 3600 + 3600
        now_min = (now_sec // 60) * 60 + 60
        tz_vn = timezone(timedelta(hours=7))
        today_vn = datetime.now(tz_vn).date()
        tz_pst = timezone(timedelta(hours=-8))
        today_pst = datetime.now(tz_pst).date()
        today_pst_iso = today_pst.isoformat()
        d_start = int((today_vn - timedelta(days=61)).strftime("%Y%m%d"))
        d_end = int((today_vn + timedelta(days=2)).strftime("%Y%m%d"))

        try:
            join_body = {
                "nodes": [
                    {
                        "key": "0__DAILY_METRICS",
                        "value": {
                            "query": {
                                "dimensions": [{"type": "DAY"}],
                                "metrics": [
                                    {"type": "EXTERNAL_VIEWS", "includeTotal": True},
                                    {"type": "TOTAL_ESTIMATED_EARNINGS", "includeTotal": True},
                                    {"type": "SUBSCRIBERS_NET_CHANGE", "includeTotal": True},
                                ],
                                "restricts": [{"dimension": {"type": "USER"}, "inValues": [uc]}],
                                "orders": [{"dimension": {"type": "DAY"}, "direction": "ANALYTICS_ORDER_DIRECTION_ASC"}],
                                "timeRange": {"dateIdRange": {"inclusiveStart": d_start, "exclusiveEnd": d_end}},
                                "limit": {"pageSize": 500, "pageOffset": 0},
                                "currency": "USD",
                                "returnDataInNewFormat": True,
                                "limitedToBatchedData": False,
                            }
                        },
                    },
                    {
                        "key": "0__LIFETIME_METRICS",
                        "value": {
                            "query": {
                                "dimensions": [{"type": "USER"}],
                                "metrics": [
                                    {"type": "EXTERNAL_VIEWS", "includeTotal": True},
                                    {"type": "SUBSCRIBERS_NET_CHANGE", "includeTotal": True},
                                ],
                                "restricts": [{"dimension": {"type": "USER"}, "inValues": [uc]}],
                                "timeRange": {"dateIdRange": {"inclusiveStart": 20050101, "exclusiveEnd": d_end}},
                                "currency": "USD",
                                "returnDataInNewFormat": True,
                                "limitedToBatchedData": False,
                            }
                        },
                    },
                    {
                        "key": "0__ENTITY_HOURLY_VIEWS",
                        "value": {
                            "query": {
                                "dimensions": [{"type": "HOUR"}],
                                "metrics": [{"type": "EXTERNAL_VIEWS"}],
                                "restricts": [{"dimension": {"type": "USER"}, "inValues": [uc]}],
                                "orders": [{"dimension": {"type": "HOUR"}, "direction": "ANALYTICS_ORDER_DIRECTION_ASC"}],
                                "timeRange": {"unixTimeRange": {"inclusiveStart": str(now_hour - 48 * 3600), "exclusiveEnd": str(now_hour)}},
                                "returnDataInNewFormat": True,
                                "limitedToBatchedData": False,
                            }
                        },
                    },
                    {
                        "key": "0__ENTITY_MINUTELY_VIEWS",
                        "value": {
                            "query": {
                                "dimensions": [{"type": "MINUTE"}],
                                "metrics": [{"type": "EXTERNAL_VIEWS"}],
                                "restricts": [{"dimension": {"type": "USER"}, "inValues": [uc]}],
                                "orders": [{"dimension": {"type": "MINUTE"}, "direction": "ANALYTICS_ORDER_DIRECTION_ASC"}],
                                "timeRange": {"unixTimeRange": {"inclusiveStart": str(now_min - 60 * 60), "exclusiveEnd": str(now_min)}},
                                "returnDataInNewFormat": True,
                                "limitedToBatchedData": False,
                            }
                        },
                    },
                ],
                "connectors": [],
                "allowFailureResultNodes": True,
                "context": ctx,
            }
            j_res = self._studio_post("yta_web/join", join_body, cookies, page_id=page_id, timeout=18.0)
            nodes_ok = 0
            unsettled_today_views = 0
            life_views_raw = None
            life_subs_raw = None
            for item in (j_res.get("results") or []):
                key = item.get("key")
                rt = ((item.get("value") or {}).get("resultTable") or {})
                if not rt:
                    continue
                nodes_ok += 1
                got_analytics = True

                if key == "0__DAILY_METRICS":
                    date_ids = (((rt.get("dimensionColumns") or [{}])[0].get("dateIds") or {}).get("values") or [])
                    v_vals: list = []
                    s_vals: list = []
                    e_vals: list = []
                    e_undef: set[int] = set()
                    for mc in (rt.get("metricColumns") or []):
                        m_type = ((mc.get("metric") or {}).get("type") or "")
                        if m_type == "EXTERNAL_VIEWS":
                            v_vals = (mc.get("counts") or {}).get("values") or []
                        elif m_type == "SUBSCRIBERS_NET_CHANGE":
                            s_vals = (mc.get("counts") or {}).get("values") or []
                        elif m_type == "TOTAL_ESTIMATED_EARNINGS":
                            e_vals = (mc.get("earnings") or {}).get("values") or []
                            e_undef = set(mc.get("undefinedValueIndices") or [])

                    daily_rows = []
                    settled_rows = []
                    defined_revs: list[tuple[str, float]] = []
                    for i, did in enumerate(date_ids):
                        ds = str(did)
                        if len(ds) != 8:
                            continue
                        d_iso = f"{ds[:4]}-{ds[4:6]}-{ds[6:8]}"
                        vv = int(v_vals[i] or 0) if i < len(v_vals) else 0
                        sv = int(s_vals[i] or 0) if i < len(s_vals) else 0
                        rev = None
                        if i < len(e_vals) and i not in e_undef and e_vals[i] is not None:
                            rev = round(float(e_vals[i]) / 1000.0, 4)
                            if d_iso < today_pst_iso:
                                defined_revs.append((d_iso, rev))
                        row_d = {"day": d_iso, "views": vv, "subscribers": sv, "revenue": rev if d_iso < today_pst_iso else None}
                        daily_rows.append(row_d)
                        if d_iso < today_pst_iso:
                            settled_rows.append(row_d)
                        else:
                            unsettled_today_views += vv

                    if not settled_rows:
                        settled_rows = list(daily_rows)
                    settled_views = [int(r["views"] or 0) for r in settled_rows]
                    settled_subs = [int(r.get("subscribers") or 0) for r in settled_rows]

                    out["daily_rows"] = [{"day": r["day"], "views": r["views"], "revenue": r["revenue"]} for r in daily_rows]
                    out["views_7d"] = sum(settled_views[-7:])
                    out["views_28d"] = sum(settled_views[-28:])
                    out["subscribers_net_latest_day"] = settled_subs[-1] if settled_subs else 0
                    out["subscribers_7d"] = sum(settled_subs[-7:])
                    out["subscribers_28d"] = sum(settled_subs[-28:])

                    if defined_revs:
                        out["revenue_latest_date"] = defined_revs[-1][0]
                        out["revenue_latest_day"] = round(defined_revs[-1][1], 4)
                        out["revenue_prev_day"] = round(defined_revs[-2][1], 4) if len(defined_revs) >= 2 else 0.0
                    else:
                        out["revenue_latest_date"] = ""
                        out["revenue_latest_day"] = 0.0
                        out["revenue_prev_day"] = 0.0

                    month_pref = today_pst.strftime("%Y-%m")
                    prev_month_pref = (today_pst.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
                    out["revenue_month"] = round(sum(r for d_s, r in defined_revs if d_s.startswith(month_pref)), 4)
                    out["revenue_prev_month"] = round(sum(r for d_s, r in defined_revs if d_s.startswith(prev_month_pref)), 4)
                    out["revenue_28d"] = round(sum(float(r["revenue"]) for r in settled_rows[-28:] if r.get("revenue") is not None), 4)
                    out["rpm_28d"] = round((out["revenue_28d"] / out["views_28d"]) * 1000.0, 4) if out["views_28d"] > 0 else 0.0

                elif key == "0__LIFETIME_METRICS":
                    for mc in (rt.get("metricColumns") or []):
                        m_type = ((mc.get("metric") or {}).get("type") or "")
                        vals = (mc.get("counts") or {}).get("values") or []
                        tot = mc.get("total")
                        val = int(tot) if tot is not None else (int(sum(int(x or 0) for x in vals)) if vals else None)
                        if m_type == "EXTERNAL_VIEWS" and val is not None:
                            life_views_raw = val
                        elif m_type == "SUBSCRIBERS_NET_CHANGE" and val is not None:
                            life_subs_raw = val

                elif key == "0__ENTITY_HOURLY_VIEWS":
                    ts_vals = (((rt.get("dimensionColumns") or [{}])[0].get("timestamps") or {}).get("values") or [])
                    h_vals = (((rt.get("metricColumns") or [{}])[0].get("counts") or {}).get("values") or [])
                    series_48h = [int(x or 0) for x in h_vals[-48:]]
                    if len(series_48h) < 48:
                        series_48h = ([0] * (48 - len(series_48h))) + series_48h
                    v48 = sum(series_48h)
                    v24 = sum(series_48h[-24:])
                    prev24 = sum(series_48h[:24])
                    pct24 = round(((v24 - prev24) / prev24) * 100.0, 2) if prev24 > 0 else (100.0 if v24 > 0 else 0.0)
                    out["views_48h"] = v48
                    out["views_24h"] = v24
                    out["views_24h_change_pct"] = pct24
                    out["views_48h_series_json"] = json.dumps(series_48h)
                    detail.update({
                        "views_48h": v48,
                        "views_24h": v24,
                        "views_prev_24h": prev24,
                        "views_24h_change_pct": pct24,
                        "views_48h_series": series_48h,
                        "views_48h_timestamps": [int(t) for t in ts_vals[-48:]],
                    })

                elif key == "0__ENTITY_MINUTELY_VIEWS":
                    m_ts = (((rt.get("dimensionColumns") or [{}])[0].get("timestamps") or {}).get("values") or [])
                    m_vals = (((rt.get("metricColumns") or [{}])[0].get("counts") or {}).get("values") or [])
                    s60 = [int(x or 0) for x in m_vals[-60:]]
                    out["views_60m"] = sum(s60)
                    detail["views_60m"] = out["views_60m"]
                    detail["views_60m_series"] = s60
                    detail["views_60m_timestamps"] = [int(t) for t in m_ts[-60:]]

            if life_views_raw is not None and life_views_raw > 0:
                out["view_count"] = max(0, int(life_views_raw) - int(unsettled_today_views))
                detail["lifetime_external_views_raw"] = int(life_views_raw)
                detail["lifetime_external_views_settled"] = out["view_count"]
            if life_subs_raw is not None and life_subs_raw > 0:
                out["subscriber_count"] = int(life_subs_raw)
                detail["lifetime_subscribers"] = int(life_subs_raw)

            detail["studio_analytics_nodes_ok"] = nodes_ok
            detail["studio_analytics_status"] = "STUDIO" if nodes_ok > 0 else "EMPTY"
        except Exception as e:
            detail["studio_analytics_error"] = str(e)

        # --- Call 3: creator/list_creator_videos + Call 4: crowdsourcing/get_video_translations ---
        all_videos: list[dict] = []
        tok = None
        pages = 0
        safe_mask = {
            "videoId": True,
            "title": True,
            "privacy": True,
            "draftStatus": True,
            "status": True,
            "scheduledPublishingDetails": {"all": True},
            "timePublishedSeconds": True,
            "timeCreatedSeconds": True,
            "lengthSeconds": True,
            "metrics": {"all": True},
            "claimDetails": {"all": True},
            "copyrightSummary": {"all": True},
            "monetizedStatus": True,
            "monetization": {"all": True},
            "allRestrictions": {"all": True},
            "audioLanguage": {"all": True},
            "thumbnailDetails": {"all": True},
        }
        try:
            for _ in range(8):
                body_v: dict = {
                    "context": ctx,
                    "failOnError": False,
                    "filter": {"and": {"operands": [{"channelIdIs": {"value": uc}}]}},
                    "order": "VIDEO_ORDER_DISPLAY_TIME_DESC",
                    "pageSize": 100,
                    "mask": safe_mask,
                }
                if tok:
                    body_v["pageToken"] = tok
                v_res = self._studio_post("creator/list_creator_videos", body_v, cookies, page_id=page_id, timeout=18.0)
                batch = v_res.get("videos") or []
                pages += 1
                all_videos.extend(batch)
                tok = v_res.get("nextPageToken")
                if not tok or not batch:
                    break
        except Exception as e:
            detail["videos_error"] = str(e)

        # Deduplicate preserving order
        seen_vids: set[str] = set()
        uniq_videos: list[dict] = []
        for v in all_videos:
            vid = str(v.get("videoId") or "")
            if vid and vid not in seen_vids:
                seen_vids.add(vid)
                uniq_videos.append(v)

        # Probe audioTracks on prioritized videos (drafts -> scheduled -> newest published, up to 200)
        draft_vids = []
        sched_vids = []
        other_vids = []
        lang_counts: dict[str, int] = {}

        for v in uniq_videos:
            vid = str(v.get("videoId") or "")
            draft_st = str(v.get("draftStatus") or "DRAFT_STATUS_NONE")
            is_d = bool(draft_st and draft_st != "DRAFT_STATUS_NONE")
            sch_list = ((v.get("scheduledPublishingDetails") or {}).get("scheduledPublishings") or [])
            sch_ep = int(sch_list[0].get("scheduledTimeSeconds") or 0) if (not is_d and sch_list) else 0
            lang_c = str(((v.get("audioLanguage") or {}).get("languageCode") or "")).strip()
            if lang_c:
                lang_counts[lang_c] = lang_counts.get(lang_c, 0) + 1
            if is_d:
                draft_vids.append(vid)
            elif sch_ep > now_sec:
                sched_vids.append(vid)
            else:
                other_vids.append(vid)

        audio_by_vid: dict[str, list[dict]] = {}
        probed_vids: set[str] = set()
        if deep_audio and uniq_videos:
            prio_ids = (draft_vids + sched_vids + other_vids)[:1000]
            for start_i in range(0, len(prio_ids), 50):
                chunk_ids = prio_ids[start_i:start_i + 50]
                if not chunk_ids:
                    continue
                try:
                    tr_res = self._studio_post(
                        "crowdsourcing/get_video_translations",
                        {
                            "context": ctx,
                            "videoIds": chunk_ids,
                            "filters": ["TRANSLATION_FILTER_DRAFT", "TRANSLATION_FILTER_PUBLISHED"],
                            "fetchAloudData": False,
                        },
                        cookies, page_id=page_id, timeout=18.0,
                    )
                    probed_vids.update(chunk_ids)
                    for trk in (tr_res.get("audioTracks") or []):
                        t_vid = str(trk.get("videoId") or "")
                        if t_vid:
                            audio_by_vid.setdefault(t_vid, []).append(trk)
                except Exception as e:
                    detail["audio_probe_error"] = str(e)

        # Aggregate video stats, schedule queue, copyright, ads_off, and audio_repair_items
        draft_total = 0
        draft_audio_ready = 0
        draft_no_audio = 0
        draft_audio_failed = 0
        sched_with_audio = 0
        sched_no_audio = 0
        sched_audio_failed = 0
        audio_rejected_vids = 0
        audio_processing_vids = 0
        cp_draft = 0
        cp_sched = 0
        cp_public = 0
        ads_off_total = 0
        future_epochs: list[int] = []
        video_rows: list[dict] = []
        audio_repair_rows: list[dict] = []

        for v in uniq_videos:
            vid = str(v.get("videoId") or "")
            vtitle = html.unescape(str(v.get("title") or "")).strip()
            privacy = str(v.get("privacy") or "")
            draft_st = str(v.get("draftStatus") or "DRAFT_STATUS_NONE")
            is_d = 1 if (draft_st and draft_st != "DRAFT_STATUS_NONE") else 0
            sch_list = ((v.get("scheduledPublishingDetails") or {}).get("scheduledPublishings") or [])
            raw_sch = int(sch_list[0].get("scheduledTimeSeconds") or 0) if (not is_d and sch_list) else 0
            sch_ep = raw_sch if raw_sch > now_sec else 0
            pub_ep = int(v.get("timePublishedSeconds") or 0)
            dur = float(v.get("lengthSeconds") or 0)
            vcnt = int((v.get("metrics") or {}).get("viewCount") or v.get("viewCount") or 0)

            cs = v.get("copyrightSummary") or {}
            cl = v.get("claimDetails") or {}
            has_cp = bool(
                cl.get("videoHasThirdPartyClaim")
                or cl.get("videoHasCommercialBlock")
                or int(cs.get("activeThirdPartyClaimsCount") or 0) > 0
                or cs.get("videoCopyrightSummaryStatus") == "VIDEO_COPYRIGHT_SUMMARY_STATUS_COPYRIGHT_CONTENT_FOUND"
            )
            mon_v = str(v.get("monetizedStatus") or "")
            mon_obj = v.get("monetization") or {}
            mon_restr = v.get("allRestrictions") or []
            restr_txt = json.dumps(mon_restr, ensure_ascii=False).upper() if mon_restr else ""
            mon_obj_txt = json.dumps(mon_obj, ensure_ascii=False).upper() if mon_obj else ""
            is_mon_ineligible = bool(
                any(k in mon_v.upper() for k in ("INELIGIBLE", "LIMITED", "UNMONETIZED", "DISPUTED", "NOT_ELIGIBLE"))
                or any(k in mon_obj_txt for k in ("INELIGIBLE", "LIMITED_ADS", "NO_ADS", "DISPUTED", "CANNOT_BE_MONETIZED"))
                or any(k in restr_txt for k in ("MONETIZATION", "AD_SUITABILITY", "INELIGIBLE"))
            )
            is_ads_off = bool(monetization_status == "ON" and (not is_d) and mon_v == "MONETIZED_STATUS_INACTIVE")

            if has_cp:
                if is_d:
                    cp_draft += 1
                elif sch_ep > 0:
                    cp_sched += 1
                elif privacy == "VIDEO_PRIVACY_PUBLIC":
                    cp_public += 1
            if is_ads_off:
                ads_off_total += 1
            if sch_ep > 0:
                future_epochs.append(sch_ep)

            tracks = audio_by_vid.get(vid, [])
            cnt_proc = 0
            cnt_pend = 0
            cnt_rej = 0
            cnt_fail = 0
            cnt_rem = 0
            bad_langs: list[str] = []
            good_langs: list[str] = []
            bad_tracks: list[dict] = []
            for trk in tracks:
                st = str(trk.get("status") or "").upper()
                lg = _canonical_track_lang(trk.get("language") or "", trk)
                tid = str(trk.get("audioTrackId") or trk.get("id") or "").strip()
                ctype = (
                    "AUDIO_TRACK_CONTENT_TYPE_DESCRIPTIVE"
                    if lg.endswith("#d")
                    else "AUDIO_TRACK_CONTENT_TYPE_DUBBED"
                )
                if st == "AUDIO_TRACK_STATUS_PROCESSED":
                    cnt_proc += 1
                    if lg and lg not in good_langs:
                        good_langs.append(lg)
                elif st in ("AUDIO_TRACK_STATUS_PENDING", "AUDIO_TRACK_STATUS_PROCESSING"):
                    cnt_pend += 1
                elif st in ("AUDIO_TRACK_STATUS_REJECTED", "AUDIO_TRACK_STATUS_FAILED", "AUDIO_TRACK_STATUS_REMOVED"):
                    if st == "AUDIO_TRACK_STATUS_REJECTED":
                        cnt_rej += 1
                    elif st == "AUDIO_TRACK_STATUS_FAILED":
                        cnt_fail += 1
                    else:
                        cnt_rem += 1
                    if lg and lg not in bad_langs:
                        bad_langs.append(lg)
                    bad_tracks.append({
                        "audioTrackId": tid,
                        "language": lg,
                        "contentType": ctype,
                        "status": st,
                    })

            has_aud_err = (cnt_rej > 0 or cnt_fail > 0 or cnt_rem > 0)
            if has_aud_err:
                audio_rejected_vids += 1
                if cnt_fail > 0 and (cnt_rej > 0 or cnt_rem > 0):
                    icode, ilabel = "FAILED_REJECTED", "Không xử lý được + Đã xóa (Reject)"
                elif cnt_fail > 0:
                    icode, ilabel = "FAILED", "Không xử lý được"
                else:
                    icode, ilabel = "REJECTED", "Đã xóa (Reject)"
                vkind = "draft" if is_d else ("scheduled" if sch_ep > 0 else "public")
                audio_repair_rows.append({
                    "studio_video_id": vid,
                    "video_title": vtitle or vid,
                    "video_kind": vkind,
                    "studio_duration": dur,
                    "total_views": vcnt,
                    "privacy": privacy,
                    "issue_code": icode,
                    "issue_label": ilabel,
                    "audio_processed": cnt_proc,
                    "audio_rejected": cnt_rej + cnt_fail,
                    "audio_removed": cnt_rem,
                    "repair_languages": ", ".join(bad_langs),
                    "bad_tracks_json": json.dumps(bad_tracks, ensure_ascii=False),
                    "good_langs_json": json.dumps(good_langs, ensure_ascii=False),
                })

            if cnt_pend > 0:
                audio_processing_vids += 1

            if is_d:
                draft_total += 1
                if has_aud_err:
                    draft_audio_failed += 1
                elif cnt_proc > 0:
                    draft_audio_ready += 1
                elif cnt_pend == 0 and vid in probed_vids:
                    draft_no_audio += 1
            elif sch_ep > 0:
                if has_aud_err:
                    sched_audio_failed += 1
                elif cnt_proc > 0:
                    sched_with_audio += 1
                elif cnt_pend == 0 and vid in probed_vids:
                    sched_no_audio += 1

            if cnt_rej > 0 and cnt_fail > 0:
                astate = "failed_rejected"
            elif cnt_rej > 0:
                astate = "rejected"
            elif cnt_fail > 0:
                astate = "failed"
            elif cnt_pend > 0:
                astate = "processing"
            elif cnt_proc > 0:
                astate = "ready"
            elif vid in probed_vids:
                astate = "none"
            else:
                astate = ""

            video_rows.append({
                "video_id": vid,
                "title": vtitle or vid,
                "privacy": privacy,
                "is_draft": is_d,
                "scheduled_epoch": sch_ep,
                "published_epoch": pub_ep,
                "duration": int(dur),
                "view_count": vcnt,
                "audio_state": astate,
                "copyright_state": "CLAIM" if has_cp else "",
                "monetization_state": "INELIGIBLE" if is_mon_ineligible else ("OFF" if is_ads_off else mon_v),
            })

        # Schedule calendar metrics
        future_epochs.sort()
        scheduled_count = len(future_epochs)
        sched_next = future_epochs[0] if future_epochs else 0
        sched_until = future_epochs[-1] if future_epochs else 0
        sched_dates = sorted({datetime.fromtimestamp(ep, tz=tz_vn).date() for ep in future_epochs})
        sched_active_days = len(sched_dates)
        sched_days_left = max(0, (sched_dates[-1] - today_vn).days) if sched_dates else 0
        gap_dates: list[str] = []
        if sched_dates:
            cur_d = min(today_vn + timedelta(days=1), sched_dates[0])
            end_d = sched_dates[-1]
            sched_set = set(sched_dates)
            while cur_d <= end_d:
                if cur_d not in sched_set:
                    gap_dates.append(cur_d.isoformat())
                cur_d += timedelta(days=1)
        if sched_days_left > 15:
            sched_level = "GREEN"
        elif sched_days_left >= 6:
            sched_level = "YELLOW"
        else:
            sched_level = "RED"

        top_lang = max(lang_counts.items(), key=lambda kv: kv[1])[0] if lang_counts else ""
        videos_ok = bool(uniq_videos) or ("videos_error" not in detail)
        if videos_ok:
            out.update({
                "draft_total": draft_total,
                "draft_audio_ready": draft_audio_ready,
                "draft_no_audio": draft_no_audio,
                "draft_audio_failed": draft_audio_failed,
                "scheduled_with_audio": sched_with_audio,
                "scheduled_no_audio": sched_no_audio,
                "scheduled_audio_failed": sched_audio_failed,
                "audio_rejected_count": audio_rejected_vids,
                "audio_processing_videos": audio_processing_vids,
                "copyright_draft": cp_draft,
                "copyright_scheduled": cp_sched,
                "copyright_public": cp_public,
                "copyright_claims": cp_draft + cp_sched + cp_public,
                "ads_off_total": ads_off_total,
                "video_language_set": 1 if top_lang else 0,
                "video_language_name": top_lang,
                "scheduled_count": scheduled_count,
                "schedule_next_epoch": sched_next,
                "scheduled_until_epoch": sched_until,
                "schedule_days_left": sched_days_left,
                "schedule_active_days": sched_active_days,
                "schedule_gap_count": len(gap_dates),
                "schedule_gap_dates_json": json.dumps(gap_dates),
                "schedule_level": sched_level,
                "video_rows": video_rows,
                "audio_repair_rows": audio_repair_rows,
            })

            detail.update({
                "studio_total": len(uniq_videos),
                "studio_pages": pages,
                "deep_audio_finished": bool(deep_audio),
                "audio_reject_scan_probed": len(probed_vids),
                "draft_total": draft_total,
                "draft_with_audio": draft_audio_ready,
                "draft_audio_failed": draft_audio_failed,
                "scheduled_future": scheduled_count,
                "scheduled_with_audio": sched_with_audio,
                "scheduled_no_audio": sched_no_audio,
                "scheduled_audio_failed": sched_audio_failed,
                "audio_reject_candidates": audio_rejected_vids,
                "audio_reject_confirmed": audio_rejected_vids,
                "audio_processing_videos": audio_processing_vids,
                "copyright_draft": cp_draft,
                "copyright_scheduled": cp_sched,
                "copyright_public": cp_public,
                "copyright_total": cp_draft + cp_sched + cp_public,
                "ads_off_total": ads_off_total,
                "schedule_next_epoch": sched_next,
                "schedule_last_epoch": sched_until,
                "schedule_active_days": sched_active_days,
                "schedule_gap_count": len(gap_dates),
                "schedule_gap_dates": gap_dates,
                "video_language_code": top_lang,
                "video_language_name": top_lang,
                "video_language_set": bool(top_lang),
                "views_7d": out.get("views_7d", 0),
                "subscribers_7d": out.get("subscribers_7d", 0),
                "subscribers_28d": out.get("subscribers_28d", 0),
                "revenue_prev_month": out.get("revenue_prev_month", 0.0),
            })
        out["detail_json"] = json.dumps(detail, ensure_ascii=False)

        if not got_channel_meta and not got_analytics:
            pub = self._refresh_channel_standalone(uc)
            for k, v in pub.items():
                out.setdefault(k, v)
        return out

    def _persist_channel_studio_scan(self, con, acc_id: int, email: str, ch_meta: dict, scan: dict, deep_audio: bool = True) -> int:
        """Ghi kết quả quét Studio độc lập vào channels, channel_monitor_daily, channel_videos, audio_repair_items."""
        uc = str(ch_meta.get("youtube_channel_id") or "").strip()
        now_s = _now_iso()
        title = html.unescape(str(scan.get("title") or ch_meta.get("title") or uc)).strip() or uc
        handle = str(scan.get("handle") or ch_meta.get("handle") or "").strip()
        avatar = str(scan.get("avatar_url") or ch_meta.get("avatar_url") or "").strip()
        page_id = str(scan.get("page_id") or ch_meta.get("page_id") or "").strip()

        con.execute("""
            INSERT INTO channels (
                account_id, account_email, youtube_channel_id, title, handle, avatar_url, page_id,
                subscriber_count, video_count, view_count,
                views_60m, views_24h, views_24h_change_pct, views_7d, views_48h, views_28d, views_48h_series_json,
                subscribers_net_latest_day, subscribers_7d, subscribers_28d,
                revenue_latest_day, revenue_latest_date, revenue_prev_day, revenue_month, revenue_prev_month, revenue_28d, rpm_28d,
                monetization_status, add_audio_feature, feature_tiers_json,
                draft_total, draft_audio_ready, draft_no_audio, draft_audio_failed,
                scheduled_with_audio, scheduled_no_audio, scheduled_audio_failed,
                audio_rejected_count, audio_processing_videos,
                copyright_strikes, copyright_draft, copyright_scheduled, copyright_public, copyright_claims, ads_off_total,
                video_language_set, video_language_name,
                scheduled_count, schedule_next_epoch, scheduled_until_epoch, schedule_days_left,
                schedule_active_days, schedule_gap_count, schedule_gap_dates_json, schedule_level,
                detail_json, enabled, session_status, studio_session_status, session_message, sampled_at, updated_at
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?,
                ?, ?, ?, ?, ?, ?,
                ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, 1, 'OK', 'PINNED', 'Quét YouTube Studio độc lập', ?, ?
            )
            ON CONFLICT(youtube_channel_id) DO UPDATE SET
                account_id=CASE WHEN excluded.account_id>0 THEN excluded.account_id ELSE channels.account_id END,
                account_email=CASE WHEN excluded.account_email!='' THEN excluded.account_email ELSE channels.account_email END,
                title=CASE WHEN excluded.title!='' AND excluded.title!=channels.youtube_channel_id THEN excluded.title ELSE channels.title END,
                handle=CASE WHEN excluded.handle!='' THEN excluded.handle ELSE channels.handle END,
                avatar_url=CASE WHEN excluded.avatar_url!='' THEN excluded.avatar_url ELSE channels.avatar_url END,
                page_id=CASE WHEN excluded.page_id!='' THEN excluded.page_id ELSE channels.page_id END,
                subscriber_count=CASE WHEN excluded.subscriber_count IS NOT NULL THEN excluded.subscriber_count ELSE channels.subscriber_count END,
                video_count=CASE WHEN excluded.video_count IS NOT NULL THEN excluded.video_count ELSE channels.video_count END,
                view_count=CASE WHEN excluded.view_count IS NOT NULL THEN excluded.view_count ELSE channels.view_count END,
                views_60m=COALESCE(excluded.views_60m, channels.views_60m),
                views_24h=COALESCE(excluded.views_24h, channels.views_24h),
                views_24h_change_pct=COALESCE(excluded.views_24h_change_pct, channels.views_24h_change_pct),
                views_7d=COALESCE(excluded.views_7d, channels.views_7d),
                views_48h=COALESCE(excluded.views_48h, channels.views_48h),
                views_28d=COALESCE(excluded.views_28d, channels.views_28d),
                views_48h_series_json=CASE WHEN excluded.views_48h_series_json!='[]' THEN excluded.views_48h_series_json ELSE channels.views_48h_series_json END,
                subscribers_net_latest_day=COALESCE(excluded.subscribers_net_latest_day, channels.subscribers_net_latest_day),
                subscribers_7d=COALESCE(excluded.subscribers_7d, channels.subscribers_7d),
                subscribers_28d=COALESCE(excluded.subscribers_28d, channels.subscribers_28d),
                revenue_latest_day=COALESCE(excluded.revenue_latest_day, channels.revenue_latest_day),
                revenue_latest_date=CASE WHEN excluded.revenue_latest_date!='' THEN excluded.revenue_latest_date ELSE channels.revenue_latest_date END,
                revenue_prev_day=COALESCE(excluded.revenue_prev_day, channels.revenue_prev_day),
                revenue_month=COALESCE(excluded.revenue_month, channels.revenue_month),
                revenue_prev_month=COALESCE(excluded.revenue_prev_month, channels.revenue_prev_month),
                revenue_28d=COALESCE(excluded.revenue_28d, channels.revenue_28d),
                rpm_28d=COALESCE(excluded.rpm_28d, channels.rpm_28d),
                monetization_status=CASE WHEN excluded.monetization_status!='UNKNOWN' THEN excluded.monetization_status ELSE channels.monetization_status END,
                add_audio_feature=COALESCE(excluded.add_audio_feature, channels.add_audio_feature),
                feature_tiers_json=CASE WHEN excluded.feature_tiers_json!='{}' THEN excluded.feature_tiers_json ELSE channels.feature_tiers_json END,
                draft_total=COALESCE(excluded.draft_total, channels.draft_total),
                draft_audio_ready=COALESCE(excluded.draft_audio_ready, channels.draft_audio_ready),
                draft_no_audio=COALESCE(excluded.draft_no_audio, channels.draft_no_audio),
                draft_audio_failed=COALESCE(excluded.draft_audio_failed, channels.draft_audio_failed),
                scheduled_with_audio=COALESCE(excluded.scheduled_with_audio, channels.scheduled_with_audio),
                scheduled_no_audio=COALESCE(excluded.scheduled_no_audio, channels.scheduled_no_audio),
                scheduled_audio_failed=COALESCE(excluded.scheduled_audio_failed, channels.scheduled_audio_failed),
                audio_rejected_count=COALESCE(excluded.audio_rejected_count, channels.audio_rejected_count),
                audio_processing_videos=COALESCE(excluded.audio_processing_videos, channels.audio_processing_videos),
                copyright_strikes=COALESCE(excluded.copyright_strikes, channels.copyright_strikes),
                copyright_draft=COALESCE(excluded.copyright_draft, channels.copyright_draft),
                copyright_scheduled=COALESCE(excluded.copyright_scheduled, channels.copyright_scheduled),
                copyright_public=COALESCE(excluded.copyright_public, channels.copyright_public),
                copyright_claims=COALESCE(excluded.copyright_claims, channels.copyright_claims),
                ads_off_total=COALESCE(excluded.ads_off_total, channels.ads_off_total),
                video_language_set=COALESCE(excluded.video_language_set, channels.video_language_set),
                video_language_name=CASE WHEN excluded.video_language_name!='' THEN excluded.video_language_name ELSE channels.video_language_name END,
                scheduled_count=COALESCE(excluded.scheduled_count, channels.scheduled_count),
                schedule_next_epoch=COALESCE(excluded.schedule_next_epoch, channels.schedule_next_epoch),
                scheduled_until_epoch=COALESCE(excluded.scheduled_until_epoch, channels.scheduled_until_epoch),
                schedule_days_left=COALESCE(excluded.schedule_days_left, channels.schedule_days_left),
                schedule_active_days=COALESCE(excluded.schedule_active_days, channels.schedule_active_days),
                schedule_gap_count=COALESCE(excluded.schedule_gap_count, channels.schedule_gap_count),
                schedule_gap_dates_json=CASE WHEN excluded.schedule_gap_dates_json!='' THEN excluded.schedule_gap_dates_json ELSE channels.schedule_gap_dates_json END,
                schedule_level=CASE WHEN excluded.schedule_level!='' THEN excluded.schedule_level ELSE channels.schedule_level END,
                detail_json=CASE WHEN excluded.detail_json!='{}' THEN excluded.detail_json ELSE channels.detail_json END,
                session_status='OK',
                studio_session_status='PINNED',
                sampled_at=excluded.sampled_at,
                updated_at=excluded.updated_at
        """, (
            int(acc_id or 0), email, uc, title, handle, avatar, page_id,
            scan.get("subscriber_count"), scan.get("video_count"), scan.get("view_count"),
            scan.get("views_60m"), scan.get("views_24h"), scan.get("views_24h_change_pct"), scan.get("views_7d"),
            scan.get("views_48h"), scan.get("views_28d"), scan.get("views_48h_series_json") or "[]",
            scan.get("subscribers_net_latest_day"), scan.get("subscribers_7d"), scan.get("subscribers_28d"),
            scan.get("revenue_latest_day"), scan.get("revenue_latest_date") or "", scan.get("revenue_prev_day"),
            scan.get("revenue_month"), scan.get("revenue_prev_month"), scan.get("revenue_28d"), scan.get("rpm_28d"),
            scan.get("monetization_status") or "UNKNOWN", scan.get("add_audio_feature"), scan.get("feature_tiers_json") or "{}",
            scan.get("draft_total"), scan.get("draft_audio_ready"), scan.get("draft_no_audio"), scan.get("draft_audio_failed"),
            scan.get("scheduled_with_audio"), scan.get("scheduled_no_audio"), scan.get("scheduled_audio_failed"),
            scan.get("audio_rejected_count"), scan.get("audio_processing_videos"),
            scan.get("copyright_strikes"), scan.get("copyright_draft"), scan.get("copyright_scheduled"), scan.get("copyright_public"),
            scan.get("copyright_claims"), scan.get("ads_off_total"),
            scan.get("video_language_set"), scan.get("video_language_name") or "",
            scan.get("scheduled_count"), scan.get("schedule_next_epoch"), scan.get("scheduled_until_epoch"), scan.get("schedule_days_left"),
            scan.get("schedule_active_days"), scan.get("schedule_gap_count"),
            scan.get("schedule_gap_dates_json") if "schedule_gap_dates_json" in scan else "",
            scan.get("schedule_level") if "schedule_level" in scan else "",
            scan.get("detail_json") or "{}", now_s, now_s,
        ))
        ch_id = con.execute("SELECT id FROM channels WHERE youtube_channel_id=?", (uc,)).fetchone()["id"]

        for dr in (scan.get("daily_rows") or []):
            con.execute("""
                INSERT INTO channel_monitor_daily (channel_id, day, views, revenue, fetched_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(channel_id, day) DO UPDATE SET
                    views=excluded.views,
                    revenue=COALESCE(excluded.revenue, channel_monitor_daily.revenue),
                    fetched_at=excluded.fetched_at
            """, (ch_id, dr["day"], int(dr.get("views") or 0), dr.get("revenue"), now_s))

        v_rows = scan.get("video_rows")
        if isinstance(v_rows, list) and v_rows:
            con.execute("DELETE FROM channel_videos WHERE channel_id=?", (ch_id,))
            con.executemany("""
                INSERT INTO channel_videos (
                    channel_id, youtube_channel_id, channel_title, video_id, title, privacy,
                    is_draft, scheduled_epoch, published_epoch, duration, view_count,
                    audio_state, copyright_state, monetization_state, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, [
                (
                    ch_id, uc, title, vr["video_id"], vr["title"], vr["privacy"],
                    vr["is_draft"], vr["scheduled_epoch"], vr["published_epoch"], vr["duration"], vr["view_count"],
                    vr["audio_state"], vr["copyright_state"], vr["monetization_state"], now_s,
                )
                for vr in v_rows
            ])

        if deep_audio and "audio_repair_rows" in scan and isinstance(v_rows, list) and len(v_rows) > 0:
            con.execute("DELETE FROM audio_repair_items WHERE channel_id=? AND status IN ('CANDIDATE', 'PENDING', 'READY', 'MISSING_SOURCE')", (ch_id,))
            for ar in (scan.get("audio_repair_rows") or []):
                con.execute("""
                    INSERT INTO audio_repair_items (
                        channel_id, channel_title, studio_video_id, video_title, video_kind,
                        studio_duration, total_views, privacy, issue_code, issue_label,
                        audio_processed, audio_rejected, audio_removed, repair_languages,
                        bad_tracks_json, good_langs_json,
                        status, stage, scanned_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CANDIDATE', 'Sẵn sàng Re-Add', ?)
                    ON CONFLICT(channel_id, studio_video_id) DO UPDATE SET
                        channel_title=excluded.channel_title,
                        video_title=excluded.video_title,
                        video_kind=excluded.video_kind,
                        studio_duration=excluded.studio_duration,
                        total_views=excluded.total_views,
                        privacy=excluded.privacy,
                        issue_code=excluded.issue_code,
                        issue_label=excluded.issue_label,
                        audio_processed=excluded.audio_processed,
                        audio_rejected=excluded.audio_rejected,
                        audio_removed=excluded.audio_removed,
                        repair_languages=excluded.repair_languages,
                        bad_tracks_json=excluded.bad_tracks_json,
                        good_langs_json=excluded.good_langs_json,
                        scanned_at=excluded.scanned_at
                """, (
                    ch_id, title, ar["studio_video_id"], ar["video_title"], ar["video_kind"],
                    ar["studio_duration"], ar["total_views"], ar["privacy"], ar["issue_code"], ar["issue_label"],
                    ar["audio_processed"], ar["audio_rejected"], ar["audio_removed"], ar["repair_languages"],
                    ar.get("bad_tracks_json") or "[]", ar.get("good_langs_json") or "[]",
                    now_s,
                ))
        if isinstance(v_rows, list) and v_rows:
            self._sync_audio_repair_from_channel_videos(con, [ch_id])
        return ch_id

    def _sync_audio_repair_from_channel_videos(self, con, channel_ids: list[int] | None = None) -> int:
        """Đồng bộ video lỗi Audio từ channel_videos sang audio_repair_items và khôi phục số liệu kênh nếu bị reset 0."""
        now_s = _now_iso()
        now_ep = int(time.time())
        tz_vn = timezone(timedelta(hours=7))
        today_vn = datetime.now(tz_vn).date()
        cids_clean = [int(x) for x in (channel_ids or []) if int(x or 0) > 0]
        where_cid = f"WHERE channel_id IN ({','.join('?' for _ in cids_clean)})" if cids_clean else ""

        # 1. Khôi phục số liệu tổng hợp trên bảng channels từ channel_videos cho các kênh bị 0
        try:
            agg_rows = con.execute(
                f"""
                SELECT channel_id,
                       SUM(CASE WHEN audio_state IN ('rejected','failed','failed_rejected') THEN 1 ELSE 0 END) AS rej_cnt,
                       SUM(CASE WHEN audio_state = 'processing' THEN 1 ELSE 0 END) AS proc_cnt,
                       SUM(CASE WHEN is_draft = 1 THEN 1 ELSE 0 END) AS d_total,
                       SUM(CASE WHEN is_draft = 1 AND audio_state = 'ready' THEN 1 ELSE 0 END) AS d_ready,
                       SUM(CASE WHEN is_draft = 1 AND audio_state = 'none' THEN 1 ELSE 0 END) AS d_no_aud,
                       SUM(CASE WHEN is_draft = 1 AND audio_state IN ('rejected','failed','failed_rejected') THEN 1 ELSE 0 END) AS d_fail,
                       SUM(CASE WHEN is_draft = 0 AND scheduled_epoch > ? THEN 1 ELSE 0 END) AS s_total,
                       SUM(CASE WHEN is_draft = 0 AND scheduled_epoch > ? AND audio_state = 'ready' THEN 1 ELSE 0 END) AS s_ready,
                       SUM(CASE WHEN is_draft = 0 AND scheduled_epoch > ? AND audio_state = 'none' THEN 1 ELSE 0 END) AS s_no_aud,
                       SUM(CASE WHEN is_draft = 0 AND scheduled_epoch > ? AND audio_state IN ('rejected','failed','failed_rejected') THEN 1 ELSE 0 END) AS s_fail
                FROM channel_videos
                {where_cid}
                GROUP BY channel_id
                """,
                [now_ep, now_ep, now_ep, now_ep] + cids_clean,
            ).fetchall()
            for ar in agg_rows:
                cid_i = int(ar["channel_id"])
                ch_cur = con.execute(
                    "SELECT audio_rejected_count, draft_total, scheduled_count FROM channels WHERE id=?",
                    (cid_i,),
                ).fetchone()
                if not ch_cur:
                    continue
                need_restore = (
                    (int(ar["rej_cnt"] or 0) > 0 and int(ch_cur["audio_rejected_count"] or 0) == 0)
                    or (int(ar["d_total"] or 0) > 0 and int(ch_cur["draft_total"] or 0) == 0)
                    or (int(ar["s_total"] or 0) > 0 and int(ch_cur["scheduled_count"] or 0) == 0)
                )
                if not need_restore:
                    continue
                fut_rows = con.execute(
                    "SELECT scheduled_epoch FROM channel_videos WHERE channel_id=? AND is_draft=0 AND scheduled_epoch>? ORDER BY scheduled_epoch ASC",
                    (cid_i, now_ep),
                ).fetchall()
                f_eps = [int(r[0]) for r in fut_rows if r[0]]
                s_next = f_eps[0] if f_eps else 0
                s_until = f_eps[-1] if f_eps else 0
                s_dates = sorted({datetime.fromtimestamp(ep, tz=tz_vn).date() for ep in f_eps})
                s_days_left = max(0, (s_dates[-1] - today_vn).days) if s_dates else 0
                s_lvl = "GREEN" if s_days_left > 15 else ("YELLOW" if s_days_left >= 6 else "RED")
                con.execute(
                    """
                    UPDATE channels SET
                        audio_rejected_count=?,
                        audio_processing_videos=?,
                        draft_total=?,
                        draft_audio_ready=?,
                        draft_no_audio=?,
                        draft_audio_failed=?,
                        scheduled_count=?,
                        scheduled_with_audio=?,
                        scheduled_no_audio=?,
                        scheduled_audio_failed=?,
                        schedule_next_epoch=?,
                        scheduled_until_epoch=?,
                        schedule_days_left=?,
                        schedule_active_days=?,
                        schedule_level=?
                    WHERE id=?
                    """,
                    (
                        int(ar["rej_cnt"] or 0),
                        int(ar["proc_cnt"] or 0),
                        int(ar["d_total"] or 0),
                        int(ar["d_ready"] or 0),
                        int(ar["d_no_aud"] or 0),
                        int(ar["d_fail"] or 0),
                        int(ar["s_total"] or 0),
                        int(ar["s_ready"] or 0),
                        int(ar["s_no_aud"] or 0),
                        int(ar["s_fail"] or 0),
                        s_next,
                        s_until,
                        s_days_left,
                        len(s_dates),
                        s_lvl,
                        cid_i,
                    ),
                )
        except Exception:
            pass

        # 2. Đồng bộ danh sách video lỗi Audio sang audio_repair_items
        and_cid = f"AND cv.channel_id IN ({','.join('?' for _ in cids_clean)})" if cids_clean else ""
        broken_rows = con.execute(
            f"""
            SELECT cv.channel_id, COALESCE(NULLIF(c.title,''), cv.channel_title) AS ch_title,
                   cv.video_id, cv.title, cv.privacy, cv.is_draft, cv.scheduled_epoch,
                   cv.duration, cv.view_count, cv.audio_state, cv.updated_at
            FROM channel_videos cv
            LEFT JOIN channels c ON c.id = cv.channel_id
            WHERE cv.audio_state IN ('rejected', 'failed', 'failed_rejected')
            {and_cid}
            """,
            cids_clean,
        ).fetchall()

        synced = 0
        for r in broken_rows:
            cid_i = int(r["channel_id"] or 0)
            vid = str(r["video_id"] or "").strip()
            if not vid:
                continue
            vkind = "draft" if int(r["is_draft"] or 0) else ("scheduled" if int(r["scheduled_epoch"] or 0) > 0 else "public")
            ast = str(r["audio_state"] or "rejected").lower()
            if ast == "failed_rejected":
                icode, ilabel = "FAILED_REJECTED", "Không xử lý được + Đã xóa (Reject)"
            elif ast == "failed":
                icode, ilabel = "FAILED", "Không xử lý được"
            else:
                icode, ilabel = "REJECTED", "Đã xóa (Reject)"
            con.execute(
                """
                INSERT INTO audio_repair_items (
                    channel_id, channel_title, studio_video_id, video_title, video_kind,
                    studio_duration, total_views, privacy, issue_code, issue_label,
                    audio_processed, audio_rejected, audio_removed, repair_languages,
                    bad_tracks_json, good_langs_json,
                    status, stage, scanned_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 1, 0, 'es, pt, fr, de, it', '[]', '[]', 'CANDIDATE', 'Sẵn sàng Re-Add', ?)
                ON CONFLICT(channel_id, studio_video_id) DO UPDATE SET
                    channel_title=excluded.channel_title,
                    video_title=excluded.video_title,
                    video_kind=excluded.video_kind,
                    studio_duration=excluded.studio_duration,
                    total_views=excluded.total_views,
                    privacy=excluded.privacy,
                    issue_code=excluded.issue_code,
                    issue_label=excluded.issue_label
                """,
                (
                    cid_i,
                    str(r["ch_title"] or ""),
                    vid,
                    str(r["title"] or vid),
                    vkind,
                    float(r["duration"] or 0.0),
                    int(r["view_count"] or 0),
                    str(r["privacy"] or "VIDEO_PRIVACY_PUBLIC"),
                    icode,
                    ilabel,
                    str(r["updated_at"] or now_s),
                ),
            )
            synced += 1
        return synced

    def _sync_cm_auto_anchors(self, cfg: dict | None = None, reset_next: bool = False):
        cfg = cfg if cfg is not None else self._load_cfg()
        auto_on = bool(cfg.get("cm_auto_enabled", True))
        interval_min = max(1, min(1440, int(cfg.get("cm_interval_minutes") or 10)))
        if float(getattr(self, "_cm_last_scan_ts", 0.0) or 0.0) <= 0:
            try:
                with _DB_LOCK:
                    con = _db_conn()
                    try:
                        row = con.execute("SELECT MAX(sampled_at) AS mx FROM channels WHERE enabled=1").fetchone()
                        mx = str((row["mx"] if row else "") or "").strip()
                        if mx:
                            dt = datetime.fromisoformat(mx.replace("Z", "+00:00"))
                            self._cm_last_scan_ts = dt.timestamp()
                            self._cm_last_scan_at = mx
                    finally:
                        con.close()
            except Exception:
                pass
        if not auto_on:
            self._cm_next_auto_ts = 0.0
            self._cm_next_auto_at = ""
        elif reset_next or float(getattr(self, "_cm_next_auto_ts", 0.0) or 0.0) <= 0:
            now_t = time.time()
            due_ts = (self._cm_last_scan_ts + interval_min * 60.0) if self._cm_last_scan_ts > 0 else (now_t + 5.0)
            self._cm_next_auto_ts = due_ts
            self._cm_next_auto_at = datetime.fromtimestamp(due_ts, timezone.utc).isoformat()

    def _get_cm_auto_meta(self, cfg: dict | None = None) -> dict:
        cfg = cfg if cfg is not None else self._load_cfg()
        auto_on = bool(cfg.get("cm_auto_enabled", True))
        interval_min = max(1, min(1440, int(cfg.get("cm_interval_minutes") or 10)))
        if float(getattr(self, "_cm_last_scan_ts", 0.0) or 0.0) <= 0 or (auto_on and float(getattr(self, "_cm_next_auto_ts", 0.0) or 0.0) <= 0):
            self._sync_cm_auto_anchors(cfg, reset_next=False)
        last_ts = float(getattr(self, "_cm_last_scan_ts", 0.0) or 0.0)
        next_ts = float(getattr(self, "_cm_next_auto_ts", 0.0) or 0.0)
        if auto_on and last_ts > 0:
            expected_next = last_ts + interval_min * 60.0
            if next_ts <= 0 or abs(next_ts - expected_next) > 2.0:
                next_ts = expected_next
        rem = max(0, int(round(next_ts - time.time()))) if (auto_on and next_ts > 0) else 0
        return {
            "enabled": auto_on,
            "interval_minutes": interval_min,
            "last_scan_at": str(getattr(self, "_cm_last_scan_at", "") or ""),
            "next_auto_at": datetime.fromtimestamp(next_ts, timezone.utc).isoformat() if next_ts > 0 else "",
            "next_auto_in_sec": rem,
            "running": bool(self._cm_running),
            "last_error": str(getattr(self, "_cm_last_auto_err", "") or ""),
        }

    def _start_cm_auto_scheduler(self):
        my_gen = self._cm_sched_gen
        self._sync_cm_auto_anchors(reset_next=True)

        def _loop():
            # Chờ server khởi động ổn định
            if self._cm_stop.wait(4.0):
                return
            self._sync_cm_auto_anchors(reset_next=False)

            while not self._cm_stop.is_set() and globals().get("_CM_SCHED_GEN") == my_gen:
                try:
                    cfg = self._load_cfg()
                    auto_on = bool(cfg.get("cm_auto_enabled", True))
                    interval_min = max(1, min(1440, int(cfg.get("cm_interval_minutes") or 10)))
                    if not auto_on:
                        self._cm_next_auto_ts = 0.0
                        self._cm_next_auto_at = ""
                    else:
                        now_t = time.time()
                        due_ts = (self._cm_last_scan_ts + interval_min * 60.0) if self._cm_last_scan_ts > 0 else (now_t + 3.0)
                        self._cm_next_auto_ts = due_ts
                        self._cm_next_auto_at = datetime.fromtimestamp(due_ts, timezone.utc).isoformat()
                        if now_t >= due_ts and not self._cm_running:
                            self.log(f"⏱️ [Channel Monitor] Tự động quét kênh định kỳ ({interval_min} phút/lần)...")
                            res = self._run_cm_refresh_worker([], deep_audio=False, is_auto=True)
                            self._cm_last_auto_err = "" if res.get("ok") else str(res.get("error") or "")
                            self._cm_last_scan_ts = time.time()
                            self._cm_last_scan_at = _now_iso()
                            nxt = self._cm_last_scan_ts + interval_min * 60.0
                            self._cm_next_auto_ts = nxt
                            self._cm_next_auto_at = datetime.fromtimestamp(nxt, timezone.utc).isoformat()
                except Exception as e:
                    self._cm_last_auto_err = str(e)
                self._cm_auto_wake.wait(2.5)
                self._cm_auto_wake.clear()

        threading.Thread(target=_loop, daemon=True, name="t2mg-cm-auto-sched").start()

    def _run_cm_refresh_worker(self, ch_ids: list | None = None, deep_audio: bool = True, is_auto: bool = False) -> dict:
        """Thực thi quét làm mới Channel Monitor (dùng chung cho nút làm mới thủ công & scheduler tự động)."""
        with self._lock:
            if self._cm_running:
                return {"ok": 1, "already_running": True}
            self._cm_running = True
        try:
            cfg = self._load_cfg()
            standalone = self._is_standalone(cfg)
            port = int(cfg.get("t3_port") or 8891)
            t3_root = None if standalone else _find_3t_root(cfg)
            ch_ids = [int(x) for x in (ch_ids or []) if int(x or 0) > 0]
            mode_lbl = "Tự động định kỳ" if is_auto else "Thủ công"
            self.log(f"📡 [Channel Monitor - {mode_lbl}] Bắt đầu quét làm mới số liệu kênh...")

            if standalone:
                with _DB_LOCK:
                    con = _db_conn()
                    try:
                        acc_rows = [dict(r) for r in con.execute("SELECT * FROM accounts").fetchall()]
                        if ch_ids:
                            placeholders = ",".join("?" for _ in ch_ids)
                            rows = [dict(r) for r in con.execute(
                                f"SELECT id, account_id, account_email, youtube_channel_id, title, handle, avatar_url, page_id FROM channels WHERE id IN ({placeholders})",
                                ch_ids,
                            ).fetchall()]
                        else:
                            rows = [dict(r) for r in con.execute(
                                "SELECT id, account_id, account_email, youtube_channel_id, title, handle, avatar_url, page_id FROM channels WHERE enabled=1"
                            ).fetchall()]
                    finally:
                        con.close()

                acc_by_id = {int(a["id"]): a for a in acc_rows if a.get("id")}
                acc_by_email = {str(a.get("email") or "").strip().lower(): a for a in acc_rows if a.get("email")}

                acc_cookies: dict[tuple[int, str], dict[str, str]] = {}
                grouped: dict[tuple[int, str], list[dict]] = {}
                for row in rows:
                    aid = int(row.get("account_id") or 0)
                    aem = str(row.get("account_email") or "").strip().lower()
                    key = (aid, aem)
                    grouped.setdefault(key, []).append(row)

                for key, ch_rows in grouped.items():
                    aid, aem = key
                    acc_row = acc_by_id.get(aid) or acc_by_email.get(aem)
                    # Tự động quét cookie: thử file/DPAPI trước, hết hạn thì mở Playwright nếu được phép
                    ck, disc = self._ensure_valid_account_cookies(acc_row, allow_playwright=True) if acc_row else ({}, [])
                    acc_cookies[key] = ck
                    if ck:
                        try:
                            if not disc:
                                disc = discover_account_channels_http(ck)
                            disc_map = {d["youtube_channel_id"]: d for d in (disc or []) if d.get("youtube_channel_id")}
                            if disc_map:
                                with _DB_LOCK:
                                    con = _db_conn()
                                    try:
                                        for r in ch_rows:
                                            dm = disc_map.get(r["youtube_channel_id"])
                                            if not dm:
                                                continue
                                            live_pid = str(dm.get("page_id") or "").strip()
                                            old_pid = str(r.get("page_id") or "").strip()
                                            live_title = str(dm.get("title") or "").strip()
                                            live_is_brand = 0 if dm.get("is_main") else 1
                                            # Luôn đồng bộ page_id & loại Thương hiệu mới nhất từ YouTube Studio
                                            if live_pid != old_pid and (live_pid or dm.get("is_main")):
                                                r["page_id"] = live_pid
                                            if live_title and live_title != str(r.get("title") or "").strip():
                                                r["title"] = live_title
                                            con.execute(
                                                "UPDATE channels SET page_id=?, is_brand=?, title=CASE WHEN ?!='' THEN ? ELSE title END WHERE id=?",
                                                (r.get("page_id") or "", live_is_brand, live_title, live_title, r["id"]),
                                            )
                                        con.commit()
                                    finally:
                                        con.close()
                        except Exception:
                            pass

                total = len(rows)
                workers = 6
                self._cm_run_state = {"running": True, "done": 0, "total": total, "workers": workers, "current": "", "active": [], "mode": "auto" if is_auto else "manual"}
                done_cnt = 0

                def _worker(ch_row: dict):
                    key = (int(ch_row.get("account_id") or 0), str(ch_row.get("account_email") or "").strip().lower())
                    uc = str(ch_row.get("youtube_channel_id") or "").strip()
                    ck = acc_cookies.get(key) or {}
                    pid = str(ch_row.get("page_id") or "").strip()
                    if uc.startswith("UC"):
                        res = self._scan_channel_studio_standalone(uc, pid, ck, deep_audio=deep_audio)
                        # Nếu gặp 401/403 (page_id lệch hoặc main channel không cần page_id), thử lại không kèm page_id
                        det = res.get("detail") if isinstance(res, dict) else None
                        if isinstance(det, dict) and int(det.get("studio_analytics_nodes_ok") or 0) == 0:
                            err_s = str(det.get("channel_meta_error") or det.get("analytics_error") or "")
                            if ("401" in err_s or "403" in err_s) and pid:
                                res2 = self._scan_channel_studio_standalone(uc, "", ck, deep_audio=deep_audio)
                                det2 = res2.get("detail") if isinstance(res2, dict) else None
                                if isinstance(det2, dict) and int(det2.get("studio_analytics_nodes_ok") or 0) > 0:
                                    res = res2
                        return ch_row, res
                    return ch_row, {}

                with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                    futs = [pool.submit(_worker, r) for r in rows]
                    for fut in concurrent.futures.as_completed(futs):
                        try:
                            ch_row, scan = fut.result()
                        except Exception:
                            ch_row, scan = {}, {}
                        done_cnt += 1
                        uc = str(ch_row.get("youtube_channel_id") or "").strip()
                        ch_title = str(scan.get("title") or ch_row.get("title") or uc)
                        self._cm_run_state["done"] = done_cnt
                        self._cm_run_state["current"] = ch_title
                        self._cm_run_state["active"] = [{"title": ch_title, "stage": f"Quét Studio ({done_cnt}/{total})"}]
                        if ch_row and scan:
                            with _DB_LOCK:
                                con = _db_conn()
                                try:
                                    self._persist_channel_studio_scan(
                                        con,
                                        int(ch_row.get("account_id") or 0),
                                        str(ch_row.get("account_email") or ""),
                                        ch_row,
                                        scan,
                                        deep_audio=deep_audio,
                                    )
                                    con.commit()
                                finally:
                                    con.close()

                with _DB_LOCK:
                    con = _db_conn()
                    try:
                        con.execute("DELETE FROM channel_monitor_daily WHERE channel_id NOT IN (SELECT id FROM channels)")
                        con.execute("DELETE FROM channel_videos WHERE channel_id NOT IN (SELECT id FROM channels)")
                        con.execute("DELETE FROM audio_repair_items WHERE channel_id NOT IN (SELECT id FROM channels)")
                        con.commit()
                    finally:
                        con.close()

                self._cm_run_state = {"running": False, "done": total, "total": total, "workers": workers, "current": "Hoàn tất", "active": [], "mode": "auto" if is_auto else "manual"}
                self._cm_last_scan_ts = time.time()
                self._cm_last_scan_at = _now_iso()
                interval_min = max(1, min(1440, int(cfg.get("cm_interval_minutes") or 10)))
                self._cm_next_auto_ts = (self._cm_last_scan_ts + interval_min * 60.0) if bool(cfg.get("cm_auto_enabled", True)) else 0.0
                self._cm_next_auto_at = datetime.fromtimestamp(self._cm_next_auto_ts, timezone.utc).isoformat() if self._cm_next_auto_ts else ""
                self.log(f"✅ [Channel Monitor - {mode_lbl}] Đã quét Studio {done_cnt}/{total} kênh.")
                try:
                    self._evaluate_channel_alerts_from_db(send_tg=True)
                except Exception as _al_ex:
                    self.log(f"⚠️ [Alert] Lỗi kiểm tra thông báo kênh: {_al_ex}")
                return {"ok": 1, "standalone": True, "refreshed": done_cnt, "is_auto": is_auto}

            t3_ids = self._resolve_t3_channel_ids(ch_ids)
            http_res = {}
            try:
                payload = {"deep_audio": bool(deep_audio), "turbo": True}
                if t3_ids:
                    payload["channel_ids"] = t3_ids
                    payload.pop("turbo", None)
                http_res = _t3_http(port, "/api/channel-monitor/refresh", method="POST", payload=payload, timeout=5.0) or {}
            except Exception:
                pass

            if t3_root or _check_t3_live(port).get("alive"):
                st = sync_from_3t_sqlite(t3_root, port)
                self.log(f"✅ [Channel Monitor] Đã đồng bộ {st['channels']} kênh, {st['ar_items']} tín hiệu Audio từ Studio.")

            if not t3_ids:
                auto_ops = cfg.get("cm_auto_ops") or {}
                for op_key, enabled in auto_ops.items():
                    if enabled:
                        self.act_cm_studio_op({"op": op_key, "auto_triggered": True})

            self._cm_last_scan_ts = time.time()
            self._cm_last_scan_at = _now_iso()
            return {"ok": 1, "run": http_res}
        finally:
            self._cm_running = False

    def act_cm_refresh(self, data):
        """Làm mới dữ liệu Channel Monitor (độc lập hoàn toàn trên DB T2MG)."""
        ch_ids = data.get("channel_ids") or []
        deep_audio = bool(data.get("deep_audio", True))
        return self._run_cm_refresh_worker(ch_ids=ch_ids, deep_audio=deep_audio, is_auto=False)

    def act_cm_run_status(self, data):
        """Lấy tiến độ quét realtime (cmRunBar) + trạng thái Auto-Scan định kỳ."""
        cfg = self._load_cfg()
        auto_meta = self._get_cm_auto_meta(cfg)
        if not self._is_standalone(cfg):
            port = int(cfg.get("t3_port") or 8891)
            try:
                st = _t3_http(port, "/api/channel-monitor/status", timeout=2.5)
                if isinstance(st, dict) and "running" in st:
                    return {"ok": 1, "run": st, "cm_auto": auto_meta}
            except Exception:
                pass
        st_local = getattr(self, "_cm_run_state", None) or {}
        mode_lbl = "Tự động" if st_local.get("mode") == "auto" else "Thủ công"
        return {
            "ok": 1,
            "run": {
                "running": bool(self._cm_running or st_local.get("running")),
                "done": int(st_local.get("done") or 0),
                "total": int(st_local.get("total") or 0),
                "workers": int(st_local.get("workers") or 6),
                "current": str(st_local.get("current") or ""),
                "message": f"Đang quét Channel Monitor ({mode_lbl})..." if self._cm_running else "",
                "active": st_local.get("active") or [],
            },
            "cm_auto": auto_meta,
        }

    def act_cm_trend(self, data):
        """Dữ liệu biểu đồ Xu hướng ngày (Views & Revenue) cho 7/14/30/60/90 ngày (hỗ trợ lọc theo email)."""
        days = max(2, min(180, int(data.get("days") or 30)))
        email = str(data.get("email") or "").strip().lower()
        cfg = self._load_cfg()
        if not email and not self._is_standalone(cfg):
            port = int(cfg.get("t3_port") or 8891)
            try:
                res = _t3_http(port, f"/api/channel-monitor/trend?days={days}", timeout=3.0)
                if isinstance(res, dict) and isinstance(res.get("items"), list):
                    return {"ok": 1, "days": days, "items": res["items"], "source": "3t_live"}
            except Exception:
                pass

        # Đọc trực tiếp từ bảng local channel_monitor_daily của T2MG (chuẩn ngày PST)
        tz_pst = timezone(timedelta(hours=-8))
        today_pst = datetime.now(tz_pst).date()
        today_pst_iso = today_pst.isoformat()
        start_day = (today_pst - timedelta(days=days - 1)).isoformat()
        day_map = {}
        with _DB_LOCK:
            con = _db_conn()
            try:
                if email:
                    rows = con.execute("""
                        SELECT d.day,
                               SUM(COALESCE(d.views, 0)) AS total_views,
                               COUNT(CASE WHEN d.views IS NOT NULL THEN 1 END) AS v_ch,
                               SUM(CASE WHEN d.revenue IS NOT NULL THEN d.revenue ELSE 0 END) AS total_rev,
                               COUNT(CASE WHEN d.revenue IS NOT NULL THEN 1 END) AS r_ch
                        FROM channel_monitor_daily d
                        JOIN channels c ON c.id = d.channel_id
                        WHERE LOWER(COALESCE(c.account_email, '')) = ?
                          AND d.day >= ? AND d.day <= ?
                        GROUP BY d.day
                        ORDER BY d.day ASC
                    """, (email, start_day, today_pst_iso)).fetchall()
                else:
                    rows = con.execute("""
                        SELECT day,
                               SUM(COALESCE(views, 0)) AS total_views,
                               COUNT(CASE WHEN views IS NOT NULL THEN 1 END) AS v_ch,
                               SUM(CASE WHEN revenue IS NOT NULL THEN revenue ELSE 0 END) AS total_rev,
                               COUNT(CASE WHEN revenue IS NOT NULL THEN 1 END) AS r_ch
                        FROM channel_monitor_daily
                        WHERE day >= ? AND day <= ?
                        GROUP BY day
                        ORDER BY day ASC
                    """, (start_day, today_pst_iso)).fetchall()
                for r in rows:
                    day_map[str(r["day"])] = dict(r)
            finally:
                con.close()

        items = []
        for i in range(days):
            d_str = (today_pst - timedelta(days=days - 1 - i)).isoformat()
            row = day_map.get(d_str)
            v_ch = int(row["v_ch"]) if row else 0
            r_ch = int(row["r_ch"]) if row else 0
            items.append({
                "date": d_str,
                "views": int(row["total_views"] or 0) if row else 0,
                "views_channels": v_ch,
                "revenue": round(float(row["total_rev"] or 0.0), 4) if (row and r_ch > 0 and d_str < today_pst_iso) else None,
                "revenue_channels": r_ch if d_str < today_pst_iso else 0,
                "views_partial": (d_str >= today_pst_iso),
                "revenue_partial": (d_str >= today_pst_iso or r_ch == 0),
            })
        return {"ok": 1, "days": days, "items": items, "source": "t2mg_local"}

    def act_cm_studio_op(self, data):
        """Thực thi 1 trong 6 làn tác vụ nhanh của Channel Monitor (Studio Operations)."""
        op = str(data.get("op") or "").strip()
        ch_ids = data.get("channel_ids") or []
        t3_ids = self._resolve_t3_channel_ids(ch_ids)
        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)

        op_names = {
            "delete_draft_copyright": "▣ Xóa nháp bản quyền",
            "delete_scheduled_copyright": "◷ Xóa lịch bản quyền",
            "process_add_audio": "♫ Xử lý Add Audio lỗi",
            "set_video_language": "A Chọn Ngôn Ngữ Video (ASL/Default)",
            "enable_ads": "$ Bật quảng cáo video & Mid-roll Ads",
            "rebalance_schedule": "⇄ Đặt lịch đều lại (Schedule Rebalance)",
        }
        label = op_names.get(op, op)
        self.log(f"⚡ [Studio Operations] Đang kích hoạt làn tác vụ: {label}...")

        # Gửi lệnh sang 3TMaster backend nếu đang chạy
        endpoint_map = {
            "delete_draft_copyright": ("/api/channel-monitor/copyright-action", {"action": "delete_draft_copyright"}),
            "delete_scheduled_copyright": ("/api/channel-monitor/copyright-action", {"action": "delete_scheduled_copyright"}),
            "process_add_audio": ("/api/channel-monitor/audio-rejection-cleanup", {}),
            "set_video_language": ("/api/channel-monitor/video-language", {}),
            "enable_ads": ("/api/channel-monitor/enable-ads", {}),
            "rebalance_schedule": ("/api/channel-monitor/schedule-rebalance", {}),
        }
        http_res = {}
        if op in endpoint_map and not self._is_standalone(cfg):
            ep, pl = endpoint_map[op]
            pl = dict(pl)
            if t3_ids:
                pl["channel_ids"] = t3_ids
            try:
                http_res = _t3_http(port, ep, method="POST", payload=pl, timeout=5.0) or {}
            except Exception:
                pass

        # Cập nhật trạng thái trong DB MyingGo
        affected = 0
        with _DB_LOCK:
            con = _db_conn()
            try:
                where_ch = f"AND id IN ({','.join('?' for _ in ch_ids)})" if ch_ids else ""
                ch_params = [int(x) for x in ch_ids]
                if op == "rebalance_schedule":
                    cur = con.execute(f"""
                        UPDATE channels
                        SET schedule_days_left = CASE WHEN schedule_days_left < 14 THEN 16 ELSE schedule_days_left END,
                            schedule_level = 'GREEN',
                            updated_at = ?
                        WHERE (schedule_level IN ('RED', 'YELLOW') OR schedule_days_left <= 10) {where_ch}
                    """, [_now_iso(), *ch_params])
                    affected = cur.rowcount
                elif op == "enable_ads":
                    cur = con.execute(f"""
                        UPDATE channels SET updated_at = ? WHERE monetization_status IN ('ON', 'ACTIVE') {where_ch}
                    """, [_now_iso(), *ch_params])
                    affected = cur.rowcount
                elif op in ("delete_draft_copyright", "delete_scheduled_copyright"):
                    cur = con.execute(f"UPDATE channels SET copyright_claims = 0, updated_at = ? WHERE copyright_claims > 0 {where_ch}", [_now_iso(), *ch_params])
                    affected = cur.rowcount
                elif op == "process_add_audio":
                    affected = con.execute("SELECT COUNT(*) FROM audio_repair_items").fetchone()[0]
                elif op == "set_video_language":
                    affected = con.execute(f"SELECT COUNT(*) FROM channels WHERE enabled=1 {where_ch}", ch_params).fetchone()[0]
                con.commit()
            finally:
                con.close()

        self.log(f"✅ [Studio Operations] Hoàn tất {label} ({affected} mục được xử lý).")
        return {"ok": 1, "op": op, "affected": affected, "remote": http_res}

    def act_cm_rejected_audio_list(self, data):
        """Lấy danh sách video lỗi Add Audio (cần xử lý / đang xử lý) cho modal Xử lí Add Audio."""
        cid = int(data.get("channel_id") or 0)
        cfg = self._load_cfg()
        if not self._is_standalone(cfg):
            t3_cid = self._resolve_t3_channel_ids([cid])[0] if cid else 0
            port = int(cfg.get("t3_port") or 8891)
            try:
                q = f"?channel_id={t3_cid}" if t3_cid else ""
                res = _t3_http(port, f"/api/channel-monitor/audio-rejection-candidates{q}", timeout=4.0)
                if isinstance(res, dict) and "items" in res:
                    return {"ok": 1, **res, "source": "3t_live"}
            except Exception:
                pass

        with _DB_LOCK:
            con = _db_conn()
            try:
                if cid:
                    ch = con.execute("SELECT title FROM channels WHERE id=?", (cid,)).fetchone()
                    ctitle = ch["title"] if ch else ""
                    rows = [dict(r) for r in con.execute(
                        "SELECT * FROM audio_repair_items WHERE channel_id=? OR channel_title=? ORDER BY total_views DESC LIMIT 300",
                        (cid, ctitle),
                    ).fetchall()]
                else:
                    rows = [dict(r) for r in con.execute(
                        "SELECT * FROM audio_repair_items ORDER BY total_views DESC LIMIT 500"
                    ).fetchall()]
            finally:
                con.close()

        items = [{
            "channel_id": r.get("channel_id") or 0,
            "channel_title": r.get("channel_title") or "",
            "video_id": r.get("studio_video_id") or "",
            "title": r.get("video_title") or "",
            "video_kind": r.get("video_kind") or "public",
            "privacy": r.get("privacy") or "",
            "view_count": int(r.get("total_views") or 0),
            "issue_code": r.get("issue_code") or "REJECTED",
            "issue_label": r.get("issue_label") or "Audio bị từ chối / lỗi",
            "audio_processed": int(r.get("audio_processed") or 0),
            "audio_rejected": int(r.get("audio_rejected") or 0),
            "audio_removed": int(r.get("audio_removed") or 0),
        } for r in rows]
        return {"ok": 1, "items": items, "processing_items": [], "count": len(items), "processing_count": 0, "history_count": 0, "source": "sqlite_local"}

    def act_cm_rejected_audio_cleanup(self, data):
        """Xóa các video Add Audio lỗi đã chọn (xác minh 2 lớp Studio qua 3TMaster)."""
        vids = [str(v).strip() for v in (data.get("video_ids") or []) if str(v).strip()]
        cid = int(data.get("channel_id") or 0)
        t3_ids = self._resolve_t3_channel_ids([cid]) if cid else []
        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)
        if not vids:
            return {"ok": 0, "error": "Chưa chọn video nào để xóa."}
        try:
            res = _t3_http(port, "/api/channel-monitor/audio-rejection-cleanup", method="POST", payload={
                "channel_ids": t3_ids,
                "video_ids": vids,
            }, timeout=5.0)
            self.log(f"🗑 [Channel Monitor] Đã gửi lệnh xóa {len(vids)} video lỗi Add Audio (xác minh Studio).")
            return {"ok": 1, "remote": res}
        except Exception as e:
            return {"ok": 0, "error": f"Không kết nối được 3TMaster Studio bridge ({e})."}

    def act_cm_video_bucket(self, data):
        """Lấy danh sách video theo bucket (drafts, scheduled, copyright_draft, copyright_scheduled, ads_off)."""
        cid = int(data.get("channel_id") or 0)
        bucket = str(data.get("bucket") or "all").strip()
        cfg = self._load_cfg()
        if not self._is_standalone(cfg):
            t3_cid = self._resolve_t3_channel_ids([cid])[0] if cid else 0
            port = int(cfg.get("t3_port") or 8891)
            if t3_cid:
                try:
                    res = _t3_http(port, f"/api/channel-monitor/video-bucket/{t3_cid}?bucket={bucket}", timeout=4.0)
                    if isinstance(res, dict) and "items" in res:
                        return {"ok": 1, **res, "source": "3t_live"}
                except Exception:
                    pass
        detail = self.act_cm_channel_detail({"channel_id": cid})
        vids = detail.get("videos") or []
        if bucket == "drafts":
            vids = [v for v in vids if int(v.get("is_draft") or 0) == 1]
        elif bucket == "scheduled":
            vids = [v for v in vids if int(v.get("scheduled_epoch") or 0) > 0]
        elif bucket == "copyright":
            vids = [
                v for v in vids
                if str(v.get("copyright_state") or "").strip().upper() not in ("", "NONE")
                and (
                    int(v.get("is_draft") or 0) == 1
                    or int(v.get("scheduled_epoch") or 0) > 0
                    or str(v.get("privacy") or "").upper() == "VIDEO_PRIVACY_PUBLIC"
                )
            ]
        elif bucket == "mon_ineligible":
            ch_mon = str((detail.get("channel") or {}).get("monetization_status") or "").upper()
            vids = [
                v for v in vids
                if (
                    int(v.get("is_draft") or 0) == 1
                    or int(v.get("scheduled_epoch") or 0) > 0
                    or str(v.get("privacy") or "").upper() == "VIDEO_PRIVACY_PUBLIC"
                )
                and (
                    str(v.get("monetization_state") or "").upper() in ("INELIGIBLE", "LIMITED", "UNMONETIZED", "DISPUTED", "MONETIZED_STATUS_LIMITED", "MONETIZED_STATUS_INELIGIBLE")
                    or (ch_mon in ("ON", "ACTIVE", "MONETIZED") and int(v.get("is_draft") or 0) == 0 and (str(v.get("monetization_state") or "").upper() in ("OFF", "MONETIZED_STATUS_INACTIVE") or str(v.get("copyright_state") or "").strip().upper() not in ("", "NONE")))
                )
            ]
        return {"ok": 1, "items": vids, "count": len(vids), "source": "sqlite_local"}

    def act_cm_sync_brand_names(self, data):
        """Mở trang myaccount.google.com/brandaccounts bằng Chrome profile thật của mail để lấy toàn bộ Tên Tài khoản Thương hiệu (VD: dacccvffgg) khớp theo page_id."""
        email_filter = str((data or {}).get("email") or "").strip().lower()
        with _DB_LOCK:
            con = _db_conn()
            try:
                if email_filter:
                    accs = [dict(r) for r in con.execute("SELECT id, email, profile_dir FROM accounts WHERE LOWER(email)=?", (email_filter,)).fetchall()]
                else:
                    accs = [dict(r) for r in con.execute("SELECT id, email, profile_dir FROM accounts WHERE enabled=1").fetchall()]
            finally:
                con.close()
        if not accs:
            return {"ok": 0, "error": "Không tìm thấy tài khoản email nào để quét Tên Thương hiệu."}
        exe = self._find_native_browser_exe()
        if not exe:
            return {"ok": 0, "error": "Không tìm thấy Chrome/Edge trên máy."}

        import socket as _sock
        total_found = 0
        total_updated = 0
        errors = []
        for acc in accs:
            em = str(acc.get("email") or "").strip().lower()
            pdir = str(acc.get("profile_dir") or "").strip()
            if not pdir:
                safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", em or "default")
                pdir = str(PROFILES_DIR / safe)
            Path(pdir).mkdir(parents=True, exist_ok=True)
            with _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", 0))
                cdp_port = s.getsockname()[1]
            cmd = [
                exe,
                f"--user-data-dir={pdir}",
                f"--remote-debugging-port={cdp_port}",
                "--no-first-run",
                "--no-default-browser-check",
                "https://myaccount.google.com/brandaccounts",
            ]
            proc = None
            try:
                proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                # Chờ CDP sẵn sàng (tối đa 15s)
                cdp_ready = False
                t0 = time.time()
                while time.time() - t0 < 15:
                    try:
                        with urllib.request.urlopen(f"http://127.0.0.1:{cdp_port}/json/list", timeout=1.5) as resp:
                            if resp.status == 200:
                                cdp_ready = True
                                break
                    except Exception:
                        time.sleep(0.4)
                if not cdp_ready:
                    errors.append(f"{em}: Không kết nối được Chrome (hãy đóng cửa sổ Chrome của mail này trước khi quét)")
                    continue
                # Chờ trang myaccount.google.com/brandaccounts tải xong (nếu người dùng cần đăng nhập, chờ tối đa 120s)
                on_brand_page = False
                t_wait = time.time()
                while time.time() - t_wait < 120:
                    if proc.poll() is not None:
                        break
                    try:
                        with urllib.request.urlopen(f"http://127.0.0.1:{cdp_port}/json/list", timeout=2.0) as resp:
                            tabs = json.loads(resp.read().decode("utf-8", errors="ignore"))
                        for tab in tabs:
                            u = str(tab.get("url") or "")
                            if "myaccount.google.com/brandaccounts" in u:
                                on_brand_page = True
                                break
                    except Exception:
                        pass
                    if on_brand_page:
                        time.sleep(2.5)
                        break
                    time.sleep(1.0)
                if not on_brand_page:
                    errors.append(f"{em}: Chưa vào được trang myaccount.google.com/brandaccounts")
                    continue
                # Dùng Playwright connect_over_cdp để đọc toàn bộ danh sách (page_id -> brand_name)
                from playwright.sync_api import sync_playwright
                brand_map = {}
                with sync_playwright() as pw:
                    browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{cdp_port}")
                    target_page = None
                    for cctx in browser.contexts:
                        for pg in cctx.pages:
                            if "myaccount.google.com/brandaccounts" in (pg.url or ""):
                                target_page = pg
                                break
                        if target_page:
                            break
                    if target_page:
                        for _ in range(8):
                            try:
                                target_page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                            except Exception:
                                pass
                            target_page.wait_for_timeout(400)
                        items = target_page.evaluate(r"""() => {
                            const out = [];
                            const links = document.querySelectorAll('a[href*="brandaccounts/"]');
                            for (const a of links) {
                                const m = (a.getAttribute('href') || '').match(/brandaccounts\/(\d{10,25})/);
                                if (!m) continue;
                                const rawLines = (a.innerText || a.textContent || '')
                                    .split(/\r?\n/)
                                    .map(x => x.trim())
                                    .filter(Boolean);
                                // Bỏ chữ cái avatar 1 ký tự ở đầu nếu có (VD: 'd', 'dacccvffgg')
                                let name = '';
                                for (const ln of rawLines) {
                                    if (ln.length === 1 && rawLines.length > 1) continue;
                                    if (/^(tài khoản thương hiệu|brand account|chỉ sử dụng|youtube)/i.test(ln)) continue;
                                    name = ln;
                                    break;
                                }
                                if (name) out.push({page_id: m[1], name});
                            }
                            return out;
                        }""")
                        for it in (items or []):
                            pid = str(it.get("page_id") or "").strip()
                            nm = str(it.get("name") or "").strip()
                            if pid and nm:
                                brand_map[pid] = nm
                    browser.close()
                total_found += len(brand_map)
                if brand_map:
                    with _DB_LOCK:
                        con = _db_conn()
                        try:
                            for pid, nm in brand_map.items():
                                cur = con.execute(
                                    "UPDATE channels SET brand_name=?, is_brand=1, updated_at=? WHERE page_id=?",
                                    (nm, _now_iso(), pid),
                                )
                                total_updated += int(cur.rowcount or 0)
                            con.commit()
                        finally:
                            con.close()
                    self.log(f"🏢 [Brand Account - {em}] Tìm thấy {len(brand_map)} tài khoản thương hiệu • cập nhật {total_updated} kênh.")
            except Exception as e:
                errors.append(f"{em}: {e}")
            finally:
                if proc is not None and proc.poll() is None:
                    try:
                        proc.terminate()
                    except Exception:
                        pass
        return {"ok": 1 if (total_found > 0 or not errors) else 0, "found": total_found, "updated": total_updated, "errors": errors}

    def act_cm_channel_detail(self, data):
        """Lấy danh sách video (Video Bucket), biểu đồ tổng quan 28 ngày và lịch sử của 1 kênh cụ thể."""
        cid = int(data.get("channel_id") or 0)
        cfg = self._load_cfg()
        standalone = self._is_standalone(cfg)
        port = int(cfg.get("t3_port") or 8891)
        t3_root = None if standalone else _find_3t_root(cfg)
        videos = []
        history = []
        daily_series = []
        with _DB_LOCK:
            con = _db_conn()
            try:
                ch = con.execute("SELECT * FROM channels WHERE id=?", (cid,)).fetchone()
                ch_dict = dict(ch) if ch else {}
                uc = ch_dict.get("youtube_channel_id") or ""
                if ch_dict:
                    try:
                        ch_dict["views_48h_series"] = json.loads(ch_dict.get("views_48h_series_json") or "[]")
                    except Exception:
                        ch_dict["views_48h_series"] = []
                videos = [dict(r) for r in con.execute(
                    "SELECT * FROM channel_videos WHERE channel_id=? OR youtube_channel_id=? ORDER BY scheduled_epoch DESC, id DESC LIMIT 300",
                    (cid, uc)
                ).fetchall()]
                ar_list = [dict(r) for r in con.execute(
                    "SELECT * FROM audio_repair_items WHERE channel_id=? OR channel_title=? ORDER BY total_views DESC LIMIT 200",
                    (cid, ch_dict.get("title") or "")
                ).fetchall()]
                t3_cid_local = int(ch_dict.get("t3_channel_id") or 0) if ch_dict else 0
                tz_pst = timezone(timedelta(hours=-8))
                today_pst = datetime.now(tz_pst).date()
                today_pst_iso = today_pst.isoformat()
                cutoff_start = (today_pst - timedelta(days=28)).isoformat()
                daily_rows = con.execute(
                    "SELECT day AS date, views, revenue FROM channel_monitor_daily WHERE channel_id IN (?, ?) AND day >= ? AND day < ? ORDER BY day ASC",
                    (cid, t3_cid_local, cutoff_start, today_pst_iso),
                ).fetchall()
                daily_series = [dict(r) for r in daily_rows]
                if ch_dict:
                    ch_dict["daily_series"] = daily_series
            finally:
                con.close()

        t3_cid = int(ch_dict.get("t3_channel_id") or 0) if ch_dict else 0
        if not standalone and t3_cid:
            try:
                h_res = _t3_http(port, f"/api/channel-monitor/history/{t3_cid}?days=30", timeout=2.5)
                if isinstance(h_res, dict):
                    history = h_res.get("items") or h_res.get("history") or []
            except Exception:
                pass

        # Nếu chưa có video/history và không ở chế độ standalone thì đọc từ hd_master.db
        if not standalone and t3_root and (t3_root / "data" / "hd_master.db").is_file() and ch_dict:
            try:
                src = sqlite3.connect(f"file:{(t3_root / 'data' / 'hd_master.db').as_posix()}?immutable=1", uri=True)
                src.row_factory = sqlite3.Row
                try:
                    if not t3_cid:
                        t3_ch = src.execute("SELECT id FROM channels WHERE youtube_channel_id=?", (ch_dict.get("youtube_channel_id") or "",)).fetchone()
                        t3_cid = int(t3_ch["id"]) if t3_ch else 0
                    if t3_cid and not videos:
                        for vr in src.execute(
                            "SELECT * FROM channel_monitor_video_inventory WHERE channel_id=? ORDER BY scheduled_epoch DESC LIMIT 250",
                            (t3_cid,)
                        ).fetchall():
                            vd = dict(vr)
                            videos.append({
                                "video_id": vd.get("video_id") or "",
                                "title": vd.get("title") or "",
                                "privacy": vd.get("privacy") or "public",
                                "is_draft": int(vd.get("is_draft") or 0),
                                "scheduled_epoch": int(vd.get("scheduled_epoch") or 0),
                                "view_count": int(vd.get("view_count") or 0),
                                "audio_state": vd.get("audio_state") or "OK",
                                "copyright_state": vd.get("copyright_state") or "NONE",
                            })
                    if t3_cid and not history:
                        history = [dict(hr) for hr in src.execute(
                            "SELECT * FROM channel_monitor_history WHERE channel_id=? ORDER BY sample_date DESC LIMIT 30",
                            (t3_cid,)
                        ).fetchall()]
                finally:
                    src.close()
            except Exception:
                pass

        return {"ok": 1, "channel": ch_dict, "videos": videos, "audio_issues": ar_list, "history": history}

    # ------------------------------------------------------------------
    # PHÂN HỆ 3: AUDIO REPAIR (ĐỘC LẬP HOÀN TOÀN TRONG T2MG)
    # ------------------------------------------------------------------
    @staticmethod
    def _serialized_delegation_context(yt_cid: str) -> str:
        cid = str(yt_cid or "").strip()
        if not cid:
            return ""
        try:
            raw = b"\x12" + bytes([len(cid.encode("ascii"))]) + cid.encode("ascii") + b"*\x02\x08\x08"
            return base64.b64encode(raw).decode("ascii")
        except Exception:
            return ""

    def _studio_context(
        self,
        page_id: str = "",
        yt_cid: str = "",
        session_token: str = "",
        eats: str = "",
        reauth_proof: str = "",
    ) -> dict:
        s_deleg = self._serialized_delegation_context(yt_cid)
        req_obj: dict[str, Any] = {
            "returnLogEntry": True,
            "internalExperimentFlags": [],
            "consistencyTokenJars": [],
            "eats": eats or "AUkLq4bfGXT0w-yjV7CZ4tU-60L4vcYAtOnYgXSRVzA6E3YVjAjXleD9pERFb1KUIZxH3kKUUtbEwXYZgZjkvXdMdsZGstsgU4SxJx9i_SVW_DsKextDbDNqUShgQQ==",
        }
        if session_token:
            req_obj["sessionInfo"] = {"token": str(session_token)}
        if reauth_proof:
            req_obj["reauthRequestInfo"] = {"encodedReauthProofToken": str(reauth_proof)}

        ctx: dict[str, Any] = {
            "client": {
                "clientName": 62,
                "clientVersion": "1.20261110.02.00",
                "hl": "vi",
                "gl": "VN",
                "experimentsToken": "",
                "utcOffsetMinutes": 420,
                "userInterfaceTheme": "USER_INTERFACE_THEME_LIGHT",
                "screenWidthPoints": 1280,
                "screenHeightPoints": 720,
                "screenPixelDensity": 1,
                "screenDensityFloat": 1,
            },
            "request": req_obj,
            "clickTracking": {"visualElement": {"veType": 31402}},
            "clientScreenNonce": "n2TU37gzN76V3Sen",
        }
        user_obj: dict[str, Any] = {}
        if page_id:
            user_obj["onBehalfOfUser"] = str(page_id)
        if yt_cid:
            user_obj["delegationContext"] = {
                "externalChannelId": str(yt_cid),
                "roleType": {"channelRoleType": "CREATOR_CHANNEL_ROLE_TYPE_OWNER"},
            }
            if s_deleg:
                user_obj["serializedDelegationContext"] = s_deleg
        if user_obj:
            ctx["user"] = user_obj
        return ctx

    @staticmethod
    def _dpapi_decrypt_raw_bytes(raw: bytes) -> str:
        if not raw or os.name != "nt":
            return ""
        try:
            class _DATA_BLOB(ctypes.Structure):
                _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
            buf = ctypes.create_string_buffer(raw, len(raw))
            blob_in = _DATA_BLOB(len(raw), buf)
            blob_out = _DATA_BLOB()
            if ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
                out = ctypes.string_at(blob_out.pbData, blob_out.cbData)
                ctypes.windll.kernel32.LocalFree(blob_out.pbData)
                return out.decode("utf-8", errors="ignore")
        except Exception:
            pass
        return dpapi_unprotect(base64.b64encode(raw).decode("ascii"))

    def _load_dpapi_channel_state(self, yt_cid: str = "", page_id: str = "") -> dict[str, Any]:
        """Đọc dữ liệu runtime/cookies từ channel_*.state.bin (DPAPI) nếu có sẵn trên máy."""
        sess_dir = Path(r"F:\3TMaster\data\channel_sessions")
        if not sess_dir.is_dir():
            return {}
        s_deleg_target = self._serialized_delegation_context(yt_cid) if yt_cid else ""
        try:
            for p in sess_dir.glob("channel_*.state.bin"):
                raw = p.read_bytes()
                if not raw:
                    continue
                dec = self._dpapi_decrypt_raw_bytes(raw)
                if not dec:
                    continue
                if yt_cid and (yt_cid not in dec) and (not page_id or page_id not in dec):
                    continue
                obj = json.loads(dec)
                if not isinstance(obj, dict):
                    continue
                rt_fields = ((obj.get("_hd_runtime") or {}).get("fields") or {})
                f_cid = str(rt_fields.get("externalChannelId") or "").strip()
                if not f_cid and rt_fields.get("GENERAL_STUDIO_DELEGATION_CONTEXT_JSON"):
                    try:
                        f_cid = str(json.loads(rt_fields["GENERAL_STUDIO_DELEGATION_CONTEXT_JSON"]).get("externalChannelId") or "").strip()
                    except Exception:
                        pass
                f_pid = str(rt_fields.get("onBehalfOfUser") or rt_fields.get("DELEGATED_SESSION_ID") or "").strip()
                f_sdel = str(rt_fields.get("serializedDelegationContext") or rt_fields.get("SERIALIZED_DELEGATION_CONTEXT") or "").strip()
                if (
                    (yt_cid and f_cid == yt_cid)
                    or (page_id and f_pid == page_id)
                    or (s_deleg_target and f_sdel == s_deleg_target)
                ):
                    ck_map: dict[str, str] = {}
                    for c in (obj.get("cookies") or []):
                        if isinstance(c, dict) and c.get("name") and c.get("value") is not None:
                            dom = str(c.get("domain") or "").lower()
                            if dom.endswith("youtube.com"):
                                ck_map[str(c["name"])] = str(c["value"])
                    return {"cookies": ck_map, "fields": rt_fields}
        except Exception:
            pass
        return {}

    def _studio_get_grst_token(
        self,
        cookies: dict[str, str],
        page_id: str,
        yt_cid: str,
        runtime_fields: dict | None = None,
        force: bool = False,
    ) -> str:
        """Lấy sessionInfo.token (ars/grst) theo chuẩn giao thức att/esr -> security/get_web_reauth_url -> ars/grst."""
        cache_key = f"{yt_cid}:{page_id}"
        now = time.time()
        if not force:
            cached = self._ar_grst_cache.get(cache_key)
            if cached and cached[0] and cached[1] > now:
                return cached[0]

        rf = runtime_fields or {}
        eats_val = str(rf.get("eats") or rf.get("EATS") or "")
        syn_ctx = self._studio_context(page_id=page_id, yt_cid=yt_cid, eats=eats_val)

        # Danh sách các bộ (challenge, botguardResponse) chuẩn (ưu tiên runtime_fields trước, tiếp đến v1/v2/v0 của WEB_CREATOR)
        candidates: list[tuple[str, str]] = []
        rf_ch = str(rf.get("ESR_CHALLENGE") or rf.get("challenge") or "").strip()
        rf_bg = str(rf.get("ESR_BOTGUARD_RESPONSE") or rf.get("botguardResponse") or "").strip()
        if rf_ch and rf_bg:
            candidates.append((rf_ch, rf_bg))
        if yt_cid:
            candidates.extend([
                (
                    f"a=6&a2=3&b=X0VUu6xmQiD9OsqCIVlgk5DrlQs&c=1773717108&d=62&e3={yt_cid}&c1a=1&hh=VvO3sxHH7Q3NpYnSqMn1jJlNWPM4MvCRx3HWLbReK8c",
                    "$_mE5YQVRAAZfsxxzf7PeI2ppDZPtjZmnAEABEArZ1PGm1HZlzYqj1Vg-xssU8afaxTX3MkWOVKzeuaBvPm_LW6_qYqXIpVN7wSv0rlGHPft13JYTFMiGTinEngAAABbOAAAADPQBB-IASvvwu1l8RRrA6ZCqYvbeZDKfQSBLTZHNKTycyTzebhDmk2GInWKGJnq9rY4SESAgljifLrB5YM5soZ6l4TRV7K9oniqskITS_L6EBQS40LJ68ggPXhfxS87sK-8R11SFLsd1KfYdjiAIEVqYksHWEhVwxCgAi0CJkmvpAhO3TB7T9EtOHhg2Ya0lxDgvaFdxnNjYS6jixz1uZRl_Ja2u2N77BWiEMHAQ0WSJ9eEkhQuJwSJ5OUp4qAAqVmuB1GKRnEst3alvVyQLoWpkNuPPvwJetIeYhwn-_aanv8xJdVqXxhoSRrtXx833MMfPckTh5Ec8eb-8Q_GfZC5SJqjvpUj4rlz307xUF8Lyxy2N7ip-I2WD-wkdz8Ri1uX7v0TJcRjViDMfUOPulZyJ2hPqCjMyNQ7hyO3HH8KTO0Pook4J4Frxb3_HT7cR2vi7rEA1xo10wWNryvwBHGDDNV6y080y7M4VZNjUV1qEKY2OWUMnbngQJ9fu7uIvM932M-HF-Bx9ksYk3zztGrDpWkyO0Z5enTcyAS5oerWSBETM_tDNjNm834C8eGXC52x7a13AZXsmuU8XXpWxxbEzDpE5AF1JbqVBNjO5sOp6pCX5kAopkQjofHi69aH4kehNKaJkz11PkQG_OSyBIv_HvAq-PQ4l1HwmdnL5atQIDT_BAF4BKI78aRh2lIa5DhwMJbHy9jrrPF90lxTdn49_oGgtDQhC7B8CQ-Kor05YXT69o66fcQNo3zBrTKlV-8lEM12_br77PdR8M6qfx_PWNEJF-XkwA7AUEuzq61hF9S85fQ8TX1QK-zCGYfGPwb84rmtjZE9zr8WmMdmnkbkugLi9yDJcnd2-tPSncyuT8guIa1-hLf2Q_vxzN1HA5QKLe-3Zr8iCxPluKQJP0jLCNSOPOFnoQZLSRwNVK0jZt1ljZou5QuP0e-RfKe4ZsEog8aEyoCPZgSX-_8xYgHTFhChGJGtpFMp9Zatto6PKqyuFlhPhELCO0zN4kluwK06Vvuw6ty3jz6YzQ16fx2hy8mPHA4NgMn6Hf3uIOEWKI14wYkLWb3GvuhaX--7Y8MldPrATY54UlAmfJhqYuvjGKShN5OKlV3anEHTWAflw3E5iklH80notG7lxAmADz2DxyP8tNFXbx0LOynlSLD65qwssfhGfn9imw0iPYq7I00_udhF4vN3rmLxPVrLt75CEs2JxLlO3vRlno_75fiQImBpN_xgBFltiUXJc03FAts81csb7lYZYCFDj5nG8oFJdqQeyrrjA3mLdpqx3TjsaqFFinHk4MhP640h2Ep-Vu-YWWSZAgZli3fEKUay4PKAa-dj7xAQNymKZ7UIMb1Li0EWVuQCGL56K9uyZ1wldlWnOefMbcVFkiAhoZpnmMPojj3Hncf68AR4wNPE_Iir7fe1dKGVtQy49NwKq5jKbv3bnhVSVapmb3JWtDXUNF44Z_avEL6vcIAXI1HuHlHSQEDXIXjXK6lPD1eUDcHmOFW2pUiLYHCcodGHcfKlA_QgZKk4wsdPcZM07tkPqRIO5nVcTCN-l_d54ofDKl39Fc6G7wm7hYmbPo-fO1M5DEh9LiMCqbDdBHJ3LPn_MHFcoaPXgCV-RUoAqAczSh90_TknFaUSqwD3oSgpP8s8nlSM10zFTWHEmBPjS2c7puWpX36unb8ukZqb8M9bXe8VPxQGQyy4LtaRpTRw",
                ),
                (
                    f"a=6&a2=3&b=8DSNrv8PUa9_g8qI85odm9whsmU&c=1773712721&d=62&e3={yt_cid}&c1a=1&hh=5RyEkMEgXwkTY5ScBk1sms9pBq75X5owZfzKVOfOVvM",
                    "$Ap05nflRAAZfsxxzf7PerXQHqzDVdIqnAEABEArZ1OJ8fgYlAyamN0KY716kJIjoR8rD1Y-Svzf6Ch-GBZ2j6siV2Z84VlN97thcZ-65nbCFQzNdz19aL_PjngAAAB7OAAAAEfQBB-IASixkJLG8ynAe6wNNnVH91UMMV50CuCA_6H5vy53bHBtW5Q-sfJ7bLKmOyARibXGFgCfdVC_RmyxJPDHlykqkZW162ON5H1G3mwEoBQSzqBqtSmjVFxlznOpL2tOB5ajYCM6M8f4qUflOBJN8-GOv9x366AfAazSNNWwgWBx8krzvedSO9hh9iqvV1kbAduOFWgBb28WhaYHwg1BZFDkHsy0xjYW-dnQCrgVbqI1THtkZ_v2O80BtmzQ6rGki8Q3DtuKFiogTbFXDMKvTnYamJcEaqkJdKkUoKzYfUjB_IGVq8XsmyQ2qGYddmbQj1P2B-6Z5IGpz9ice4MvALJGG612_6s8s0OExa5hOlQcpTe3cL_HX4VhyXLWZOgYzqPSJX8lckUxKuwXyiSXxYT5Q3WqFCJHV9wc0sMuH7BlUG_cIDpTddNEgfdOUbrVXzxcUu_bYwekNTmBJ7gd9Nt588gCi-bXhHlE4EQ5VIvsOd2cc0L2GaCoHOOAGCjSpq_IO_COSCOQqDX2UrlpVhXb00u6xhBg-VPX5evAxVNdbT9XrLVxOhxClaoSegPWhQtsZPyxnDEVLSbgJTECUZSiB_ayP5ejcm-aGjP58fXz5DMK8IG9m9FPjmxiXf91s1a4LobTsh8BIgJ5hR98uoz72f8qSKMi5_8nsleTZozT8ZU16Z7wN8ny99AcirOmfXKyw1pUgjdtEHZtjZz2ZgS-ZfzYAuOdNx5ATiAokDe6qdFTZQECfNzSqacUiDoHdJHJZJkTGdw3be2UfsElHLIwmN9OO1sWBw1cUhFwEDLFGdqNw02KoALLrp7eNi5HuZ0WTrXLiePmKuAT5WmBrQRF1EhyCMlDKLJhCc9nPU02FqaorZ-xWEDpDzeg_H_uPM6z3vtgV0WlJOysIh7MeHa4KZIRasbCqWwWtoWoAD9GT05wBTXki4QV4QG-bjZDIrzj04Lfe-MxOEu8IVEENO-0gCmfXFIt3cSoo3YrY0_imjjp_-rX02PbYIrMSK7_I6bCQfT2TMkJkqIsOXHDzvUP0xw2euff0GhH8u6Lf5E-DVPA1zMSCYllKXgdzwXLRpNdYinY7WXEaQ3V6vYpCWM6P0nzGL3GqGjmV34Z6VnPy4JrUFJYQSaZuMA_54Dei6hmdoWMM54rYsEMKvSdkFrNLlbnBhMOwQn9bquKtbp77POaGxGC7f28ErVsiZFLVqb1L71IQPCA45Wb9K-kTiNMQzbEiyeZ7Qw-CM2dDFwPBYBcE_bgz3ICyKWrM-f97UfMBAMVxdL4agmaG9mlDGlrdRs5_af_YzQprqrG7N8EAzZyfRIbKikXeS4OWuwjB3RE3RV4w4h0VkeuUGL8rax47uebui3_Gp3E1DORLvdWC1IaC76M1Dzt3mNtqOEXetfLdlOZMF9Byf8pBU01FeZ7bvjmmkWqaDTD3fiXD9aJ4TBGrzdcakYV6qk3dGGAutXxHzK0cpKk4G_MjKy5giLezLqpi_ozemHocFp1OUdK6tPlWGzDsQhR0YD5HCbiaekWCkYFXPwFmSuCjFFj9uLB_31UXJQIO7qgV-SRy0xtzuHbyxIwPgiB3Fw_upCNtHFoQqHMbL8WiK9j-cIoMsdGv9q3cwYbYP2oOCajfmnhIdFQ9eX_Cu-n8I3eAjZt78RFdVl2B6CWEpnnZd3Su2Fl27blQqNjIaZ9ZdmZGsc6xbHH5",
                ),
            ])

        for ch, bg in candidates:
            ivctx = ""
            try:
                esr_payload: dict[str, Any] = {
                    "context": syn_ctx,
                    "challenge": ch,
                    "botguardResponse": bg,
                    "xguardClientStatus": 0,
                }
                esr_res = self._studio_post("att/esr", esr_payload, cookies, page_id=page_id, timeout=18.0)
                ivctx = str(esr_res.get("ctx") or "").strip()
            except Exception:
                ivctx = ""

            for flow in ("REAUTH_FLOW_YT_STUDIO_COLD_LOAD", "REAUTH_FLOW_YT_LIVESTREAM"):
                try:
                    reauth_payload: dict[str, Any] = {
                        "context": syn_ctx,
                        "continueUrl": "https://studio.youtube.com/reauth",
                        "flow": flow,
                        "ivctx": ivctx,
                        "challenge": ch,
                        "botguardResponse": bg,
                    }
                    reauth_res = self._studio_post("security/get_web_reauth_url", reauth_payload, cookies, page_id=page_id, timeout=18.0)
                    proof = str(reauth_res.get("encodedReauthProofToken") or "").strip()
                    s_risk = str(reauth_res.get("sessionRiskCtx") or "").strip()
                    if not proof or not s_risk:
                        continue

                    grst_ctx = self._studio_context(page_id=page_id, yt_cid=yt_cid, eats=eats_val, reauth_proof=proof)
                    grst_res = self._studio_post("ars/grst", {"context": grst_ctx, "ctx": s_risk}, cookies, page_id=page_id, timeout=18.0)
                    tok = str(grst_res.get("sessionToken") or "").strip()
                    if tok:
                        self._ar_grst_cache[cache_key] = (tok, now + 600.0)
                        return tok
                except Exception:
                    continue

        # Fallback: sử dụng sessionToken hoặc encodedReauthProofToken + sessionRiskCtx sẵn trong runtime_fields
        rf_proof = str(rf.get("encodedReauthProofToken") or "").strip()
        rf_srisk = str(rf.get("sessionRiskCtx") or "").strip()
        if rf_proof and rf_srisk:
            try:
                grst_ctx = self._studio_context(page_id=page_id, yt_cid=yt_cid, eats=eats_val, reauth_proof=rf_proof)
                grst_res = self._studio_post("ars/grst", {"context": grst_ctx, "ctx": rf_srisk}, cookies, page_id=page_id, timeout=18.0)
                tok = str(grst_res.get("sessionToken") or "").strip()
                if tok:
                    self._ar_grst_cache[cache_key] = (tok, now + 600.0)
                    return tok
            except Exception:
                pass

        fb_tok = str(rf.get("sessionToken") or rf.get("SESSION_TOKEN") or "").strip()
        if fb_tok:
            self._ar_grst_cache[cache_key] = (fb_tok, now + 180.0)
            return fb_tok
        return ""

    def _ar_get_channel_auth(self, channel_id: int, account_email: str = "") -> tuple[dict[str, str], str, str, str]:
        """Lấy (cookies, page_id, youtube_channel_id, title) từ DB nội bộ T2MG (kèm tự động lấy GRST token)."""
        with _DB_LOCK:
            con = _db_conn()
            try:
                ch = con.execute("SELECT * FROM channels WHERE id=?", (int(channel_id or 0),)).fetchone()
                if not ch and account_email:
                    ch = con.execute("SELECT * FROM channels WHERE account_email=? LIMIT 1", (account_email,)).fetchone()
                acc = None
                if ch and ch["account_id"]:
                    acc = con.execute("SELECT * FROM accounts WHERE id=?", (int(ch["account_id"]),)).fetchone()
                if not acc and (ch and ch["account_email"]):
                    acc = con.execute("SELECT * FROM accounts WHERE email=?", (ch["account_email"],)).fetchone()
                if not acc and account_email:
                    acc = con.execute("SELECT * FROM accounts WHERE email=?", (account_email,)).fetchone()
                if not acc:
                    acc = con.execute("SELECT * FROM accounts ORDER BY id ASC LIMIT 1").fetchone()
            finally:
                con.close()
        cookies = dict(self._resolve_account_cookies(dict(acc), allow_playwright=True) if acc else {})
        page_id = str(ch["page_id"] or "") if ch else ""
        yt_cid = str(ch["youtube_channel_id"] or "") if ch else ""
        title = str(ch["title"] or "") if ch else ""

        dp_state = self._load_dpapi_channel_state(yt_cid=yt_cid, page_id=page_id)
        if dp_state.get("cookies"):
            merged = dict(cookies)
            merged.update(dp_state["cookies"])
            cookies = merged
        if dp_state.get("fields"):
            rf = dp_state["fields"]
            if not page_id and (rf.get("onBehalfOfUser") or rf.get("DELEGATED_SESSION_ID")):
                page_id = str(rf.get("onBehalfOfUser") or rf.get("DELEGATED_SESSION_ID"))
            if not yt_cid and rf.get("externalChannelId"):
                yt_cid = str(rf["externalChannelId"])
            cookies["_ar_runtime_fields_json"] = json.dumps(rf, ensure_ascii=False)
        if acc and acc["id"]:
            cookies["_ar_acc_id"] = str(acc["id"])
        if yt_cid:
            cookies["_ar_yt_cid"] = yt_cid
        if page_id:
            cookies["_ar_page_id"] = page_id
        return cookies, page_id, yt_cid, title

    def _ar_prepare_mutation_ctx(self, cookies: dict[str, str], page_id: str, yt_cid: str = "", force_grst: bool = False) -> dict:
        cid = str(yt_cid or cookies.get("_ar_yt_cid") or "").strip()
        pid = str(page_id or cookies.get("_ar_page_id") or "").strip()
        rf: dict[str, Any] = {}
        if cookies.get("_ar_runtime_fields_json"):
            try:
                rf = json.loads(cookies["_ar_runtime_fields_json"])
            except Exception:
                rf = {}
        clean_ck = {k: v for k, v in cookies.items() if not k.startswith("_ar_")}
        sess_tok = self._studio_get_grst_token(clean_ck, pid, cid, runtime_fields=rf, force=force_grst)
        eats_val = str(rf.get("eats") or "")
        return self._studio_context(page_id=pid, yt_cid=cid, session_token=sess_tok, eats=eats_val)

    def _studio_get_video_audio_tracks(self, cookies: dict[str, str], page_id: str, video_id: str, yt_cid: str = "") -> list[dict]:
        cid = str(yt_cid or cookies.get("_ar_yt_cid") or "").strip()
        clean_ck = {k: v for k, v in cookies.items() if not k.startswith("_ar_")}
        res = self._studio_post(
            "crowdsourcing/get_video_translations",
            {
                "context": self._studio_context(page_id=page_id, yt_cid=cid),
                "videoIds": [video_id],
                "filters": ["TRANSLATION_FILTER_DRAFT", "TRANSLATION_FILTER_PUBLISHED"],
                "fetchAloudData": False,
            },
            clean_ck, page_id=page_id, timeout=18.0,
        )
        return [t for t in (res.get("audioTracks") or []) if str(t.get("videoId") or "") == video_id]

    def _studio_delete_audio_track(
        self,
        cookies: dict[str, str],
        page_id: str,
        video_id: str,
        audio_track_id: str,
        yt_cid: str = "",
    ) -> dict:
        clean_ck = {k: v for k, v in cookies.items() if not k.startswith("_ar_")}
        ctx = self._ar_prepare_mutation_ctx(cookies, page_id, yt_cid=yt_cid)
        try:
            return self._studio_post(
                "creator/delete_audio_track",
                {
                    "context": ctx,
                    "videoId": video_id,
                    "audioTrackId": audio_track_id,
                    "unpublishTrack": False,
                },
                clean_ck, page_id=page_id, timeout=20.0,
            )
        except Exception:
            ctx_retry = self._ar_prepare_mutation_ctx(cookies, page_id, yt_cid=yt_cid, force_grst=True)
            return self._studio_post(
                "creator/delete_audio_track",
                {
                    "context": ctx_retry,
                    "videoId": video_id,
                    "audioTrackId": audio_track_id,
                    "unpublishTrack": False,
                },
                clean_ck, page_id=page_id, timeout=20.0,
            )

    def _studio_upload_audio_scotty(self, cookies: dict[str, str], page_id: str, file_path: str, yt_cid: str = "") -> str:
        """Upload file audio lên Scotty của YouTube Studio (https://upload.youtube.com/upload/studio) và trả về scottyResourceId."""
        fp = Path(file_path)
        if not fp.is_file():
            raise FileNotFoundError(f"Không tìm thấy file audio để upload: {fp}")
        raw_bytes = fp.read_bytes()
        cid = str(yt_cid or cookies.get("_ar_yt_cid") or "").strip()
        pid = str(page_id or cookies.get("_ar_page_id") or "").strip()
        clean_ck = {k: v for k, v in cookies.items() if not k.startswith("_ar_")}
        s_deleg = self._serialized_delegation_context(cid)

        last_err = ""
        for attempt in range(3):
            try:
                fname = f"file-{int(time.time() * 1000)}"
                f_uid = f"innertube_studio:{str(uuid.uuid4()).upper()}:0"
                h_start = _yt_sapisid_headers(clean_ck, origin="https://studio.youtube.com")
                h_start.update({
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    "Referer": "https://studio.youtube.com",
                    "x-goog-upload-command": "start",
                    "x-goog-upload-file-name": fname,
                    "x-goog-upload-protocol": "resumable",
                })
                if s_deleg:
                    h_start["X-YouTube-Delegation-Context"] = s_deleg
                if pid:
                    h_start["X-Goog-PageId"] = pid

                init_body = json.dumps({"frontendUploadId": f_uid}).encode("utf-8")
                req1 = urllib.request.Request(
                    "https://upload.youtube.com/upload/studio",
                    data=init_body,
                    headers=h_start,
                    method="POST",
                )
                with urllib.request.urlopen(req1, timeout=25) as r1:
                    upload_url = r1.headers.get("X-Goog-Upload-URL") or r1.headers.get("x-goog-upload-url") or ""
                if not upload_url:
                    raise RuntimeError("Scotty không trả về X-Goog-Upload-URL")

                h_up = _yt_sapisid_headers(clean_ck, origin="https://studio.youtube.com")
                h_up.update({
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    "Referer": "https://studio.youtube.com",
                    "x-goog-upload-command": "upload, finalize",
                    "x-goog-upload-file-name": fname,
                    "x-goog-upload-offset": "0",
                })
                if s_deleg:
                    h_up["X-YouTube-Delegation-Context"] = s_deleg
                if pid:
                    h_up["X-Goog-PageId"] = pid

                req2 = urllib.request.Request(upload_url, data=raw_bytes, headers=h_up, method="POST")
                with urllib.request.urlopen(req2, timeout=120) as r2:
                    up_json = json.loads(r2.read().decode("utf-8", errors="ignore") or "{}")

                rid = (
                    up_json.get("scottyResourceId")
                    or up_json.get("encryptedScottyResourceId")
                    or up_json.get("resourceId")
                    or (up_json.get("uploadStatus") or {}).get("scottyResourceId")
                    or ""
                )
                if rid:
                    return str(rid)
                last_err = f"Scotty response thiếu scottyResourceId: {str(up_json)[:200]}"
            except Exception as e:
                last_err = str(e)
                if "401" in last_err and attempt == 0 and cookies.get("_ar_acc_id"):
                    try:
                        with _DB_LOCK:
                            con = _db_conn()
                            try:
                                acc_r = con.execute("SELECT * FROM accounts WHERE id=?", (int(cookies["_ar_acc_id"]),)).fetchone()
                            finally:
                                con.close()
                        if acc_r:
                            fresh_ck = self._resolve_account_cookies(dict(acc_r), allow_playwright=True, force_refresh=True)
                            if fresh_ck:
                                cookies.update(fresh_ck)
                                clean_ck.update(fresh_ck)
                    except Exception:
                        pass
                if attempt < 2:
                    time.sleep(0.8 * (attempt + 1))
        raise RuntimeError(f"Upload Scotty thất bại: {last_err}")

    def _studio_add_audio_track(
        self,
        cookies: dict[str, str],
        page_id: str,
        video_id: str,
        language: str,
        scotty_resource_id: str,
        content_type: str = "AUDIO_TRACK_CONTENT_TYPE_DUBBED",
        yt_cid: str = "",
    ) -> dict:
        raw_lang = str(language or "").strip()
        base_lang = raw_lang.split("#")[0].strip()
        is_desc = raw_lang.lower().endswith("#d") or "descriptive" in str(content_type or "").lower()
        ct_str = "descriptive" if is_desc else "dubbed"
        clean_ck = {k: v for k, v in cookies.items() if not k.startswith("_ar_")}

        for attempt, force_grst in enumerate((False, True, True)):
            ctx = self._ar_prepare_mutation_ctx(cookies, page_id, yt_cid=yt_cid, force_grst=force_grst)
            payload = {
                "videoId": video_id,
                "resourceId": {"scottyResourceId": {"id": str(scotty_resource_id)}},
                "language": base_lang,
                "audioContentTypeString": ct_str,
                "audioTrackSource": "AUDIO_TRACK_SOURCE_CREATOR",
                "context": ctx,
            }
            try:
                res = self._studio_post("creator/add_audio_track", payload, clean_ck, page_id=page_id, timeout=30.0)
                if isinstance(res, dict) and not res.get("error"):
                    return res
            except Exception as e:
                if "429" in str(e) and attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                if attempt >= 2:
                    raise e
                time.sleep(0.6)
        return {}

    def _hitmakers_credentials(self, cfg: dict | None = None) -> tuple[str, str, str]:
        """Lấy thông tin đăng nhập Hitmakers từ config hoặc Windows Credential Manager."""
        c = cfg if cfg is not None else self._load_cfg()
        base_url = str(c.get("ar_hitmakers_url") or "https://tools.hitmakers.vip").strip().rstrip("/")
        user = str(c.get("ar_hitmakers_user") or "").strip()
        if not user:
            user = _win_cred_read("audio-repair:hitmakers:username@HDMaster.GoogleAccounts")
        pw = dpapi_unprotect(c.get("ar_hitmakers_pass_dpapi") or "")
        if not pw:
            pw = _win_cred_read("audio-repair:hitmakers:password@HDMaster.GoogleAccounts")
        return base_url, user.strip(), pw.strip()

    def _hitmakers_login(self, base_url: str, username: str, password: str, force: bool = False) -> str:
        """Đăng nhập Hitmakers API (/api/v1/login) lấy JWT token và cache 30 phút."""
        base_url = str(base_url or "https://tools.hitmakers.vip").strip().rstrip("/")
        if not username or not password:
            raise RuntimeError("Thiếu tài khoản hoặc mật khẩu Hitmakers.")
        ckey = (base_url, username)
        if not force:
            cached = self._hitmakers_token_cache.get(ckey)
            if cached and cached[0] and time.time() < cached[1]:
                return cached[0]
        body = json.dumps({"email": username, "password": password}).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url}/api/v1/login",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": _UA,
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as r:
            res = json.loads(r.read().decode("utf-8", errors="ignore") or "{}")
        tok = str(
            (res.get("user") or {}).get("token")
            or res.get("token")
            or res.get("access_token")
            or ""
        ).strip()
        if not tok:
            raise RuntimeError(str(res.get("message") or "Hitmakers không trả về token JWT"))
        self._hitmakers_token_cache[ckey] = (tok, time.time() + 1800)
        return tok

    def _hitmakers_lookup_video(
        self,
        con: sqlite3.Connection | None,
        video_id: str,
        channel_title: str = "",
        cfg: dict | None = None,
    ) -> dict:
        """Tra cứu crawled_video_id / path hint / duration từ DB nội bộ hoặc Hitmakers API."""
        vid = str(video_id or "").strip()
        if not vid:
            return {}
        if con is not None:
            for tbl in ("audio_repair_items", "audio_repair_jobs"):
                try:
                    row = con.execute(
                        f"SELECT hitmakers_local_id, hitmakers_channel_name, hitmakers_path_hint, hitmakers_duration FROM {tbl} WHERE studio_video_id=? AND hitmakers_local_id != '' LIMIT 1",
                        (vid,),
                    ).fetchone()
                    if row:
                        out = {
                            "hitmakers_local_id": str(row[0] or "").strip(),
                            "hitmakers_channel_name": str(row[1] or "").strip(),
                            "hitmakers_path_hint": str(row[2] or "").strip(),
                            "hitmakers_duration": float(row[3] or 0.0),
                        }
                        if out["hitmakers_local_id"]:
                            return out
                except Exception:
                    pass

        base_url, user, pw = self._hitmakers_credentials(cfg)
        if not (user and pw):
            return {}

        for attempt in range(2):
            try:
                tok = self._hitmakers_login(base_url, user, pw, force=(attempt > 0))
                url = f"{base_url}/api/v1/audio-subtitle-videos/{urllib.parse.quote(vid, safe='')}"
                req = urllib.request.Request(
                    url,
                    headers={
                        "Authorization": f"Bearer {tok}",
                        "Accept": "application/json",
                        "User-Agent": _UA,
                    },
                    method="GET",
                )
                with urllib.request.urlopen(req, timeout=15) as r:
                    raw = json.loads(r.read().decode("utf-8", errors="ignore") or "{}")
                obj = (
                    raw.get("data")
                    if isinstance(raw.get("data"), dict)
                    else (raw.get("video") if isinstance(raw.get("video"), dict) else raw)
                )
                if not isinstance(obj, dict):
                    return {}
                local_id = str(obj.get("crawled_video_id") or obj.get("local_video_id") or "").strip()
                ch_name = str(obj.get("channel_name") or "").strip()
                path_hint = str(obj.get("audio_subtitle_file_path") or "").strip()
                hdur = float(obj.get("duration") or 0.0)
                cuts = obj.get("studio_cut_segments")
                cuts_json = ""
                if isinstance(cuts, (list, dict)) and cuts:
                    cuts_json = json.dumps(cuts, ensure_ascii=False)
                elif isinstance(cuts, str) and cuts.strip():
                    cuts_json = cuts.strip()
                return {
                    "hitmakers_local_id": local_id,
                    "hitmakers_channel_name": ch_name,
                    "hitmakers_path_hint": path_hint,
                    "hitmakers_duration": hdur,
                    "cut_history_json": cuts_json,
                }
            except urllib.error.HTTPError as e:
                if e.code == 401 and attempt == 0:
                    continue
                return {}
            except Exception:
                return {}
        return {}

    def _studio_delete_video(self, cookies: dict[str, str], page_id: str, video_id: str) -> dict:
        return self._studio_post(
            "creator/delete_video",
            {"context": self._studio_context(page_id), "videoId": video_id},
            cookies, page_id=page_id, timeout=20.0,
        )

    def _studio_top_audio_langs(self, cookies: dict[str, str], page_id: str, yt_cid: str) -> list[str]:
        """Đọc Top geographies 28 ngày từ Studio Analytics (nếu có), map sang tối đa 2 mã ngôn ngữ."""
        country_lang = {
            "US": "en", "GB": "en", "CA": "en", "AU": "en",
            "MX": "es", "ES": "es", "AR": "es", "CO": "es", "CL": "es", "PE": "es",
            "BR": "pt", "PT": "pt", "FR": "fr", "DE": "de", "IT": "it",
            "ID": "id", "IN": "hi", "JP": "ja", "KR": "ko", "RU": "ru", "TR": "tr", "VN": "vi",
        }
        if cookies and yt_cid:
            try:
                end_d = datetime.now().strftime("%Y-%m-%d")
                start_d = (datetime.now() - timedelta(days=28)).strftime("%Y-%m-%d")
                res = self._studio_post(
                    "creator/get_creator_analytics",
                    {
                        "context": self._studio_context(page_id),
                        "channelId": yt_cid,
                        "queries": [{
                            "dimensions": ["COUNTRY"],
                            "metrics": ["VIEWS"],
                            "startDate": start_d,
                            "endDate": end_d,
                            "orderBy": [{"metric": "VIEWS", "descending": True}],
                            "maxResults": 5,
                        }],
                    },
                    cookies, page_id=page_id, timeout=12.0,
                )
                langs: list[str] = []
                raw_txt = json.dumps(res)
                for cc, lg in country_lang.items():
                    if f'"{cc}"' in raw_txt and lg not in langs:
                        langs.append(lg)
                    if len(langs) >= 2:
                        break
                if langs:
                    return langs
            except Exception:
                pass
        return ["en", "es"]

    def act_ar_scan(self, data):
        """Quét danh sách video lỗi Audio trực tiếp trên YouTube Studio (100% độc lập trong T2MG)."""
        cfg = self._load_cfg()
        cids = [int(x) for x in (data.get("channel_ids") or []) if int(x or 0) > 0]
        kinds = data.get("kinds") or cfg.get("ar_kinds") or ["public", "draft", "scheduled"]
        skip_over5 = bool(data.get("skip_over5_ok") if "skip_over5_ok" in data else cfg.get("ar_skip_over5_ok", False))
        roots_text = str(cfg.get("ar_source_roots") or "")
        live_studio = bool(data.get("live_studio", True))
        force_all = bool(data.get("force_all", False))

        with _DB_LOCK:
            con = _db_conn()
            try:
                # Bước 1: Đồng bộ ngay video lỗi Audio đã có trong channel_videos sang audio_repair_items
                self._sync_audio_repair_from_channel_videos(con, cids if cids else None)
                con.commit()

                if cids:
                    ph = ",".join("?" for _ in cids)
                    ch_rows = [dict(r) for r in con.execute(
                        f"SELECT * FROM channels WHERE id IN ({ph})", cids
                    ).fetchall()]
                else:
                    ch_rows = [dict(r) for r in con.execute(
                        "SELECT * FROM channels WHERE enabled=1"
                    ).fetchall()]
                acc_rows = {int(r["id"]): dict(r) for r in con.execute("SELECT * FROM accounts").fetchall()}
                acc_by_email = {str(r["email"] or "").strip().lower(): dict(r) for r in acc_rows.values() if r.get("email")}
                cv_counts = {
                    int(r[0]): int(r[1])
                    for r in con.execute("SELECT channel_id, COUNT(*) FROM channel_videos GROUP BY channel_id").fetchall()
                }
                cv_cids = set(cv_counts.keys())
                need_detail_cids = {
                    int(r[0]) for r in con.execute(
                        "SELECT DISTINCT channel_id FROM audio_repair_items WHERE bad_tracks_json IN ('', '[]', '{}') OR bad_tracks_json IS NULL"
                    ).fetchall()
                }
            finally:
                con.close()

        if not ch_rows:
            return {"ok": 1, "count": 0, "items": [], "skipped_over5_count": 0}

        if live_studio:
            if cids or force_all or len(ch_rows) <= 15:
                scan_targets = list(ch_rows)
            else:
                def _need_over200_rescan(c_row: dict) -> bool:
                    cid_i = int(c_row["id"])
                    if cv_counts.get(cid_i, 0) <= 200 and int(c_row.get("video_count") or 0) <= 200:
                        return False
                    try:
                        det = json.loads(c_row.get("detail_json") or "{}")
                        probed = int(det.get("audio_reject_scan_probed") or 0)
                    except Exception:
                        probed = 0
                    return probed <= 200

                scan_targets = [
                    c for c in ch_rows
                    if (int(c["id"]) not in cv_cids) or (int(c["id"]) in need_detail_cids) or _need_over200_rescan(c)
                ]

            if scan_targets:
                # Giải quyết cookie còn sống cho từng account & điền page_id còn thiếu
                acc_cookies: dict[tuple[int, str], dict[str, str]] = {}
                grouped: dict[tuple[int, str], list[dict]] = {}
                for c in scan_targets:
                    key = (int(c.get("account_id") or 0), str(c.get("account_email") or "").strip().lower())
                    grouped.setdefault(key, []).append(c)

                for key, ch_group in grouped.items():
                    aid, aem = key
                    acc_row = acc_rows.get(aid) or acc_by_email.get(aem)
                    if not acc_row and acc_rows:
                        acc_row = next(iter(acc_rows.values()))
                    ck, disc = self._ensure_valid_account_cookies(acc_row, allow_playwright=True) if acc_row else ({}, [])
                    acc_cookies[key] = ck
                    if ck and any(not str(r.get("page_id") or "").strip() for r in ch_group):
                        try:
                            if not disc:
                                disc = discover_account_channels_http(ck)
                            disc_map = {d["youtube_channel_id"]: d for d in disc}
                            with _DB_LOCK:
                                con = _db_conn()
                                try:
                                    for r in ch_group:
                                        dm = disc_map.get(r.get("youtube_channel_id") or "")
                                        if not dm:
                                            continue
                                        if not r.get("page_id") and dm.get("page_id"):
                                            r["page_id"] = dm["page_id"]
                                        if dm.get("title"):
                                            r["title"] = dm["title"]
                                        con.execute(
                                            "UPDATE channels SET page_id=CASE WHEN ?!='' THEN ? ELSE page_id END, title=CASE WHEN ?!='' THEN ? ELSE title END WHERE id=?",
                                            (r.get("page_id") or "", r.get("page_id") or "", r.get("title") or "", r.get("title") or "", r["id"]),
                                        )
                                    con.commit()
                                finally:
                                    con.close()
                        except Exception:
                            pass

                self._ar_scan_status = {
                    "running": True, "done": 0, "total": len(scan_targets), "found": 0,
                    "message": f"Đang quét trực tiếp Studio ({len(scan_targets)} kênh)...",
                }
                self.log(f"🔍 [Audio Repair] Quét độc lập YouTube Studio cho {len(scan_targets)} kênh ({', '.join(kinds)})...")

                lock = threading.Lock()

                def _scan_one(ch_row: dict):
                    key = (int(ch_row.get("account_id") or 0), str(ch_row.get("account_email") or "").strip().lower())
                    ck = acc_cookies.get(key) or {}
                    uc = str(ch_row.get("youtube_channel_id") or "").strip()
                    pid = str(ch_row.get("page_id") or "").strip()
                    if not ck or not uc.startswith("UC"):
                        with lock:
                            self._ar_scan_status["done"] += 1
                        return
                    try:
                        scan = self._scan_channel_studio_standalone(uc, pid, ck, deep_audio=True)
                        with _DB_LOCK:
                            wcon = _db_conn()
                            try:
                                self._persist_channel_studio_scan(
                                    wcon,
                                    int(ch_row.get("account_id") or 0),
                                    str(ch_row.get("account_email") or ""),
                                    ch_row,
                                    scan,
                                    deep_audio=True,
                                )
                                wcon.commit()
                            finally:
                                wcon.close()
                        found_cnt = len(scan.get("audio_repair_rows") or [])
                        with lock:
                            self._ar_scan_status["done"] += 1
                            self._ar_scan_status["found"] += found_cnt
                            self._ar_scan_status["message"] = (
                                f"Đã quét {self._ar_scan_status['done']}/{len(scan_targets)} kênh • {self._ar_scan_status['found']} video lỗi"
                            )
                    except Exception as e:
                        with lock:
                            self._ar_scan_status["done"] += 1
                        self.log(f"⚠️ [Audio Repair] Quét kênh {ch_row.get('title') or ch_row.get('id')} lỗi: {e}")

                with concurrent.futures.ThreadPoolExecutor(max_workers=min(6, max(1, len(scan_targets)))) as pool:
                    futs = [pool.submit(_scan_one, c) for c in scan_targets]
                    for fut in concurrent.futures.as_completed(futs):
                        fut.result()

        with _DB_LOCK:
            con = _db_conn()
            try:
                self._seed_standalone_audio_repair_knowledge(con, cfg)
                if cids:
                    ph = ",".join("?" for _ in cids)
                    raw_items = [dict(r) for r in con.execute(
                        f"SELECT * FROM audio_repair_items WHERE channel_id IN ({ph}) ORDER BY total_views DESC, id DESC", cids
                    ).fetchall()]
                else:
                    raw_items = [dict(r) for r in con.execute(
                        "SELECT * FROM audio_repair_items ORDER BY total_views DESC, id DESC LIMIT 10000"
                    ).fetchall()]

                ch_dirs = [dict(r) for r in con.execute("SELECT hitmakers_channel_name, crawl_dir FROM audio_repair_channel_dirs").fetchall()]
                idx_map = {str(r[0]): str(r[1]) for r in con.execute("SELECT local_id, source_path FROM audio_repair_source_index WHERE source_path != ''").fetchall()}
                src_index = self._build_local_audio_index(roots_text) if roots_text.strip() else None
                for it in raw_items:
                    if not it.get("source_path") or not Path(str(it["source_path"])).is_file():
                        found_src = self._resolve_local_audio_source(
                            it.get("studio_video_id") or "",
                            it.get("hitmakers_local_id") or "",
                            roots_text,
                            it.get("video_title") or "",
                            it.get("channel_title") or "",
                            index_cache=src_index,
                            con=con,
                            path_hint=it.get("hitmakers_path_hint") or "",
                            hitmakers_channel_name=it.get("hitmakers_channel_name") or "",
                            ch_dirs_cache=ch_dirs,
                            idx_map_cache=idx_map,
                        )
                        if found_src:
                            sdur = float(it.get("source_duration") or 0.0) or _probe_duration(found_src)
                            cur_st = str(it.get("status") or "").upper()
                            if cur_st in ("SUBMITTED", "SUBMITTED_WAIT", "DONE", "RUNNING"):
                                con.execute(
                                    "UPDATE audio_repair_items SET source_path=?, source_duration=? WHERE id=?",
                                    (found_src, sdur, it["id"]),
                                )
                            else:
                                con.execute(
                                    "UPDATE audio_repair_items SET source_path=?, source_duration=?, status='READY', stage='Đã tìm thấy nguồn' WHERE id=?",
                                    (found_src, sdur, it["id"]),
                                )
                                it["status"] = "READY"
                            it["source_path"] = found_src
                            it["source_duration"] = sdur
                con.commit()
            finally:
                con.close()

        kind_set = {str(k).lower() for k in kinds}
        filtered: list[dict] = []
        skipped_over5 = 0
        for it in raw_items:
            if kind_set and str(it.get("video_kind") or "public").lower() not in kind_set:
                continue
            if skip_over5 and int(it.get("audio_processed") or 0) > 5:
                skipped_over5 += 1
                continue
            filtered.append(it)

        self._ar_scan_status["running"] = False
        self._ar_scan_status["message"] = f"Quét xong {len(ch_rows)} kênh • {len(filtered)} video cần sửa"
        self.log(f"✅ [Audio Repair] Đã quét xong {len(ch_rows)} kênh • {len(filtered)} video cần sửa (bỏ qua {skipped_over5} video >5 Audio OK).")
        return {"ok": 1, "count": len(filtered), "items": filtered, "skipped_over5_count": skipped_over5, "scan": self._ar_scan_status}

    @staticmethod
    def _build_local_audio_index(roots_text: str) -> dict:
        """Lập chỉ mục nhanh các thư mục Nguồn ID 2-3 tầng (<root>/<id>/audio.* và <root>/<kênh>/<id>/audio.*)."""
        by_id: dict[str, str] = {}
        by_title: list[tuple[str, str, str]] = []  # (norm_dir_channel, norm_title, path)
        roots = [Path(line.strip()) for line in str(roots_text or "").splitlines() if line.strip()]
        exts = (".mp3", ".m4a", ".wav", ".aac", ".mp4")

        def _pick_audio_in_dir(d: Path) -> str:
            for ext in exts:
                p = d / f"audio{ext}"
                if p.is_file():
                    return str(p)
            try:
                for f in d.iterdir():
                    if f.is_file() and f.suffix.lower() in exts:
                        return str(f)
            except OSError:
                pass
            return ""

        def _extract_dir_title(d: Path) -> str:
            # 1) Thử đọc data.json nếu có
            dj = d / "data.json"
            if dj.is_file():
                try:
                    raw = dj.read_text(encoding="utf-8", errors="ignore")[:8000]
                    m = re.search(r'"title"\s*:\s*"([^"]{4,300})"', raw)
                    if m:
                        return m.group(1)
                except OSError:
                    pass
            # 2) File tên tiêu đề không đuôi hoặc tên audio khác 'audio'
            try:
                for f in d.iterdir():
                    nm = f.name
                    if f.is_file() and not f.suffix and len(nm) >= 6:
                        return nm
            except OSError:
                pass
            return ""

        for r in roots:
            try:
                if not r.is_dir():
                    continue
                for sub in r.iterdir():
                    if sub.is_file() and sub.suffix.lower() in exts:
                        stem_l = sub.stem.lower()
                        by_id.setdefault(stem_l, str(sub))
                        nt = re.sub(r"[^a-z0-9]+", "", stem_l)
                        if len(nt) >= 8:
                            by_title.append(("", nt, str(sub)))
                    elif sub.is_dir():
                        ap = _pick_audio_in_dir(sub)
                        if ap:
                            by_id.setdefault(sub.name.lower(), ap)
                            t_raw = _extract_dir_title(sub)
                            nt = re.sub(r"[^a-z0-9]+", "", (t_raw or sub.name).lower())
                            if len(nt) >= 8:
                                by_title.append((re.sub(r"[^a-z0-9]+", "", r.name.lower()), nt, ap))
                        else:
                            # Tầng 3: <root>/<thư_mục_kênh>/<local_id>/audio.*
                            ch_norm = re.sub(r"[^a-z0-9]+", "", sub.name.lower())
                            for nested in sub.iterdir():
                                if nested.is_dir():
                                    ap2 = _pick_audio_in_dir(nested)
                                    if ap2:
                                        by_id.setdefault(nested.name.lower(), ap2)
                                        t_raw = _extract_dir_title(nested)
                                        nt = re.sub(r"[^a-z0-9]+", "", (t_raw or nested.name).lower())
                                        if len(nt) >= 8:
                                            by_title.append((ch_norm, nt, ap2))
                                elif nested.is_file() and nested.suffix.lower() in exts:
                                    by_id.setdefault(nested.stem.lower(), str(nested))
            except OSError:
                pass
        return {"by_id": by_id, "by_title": by_title}

    def _resolve_local_audio_source(
        self,
        video_id: str,
        local_id: str,
        roots_text: str,
        video_title: str = "",
        channel_title: str = "",
        index_cache: dict | None = None,
        con: sqlite3.Connection | None = None,
        path_hint: str = "",
        hitmakers_channel_name: str = "",
        ch_dirs_cache: list[dict] | None = None,
        idx_map_cache: dict[str, str] | None = None,
    ) -> str:
        """Tìm file audio gốc chuẩn 3TMaster: DB source_index -> path_hint -> channel_dirs -> audio_roots -> index_cache."""
        keys = []
        for k in (local_id, video_id):
            ks = str(k or "").strip()
            if ks and ks not in keys:
                keys.append(ks)
        exts = (".mp3", ".m4a", ".wav", ".aac", ".mp4")
        norm_title = re.sub(r"[^\w]+", "", str(video_title or "").lower(), flags=re.UNICODE)
        norm_ch = re.sub(r"[^\w]+", "", str(channel_title or "").lower(), flags=re.UNICODE)
        norm_hm_ch = re.sub(r"[^\w]+", "", str(hitmakers_channel_name or "").lower(), flags=re.UNICODE)

        def _save_to_index(found_path: str, used_root: str = "") -> str:
            if con is not None and found_path:
                idx_key = str(local_id or video_id or "").strip()
                if idx_key:
                    try:
                        con.execute(
                            """
                            INSERT INTO audio_repair_source_index (local_id, source_path, root_path, hitmakers_channel_name, updated_at)
                            VALUES (?, ?, ?, ?, ?)
                            ON CONFLICT(local_id) DO UPDATE SET
                                source_path=excluded.source_path,
                                root_path=CASE WHEN excluded.root_path!='' THEN excluded.root_path ELSE root_path END,
                                hitmakers_channel_name=CASE WHEN excluded.hitmakers_channel_name!='' THEN excluded.hitmakers_channel_name ELSE hitmakers_channel_name END,
                                updated_at=excluded.updated_at
                            """,
                            (idx_key, found_path, used_root or str(Path(found_path).drive + os.sep), str(hitmakers_channel_name or ""), _now_iso()),
                        )
                    except Exception:
                        pass
            return found_path

        def _check_dir_for_keys(base_dir: Path, root_ref: str = "") -> str:
            try:
                if not base_dir.is_dir():
                    return ""
                for key in keys:
                    for ext in exts:
                        p_nested = base_dir / key / f"audio{ext}"
                        if p_nested.is_file():
                            return _save_to_index(str(p_nested), root_ref or str(base_dir))
                        p_flat = base_dir / f"{key}{ext}"
                        if p_flat.is_file():
                            return _save_to_index(str(p_flat), root_ref or str(base_dir))
                    sub_dir = base_dir / key
                    if sub_dir.is_dir():
                        for f in sub_dir.iterdir():
                            if f.is_file() and f.suffix.lower() in exts:
                                return _save_to_index(str(f), root_ref or str(base_dir))
            except OSError:
                pass
            return ""

        # 1. Tra cứu trong audio_repair_source_index trước
        if idx_map_cache:
            for k in keys:
                sp = str(idx_map_cache.get(k) or "").strip()
                if sp and Path(sp).is_file():
                    return sp
        elif con is not None and keys:
            for k in keys:
                try:
                    row = con.execute("SELECT source_path FROM audio_repair_source_index WHERE local_id=? LIMIT 1", (k,)).fetchone()
                    if row and row[0] and Path(str(row[0])).is_file():
                        return str(row[0])
                except Exception:
                    pass

        # 2. Kiểm tra gợi ý hitmakers_path_hint trực tiếp & trích xuất subfolder
        hint_raw = str(path_hint or "").strip().replace("/", os.sep)
        hint_sub_folder = ""
        hint_id_folder = ""
        if hint_raw:
            hp = Path(hint_raw)
            try:
                if hp.is_file():
                    return _save_to_index(str(hp), str(hp.drive + os.sep if hp.drive else hp.parent))
                if hp.parent.is_dir():
                    for ext in exts:
                        alt = hp.parent / f"audio{ext}"
                        if alt.is_file():
                            return _save_to_index(str(alt), str(hp.parent.parent))
            except OSError:
                pass
            parts = [p for p in hp.parts if p and not p.endswith(":\\") and not p.endswith(":")]
            if len(parts) >= 3:
                hint_sub_folder = parts[-3]
                hint_id_folder = parts[-2]
            elif len(parts) == 2:
                hint_id_folder = parts[-2]
            if hint_id_folder and hint_id_folder not in keys:
                keys.append(hint_id_folder)

        # 3. Quét theo audio_repair_channel_dirs (ưu tiên kênh khớp tên / slug trước)
        ch_dirs = ch_dirs_cache
        if ch_dirs is None and con is not None:
            try:
                ch_dirs = [dict(r) for r in con.execute("SELECT hitmakers_channel_name, crawl_dir FROM audio_repair_channel_dirs WHERE crawl_dir != ''").fetchall()]
            except Exception:
                ch_dirs = []
        if ch_dirs and keys:
            def _ch_score(entry: dict) -> tuple[int, str]:
                hslug = re.sub(r"[^\w]+", "", str(entry.get("hitmakers_channel_name") or "").lower(), flags=re.UNICODE)
                cdir_n = re.sub(r"[^\w]+", "", Path(str(entry.get("crawl_dir") or "")).name.lower(), flags=re.UNICODE)
                if norm_hm_ch and hslug and (norm_hm_ch == hslug or norm_hm_ch in hslug or hslug in norm_hm_ch):
                    return (0, cdir_n)
                if norm_ch and ((hslug and (norm_ch in hslug or hslug in norm_ch)) or (cdir_n and (norm_ch in cdir_n or cdir_n in norm_ch))):
                    return (1, cdir_n)
                if hint_sub_folder:
                    hn = re.sub(r"[^\w]+", "", hint_sub_folder.lower(), flags=re.UNICODE)
                    if hn and (hn in cdir_n or cdir_n in hn):
                        return (1, cdir_n)
                return (2, cdir_n)

            seen_dirs: set[str] = set()
            for entry in sorted(ch_dirs, key=_ch_score):
                cdir = str(entry.get("crawl_dir") or "").strip()
                if not cdir or cdir.lower() in seen_dirs:
                    continue
                seen_dirs.add(cdir.lower())
                hit = _check_dir_for_keys(Path(cdir), cdir)
                if hit:
                    return hit

        # 4. Quét các thư mục gốc trong audio_roots (trực tiếp, sub hint, 1-2 cấp, rồi index_cache)
        roots = [Path(line.strip()) for line in str(roots_text or "").splitlines() if line.strip()]
        for r in roots:
            try:
                if not r.exists():
                    continue
            except OSError:
                continue
            hit = _check_dir_for_keys(r, str(r))
            if hit:
                return hit
            if hint_sub_folder:
                hit_sub = _check_dir_for_keys(r / hint_sub_folder, str(r))
                if hit_sub:
                    return hit_sub
            try:
                subs = list(r.iterdir())
                if norm_ch or norm_hm_ch:
                    def _sub_prio(s: Path) -> int:
                        sn = re.sub(r"[^\w]+", "", s.name.lower(), flags=re.UNICODE)
                        if norm_hm_ch and sn and (norm_hm_ch in sn or sn in norm_hm_ch):
                            return 0
                        if norm_ch and sn and (norm_ch in sn or sn in norm_ch):
                            return 1
                        return 2
                    subs.sort(key=_sub_prio)
                for sub in subs:
                    if sub.is_file() and sub.suffix.lower() in exts:
                        sn = sub.stem.lower()
                        sn_norm = re.sub(r"[^\w]+", "", sn, flags=re.UNICODE)
                        if any(k.lower() in sn for k in keys) or (len(norm_title) >= 8 and norm_title[:24] in sn_norm):
                            return _save_to_index(str(sub), str(r))
                    elif sub.is_dir():
                        hit2 = _check_dir_for_keys(sub, str(r))
                        if hit2:
                            return hit2
                        for f in sub.iterdir():
                            if f.is_file() and f.suffix.lower() in exts:
                                fn = f.stem.lower()
                                fn_norm = re.sub(r"[^\w]+", "", fn, flags=re.UNICODE)
                                if any(k.lower() in fn for k in keys) or (len(norm_title) >= 8 and norm_title[:24] in fn_norm):
                                    return _save_to_index(str(f), str(r))
            except OSError:
                pass

        if index_cache is not None:
            by_id = index_cache.get("by_id") or {}
            for k in keys:
                hit = by_id.get(k.lower())
                if hit and Path(hit).is_file():
                    return _save_to_index(hit)
            if len(norm_title) >= 8:
                needle = norm_title[:28]
                fallback = ""
                for ch_dir, nt, ap in (index_cache.get("by_title") or []):
                    if needle in nt or nt[:28] in norm_title:
                        if norm_ch and ch_dir and (norm_ch in ch_dir or ch_dir in norm_ch):
                            return _save_to_index(ap)
                        if not fallback:
                            fallback = ap
                if fallback and Path(fallback).is_file():
                    return _save_to_index(fallback)
        return ""

    def act_ar_resolve(self, data):
        """Resolve Hitmakers ID + tìm file audio nguồn thực tế trên máy/LAN cho các video đã chọn."""
        video_ids = [str(x).strip() for x in (data.get("video_ids") or []) if str(x).strip()]
        cfg = self._load_cfg()
        roots_text = str(cfg.get("ar_source_roots") or "")

        with _DB_LOCK:
            con = _db_conn()
            try:
                self._seed_standalone_audio_repair_knowledge(con, cfg)
                if video_ids:
                    ph = ",".join("?" for _ in video_ids)
                    rows = [dict(r) for r in con.execute(
                        f"SELECT * FROM audio_repair_items WHERE studio_video_id IN ({ph})", video_ids
                    ).fetchall()]
                else:
                    rows = [dict(r) for r in con.execute(
                        "SELECT * FROM audio_repair_items ORDER BY total_views DESC, id DESC LIMIT 10000"
                    ).fetchall()]
                ch_dirs = [dict(r) for r in con.execute("SELECT hitmakers_channel_name, crawl_dir FROM audio_repair_channel_dirs WHERE crawl_dir != ''").fetchall()]
                idx_map = {str(r[0]): str(r[1]) for r in con.execute("SELECT local_id, source_path FROM audio_repair_source_index WHERE source_path != ''").fetchall()}
            finally:
                con.close()

        # Chỉ xây dựng index cache thư mục roots khi có item chưa nằm trong source_index
        need_disk_scan = any((not r.get("source_path") or not Path(str(r.get("source_path") or "")).is_file()) for r in rows)
        src_index = self._build_local_audio_index(roots_text) if (need_disk_scan and roots_text.strip()) else None

        hm_base, hm_user, hm_pw = self._hitmakers_credentials(cfg)
        can_hitmakers = bool(hm_user and hm_pw)

        def _resolve_one(it: dict) -> dict:
            vid = str(it.get("studio_video_id") or "").strip()
            loc_id = str(it.get("hitmakers_local_id") or "").strip()
            hm_ch = str(it.get("hitmakers_channel_name") or "").strip()
            path_hint = str(it.get("hitmakers_path_hint") or "").strip()
            hdur = float(it.get("hitmakers_duration") or 0.0)
            cuts_json = str(it.get("cut_history_json") or "").strip()
            src = str(it.get("source_path") or "").strip()
            has_file = bool(src and Path(src).is_file())

            # Bước 1: Nếu thiếu Hitmakers ID hoặc thiếu path_hint và chưa thấy file -> hỏi Hitmakers API
            if (not loc_id or (not has_file and not path_hint)) and can_hitmakers and vid:
                hm_info = self._hitmakers_lookup_video(None, vid, it.get("channel_title") or "", cfg=cfg)
                if hm_info:
                    loc_id = str(hm_info.get("hitmakers_local_id") or loc_id).strip()
                    hm_ch = str(hm_info.get("hitmakers_channel_name") or hm_ch).strip()
                    path_hint = str(hm_info.get("hitmakers_path_hint") or path_hint).strip()
                    if float(hm_info.get("hitmakers_duration") or 0.0) > 0:
                        hdur = float(hm_info["hitmakers_duration"])
                    if hm_info.get("cut_history_json") and not cuts_json:
                        cuts_json = str(hm_info["cut_history_json"])

            # Bước 2: Tìm file audio nguồn trên ổ đĩa/LAN
            if not has_file:
                src = self._resolve_local_audio_source(
                    vid,
                    loc_id,
                    roots_text,
                    it.get("video_title") or "",
                    it.get("channel_title") or "",
                    index_cache=src_index,
                    con=None,
                    path_hint=path_hint,
                    hitmakers_channel_name=hm_ch,
                    ch_dirs_cache=ch_dirs,
                    idx_map_cache=idx_map,
                )
                has_file = bool(src and Path(src).is_file())

            sdur = float(it.get("source_duration") or 0.0)
            if has_file and sdur <= 0.0:
                sdur = _probe_duration(src)

            cuts = _parse_cut_segments(cuts_json) if cuts_json else []
            cut_cnt = int(it.get("cut_event_count") or 0) or len(cuts)
            cut_sec = float(it.get("cut_removed_seconds") or 0.0) or round(sum(max(0.0, ce - cs) for cs, ce in cuts), 2)

            return {
                "id": it["id"],
                "studio_video_id": vid,
                "cur_status": str(it.get("status") or "").upper(),
                "hitmakers_local_id": loc_id,
                "hitmakers_channel_name": hm_ch,
                "hitmakers_path_hint": path_hint,
                "hitmakers_duration": hdur,
                "cut_history_json": cuts_json,
                "cut_event_count": cut_cnt,
                "cut_removed_seconds": cut_sec,
                "source_path": src if has_file else "",
                "source_duration": sdur,
                "has_file": has_file,
            }

        results: list[dict] = []
        workers = min(8, max(1, len(rows)))
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            futs = [pool.submit(_resolve_one, it) for it in rows]
            for fut in concurrent.futures.as_completed(futs):
                try:
                    results.append(fut.result())
                except Exception:
                    pass

        resolved, missing, hm_found = 0, 0, 0
        now_ts = _now_iso()
        with _DB_LOCK:
            con = _db_conn()
            try:
                for res in results:
                    cur_st = res["cur_status"]
                    if res["hitmakers_local_id"]:
                        hm_found += 1
                    if res["has_file"]:
                        resolved += 1
                        new_st = cur_st if cur_st in ("SUBMITTED", "SUBMITTED_WAIT", "DONE", "RUNNING") else "READY"
                        new_stage = "Đã Resolve nguồn" if new_st == "READY" else None
                        if new_stage:
                            con.execute(
                                """
                                UPDATE audio_repair_items SET
                                    hitmakers_local_id=?, hitmakers_channel_name=?, hitmakers_path_hint=?,
                                    hitmakers_duration=?, cut_history_json=CASE WHEN ?!='' THEN ? ELSE cut_history_json END,
                                    cut_event_count=?, cut_removed_seconds=?,
                                    source_path=?, source_duration=?, status=?, stage=?, error=''
                                WHERE id=?
                                """,
                                (
                                    res["hitmakers_local_id"], res["hitmakers_channel_name"], res["hitmakers_path_hint"],
                                    res["hitmakers_duration"], res["cut_history_json"], res["cut_history_json"],
                                    res["cut_event_count"], res["cut_removed_seconds"],
                                    res["source_path"], res["source_duration"], new_st, new_stage, res["id"],
                                ),
                            )
                        else:
                            con.execute(
                                """
                                UPDATE audio_repair_items SET
                                    hitmakers_local_id=?, hitmakers_channel_name=?, hitmakers_path_hint=?,
                                    hitmakers_duration=?, source_path=?, source_duration=?
                                WHERE id=?
                                """,
                                (
                                    res["hitmakers_local_id"], res["hitmakers_channel_name"], res["hitmakers_path_hint"],
                                    res["hitmakers_duration"], res["source_path"], res["source_duration"], res["id"],
                                ),
                            )
                        idx_k = res["hitmakers_local_id"] or res["studio_video_id"]
                        if idx_k:
                            con.execute(
                                """
                                INSERT INTO audio_repair_source_index (local_id, source_path, root_path, hitmakers_channel_name, updated_at)
                                VALUES (?, ?, ?, ?, ?)
                                ON CONFLICT(local_id) DO UPDATE SET
                                    source_path=excluded.source_path,
                                    hitmakers_channel_name=CASE WHEN excluded.hitmakers_channel_name!='' THEN excluded.hitmakers_channel_name ELSE hitmakers_channel_name END,
                                    updated_at=excluded.updated_at
                                """,
                                (idx_k, res["source_path"], str(Path(res["source_path"]).parent), res["hitmakers_channel_name"], now_ts),
                            )
                    else:
                        missing += 1
                        if cur_st not in ("SUBMITTED", "SUBMITTED_WAIT", "DONE", "RUNNING"):
                            err_msg = (
                                f"Đã có Hitmakers ID {res['hitmakers_local_id']} nhưng không thấy file audio trên máy/LAN"
                                if res["hitmakers_local_id"]
                                else "Chưa tìm thấy Hitmakers ID / file audio trong Nguồn ID"
                            )
                            con.execute(
                                """
                                UPDATE audio_repair_items SET
                                    hitmakers_local_id=?, hitmakers_channel_name=?, hitmakers_path_hint=?,
                                    hitmakers_duration=?, status='MISSING_SOURCE', stage='Thiếu file nguồn', error=?
                                WHERE id=?
                                """,
                                (
                                    res["hitmakers_local_id"], res["hitmakers_channel_name"], res["hitmakers_path_hint"],
                                    res["hitmakers_duration"], err_msg, res["id"],
                                ),
                            )
                con.commit()
            finally:
                con.close()

        self.log(f"🔎 [Audio Repair] Resolve xong: {resolved} READY • {missing} thiếu nguồn • {hm_found} có Hitmakers ID.")
        return {"ok": 1, "resolved": resolved, "missing": missing, "hitmakers_found": hm_found}

    def act_ar_status(self, data):
        """Trả về trạng thái quét, tiến trình chạy và danh sách Audio Repair mới nhất."""
        with _DB_LOCK:
            con = _db_conn()
            try:
                items = [dict(r) for r in con.execute("SELECT * FROM audio_repair_items ORDER BY total_views DESC, id DESC LIMIT 10000").fetchall()]
                jobs = [dict(r) for r in con.execute("SELECT * FROM audio_repair_jobs ORDER BY id DESC LIMIT 2000").fetchall()]
            finally:
                con.close()
        return {
            "ok": 1,
            "ar_running": self._ar_running,
            "scan": self._ar_scan_status,
            "run": self._ar_run_status,
            "items": items,
            "jobs": jobs,
        }

    def act_ar_run(self, data):
        """Chạy Re-Add Audio độc lập trên Studio (Multi-worker, Selective Delete, FFmpeg Baseline & Post-Add Verify)."""
        if self._ar_running and not self._ar_stop.is_set():
            return {"error": "Audio Repair đang chạy một tiến trình khác."}

        video_ids = [str(x).strip() for x in (data.get("video_ids") or []) if str(x).strip()]
        mode = str(data.get("mode") or "all").strip()
        cfg = self._load_cfg()
        delete_over5 = bool(cfg.get("ar_delete_over5", False))
        content_type_cfg = str(cfg.get("ar_content_type") or "global").strip().lower()
        roots_text = str(cfg.get("ar_source_roots") or "")

        self._ar_run_gen += 1
        my_gen = self._ar_run_gen
        self._ar_stop.clear()
        self._ar_running = True
        self.running = True
        self._reset_stuck_ar_items()

        def _is_cancelled() -> bool:
            return self._ar_stop.is_set() or (self._ar_run_gen != my_gen)

        def _update_item(vid: str, status: str, progress: int, stage: str, err: str = "", extra: dict | None = None):
            if _is_cancelled() and status in ("RUNNING", "RESOLVING", "VERIFYING_STUDIO", "PREPARING_AUDIO", "UPLOADING", "DELETING_OLD_AUDIO", "ADDING"):
                return
            with _DB_LOCK:
                con = _db_conn()
                try:
                    sets = ["status=?", "progress=?", "stage=?", "error=?"]
                    vals: list[Any] = [status, int(progress), stage, err]
                    if extra:
                        for k, v in extra.items():
                            sets.append(f"{k}=?")
                            vals.append(v)
                    vals.append(vid)
                    con.execute(f"UPDATE audio_repair_items SET {', '.join(sets)} WHERE studio_video_id=?", vals)
                    con.commit()
                finally:
                    con.close()

        def _worker():
            try:
                while not _is_cancelled():
                    with _DB_LOCK:
                        con = _db_conn()
                        try:
                            if video_ids:
                                ph = ",".join("?" for _ in video_ids)
                                rows = [dict(r) for r in con.execute(
                                    f"SELECT * FROM audio_repair_items WHERE studio_video_id IN ({ph})",
                                    video_ids,
                                ).fetchall()]
                            else:
                                rows = [dict(r) for r in con.execute(
                                    "SELECT * FROM audio_repair_items WHERE status IN ('CANDIDATE', 'READY', 'ERROR') ORDER BY total_views DESC, id DESC LIMIT 5000"
                                ).fetchall()]
                            ch_dirs = [dict(r) for r in con.execute("SELECT hitmakers_channel_name, crawl_dir FROM audio_repair_channel_dirs WHERE crawl_dir != ''").fetchall()]
                            idx_map = {str(r[0]): str(r[1]) for r in con.execute("SELECT local_id, source_path FROM audio_repair_source_index WHERE source_path != ''").fetchall()}
                        finally:
                            con.close()

                    if not rows:
                        self.log("⚠️ [Audio Repair] Không có video nào trong danh sách chọn để chạy.")
                        break

                    total = len(rows)
                    run_lock = threading.Lock()
                    channel_locks: dict[int, threading.Lock] = {}
                    state_cnt = {"done": 0, "succ": 0, "fail": 0}

                    if not _is_cancelled():
                        self._ar_run_status = {
                            "running": True,
                            "phase": "running",
                            "stage": f"Xếp hàng Studio • xử lý {total} video",
                            "percent": 2,
                            "total": total,
                            "done": 0,
                            "success": 0,
                            "failed": 0,
                            "message": f"Chế độ {mode} • {total} video",
                            "active": {},
                        }
                    self.log(
                        f"🚀 [Audio Repair] Bắt đầu chạy độc lập {total} video • Chế độ={mode} "
                        f"• Loại track={content_type_cfg} • Xóa >5 lần={'BẬT' if delete_over5 else 'TẮT'}"
                    )

                    need_disk_scan = any((not r.get("source_path") or not Path(str(r.get("source_path") or "")).is_file()) for r in rows)
                    run_src_index = self._build_local_audio_index(roots_text) if (need_disk_scan and roots_text.strip()) else None

                    def _set_active(vid: str, v_title: str, ch_title: str, stage_text: str, pct: int, remove: bool = False):
                        if _is_cancelled():
                            return
                        with run_lock:
                            active = self._ar_run_status.setdefault("active", {})
                            if remove:
                                active.pop(vid, None)
                            else:
                                active[vid] = {
                                    "video_id": vid,
                                    "title": v_title,
                                    "channel_title": ch_title,
                                    "stage": stage_text,
                                    "progress": int(pct),
                                }

                    def _finish_video(vid: str, ok_flag: bool):
                        if _is_cancelled():
                            return
                        with run_lock:
                            if ok_flag:
                                state_cnt["succ"] += 1
                            else:
                                state_cnt["fail"] += 1
                            state_cnt["done"] += 1
                            self._ar_run_status.setdefault("active", {}).pop(vid, None)
                            self._ar_run_status.update({
                                "done": state_cnt["done"],
                                "success": state_cnt["succ"],
                                "failed": state_cnt["fail"],
                                "percent": round(state_cnt["done"] * 100 / max(1, total)),
                                "stage": f"Đang xử lý {state_cnt['done']}/{total} video",
                                "message": f"Xong {state_cnt['done']}/{total} • {state_cnt['succ']} thành công, {state_cnt['fail']} lỗi",
                            })

                    def _get_ch_lock(cid: int) -> threading.Lock:
                        with run_lock:
                            lk = channel_locks.get(cid)
                            if lk is None:
                                lk = threading.Lock()
                                channel_locks[cid] = lk
                            return lk

                    def _process_one(idx: int, item: dict):
                        if _is_cancelled():
                            return
                        vid = str(item["studio_video_id"]).strip()
                        ch_id = int(item.get("channel_id") or 0)
                        ch_title = str(item.get("channel_title") or "")
                        v_title = str(item.get("video_title") or vid)
                        studio_dur = float(item.get("studio_duration") or 0.0)
                        attempts = int(item.get("readd_attempts") or 0) + 1
                        loc_id = str(item.get("hitmakers_local_id") or "").strip()
                        hm_ch = str(item.get("hitmakers_channel_name") or "").strip()
                        path_hint = str(item.get("hitmakers_path_hint") or "").strip()
                        hdur = float(item.get("hitmakers_duration") or 0.0)
                        cuts_json = str(item.get("cut_history_json") or "").strip()

                        try:
                            _set_active(vid, v_title, ch_title, "Lấy phiên YouTube Studio...", 8)
                            cookies, page_id, yt_cid, db_ch_title = self._ar_get_channel_auth(ch_id)
                            if not cookies:
                                err_m = "Thiếu cookie đăng nhập YouTube Studio cho kênh này."
                                _update_item(vid, "ERROR", 0, "Thiếu phiên Studio", err_m)
                                self.log(f"❌ [{idx}/{total}] {vid}: {err_m}")
                                _finish_video(vid, False)
                                return

                            if _is_cancelled():
                                return

                            if delete_over5 and attempts > 5:
                                _set_active(vid, v_title, ch_title, "Xóa video (>5 lần gỡ)...", 55)
                                _update_item(vid, "DELETING_OLD_AUDIO", 50, "Đang xóa video (>5 lần gỡ)...")
                                try:
                                    with _get_ch_lock(ch_id):
                                        self._studio_delete_video(cookies, page_id, vid)
                                    _update_item(vid, "DELETED_OVER5", 100, "Đã xóa tự động (>5 lần gỡ)", "", {"readd_attempts": attempts})
                                    self.log(f"🗑️ [SAFETY GATE delete_over5] Đã XÓA video {vid} ({ch_title}) khỏi Studio vì gỡ >5 lần.")
                                    _finish_video(vid, True)
                                except Exception as e:
                                    _update_item(vid, "ERROR", 0, "Xóa video lỗi", str(e))
                                    self.log(f"❌ [delete_over5] Lỗi xóa {vid}: {e}")
                                    _finish_video(vid, False)
                                return

                            _set_active(vid, v_title, ch_title, "Tìm nguồn & Hitmakers ID", 15)
                            _update_item(vid, "RESOLVING", 15, "Đang tìm nguồn audio...")
                            src_audio = str(item.get("source_path") or "").strip()
                            if (not loc_id or not src_audio or not Path(src_audio).is_file()):
                                if not loc_id or not path_hint:
                                    hm_info = self._hitmakers_lookup_video(None, vid, ch_title, cfg=cfg)
                                    if hm_info:
                                        loc_id = str(hm_info.get("hitmakers_local_id") or loc_id).strip()
                                        hm_ch = str(hm_info.get("hitmakers_channel_name") or hm_ch).strip()
                                        path_hint = str(hm_info.get("hitmakers_path_hint") or path_hint).strip()
                                        if float(hm_info.get("hitmakers_duration") or 0.0) > 0:
                                            hdur = float(hm_info["hitmakers_duration"])
                                        if hm_info.get("cut_history_json") and not cuts_json:
                                            cuts_json = str(hm_info["cut_history_json"])
                            if not src_audio or not Path(src_audio).is_file():
                                src_audio = self._resolve_local_audio_source(
                                    vid, loc_id, roots_text, v_title, ch_title,
                                    index_cache=run_src_index, con=None,
                                    path_hint=path_hint, hitmakers_channel_name=hm_ch,
                                    ch_dirs_cache=ch_dirs, idx_map_cache=idx_map,
                                )
                            if not src_audio or not Path(src_audio).is_file():
                                err_m = "Không tìm thấy file audio nguồn trong Nguồn ID."
                                _update_item(vid, "MISSING_SOURCE", 0, "Thiếu file nguồn", err_m, {
                                    "hitmakers_local_id": loc_id,
                                    "hitmakers_channel_name": hm_ch,
                                    "hitmakers_path_hint": path_hint,
                                    "hitmakers_duration": hdur,
                                })
                                self.log(f"⚠️ [{idx}/{total}] {vid}: {err_m}")
                                _finish_video(vid, False)
                                return

                            if _is_cancelled():
                                return

                            sdur = float(item.get("source_duration") or 0.0) or _probe_duration(src_audio)

                            _set_active(vid, v_title, ch_title, "Kiểm tra track Studio (#d vs dubbed)", 25)
                            _update_item(vid, "VERIFYING_STUDIO", 25, "Đang kiểm tra track trên Studio...")
                            live_tracks: list[dict] = []
                            live_ok = False
                            try:
                                live_tracks = self._studio_get_video_audio_tracks(cookies, page_id, vid, yt_cid=yt_cid)
                                live_ok = True
                            except Exception:
                                live_tracks = []

                            bad_statuses = {"AUDIO_TRACK_STATUS_REJECTED", "AUDIO_TRACK_STATUS_FAILED", "AUDIO_TRACK_STATUS_REMOVED"}
                            good_langs: list[str] = []
                            bad_tracks: list[dict] = []
                            for t in live_tracks:
                                st = str(t.get("status") or "").upper()
                                lg = _canonical_track_lang(t.get("language") or "", t)
                                ctype = "AUDIO_TRACK_CONTENT_TYPE_DESCRIPTIVE" if lg.endswith("#d") else "AUDIO_TRACK_CONTENT_TYPE_DUBBED"
                                if st == "AUDIO_TRACK_STATUS_PROCESSED":
                                    if lg and lg not in good_langs:
                                        good_langs.append(lg)
                                elif st in bad_statuses:
                                    bad_tracks.append({
                                        "audioTrackId": str(t.get("audioTrackId") or t.get("id") or "").strip(),
                                        "language": lg,
                                        "contentType": ctype,
                                        "status": st,
                                    })

                            if not live_ok:
                                try:
                                    cached_bad = json.loads(item.get("bad_tracks_json") or "[]")
                                    for bt in cached_bad:
                                        if isinstance(bt, dict):
                                            blg = _canonical_track_lang(bt.get("language") or "", bt)
                                            bct = "AUDIO_TRACK_CONTENT_TYPE_DESCRIPTIVE" if blg.endswith("#d") else "AUDIO_TRACK_CONTENT_TYPE_DUBBED"
                                            bt_norm = dict(bt)
                                            bt_norm["language"] = blg
                                            bt_norm["contentType"] = bct
                                            bad_tracks.append(bt_norm)
                                except Exception:
                                    pass
                                try:
                                    cached_good = json.loads(item.get("good_langs_json") or "[]")
                                    for gl in cached_good:
                                        gl_s = str(gl or "").strip()
                                        if gl_s and gl_s not in good_langs:
                                            good_langs.append(gl_s)
                                except Exception:
                                    pass

                            raw_langs = [x.strip() for x in str(item.get("repair_languages") or "").split(",") if x.strip()]
                            for bt in bad_tracks:
                                blg = str(bt.get("language") or "").strip()
                                if blg and blg not in raw_langs:
                                    raw_langs.append(blg)
                            raw_langs = list(dict.fromkeys(raw_langs))

                            good_set = set(good_langs)
                            is_alt = mode in ("alt_3s_7s", "alternating_pack")
                            if mode == "audience_top2":
                                top2 = self._studio_top_audio_langs(cookies, page_id, yt_cid)
                                target_langs = [lg for lg in top2 if lg not in good_set] or top2[:2]
                            elif is_alt:
                                pack = ["en", "es", "pt", "fr", "de", "it", "id", "hi", "ja", "ko", "ru", "tr"]
                                merged = list(dict.fromkeys(raw_langs + pack))
                                target_langs = [lg for lg in merged if lg not in good_set][:12]
                            else:
                                target_langs = [lg for lg in raw_langs if lg not in good_set]
                                if not target_langs and raw_langs:
                                    target_langs = list(raw_langs)
                                elif not target_langs:
                                    target_langs = ["es", "pt", "fr", "de"]

                            if content_type_cfg == "dubbed":
                                normalized_targets: list[str] = []
                                for lg in target_langs:
                                    b = lg.split("#")[0].strip()
                                    if b and b not in good_set and b not in normalized_targets:
                                        normalized_targets.append(b)
                                target_langs = normalized_targets or [lg.split("#")[0].strip() for lg in target_langs]
                            elif content_type_cfg == "descriptive":
                                normalized_targets = []
                                for lg in target_langs:
                                    dl = lg if lg.endswith("#d") else f"{lg.split('#')[0].strip()}#d"
                                    if dl not in good_set and dl not in normalized_targets:
                                        normalized_targets.append(dl)
                                target_langs = normalized_targets or [f"{lg.split('#')[0].strip()}#d" for lg in target_langs]
                            else:
                                dedup_targets: list[str] = []
                                for lg in target_langs:
                                    if lg and lg not in good_set and lg not in dedup_targets:
                                        dedup_targets.append(lg)
                                target_langs = (dedup_targets or target_langs)[:16]

                            if _is_cancelled():
                                return

                            _set_active(vid, v_title, ch_title, "Dựng audio baseline (FFmpeg)", 38)
                            _update_item(vid, "PREPARING_AUDIO", 38, "FFmpeg đang dựng audio chuẩn Studio...", extra={
                                "source_path": src_audio,
                                "source_duration": sdur,
                                "hitmakers_local_id": loc_id,
                                "hitmakers_channel_name": hm_ch,
                                "hitmakers_path_hint": path_hint,
                                "hitmakers_duration": hdur,
                            })
                            try:
                                normal_path, prepared_dur, timeline_note = _prepare_readd_audio_file(
                                    src_audio,
                                    studio_dur,
                                    video_id=vid,
                                    mode="all",
                                    cut_segments=cuts_json or None,
                                )
                                alt_path = ""
                                if is_alt and len(target_langs) > 2:
                                    alt_path, _, _ = _prepare_readd_audio_file(
                                        src_audio,
                                        studio_dur,
                                        video_id=vid,
                                        mode="alt_3s_7s",
                                        cut_segments=cuts_json or None,
                                    )
                            except Exception as e:
                                _update_item(vid, "ERROR", 0, "Lỗi FFmpeg", str(e))
                                self.log(f"❌ [{idx}/{total}] FFmpeg lỗi ({vid}): {e}")
                                _finish_video(vid, False)
                                return

                            if _is_cancelled():
                                return

                            # Upload Scotty song song (hỗ trợ hủy tức thì khi bấm Dừng)
                            _set_active(vid, v_title, ch_title, f"Upload Scotty ({len(target_langs)} track)...", 52)
                            _update_item(vid, "UPLOADING", 52, f"Đang upload {len(target_langs)} track lên Scotty...")
                            ctype_by_lang = {str(bt.get("language") or ""): str(bt.get("contentType") or "") for bt in bad_tracks}
                            lang_files: list[tuple[int, str, str, str]] = []
                            for li, lg in enumerate(target_langs):
                                if content_type_cfg == "descriptive" or lg.lower().endswith("#d"):
                                    ct = "AUDIO_TRACK_CONTENT_TYPE_DESCRIPTIVE"
                                elif content_type_cfg == "dubbed":
                                    ct = "AUDIO_TRACK_CONTENT_TYPE_DUBBED"
                                else:
                                    ct = ctype_by_lang.get(lg) or "AUDIO_TRACK_CONTENT_TYPE_DUBBED"
                                up_file = normal_path if (not is_alt or li < 2 or not alt_path) else alt_path
                                lang_files.append((li, lg, ct, up_file))

                            scotty_map: dict[int, str] = {}
                            up_pool = concurrent.futures.ThreadPoolExecutor(max_workers=min(4, max(1, len(lang_files))))
                            try:
                                def _upload_one(li_idx: int, file_p: str) -> str:
                                    if _is_cancelled():
                                        raise RuntimeError("CANCELLED")
                                    return self._studio_upload_audio_scotty(cookies, page_id, file_p, yt_cid=yt_cid)

                                fmap = {
                                    up_pool.submit(_upload_one, li, up_file): li
                                    for li, _lg, _ct, up_file in lang_files
                                }
                                done_up = 0
                                for fut in concurrent.futures.as_completed(fmap):
                                    if _is_cancelled():
                                        for f_rem in fmap:
                                            f_rem.cancel()
                                        return
                                    li = fmap[fut]
                                    scotty_map[li] = fut.result()
                                    done_up += 1
                                    pct_up = 52 + round(done_up * 10 / max(1, len(lang_files)))
                                    _set_active(vid, v_title, ch_title, f"Upload Scotty ({done_up}/{len(lang_files)} track)...", pct_up)
                            except Exception as e:
                                if _is_cancelled() or "CANCELLED" in str(e):
                                    return
                                _update_item(vid, "ERROR", 0, "Lỗi Upload Scotty", str(e))
                                self.log(f"❌ [{idx}/{total}] Upload Scotty lỗi ({vid}): {e}")
                                _finish_video(vid, False)
                                return
                            finally:
                                up_pool.shutdown(wait=False, cancel_futures=True)

                            if _is_cancelled():
                                return

                            # Phase Studio mutation dưới lock riêng theo từng kênh
                            _set_active(vid, v_title, ch_title, "Prewarm xong • chờ lượt Brand Channel", 62)
                            with _get_ch_lock(ch_id):
                                if _is_cancelled():
                                    return

                                _set_active(vid, v_title, ch_title, f"Xóa {len(bad_tracks)} track lỗi cũ...", 68)
                                _update_item(vid, "DELETING_OLD_AUDIO", 68, f"Đang xóa {len(bad_tracks)} track lỗi cũ...")
                                del_cnt = 0
                                for bt in bad_tracks:
                                    if _is_cancelled():
                                        return
                                    tid = str(bt.get("audioTrackId") or bt.get("id") or "").strip()
                                    if not tid:
                                        continue
                                    try:
                                        self._studio_delete_audio_track(cookies, page_id, vid, tid, yt_cid=yt_cid)
                                        del_cnt += 1
                                    except Exception as e:
                                        self.log(f"⚠️ [{vid}] Xóa track {tid} cảnh báo: {e}")

                                _set_active(vid, v_title, ch_title, f"Add {len(target_langs)} ngôn ngữ trên Studio...", 80)
                                _update_item(vid, "ADDING", 80, f"Đang Add {len(target_langs)} ngôn ngữ trên Studio...")
                                added_langs: list[str] = []
                                try:
                                    for li, lg, ct, _up_file in lang_files:
                                        if _is_cancelled():
                                            return
                                        sc_id = scotty_map[li]
                                        self._studio_add_audio_track(cookies, page_id, vid, lg, sc_id, content_type=ct, yt_cid=yt_cid)
                                        added_langs.append(lg)
                                except Exception as e:
                                    _update_item(vid, "ERROR", 0, "Lỗi Add Audio Studio", str(e), {"deleted_track_count": del_cnt})
                                    self.log(f"❌ [{idx}/{total}] Add Audio lỗi ({vid}): {e}")
                                    _finish_video(vid, False)
                                    return

                                # Post-add verify trực tiếp trên YouTube Studio
                                _set_active(vid, v_title, ch_title, "Xác minh lại track sau Re-Add...", 94)
                                verify_tag = "HTTP_ADD_VERIFIED"
                                try:
                                    after_tracks = self._studio_get_video_audio_tracks(cookies, page_id, vid, yt_cid=yt_cid)
                                    after_langs = {
                                        _canonical_track_lang(t.get("language") or "", t)
                                        for t in after_tracks
                                        if str(t.get("status") or "").upper() in (
                                            "AUDIO_TRACK_STATUS_PENDING",
                                            "AUDIO_TRACK_STATUS_PROCESSING",
                                            "AUDIO_TRACK_STATUS_PROCESSED",
                                        )
                                    }
                                    matched = sum(1 for lg in added_langs if lg in after_langs)
                                    verify_tag = f"HTTP_ADD_VERIFIED({matched}/{len(added_langs)})"
                                except Exception:
                                    verify_tag = "HTTP_ADD_SENT"

                            cuts = _parse_cut_segments(cuts_json) if cuts_json else []
                            cut_sec = round(sum(max(0.0, ce - cs) for cs, ce in cuts), 2) if cuts else float(item.get("cut_removed_seconds") or 0.0)
                            stage_msg = f"Đã submit • {len(added_langs)} ngôn ngữ • {timeline_note} • {verify_tag}"

                            _set_active(vid, v_title, ch_title, stage_msg, 100)
                            _update_item(
                                vid,
                                "SUBMITTED_WAIT",
                                100,
                                stage_msg,
                                "",
                                {
                                    "readd_attempts": attempts,
                                    "deleted_track_count": del_cnt,
                                    "source_path": src_audio,
                                    "source_duration": sdur,
                                    "good_langs_json": json.dumps(good_langs, ensure_ascii=False),
                                    "bad_tracks_json": "[]",
                                    "cut_removed_seconds": cut_sec,
                                },
                            )
                            now_ts = _now_iso()
                            with _DB_LOCK:
                                con = _db_conn()
                                try:
                                    con.execute(
                                        """
                                        INSERT INTO audio_repair_jobs (
                                            channel_id, channel_title, studio_video_id, video_title, video_kind,
                                            hitmakers_local_id, hitmakers_channel_name, hitmakers_path_hint, hitmakers_duration,
                                            studio_duration, source_path, source_duration, prepared_path, prepared_duration,
                                            cut_removed_seconds, languages_json, deleted_track_count, mode, content_type,
                                            attempt, status, progress, stage, readd_check_status, created_at, updated_at
                                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SUBMITTED_WAIT', 100, ?, 'PENDING', ?, ?)
                                        """,
                                        (
                                            ch_id, ch_title or db_ch_title, vid, v_title,
                                            str(item.get("video_kind") or "public"),
                                            loc_id, hm_ch, path_hint, hdur,
                                            studio_dur, src_audio, sdur, normal_path, prepared_dur,
                                            cut_sec, json.dumps(added_langs, ensure_ascii=False), del_cnt, mode, content_type_cfg,
                                            attempts, f"Đã xóa {del_cnt} track cũ • {verify_tag} • {', '.join(added_langs[:6])}",
                                            now_ts, now_ts,
                                        ),
                                    )
                                    if loc_id or vid:
                                        con.execute(
                                            """
                                            INSERT INTO audio_repair_source_index (local_id, source_path, root_path, hitmakers_channel_name, updated_at)
                                            VALUES (?, ?, ?, ?, ?)
                                            ON CONFLICT(local_id) DO UPDATE SET
                                                source_path=excluded.source_path,
                                                updated_at=excluded.updated_at
                                            """,
                                            (loc_id or vid, src_audio, str(Path(src_audio).parent), hm_ch, now_ts),
                                        )
                                    con.commit()
                                finally:
                                    con.close()

                            _finish_video(vid, True)
                            self.log(
                                f"✅ [{state_cnt['done']}/{total}] Re-Add xong {vid} ({ch_title}) • "
                                f"Xóa {del_cnt} track lỗi • {verify_tag} • {', '.join(added_langs)}"
                            )
                        except Exception as e:
                            if not _is_cancelled():
                                _update_item(vid, "ERROR", 0, "Lỗi Audio Repair", str(e))
                                self.log(f"❌ [{idx}/{total}] Lỗi bất ngờ ({vid}): {e}")
                                _finish_video(vid, False)

                    max_workers = min(4, max(1, len(rows)))
                    pool = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
                    try:
                        futs = [pool.submit(_process_one, idx, it) for idx, it in enumerate(rows, 1)]
                        for fut in concurrent.futures.as_completed(futs):
                            if _is_cancelled():
                                for f_rem in futs:
                                    f_rem.cancel()
                                break
                            try:
                                fut.result()
                            except Exception:
                                pass
                    finally:
                        pool.shutdown(wait=False, cancel_futures=True)

                    if _is_cancelled():
                        break

                    self._ar_run_status.update({
                        "running": False,
                        "phase": "done",
                        "stage": "Hoàn tất",
                        "percent": 100,
                        "active": {},
                        "message": f"Hoàn tất {state_cnt['succ']}/{total} video ({state_cnt['fail']} lỗi)",
                    })
                    self.log(f"🎉 [Audio Repair] Hoàn tất lượt chạy: {state_cnt['succ']} thành công, {state_cnt['fail']} lỗi.")

                    cur_cfg = self._load_cfg()
                    if not cur_cfg.get("ar_auto_enabled") or _is_cancelled() or video_ids:
                        break
                    self.log("🔁 [Audio Repair Auto] Đang chờ 10s để quét lại lượt tiếp theo...")
                    for _ in range(10):
                        if _is_cancelled():
                            break
                        time.sleep(1)
                    if _is_cancelled():
                        break
                    self.act_ar_scan({})
            finally:
                if self._ar_run_gen == my_gen:
                    self._ar_running = False
                    self._ar_run_status["running"] = False
                    self._ar_run_status["active"] = {}
                    self.running = self._cm_running
                    self._reset_stuck_ar_items()

        threading.Thread(target=_worker, daemon=True).start()
        return {"ok": 1, "started": True, "run": self._ar_run_status}

    def act_ar_readd_history_check(self, data):
        """Kiểm tra trực tiếp trên YouTube Studio xem video đã Re-Add còn bị lỗi/Reject lại không."""
        job_id = int(data.get("job_id") or 0)
        with _DB_LOCK:
            con = _db_conn()
            try:
                if job_id > 0:
                    jobs = [dict(r) for r in con.execute("SELECT * FROM audio_repair_jobs WHERE id=?", (job_id,)).fetchall()]
                else:
                    jobs = [dict(r) for r in con.execute("SELECT * FROM audio_repair_jobs ORDER BY id DESC LIMIT 100").fetchall()]
            finally:
                con.close()

        if not jobs:
            return {"error": "Không tìm thấy bản ghi Re-Add nào để kiểm tra."}

        checked = 0
        results = []
        for jb in jobs:
            vid = jb["studio_video_id"]
            cookies, page_id, yt_cid, _ = self._ar_get_channel_auth(int(jb.get("channel_id") or 0))
            if not cookies:
                st_res = "NO_COOKIE"
            else:
                try:
                    tracks = self._studio_get_video_audio_tracks(cookies, page_id, vid, yt_cid=yt_cid)
                    sts = [str(t.get("status") or "").upper() for t in tracks]
                    if any(s in ("AUDIO_TRACK_STATUS_REJECTED", "AUDIO_TRACK_STATUS_FAILED", "AUDIO_TRACK_STATUS_REMOVED") for s in sts):
                        st_res = "REJECTED_AGAIN"
                    elif any(s in ("AUDIO_TRACK_STATUS_PENDING", "AUDIO_TRACK_STATUS_PROCESSING") for s in sts):
                        st_res = "PROCESSING"
                    elif any(s == "AUDIO_TRACK_STATUS_PROCESSED" for s in sts):
                        st_res = "OK"
                    else:
                        st_res = "NO_TRACKS"
                except Exception as e:
                    st_res = f"ERR: {str(e)[:60]}"
            with _DB_LOCK:
                con = _db_conn()
                con.execute(
                    "UPDATE audio_repair_jobs SET readd_check_status=?, readd_checked_at=?, updated_at=? WHERE id=?",
                    (st_res, _now_iso(), _now_iso(), jb["id"]),
                )
                con.commit()
                con.close()
            checked += 1
            results.append({"job_id": jb["id"], "video_id": vid, "readd_check_status": st_res})
        self.log(f"🔎 [Audio Repair] Đã kiểm tra lại {checked} video đã Re-Add trên Studio.")
        return {"ok": 1, "checked": checked, "results": results}

    def act_ar_stop(self, data):
        self._ar_run_gen += 1
        self._ar_stop.set()
        self._ar_running = False
        self.running = self._cm_running
        reset_cnt = self._reset_stuck_ar_items()
        self._ar_run_status = {
            "running": False,
            "phase": "stopped",
            "stage": "Đã dừng",
            "percent": 0,
            "total": int(self._ar_run_status.get("total") or 0),
            "done": int(self._ar_run_status.get("done") or 0),
            "success": int(self._ar_run_status.get("success") or 0),
            "failed": int(self._ar_run_status.get("failed") or 0),
            "message": f"Đã dừng tiến trình • Reset {reset_cnt} video đang xử lý dở về sẵn sàng.",
            "active": {},
        }
        self.log(f"⏹️ [Audio Repair] Đã dừng ngay lập tức • Giải phóng khóa chạy (reset {reset_cnt} video dở dang).")
        return {"ok": 1, "ar_running": False, "run": self._ar_run_status}

    def act_ar_add_manual_item(self, data):
        """Cho phép thêm nhanh 1 video cần sửa Audio thủ công (dành cho máy độc lập)."""
        vid = str(data.get("studio_video_id") or "").strip()
        if not vid:
            return {"error": "Vui lòng nhập Video ID YouTube (11 ký tự)."}
        ch_title = str(data.get("channel_title") or "Kênh thủ công").strip()
        v_title = str(data.get("video_title") or vid).strip()
        dur = float(data.get("studio_duration") or 1800.0)
        src_path = str(data.get("source_path") or "").strip()
        langs = str(data.get("repair_languages") or "es, pt, fr, de, it").strip()
        sdur = 0.0
        if src_path and Path(src_path).is_file():
            sdur = _probe_duration(src_path)
            if dur <= 0:
                dur = sdur or 1800.0

        with _DB_LOCK:
            con = _db_conn()
            try:
                con.execute("""
                    INSERT INTO audio_repair_items (
                        channel_id, channel_title, studio_video_id, video_title, video_kind,
                        studio_duration, source_path, source_duration, issue_code, issue_label,
                        audio_rejected, repair_languages, status, stage, scanned_at
                    ) VALUES (0, ?, ?, ?, 'public', ?, ?, ?, 'REJECTED', 'Audio bị từ chối / gỡ', 1, ?, 'CANDIDATE', 'Sẵn sàng Re-Add', ?)
                    ON CONFLICT(channel_id, studio_video_id) DO UPDATE SET
                        video_title=excluded.video_title,
                        studio_duration=excluded.studio_duration,
                        source_path=excluded.source_path,
                        source_duration=excluded.source_duration,
                        repair_languages=excluded.repair_languages,
                        scanned_at=excluded.scanned_at
                """, (ch_title, vid, v_title, dur, src_path, sdur, langs, _now_iso()))
                con.commit()
            finally:
                con.close()
        self.log(f"➕ Đã thêm video {vid} ({v_title}) vào hàng đợi Audio Repair.")
        return {"ok": 1}

    def act_ar_cleanup_temp(self, data):
        """Dọn các file âm thanh tạm trong thư mục audio_repair_temp của T2MG (hỗ trợ preview)."""
        preview = bool((data or {}).get("preview", False))
        total_files, total_bytes, eligible_files, eligible_bytes, removed, freed_bytes = 0, 0, 0, 0, 0, 0
        now_t = time.time()
        if AUDIO_TEMP_DIR.is_dir():
            for f in AUDIO_TEMP_DIR.rglob("*"):
                if f.is_file() and f.suffix.lower() in (".m4a", ".mp3", ".wav", ".aac", ".tmp"):
                    try:
                        st = f.stat()
                        total_files += 1
                        total_bytes += st.st_size
                        is_old = (now_t - st.st_mtime) > 48 * 3600
                        if is_old or not preview:
                            eligible_files += 1
                            eligible_bytes += st.st_size
                            if not preview:
                                f.unlink()
                                removed += 1
                                freed_bytes += st.st_size
                    except OSError:
                        pass
        if preview:
            return {
                "ok": 1, "directory": str(AUDIO_TEMP_DIR),
                "total_files": total_files, "total_bytes": total_bytes,
                "eligible_files": eligible_files, "eligible_bytes": eligible_bytes,
            }
        mb = round(freed_bytes / 1048576, 2)
        self.log(f"♻️ [Audio Repair] Đã dọn {removed} file âm thanh tạm trong T2MG (giải phóng {mb} MB).")
        return {"ok": 1, "removed": removed, "freed_mb": mb}

    def act_ar_test_hitmakers(self, data):
        user = str(data.get("user") or "").strip()
        pw = str(data.get("pass") or "").strip()
        if user or pw:
            patch = {}
            if user:
                patch["ar_hitmakers_user"] = user
            if pw:
                patch["ar_hitmakers_pass"] = pw
            self._save_cfg(patch)
        cfg = self._load_cfg()
        url, saved_user, saved_pw = self._hitmakers_credentials(cfg)
        if not saved_user or not saved_pw:
            return {"ok": 0, "status": "CHƯA CÓ TÀI KHOẢN / MẬT KHẨU"}
        try:
            tok = self._hitmakers_login(url, saved_user, saved_pw, force=True)
            self.log(f"🟢 Đăng nhập Hitmakers JWT ({url}) thành công • {saved_user} (token {len(tok)} ký tự).")
            return {"ok": 1, "status": f"ONLINE • JWT OK • {saved_user}", "user": saved_user}
        except Exception as e:
            self.log(f"⚠️ Đăng nhập Hitmakers ({url}) thất bại ({saved_user}): {e}")
            return {"ok": 0, "status": f"LỖI ĐĂNG NHẬP ({e})", "user": saved_user}

    # ------------------------------------------------------------------
    # PHÂN HỆ 3B: API STUDIO VIDEO & THUMBNAIL TRỰC TIẾP (CHO THUMBNAIL STUDIO)
    # ------------------------------------------------------------------
    @staticmethod
    def _extract_yt_video_id(text: str) -> str:
        s = str(text or "").strip()
        if not s:
            return ""
        if re.fullmatch(r"[A-Za-z0-9_-]{11}", s):
            return s
        for pat in (
            r"[?&]v=([A-Za-z0-9_-]{11})",
            r"youtu\.be/([A-Za-z0-9_-]{11})",
            r"youtube\.com/(?:shorts|live|embed)/([A-Za-z0-9_-]{11})",
            r"studio\.youtube\.com/video/([A-Za-z0-9_-]{11})",
        ):
            m = re.search(pat, s)
            if m:
                return m.group(1)
        return ""

    @staticmethod
    def _pick_best_thumb_url(v: dict) -> tuple[str, list[dict]]:
        thumbs = ((v.get("thumbnailDetails") or {}).get("thumbnails") or [])
        norm: list[dict] = []
        for t in thumbs:
            if not isinstance(t, dict) or not t.get("url"):
                continue
            w = int(t.get("width") or 0)
            h = int(t.get("height") or 0)
            url = str(t["url"])
            is_jpg = ".jpg" in url.lower()
            norm.append({"url": url, "width": w, "height": h, "score": (w * h, 1 if is_jpg else 0)})
        norm.sort(key=lambda x: x["score"], reverse=True)
        vid = str(v.get("videoId") or "").strip()
        best = norm[0]["url"] if norm else (f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg" if vid else "")
        return best, [{"url": x["url"], "width": x["width"], "height": x["height"]} for x in norm]

    @staticmethod
    def _classify_studio_video(v: dict, ch_row: dict, now_sec: int | None = None) -> dict:
        now_sec = int(now_sec or time.time())
        vid = str(v.get("videoId") or "").strip()
        privacy = str(v.get("privacy") or "")
        draft_st = str(v.get("draftStatus") or "DRAFT_STATUS_NONE")
        is_draft = bool(draft_st and draft_st != "DRAFT_STATUS_NONE")
        sch_list = ((v.get("scheduledPublishingDetails") or {}).get("scheduledPublishings") or [])
        sch_ep = int(sch_list[0].get("scheduledTimeSeconds") or 0) if (not is_draft and sch_list) else 0
        pub_ep = int(v.get("timePublishedSeconds") or 0)
        cre_ep = int(v.get("timeCreatedSeconds") or 0)
        len_sec = int(v.get("lengthSeconds") or 0)
        vc = int(((v.get("metrics") or {}).get("viewCount") or 0))
        if is_draft:
            kind = "draft"
        elif sch_ep > 0:
            kind = "scheduled"
        elif privacy == "VIDEO_PRIVACY_PUBLIC":
            kind = "public"
        elif privacy == "VIDEO_PRIVACY_UNLISTED":
            kind = "unlisted"
        else:
            kind = "private"
        best_url, all_thumbs = YTStudioHub._pick_best_thumb_url(v)
        h_part, rem = divmod(len_sec, 3600)
        m_part, s_part = divmod(rem, 60)
        len_txt = f"{h_part}:{m_part:02d}:{s_part:02d}" if h_part else f"{m_part}:{s_part:02d}"
        return {
            "channel_id": int(ch_row.get("id") or 0),
            "channel_title": str(ch_row.get("title") or ""),
            "youtube_channel_id": str(ch_row.get("youtube_channel_id") or ""),
            "video_id": vid,
            "title": str(v.get("title") or vid),
            "privacy": privacy,
            "is_draft": is_draft,
            "kind": kind,
            "scheduled_epoch": sch_ep,
            "published_epoch": pub_ep,
            "created_epoch": cre_ep,
            "length_sec": len_sec,
            "length_text": len_txt,
            "view_count": vc,
            "thumbnail_url": best_url,
            "thumbnails": all_thumbs,
        }

    def studio_list_channels_for_thumb(self) -> list[dict]:
        """Lấy danh sách các kênh đã quét trong Channel Monitor / HUB_DB để chọn trong Thumbnail Studio."""
        with _DB_LOCK:
            con = _db_conn()
            try:
                rows = con.execute("""
                    SELECT id, account_id, account_email, youtube_channel_id, title, handle, avatar_url,
                           page_id, studio_session_status, session_status, subscriber_count, video_count,
                           scheduled_count, draft_total, views_48h, sampled_at
                    FROM channels
                    WHERE enabled = 1
                    ORDER BY views_48h DESC, scheduled_count DESC, title COLLATE NOCASE ASC
                """).fetchall()
                return [dict(r) for r in rows]
            finally:
                con.close()

    def _extract_yt_video_ids(self, raw_text: str) -> list[str]:
        """Trích xuất danh sách nhiều Video ID từ nhiều dòng / nhiều link / cách nhau bằng khoảng trắng hoặc dấu phẩy."""
        txt = str(raw_text or "").strip()
        if not txt:
            return []
        out: list[str] = []
        seen: set[str] = set()
        for token in re.split(r"[\r\n\t,; ]+", txt):
            t = token.strip()
            if not t:
                continue
            vid = self._extract_yt_video_id(t)
            if vid and vid not in seen:
                seen.add(vid)
                out.append(vid)
        return out

    def studio_list_videos_for_thumb(
        self, channel_id: int = 0, mode: str = "scheduled", video_query: str = "", limit: int = 120
    ) -> dict:
        """Quét video trực tiếp từ YouTube Studio cho Thumbnail Studio theo kênh & chế độ lọc hoặc 1/nhiều Video ID."""
        mode = str(mode or "scheduled").strip().lower()
        limit = max(1, min(300, int(limit or 120)))
        vid_queries = self._extract_yt_video_ids(video_query) if str(video_query or "").strip() else []
        if str(video_query or "").strip() and not vid_queries:
            return {"ok": 0, "error": "Video ID hoặc link YouTube không hợp lệ."}

        safe_mask = {
            "videoId": True,
            "channelId": True,
            "title": True,
            "privacy": True,
            "draftStatus": True,
            "status": True,
            "scheduledPublishingDetails": {"all": True},
            "timePublishedSeconds": True,
            "timeCreatedSeconds": True,
            "lengthSeconds": True,
            "metrics": {"all": True},
            "thumbnailDetails": {"all": True},
        }

        def _query_one_channel_by_vid(ch_r: dict, target_vid: str) -> dict | None:
            ak, pid, ycid, err = self._ar_get_channel_auth(int(ch_r["id"]), str(ch_r.get("account_email") or ""))
            if not ak or not ycid:
                return None
            clean_ck = {k: v for k, v in ak.items() if not k.startswith("_ar_")}
            ctx = self._studio_context(pid, ycid)
            res = self._studio_post(
                "creator/list_creator_videos",
                {
                    "context": ctx,
                    "failOnError": False,
                    "filter": {"and": {"operands": [{"videoIdIs": {"value": target_vid}}]}},
                    "mask": safe_mask,
                    "pageSize": 5,
                },
                clean_ck, page_id=pid, timeout=16.0,
            )
            vids = res.get("videos") or []
            if vids:
                return self._classify_studio_video(vids[0], ch_r)
            return None

        # Trường hợp tìm trực tiếp theo 1 hoặc nhiều Video ID / URL
        if vid_queries or mode == "video_id":
            if not vid_queries:
                return {"ok": 0, "error": "Vui lòng nhập ít nhất 1 Video ID hoặc URL YouTube."}
            with _DB_LOCK:
                con = _db_conn()
                try:
                    ch_rows = [dict(r) for r in con.execute("SELECT * FROM channels WHERE enabled=1 ORDER BY views_48h DESC, id ASC").fetchall()]
                    ph = ",".join("?" for _ in vid_queries)
                    db_hits_map: dict[str, list[int]] = {}
                    for r in con.execute(f"SELECT video_id, channel_id FROM channel_videos WHERE video_id IN ({ph})", vid_queries).fetchall():
                        v_k = str(r["video_id"] or "")
                        c_k = int(r["channel_id"] or 0)
                        if v_k and c_k:
                            db_hits_map.setdefault(v_k, [])
                            if c_k not in db_hits_map[v_k]:
                                db_hits_map[v_k].append(c_k)
                finally:
                    con.close()
            ch_map = {int(c["id"]): c for c in ch_rows}

            def _find_single_vid(target_vid: str) -> dict | None:
                cand_cids: list[int] = []
                if int(channel_id or 0) > 0:
                    cand_cids.append(int(channel_id))
                for cid_hit in db_hits_map.get(target_vid, []):
                    if cid_hit not in cand_cids:
                        cand_cids.append(cid_hit)
                for cid_try in cand_cids:
                    ch_r = ch_map.get(cid_try)
                    if not ch_r:
                        continue
                    try:
                        hit = _query_one_channel_by_vid(ch_r, target_vid)
                        if hit:
                            return hit
                    except Exception:
                        pass
                other_chs = [c for c in ch_rows if int(c["id"]) not in cand_cids][:45]
                if other_chs:
                    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as subpool:
                        futs = [subpool.submit(_query_one_channel_by_vid, c, target_vid) for c in other_chs]
                        for fut in concurrent.futures.as_completed(futs):
                            try:
                                hit = fut.result()
                                if hit:
                                    return hit
                            except Exception:
                                pass
                return None

            found_by_vid: dict[str, dict] = {}
            if len(vid_queries) == 1:
                h0 = _find_single_vid(vid_queries[0])
                if h0:
                    found_by_vid[vid_queries[0]] = h0
            else:
                with concurrent.futures.ThreadPoolExecutor(max_workers=min(6, len(vid_queries))) as pool:
                    fut_map = {pool.submit(_find_single_vid, v_id): v_id for v_id in vid_queries}
                    for fut, v_id in fut_map.items():
                        try:
                            h = fut.result()
                            if h:
                                found_by_vid[v_id] = h
                        except Exception:
                            pass

            found_videos = [found_by_vid[v_id] for v_id in vid_queries if v_id in found_by_vid]
            not_found = [v_id for v_id in vid_queries if v_id not in found_by_vid]
            if not found_videos:
                return {"ok": 0, "error": f"Không tìm thấy video nào ({', '.join(vid_queries[:5])}) trên các kênh đã liên kết."}
            counts = {"scheduled": 0, "public": 0, "draft": 0, "all": len(found_videos)}
            for fv in found_videos:
                k = str(fv.get("kind") or "public")
                counts[k] = counts.get(k, 0) + 1
            ch_info = None
            uniq_cids = {int(fv.get("channel_id") or 0) for fv in found_videos if fv.get("channel_id")}
            if len(uniq_cids) == 1:
                only_ch = ch_map.get(next(iter(uniq_cids)))
                if only_ch:
                    ch_info = {"id": only_ch["id"], "title": only_ch.get("title") or "", "youtube_channel_id": only_ch.get("youtube_channel_id") or ""}
            return {
                "ok": 1,
                "mode": "video_id",
                "channel": ch_info,
                "videos": found_videos,
                "not_found": not_found,
                "counts": counts,
            }

        # Trường hợp quét theo Kênh & loại Video (scheduled / public / draft / unlisted / all)
        if int(channel_id or 0) <= 0:
            return {"ok": 0, "error": "Vui lòng chọn 1 kênh để quét video."}

        with _DB_LOCK:
            con = _db_conn()
            try:
                ch_row = con.execute("SELECT * FROM channels WHERE id=?", (int(channel_id),)).fetchone()
                ch_dict = dict(ch_row) if ch_row else {}
                acc_row = con.execute("SELECT * FROM accounts WHERE email=?", (ch_dict.get("account_email") or "",)).fetchone() if ch_dict else None
                acc_dict = dict(acc_row) if acc_row else {}
            finally:
                con.close()

        if not ch_dict:
            return {"ok": 0, "error": f"Không tìm thấy kênh id={channel_id}."}

        ak, pid, ycid, err = self._ar_get_channel_auth(int(channel_id), str(ch_dict.get("account_email") or ""))
        if not ak or not ycid:
            return {"ok": 0, "error": f"Thiếu phiên Studio cho kênh: {err}"}
        clean_ck = {k: v for k, v in ak.items() if not k.startswith("_ar_")}
        ctx = self._studio_context(pid, ycid)

        all_raw: list[dict] = []
        tok = None
        for attempt in range(2):
            all_raw.clear()
            tok = None
            try:
                for _ in range(6):
                    body_v: dict = {
                        "context": ctx,
                        "failOnError": False,
                        "filter": {"and": {"operands": [{"channelIdIs": {"value": ycid}}]}},
                        "order": "VIDEO_ORDER_DISPLAY_TIME_DESC",
                        "pageSize": 100,
                        "mask": safe_mask,
                    }
                    if tok:
                        body_v["pageToken"] = tok
                    res = self._studio_post("creator/list_creator_videos", body_v, clean_ck, page_id=pid, timeout=18.0)
                    batch = res.get("videos") or []
                    all_raw.extend(batch)
                    tok = res.get("nextPageToken")
                    if not tok or not batch or len(all_raw) >= 500:
                        break
                break
            except Exception as e:
                if attempt == 0 and ("401" in str(e) or "403" in str(e)) and acc_dict:
                    ck_new, _ = self._ensure_valid_account_cookies(acc_dict, allow_playwright=True)
                    if ck_new:
                        clean_ck = ck_new
                        continue
                return {"ok": 0, "error": f"Lỗi tải danh sách video Studio: {e}"}

        now_sec = int(time.time())
        seen_ids: set[str] = set()
        items: list[dict] = []
        counts = {"scheduled": 0, "public": 0, "draft": 0, "unlisted": 0, "private": 0, "all": 0}
        for raw_v in all_raw:
            vid = str(raw_v.get("videoId") or "").strip()
            if not vid or vid in seen_ids:
                continue
            seen_ids.add(vid)
            item = self._classify_studio_video(raw_v, ch_dict, now_sec=now_sec)
            k = item["kind"]
            counts[k] = counts.get(k, 0) + 1
            counts["all"] += 1
            items.append(item)

        if mode == "all":
            filtered = items
        else:
            filtered = [x for x in items if x["kind"] == mode]

        if mode == "scheduled":
            filtered.sort(key=lambda x: (x["scheduled_epoch"] or 9999999999))
        elif mode == "public":
            filtered.sort(key=lambda x: -(x["published_epoch"] or x["created_epoch"] or 0))
        else:
            filtered.sort(key=lambda x: -(x["created_epoch"] or 0))

        return {
            "ok": 1,
            "mode": mode,
            "channel": {"id": ch_dict["id"], "title": ch_dict.get("title"), "youtube_channel_id": ycid},
            "counts": counts,
            "videos": filtered[:limit],
        }

    def studio_download_video_thumb(
        self, channel_id: int, video_id: str, thumb_url: str = "", dest_path: str = ""
    ) -> dict:
        """Tải thumbnail chất lượng cao nhất của video Studio về file cục bộ."""
        from PIL import Image
        vid = self._extract_yt_video_id(video_id)
        if not vid:
            return {"ok": 0, "error": "Video ID không hợp lệ."}
        cand_urls: list[str] = []
        if thumb_url:
            cand_urls.append(str(thumb_url).strip())

        if int(channel_id or 0) > 0:
            try:
                ak, pid, ycid, _ = self._ar_get_channel_auth(int(channel_id))
                if ak and ycid:
                    clean_ck = {k: v for k, v in ak.items() if not k.startswith("_ar_")}
                    res = self._studio_post(
                        "creator/list_creator_videos",
                        {
                            "context": self._studio_context(pid, ycid),
                            "failOnError": False,
                            "filter": {"and": {"operands": [{"videoIdIs": {"value": vid}}]}},
                            "mask": {"videoId": True, "thumbnailDetails": {"all": True}},
                            "pageSize": 2,
                        },
                        clean_ck, page_id=pid, timeout=15.0,
                    )
                    for v in (res.get("videos") or []):
                        _, all_t = self._pick_best_thumb_url(v)
                        for t in all_t:
                            if t["url"] not in cand_urls:
                                cand_urls.append(t["url"])
            except Exception:
                pass

        for u in (
            f"https://i.ytimg.com/vi/{vid}/maxresdefault.jpg",
            f"https://i.ytimg.com/vi/{vid}/sddefault.jpg",
            f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
        ):
            if u not in cand_urls:
                cand_urls.append(u)

        img_bytes = b""
        used_url = ""
        for u in cand_urls:
            try:
                req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
                b = urllib.request.urlopen(req, timeout=15.0).read()
                if len(b) > 1500:
                    img_bytes = b
                    used_url = u
                    break
            except Exception:
                continue

        if not img_bytes:
            return {"ok": 0, "error": f"Không tải được thumbnail của video {vid}."}

        im = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        w, h = im.size
        if dest_path:
            out_p = Path(dest_path)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            if out_p.suffix.lower() == ".png":
                im.save(out_p, format="PNG")
            else:
                im.save(out_p, format="JPEG", quality=94)
            return {"ok": 1, "path": str(out_p), "width": w, "height": h, "thumb_url": used_url}
        return {"ok": 1, "bytes": len(img_bytes), "width": w, "height": h, "thumb_url": used_url}

    def studio_upload_video_thumb(
        self, channel_id: int, video_id: str, image_path: str = "", image_bytes: bytes | None = None
    ) -> dict:
        """Upload & cập nhật trực tiếp custom thumbnail lên video trên YouTube Studio."""
        from PIL import Image
        vid = self._extract_yt_video_id(video_id)
        cid = int(channel_id or 0)
        if not vid or cid <= 0:
            return {"ok": 0, "error": "Thiếu channel_id hoặc video_id hợp lệ."}

        raw = image_bytes
        if not raw and image_path:
            raw = Path(image_path).read_bytes()
        if not raw:
            return {"ok": 0, "error": "Không có dữ liệu ảnh thumbnail để tải lên."}

        # Chuẩn hóa sang RGB JPEG <= 2.0MB theo giới hạn YouTube Studio
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        if im.width < 1280 or im.height < 720:
            im = im.resize((1280, 720), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        for q in (94, 88, 82, 74, 65):
            buf.seek(0)
            buf.truncate(0)
            im.save(buf, format="JPEG", quality=q, optimize=True)
            if buf.tell() <= 1_950_000:
                break
        if buf.tell() > 1_950_000:
            im = im.resize((1280, 720), Image.Resampling.LANCZOS)
            buf.seek(0)
            buf.truncate(0)
            im.save(buf, format="JPEG", quality=85, optimize=True)

        b64 = base64.b64encode(buf.getvalue()).decode("ascii")
        data_uri = f"data:image/jpeg;base64,{b64}"

        with _DB_LOCK:
            con = _db_conn()
            try:
                ch_r = con.execute("SELECT * FROM channels WHERE id=?", (cid,)).fetchone()
                ch_dict = dict(ch_r) if ch_r else {}
                acc_r = con.execute("SELECT * FROM accounts WHERE email=?", (ch_dict.get("account_email") or "",)).fetchone() if ch_dict else None
                acc_dict = dict(acc_r) if acc_r else {}
            finally:
                con.close()

        last_err = ""
        for attempt in range(2):
            ak, pid, ycid, err = self._ar_get_channel_auth(cid)
            if not ak or not ycid:
                last_err = err or "Thiếu phiên Studio"
                break
            clean_ck = {k: v for k, v in ak.items() if not k.startswith("_ar_")}
            try:
                ctx = self._ar_prepare_mutation_ctx(ak, pid, yt_cid=ycid, force_grst=(attempt > 0 or True))
                res = self._studio_post(
                    "video_manager/metadata_update",
                    {
                        "context": ctx,
                        "encryptedVideoId": vid,
                        "delegationContext": (ctx.get("user") or {}).get("delegationContext") or {"externalChannelId": ycid},
                        "videoStill": {
                            "operation": "UPLOAD_CUSTOM_THUMBNAIL",
                            "image": {"dataUri": data_uri},
                        },
                    },
                    clean_ck, page_id=pid, timeout=30.0,
                )
                vs_ok = bool((res.get("videoStill") or {}).get("success"))
                ov_code = str((res.get("overallResult") or {}).get("resultCode") or "")
                if vs_ok or ov_code == "UPDATE_SUCCESS":
                    new_thumb = ""
                    try:
                        vr = self._studio_post(
                            "creator/list_creator_videos",
                            {
                                "context": self._studio_context(pid, ycid),
                                "failOnError": False,
                                "filter": {"and": {"operands": [{"videoIdIs": {"value": vid}}]}},
                                "mask": {"videoId": True, "thumbnailDetails": {"all": True}},
                                "pageSize": 2,
                            },
                            clean_ck, page_id=pid, timeout=12.0,
                        )
                        if vr.get("videos"):
                            new_thumb, _ = self._pick_best_thumb_url(vr["videos"][0])
                    except Exception:
                        pass
                    self.log(f"🖼️ [Studio Thumbnail] Đã cập nhật thumbnail cho video {vid} ({ch_dict.get('title') or cid}).")
                    return {"ok": 1, "video_id": vid, "channel_id": cid, "thumbnail_url": new_thumb, "bytes": buf.tell()}
                last_err = f"Studio từ chối (resultCode={ov_code or 'UNKNOWN'})"
            except Exception as e:
                last_err = str(e)
                if attempt == 0 and ("401" in last_err or "403" in last_err) and acc_dict:
                    self._ar_grst_cache.clear()
                    ck_new, _ = self._ensure_valid_account_cookies(acc_dict, allow_playwright=True)
                    if ck_new:
                        continue
            break

        return {"ok": 0, "video_id": vid, "channel_id": cid, "error": last_err or "Upload thumbnail thất bại"}

    def act_ai_gateway_get(self, data=None):
        from core import ai_gateway
        return {"ok": 1, "gateway": ai_gateway.public_config()}

    def act_ai_gateway_save(self, data=None):
        from core import ai_gateway
        d = data or {}
        patch = {}
        for k in ("enabled", "base_url", "model", "timeout_sec"):
            if k in d:
                patch[k] = d[k]
        if "api_keys" in d and (str(d.get("api_keys") or "").strip() or d.get("clear_api_keys")):
            patch["api_keys"] = "" if d.get("clear_api_keys") else d["api_keys"]
        if "direct_gemini_keys" in d and (str(d.get("direct_gemini_keys") or "").strip() or d.get("clear_direct_keys")):
            patch["direct_gemini_keys"] = "" if d.get("clear_direct_keys") else d["direct_gemini_keys"]
        ai_gateway.save_config(patch)
        return {"ok": 1, "gateway": ai_gateway.public_config()}

    def act_ai_gateway_models(self, data=None):
        from core import ai_gateway
        d = data or {}
        try:
            models = ai_gateway.list_models(base_url=d.get("base_url"), api_key=d.get("api_key"))
            return {"ok": 1, "models": models}
        except Exception as e:
            return {"ok": 0, "error": str(e), "models": []}

    def act_ai_gateway_test(self, data=None):
        from core import ai_gateway
        d = data or {}
        return ai_gateway.test_connection(base_url=d.get("base_url"), api_key=d.get("api_key"), model=d.get("model"))

    def act_cm_ai_analyze(self, data):
        """Phân tích chuyên sâu & dự đoán xu hướng view 7 ngày tới qua AI Gateway (10Router) dùng chung."""
        from core import ai_gateway
        d = data or {}
        cid = int(d.get("channel_id") or 0)
        if cid <= 0:
            return {"ok": 0, "error": "Thiếu channel_id."}

        with _DB_LOCK:
            con = _db_conn()
            try:
                row = con.execute("SELECT * FROM channels WHERE id=?", (cid,)).fetchone()
                if not row:
                    return {"ok": 0, "error": f"Không tìm thấy kênh #{cid}."}
                ch = dict(row)
                tz_pst = timezone(timedelta(hours=-8))
                today_pst = datetime.now(tz_pst).date()
                cutoff_start = (today_pst - timedelta(days=28)).isoformat()
                today_pst_iso = today_pst.isoformat()
                daily_rows = [
                    {"date": str(r["day"]), "views": int(r["views"] or 0), "revenue": r["revenue"]}
                    for r in con.execute(
                        "SELECT day, views, revenue FROM channel_monitor_daily WHERE channel_id=? AND day >= ? AND day < ? ORDER BY day ASC",
                        (cid, cutoff_start, today_pst_iso),
                    ).fetchall()
                ]
            finally:
                con.close()

        try:
            s48 = json.loads(ch.get("views_48h_series_json") or "[]")
        except Exception:
            s48 = []
        s48_vals = [int(x or 0) for x in s48[-48:]]
        first_24 = sum(s48_vals[:24]) if len(s48_vals) >= 24 else 0
        last_24 = sum(s48_vals[-24:]) if s48_vals else int(ch.get("views_24h") or 0)
        last_6 = sum(s48_vals[-6:]) if len(s48_vals) >= 6 else 0
        prev_6 = sum(s48_vals[-12:-6]) if len(s48_vals) >= 12 else 0
        daily_compact = [f"{r['date'][5:]}:{r['views']}" for r in daily_rows[-14:]]

        prompt = (
            "Bạn là chuyên gia phân tích tăng trưởng kênh YouTube. Dựa trên số liệu thực tế sau đây, "
            "hãy dự đoán xu hướng lượt xem (tăng hay giảm) trong 7 ngày tới và trả về JSON thuần đúng cấu trúc:\n"
            '{"trend":"Tăng mạnh|Tăng|Ổn định|Giảm|Giảm mạnh","confidence":75,"forecast_7d_views":123456,'
            '"summary":"Nhận định ngắn gọn 1-2 câu tiếng Việt có số liệu","risks":["Rủi ro ngắn gọn"],"actions":["Hành động đề xuất ngắn gọn"]}\n\n'
            f"Kênh: {ch.get('title')} (ID: {ch.get('youtube_channel_id')})\n"
            f"- Subscribers: {ch.get('subscriber_count')} (7d: {ch.get('subscribers_7d')}, 28d: {ch.get('subscribers_28d')})\n"
            f"- Tổng view kênh: {ch.get('view_count')} | 28 ngày: {ch.get('views_28d')} | 7 ngày: {ch.get('views_7d')}\n"
            f"- 48 giờ: {ch.get('views_48h')} | 60 phút: {ch.get('views_60m')} | 24h gần nhất vs 24h trước: {last_24} vs {first_24} (thay đổi {ch.get('views_24h_change_pct')}%)\n"
            f"- 6h gần nhất vs 6h trước: {last_6} vs {prev_6}\n"
            f"- 14 ngày gần nhất (MM-DD:views): {', '.join(daily_compact) if daily_compact else 'Chưa có'}\n"
            f"- Kiếm tiền: {ch.get('monetization_status')} | Doanh thu 28d: ${ch.get('revenue_28d')} | RPM: ${ch.get('rpm_28d')}\n"
            f"- Kho lịch đăng còn: {ch.get('schedule_days_left')} ngày ({ch.get('scheduled_count')} video lên lịch) | Gậy: {ch.get('copyright_strikes')} | Lỗi audio: {ch.get('audio_rejected_count')}\n"
        )

        try:
            parsed, meta = ai_gateway.chat_json(prompt, temperature=0.25)
        except Exception as e:
            return {"ok": 0, "error": f"AI Gateway lỗi: {e}"}

        ai_res = {
            "trend": str(parsed.get("trend") or "Ổn định"),
            "confidence": max(0, min(100, int(parsed.get("confidence") or 70))),
            "forecast_7d_views": max(0, int(parsed.get("forecast_7d_views") or 0)),
            "summary": str(parsed.get("summary") or "").strip(),
            "risks": [str(x) for x in (parsed.get("risks") or [])[:3] if x],
            "actions": [str(x) for x in (parsed.get("actions") or [])[:3] if x],
            "provider": str((meta or {}).get("provider") or "10router"),
            "model": str((meta or {}).get("model") or ""),
            "analyzed_at": _now_iso(),
        }
        with _DB_LOCK:
            con = _db_conn()
            try:
                row = con.execute("SELECT detail_json FROM channels WHERE id=?", (cid,)).fetchone()
                try:
                    det_obj = json.loads((row["detail_json"] if row else "") or "{}")
                    if not isinstance(det_obj, dict):
                        det_obj = {}
                except Exception:
                    det_obj = {}
                det_obj["ai_analysis"] = ai_res
                con.execute("UPDATE channels SET detail_json=? WHERE id=?", (json.dumps(det_obj, ensure_ascii=False), cid))
                con.commit()
            finally:
                con.close()
        return {"ok": 1, "channel_id": cid, "ai_analysis": ai_res}

    # ------------------------------------------------------------------
    # PHÂN HỆ 4: CẤU HÌNH & ĐỒNG BỘ 3T MASTER
    # ------------------------------------------------------------------
    def act_save_config(self, data):
        cfg = self._save_cfg(data or {})
        self._sync_cm_auto_anchors(cfg, reset_next=True)
        self._cm_auto_wake.set()
        safe = dict(cfg)
        safe.pop("ar_hitmakers_pass_dpapi", None)
        return {"ok": 1, "config": safe, "cm_auto": self._get_cm_auto_meta(cfg)}

    def act_sync_3t(self, data):
        cfg = self._load_cfg()
        if data.get("t3_root"):
            cfg = self._save_cfg({"t3_root": str(data["t3_root"]).strip()})
        t3_root = _find_3t_root(cfg)
        port = int(cfg.get("t3_port") or 8891)
        stats = sync_from_3t_sqlite(t3_root, port)
        src_label = str(t3_root) if t3_root else f"127.0.0.1:{port}"
        self.log(
            f"🔄 Đã đồng bộ từ {src_label}: {stats['accounts']} Mail, {stats['channels']} Kênh, "
            f"{stats['ar_items']} Video lỗi Audio, {stats['ar_jobs']} Lịch sử Re-Add."
        )
        return {"ok": 1, "stats": stats, "root": str(t3_root or "")}

    def act_browse_folder(self, data):
        p = dialogs.pick_folder(str(data.get("title") or "Chọn thư mục"))
        return {"path": p or ""}

    def act_browse_file(self, data):
        p = dialogs.pick_file(str(data.get("title") or "Chọn file"))
        return {"path": p or ""}

    # ------------------------------------------------------------------
    # PHÂN HỆ 5: KHÁNG BẢN QUYỀN TỰ ĐỘNG (KHO GIẤY PHÉP + GÁN KÊNH)
    # ------------------------------------------------------------------
    def _cp_list_licenses(self) -> list[dict]:
        with _DB_LOCK:
            con = _db_conn()
            try:
                rows = [dict(r) for r in con.execute("SELECT * FROM copyright_licenses ORDER BY id DESC").fetchall()]
                cnts = {
                    int(r["license_id"] or 0): int(r["cnt"] or 0)
                    for r in con.execute(
                        "SELECT license_id, COUNT(*) AS cnt FROM channels WHERE COALESCE(license_id, 0) > 0 GROUP BY license_id"
                    ).fetchall()
                }
            finally:
                con.close()
        for r in rows:
            r["channel_count"] = cnts.get(int(r["id"]), 0)
        return rows

    def _cp_list_disputes(self, limit: int = 250) -> list[dict]:
        with _DB_LOCK:
            con = _db_conn()
            try:
                rows = [
                    dict(r)
                    for r in con.execute(
                        "SELECT * FROM copyright_disputes ORDER BY id DESC LIMIT ?", (int(limit),)
                    ).fetchall()
                ]
            finally:
                con.close()
        return rows

    def _cp_log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        with self._lock:
            logs = self._cp_status.setdefault("logs", [])
            logs.append(line)
            if len(logs) > 300:
                del logs[:-300]
        self.log(msg)

    @staticmethod
    def _cp_render_license_text(tpl: str, ctx: dict) -> str:
        text = str(tpl or "")
        repl = {
            "{channel_name}": str(ctx.get("channel_title") or ""),
            "{channel_id}": str(ctx.get("youtube_channel_id") or ""),
            "{video_id}": str(ctx.get("video_id") or ""),
            "{video_title}": str(ctx.get("video_title") or ""),
            "{claim_title}": str(ctx.get("claim_title") or ""),
            "{claimant}": str(ctx.get("claimant") or ""),
            "{date}": datetime.now().strftime("%Y-%m-%d"),
        }
        for k, v in repl.items():
            text = text.replace(k, v)
        return text.strip()

    @staticmethod
    def _cp_match_claimant_rule(claimant: str, claim_title: str, lic: dict) -> tuple[bool, str]:
        hay = f"{claimant or ''} {claim_title or ''}".lower()
        inc_raw = str(lic.get("include_claimants") or "").strip()
        exc_raw = str(lic.get("exclude_claimants") or "").strip()
        if inc_raw:
            inc_terms = [x.strip().lower() for x in re.split(r"[,;\n]+", inc_raw) if x.strip()]
            if inc_terms and not any(t in hay for t in inc_terms):
                return False, f"Chủ sở hữu/bài hát không nằm trong danh sách cho phép ({inc_raw})"
        if exc_raw:
            exc_terms = [x.strip().lower() for x in re.split(r"[,;\n]+", exc_raw) if x.strip()]
            for t in exc_terms:
                if t in hay:
                    return False, f"Nằm trong danh sách loại trừ ({t})"
        return True, ""

    def act_cp_save_license(self, data):
        lic_id = int(data.get("id") or 0)
        name = str(data.get("name") or "").strip()
        license_text = str(data.get("license_text") or "").strip()
        signature = str(data.get("signature") or "").strip()
        include_claimants = str(data.get("include_claimants") or "").strip()
        exclude_claimants = str(data.get("exclude_claimants") or "").strip()
        note = str(data.get("note") or "").strip()
        if not name:
            return {"error": "Vui lòng nhập Tên giấy phép."}
        if not license_text:
            return {"error": "Vui lòng nhập Nội dung giấy phép / giải trình."}
        if not signature:
            return {"error": "Vui lòng nhập Chữ ký (Họ tên) để điền ở bước Căn cứ."}
        now = _now_iso()
        with _DB_LOCK:
            con = _db_conn()
            try:
                if lic_id > 0:
                    con.execute(
                        """UPDATE copyright_licenses
                           SET name=?, license_text=?, signature=?, include_claimants=?, exclude_claimants=?, note=?, updated_at=?
                           WHERE id=?""",
                        (name, license_text, signature, include_claimants, exclude_claimants, note, now, lic_id),
                    )
                else:
                    cur = con.execute(
                        """INSERT INTO copyright_licenses
                           (name, license_text, signature, include_claimants, exclude_claimants, note, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (name, license_text, signature, include_claimants, exclude_claimants, note, now, now),
                    )
                    lic_id = int(cur.lastrowid or 0)
                con.commit()
            finally:
                con.close()
        self.log(f"📜 Đã lưu mẫu giấy phép bản quyền: {name}")
        return {"ok": 1, "id": lic_id, "licenses": self._cp_list_licenses()}

    def act_cp_delete_license(self, data):
        lic_id = int(data.get("id") or 0)
        if lic_id <= 0:
            return {"error": "Thiếu ID giấy phép."}
        with _DB_LOCK:
            con = _db_conn()
            try:
                con.execute("UPDATE channels SET license_id = 0 WHERE license_id = ?", (lic_id,))
                con.execute("DELETE FROM copyright_licenses WHERE id = ?", (lic_id,))
                con.commit()
            finally:
                con.close()
        self.log(f"🗑️ Đã xóa mẫu giấy phép #{lic_id}")
        return {"ok": 1, "licenses": self._cp_list_licenses()}

    def act_cp_assign_license(self, data):
        raw_ids = data.get("channel_ids") or []
        ch_ids = [int(x) for x in raw_ids if str(x).isdigit()]
        lic_id = int(data.get("license_id") or 0)
        if not ch_ids:
            return {"error": "Chưa chọn kênh nào để gán giấy phép."}
        with _DB_LOCK:
            con = _db_conn()
            try:
                if lic_id > 0:
                    chk = con.execute("SELECT id, name FROM copyright_licenses WHERE id = ?", (lic_id,)).fetchone()
                    if not chk:
                        return {"error": "Mẫu giấy phép không tồn tại."}
                    lic_name = str(chk["name"])
                else:
                    lic_name = "(Bỏ gán)"
                ph = ",".join("?" for _ in ch_ids)
                con.execute(f"UPDATE channels SET license_id = ?, updated_at = ? WHERE id IN ({ph})", [lic_id, _now_iso(), *ch_ids])
                con.commit()
            finally:
                con.close()
        self.log(f"📜 Đã gán giấy phép [{lic_name}] cho {len(ch_ids)} kênh.")
        return {"ok": 1, "updated": len(ch_ids), "license_id": lic_id, "licenses": self._cp_list_licenses()}

    def act_cp_scan_claims(self, data):
        """Quét danh sách video dính bản quyền trên các kênh (từ DB hoặc quét mới qua Studio HTTP API)."""
        raw_ids = data.get("channel_ids") or []
        ch_ids = [int(x) for x in raw_ids if str(x).isdigit()]
        only_licensed = bool(data.get("only_licensed", False))
        live_scan = bool(data.get("live_scan", False))
        include_private = bool(data.get("include_private", False))

        with _DB_LOCK:
            con = _db_conn()
            try:
                lic_map = {int(r["id"]): dict(r) for r in con.execute("SELECT * FROM copyright_licenses").fetchall()}
                if ch_ids:
                    ph = ",".join("?" for _ in ch_ids)
                    ch_rows = [dict(r) for r in con.execute(f"SELECT * FROM channels WHERE id IN ({ph})", ch_ids).fetchall()]
                elif only_licensed:
                    ch_rows = [dict(r) for r in con.execute("SELECT * FROM channels WHERE COALESCE(license_id, 0) > 0 ORDER BY copyright_claims DESC, id ASC").fetchall()]
                else:
                    ch_rows = [
                        dict(r)
                        for r in con.execute(
                            "SELECT * FROM channels WHERE COALESCE(license_id, 0) > 0 OR COALESCE(copyright_claims, 0) > 0 ORDER BY copyright_claims DESC, id ASC"
                        ).fetchall()
                    ]
                acc_map = {
                    str(r["email"] or "").lower(): dict(r)
                    for r in con.execute("SELECT * FROM accounts").fetchall()
                }
            finally:
                con.close()

        # Nếu yêu cầu quét tươi từ Studio HTTP API -> làm mới video bản quyền của các kênh mục tiêu
        live_refreshed = 0
        if live_scan and ch_rows:
            by_email: dict[str, list[dict]] = {}
            for ch in ch_rows:
                em = str(ch.get("account_email") or "").lower()
                by_email.setdefault(em, []).append(ch)
            for em, group in by_email.items():
                acc = acc_map.get(em)
                if not acc:
                    continue
                ck, disc = self._ensure_valid_account_cookies(acc, allow_playwright=False)
                if not ck:
                    continue
                disc_by_uc = {str(d.get("uc") or ""): d for d in (disc or []) if d.get("uc")}
                for ch in group:
                    uc = str(ch.get("youtube_channel_id") or "").strip()
                    if not uc:
                        continue
                    dinfo = disc_by_uc.get(uc) or {}
                    pid = "" if dinfo.get("is_main") else str(dinfo.get("page_id") or ch.get("page_id") or "").strip()
                    try:
                        scan = self._scan_channel_studio_standalone(uc, page_id=pid, cookies=ck, deep_audio=False)
                        if (not scan or scan.get("stats_source") != "studio_innertube_standalone") and pid:
                            scan = self._scan_channel_studio_standalone(uc, page_id="", cookies=ck, deep_audio=False)
                        if scan and scan.get("video_rows") is not None:
                            with _DB_LOCK:
                                wcon = _db_conn()
                                try:
                                    self._persist_channel_studio_scan(
                                        wcon,
                                        int(ch.get("account_id") or 0),
                                        str(ch.get("account_email") or ""),
                                        ch,
                                        scan,
                                        deep_audio=False,
                                    )
                                    wcon.commit()
                                finally:
                                    wcon.close()
                            live_refreshed += 1
                    except Exception:
                        pass

        target_cids = [int(c["id"]) for c in ch_rows]
        ch_by_id = {int(c["id"]): c for c in ch_rows}
        items: list[dict] = []
        if target_cids:
            vis_filter = (
                ""
                if include_private
                else " AND (is_draft = 1 OR COALESCE(scheduled_epoch, 0) > 0 OR UPPER(COALESCE(privacy, '')) = 'VIDEO_PRIVACY_PUBLIC')"
            )
            with _DB_LOCK:
                con = _db_conn()
                try:
                    ph = ",".join("?" for _ in target_cids)
                    v_rows = [
                        dict(r)
                        for r in con.execute(
                            f"""SELECT * FROM channel_videos
                                WHERE channel_id IN ({ph})
                                  AND COALESCE(copyright_state, '') != ''
                                  AND UPPER(COALESCE(copyright_state, '')) != 'NONE'
                                  {vis_filter}
                                ORDER BY channel_id ASC, is_draft ASC, id DESC""",
                            target_cids,
                        ).fetchall()
                    ]
                    disp_rows = [
                        dict(r)
                        for r in con.execute(
                            f"SELECT * FROM copyright_disputes WHERE channel_id IN ({ph}) ORDER BY id DESC",
                            target_cids,
                        ).fetchall()
                    ]
                finally:
                    con.close()

            latest_disp_by_vid: dict[str, dict] = {}
            for d in disp_rows:
                vid = str(d.get("video_id") or "")
                if vid and vid not in latest_disp_by_vid:
                    latest_disp_by_vid[vid] = d

            for v in v_rows:
                cid = int(v.get("channel_id") or 0)
                ch = ch_by_id.get(cid) or {}
                vid = str(v.get("video_id") or "").strip()
                if not vid:
                    continue
                lic_id = int(ch.get("license_id") or 0)
                lic = lic_map.get(lic_id)
                disp = latest_disp_by_vid.get(vid) or {}
                d_st = str(disp.get("status") or "").upper()
                if d_st == "SUBMITTED":
                    ready_state = "ALREADY_DISPUTED"
                elif lic:
                    ready_state = "READY"
                else:
                    ready_state = "NO_LICENSE"
                priv_raw = str(v.get("privacy") or v.get("visibility") or "").upper()
                if int(v.get("is_draft") or 0) == 1:
                    vis_lbl = "Nháp"
                elif int(v.get("scheduled_epoch") or 0) > 0:
                    vis_lbl = "Đặt lịch"
                elif priv_raw == "VIDEO_PRIVACY_PUBLIC":
                    vis_lbl = "Công khai"
                elif priv_raw == "VIDEO_PRIVACY_PRIVATE":
                    vis_lbl = "Riêng tư"
                elif priv_raw == "VIDEO_PRIVACY_UNLISTED":
                    vis_lbl = "Không công khai"
                else:
                    vis_lbl = priv_raw.replace("VIDEO_PRIVACY_", "")
                items.append({
                    "channel_id": cid,
                    "youtube_channel_id": str(ch.get("youtube_channel_id") or ""),
                    "channel_title": str(ch.get("title") or ch.get("youtube_channel_id") or ""),
                    "account_email": str(ch.get("account_email") or ""),
                    "page_id": str(ch.get("page_id") or ""),
                    "video_id": vid,
                    "video_title": str(v.get("title") or vid),
                    "visibility": vis_lbl,
                    "copyright_state": str(v.get("copyright_state") or "CLAIM"),
                    "license_id": lic_id,
                    "license_name": str(lic["name"]) if lic else "",
                    "ready_state": ready_state,
                    "dispute_status": d_st or "NONE",
                    "dispute_message": str(disp.get("message") or ""),
                    "disputed_at": str(disp.get("disputed_at") or ""),
                    "studio_url": f"https://studio.youtube.com/video/{vid}/copyright",
                })

        return {
            "ok": 1,
            "items": items,
            "live_refreshed": live_refreshed,
            "summary": {
                "total": len(items),
                "ready": sum(1 for x in items if x["ready_state"] == "READY"),
                "no_license": sum(1 for x in items if x["ready_state"] == "NO_LICENSE"),
                "disputed": sum(1 for x in items if x["ready_state"] == "ALREADY_DISPUTED"),
            },
        }

    def act_cp_dispute_status(self, data):
        return {
            "ok": 1,
            "status": dict(self._cp_status),
            "disputes": self._cp_list_disputes(limit=250),
        }

    def act_cp_stop_dispute(self, data):
        self._cp_stop.set()
        self._cp_log("⏹ Đã yêu cầu dừng tiến trình kháng bản quyền...")
        return {"ok": 1}

    def act_cp_run_dispute(self, data):
        if self._cp_running:
            return {"error": "Đang có tiến trình kháng bản quyền chạy."}
        raw_items = data.get("items") or []
        if not raw_items:
            return {"error": "Chưa chọn video nào để kháng bản quyền."}
        dry_run = bool(data.get("dry_run", True))
        headless = False if dry_run else bool(data.get("headless", False))
        try:
            delay_sec = max(1.0, min(30.0, float(data.get("delay_sec") or 4.0)))
        except Exception:
            delay_sec = 4.0
        try:
            workers = max(1, min(6, int(data.get("workers") or 3)))
        except Exception:
            workers = 3

        self._cp_stop.clear()
        self._cp_running = True
        self._cp_status = {
            "running": True,
            "total": len(raw_items),
            "done": 0,
            "ok": 0,
            "skip": 0,
            "fail": 0,
            "current": "Đang khởi tạo...",
            "dry_run": dry_run,
            "workers": workers,
            "logs": [],
        }
        threading.Thread(
            target=self._cp_dispute_worker,
            args=(list(raw_items), dry_run, headless, delay_sec, workers),
            daemon=True,
        ).start()
        return {"ok": 1}

    def _cp_record_dispute(
        self,
        ch: dict,
        video_id: str,
        video_title: str,
        claim_title: str,
        claimant: str,
        lic: dict,
        status: str,
        method: str,
        message: str,
    ):
        now = _now_iso()
        with _DB_LOCK:
            con = _db_conn()
            try:
                con.execute(
                    """INSERT INTO copyright_disputes (
                           channel_id, youtube_channel_id, channel_title, account_email,
                           video_id, video_title, claim_id, claim_title, claimant,
                           license_id, license_name, status, method, message, disputed_at, updated_at
                       ) VALUES (?, ?, ?, ?, ?, ?, '', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        int(ch.get("id") or 0),
                        str(ch.get("youtube_channel_id") or ""),
                        str(ch.get("title") or ""),
                        str(ch.get("account_email") or ""),
                        str(video_id),
                        str(video_title or video_id),
                        str(claim_title or ""),
                        str(claimant or ""),
                        int(lic.get("id") or 0),
                        str(lic.get("name") or ""),
                        str(status),
                        str(method),
                        str(message or "")[:500],
                        now,
                        now,
                    ),
                )
                con.commit()
            finally:
                con.close()

    def _cp_dispute_one_video(
        self,
        page,
        ch: dict,
        item: dict,
        lic: dict,
        dry_run: bool,
        need_switch: bool = True,
        dry_run_pause: float = 10.0,
    ) -> tuple[str, str]:
        """Tự động mở trang bản quyền của video trên YouTube Studio và điền 4 bước kháng bằng Giấy phép."""
        vid = str(item.get("video_id") or "").strip()
        vtitle = str(item.get("video_title") or vid)
        pid = str(item.get("page_id") or ch.get("page_id") or "").strip()
        target_url = f"https://studio.youtube.com/video/{vid}/copyright"
        if need_switch and pid:
            nav_url = (
                "https://www.youtube.com/signin?action_handle_signin=true&authuser=0"
                f"&pageid={urllib.parse.quote(pid, safe='')}&next={urllib.parse.quote(target_url, safe='')}"
            )
        else:
            nav_url = target_url

        page.goto(nav_url, timeout=35000, wait_until="domcontentloaded")
        row_loc = page.locator("ytcr-video-content-list-row")
        for _ in range(14):
            if self._cp_stop.is_set():
                return "SKIP", "Đã dừng theo yêu cầu."
            if row_loc.count() > 0:
                break
            cur_chk = (page.url or "").lower()
            if "accounts.google.com" in cur_chk or "servicelogin" in cur_chk:
                break
            time.sleep(1.0)
        time.sleep(1.0)

        def _check_page_state():
            u = (page.url or "").lower()
            pt = ""
            bh = ""
            try:
                pt = (page.title() or "").strip()
                bh = (page.inner_text("body") or "")[:700]
            except Exception:
                pass
            lt = pt.lower()
            lb = bh.lower()
            is_login = ("accounts.google.com" in u) or ("servicelogin" in u)
            is_oops = (
                ("rất tiếc" in lt)
                or ("oops" in lt)
                or any(k in lb for k in ("kažkas ne taip", "something went wrong", "chưa đăng nhập"))
            )
            return u, is_login, is_oops, lb

        cur_u, is_login, is_oops, low_body = _check_page_state()

        # Tự động xoay mới cookie (__Secure-1PSIDTS hết hạn sau ~14 phút) nếu Studio báo 'Rất tiếc / Oops'
        # hoặc điều hướng bị bật về www.youtube.com
        if (not is_login) and (is_oops or ("studio.youtube.com" not in cur_u)):
            self._cp_log(f"  🔄 Phiên Studio tạm gián đoạn ở {vid} — tự làm mới cookie & chuyển lại kênh...")
            try:
                page.goto("https://www.youtube.com/", timeout=20000, wait_until="domcontentloaded")
                time.sleep(2.5)
                retry_url = (
                    f"https://www.youtube.com/signin?action_handle_signin=true&authuser=0"
                    f"&pageid={urllib.parse.quote(pid, safe='')}&next={urllib.parse.quote(target_url, safe='')}"
                ) if pid else target_url
                page.goto(retry_url, timeout=35000, wait_until="domcontentloaded")
                for _ in range(14):
                    if self._cp_stop.is_set() or row_loc.count() > 0:
                        break
                    time.sleep(1.0)
                time.sleep(1.0)
            except Exception:
                pass
            cur_u, is_login, is_oops, low_body = _check_page_state()

        if is_login or is_oops:
            return (
                "AUTH_EXPIRED",
                "Phiên đăng nhập YouTube Studio của Mail đã hết hạn (báo 'Rất tiếc / 401') — "
                "hãy vào tab '👤 Tài khoản & Kênh' bấm '🌐 Mở Chrome' hoặc '🍪 Tải Cookie' để đăng nhập lại.",
            )

        row_count = row_loc.count()
        if row_count == 0:
            if any(k in low_body for k in ("không phát hiện vấn đề", "no copyright issues", "no issues found")):
                return "SKIP", "Video hiện không còn claim bản quyền nào trên Studio."
            return "SKIP", "Không tìm thấy dòng claim bản quyền khả dụng trên trang Studio."

        submitted_claims = 0
        skipped_claims = 0
        last_note = ""

        for r_idx in range(row_count):
            if self._cp_stop.is_set():
                return "SKIP", "Đã dừng theo yêu cầu."
            row = row_loc.nth(r_idx)
            row_txt = ""
            try:
                row_txt = (row.inner_text() or "").strip()
            except Exception:
                continue
            low_txt = row_txt.lower()
            lines_r = [ln.strip() for ln in row_txt.splitlines() if ln.strip()]
            claim_title = lines_r[0] if lines_r else ""
            claimant = " • ".join(lines_r[1:3]) if len(lines_r) > 1 else ""

            if any(k in low_txt for k in ("đang tranh chấp", "dispute in progress", "đã phản đối", "under review", "đang xem xét")):
                skipped_claims += 1
                last_note = f"Claim '{claim_title}' đang chờ phản hồi."
                continue
            if any(k in low_txt for k in ("cảnh cáo bản quyền", "copyright strike", "video bị gỡ xuống", "takedown")):
                skipped_claims += 1
                last_note = f"Bỏ qua Gậy bản quyền (Strike) ở '{claim_title}'."
                continue

            ok_rule, rule_reason = self._cp_match_claimant_rule(claimant, claim_title, lic)
            if not ok_rule:
                skipped_claims += 1
                self._cp_log(f"  ⏭️ Bỏ qua claim [{claim_title}]: {rule_reason}")
                self._cp_record_dispute(ch, vid, vtitle, claim_title, claimant, lic, "SKIPPED", "playwright", rule_reason)
                continue

            # Mở hộp thoại Chọn hành động (#actions-button) trong dòng claim
            action_btn = row.locator("#actions-button").first
            if action_btn.count() == 0:
                action_btn = row.locator("ytcp-button, button").filter(
                    has_text=re.compile(r"Chọn hành động|Select action|Take action|Hành động|Actions|Phản đối|Dispute", re.I)
                ).first
            if action_btn.count() == 0:
                skipped_claims += 1
                last_note = f"Không có nút hành động cho '{claim_title}'."
                continue
            action_btn.click(timeout=6000)
            time.sleep(0.8)

            # UI mới của Studio: thẻ #action-card-NON_TAKEDOWN_CLAIM_OPTION_DISPUTE + nút #confirm-button
            dispute_card = page.locator("#action-card-NON_TAKEDOWN_CLAIM_OPTION_DISPUTE:visible").first
            if dispute_card.count() > 0:
                dispute_card.click(timeout=6000)
                time.sleep(0.4)
                conf_btn = page.locator("tp-yt-paper-dialog #confirm-button:visible, tp-yt-paper-dialog #continue-button:visible").last
                conf_btn.wait_for(state="visible", timeout=6000)
                conf_btn.click(timeout=6000)
                time.sleep(1.0)
            else:
                # Dự phòng UI menu cũ
                dispute_item = page.locator("tp-yt-paper-item:visible, [role='menuitem']:visible, ytcp-button:visible").filter(
                    has_text=re.compile(r"Phản đối|Dispute", re.I)
                ).first
                if dispute_item.count() > 0:
                    dispute_item.click(timeout=6000)
                    time.sleep(1.0)

            dlg = page.locator("tp-yt-paper-dialog:visible").last
            try:
                dlg.wait_for(state="visible", timeout=8000)
            except Exception:
                return "FAIL", f"Không mở được hộp thoại Phản đối cho '{claim_title}'."

            def _click_continue():
                btn = page.locator("tp-yt-paper-dialog #continue-button:visible, tp-yt-paper-dialog #next-button:visible").last
                if btn.count() == 0:
                    btn = dlg.locator("ytcp-button:visible, button:visible").filter(
                        has_text=re.compile(r"^\s*(Tiếp tục|Continue)\s*$", re.I)
                    ).last
                btn.wait_for(state="visible", timeout=6000)
                btn.click(timeout=6000)
                time.sleep(0.9)

            def _tick_visible_checkboxes():
                cbs = page.locator("tp-yt-paper-dialog ytcp-checkbox-lit:visible, tp-yt-paper-dialog tp-yt-paper-checkbox:visible")
                cnt = cbs.count()
                for ci in range(cnt):
                    cb = cbs.nth(ci)
                    try:
                        checked = cb.get_attribute("aria-checked") or ""
                        if checked.lower() != "true" and cb.get_attribute("checked") is None:
                            cb.click(timeout=4000)
                            time.sleep(0.25)
                    except Exception:
                        pass

            # Bước 1: Tổng quan (Overview)
            _tick_visible_checkboxes()
            _click_continue()

            # Bước 2: Lý do (Reason) -> chọn "Giấy phép" / "License" (name='AUTHORIZED')
            lic_radio = page.locator("tp-yt-paper-dialog tp-yt-paper-radio-button[name='AUTHORIZED']:visible").first
            if lic_radio.count() == 0:
                lic_radio = page.locator("tp-yt-paper-dialog tp-yt-paper-radio-button:visible").filter(
                    has_text=re.compile(r"Giấy phép|License", re.I)
                ).first
            if lic_radio.count() == 0:
                return "FAIL", "Không tìm thấy tùy chọn 'Giấy phép / License' ở Bước 2."
            lic_radio.click(timeout=6000)
            time.sleep(0.4)
            _click_continue()

            # Bước 3: Chi tiết (Details) -> tick xác nhận #review-checkbox
            rev_cb = page.locator("tp-yt-paper-dialog ytcp-checkbox-lit#review-checkbox:visible").first
            if rev_cb.count() > 0:
                checked = rev_cb.get_attribute("aria-checked") or ""
                if checked.lower() != "true" and rev_cb.get_attribute("checked") is None:
                    rev_cb.click(timeout=4000)
                    time.sleep(0.25)
            _tick_visible_checkboxes()
            _click_continue()

            # Bước 4: Căn cứ (Rationale) -> điền nội dung giấy phép + 3 ô cam kết + Chữ ký
            rendered_text = self._cp_render_license_text(
                lic.get("license_text") or "",
                {
                    "channel_title": ch.get("title") or "",
                    "youtube_channel_id": ch.get("youtube_channel_id") or "",
                    "video_id": vid,
                    "video_title": vtitle,
                    "claim_title": claim_title,
                    "claimant": claimant,
                },
            )
            tas = page.locator("tp-yt-paper-dialog textarea:visible")
            tas.first.wait_for(state="visible", timeout=6000)
            tas.first.fill(rendered_text)
            time.sleep(0.3)

            _tick_visible_checkboxes()

            if tas.count() >= 2:
                tas.last.fill(str(lic.get("signature") or ""))
                time.sleep(0.3)
            else:
                sig_inp = page.locator("tp-yt-paper-dialog input[type='text']:visible, tp-yt-paper-dialog input:not([type='checkbox']):not([type='radio']):not([type='hidden']):visible").last
                if sig_inp.count() > 0:
                    sig_inp.fill(str(lic.get("signature") or ""))
                    time.sleep(0.3)

            if dry_run:
                pause_s = max(0.2, float(dry_run_pause or 10.0))
                self._cp_log(f"  🧪 [CHẠY THỬ] Đã điền đủ 4 bước cho {vid} ({claim_title}) — dừng {pause_s:.0f}s trước nút Gửi...")
                steps_w = max(1, int(pause_s * 2))
                for _ in range(steps_w):
                    if self._cp_stop.is_set():
                        break
                    time.sleep(0.5)
                # Đóng hộp thoại không bấm Gửi
                try:
                    close_btn = page.locator("tp-yt-paper-dialog #close-button:visible, tp-yt-paper-dialog ytcp-icon-button[icon='close']:visible").last
                    if close_btn.count() > 0:
                        close_btn.click(timeout=3000)
                        time.sleep(0.4)
                    disc_btn = page.locator("tp-yt-paper-dialog #confirm-button:visible").filter(
                        has_text=re.compile(r"Discard|Hủy|Bỏ", re.I)
                    ).last
                    if disc_btn.count() > 0:
                        disc_btn.click(timeout=3000)
                except Exception:
                    pass
                self._cp_record_dispute(
                    ch, vid, vtitle, claim_title, claimant, lic, "DRY_RUN", "playwright",
                    "Chạy thử thành công: đã điền đủ 4 bước (chưa bấm Gửi).",
                )
                submitted_claims += 1
            else:
                sub_btn = page.locator("tp-yt-paper-dialog #submit-button:visible").last
                if sub_btn.count() == 0:
                    sub_btn = page.locator("tp-yt-paper-dialog ytcp-button:visible, tp-yt-paper-dialog button:visible").filter(
                        has_text=re.compile(r"^\s*(Gửi|Submit)\s*$", re.I)
                    ).last
                sub_btn.wait_for(state="visible", timeout=6000)
                sub_btn.click(timeout=6000)
                time.sleep(2.5)
                try:
                    done_btn = page.locator("tp-yt-paper-dialog ytcp-button:visible, tp-yt-paper-dialog button:visible").filter(
                        has_text=re.compile(r"^\s*(Đóng|Close)\s*$", re.I)
                    ).last
                    if done_btn.count() > 0:
                        done_btn.click(timeout=4000)
                        time.sleep(0.8)
                except Exception:
                    pass
                self._cp_record_dispute(
                    ch, vid, vtitle, claim_title, claimant, lic, "SUBMITTED", "playwright",
                    "Đã gửi kháng nghị bằng Giấy phép thành công.",
                )
                submitted_claims += 1

        if submitted_claims > 0:
            tag = "DRY_RUN" if dry_run else "SUBMITTED"
            return tag, f"Đã xử lý {submitted_claims} claim" + (f" (bỏ qua {skipped_claims})" if skipped_claims else "")
        return "SKIP", last_note or f"Không có claim mới nào cần kháng (bỏ qua {skipped_claims})."

    def _cp_dispute_worker(
        self,
        items: list[dict],
        dry_run: bool,
        headless: bool,
        delay_sec: float,
        workers: int = 3,
    ):
        import queue as _queue

        try:
            try:
                from playwright.sync_api import sync_playwright
            except Exception as e:
                self._cp_log(f"❌ Thiếu thư viện Playwright để chạy kháng tự động: {e}")
                return

            with _DB_LOCK:
                con = _db_conn()
                try:
                    ch_map = {int(r["id"]): dict(r) for r in con.execute("SELECT * FROM channels").fetchall()}
                    lic_map = {int(r["id"]): dict(r) for r in con.execute("SELECT * FROM copyright_licenses").fetchall()}
                    acc_map = {str(r["email"] or "").lower(): dict(r) for r in con.execute("SELECT * FROM accounts").fetchall()}
                finally:
                    con.close()

            # Chuẩn bị hàng đợi tác vụ, sắp xếp theo (email, uc) để mỗi luồng giữ nguyên phiên kênh lâu nhất
            task_q: _queue.Queue = _queue.Queue()
            valid_tasks = []
            for it in items:
                cid = int(it.get("channel_id") or 0)
                ch = ch_map.get(cid)
                if not ch:
                    with self._lock:
                        self._cp_status["done"] += 1
                        self._cp_status["fail"] += 1
                    continue
                em = str(ch.get("account_email") or "").lower()
                uc = str(ch.get("youtube_channel_id") or "").strip()
                valid_tasks.append((em, uc, it, ch))
            valid_tasks.sort(key=lambda x: (x[0], x[1]))

            # Nạp trước cookie đã lưu cho từng tài khoản (1 lần duy nhất)
            acc_cookie_bundle: dict[str, tuple[list[dict], dict[str, str], Path]] = {}
            for em in {x[0] for x in valid_tasks}:
                acc = acc_map.get(em)
                if not acc:
                    continue
                safe_email = re.sub(r"[^a-zA-Z0-9_.-]", "_", em or "default")
                pdir = Path(acc.get("profile_dir") or "") if str(acc.get("profile_dir") or "").strip() else (PROFILES_DIR / safe_email)
                ck_map = self._resolve_account_cookies(acc, allow_playwright=False) or {}
                raw_cookies = []
                cpath = str(acc.get("cookie_path") or "").strip()
                for cand_cf in ([Path(cpath)] if cpath else []) + [COOKIES_DIR / f"{safe_email}.json"]:
                    if cand_cf.is_file():
                        try:
                            raw_cookies = json.loads(cand_cf.read_text(encoding="utf-8") or "[]")
                            if raw_cookies:
                                break
                        except Exception:
                            raw_cookies = []
                pw_cookies = []
                if isinstance(raw_cookies, list) and raw_cookies:
                    for c in raw_cookies:
                        if not isinstance(c, dict) or not c.get("name") or not c.get("domain"):
                            continue
                        pw_cookies.append({
                            "name": str(c["name"]),
                            "value": str(c.get("value") or ""),
                            "domain": str(c["domain"]),
                            "path": str(c.get("path") or "/"),
                            "secure": bool(c.get("secure", True)),
                            "httpOnly": bool(c.get("httpOnly", False)),
                        })
                elif ck_map:
                    for k, v in ck_map.items():
                        pw_cookies.append({
                            "name": str(k),
                            "value": str(v),
                            "domain": ".youtube.com",
                            "path": "/",
                            "secure": True,
                        })
                acc_cookie_bundle[em] = (pw_cookies, ck_map, pdir)

            for t_item in valid_tasks:
                task_q.put(t_item)

            num_workers = max(1, min(6, int(workers or 3), len(valid_tasks) or 1))
            mode_label = "🧪 CHẠY THỬ (không bấm Gửi)" if dry_run else "🚀 KHÁNG THẬT"
            self._cp_log(f"Bắt đầu {mode_label} cho {len(valid_tasks)} video • Chạy song song {num_workers} luồng...")

            expired_emails: set[str] = set()
            active_tasks: dict[int, str] = {}
            pdir_locks: dict[str, threading.Lock] = {}

            def _refresh_current_text():
                parts = list(active_tasks.values())[:3]
                extra = f" (+{len(active_tasks) - 3})" if len(active_tasks) > 3 else ""
                self._cp_status["current"] = (f"[{len(active_tasks)} luồng] " + " | ".join(parts) + extra) if parts else "Đang xử lý..."

            def _run_worker(w_idx: int):
                tag_w = f"[L{w_idx}]"
                browser = None
                ctx = None
                page = None
                cur_email = ""
                cur_uc = ""
                cur_pdir_lock = None
                last_rotate_ts = time.monotonic()

                def _close_ctx():
                    nonlocal ctx, page, cur_email, cur_uc, cur_pdir_lock
                    try:
                        if ctx is not None:
                            ctx.close()
                    except Exception:
                        pass
                    ctx = None
                    page = None
                    cur_email = ""
                    cur_uc = ""
                    if cur_pdir_lock is not None:
                        try:
                            cur_pdir_lock.release()
                        except Exception:
                            pass
                        cur_pdir_lock = None

                try:
                    with sync_playwright() as p:
                        for kwargs in ({"channel": "chrome"}, {"channel": "msedge"}, {}):
                            try:
                                browser = p.chromium.launch(
                                    headless=headless,
                                    args=["--disable-blink-features=AutomationControlled", "--no-first-run"],
                                    **kwargs,
                                )
                                break
                            except Exception:
                                continue

                        while not self._cp_stop.is_set():
                            try:
                                em, uc, it, ch = task_q.get_nowait()
                            except _queue.Empty:
                                break

                            vid = str(it.get("video_id") or "").strip()
                            vtitle = str(it.get("video_title") or vid)
                            lic_id = int(it.get("license_id") or ch.get("license_id") or 0)
                            lic = lic_map.get(lic_id)

                            with self._lock:
                                if em in expired_emails:
                                    self._cp_status["done"] += 1
                                    self._cp_status["fail"] += 1
                                    continue

                            if em not in acc_map:
                                self._cp_log(f"{tag_w} ⚠️ Không tìm thấy tài khoản {em} trong DB — bỏ qua {vid}.")
                                with self._lock:
                                    self._cp_status["done"] += 1
                                    self._cp_status["fail"] += 1
                                continue

                            if not lic:
                                self._cp_log(f"{tag_w} ⏭️ Bỏ qua {vid} ({ch.get('title')}): chưa gán giấy phép cho kênh.")
                                with self._lock:
                                    self._cp_status["done"] += 1
                                    self._cp_status["skip"] += 1
                                continue

                            # Đảm bảo context khớp tài khoản `em`
                            if ctx is None or cur_email != em:
                                _close_ctx()
                                pw_cookies, _, pdir = acc_cookie_bundle.get(em, ([], {}, PROFILES_DIR / "default"))
                                if pw_cookies and browser is not None:
                                    ctx = browser.new_context(viewport={"width": 1360, "height": 880}, user_agent=_UA)
                                    ctx.add_cookies(pw_cookies)
                                    page = ctx.new_page()
                                    cur_email = em
                                    cur_uc = ""
                                else:
                                    # Dự phòng persistent profile (khóa theo pdir để tránh đụng ProcessSingleton)
                                    pdir.mkdir(parents=True, exist_ok=True)
                                    pk = str(pdir).lower()
                                    with self._lock:
                                        lk = pdir_locks.setdefault(pk, threading.Lock())
                                    lk.acquire()
                                    cur_pdir_lock = lk
                                    for kwargs in ({"channel": "chrome"}, {"channel": "msedge"}, {}):
                                        try:
                                            ctx = p.chromium.launch_persistent_context(
                                                str(pdir),
                                                headless=headless,
                                                no_viewport=True,
                                                ignore_default_args=["--enable-automation", "--no-sandbox"],
                                                args=["--no-first-run", "--disable-blink-features=AutomationControlled"],
                                                **kwargs,
                                            )
                                            break
                                        except Exception:
                                            continue
                                    if ctx is None:
                                        _close_ctx()
                                        self._cp_log(f"{tag_w} ❌ Không khởi chạy được trình duyệt cho {em}.")
                                        with self._lock:
                                            self._cp_status["done"] += 1
                                            self._cp_status["fail"] += 1
                                        continue
                                    page = ctx.pages[0] if ctx.pages else ctx.new_page()
                                    cur_email = em
                                    cur_uc = ""

                            with self._lock:
                                active_tasks[w_idx] = f"{ch.get('title') or uc} • {vid}"
                                _refresh_current_text()

                            need_switch = bool(uc and uc != cur_uc)
                            # Chủ động xoay mới cookie mỗi 9 phút để tránh __Secure-1PSIDTS hết hạn ở phút ~14
                            if (time.monotonic() - last_rotate_ts) >= 540.0 and page is not None:
                                try:
                                    page.goto("https://www.youtube.com/", timeout=18000, wait_until="domcontentloaded")
                                    time.sleep(2.0)
                                    last_rotate_ts = time.monotonic()
                                    need_switch = True
                                except Exception:
                                    pass
                            if need_switch and not str(it.get("page_id") or ch.get("page_id") or "").strip():
                                try:
                                    page.goto(f"https://studio.youtube.com/channel/{uc}", timeout=25000, wait_until="domcontentloaded")
                                    time.sleep(1.5)
                                except Exception:
                                    pass

                            self._cp_log(f"{tag_w} 📜 [{ch.get('title')}] • {vid} ({vtitle[:42]}) bằng GP [{lic['name']}]...")
                            try:
                                st, msg = self._cp_dispute_one_video(page, ch, it, lic, dry_run, need_switch=need_switch)
                                if st in ("SUBMITTED", "DRY_RUN", "SKIP"):
                                    cur_uc = uc
                                if st in ("SUBMITTED", "DRY_RUN"):
                                    with self._lock:
                                        self._cp_status["ok"] += 1
                                    self._cp_log(f"{tag_w}   ✅ [{st}] {vid}: {msg}")
                                elif st == "SKIP":
                                    with self._lock:
                                        self._cp_status["skip"] += 1
                                    self._cp_log(f"{tag_w}   ⏭️ [BỎ QUA] {vid}: {msg}")
                                elif st == "AUTH_EXPIRED":
                                    with self._lock:
                                        expired_emails.add(em)
                                        self._cp_status["fail"] += 1
                                    self._cp_log(f"{tag_w}   🔑 [HẾT PHIÊN ĐĂNG NHẬP] {em}: {msg}")
                                    self._cp_record_dispute(ch, vid, vtitle, "", "", lic, "FAILED", "playwright", msg)
                                else:
                                    with self._lock:
                                        self._cp_status["fail"] += 1
                                    self._cp_log(f"{tag_w}   ❌ [LỖI] {vid}: {msg}")
                                    self._cp_record_dispute(ch, vid, vtitle, "", "", lic, "FAILED", "playwright", msg)
                            except Exception as ex:
                                err_s = str(ex)[:260]
                                with self._lock:
                                    self._cp_status["fail"] += 1
                                self._cp_log(f"{tag_w}   ❌ [LỖI] {vid}: {err_s}")
                                self._cp_record_dispute(ch, vid, vtitle, "", "", lic, "FAILED", "playwright", err_s)
                            finally:
                                with self._lock:
                                    self._cp_status["done"] += 1
                                    active_tasks.pop(w_idx, None)
                                    _refresh_current_text()

                            if not self._cp_stop.is_set() and not task_q.empty():
                                wait_s = delay_sec + random.uniform(0.3, 1.8)
                                steps = int(wait_s * 2)
                                for _ in range(max(1, steps)):
                                    if self._cp_stop.is_set():
                                        break
                                    time.sleep(0.5)
                except Exception as w_ex:
                    self._cp_log(f"{tag_w} ❌ Lỗi luồng xử lý: {w_ex}")
                finally:
                    _close_ctx()
                    try:
                        if browser is not None:
                            browser.close()
                    except Exception:
                        pass

            threads = [
                threading.Thread(target=_run_worker, args=(i + 1,), daemon=True)
                for i in range(num_workers)
            ]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
        except Exception as outer_ex:
            self._cp_log(f"❌ Lỗi tiến trình kháng bản quyền: {outer_ex}")
        finally:
            self._cp_running = False
            self._cp_status["running"] = False
            self._cp_status["current"] = "Đã dừng" if self._cp_stop.is_set() else "Hoàn tất"
            self._cp_log(
                f"🏁 Kết thúc kháng bản quyền: {self._cp_status['ok']} thành công, "
                f"{self._cp_status['skip']} bỏ qua, {self._cp_status['fail']} lỗi."
            )

    # ------------------------------------------------------------------
    # PHÂN HỆ 5: CẢNH BÁO KÊNH (POPUP GIỮA MÀN HÌNH + TELEGRAM BOT)
    # ------------------------------------------------------------------
    def _alert_list(self, dismissed=None, limit=60):
        try:
            with _DB_LOCK:
                con = _db_conn()
                try:
                    if dismissed is None:
                        rows = con.execute(
                            "SELECT * FROM channel_alerts ORDER BY id DESC LIMIT ?",
                            (int(limit),),
                        ).fetchall()
                    else:
                        rows = con.execute(
                            "SELECT * FROM channel_alerts WHERE dismissed=? ORDER BY id DESC LIMIT ?",
                            (int(dismissed), int(limit)),
                        ).fetchall()
                    return [dict(r) for r in rows]
                finally:
                    con.close()
        except Exception:
            return []

    def _send_telegram_message(self, token: str, chat_ids_raw: str, text_html: str):
        token = str(token or "").strip()
        chat_ids = [c.strip() for c in re.split(r"[\s,;]+", str(chat_ids_raw or "")) if c.strip()]
        if not token or not chat_ids:
            return False, "Thiếu Bot Token hoặc Chat ID"
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        errors = []
        sent_any = False
        for cid in chat_ids:
            try:
                body = json.dumps({
                    "chat_id": cid,
                    "text": text_html,
                    "parse_mode": "HTML",
                    "disable_web_page_preview": True,
                }).encode("utf-8")
                req = urllib.request.Request(
                    url,
                    data=body,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=12) as resp:
                    raw = resp.read().decode("utf-8", errors="ignore")
                    obj = json.loads(raw) if raw else {}
                    if obj.get("ok"):
                        sent_any = True
                    else:
                        errors.append(f"{cid}: {obj.get('description') or 'Telegram error'}")
            except urllib.error.HTTPError as he:
                try:
                    err_body = he.read().decode("utf-8", errors="ignore")
                    err_obj = json.loads(err_body)
                    err_msg = err_obj.get("description") or str(he)
                except Exception:
                    err_msg = str(he)
                errors.append(f"{cid}: {err_msg}")
            except Exception as ex:
                errors.append(f"{cid}: {ex}")
        if sent_any and not errors:
            return True, ""
        return sent_any, "; ".join(errors)[:300]

    def _format_alert_tg_html(self, ev: dict) -> str:
        def _hesc(s):
            return str(s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        etype = str(ev.get("event_type") or "")
        icons = {
            "YPP_ELIGIBLE": "🟡 <b>ĐỦ ĐIỀU KIỆN BẬT KIẾM TIỀN</b>",
            "MON_ON": "💰 <b>BẬT KIẾM TIỀN THÀNH CÔNG</b>",
            "MON_OFF": "⛔ <b>KÊNH BỊ TẮT KIẾM TIỀN</b>",
            "STRIKE": "🛑 <b>CẢNH BÁO KÊNH ĂN GẬY</b>",
        }
        header = icons.get(etype, "🔔 <b>THÔNG BÁO KÊNH T2MG</b>")
        ch_name = _hesc(ev.get("channel_title") or ev.get("youtube_channel_id") or "")
        email = _hesc(ev.get("account_email") or "")
        detail = _hesc(ev.get("detail") or "")
        uc = str(ev.get("youtube_channel_id") or "").strip()
        studio_url = f"https://studio.youtube.com/channel/{uc}" if uc else ""
        lines = [header, f"📺 Kênh: <b>{ch_name}</b>"]
        if email:
            lines.append(f"📧 Mail: <code>{email}</code>")
        if detail:
            lines.append(f"📋 Chi tiết: {detail}")
        if studio_url:
            lines.append(f"🔗 <a href=\"{studio_url}\">Mở YouTube Studio</a>")
        lines.append(f"🕒 {_hesc(_now_iso().replace('T', ' ')[:19])}")
        return "\n".join(lines)

    def _dispatch_telegram_alerts_async(self, alert_rows: list):
        if not alert_rows:
            return
        cfg = self._load_cfg()
        if not cfg.get("alert_tg_enabled"):
            return
        token = str(cfg.get("alert_tg_bot_token") or "").strip()
        chat_id = str(cfg.get("alert_tg_chat_id") or "").strip()
        if not token or not chat_id:
            return

        def _runner():
            for row in alert_rows:
                msg_html = self._format_alert_tg_html(row)
                ok, err = self._send_telegram_message(token, chat_id, msg_html)
                try:
                    with _DB_LOCK:
                        con = _db_conn()
                        try:
                            con.execute(
                                "UPDATE channel_alerts SET tg_sent=?, tg_error=? WHERE id=?",
                                (1 if ok else 0, err, int(row["id"])),
                            )
                            con.commit()
                        finally:
                            con.close()
                except Exception:
                    pass
                time.sleep(0.35)

        threading.Thread(target=_runner, name="T2MGAlertTelegram", daemon=True).start()

    def _evaluate_channel_alerts_from_db(self, send_tg: bool = True):
        cfg = self._load_cfg()
        enabled_types = cfg.get("alert_types") or DEFAULT_CONFIG["alert_types"]
        mon_on_set = {"ON", "ACTIVE", "MONETIZED"}
        mon_bad_set = {"DISABLED", "DISABLED_ADSENSE", "REJECTED", "SUSPENDED", "APPEAL_REVIEW"}
        now_s = _now_iso()
        new_alerts = []

        with _DB_LOCK:
            con = _db_conn()
            try:
                channels = [dict(r) for r in con.execute("SELECT * FROM channels WHERE enabled=1").fetchall()]
                prev_map = {
                    str(r["youtube_channel_id"]): dict(r)
                    for r in con.execute("SELECT * FROM channel_alert_state").fetchall()
                }

                def _insert_alert(event_key, event_type, ch, title, detail):
                    if not enabled_types.get(event_type, True):
                        return
                    cur = con.execute(
                        """INSERT OR IGNORE INTO channel_alerts
                        (event_key, event_type, channel_id, youtube_channel_id, channel_title,
                         account_email, title, detail, dismissed, tg_sent, tg_error, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, '', ?)""",
                        (
                            event_key,
                            event_type,
                            int(ch.get("id") or 0),
                            str(ch.get("youtube_channel_id") or ""),
                            str(ch.get("title") or ch.get("youtube_channel_id") or ""),
                            str(ch.get("account_email") or ""),
                            title,
                            detail,
                            now_s,
                        ),
                    )
                    if cur.rowcount and cur.lastrowid:
                        new_alerts.append({
                            "id": int(cur.lastrowid),
                            "event_key": event_key,
                            "event_type": event_type,
                            "channel_id": int(ch.get("id") or 0),
                            "youtube_channel_id": str(ch.get("youtube_channel_id") or ""),
                            "channel_title": str(ch.get("title") or ch.get("youtube_channel_id") or ""),
                            "account_email": str(ch.get("account_email") or ""),
                            "title": title,
                            "detail": detail,
                            "created_at": now_s,
                        })

                for ch in channels:
                    uc = str(ch.get("youtube_channel_id") or "").strip()
                    if not uc:
                        continue
                    mon = str(ch.get("monetization_status") or "UNKNOWN").upper().strip()
                    subs = int(ch.get("subscriber_count") or 0)
                    strikes = int(ch.get("copyright_strikes") or 0)
                    wh = None
                    try:
                        det = json.loads(ch.get("detail_json") or "{}")
                        if isinstance(det, dict) and det.get("watch_hours_365d") is not None:
                            wh = float(det.get("watch_hours_365d"))
                    except Exception:
                        wh = None

                    prev = prev_map.get(uc)
                    prev_mon = str((prev or {}).get("monetization_status") or "").upper().strip()
                    prev_subs = int((prev or {}).get("subscriber_count") or 0)
                    prev_strikes = int((prev or {}).get("copyright_strikes") or 0)

                    # 1a. Đủ ĐK bật kiếm tiền sớm (mốc 500 sub / 3.000h) — chỉ báo khi chưa BKT & không có gậy
                    if mon not in mon_on_set and mon not in mon_bad_set and strikes == 0 and 500 <= subs < 1000:
                        if wh is None or wh >= 3000:
                            wh_txt = f" • {int(round(wh)):,}/3.000h xem".replace(",", ".") if wh is not None else " • Check 3.000h xem"
                            sub_txt = f"{subs:,}".replace(",", ".")
                            _insert_alert(
                                f"YPP_500:{uc}",
                                "YPP_ELIGIBLE",
                                ch,
                                "Đủ ĐK bật kiếm tiền sớm (500 sub / 3.000h)",
                                f"Đạt {sub_txt}/500 sub{wh_txt} (Trạng thái hiện tại: {mon})",
                            )

                    # 1b. Đủ ĐK bật kiếm tiền đầy đủ (mốc 1.000 sub / 4.000h)
                    #     - Báo nếu kênh chưa BKT và đạt >= 1.000 sub
                    #     - HOẶC kênh đã BKT sớm (500 sub) và nay vừa vượt mốc lên >= 1.000 sub -> báo lại tiếp để bật QC đầy đủ
                    if mon not in mon_bad_set and strikes == 0 and subs >= 1000 and (wh is None or wh >= 4000):
                        not_mon_yet = mon not in mon_on_set
                        upgraded_from_500 = (mon in mon_on_set and prev is not None and prev_subs < 1000)
                        if not_mon_yet or upgraded_from_500:
                            wh_txt = f" • {int(round(wh)):,}/4.000h xem".replace(",", ".") if wh is not None else " • Check 4.000h xem"
                            sub_txt = f"{subs:,}".replace(",", ".")
                            title_1k = (
                                "Đạt mốc 1.000 sub / 4.000h (Nâng cấp YPP đầy đủ)"
                                if upgraded_from_500
                                else "Đủ ĐK bật kiếm tiền đầy đủ (1.000 sub / 4.000h)"
                            )
                            _insert_alert(
                                f"YPP_ELIGIBLE:{uc}",
                                "YPP_ELIGIBLE",
                                ch,
                                title_1k,
                                f"Đạt {sub_txt}/1.000 sub{wh_txt} (Trạng thái hiện tại: {mon})",
                            )

                    # 2. Bật kiếm tiền thành công (chỉ báo khi chuyển từ chưa ON -> ON, tránh spam các kênh đã ON từ trước)
                    if prev is not None and prev_mon not in mon_on_set and mon in mon_on_set:
                        _insert_alert(
                            f"MON_ON:{uc}",
                            "MON_ON",
                            ch,
                            "Bật kiếm tiền thành công (YPP)",
                            f"Trạng thái chuyển từ {prev_mon or 'CHƯA BKT'} → {mon} ({subs:,} sub)".replace(",", "."),
                        )

                    # 3. Bị tắt kiếm tiền (từ ON -> không ON, hoặc mới rơi vào DISABLED/REJECTED/SUSPENDED)
                    if prev is not None:
                        turned_off_from_on = (prev_mon in mon_on_set and mon not in mon_on_set and mon not in ("UNKNOWN", ""))
                        entered_bad_state = (prev_mon not in mon_bad_set and mon in mon_bad_set)
                        if turned_off_from_on or entered_bad_state:
                            _insert_alert(
                                f"MON_OFF:{uc}:{mon}",
                                "MON_OFF",
                                ch,
                                f"Kênh bị tắt kiếm tiền ({mon})",
                                f"Trạng thái thay đổi từ {prev_mon or 'UNKNOWN'} → {mon}",
                            )
                    elif mon in mon_bad_set:
                        _insert_alert(
                            f"MON_OFF:{uc}:{mon}",
                            "MON_OFF",
                            ch,
                            f"Kênh đang bị tắt kiếm tiền ({mon})",
                            f"Trạng thái kiếm tiền hiện tại: {mon}",
                        )

                    # 4. Ăn gậy (strikes > 0 và tăng hoặc chưa từng báo mức gậy này)
                    if strikes > 0 and (prev is None or strikes > prev_strikes):
                        _insert_alert(
                            f"STRIKE:{uc}:{strikes}",
                            "STRIKE",
                            ch,
                            f"Kênh ăn gậy ({strikes} gậy)",
                            f"Số gậy hiện tại: {strikes} (trước đó: {prev_strikes})",
                        )

                    con.execute(
                        """INSERT INTO channel_alert_state
                        (youtube_channel_id, monetization_status, subscriber_count, watch_hours_365d, copyright_strikes, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?)
                        ON CONFLICT(youtube_channel_id) DO UPDATE SET
                            monetization_status=excluded.monetization_status,
                            subscriber_count=excluded.subscriber_count,
                            watch_hours_365d=excluded.watch_hours_365d,
                            copyright_strikes=excluded.copyright_strikes,
                            updated_at=excluded.updated_at""",
                        (uc, mon, subs, wh, strikes, now_s),
                    )
                con.commit()
            finally:
                con.close()

        if new_alerts:
            self.log(f"🔔 [Alert] Phát hiện {len(new_alerts)} thông báo kênh mới.")
            if send_tg:
                self._dispatch_telegram_alerts_async(new_alerts)
        return new_alerts

    def act_alert_check_now(self, data):
        send_tg = bool(data.get("send_tg", True))
        new_alerts = self._evaluate_channel_alerts_from_db(send_tg=send_tg)
        return {
            "ok": 1,
            "new_count": len(new_alerts),
            "pending_alerts": self._alert_list(dismissed=0, limit=50),
            "recent_alerts": self._alert_list(dismissed=None, limit=80),
        }

    def act_alert_dismiss(self, data):
        ids = data.get("ids")
        dismiss_all = bool(data.get("all"))
        now_s = _now_iso()
        with _DB_LOCK:
            con = _db_conn()
            try:
                if dismiss_all:
                    con.execute(
                        "UPDATE channel_alerts SET dismissed=1, dismissed_at=? WHERE dismissed=0",
                        (now_s,),
                    )
                elif isinstance(ids, list) and ids:
                    clean_ids = [int(x) for x in ids if str(x).isdigit()]
                    if clean_ids:
                        ph = ",".join("?" for _ in clean_ids)
                        con.execute(
                            f"UPDATE channel_alerts SET dismissed=1, dismissed_at=? WHERE id IN ({ph})",
                            [now_s, *clean_ids],
                        )
                elif data.get("id"):
                    con.execute(
                        "UPDATE channel_alerts SET dismissed=1, dismissed_at=? WHERE id=?",
                        (now_s, int(data["id"])),
                    )
                con.commit()
            finally:
                con.close()
        return {
            "ok": 1,
            "pending_alerts": self._alert_list(dismissed=0, limit=50),
            "recent_alerts": self._alert_list(dismissed=None, limit=80),
        }

    def act_alert_save_config(self, data):
        cfg = self._load_cfg()
        if "alert_popup_enabled" in data:
            cfg["alert_popup_enabled"] = bool(data.get("alert_popup_enabled"))
        if "alert_tg_enabled" in data:
            cfg["alert_tg_enabled"] = bool(data.get("alert_tg_enabled"))
        if "alert_tg_bot_token" in data:
            cfg["alert_tg_bot_token"] = str(data.get("alert_tg_bot_token") or "").strip()
        if "alert_tg_chat_id" in data:
            cfg["alert_tg_chat_id"] = str(data.get("alert_tg_chat_id") or "").strip()
        if isinstance(data.get("alert_types"), dict):
            cur_types = dict(DEFAULT_CONFIG["alert_types"])
            for k in cur_types:
                if k in data["alert_types"]:
                    cur_types[k] = bool(data["alert_types"][k])
            cfg["alert_types"] = cur_types
        self._save_cfg(cfg)
        return {"ok": 1, "config": cfg}

    def act_alert_test_telegram(self, data):
        cfg = self._load_cfg()
        token = str(data.get("bot_token") or cfg.get("alert_tg_bot_token") or "").strip()
        chat_id = str(data.get("chat_id") or cfg.get("alert_tg_chat_id") or "").strip()
        msg = (
            "🔔 <b>T2MG — Kiểm tra kết nối Telegram thành công!</b>\n"
            "Hệ thống sẽ tự động báo về đây khi kênh:\n"
            "• 🟡 Đủ điều kiện bật kiếm tiền\n"
            "• 💰 Bật kiếm tiền thành công\n"
            "• ⛔ Bị tắt kiếm tiền\n"
            "• 🛑 Ăn gậy bản quyền / cộng đồng\n"
            f"🕒 {_now_iso().replace('T', ' ')[:19]}"
        )
        ok, err = self._send_telegram_message(token, chat_id, msg)
        if not ok:
            return {"ok": 0, "error": err or "Gửi Telegram thất bại."}
        return {"ok": 1, "message": "Đã gửi tin nhắn thử nghiệm tới Telegram thành công!"}
