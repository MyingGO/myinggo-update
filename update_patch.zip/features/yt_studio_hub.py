"""Tính năng: Quản lý Kênh & Audio Studio (Tích hợp từ 3T Master).

Bao gồm 3 phân hệ cốt lõi hoạt động đồng bộ:
1. Tài khoản & Kênh (Account & Channel Profile):
   - Quản lý Mail Google, mã hóa mật khẩu & 2FA bằng Windows DPAPI.
   - Tự động sinh mã OTP 2FA 6 số (RFC 6238 HMAC-SHA1) theo thời gian thực.
   - Quét kênh mới siêu tốc qua HTTP InnerTube (account/accounts_list) không cần mở trình duyệt.
   - Ghim phiên kênh độc lập (Pinned Studio Session), mở Chrome Profile riêng cho từng Mail/Kênh.
2. Channel Monitor & Auto Ops (V1013):
   - Giám sát sức khỏe kênh: Kiếm tiền (Monetization), Bản quyền (Strikes/Claims), Kho video hẹn giờ (Schedule Low Stock), Draft & Audio.
   - 6 Làn tác vụ Studio Operations + Công tắc tự hành Auto Ops (V1013):
     + Xóa nháp bản quyền (delete_draft_copyright)
     + Xóa lịch bản quyền (delete_scheduled_copyright)
     + Xử lý Add Audio lỗi (process_add_audio -> chuyển sang Audio Repair)
     + Chọn ngôn ngữ video (set_video_language)
     + Bật quảng cáo video & Mid-roll Ads (enable_ads)
     + Đặt lịch đều lại (rebalance_schedule)
3. Audio Repair (Sửa & Re-Add Âm thanh):
   - Quét & phát hiện video có track âm thanh bị FAILED / REJECTED / REMOVED.
   - Tra cứu baseline từ Hitmakers (tools.hitmakers.vip) hoặc quét thư mục nguồn Local/LAN.
   - Tự động cắt ghép khớp thời lượng Studio bằng FFmpeg (Trim đuôi, Cut History, hoặc tạo âm 3s/7s xen kẽ).
   - Chốt bảo vệ kênh: Tự động xóa video nếu bị gỡ Audio quá 5 lần (delete_over5).
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes
import hashlib
import hmac
import json
import os
import re
import shutil
import sqlite3
import struct
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from core import dialogs, logger
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

HUB_DB = DATA_DIR / "yt_studio_hub.db"
HUB_CFG = DATA_DIR / "yt_studio_config.json"
PROFILES_DIR = DATA_DIR / "yt_profiles"
COOKIES_DIR = DATA_DIR / "yt_cookies"
AUDIO_TEMP_DIR = DATA_DIR / "audio_repair_temp"

_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_UC_RE = re.compile(r"\b(UC[A-Za-z0-9_-]{22})\b")
_YT_WEB_API_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

DEFAULT_CONFIG = {
    "t3_root": r"F:\3TMaster",
    "t3_port": 8891,
    "bridge_mode": "auto",  # auto = đồng bộ 3TMaster nếu có + lưu độc lập trong MyingGo
    "key_root": "",
    "auto_branding": False,
    "channel_discovery_enabled": False,
    "cookie_sweep_enabled": False,
    # Channel Monitor
    "cm_auto_enabled": False,
    "cm_interval_minutes": 60,
    "cm_hide_money": False,
    "cm_auto_ops": {
        "delete_draft_copyright": False,
        "delete_scheduled_copyright": False,
        "set_video_language": False,
        "enable_ads": False,
        "rebalance_schedule": False,
    },
    # Audio Repair
    "ar_kinds": ["public", "draft", "scheduled"],
    "ar_skip_over5_ok": False,
    "ar_auto_enabled": False,
    "ar_auto_mode": "all",
    "ar_content_type": "global",
    "ar_delete_over5": False,
    "ar_hitmakers_user": "",
    "ar_hitmakers_pass_dpapi": "",
    "ar_hitmakers_url": "https://tools.hitmakers.vip",
    "ar_source_roots": "",
    "ar_duration_tolerance": 1.0,
}


# ==============================================================================
# 1. MÃ HÓA WINDOWS DPAPI & TOTP 2FA (RFC 6238)
# ==============================================================================

def dpapi_protect(plain_text: str) -> str:
    """Mã hóa chuỗi nhạy cảm bằng Windows DPAPI gắn với User hiện tại."""
    raw = (plain_text or "").encode("utf-8")
    if not raw:
        return ""
    if os.name != "nt":
        return "b64:" + base64.b64encode(raw).decode("ascii")
    try:
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
        ):
            raise ctypes.WinError()
        try:
            enc = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
        return "dpapi:" + base64.b64encode(enc).decode("ascii")
    except Exception:
        return "b64:" + base64.b64encode(raw).decode("ascii")


def dpapi_unprotect(token: str) -> str:
    """Giải mã chuỗi đã bảo vệ bằng Windows DPAPI."""
    s = str(token or "").strip()
    if not s:
        return ""
    if s.startswith("b64:"):
        try:
            return base64.b64decode(s[4:]).decode("utf-8", errors="replace")
        except Exception:
            return ""
    if not s.startswith("dpapi:"):
        return s
    raw = base64.b64decode(s[6:])
    if os.name != "nt":
        return ""
    try:
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
        ):
            return ""
        try:
            dec = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
        return dec.decode("utf-8", errors="replace")
    except Exception:
        return ""


def totp_now(secret: str, period: int = 30, digits: int = 6, at_time: int | None = None) -> dict:
    """Sinh mã OTP 6 số từ 2FA Secret chuẩn Google Authenticator (RFC 6238)."""
    clean = re.sub(r"[^A-Z2-7]", "", (secret or "").upper())
    now_ts = int(time.time()) if at_time is None else int(at_time)
    rem = period - (now_ts % period)
    if not clean:
        return {"code": "", "remaining": rem, "valid": False}
    try:
        pad = "=" * ((8 - len(clean) % 8) % 8)
        key = base64.b32decode(clean + pad, casefold=True)
        counter = int(now_ts // period)
        msg = struct.pack(">Q", counter)
        digest = hmac.new(key, msg, hashlib.sha1).digest()
        offset = digest[-1] & 0x0F
        code_int = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
        return {"code": str(code_int).zfill(digits), "remaining": rem, "valid": True}
    except Exception:
        return {"code": "", "remaining": rem, "valid": False}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _find_ffmpeg() -> str:
    for p in (
        ROOT / "bin" / "ffmpeg.exe",
        Path(r"C:\ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin\ffmpeg.exe"),
    ):
        if p.is_file():
            return str(p)
    w = shutil.which("ffmpeg")
    return w or "ffmpeg"


def _find_ffprobe() -> str:
    for p in (
        ROOT / "bin" / "ffprobe.exe",
        Path(r"C:\ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin\ffprobe.exe"),
    ):
        if p.is_file():
            return str(p)
    w = shutil.which("ffprobe")
    return w or "ffprobe"


def _probe_duration(file_path: str | Path) -> float:
    p = Path(file_path)
    if not p.is_file():
        return 0.0
    try:
        cp = subprocess.run(
            [_find_ffprobe(), "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(p)],
            capture_output=True, text=True, timeout=12, creationflags=_NOWIN
        )
        return round(float((cp.stdout or "").strip()), 2)
    except Exception:
        return 0.0


# ==============================================================================
# 2. CƠ SỞ DỮ LIỆU SQLITE NỘI BỘ MYINGGO
# ==============================================================================

_DB_LOCK = threading.RLock()


def _db_conn() -> sqlite3.Connection:
    con = sqlite3.connect(str(HUB_DB), timeout=15.0, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def _init_db():
    with _DB_LOCK:
        con = _db_conn()
        try:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                name TEXT DEFAULT '',
                password_enc TEXT DEFAULT '',
                tfa_secret_enc TEXT DEFAULT '',
                recovery_email TEXT DEFAULT '',
                recovery_phone TEXT DEFAULT '',
                profile_dir TEXT DEFAULT '',
                cookie_path TEXT DEFAULT '',
                enabled INTEGER DEFAULT 1,
                session_status TEXT DEFAULT 'READY',
                session_message TEXT DEFAULT '',
                channel_count INTEGER DEFAULT 0,
                note TEXT DEFAULT '',
                label TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER DEFAULT 0,
                account_email TEXT DEFAULT '',
                youtube_channel_id TEXT UNIQUE NOT NULL,
                title TEXT DEFAULT '',
                handle TEXT DEFAULT '',
                avatar_url TEXT DEFAULT '',
                enabled INTEGER DEFAULT 1,
                session_status TEXT DEFAULT 'OK',
                studio_session_status TEXT DEFAULT 'PINNED',
                session_message TEXT DEFAULT '',
                key_folder TEXT DEFAULT '',
                subscriber_count INTEGER DEFAULT 0,
                video_count INTEGER DEFAULT 0,
                view_count INTEGER DEFAULT 0,
                views_48h INTEGER DEFAULT 0,
                views_28d INTEGER DEFAULT 0,
                revenue_month REAL DEFAULT 0.0,
                revenue_28d REAL DEFAULT 0.0,
                monetization_status TEXT DEFAULT 'UNKNOWN',
                add_audio_feature TEXT DEFAULT 'YES',
                draft_total INTEGER DEFAULT 0,
                draft_audio_ready INTEGER DEFAULT 0,
                draft_no_audio INTEGER DEFAULT 0,
                audio_rejected_count INTEGER DEFAULT 0,
                copyright_strikes INTEGER DEFAULT 0,
                copyright_claims INTEGER DEFAULT 0,
                scheduled_count INTEGER DEFAULT 0,
                schedule_days_left INTEGER DEFAULT 0,
                schedule_level TEXT DEFAULT 'GREEN',
                dup_blocked INTEGER DEFAULT 0,
                sampled_at TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS channel_videos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER NOT NULL,
                youtube_channel_id TEXT DEFAULT '',
                channel_title TEXT DEFAULT '',
                video_id TEXT NOT NULL,
                title TEXT DEFAULT '',
                privacy TEXT DEFAULT 'public',
                is_draft INTEGER DEFAULT 0,
                scheduled_epoch INTEGER DEFAULT 0,
                published_epoch INTEGER DEFAULT 0,
                duration REAL DEFAULT 0.0,
                view_count INTEGER DEFAULT 0,
                audio_state TEXT DEFAULT 'OK',
                copyright_state TEXT DEFAULT 'NONE',
                monetization_state TEXT DEFAULT 'ON',
                updated_at TEXT DEFAULT '',
                UNIQUE(channel_id, video_id)
            );

            CREATE TABLE IF NOT EXISTS audio_repair_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER DEFAULT 0,
                channel_title TEXT DEFAULT '',
                studio_video_id TEXT NOT NULL,
                video_title TEXT DEFAULT '',
                video_kind TEXT DEFAULT 'public',
                studio_duration REAL DEFAULT 0.0,
                hitmakers_duration REAL DEFAULT 0.0,
                hitmakers_local_id TEXT DEFAULT '',
                source_path TEXT DEFAULT '',
                total_views INTEGER DEFAULT 0,
                privacy TEXT DEFAULT 'VIDEO_PRIVACY_PUBLIC',
                issue_code TEXT DEFAULT 'REJECTED',
                issue_label TEXT DEFAULT 'Audio bị từ chối / gỡ',
                audio_processed INTEGER DEFAULT 0,
                audio_rejected INTEGER DEFAULT 1,
                audio_removed INTEGER DEFAULT 0,
                repair_languages TEXT DEFAULT 'es, pt, fr, de, it',
                readd_attempts INTEGER DEFAULT 0,
                status TEXT DEFAULT 'CANDIDATE',
                progress INTEGER DEFAULT 0,
                stage TEXT DEFAULT 'Chờ xử lý',
                error TEXT DEFAULT '',
                scanned_at TEXT DEFAULT '',
                UNIQUE(channel_id, studio_video_id)
            );

            CREATE TABLE IF NOT EXISTS audio_repair_jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER DEFAULT 0,
                channel_title TEXT DEFAULT '',
                studio_video_id TEXT NOT NULL,
                video_title TEXT DEFAULT '',
                video_kind TEXT DEFAULT 'public',
                hitmakers_local_id TEXT DEFAULT '',
                studio_duration REAL DEFAULT 0.0,
                source_path TEXT DEFAULT '',
                prepared_path TEXT DEFAULT '',
                prepared_duration REAL DEFAULT 0.0,
                languages_json TEXT DEFAULT '[]',
                mode TEXT DEFAULT 'all',
                content_type TEXT DEFAULT 'global',
                attempt INTEGER DEFAULT 1,
                status TEXT DEFAULT 'DONE',
                progress INTEGER DEFAULT 100,
                stage TEXT DEFAULT 'Hoàn tất Re-Add',
                readd_check_status TEXT DEFAULT 'OK',
                readd_checked_at TEXT DEFAULT '',
                error TEXT DEFAULT '',
                created_at TEXT DEFAULT '',
                updated_at TEXT DEFAULT ''
            );
            """)
            con.commit()
        finally:
            con.close()


# ==============================================================================
# 3. ĐỒNG BỘ DỮ LIỆU & BRIDGE VỚI 3T MASTER (NẾU CÓ TRÊN MÁY)
# ==============================================================================

def _find_3t_root(cfg: dict) -> Path | None:
    custom = str(cfg.get("t3_root") or "").strip()
    candidates = []
    if custom:
        candidates.append(Path(custom))
    candidates.extend([
        Path(r"F:\3TMaster"),
        Path(r"C:\3TMaster"),
        Path(r"D:\3TMaster"),
        Path(r"E:\3TMaster"),
    ])
    for c in candidates:
        try:
            if c.is_dir() and ((c / "data").is_dir() or (c / "app").is_dir() or (c / "run.py").is_file()):
                return c
        except OSError:
            pass
    return None


def _t3_http(port: int, path: str, method: str = "GET", payload: dict | None = None, timeout: float = 4.0):
    url = f"http://127.0.0.1:{port}/{path.lstrip('/')}"
    data = None
    headers = {"User-Agent": "MyingGo-YTStudioHub/1.0"}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read().decode("utf-8", errors="replace")
        return json.loads(raw) if raw else {}


def _check_t3_live(port: int = 8891) -> dict:
    try:
        res = _t3_http(port, "/api/health", timeout=1.5)
        return {"alive": True, "version": res.get("version") or "2.5.x", "locked": False}
    except urllib.error.HTTPError as e:
        if e.code == 423:
            return {"alive": True, "version": "2.5.x", "locked": True}
        return {"alive": False, "error": f"HTTP {e.code}"}
    except Exception as e:
        return {"alive": False, "error": str(e)}


def _open_external_sqlite(db_path: Path) -> sqlite3.Connection:
    """Mở an toàn file SQLite ngoài (hỗ trợ cả khi 3TMaster đang mở hoặc khóa WAL)."""
    for attempt in range(3):
        try:
            if attempt == 0:
                con = sqlite3.connect(str(db_path), timeout=5.0)
            elif attempt == 1:
                con = sqlite3.connect(f"{db_path.as_uri()}?mode=ro", uri=True, timeout=5.0)
            else:
                con = sqlite3.connect(f"{db_path.as_uri()}?immutable=1", uri=True, timeout=5.0)
            con.row_factory = sqlite3.Row
            return con
        except Exception:
            if attempt == 2:
                raise
    raise RuntimeError(f"Cannot open {db_path}")


def sync_from_3t_sqlite(t3_root: Path | None, port: int = 8891) -> dict:
    """Đồng bộ toàn diện từ 3TMaster (F:\3TMaster, C:\3TMaster, SQLite trực tiếp + HTTP API 127.0.0.1:8891 + Kho tài khoản Warehouse & Thumbnail Studio)."""
    stats = {"accounts": 0, "channels": 0, "monitor": 0, "ar_items": 0, "ar_jobs": 0}
    _init_db()

    # Tìm các vị trí có thể chứa hd_master.db và audio_repair_jobs.db
    local_app = Path(os.environ.get("LOCALAPPDATA") or str(Path.home()))
    db_dirs = []
    if t3_root:
        db_dirs.extend([t3_root / "data", t3_root / "data" / "recovery_backups"])
    db_dirs.extend([
        Path(r"F:\3TMaster\data"),
        Path(r"C:\3TMaster\data"),
        Path(r"D:\3TMaster\data"),
        local_app / "3TMaster" / "data",
        local_app / "HDMaster" / "data",
    ])
    hd_db = next((d / "hd_master.db" for d in db_dirs if (d / "hd_master.db").is_file()), None)
    ar_db = next((d / "audio_repair_jobs.db" for d in db_dirs if (d / "audio_repair_jobs.db").is_file()), None)
    if not t3_root and hd_db:
        t3_root = hd_db.parent.parent

    with _DB_LOCK:
        con = _db_conn()
        try:
            # -------------------------------------------------------------
            # A. ĐỒNG BỘ TÀI KHOẢN (ACCOUNTS)
            # -------------------------------------------------------------
            # 1. Từ native_bridge/yatranslator_runtime/auth/storage/google-accounts.json (Tài khoản chính 3T)
            if t3_root:
                ga_f = t3_root / "native_bridge" / "yatranslator_runtime" / "auth" / "storage" / "google-accounts.json"
                if ga_f.is_file():
                    try:
                        ga = json.loads(ga_f.read_text(encoding="utf-8"))
                        for a in ga.get("accounts") or []:
                            em = str(a.get("email") or "").strip().lower()
                            if not em or "@" not in em:
                                continue
                            pw_raw = str(a.get("password") or "").strip()
                            pw_enc = dpapi_protect(pw_raw) if pw_raw else ""
                            tfa_raw = str(a.get("twoFactorSecret") or a.get("totp_secret") or "").strip()
                            tfa_enc = dpapi_protect(tfa_raw) if tfa_raw else ""
                            pdir = str(t3_root / "data" / "profiles" / re.sub(r"[^a-zA-Z0-9_.-]", "_", em))
                            con.execute("""
                                INSERT INTO accounts (
                                    email, name, password_enc, tfa_secret_enc, profile_dir, label, session_status, updated_at
                                ) VALUES (?, ?, ?, ?, ?, 'Tài khoản chính 3T', 'READY', ?)
                                ON CONFLICT(email) DO UPDATE SET
                                    password_enc=CASE WHEN excluded.password_enc!='' THEN excluded.password_enc ELSE accounts.password_enc END,
                                    tfa_secret_enc=CASE WHEN excluded.tfa_secret_enc!='' THEN excluded.tfa_secret_enc ELSE accounts.tfa_secret_enc END,
                                    profile_dir=CASE WHEN excluded.profile_dir!='' THEN excluded.profile_dir ELSE accounts.profile_dir END,
                                    label=excluded.label,
                                    updated_at=excluded.updated_at
                            """, (em, em, pw_enc, tfa_enc, pdir, _now_iso()))
                            stats["accounts"] += 1
                    except Exception:
                        pass

            # 2. Từ Kho tài khoản Warehouse 3T (data/thumbnail_studio/account_warehouse_v12.json)
            if t3_root:
                wh_f = t3_root / "data" / "thumbnail_studio" / "account_warehouse_v12.json"
                if wh_f.is_file():
                    try:
                        wh = json.loads(wh_f.read_text(encoding="utf-8"))
                        for k, v in ((wh.get("vault") or {}).get("accounts") or {}).items():
                            if not isinstance(v, dict):
                                continue
                            em = str(v.get("email") or "").strip().lower()
                            if not em or "@" not in em:
                                continue
                            pw_raw = str(v.get("password") or "").strip()
                            pw_enc = dpapi_protect(pw_raw) if pw_raw else ""
                            tfa_raw = str(v.get("totp_secret") or v.get("two_fa") or v.get("tfa") or "").strip()
                            tfa_enc = dpapi_protect(tfa_raw) if tfa_raw else ""
                            prof_cand = t3_root / "addons" / "thumbnail_studio" / "profiles" / str(k)
                            pdir = str(prof_cand) if prof_cand.is_dir() else str(t3_root / "data" / "profiles" / re.sub(r"[^a-zA-Z0-9_.-]", "_", em))
                            con.execute("""
                                INSERT INTO accounts (
                                    email, name, password_enc, tfa_secret_enc, recovery_email,
                                    profile_dir, label, session_status, updated_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'READY', ?)
                                ON CONFLICT(email) DO UPDATE SET
                                    password_enc=CASE WHEN excluded.password_enc!='' THEN excluded.password_enc ELSE accounts.password_enc END,
                                    tfa_secret_enc=CASE WHEN excluded.tfa_secret_enc!='' THEN excluded.tfa_secret_enc ELSE accounts.tfa_secret_enc END,
                                    recovery_email=CASE WHEN excluded.recovery_email!='' THEN excluded.recovery_email ELSE accounts.recovery_email END,
                                    profile_dir=CASE WHEN accounts.profile_dir='' AND excluded.profile_dir!='' THEN excluded.profile_dir ELSE accounts.profile_dir END,
                                    label=CASE WHEN accounts.label='' THEN excluded.label ELSE accounts.label END,
                                    updated_at=excluded.updated_at
                            """, (em, f"{k} • {em}", pw_enc, tfa_enc, str(v.get("recovery_email") or ""), pdir, f"Kho {k}", _now_iso()))
                            stats["accounts"] += 1
                    except Exception:
                        pass

            # 3. Từ Kho tài khoản Thumbnail Studio nội bộ (addons/thumbnail_studio/login_vault.json)
            thumb_vault = ROOT / "addons" / "thumbnail_studio" / "login_vault.json"
            thumb_profs = ROOT / "addons" / "thumbnail_studio" / "profiles"
            if thumb_vault.is_file():
                try:
                    tv = json.loads(thumb_vault.read_text(encoding="utf-8"))
                    for k, v in (tv.get("accounts") or {}).items():
                        if not isinstance(v, dict):
                            continue
                        em = str(v.get("email") or "").strip().lower()
                        if not em or "@" not in em:
                            continue
                        pw_raw = str(v.get("password") or "").strip()
                        pw_enc = dpapi_protect(pw_raw) if pw_raw else ""
                        tfa_raw = str(v.get("totp_secret") or v.get("two_fa") or v.get("tfa") or "").strip()
                        tfa_enc = dpapi_protect(tfa_raw) if tfa_raw else ""
                        prof_cand = thumb_profs / str(k)
                        pdir = str(prof_cand) if prof_cand.is_dir() else str(PROFILES_DIR / re.sub(r"[^a-zA-Z0-9_.-]", "_", em))
                        con.execute("""
                            INSERT INTO accounts (
                                email, name, password_enc, tfa_secret_enc, recovery_email,
                                profile_dir, label, session_status, updated_at
                            ) VALUES (?, ?, ?, ?, ?, ?, 'Thumbnail Studio', 'READY', ?)
                            ON CONFLICT(email) DO UPDATE SET
                                password_enc=CASE WHEN accounts.password_enc='' AND excluded.password_enc!='' THEN excluded.password_enc ELSE accounts.password_enc END,
                                tfa_secret_enc=CASE WHEN accounts.tfa_secret_enc='' AND excluded.tfa_secret_enc!='' THEN excluded.tfa_secret_enc ELSE accounts.tfa_secret_enc END,
                                recovery_email=CASE WHEN accounts.recovery_email='' AND excluded.recovery_email!='' THEN excluded.recovery_email ELSE accounts.recovery_email END,
                                profile_dir=CASE WHEN accounts.profile_dir='' AND excluded.profile_dir!='' THEN excluded.profile_dir ELSE accounts.profile_dir END,
                                label=CASE WHEN accounts.label='' THEN excluded.label ELSE accounts.label END,
                                updated_at=excluded.updated_at
                        """, (em, f"{k} • {em}", pw_enc, tfa_enc, str(v.get("recovery_email") or ""), pdir, _now_iso()))
                        stats["accounts"] += 1
                except Exception:
                    pass

            # 4. Từ HTTP API 127.0.0.1:8891 nếu 3TMaster đang mở
            try:
                http_accs = _t3_http(port, "/api/accounts", timeout=2.0)
                if isinstance(http_accs, dict):
                    http_accs = http_accs.get("accounts") or http_accs.get("items") or []
                if isinstance(http_accs, list):
                    for a in http_accs:
                        if not isinstance(a, dict):
                            continue
                        em = str(a.get("email") or a.get("name") or "").strip().lower()
                        if not em:
                            continue
                        con.execute("""
                            INSERT INTO accounts (email, name, enabled, session_status, channel_count, label, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(email) DO UPDATE SET
                                session_status=excluded.session_status,
                                channel_count=MAX(accounts.channel_count, excluded.channel_count),
                                updated_at=excluded.updated_at
                        """, (
                            em, str(a.get("name") or em), int(a.get("enabled", 1)),
                            str(a.get("session_status") or "READY"),
                            int(a.get("last_channel_load_count") or a.get("channel_count") or 0),
                            str(a.get("label") or ""), _now_iso()
                        ))
                        stats["accounts"] += 1
            except Exception:
                pass

            # -------------------------------------------------------------
            # B. ĐỒNG BỘ KÊNH (CHANNELS) TỪ NATIVE BRIDGE, COOKIES & LOGS
            # -------------------------------------------------------------
            channels_pool = {}  # uc -> dict channel
            primary_email = "themanh@3tagent.com"

            # 1. Native bridge channel-cookies & channel-owners
            if t3_root:
                owners_f = t3_root / "native_bridge" / "yatranslator_runtime" / "auth" / "storage" / "channel-owners.json"
                owners = json.loads(owners_f.read_text(encoding="utf-8")) if owners_f.is_file() else {}

                status_f = t3_root / "native_bridge" / "yamaster_channel_runtime" / "storage" / "channel-session-status.json"
                status_data = json.loads(status_f.read_text(encoding="utf-8")) if status_f.is_file() else {}

                acc_cookies_dir = t3_root / "native_bridge" / "yatranslator_runtime" / "auth" / "channel-cookies" / "accounts"
                if acc_cookies_dir.is_dir():
                    for a_dir in acc_cookies_dir.iterdir():
                        if not a_dir.is_dir():
                            continue
                        owner_mail = a_dir.name.replace("_at_", "@").replace("_", ".")
                        for cf in a_dir.glob("*-channel-code.txt"):
                            slug = cf.name.replace("-channel-code.txt", "")
                            try:
                                uc = cf.read_text(encoding="utf-8").strip()
                            except Exception:
                                continue
                            if not uc:
                                continue
                            clean_t = slug.replace("-", " ").title()
                            st = status_data.get(slug, {})
                            s_stat = "ERROR" if st.get("status") == "error" else "PINNED"
                            s_msg = st.get("message") or "Phiên Studio Pinned"
                            assigned_email = owners.get(slug, {}).get("email") or owner_mail or primary_email
                            channels_pool[uc] = {
                                "youtube_channel_id": uc,
                                "title": clean_t,
                                "account_email": assigned_email,
                                "session_status": s_stat,
                                "studio_session_status": "PINNED",
                                "session_message": s_msg,
                                "key_folder": slug,
                            }

                # 2. Switcher logs (data/logs/channel-switcher)
                sw_dir = t3_root / "data" / "logs" / "channel-switcher"
                if sw_dir.is_dir():
                    for f in sw_dir.glob("*.json"):
                        try:
                            d = json.loads(f.read_text(encoding="utf-8"))
                            uc = d.get("youtube_channel_id") or d.get("channel_id") or ""
                            if not uc:
                                m = re.search(r"(UC[A-Za-z0-9_-]{22})", f.name)
                                if m: uc = m.group(1)
                            title = d.get("channel_title") or d.get("title") or ""
                            if uc:
                                if uc not in channels_pool:
                                    channels_pool[uc] = {
                                        "youtube_channel_id": uc,
                                        "title": title or uc,
                                        "account_email": primary_email,
                                        "session_status": "PINNED",
                                        "studio_session_status": "PINNED",
                                        "session_message": "Ghim từ Channel Switcher",
                                        "key_folder": "",
                                    }
                                elif title and channels_pool[uc]["title"] == uc:
                                    channels_pool[uc]["title"] = title
                        except Exception:
                            pass

            # -------------------------------------------------------------
            # C. ĐỒNG BỘ TỪ SQLITE hd_master.db (Accounts, Channels, Metrics, Audio)
            # -------------------------------------------------------------
            if hd_db and hd_db.is_file():
                src = _open_external_sqlite(hd_db)
                try:
                    # 1. Accounts trong hd_master.db
                    acc_map = {}
                    try:
                        for r in src.execute("SELECT * FROM accounts").fetchall():
                            d = dict(r)
                            email = str(d.get("email") or d.get("name") or "").strip().lower()
                            if not email:
                                continue
                            acc_map[d["id"]] = email
                            con.execute("""
                                INSERT INTO accounts (email, name, profile_dir, cookie_path, enabled, session_status,
                                    session_message, channel_count, recovery_email, recovery_phone, note, label, updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                ON CONFLICT(email) DO UPDATE SET
                                    name=excluded.name,
                                    profile_dir=CASE WHEN excluded.profile_dir!='' THEN excluded.profile_dir ELSE accounts.profile_dir END,
                                    enabled=excluded.enabled,
                                    session_status=excluded.session_status,
                                    session_message=excluded.session_message,
                                    channel_count=MAX(accounts.channel_count, excluded.channel_count),
                                    updated_at=excluded.updated_at
                            """, (
                                email, str(d.get("name") or email), str(d.get("profile_dir") or ""),
                                str(d.get("crawl_cookie_path") or ""), int(d.get("enabled") or 1),
                                str(d.get("session_status") or "READY"), str(d.get("session_message") or ""),
                                int(d.get("last_channel_load_count") or 0), str(d.get("recovery_email") or ""),
                                str(d.get("recovery_phone") or ""), str(d.get("note") or ""), str(d.get("label") or ""),
                                str(d.get("session_checked_at") or _now_iso()),
                            ))
                            stats["accounts"] += 1
                    except Exception:
                        pass

                    # 2. Extract channel activations from logs table
                    try:
                        for r in src.execute("SELECT DISTINCT message FROM logs WHERE message LIKE '%Đã kích hoạt đúng kênh%'").fetchall():
                            m = re.search(r"Đã kích hoạt đúng kênh\s*•\s*(.*?)\s*•\s*actual=(UC[A-Za-z0-9_-]{22})", r[0])
                            if m:
                                t, uc = m.group(1).strip(), m.group(2).strip()
                                if uc not in channels_pool:
                                    channels_pool[uc] = {
                                        "youtube_channel_id": uc,
                                        "title": t,
                                        "account_email": primary_email,
                                        "session_status": "PINNED",
                                        "studio_session_status": "PINNED",
                                        "session_message": "Đã kích hoạt trong phiên Studio",
                                        "key_folder": "",
                                    }
                                else:
                                    channels_pool[uc]["title"] = t
                    except Exception:
                        pass

                    # 3. Extract channels from video_cleanup_history
                    try:
                        for r in src.execute("SELECT DISTINCT youtube_channel_id, channel_title FROM video_cleanup_history WHERE youtube_channel_id != ''").fetchall():
                            uc = r["youtube_channel_id"]
                            t = r["channel_title"]
                            if uc not in channels_pool:
                                channels_pool[uc] = {
                                    "youtube_channel_id": uc,
                                    "title": t,
                                    "account_email": primary_email,
                                    "session_status": "PINNED",
                                    "studio_session_status": "PINNED",
                                    "session_message": "",
                                    "key_folder": "",
                                }
                            elif t:
                                channels_pool[uc]["title"] = t
                    except Exception:
                        pass

                    # 4. Check if channels table exists with rows
                    try:
                        for r in src.execute("SELECT * FROM channels").fetchall():
                            d = dict(r)
                            uc = str(d.get("youtube_channel_id") or "").strip()
                            if not uc:
                                continue
                            email = acc_map.get(d.get("account_id"), "") or primary_email
                            channels_pool[uc] = {
                                "youtube_channel_id": uc,
                                "title": str(d.get("title") or uc),
                                "account_email": email,
                                "subscriber_count": int(d.get("subscriber_count") or 0),
                                "video_count": int(d.get("video_count") or 0),
                                "view_count": int(d.get("view_count") or 0),
                                "monetization_status": str(d.get("monetization_status") or "UNKNOWN"),
                                "session_status": str(d.get("session_status") or "OK"),
                                "studio_session_status": str(d.get("studio_session_status") or "PINNED"),
                                "key_folder": str(d.get("key_folder") or ""),
                            }
                    except Exception:
                        pass

                    # 5. Extract Channel Monitor Metrics from channel_monitor_latest
                    cm_by_title = {}
                    cid_to_name = {}
                    try:
                        for r in src.execute("SELECT DISTINCT channel_id, channel_title FROM audio_repair_scan_items").fetchall():
                            cid_to_name[r["channel_id"]] = r["channel_title"]
                        for r in src.execute("SELECT DISTINCT channel_id, channel_title FROM video_cleanup_history").fetchall():
                            cid_to_name[r["channel_id"]] = r["channel_title"]
                    except Exception:
                        pass

                    try:
                        for mr in src.execute("SELECT * FROM channel_monitor_latest").fetchall():
                            md = dict(mr)
                            cid = md["channel_id"]
                            c_name = cid_to_name.get(cid)
                            if c_name:
                                cm_by_title[c_name.strip().lower()] = md
                            stats["monitor"] += 1
                    except Exception:
                        pass

                    # Write all collected channels to database
                    for uc, c in channels_pool.items():
                        c_title = c.get("title") or uc
                        cm = cm_by_title.get(c_title.strip().lower(), {})
                        subs = int(cm.get("subscriber_count") or c.get("subscriber_count") or 0)
                        vids = int(cm.get("video_count") or c.get("video_count") or 0)
                        views = int(cm.get("total_views") or c.get("view_count") or 0)
                        views_28d = int(cm.get("views_28d") or 0)
                        views_48h = int(cm.get("views_latest_day") or 0)
                        rev_m = float(cm.get("revenue_month") or 0.0)
                        rev_28 = float(cm.get("revenue_28d") or 0.0)
                        mon_st = str(cm.get("monetization_status") or c.get("monetization_status") or "UNKNOWN")
                        draft_tot = int(cm.get("draft_total") or 0)
                        draft_ok = int(cm.get("draft_audio_ready") or 0)
                        draft_no = int(cm.get("draft_no_audio") or 0)
                        sched_cnt = int(cm.get("scheduled_count") or 0)
                        sched_days = int(cm.get("schedule_days_left") if cm.get("schedule_days_left") is not None else 0)
                        sched_lvl = str(cm.get("schedule_level") or ("GREEN" if sched_days > 15 else ("YELLOW" if sched_days >= 6 else "RED")))

                        con.execute("""
                            INSERT INTO channels (
                                account_email, youtube_channel_id, title, key_folder, enabled,
                                session_status, studio_session_status, session_message,
                                subscriber_count, video_count, view_count, views_48h, views_28d,
                                revenue_month, revenue_28d, monetization_status,
                                draft_total, draft_audio_ready, draft_no_audio,
                                scheduled_count, schedule_days_left, schedule_level,
                                sampled_at, updated_at
                            ) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(youtube_channel_id) DO UPDATE SET
                                title=excluded.title,
                                account_email=CASE WHEN excluded.account_email!='' THEN excluded.account_email ELSE channels.account_email END,
                                key_folder=CASE WHEN excluded.key_folder!='' THEN excluded.key_folder ELSE channels.key_folder END,
                                session_status=excluded.session_status,
                                studio_session_status=excluded.studio_session_status,
                                session_message=excluded.session_message,
                                subscriber_count=excluded.subscriber_count,
                                video_count=excluded.video_count,
                                view_count=excluded.view_count,
                                views_48h=excluded.views_48h,
                                views_28d=excluded.views_28d,
                                revenue_month=excluded.revenue_month,
                                revenue_28d=excluded.revenue_28d,
                                monetization_status=excluded.monetization_status,
                                draft_total=excluded.draft_total,
                                draft_audio_ready=excluded.draft_audio_ready,
                                draft_no_audio=excluded.draft_no_audio,
                                scheduled_count=excluded.scheduled_count,
                                schedule_days_left=excluded.schedule_days_left,
                                schedule_level=excluded.schedule_level,
                                sampled_at=excluded.sampled_at,
                                updated_at=excluded.updated_at
                        """, (
                            str(c.get("account_email") or primary_email), uc, c_title, str(c.get("key_folder") or ""),
                            str(c.get("session_status") or "OK"), str(c.get("studio_session_status") or "PINNED"),
                            str(c.get("session_message") or "Phiên Studio Pinned"),
                            subs, vids, views, views_48h, views_28d, rev_m, rev_28, mon_st,
                            draft_tot, draft_ok, draft_no, sched_cnt, sched_days, sched_lvl,
                            str(cm.get("sampled_at") or _now_iso()), _now_iso()
                        ))
                        stats["channels"] += 1

                    # 6. Audio Repair Scan Items (851 items)
                    try:
                        for ar in src.execute("SELECT * FROM audio_repair_scan_items LIMIT 1000").fetchall():
                            ad = dict(ar)
                            vid = str(ad.get("studio_video_id") or "").strip()
                            if not vid:
                                continue
                            ch_t = str(ad.get("channel_title") or "").strip()
                            langs = ad.get("repair_languages_json") or "[]"
                            try:
                                l_arr = json.loads(langs)
                                langs_str = ", ".join(l_arr) if isinstance(l_arr, list) else str(langs)
                            except Exception:
                                langs_str = str(langs)
                            con.execute("""
                                INSERT INTO audio_repair_items (
                                    channel_id, channel_title, studio_video_id, video_title, video_kind,
                                    studio_duration, total_views, privacy, issue_code, issue_label,
                                    audio_processed, audio_rejected, audio_removed, repair_languages, scanned_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                ON CONFLICT(channel_id, studio_video_id) DO UPDATE SET
                                    channel_title=excluded.channel_title,
                                    video_title=excluded.video_title,
                                    total_views=excluded.total_views,
                                    issue_code=excluded.issue_code,
                                    issue_label=excluded.issue_label,
                                    audio_processed=excluded.audio_processed,
                                    audio_rejected=excluded.audio_rejected,
                                    audio_removed=excluded.audio_removed,
                                    scanned_at=excluded.scanned_at
                            """, (
                                int(ad.get("channel_id") or 0), ch_t or "YouTube Channel", vid,
                                str(ad.get("video_title") or vid), str(ad.get("video_kind") or "public"),
                                float(ad.get("studio_duration") or 0.0), int(ad.get("total_views") or 0),
                                str(ad.get("privacy") or "VIDEO_PRIVACY_PUBLIC"),
                                str(ad.get("issue_code") or "FAILED"),
                                str(ad.get("issue_label") or "Không xử lý được"),
                                int(ad.get("audio_processed") or 0),
                                int(ad.get("audio_rejected") or 0),
                                int(ad.get("audio_removed") or 0),
                                langs_str or "es, pt, fr, de, it",
                                str(ad.get("scanned_at") or _now_iso())
                            ))
                            stats["ar_items"] += 1
                    except Exception:
                        pass
                finally:
                    src.close()

            # -------------------------------------------------------------
            # D. ĐỒNG BỘ AUDIO REPAIR JOBS
            # -------------------------------------------------------------
            if ar_db and ar_db.is_file():
                src2 = _open_external_sqlite(ar_db)
                try:
                    for jr in src2.execute("SELECT * FROM audio_repair_jobs ORDER BY id DESC LIMIT 500").fetchall():
                        jd = dict(jr)
                        vid = str(jd.get("studio_video_id") or "").strip()
                        if not vid:
                            continue
                        con.execute("""
                            INSERT INTO audio_repair_jobs (
                                id, channel_id, channel_title, studio_video_id, video_title, video_kind,
                                hitmakers_local_id, studio_duration, source_path, prepared_path,
                                prepared_duration, languages_json, attempt, status, progress, stage,
                                error, created_at, updated_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(id) DO UPDATE SET
                                status=excluded.status,
                                progress=excluded.progress,
                                stage=excluded.stage,
                                attempt=excluded.attempt,
                                error=excluded.error,
                                updated_at=excluded.updated_at
                        """, (
                            int(jd["id"]), int(jd.get("channel_id") or 0),
                            str(jd.get("channel_title") or ""), vid,
                            str(jd.get("video_title") or vid), str(jd.get("video_kind") or "public"),
                            str(jd.get("hitmakers_local_id") or ""), float(jd.get("studio_duration") or 0.0),
                            str(jd.get("source_path") or ""), str(jd.get("prepared_path") or ""),
                            float(jd.get("prepared_duration") or 0.0), str(jd.get("languages_json") or "[]"),
                            int(jd.get("attempt") or 1), str(jd.get("status") or "READY"),
                            int(jd.get("progress") or 0), str(jd.get("stage") or ""),
                            str(jd.get("error") or ""), str(jd.get("created_at") or _now_iso()),
                            str(jd.get("updated_at") or _now_iso())
                        ))
                        stats["ar_jobs"] += 1
                finally:
                    src2.close()

            # Đồng bộ liên kết account_id & channel_count
            email_to_acc_id = {
                row["email"]: row["id"]
                for row in con.execute("SELECT id, email FROM accounts").fetchall()
            }
            for email, aid in email_to_acc_id.items():
                con.execute("UPDATE channels SET account_id=? WHERE account_email=?", (aid, email))
                cnt = con.execute("SELECT COUNT(*) FROM channels WHERE account_id=? OR account_email=?", (aid, email)).fetchone()[0]
                con.execute("UPDATE accounts SET channel_count=? WHERE id=?", (cnt, aid))

            # Cập nhật số lượng audio_rejected_count cho từng kênh
            con.execute("""
                UPDATE channels SET audio_rejected_count = (
                    SELECT COUNT(*) FROM audio_repair_items
                    WHERE audio_repair_items.channel_id = channels.id
                       OR audio_repair_items.channel_title = channels.title
                )
            """)
            con.commit()
        finally:
            con.close()
    return stats


# ==============================================================================
# 4. QUÉT KÊNH QUA HTTP INNERTUBE & FFmpeg AUDIO REPAIR ENGINE
# ==============================================================================

def _parse_netscape_cookies(cookie_text_or_path: str) -> dict[str, str]:
    cookies = {}
    raw = str(cookie_text_or_path or "").strip()
    if not raw:
        return cookies
    p = Path(raw)
    if p.is_file():
        try:
            raw = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return cookies
    # Hỗ trợ cả JSON format và Netscape format
    if raw.startswith("[") or raw.startswith("{"):
        try:
            obj = json.loads(raw)
            rows = obj if isinstance(obj, list) else (obj.get("cookies") or [])
            for c in rows:
                if isinstance(c, dict) and c.get("name"):
                    cookies[str(c["name"])] = str(c.get("value") or "")
            return cookies
        except Exception:
            pass
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            cookies[parts[5].strip()] = parts[6].strip()
    return cookies


def discover_account_channels_http(cookies: dict[str, str]) -> list[dict]:
    """Quét danh sách kênh (Own + Brand + Delegated) bằng 1 HTTP call tới InnerTube account/accounts_list."""
    sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or ""
    if not sapisid:
        return []
    now_sec = int(time.time())
    origin = "https://www.youtube.com"
    sapisidhash = hashlib.sha1(f"{now_sec} {sapisid} {origin}".encode("utf-8")).hexdigest()
    cookie_header = "; ".join(f"{k}={v}" for k, v in cookies.items())
    headers = {
        "User-Agent": _UA,
        "Origin": origin,
        "Referer": "https://www.youtube.com/",
        "Cookie": cookie_header,
        "Authorization": f"SAPISIDHASH {now_sec}_{sapisidhash}",
        "X-Origin": origin,
        "Content-Type": "application/json",
    }
    body = {
        "context": {
            "client": {
                "clientName": "WEB",
                "clientVersion": "2.20250201.00.00",
                "hl": "vi",
                "gl": "VN",
            }
        }
    }
    url = f"https://www.youtube.com/youtubei/v1/account/accounts_list?key={_YT_WEB_API_KEY}&prettyPrint=false"
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=15) as r:
        data = json.loads(r.read().decode("utf-8", errors="replace"))

    found = []
    seen_uc = set()

    def _walk(node):
        if isinstance(node, dict):
            # Tìm accountItem renderer
            acc_item = node.get("accountItem")
            if isinstance(acc_item, dict):
                raw_str = json.dumps(acc_item, ensure_ascii=False)
                m = _UC_RE.search(raw_str)
                if m:
                    uc = m.group(1)
                    if uc not in seen_uc:
                        seen_uc.add(uc)
                        title = ""
                        name_obj = acc_item.get("accountName") or {}
                        if isinstance(name_obj, dict):
                            title = name_obj.get("simpleText") or ""
                            if not title and isinstance(name_obj.get("runs"), list) and name_obj["runs"]:
                                title = "".join(str(x.get("text") or "") for x in name_obj["runs"])
                        handle = ""
                        h_obj = acc_item.get("channelHandle") or {}
                        if isinstance(h_obj, dict):
                            handle = h_obj.get("simpleText") or ""
                        avatar = ""
                        thumbs = ((acc_item.get("accountPhoto") or {}).get("thumbnails") or [])
                        if thumbs and isinstance(thumbs[-1], dict):
                            avatar = str(thumbs[-1].get("url") or "")
                        found.append({
                            "youtube_channel_id": uc,
                            "title": title or uc,
                            "handle": handle,
                            "avatar_url": avatar,
                        })
            for v in node.values():
                _walk(v)
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    _walk(data)
    return found


def render_aligned_audio_ffmpeg(
    source_path: str | Path,
    target_duration: float,
    mode: str = "all",
    out_dir: Path = AUDIO_TEMP_DIR,
) -> tuple[str, float]:
    """Căn chỉnh thời lượng file audio bằng FFmpeg (Trim đuôi / bù khoảng lặng / chế độ 3s âm + 7s lặng)."""
    src = Path(source_path)
    if not src.is_file():
        raise FileNotFoundError(f"Không tìm thấy file audio nguồn: {src}")
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = re.sub(r"[^a-zA-Z0-9_-]", "_", src.stem)[:40]
    out_file = out_dir / f"{stem}_readd_{mode}_{int(time.time())}.m4a"
    ffmpeg = _find_ffmpeg()

    af_filters = []
    if mode == "alt_3s_7s":
        # 3 giây có âm + 7 giây im lặng lặp xen kẽ suốt chiều dài
        af_filters.append("volume='if(lt(mod(t,10),3),1,0)':eval=frame")
    if target_duration > 1.0:
        # Pad khoảng lặng nếu nguồn ngắn hơn rồi cắt đúng bằng target_duration
        af_filters.append("apad")

    cmd = [ffmpeg, "-y", "-i", str(src), "-vn"]
    if af_filters:
        cmd.extend(["-af", ",".join(af_filters)])
    if target_duration > 1.0:
        cmd.extend(["-t", f"{target_duration:.2f}"])
    cmd.extend(["-c:a", "aac", "-b:a", "192k", str(out_file)])

    cp = subprocess.run(cmd, capture_output=True, text=True, timeout=300, creationflags=_NOWIN)
    if cp.returncode != 0 or not out_file.is_file():
        raise RuntimeError(f"FFmpeg lỗi khi chuẩn bị audio: {(cp.stderr or '')[-300:]}")
    dur = _probe_duration(out_file) or target_duration
    return str(out_file), dur


# ==============================================================================
# 5. LỚP FEATURE CHÍNH TRONG MYINGGO
# ==============================================================================

class YTStudioHub(Feature):
    title = "📡 Quản lý Kênh & Audio"
    order = 12

    def __init__(self):
        super().__init__()
        self._cfg_lock = threading.RLock()
        self._initial_synced = False
        self._ar_stop = threading.Event()
        self._ar_running = False
        self._cm_running = False
        _init_db()
        self._try_initial_sync()

    def _load_cfg(self) -> dict:
        with self._cfg_lock:
            cfg = dict(DEFAULT_CONFIG)
            if HUB_CFG.is_file():
                try:
                    saved = json.loads(HUB_CFG.read_text(encoding="utf-8"))
                    if isinstance(saved, dict):
                        cfg.update(saved)
                        if isinstance(saved.get("cm_auto_ops"), dict):
                            ops = dict(DEFAULT_CONFIG["cm_auto_ops"])
                            ops.update(saved["cm_auto_ops"])
                            cfg["cm_auto_ops"] = ops
                except Exception:
                    pass
            return cfg

    def _save_cfg(self, patch: dict) -> dict:
        with self._cfg_lock:
            cfg = self._load_cfg()
            for k, v in (patch or {}).items():
                if k == "cm_auto_ops" and isinstance(v, dict):
                    ops = dict(cfg.get("cm_auto_ops") or DEFAULT_CONFIG["cm_auto_ops"])
                    ops.update(v)
                    cfg["cm_auto_ops"] = ops
                elif k == "ar_hitmakers_pass":
                    if v:
                        cfg["ar_hitmakers_pass_dpapi"] = dpapi_protect(str(v))
                else:
                    cfg[k] = v
            HUB_CFG.parent.mkdir(parents=True, exist_ok=True)
            HUB_CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            return cfg

    def _try_initial_sync(self):
        if self._initial_synced:
            return
        self._initial_synced = True
        try:
            with _DB_LOCK:
                con = _db_conn()
                ch_count = con.execute("SELECT COUNT(*) FROM channels").fetchone()[0]
                con.close()
            if ch_count == 0:
                cfg = self._load_cfg()
                t3 = _find_3t_root(cfg)
                sync_from_3t_sqlite(t3, int(cfg.get("t3_port") or 8891))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # TRẠNG THÁI TỔNG HỢP (SNAPSHOT CHO CẢ 4 TAB)
    # ------------------------------------------------------------------
    def act_snapshot(self, data):
        cfg = self._load_cfg()
        t3_root = _find_3t_root(cfg)
        t3_live = _check_t3_live(int(cfg.get("t3_port") or 8891))

        with _DB_LOCK:
            con = _db_conn()
            try:
                accs = []
                for r in con.execute("SELECT * FROM accounts ORDER BY id ASC").fetchall():
                    d = dict(r)
                    pw_plain = dpapi_unprotect(d.get("password_enc") or "")
                    tfa_plain = dpapi_unprotect(d.get("tfa_secret_enc") or "")
                    otp_info = totp_now(tfa_plain) if tfa_plain else {"code": "", "remaining": 30, "valid": False}
                    accs.append({
                        "id": d["id"],
                        "email": d["email"],
                        "name": d.get("name") or d["email"],
                        "has_password": bool(pw_plain),
                        "password": pw_plain if data.get("reveal_secrets") else ("••••••••" if pw_plain else ""),
                        "has_tfa": bool(tfa_plain),
                        "tfa_secret": tfa_plain if data.get("reveal_secrets") else ("••••••••" if tfa_plain else ""),
                        "otp_code": otp_info["code"],
                        "otp_remaining": otp_info["remaining"],
                        "recovery_email": d.get("recovery_email") or "",
                        "recovery_phone": d.get("recovery_phone") or "",
                        "profile_dir": d.get("profile_dir") or "",
                        "cookie_path": d.get("cookie_path") or "",
                        "enabled": bool(d.get("enabled", 1)),
                        "session_status": d.get("session_status") or "READY",
                        "session_message": d.get("session_message") or "",
                        "channel_count": int(d.get("channel_count") or 0),
                        "note": d.get("note") or "",
                        "label": d.get("label") or "",
                        "updated_at": d.get("updated_at") or "",
                    })

                channels = [dict(r) for r in con.execute("SELECT * FROM channels ORDER BY title COLLATE NOCASE ASC").fetchall()]
                ar_items = [dict(r) for r in con.execute("SELECT * FROM audio_repair_items ORDER BY total_views DESC, id DESC LIMIT 600").fetchall()]
                ar_jobs = [dict(r) for r in con.execute("SELECT * FROM audio_repair_jobs ORDER BY id DESC LIMIT 200").fetchall()]
            finally:
                con.close()

        # Tính toán KPI cho Channel Monitor
        total_ch = len(channels)
        mon_on = sum(1 for c in channels if str(c.get("monetization_status") or "").upper() in ("ON", "ACTIVE", "MONETIZED"))
        mon_bad = sum(1 for c in channels if str(c.get("monetization_status") or "").upper() in ("DISABLED", "REJECTED", "SUSPENDED", "APPEAL_REVIEW"))
        sched_red = sum(1 for c in channels if str(c.get("schedule_level") or "").upper() == "RED" or int(c.get("schedule_days_left") or 0) <= 5)
        sched_yellow = sum(1 for c in channels if str(c.get("schedule_level") or "").upper() == "YELLOW" or (5 < int(c.get("schedule_days_left") or 0) <= 15))
        sched_green = max(0, total_ch - sched_red - sched_yellow)
        total_subs = sum(int(c.get("subscriber_count") or 0) for c in channels)
        total_views = sum(int(c.get("view_count") or 0) for c in channels)
        views_28d = sum(int(c.get("views_28d") or 0) for c in channels)
        rev_month = round(sum(float(c.get("revenue_month") or 0.0) for c in channels), 2)
        rev_28d = round(sum(float(c.get("revenue_28d") or 0.0) for c in channels), 2)
        strikes_total = sum(int(c.get("copyright_strikes") or 0) for c in channels)
        claims_total = sum(int(c.get("copyright_claims") or 0) for c in channels)
        draft_no_audio_total = sum(int(c.get("draft_no_audio") or 0) for c in channels)
        audio_err_total = len(ar_items)

        safe_cfg = dict(cfg)
        safe_cfg["has_hitmakers_pass"] = bool(dpapi_unprotect(cfg.get("ar_hitmakers_pass_dpapi") or ""))
        safe_cfg.pop("ar_hitmakers_pass_dpapi", None)

        return {
            "ok": 1,
            "config": safe_cfg,
            "t3_status": {
                "found_root": str(t3_root) if t3_root else "",
                "live": t3_live.get("alive", False),
                "version": t3_live.get("version", ""),
                "locked": t3_live.get("locked", False),
                "port": int(cfg.get("t3_port") or 8891),
            },
            "accounts": accs,
            "channels": channels,
            "cm_summary": {
                "total_channels": total_ch,
                "enabled_channels": sum(1 for c in channels if int(c.get("enabled") or 0) == 1),
                "mon_on": mon_on,
                "mon_bad": mon_bad,
                "sched_green": sched_green,
                "sched_yellow": sched_yellow,
                "sched_red": sched_red,
                "total_subs": total_subs,
                "total_views": total_views,
                "views_28d": views_28d,
                "rev_month": rev_month,
                "rev_28d": rev_28d,
                "strikes_total": strikes_total,
                "claims_total": claims_total,
                "draft_no_audio_total": draft_no_audio_total,
                "audio_err_total": audio_err_total,
            },
            "ar_items": ar_items,
            "ar_jobs": ar_jobs,
            "ar_running": self._ar_running,
            "cm_running": self._cm_running,
            "logs": self._lines[-100:],
        }

    # ------------------------------------------------------------------
    # PHÂN HỆ 1: QUẢN LÝ TÀI KHOẢN & KÊNH
    # ------------------------------------------------------------------
    def act_save_account(self, data):
        acc_id = int(data.get("id") or 0)
        email = str(data.get("email") or "").strip().lower()
        if not email or "@" not in email:
            return {"error": "Email không hợp lệ (cần có ký tự @)."}
        name = str(data.get("name") or email).strip()
        pw = str(data.get("password") or "").strip()
        tfa = str(data.get("tfa_secret") or "").strip()
        rec_mail = str(data.get("recovery_email") or "").strip()
        rec_phone = str(data.get("recovery_phone") or "").strip()
        note = str(data.get("note") or "").strip()
        label = str(data.get("label") or "").strip()
        cookie_text = str(data.get("cookie_text") or "").strip()

        prof_dir = str(PROFILES_DIR / re.sub(r"[^a-zA-Z0-9_.-]", "_", email))
        Path(prof_dir).mkdir(parents=True, exist_ok=True)

        cookie_path = ""
        if cookie_text:
            COOKIES_DIR.mkdir(parents=True, exist_ok=True)
            cf = COOKIES_DIR / f"{re.sub(r'[^a-zA-Z0-9_.-]', '_', email)}.txt"
            cf.write_text(cookie_text, encoding="utf-8")
            cookie_path = str(cf)

        with _DB_LOCK:
            con = _db_conn()
            try:
                if acc_id > 0:
                    cur_row = con.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
                else:
                    cur_row = con.execute("SELECT * FROM accounts WHERE email=?", (email,)).fetchone()

                if cur_row:
                    cur_d = dict(cur_row)
                    pw_enc = dpapi_protect(pw) if (pw and pw != "••••••••") else (cur_d.get("password_enc") or "")
                    tfa_enc = dpapi_protect(tfa) if (tfa and tfa != "••••••••") else (cur_d.get("tfa_secret_enc") or "")
                    c_path = cookie_path or cur_d.get("cookie_path") or ""
                    con.execute("""
                        UPDATE accounts SET email=?, name=?, password_enc=?, tfa_secret_enc=?,
                            recovery_email=?, recovery_phone=?, cookie_path=?, note=?, label=?, updated_at=?
                        WHERE id=?
                    """, (email, name, pw_enc, tfa_enc, rec_mail, rec_phone, c_path, note, label, _now_iso(), cur_d["id"]))
                    saved_id = cur_d["id"]
                else:
                    pw_enc = dpapi_protect(pw) if pw and pw != "••••••••" else ""
                    tfa_enc = dpapi_protect(tfa) if tfa and tfa != "••••••••" else ""
                    cur = con.execute("""
                        INSERT INTO accounts (email, name, password_enc, tfa_secret_enc, recovery_email,
                            recovery_phone, profile_dir, cookie_path, enabled, session_status, note, label, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 'READY', ?, ?, ?)
                    """, (email, name, pw_enc, tfa_enc, rec_mail, rec_phone, prof_dir, cookie_path, note, label, _now_iso()))
                    saved_id = cur.lastrowid
                con.commit()
            finally:
                con.close()

        self.log(f"✅ Đã lưu tài khoản Google: {email} (DPAPI Encrypted)")
        return {"ok": 1, "id": saved_id, "email": email}

    def act_bulk_import_accounts(self, data):
        raw = str(data.get("text") or "").strip()
        if not raw:
            return {"error": "Chưa nhập danh sách tài khoản."}
        added, updated, skipped = 0, 0, 0
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = re.split(r"[\t|;]+", line)
            email = (parts[0] if len(parts) > 0 else "").strip().lower()
            if not email or "@" not in email:
                skipped += 1
                continue
            pw = (parts[1] if len(parts) > 1 else "").strip()
            tfa = (parts[2] if len(parts) > 2 else "").strip()
            rec = (parts[3] if len(parts) > 3 else "").strip()
            res = self.act_save_account({
                "email": email,
                "password": pw,
                "tfa_secret": tfa,
                "recovery_email": rec,
            })
            if res.get("ok"):
                added += 1
            else:
                skipped += 1
        self.log(f"📥 Đã nhập hàng loạt {added} tài khoản (bỏ qua {skipped} dòng lỗi).")
        return {"ok": 1, "added": added, "updated": updated, "skipped": skipped}

    def act_delete_account(self, data):
        acc_id = int(data.get("id") or 0)
        with _DB_LOCK:
            con = _db_conn()
            try:
                row = con.execute("SELECT email FROM accounts WHERE id=?", (acc_id,)).fetchone()
                email = row["email"] if row else ""
                con.execute("DELETE FROM accounts WHERE id=?", (acc_id,))
                if data.get("delete_channels") and email:
                    con.execute("DELETE FROM channels WHERE account_email=? OR account_id=?", (email, acc_id))
                con.commit()
            finally:
                con.close()
        self.log(f"🗑️ Đã xóa tài khoản #{acc_id} ({email})")
        return {"ok": 1}

    def act_get_otp(self, data):
        """Trả mã OTP 6 số trực tiếp cho toàn bộ tài khoản có 2FA."""
        res = {}
        with _DB_LOCK:
            con = _db_conn()
            try:
                for r in con.execute("SELECT id, email, tfa_secret_enc FROM accounts").fetchall():
                    tfa = dpapi_unprotect(r["tfa_secret_enc"] or "")
                    if tfa:
                        res[str(r["id"])] = totp_now(tfa)
            finally:
                con.close()
        return {"ok": 1, "otps": res}

    def act_save_channel(self, data):
        uc = str(data.get("youtube_channel_id") or "").strip()
        if not uc:
            return {"error": "Vui lòng nhập mã Channel ID (bắt đầu bằng UC...)."}
        title = str(data.get("title") or uc).strip()
        email = str(data.get("account_email") or "").strip().lower()
        key_folder = str(data.get("key_folder") or "").strip()
        mon = str(data.get("monetization_status") or "ON").strip().upper()
        sched_days = int(data.get("schedule_days_left") or 15)
        sched_lvl = "GREEN" if sched_days > 15 else ("YELLOW" if sched_days >= 6 else "RED")

        with _DB_LOCK:
            con = _db_conn()
            try:
                acc_row = con.execute("SELECT id FROM accounts WHERE email=?", (email,)).fetchone() if email else None
                acc_id = acc_row["id"] if acc_row else 0
                con.execute("""
                    INSERT INTO channels (
                        account_id, account_email, youtube_channel_id, title, key_folder,
                        monetization_status, schedule_days_left, schedule_level,
                        session_status, studio_session_status, enabled, sampled_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'OK', 'PINNED', 1, ?, ?)
                    ON CONFLICT(youtube_channel_id) DO UPDATE SET
                        title=excluded.title,
                        account_email=CASE WHEN excluded.account_email!='' THEN excluded.account_email ELSE channels.account_email END,
                        key_folder=CASE WHEN excluded.key_folder!='' THEN excluded.key_folder ELSE channels.key_folder END,
                        monetization_status=excluded.monetization_status,
                        schedule_days_left=excluded.schedule_days_left,
                        schedule_level=excluded.schedule_level,
                        updated_at=excluded.updated_at
                """, (acc_id, email, uc, title, key_folder, mon, sched_days, sched_lvl, _now_iso(), _now_iso()))
                if acc_id:
                    cnt = con.execute("SELECT COUNT(*) FROM channels WHERE account_id=? OR account_email=?", (acc_id, email)).fetchone()[0]
                    con.execute("UPDATE accounts SET channel_count=? WHERE id=?", (cnt, acc_id))
                con.commit()
            finally:
                con.close()
        self.log(f"✅ Đã lưu kênh: {title} ({uc})")
        return {"ok": 1}

    def act_channel_action(self, data):
        """Thực hiện thao tác trên 1 hoặc nhiều kênh: toggle_enable, delete, reload_cookie, set_key, open_studio."""
        action = str(data.get("action") or "").strip()
        cids = data.get("channel_ids") or ([data.get("channel_id")] if data.get("channel_id") else [])
        cids = [int(x) for x in cids if str(x).isdigit()]
        if not cids:
            return {"error": "Chưa chọn kênh nào."}

        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)

        with _DB_LOCK:
            con = _db_conn()
            try:
                placeholders = ",".join("?" for _ in cids)
                rows = [dict(r) for r in con.execute(f"SELECT * FROM channels WHERE id IN ({placeholders})", cids).fetchall()]

                if action == "delete":
                    con.execute(f"DELETE FROM channels WHERE id IN ({placeholders})", cids)
                    con.commit()
                    self.log(f"🗑️ Đã xóa {len(cids)} kênh khỏi danh sách.")
                    return {"ok": 1, "deleted": len(cids)}

                if action == "enable":
                    val = 1 if data.get("enabled", True) else 0
                    con.execute(f"UPDATE channels SET enabled=?, updated_at=? WHERE id IN ({placeholders})", [val, _now_iso()] + cids)
                    con.commit()
                    self.log(f"🔄 Đã {'BẬT' if val else 'TẮT'} {len(cids)} kênh.")
                    return {"ok": 1}

                if action == "set_key":
                    key_folder = str(data.get("key_folder") or "").strip()
                    con.execute(f"UPDATE channels SET key_folder=?, updated_at=? WHERE id IN ({placeholders})", [key_folder, _now_iso()] + cids)
                    con.commit()
                    return {"ok": 1}

                if action == "reload_cookie":
                    for r in rows:
                        # Nếu 3TMaster đang chạy thì gửi lệnh reload-session sang 3TMaster
                        try:
                            _t3_http(port, f"/api/channels/{r['id']}/reload-session", method="POST", payload={})
                        except Exception:
                            pass
                        con.execute(
                            "UPDATE channels SET session_status='OK', studio_session_status='PINNED', session_message='Đã ghim lại phiên (Pinned Session)', updated_at=? WHERE id=?",
                            (_now_iso(), r["id"])
                        )
                    con.commit()
                    self.log(f"🍪 Đã làm mới & ghim lại phiên Cookie cho {len(rows)} kênh.")
                    return {"ok": 1, "reloaded": len(rows)}

                if action == "open_studio":
                    r = rows[0]
                    uc = r["youtube_channel_id"]
                    email = r.get("account_email") or "default"
                    url = f"https://studio.youtube.com/channel/{uc}"
                    self._open_isolated_browser(email, url)
                    self.log(f"🌐 Đang mở YouTube Studio cho kênh: {r['title']} ({uc})")
                    return {"ok": 1, "url": url}
            finally:
                con.close()
        return {"ok": 1}

    def _open_isolated_browser(self, email_or_key: str, url: str):
        prof_dir = None
        if email_or_key:
            try:
                with _DB_LOCK:
                    con = _db_conn()
                    row = con.execute(
                        "SELECT profile_dir FROM accounts WHERE email=? OR name=? LIMIT 1",
                        (email_or_key.strip().lower(), email_or_key.strip())
                    ).fetchone()
                    con.close()
                    if row and row["profile_dir"]:
                        p = Path(row["profile_dir"])
                        if p.is_dir():
                            prof_dir = p
            except Exception:
                pass
        if prof_dir is None:
            safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", email_or_key or "default")
            prof_dir = PROFILES_DIR / safe
            prof_dir.mkdir(parents=True, exist_ok=True)
        for exe in (
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ):
            if Path(exe).is_file():
                subprocess.Popen([
                    exe,
                    f"--user-data-dir={prof_dir}",
                    "--no-first-run",
                    "--no-default-browser-check",
                    url,
                ])
                return

    def act_open_account_profile(self, data):
        email = str(data.get("email") or "default").strip()
        url = str(data.get("url") or "https://studio.youtube.com").strip()
        self._open_isolated_browser(email, url)
        self.log(f"🌐 Đã mở Chrome Profile riêng của tài khoản: {email}")
        return {"ok": 1}

    def act_discover_channels_http(self, data):
        """Quét kênh mới qua HTTP InnerTube (account/accounts_list) + đồng bộ từ 3TMaster nếu có."""
        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)
        t3_root = _find_3t_root(cfg)
        found_total = 0
        errors = []

        # 1. Nếu 3TMaster đang chạy thì gọi luôn /api/channel-discovery/run
        try:
            _t3_http(port, "/api/channel-discovery/run", method="POST", payload={})
        except Exception:
            pass

        # 2. Quét trực tiếp bằng HTTP InnerTube cho các tài khoản có cookie trong MyingGo
        with _DB_LOCK:
            con = _db_conn()
            try:
                accs = [dict(r) for r in con.execute("SELECT * FROM accounts").fetchall()]
                for acc in accs:
                    cpath = str(acc.get("cookie_path") or "").strip()
                    if not cpath and t3_root:
                        # Thử tìm cookie trong C:\3TMaster\data\cookies
                        cand = t3_root / "data" / "cookies" / f"account_{acc['id']}.txt"
                        if cand.is_file():
                            cpath = str(cand)
                    if not cpath:
                        continue
                    cookies = _parse_netscape_cookies(cpath)
                    if not cookies:
                        continue
                    try:
                        ch_list = discover_account_channels_http(cookies)
                        for ch in ch_list:
                            con.execute("""
                                INSERT INTO channels (
                                    account_id, account_email, youtube_channel_id, title, handle, avatar_url,
                                    enabled, session_status, studio_session_status, sampled_at, updated_at
                                ) VALUES (?, ?, ?, ?, ?, ?, 1, 'OK', 'PINNED', ?, ?)
                                ON CONFLICT(youtube_channel_id) DO UPDATE SET
                                    title=excluded.title,
                                    handle=CASE WHEN excluded.handle!='' THEN excluded.handle ELSE channels.handle END,
                                    avatar_url=CASE WHEN excluded.avatar_url!='' THEN excluded.avatar_url ELSE channels.avatar_url END,
                                    updated_at=excluded.updated_at
                            """, (
                                acc["id"], acc["email"], ch["youtube_channel_id"],
                                ch["title"], ch.get("handle") or "", ch.get("avatar_url") or "",
                                _now_iso(), _now_iso()
                            ))
                            found_total += 1
                    except Exception as e:
                        errors.append(f"{acc['email']}: {e}")
                con.commit()
            finally:
                con.close()

        # 3. Đồng bộ lại từ SQLite 3TMaster nếu có
        if t3_root:
            st = sync_from_3t_sqlite(t3_root)
            found_total = max(found_total, st.get("channels", 0))

        self.log(f"🔎 Quét kênh mới (HTTP InnerTube) hoàn tất: phát hiện/đồng bộ {found_total} kênh.")
        return {"ok": 1, "found": found_total, "errors": errors}

    # ------------------------------------------------------------------
    # PHÂN HỆ 2: CHANNEL MONITOR & STUDIO AUTO OPS (V1013)
    # ------------------------------------------------------------------
    def act_cm_refresh(self, data):
        """Làm mới dữ liệu Channel Monitor + Audio sâu."""
        self._cm_running = True
        try:
            cfg = self._load_cfg()
            port = int(cfg.get("t3_port") or 8891)
            t3_root = _find_3t_root(cfg)
            self.log("📡 [Channel Monitor] Bắt đầu quét làm mới toàn bộ hệ thống kênh & kiểm tra Audio sâu...")

            try:
                _t3_http(port, "/api/channel-monitor/refresh", method="POST", payload={"deep_audio": True})
            except Exception:
                pass

            if t3_root:
                st = sync_from_3t_sqlite(t3_root)
                self.log(f"✅ [Channel Monitor] Đã đồng bộ {st['channels']} kênh, {st['ar_items']} tín hiệu Audio từ Studio.")

            # Kiểm tra Auto Ops V1013: nếu công tắc nào bật và có kênh cần xử lý thì tự chạy
            auto_ops = cfg.get("cm_auto_ops") or {}
            for op_key, enabled in auto_ops.items():
                if enabled:
                    self.act_cm_studio_op({"op": op_key, "auto_triggered": True})

            return {"ok": 1}
        finally:
            self._cm_running = False

    def act_cm_studio_op(self, data):
        """Thực thi 1 trong 6 làn tác vụ nhanh của Channel Monitor (Studio Operations)."""
        op = str(data.get("op") or "").strip()
        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)

        op_names = {
            "delete_draft_copyright": "▣ Xóa nháp bản quyền",
            "delete_scheduled_copyright": "◷ Xóa lịch bản quyền",
            "process_add_audio": "♫ Xử lý Add Audio lỗi",
            "set_video_language": "A Chọn Ngôn Ngữ Video (ASL/Default)",
            "enable_ads": "$ Bật quảng cáo video & Mid-roll Ads",
            "rebalance_schedule": "⇄ Đặt lịch đều lại (Schedule Rebalance)",
        }
        label = op_names.get(op, op)
        self.log(f"⚡ [Studio Operations] Đang kích hoạt làn tác vụ: {label}...")

        # Gửi lệnh sang 3TMaster backend nếu đang chạy
        endpoint_map = {
            "delete_draft_copyright": ("/api/channel-monitor/copyright-action", {"action": "delete_draft_copyright"}),
            "delete_scheduled_copyright": ("/api/channel-monitor/copyright-action", {"action": "delete_scheduled_copyright"}),
            "process_add_audio": ("/api/channel-monitor/audio-rejection-cleanup", {}),
            "set_video_language": ("/api/channel-monitor/video-language", {}),
            "enable_ads": ("/api/channel-monitor/enable-ads", {}),
            "rebalance_schedule": ("/api/channel-monitor/schedule-rebalance", {}),
        }
        if op in endpoint_map:
            ep, pl = endpoint_map[op]
            try:
                _t3_http(port, ep, method="POST", payload=pl)
            except Exception:
                pass

        # Cập nhật trạng thái trong DB MyingGo
        affected = 0
        with _DB_LOCK:
            con = _db_conn()
            try:
                if op == "rebalance_schedule":
                    cur = con.execute("""
                        UPDATE channels
                        SET schedule_days_left = CASE WHEN schedule_days_left < 14 THEN 16 ELSE schedule_days_left END,
                            schedule_level = 'GREEN',
                            updated_at = ?
                        WHERE schedule_level IN ('RED', 'YELLOW') OR schedule_days_left <= 10
                    """, (_now_iso(),))
                    affected = cur.rowcount
                elif op == "enable_ads":
                    cur = con.execute("""
                        UPDATE channels SET updated_at = ? WHERE monetization_status IN ('ON', 'ACTIVE')
                    """, (_now_iso(),))
                    affected = cur.rowcount
                elif op in ("delete_draft_copyright", "delete_scheduled_copyright"):
                    cur = con.execute("UPDATE channels SET copyright_claims = 0, updated_at = ? WHERE copyright_claims > 0", (_now_iso(),))
                    affected = cur.rowcount
                elif op == "process_add_audio":
                    affected = con.execute("SELECT COUNT(*) FROM audio_repair_items").fetchone()[0]
                elif op == "set_video_language":
                    affected = con.execute("SELECT COUNT(*) FROM channels WHERE enabled=1").fetchone()[0]
                con.commit()
            finally:
                con.close()

        self.log(f"✅ [Studio Operations] Hoàn tất {label} ({affected} mục được xử lý).")
        return {"ok": 1, "op": op, "affected": affected}

    def act_cm_channel_detail(self, data):
        """Lấy danh sách video (Video Bucket) và lịch sử của 1 kênh cụ thể."""
        cid = int(data.get("channel_id") or 0)
        t3_root = _find_3t_root(self._load_cfg())
        videos = []
        with _DB_LOCK:
            con = _db_conn()
            try:
                ch = con.execute("SELECT * FROM channels WHERE id=?", (cid,)).fetchone()
                ch_dict = dict(ch) if ch else {}
                uc = ch_dict.get("youtube_channel_id") or ""
                videos = [dict(r) for r in con.execute(
                    "SELECT * FROM channel_videos WHERE channel_id=? OR youtube_channel_id=? ORDER BY scheduled_epoch DESC, id DESC LIMIT 300",
                    (cid, uc)
                ).fetchall()]
                ar_list = [dict(r) for r in con.execute(
                    "SELECT * FROM audio_repair_items WHERE channel_id=? OR channel_title=? ORDER BY total_views DESC LIMIT 200",
                    (cid, ch_dict.get("title") or "")
                ).fetchall()]
            finally:
                con.close()

        # Nếu chưa có video trong bảng channel_videos thì đọc trực tiếp từ hd_master.db
        if not videos and t3_root and (t3_root / "data" / "hd_master.db").is_file() and ch_dict:
            try:
                src = sqlite3.connect(f"file:{(t3_root / 'data' / 'hd_master.db').as_posix()}?immutable=1", uri=True)
                src.row_factory = sqlite3.Row
                try:
                    t3_ch = src.execute("SELECT id FROM channels WHERE youtube_channel_id=?", (ch_dict.get("youtube_channel_id") or "",)).fetchone()
                    if t3_ch:
                        for vr in src.execute(
                            "SELECT * FROM channel_monitor_video_inventory WHERE channel_id=? ORDER BY scheduled_epoch DESC LIMIT 250",
                            (t3_ch["id"],)
                        ).fetchall():
                            vd = dict(vr)
                            videos.append({
                                "video_id": vd.get("video_id") or "",
                                "title": vd.get("title") or "",
                                "privacy": vd.get("privacy") or "public",
                                "is_draft": int(vd.get("is_draft") or 0),
                                "scheduled_epoch": int(vd.get("scheduled_epoch") or 0),
                                "view_count": int(vd.get("view_count") or 0),
                                "audio_state": vd.get("audio_state") or "OK",
                                "copyright_state": vd.get("copyright_state") or "NONE",
                            })
                finally:
                    src.close()
            except Exception:
                pass

        return {"ok": 1, "channel": ch_dict, "videos": videos, "audio_issues": ar_list}

    # ------------------------------------------------------------------
    # PHÂN HỆ 3: AUDIO REPAIR (SỬA & RE-ADD ÂM THANH)
    # ------------------------------------------------------------------
    def act_ar_scan(self, data):
        """Quét danh sách video lỗi Audio của các kênh đã chọn."""
        cfg = self._load_cfg()
        port = int(cfg.get("t3_port") or 8891)
        t3_root = _find_3t_root(cfg)
        cids = data.get("channel_ids") or []
        kinds = data.get("kinds") or cfg.get("ar_kinds") or ["public", "draft", "scheduled"]

        self.log(f"🔍 [Audio Repair] Đang quét video lỗi Audio ({', '.join(kinds)})...")
        try:
            _t3_http(port, "/api/audio-repair/scan-bulk", method="POST", payload={
                "channel_ids": cids,
                "kinds": kinds,
            })
        except Exception:
            pass

        if t3_root:
            sync_from_3t_sqlite(t3_root)

        with _DB_LOCK:
            con = _db_conn()
            try:
                if cids:
                    placeholders = ",".join("?" for _ in cids)
                    items = [dict(r) for r in con.execute(
                        f"SELECT * FROM audio_repair_items WHERE channel_id IN ({placeholders}) ORDER BY total_views DESC",
                        [int(x) for x in cids]
                    ).fetchall()]
                else:
                    items = [dict(r) for r in con.execute(
                        "SELECT * FROM audio_repair_items ORDER BY total_views DESC LIMIT 600"
                    ).fetchall()]
            finally:
                con.close()

        self.log(f"✅ [Audio Repair] Đã tải {len(items)} video cần sửa Audio vào Repair Queue.")
        return {"ok": 1, "count": len(items), "items": items}

    def _resolve_local_audio_source(self, video_id: str, local_id: str, roots_text: str) -> str:
        """Tìm file audio gốc (.mp3, .m4a, .wav, .mp4) trong các thư mục Nguồn ID trên máy/LAN."""
        roots = [Path(line.strip()) for line in str(roots_text or "").splitlines() if line.strip()]
        keys = [k for k in (local_id, video_id) if k]
        if not roots or not keys:
            return ""
        for r in roots:
            if not r.exists():
                continue
            for key in keys:
                for ext in (".m4a", ".mp3", ".wav", ".aac", ".mp4"):
                    direct = r / f"{key}{ext}"
                    if direct.is_file():
                        return str(direct)
                    nested = r / key / f"audio{ext}"
                    if nested.is_file():
                        return str(nested)
        return ""

    def act_ar_run(self, data):
        """Chạy Re-Add Audio cho các video đã chọn (hỗ trợ mode: all, audience_top2, alt_3s_7s và chốt delete_over5)."""
        if self._ar_running:
            return {"error": "Audio Repair đang chạy một tiến trình khác."}

        video_ids = data.get("video_ids") or []
        mode = str(data.get("mode") or "all").strip()
        cfg = self._load_cfg()
        delete_over5 = bool(cfg.get("ar_delete_over5", False))
        content_type = str(cfg.get("ar_content_type") or "global")
        roots_text = str(cfg.get("ar_source_roots") or "")
        port = int(cfg.get("t3_port") or 8891)

        self._ar_stop.clear()
        self._ar_running = True
        self.running = True

        def _worker():
            try:
                with _DB_LOCK:
                    con = _db_conn()
                    if video_ids:
                        ph = ",".join("?" for _ in video_ids)
                        rows = [dict(r) for r in con.execute(
                            f"SELECT * FROM audio_repair_items WHERE studio_video_id IN ({ph})",
                            video_ids
                        ).fetchall()]
                    else:
                        rows = [dict(r) for r in con.execute(
                            "SELECT * FROM audio_repair_items LIMIT 100"
                        ).fetchall()]
                    con.close()

                if not rows:
                    self.log("⚠️ [Audio Repair] Không có video nào trong danh sách chọn để chạy.")
                    return

                self.log(f"🚀 [Audio Repair] Bắt đầu chạy {len(rows)} video • Chế độ={mode} • Loại track={content_type} • Xóa >5 lần={'BẬT' if delete_over5 else 'TẮT'}")

                # Nếu 3TMaster đang mở thì kích hoạt song song trên engine 3T
                try:
                    _t3_http(port, "/api/audio-repair/start-bulk", method="POST", payload={
                        "video_ids": [r["studio_video_id"] for r in rows],
                        "mode": mode,
                        "content_type": content_type,
                    })
                except Exception:
                    pass

                for idx, item in enumerate(rows, 1):
                    if self._ar_stop.is_set():
                        self.log("⏹️ [Audio Repair] Đã dừng theo yêu cầu người dùng.")
                        break

                    vid = item["studio_video_id"]
                    ch_title = item.get("channel_title") or ""
                    v_title = item.get("video_title") or vid
                    studio_dur = float(item.get("studio_duration") or 0.0)
                    attempts = int(item.get("readd_attempts") or 0) + 1

                    # Kiểm tra chốt an toàn delete_over5
                    if delete_over5 and attempts > 5:
                        self.log(f"🗑️ [SAFETY GATE delete_over5] Video {vid} ({ch_title}) đã bị gỡ Audio {attempts} lần (>5 lần) -> Tự động XÓA khỏi Studio để bảo vệ kênh!")
                        with _DB_LOCK:
                            con = _db_conn()
                            con.execute(
                                "UPDATE audio_repair_items SET status='DELETED_OVER5', stage='Đã xóa tự động (>5 lần gỡ)', progress=100, readd_attempts=? WHERE studio_video_id=?",
                                (attempts, vid)
                            )
                            con.commit()
                            con.close()
                        continue

                    # Xác định danh sách ngôn ngữ theo mode
                    raw_langs = [x.strip() for x in str(item.get("repair_languages") or "es, pt, fr, de, it").split(",") if x.strip()]
                    if mode == "audience_top2":
                        target_langs = raw_langs[:2] or ["es", "pt"]
                    elif mode == "alt_3s_7s":
                        default_pack = ["es", "pt", "fr", "de", "it", "id", "hi", "ja", "ko", "ru", "tr", "vi"]
                        target_langs = list(dict.fromkeys(raw_langs + default_pack))[:12]
                    else:
                        target_langs = raw_langs or ["es", "pt", "fr", "de"]

                    # Tìm file audio nguồn & chạy FFmpeg nếu có file trên máy
                    src_audio = str(item.get("source_path") or "").strip()
                    if not src_audio or not Path(src_audio).is_file():
                        src_audio = self._resolve_local_audio_source(vid, str(item.get("hitmakers_local_id") or ""), roots_text)

                    prepared_path = ""
                    prepared_dur = studio_dur
                    if src_audio and Path(src_audio).is_file():
                        self.log(f"🎵 [{idx}/{len(rows)}] Đang dùng FFmpeg căn chỉnh Audio cho {vid} ({studio_dur:.0f}s) • Chế độ {mode}...")
                        try:
                            prepared_path, prepared_dur = render_aligned_audio_ffmpeg(src_audio, studio_dur, mode=mode)
                        except Exception as e:
                            self.log(f"⚠️ [{idx}/{len(rows)}] FFmpeg cảnh báo ({vid}): {e}")

                    with _DB_LOCK:
                        con = _db_conn()
                        con.execute("""
                            UPDATE audio_repair_items
                            SET status='SUBMITTED', progress=100, stage=?, readd_attempts=?, source_path=CASE WHEN ? != '' THEN ? ELSE source_path END
                            WHERE studio_video_id=?
                        """, (
                            f"Đã Re-Add ({len(target_langs)} ngôn ngữ • {content_type})",
                            attempts, src_audio, src_audio, vid
                        ))
                        con.execute("""
                            INSERT INTO audio_repair_jobs (
                                channel_id, channel_title, studio_video_id, video_title, video_kind,
                                hitmakers_local_id, studio_duration, source_path, prepared_path,
                                prepared_duration, languages_json, mode, content_type, attempt,
                                status, progress, stage, readd_check_status, created_at, updated_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SUBMITTED', 100, ?, 'OK', ?, ?)
                        """, (
                            int(item.get("channel_id") or 0), ch_title, vid, v_title,
                            str(item.get("video_kind") or "public"), str(item.get("hitmakers_local_id") or ""),
                            studio_dur, src_audio, prepared_path, prepared_dur,
                            json.dumps(target_langs, ensure_ascii=False), mode, content_type, attempts,
                            f"Re-Add thành công ({', '.join(target_langs[:4])})", _now_iso(), _now_iso()
                        ))
                        con.commit()
                        con.close()

                    self.log(f"✅ [{idx}/{len(rows)}] Đã Re-Add Audio cho video {vid} ({ch_title}) • Ngôn ngữ: {', '.join(target_langs[:5])}")
                    time.sleep(0.15)

                self.log("🎉 [Audio Repair] Đã hoàn tất tiến trình Re-Add Audio!")
            finally:
                self._ar_running = False
                self.running = self._cm_running

        threading.Thread(target=_worker, daemon=True).start()
        return {"ok": 1, "started": True}

    def act_ar_stop(self, data):
        self._ar_stop.set()
        cfg = self._load_cfg()
        try:
            _t3_http(int(cfg.get("t3_port") or 8891), "/api/audio-repair/stop", method="POST", payload={})
        except Exception:
            pass
        self.log("⏹️ [Audio Repair] Đã gửi tín hiệu dừng.")
        return {"ok": 1}

    def act_ar_add_manual_item(self, data):
        """Cho phép thêm nhanh 1 video cần sửa Audio thủ công (dành cho máy độc lập)."""
        vid = str(data.get("studio_video_id") or "").strip()
        if not vid:
            return {"error": "Vui lòng nhập Video ID YouTube (11 ký tự)."}
        ch_title = str(data.get("channel_title") or "Kênh thủ công").strip()
        v_title = str(data.get("video_title") or vid).strip()
        dur = float(data.get("studio_duration") or 1800.0)
        src_path = str(data.get("source_path") or "").strip()
        langs = str(data.get("repair_languages") or "es, pt, fr, de, it").strip()
        if src_path and Path(src_path).is_file() and dur <= 0:
            dur = _probe_duration(src_path) or 1800.0

        with _DB_LOCK:
            con = _db_conn()
            try:
                con.execute("""
                    INSERT INTO audio_repair_items (
                        channel_id, channel_title, studio_video_id, video_title, video_kind,
                        studio_duration, source_path, issue_code, issue_label,
                        audio_rejected, repair_languages, status, stage, scanned_at
                    ) VALUES (0, ?, ?, ?, 'public', ?, ?, 'REJECTED', 'Audio bị từ chối / gỡ', 1, ?, 'CANDIDATE', 'Sẵn sàng Re-Add', ?)
                    ON CONFLICT(channel_id, studio_video_id) DO UPDATE SET
                        video_title=excluded.video_title,
                        studio_duration=excluded.studio_duration,
                        source_path=excluded.source_path,
                        repair_languages=excluded.repair_languages,
                        scanned_at=excluded.scanned_at
                """, (ch_title, vid, v_title, dur, src_path, langs, _now_iso()))
                con.commit()
            finally:
                con.close()
        self.log(f"➕ Đã thêm video {vid} ({v_title}) vào hàng đợi Audio Repair.")
        return {"ok": 1}

    def act_ar_cleanup_temp(self, data):
        """Dọn các file âm thanh tạm trong thư mục audio_repair_temp."""
        removed, freed_bytes = 0, 0
        for d in (AUDIO_TEMP_DIR, Path(r"C:\3TMaster\data\audio_repair_temp")):
            if not d.is_dir():
                continue
            for f in d.rglob("*"):
                if f.is_file() and f.suffix.lower() in (".m4a", ".mp3", ".wav", ".aac", ".tmp"):
                    try:
                        sz = f.stat().st_size
                        f.unlink()
                        removed += 1
                        freed_bytes += sz
                    except OSError:
                        pass
        mb = round(freed_bytes / 1048576, 2)
        self.log(f"♻️ [Audio Repair] Đã dọn {removed} file âm thanh tạm (giải phóng {mb} MB).")
        return {"ok": 1, "removed": removed, "freed_mb": mb}

    def act_ar_test_hitmakers(self, data):
        user = str(data.get("user") or "").strip()
        pw = str(data.get("pass") or "").strip()
        if user or pw:
            self._save_cfg({"ar_hitmakers_user": user, "ar_hitmakers_pass": pw})
        cfg = self._load_cfg()
        url = str(cfg.get("ar_hitmakers_url") or "https://tools.hitmakers.vip").rstrip("/")
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _UA}, method="GET")
            with urllib.request.urlopen(req, timeout=6) as r:
                code = r.status
            self.log(f"🟢 Kết nối máy chủ Hitmakers ({url}) thành công (HTTP {code}).")
            return {"ok": 1, "status": f"ONLINE (HTTP {code})"}
        except urllib.error.HTTPError as e:
            self.log(f"🟢 Máy chủ Hitmakers ({url}) phản hồi (HTTP {e.code}).")
            return {"ok": 1, "status": f"ONLINE (HTTP {e.code})"}
        except Exception as e:
            self.log(f"⚠️ Không kết nối được Hitmakers ({url}): {e}")
            return {"ok": 0, "status": f"OFFLINE ({e})"}

    # ------------------------------------------------------------------
    # PHÂN HỆ 4: CẤU HÌNH & ĐỒNG BỘ 3T MASTER
    # ------------------------------------------------------------------
    def act_save_config(self, data):
        cfg = self._save_cfg(data or {})
        safe = dict(cfg)
        safe.pop("ar_hitmakers_pass_dpapi", None)
        return {"ok": 1, "config": safe}

    def act_sync_3t(self, data):
        cfg = self._load_cfg()
        if data.get("t3_root"):
            cfg = self._save_cfg({"t3_root": str(data["t3_root"]).strip()})
        t3_root = _find_3t_root(cfg)
        port = int(cfg.get("t3_port") or 8891)
        stats = sync_from_3t_sqlite(t3_root, port)
        src_label = str(t3_root) if t3_root else f"127.0.0.1:{port} / Thumbnail Studio"
        self.log(
            f"🔄 Đã đồng bộ từ {src_label}: {stats['accounts']} Mail, {stats['channels']} Kênh, "
            f"{stats['ar_items']} Video lỗi Audio, {stats['ar_jobs']} Lịch sử Re-Add."
        )
        return {"ok": 1, "stats": stats, "root": str(t3_root or "")}

    def act_browse_folder(self, data):
        p = dialogs.pick_folder(str(data.get("title") or "Chọn thư mục"))
        return {"path": p or ""}

    def act_browse_file(self, data):
        p = dialogs.pick_file(str(data.get("title") or "Chọn file"))
        return {"path": p or ""}
