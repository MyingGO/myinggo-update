"""Tính năng: Tải lên Google Drive siêu tốc (Rclone đa luồng).

Hỗ trợ:
- Tự động tải rclone.exe về thư mục bin/ nếu máy phụ chưa có.
- Tự động đồng bộ tài khoản Google Drive đã đăng nhập giữa máy chính và máy phụ.
- Đa luồng Gigabit: 16, 24, 32, 48, 64 luồng song song (tối ưu kịch trần cho mạng 900M - 1Gbps).
- Tải từng file lẻ nguyên bản (không nén ZIP), auto-resume, bỏ qua file cũ.
- Quét danh sách toàn bộ thư mục & checkbox loại trừ.
"""
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
import urllib.error
import urllib.request
import webbrowser
import zipfile
from pathlib import Path

from core import dialogs, logger
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
BIN_RCLONE = ROOT / "bin" / "rclone.exe"
DATA_DIR = ROOT / "data"
CONFIG_FILE = DATA_DIR / "rclone.conf"
HISTORY_FILE = DATA_DIR / "drive_uploaded_history.json"

# Cấu hình tài khoản Google Drive mặc định (được chia sẻ tự động sang máy phụ)
DEFAULT_RCLONE_CONF = """[gdrive]
type = drive
scope = drive
token = {"access_token":"ya29.a0AehfTOkQGay8lmS0sN2MG3-ktM9VokV78lih2zNNYvb2ErUiL8AihOpdEzqi5kt5S16MTjdTDGq1EJlz_nCjQoNlMHf-4wUUbgfikOQCV5iXc8-kyidlaRfjnbY9ARj77oCH9J5joJhB7f42T7Il8ktiyaDtSQuutoAMbdSluPkct8QUvmZ_JZT7CSdqx_GbZ1qeBOMaCgYKASwSARASFQHGX2Mi9xU7bQOBFmg1ixBrw9SYoQ0206","token_type":"Bearer","refresh_token":"1//0ePxnH-qqKrkhCgYIARAAGA4SNwF-L9IrxfGO743JC5hx0pUA15aS69kf2PuLL71Gk21a9i8t2x_wHw-D0sgK_JasN4dpvhlNyxA","expiry":"2026-11-06T17:35:11.1521589+07:00","expires_in":3599}
team_drive = 
"""

RE_STATS_BYTES = re.compile(r"Transferred:\s+([\d.]+\s+[A-Za-z]+)\s+/\s+([\d.]+\s+[A-Za-z]+),\s+([\d.]+)%,\s+([\d.]+\s+[A-Za-z]+/s),\s+ETA\s+(\S+)")
RE_STATS_FILES = re.compile(r"Transferred:\s+(\d+)\s+/\s+(\d+),\s+([\d.]+)%")
RE_CHECKS_FILES = re.compile(r"Checks:\s+(\d+)\s+/\s+(\d+)")
RE_FILE_COPIED = re.compile(r"(?:INFO|NOTICE)\s+:\s+(.+?):\s+Copied\s+\((?:new|replaced existing)\)")


def natural_sort_key(s):
    """Sắp xếp tự nhiên: số nhỏ trước số lớn (01, 02... 09, 10...)."""
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r"(\d+)", s)]


class DriveUploader(Feature):
    title = "☁️ Tải lên Drive"
    order = 13
    dock = "top"

    def __init__(self):
        super().__init__()
        self.proc = None
        self._proc_lock = threading.Lock()
        self._stop_requested = False
        self._ensure_config_exists()
        self.stats = {
            "running": False,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "--",
            "source": "",
            "target": "",
            "transfers": 32,
            "recent_files": [],
            "error": "",
            "finished": False,
            "start_time": 0,
            "is_batch": False,
            "batch_total": 0,
            "batch_done": 0,
            "current_subfolder": "",
            "done_folders": [],
        }

    def _load_done_history(self) -> set:
        if not HISTORY_FILE.is_file():
            return set()
        try:
            data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return set(str(x).strip().lower() for x in data if str(x).strip())
        except Exception:
            pass
        return set()

    def _save_done_history(self, done_set: set):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            HISTORY_FILE.write_text(
                json.dumps(sorted(list(done_set)), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _folder_keys(self, folder_path: str, folder_name: str) -> tuple[str, str]:
        try:
            norm_path = str(Path(folder_path).resolve()).strip().lower()
        except Exception:
            norm_path = str(folder_path).strip().lower()
        norm_name = f"name::{str(folder_name).strip().lower()}"
        return norm_path, norm_name

    def _is_folder_done(self, folder_path: str, folder_name: str, done_set: set | None = None) -> bool:
        if done_set is None:
            done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        return (k_path in done_set) or (k_name in done_set)

    def _mark_folder_done(self, folder_path: str, folder_name: str, is_done: bool = True):
        done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        if is_done:
            done_set.add(k_path)
            done_set.add(k_name)
        else:
            done_set.discard(k_path)
            done_set.discard(k_name)
        self._save_done_history(done_set)

    def _get_rclone_bin(self):
        if BIN_RCLONE.is_file():
            return str(BIN_RCLONE)
        found = shutil.which("rclone")
        return found if found else str(BIN_RCLONE)

    def _ensure_config_exists(self):
        """Đảm bảo file data/rclone.conf luôn có sẵn tài khoản Drive đã đăng nhập."""
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not CONFIG_FILE.is_file() or not CONFIG_FILE.read_text(encoding="utf-8").strip():
            # Nếu máy có %APPDATA%\rclone\rclone.conf thì sao chép
            appdata_conf = Path(os.environ.get("APPDATA", "")) / "rclone" / "rclone.conf"
            if appdata_conf.is_file() and "[gdrive]" in appdata_conf.read_text(encoding="utf-8"):
                try:
                    shutil.copy2(appdata_conf, CONFIG_FILE)
                    return
                except Exception:
                    pass
            # Nếu không có, tự động ghi cấu hình mặc định đã xác thực từ máy chính
            try:
                CONFIG_FILE.write_text(DEFAULT_RCLONE_CONF, encoding="utf-8")
            except Exception:
                pass

    def _get_config_path(self):
        self._ensure_config_exists()
        return str(CONFIG_FILE)

    def _list_remotes(self):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        if not Path(rc).is_file():
            return []
        try:
            p = subprocess.run(
                [rc, "listremotes", "--config", conf],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            remotes = [r.strip().rstrip(":") for r in p.stdout.splitlines() if r.strip()]
            return remotes
        except Exception:
            return []

    def act_status(self, data):
        rc = self._get_rclone_bin()
        installed = Path(rc).is_file()
        conf = self._get_config_path()
        remotes = self._list_remotes()
        connected = "gdrive" in remotes or len(remotes) > 0
        quota_info = None

        if connected:
            primary_remote = "gdrive" if "gdrive" in remotes else remotes[0]
            try:
                p = subprocess.run(
                    [rc, "about", f"{primary_remote}:", "--json", "--config", conf],
                    capture_output=True,
                    text=True,
                    timeout=6,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if p.returncode == 0 and p.stdout.strip():
                    import json
                    quota_info = json.loads(p.stdout)
            except Exception:
                pass

        return {
            "installed": installed,
            "rclone_path": rc,
            "config_path": conf,
            "connected": connected,
            "remotes": remotes,
            "primary_remote": ("gdrive" if "gdrive" in remotes else (remotes[0] if remotes else "gdrive")),
            "quota": quota_info,
            "running": self.running,
            "stats": self.stats,
        }

    def act_download_rclone(self, data):
        """Tự động tải rclone.exe về thư mục bin/ (cho máy phụ khi chưa có)."""
        bin_dir = ROOT / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        target_exe = bin_dir / "rclone.exe"

        url = "https://downloads.rclone.org/rclone-current-windows-amd64.zip"
        try:
            self.log("🌐 Đang kết nối tải rclone.exe từ downloads.rclone.org...")
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MyingGo/1.0"}
            )
            with urllib.request.urlopen(req, timeout=40) as resp:
                data_bytes = resp.read()

            self.log(f"📦 Đã tải gói nén ({len(data_bytes) // 1048576} MB), đang giải nén...")
            with zipfile.ZipFile(io.BytesIO(data_bytes)) as z:
                found = False
                for member in z.namelist():
                    if member.endswith("rclone.exe"):
                        with z.open(member) as src_file, open(target_exe, "wb") as dst_file:
                            shutil.copyfileobj(src_file, dst_file)
                        found = True
                        break
                if not found:
                    return {"error": "Không tìm thấy file rclone.exe trong gói nén."}

            if target_exe.is_file():
                self.log(f"✅ ĐÃ CÀI ĐẶT THÀNH CÔNG: {target_exe}")
                return {"ok": 1, "path": str(target_exe)}
            return {"error": "Lỗi lưu file rclone.exe"}
        except Exception as e:
            return {"error": f"Lỗi tải rclone: {e}"}

    def act_connect(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"

        if not Path(rc).is_file():
            # Tự động tải Rclone luôn nếu chưa có
            res = self.act_download_rclone({})
            if res.get("error"):
                return {"error": f"Chưa có file rclone.exe và tải tự động thất bại: {res['error']}"}
            rc = self._get_rclone_bin()

        bat_file = ROOT / "Ket_Noi_Google_Drive.bat"
        if not bat_file.is_file():
            bat_file = DATA_DIR / "connect_gdrive.bat"
            bat_file.write_text(f"""@echo off
chcp 65001 >nul
title KẾT NỐI GOOGLE DRIVE CHO MYINGGO
"{rc}" config create {remote_name} drive scope=drive config_shared_client_id=true --config "{conf}"
pause
""", encoding="utf-8")

        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        try:
            subprocess.Popen(["cmd.exe", "/c", str(bat_file)], creationflags=flags)
        except Exception as e:
            return {"error": f"Không thể khởi chạy cửa sổ kết nối: {e}"}

        return {"ok": 1, "message": "Đã mở cửa sổ kết nối Google Drive"}

    def act_export_token(self, data):
        conf = self._get_config_path()
        if not Path(conf).is_file():
            return {"error": "Chưa có file cấu hình Drive trên máy này."}
        try:
            text = Path(conf).read_text(encoding="utf-8").strip()
            if not text or "[gdrive]" not in text:
                return {"error": "Chưa có tài khoản Google Drive nào được liên kết trên máy này."}
            return {"ok": 1, "config_text": text}
        except Exception as e:
            return {"error": f"Lỗi đọc file: {e}"}

    def act_import_token(self, data):
        text = str(data.get("config_text") or "").strip()
        if not text or "[gdrive]" not in text:
            return {"error": "Nội dung mã kết nối không hợp lệ (phải chứa thông tin [gdrive])."}
        conf = self._get_config_path()
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            Path(conf).write_text(text + "\n", encoding="utf-8")
            remotes = self._list_remotes()
            if "gdrive" in remotes or len(remotes) > 0:
                return {"ok": 1, "message": "Đã nhập tài khoản Google Drive thành công!"}
            return {"error": "Đã lưu nhưng không nhận diện được remote Drive."}
        except Exception as e:
            return {"error": f"Lỗi ghi file cấu hình: {e}"}

    def act_open_advanced_config(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        subprocess.Popen(["cmd.exe", "/c", f'title Rclone Advanced Config & "{rc}" config --config "{conf}"'], creationflags=flags)
        return {"ok": 1}

    def act_pick_folder(self, data):
        init_dir = str(data.get("initial") or "")
        title = str(data.get("title") or "Chọn thư mục/ổ đĩa cần tải lên Google Drive")
        picked = dialogs.pick_dir(title, init_dir)
        return {"path": picked}

    def act_scan_subfolders(self, data):
        import concurrent.futures
        p_str = str(data.get("path") or "").strip()
        if not p_str:
            return {"error": "Vui lòng chọn thư mục hoặc ổ đĩa cần quét"}
        
        p = Path(p_str)
        if not p.exists():
            return {"error": f"Đường dẫn không tồn tại: {p_str}"}

        done_set = self._load_done_history()
        dir_entries = []
        root_files = 0
        try:
            with os.scandir(p) as it:
                for entry in it:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if entry.name.startswith("$") or entry.name in ("System Volume Information", "RECYCLER", "MyingGo_Trash_Logs"):
                                continue
                            dir_entries.append((entry.name, entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            root_files += 1
                    except Exception:
                        continue
        except Exception as e:
            return {"error": f"Lỗi đọc thư mục: {e}"}

        def _inspect_one(item):
            name, fpath = item
            sub_count = 0
            try:
                with os.scandir(fpath) as sub_it:
                    sub_count = sum(1 for _ in sub_it)
            except Exception:
                pass
            is_done = self._is_folder_done(fpath, name, done_set)
            return {
                "name": name,
                "path": fpath,
                "item_count": sub_count,
                "done": is_done,
                "checked": (not is_done),
            }

        with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
            folders = list(pool.map(_inspect_one, dir_entries))

        folders.sort(key=lambda x: natural_sort_key(x["name"]))
        return {
            "ok": 1,
            "parent": str(p),
            "folders": folders,
            "root_files": root_files,
            "done_count": sum(1 for f in folders if f.get("done")),
        }

    def act_mark_folders_done(self, data):
        """Đánh dấu hoặc bỏ đánh dấu danh sách thư mục là 'Đã tải xong'."""
        items = data.get("folders") or []
        is_done = bool(data.get("done", True))
        done_set = self._load_done_history()
        for it in items:
            fpath = str(it.get("path") or "")
            fname = str(it.get("name") or "")
            if fpath or fname:
                k_path, k_name = self._folder_keys(fpath, fname)
                if is_done:
                    if fpath:
                        done_set.add(k_path)
                    if fname:
                        done_set.add(k_name)
                else:
                    done_set.discard(k_path)
                    done_set.discard(k_name)
        self._save_done_history(done_set)
        return {"ok": 1}

    def act_clear_done_history(self, data):
        """Xóa lịch sử các thư mục đã tải xong."""
        self._save_done_history(set())
        self.stats["done_folders"] = []
        return {"ok": 1}

    def act_start_upload(self, data):
        if self.running:
            return {"error": "Đang có tiến trình tải lên đang chạy"}

        rc = self._get_rclone_bin()
        if not Path(rc).is_file():
            # Tự động tải rclone nếu chưa có
            self.act_download_rclone({})
            rc = self._get_rclone_bin()
            if not Path(rc).is_file():
                return {"error": "Chưa có file rclone.exe. Vui lòng bấm nút '⚡ Tự Động Tải Rclone' phía trên."}

        source = str(data.get("source") or "").strip()
        if not source or not Path(source).exists():
            return {"error": "Thư mục nguồn không tồn tại"}

        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"
        target = str(data.get("target") or "").strip()
        if not target:
            target = Path(source).name

        try:
            raw_transfers = int(data.get("transfers") or 24)
            # Cho phép 12..32 luồng song song liênfolder (24-32 luồng × 2.5 MiB/s = 60-80 MiB/s, tải 60GB trong ~10-12 phút)
            transfers = max(12, min(32, raw_transfers))
        except (ValueError, TypeError):
            transfers = 24

        selected_folders = data.get("selected_folders") or []
        is_batch = bool(selected_folders and len(selected_folders) > 0)

        self._stop_requested = False
        self.stats = {
            "running": True,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "Đang tính...",
            "source": source,
            "target": target,
            "transfers": transfers,
            "recent_files": [],
            "error": "",
            "finished": False,
            "start_time": time.time(),
            "is_batch": is_batch,
            "batch_total": len(selected_folders) if is_batch else 1,
            "batch_done": 0,
            "current_subfolder": "",
            "done_folders": [],
        }
        self.clear_log()

        if is_batch:
            self.log(f"📋 BẮT ĐẦU TẢI HÀNG LOẠT SIÊU TỐC: Đã chọn {len(selected_folders)} thư mục trong {source}")
            self.log(f"🎯 Thư mục đích trên Drive: {remote_name}:{target}")
            self.log(f"⚡ Động cơ Liên Thư Mục ({transfers} luồng gộp liên hoàn | Không nghẽn 1 file cuối | Timeout 10m chống đứt ở 100%)")
            self.run_bg(self._batch_upload_worker, source, remote_name, target, selected_folders, transfers)
        else:
            self.log(f"🚀 Bắt đầu tải lên: {source} ➔ {remote_name}:{target}")
            self.log(f"⚡ Động cơ Siêu Tốc ({transfers} luồng | Timeout 10m chống đứt ở 100%)")
            self.run_bg(self._single_upload_worker, source, remote_name, target, transfers)

        return {"ok": 1, "stats": self.stats}

    def _norm_rel(self, p_str: str) -> str:
        return unicodedata.normalize("NFC", p_str.strip().replace("\\", "/")).lower()

    def _list_existing_remote_dirs(self, rc, remote_base, conf) -> set | None:
        """Lấy danh sách thư mục con đã tồn tại trên Drive chỉ bằng 1 lệnh duy nhất."""
        try:
            p = subprocess.run(
                [rc, "lsf", remote_base, "--dirs-only", "--config", conf],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=15,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if p.returncode == 0:
                return {
                    unicodedata.normalize("NFC", line.strip().rstrip("/")).lower()
                    for line in p.stdout.splitlines()
                    if line.strip()
                }
        except Exception:
            pass
        return None

    def _list_remote_folder_files(self, rc, remote_folder, conf) -> dict[str, int] | None:
        """Lấy danh sách toàn bộ file + dung lượng của 1 thư mục con trên Drive bằng --fast-list."""
        try:
            p = subprocess.run(
                [
                    rc, "lsf", remote_folder,
                    "-R", "--files-only",
                    "--format", "ps",
                    "--separator", "|",
                    "--fast-list",
                    "--config", conf,
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=60,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if p.returncode == 0:
                out = {}
                for line in p.stdout.splitlines():
                    if "|" in line:
                        rp, sz = line.rsplit("|", 1)
                        try:
                            out[self._norm_rel(rp)] = int(sz.strip())
                        except ValueError:
                            pass
                return out
        except Exception:
            pass
        return None

    def _build_copy_cmd(self, rc, src_folder, dest, conf, transfers, is_new_dest=False, manifest_file=None):
        """Công thức Liên Thư Mục v3:
        - Nếu có manifest_file (--files-from-raw): chỉ tải đúng các file còn thiếu đã được Python lọc sẵn, bật --no-check-dest + --no-traverse để vào tải 100% công suất ngay lập tức mà KHÔNG tốn bất kỳ lệnh quét thư mục nào trên Drive.
        - Bật --disable-http2 + --drive-chunk-size=64M để mở kết nối TCP HTTP/1.1 độc lập cho từng luồng, đẩy tối đa băng thông Gigabit.
        - Đặt --timeout=10m (thay vì 30s) để khi file video 2.5GB-5GB đạt 100%, Rclone kiên nhẫn chờ Google Drive băm mã MD5 (mất ~40-60s) mà KHÔNG BAO GIỜ ngắt kết nối ở 100% gây tải lại từ đầu.
        """
        checkers = 1 if manifest_file else 8
        cmd = [
            rc,
            "copy",
            src_folder,
            dest,
            "--config",
            conf,
            f"--transfers={transfers}",
            f"--checkers={checkers}",
            "--max-backlog=100000",
            "--drive-chunk-size=64M",
            "--drive-upload-cutoff=64M",
            "--disable-http2",
            "--timeout=10m",
            "--contimeout=20s",
            "--low-level-retries=30",
            "--retries=5",
            "--retries-sleep=5s",
            "--tpslimit=10",
            "--tpslimit-burst=20",
            "--stats=1s",
            "-v",
        ]
        if manifest_file:
            cmd.extend(["--files-from-raw", str(manifest_file), "--no-check-dest", "--no-traverse"])
        elif is_new_dest:
            cmd.append("--no-check-dest")
        else:
            cmd.extend(["--size-only", "--fast-list", "--check-first"])
        return cmd

    def _batch_upload_worker(self, parent_src, remote_name, target_base, selected_folders, transfers):
        import concurrent.futures

        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        total_folders = len(selected_folders)
        parent_path = Path(parent_src)

        remote_parent = f"{remote_name}:{target_base.rstrip('/')}" if target_base else f"{remote_name}:"
        self.stats["eta"] = "Đang đối chiếu nhanh..."
        self.log("🔍 Đang kiểm tra danh sách thư mục trên Google Drive...")
        existing_dirs = self._list_existing_remote_dirs(rc, remote_parent, conf)

        # Kiểm tra song song các thư mục đã tồn tại một phần trên Drive (thường chỉ 1-2 thư mục đang tải dở)
        existing_to_check = []
        if existing_dirs is not None:
            for folder_name in selected_folders:
                if self._norm_rel(folder_name) in existing_dirs:
                    existing_to_check.append(folder_name)

        remote_files_map: dict[str, dict[str, int] | None] = {}
        if existing_to_check:
            self.log(f"⚡ Phát hiện {len(existing_to_check)} thư mục đã có một phần trên Drive — đang đối chiếu nhanh các file đã tải...")
            def _fetch_one(fname):
                dst_f = f"{target_base.rstrip('/')}/{fname}" if target_base else fname
                return fname, self._list_remote_folder_files(rc, f"{remote_name}:{dst_f}", conf)

            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
                for fname, rmap in pool.map(_fetch_one, existing_to_check):
                    remote_files_map[fname] = rmap

        manifest_lines: list[str] = []
        pending_by_folder: dict[str, set[str]] = {}
        remaining_count_by_folder: dict[str, int] = {}
        fallback_per_folder: list[str] = []
        total_missing_bytes = 0

        for idx, folder_name in enumerate(selected_folders, 1):
            if self._stop_requested:
                break
            src_folder_path = parent_path / folder_name
            if not src_folder_path.exists():
                continue

            is_new_dest = (existing_dirs is not None) and (self._norm_rel(folder_name) not in existing_dirs)
            rmap = {} if is_new_dest else remote_files_map.get(folder_name)

            if rmap is None:
                # Nếu không lấy được danh sách từ xa, dùng chế độ dự phòng cho thư mục này
                fallback_per_folder.append(folder_name)
                continue

            # Quét file trên ổ cứng cục bộ (tốc độ < 0.01s mỗi thư mục)
            local_entries: list[tuple[str, int, str]] = []
            for root_dir, _, files in os.walk(src_folder_path):
                for f in files:
                    full_p = os.path.join(root_dir, f)
                    try:
                        sz = os.path.getsize(full_p)
                    except OSError:
                        sz = 0
                    rel_in_folder = os.path.relpath(full_p, src_folder_path).replace("\\", "/")
                    rel_from_parent = f"{folder_name}/{rel_in_folder}"
                    local_entries.append((rel_in_folder, sz, rel_from_parent))

            total_local = len(local_entries)
            missing_entries = [
                (rel_in_f, sz, rel_from_p)
                for (rel_in_f, sz, rel_from_p) in local_entries
                if rmap.get(self._norm_rel(rel_in_f)) != sz
            ]

            if total_local > 0 and len(missing_entries) == 0:
                # Thư mục đã đủ 100% file trên Drive!
                self._mark_folder_done(str(src_folder_path), folder_name, True)
                if folder_name not in self.stats["done_folders"]:
                    self.stats["done_folders"].append(folder_name)
                self.stats["batch_done"] = len(self.stats["done_folders"])
                self.log(f"✅ [{idx}/{total_folders}] '{folder_name}': Đã có đủ 100% ({total_local}/{total_local} file) trên Drive ➔ Tự động đánh dấu Đã tải!")
                continue

            # Sắp xếp ưu tiên đẩy các file lớn (.mp4) xen kẽ file nhỏ trong từng thư mục để lấp đầy 100% băng thông
            missing_entries.sort(key=lambda x: x[1], reverse=True)
            pset = set()
            for _, sz, rel_from_p in missing_entries:
                manifest_lines.append(rel_from_p)
                pset.add(self._norm_rel(rel_from_p))
                total_missing_bytes += sz

            pending_by_folder[folder_name] = pset
            remaining_count_by_folder[folder_name] = len(missing_entries)
            already_done = total_local - len(missing_entries)
            if already_done > 0:
                self.log(f"📌 [{idx}/{total_folders}] '{folder_name}': Đã có {already_done}/{total_local} file trên Drive ➔ Chỉ tải thêm {len(missing_entries)} file còn thiếu.")
            else:
                self.log(f"📁 [{idx}/{total_folders}] '{folder_name}': Sẵn sàng tải {len(missing_entries)} file mới.")

        if manifest_lines and not self._stop_requested:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            manifest_path = DATA_DIR / "upload_manifest.txt"
            manifest_path.write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

            active_folders = list(pending_by_folder.keys())
            self.stats["current_subfolder"] = active_folders[0] if active_folders else ""
            self.stats["files_total"] = len(manifest_lines)
            gb_need = total_missing_bytes / (1024 ** 3)
            self.log(f"\n🚀 KHỞI CHẠY ĐỘNG CƠ GỘP LIÊN THƯ MỤC: Đẩy {len(manifest_lines)} file ({gb_need:.2f} GiB) qua {transfers} luồng song song liên tục!")
            self.log("   ➔ Không chờ lẻ 1 file cuối thư mục — Tự động đánh dấu từng thư mục ngay khi đủ file!")

            cmd = self._build_copy_cmd(
                rc,
                str(parent_path),
                remote_parent,
                conf,
                transfers,
                is_new_dest=True,
                manifest_file=manifest_path,
            )
            success = self._run_rclone_cmd(
                cmd,
                pending_by_folder=pending_by_folder,
                remaining_count_by_folder=remaining_count_by_folder,
                parent_src=str(parent_path),
                total_folders=total_folders,
            )
            if success and not self._stop_requested:
                for fname in active_folders:
                    if fname not in self.stats["done_folders"]:
                        self._mark_folder_done(str(parent_path / fname), fname, True)
                        self.stats["done_folders"].append(fname)
                        self.stats["batch_done"] = len(self.stats["done_folders"])
                        self.log(f"✅ Hoàn tất 100% & Đã ghi nhớ thư mục [{self.stats['batch_done']}/{total_folders}]: {fname}")

        # Chạy dự phòng nếu có thư mục không lấy được manifest
        for folder_name in fallback_per_folder:
            if self._stop_requested:
                break
            src_folder = str(parent_path / folder_name)
            dst_folder = f"{target_base.rstrip('/')}/{folder_name}" if target_base else folder_name
            dest = f"{remote_name}:{dst_folder}"
            self.stats["current_subfolder"] = folder_name
            self.log(f"\n📁 Đang tải thư mục: {folder_name} ➔ {dest}")
            cmd = self._build_copy_cmd(rc, src_folder, dest, conf, transfers, is_new_dest=False)
            if self._run_rclone_cmd(cmd) and not self._stop_requested:
                self._mark_folder_done(src_folder, folder_name, True)
                if folder_name not in self.stats["done_folders"]:
                    self.stats["done_folders"].append(folder_name)
                self.stats["batch_done"] = len(self.stats["done_folders"])
                self.log(f"✅ Hoàn tất 100% & Đã ghi nhớ thư mục: {folder_name}")

        if not self._stop_requested and len(self.stats["done_folders"]) >= total_folders:
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất tất cả"
            self.stats["batch_done"] = total_folders
            self.log(f"\n🎉 TẤT CẢ {total_folders} THƯ MỤC ĐÃ ĐƯỢC TẢI LÊN DRIVE THÀNH CÔNG!")
        elif not self._stop_requested:
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
        self.stats["running"] = False

    def _single_upload_worker(self, source, remote_name, target, transfers):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        dest = f"{remote_name}:{target}"

        existing = self._list_existing_remote_dirs(rc, dest, conf)
        is_new_dest = (existing is not None and len(existing) == 0)

        cmd = self._build_copy_cmd(rc, source, dest, conf, transfers, is_new_dest=is_new_dest)
        success = self._run_rclone_cmd(cmd)
        if success and not self._stop_requested:
            self._mark_folder_done(source, Path(source).name, True)
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất"
            self.log(f"🎉 TẢI LÊN HOÀN TẤT 100% & ĐÃ GHI NHỚ: {source} ➔ {dest}")
        self.stats["running"] = False

    def _run_rclone_cmd(self, cmd, pending_by_folder=None, remaining_count_by_folder=None, parent_src="", total_folders=1):
        try:
            with self._proc_lock:
                self.proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )

            for raw_line in self.proc.stdout:
                if self._stop_requested:
                    break
                line = raw_line.strip()
                if not line:
                    continue

                m_bytes = RE_STATS_BYTES.search(line)
                if m_bytes:
                    self.stats["transferred_bytes"] = m_bytes.group(1)
                    self.stats["total_bytes"] = m_bytes.group(2)
                    try:
                        pct_val = float(m_bytes.group(3))
                        f_done = self.stats.get("files_done", 0)
                        f_tot = self.stats.get("files_total", 0)
                        if pct_val >= 100.0 and f_tot > 0 and f_done < f_tot:
                            pct_val = 99.0
                        self.stats["percent"] = pct_val
                    except ValueError:
                        pass
                    self.stats["speed"] = m_bytes.group(4)
                    self.stats["eta"] = m_bytes.group(5)

                m_files = RE_STATS_FILES.search(line)
                if m_files:
                    try:
                        self.stats["files_done"] = int(m_files.group(1))
                        self.stats["files_total"] = int(m_files.group(2))
                        if self.stats.get("percent", 0) >= 100.0 and self.stats["files_total"] > 0 and self.stats["files_done"] < self.stats["files_total"]:
                            self.stats["percent"] = 99.0
                    except ValueError:
                        pass

                m_checks = RE_CHECKS_FILES.search(line)
                if m_checks:
                    try:
                        self.stats["checks_done"] = int(m_checks.group(1))
                        self.stats["checks_total"] = int(m_checks.group(2))
                    except ValueError:
                        pass

                m_copied = RE_FILE_COPIED.search(line)
                if m_copied:
                    fname = m_copied.group(1).strip()
                    rec = self.stats["recent_files"]
                    if fname not in rec:
                        rec.insert(0, fname)
                        if len(rec) > 10:
                            rec.pop()
                    self.log(f"  ✓ {fname}")

                    if pending_by_folder is not None and "/" in fname.replace("\\", "/"):
                        norm_f = self._norm_rel(fname)
                        top_raw = fname.replace("\\", "/").split("/", 1)[0]
                        matched_folder = None
                        for k in pending_by_folder:
                            if self._norm_rel(k) == self._norm_rel(top_raw):
                                matched_folder = k
                                break
                        if matched_folder and matched_folder not in self.stats["done_folders"]:
                            self.stats["current_subfolder"] = matched_folder
                            pset = pending_by_folder[matched_folder]
                            pset.discard(norm_f)
                            if remaining_count_by_folder is not None and matched_folder in remaining_count_by_folder:
                                remaining_count_by_folder[matched_folder] = max(0, remaining_count_by_folder[matched_folder] - 1)
                            is_folder_complete = (len(pset) == 0) or (
                                remaining_count_by_folder is not None and remaining_count_by_folder.get(matched_folder, 1) <= 0
                            )
                            if is_folder_complete:
                                self._mark_folder_done(str(Path(parent_src) / matched_folder), matched_folder, True)
                                self.stats["done_folders"].append(matched_folder)
                                self.stats["batch_done"] = len(self.stats["done_folders"])
                                self.log(f"✅ HOÀN TẤT 100% & ĐÃ GHI NHỚ THƯ MỤC [{self.stats['batch_done']}/{total_folders}]: {matched_folder}")
                                # Chuyển tên thư mục đang hiển thị sang thư mục kế tiếp còn file
                                for next_f, next_set in pending_by_folder.items():
                                    if next_f not in self.stats["done_folders"] and len(next_set) > 0:
                                        self.stats["current_subfolder"] = next_f
                                        break

                if any(k in line.upper() for k in ("ERROR", "FAILED", "NOTICE", "TRANSFERRED", "ELAPSED")):
                    if "using defaults" not in line and "Config file" not in line:
                        self.log(line)

            ret = self.proc.wait() if self.proc else 0
            return (ret == 0)
        except Exception as e:
            self.stats["error"] = str(e)
            self.log(f"❌ Lỗi: {e}")
            return False
        finally:
            with self._proc_lock:
                self.proc = None

    def act_progress(self, data):
        since = int(data.get("since") or 0)
        logs = self.get_log(since)
        return {
            "stats": self.stats,
            "logs": logs.get("lines", []),
            "next_log": logs.get("next", 0),
            "running": self.running,
        }

    def act_stop_upload(self, data):
        self._stop_requested = True
        with self._proc_lock:
            if self.proc and self.proc.poll() is None:
                self.log("⏹ Đang gửi tín hiệu dừng tiến trình...")
                try:
                    self.proc.terminate()
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None
        self.stats["running"] = False
        self.running = False
        return {"ok": 1, "message": "Đã dừng tiến trình tải lên"}

    def act_open_drive_web(self, data):
        url = "https://drive.google.com/drive/my-drive"
        webbrowser.open(url)
        return {"ok": 1, "url": url}
