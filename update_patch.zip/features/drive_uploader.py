"""Tính năng: Tải lên Google Drive Chuẩn & Ổn Định (1 Luồng / Đa Luồng / Google Drive Desktop).

Hỗ trợ:
- Tải tuần tự từng thư mục (FD) với 1 luồng, 2 luồng, 4 luồng (chuẩn như Chrome Web) hoặc 8-16 luồng.
- Hỗ trợ chế độ Copy trực tiếp qua Ổ đĩa Google Drive Desktop (E:\\My Drive, G:\\My Drive) nếu máy có cài.
- Tải nguyên vẹn 100% mọi file trong thư mục, không bỏ sót bất kỳ định dạng nào.
- Tự động ghi nhớ các thư mục (FD) đã tải xong vào data/drive_uploaded_history.json và bỏ chọn ở lần sau.
- Tự động lọc bỏ thư mục bộ nhớ đệm ẩn của Google Drive Desktop (101274184026883034021).
- Tự động phát hiện và cảnh báo rõ ràng khi tài khoản chạm hạn mức 750 GB / 24h của Google Drive.
"""
import configparser
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
import urllib.error
import urllib.request
import webbrowser
import zipfile
from pathlib import Path

from core import dialogs, logger
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
BIN_RCLONE = ROOT / "bin" / "rclone.exe"
DATA_DIR = ROOT / "data"
CONFIG_FILE = DATA_DIR / "rclone.conf"
HISTORY_FILE = DATA_DIR / "drive_uploaded_history.json"
CLIENT_CRED_FILE = DATA_DIR / "drive_client_credentials.json"

# Cấu hình tài khoản Google Drive mặc định (được chia sẻ tự động sang máy phụ)
DEFAULT_RCLONE_CONF = """[gdrive]
type = drive
scope = drive
token = {"access_token":"ya29.a0AehfTOkQGay8lmS0sN2MG3-ktM9VokV78lih2zNNYvb2ErUiL8AihOpdEzqi5kt5S16MTjdTDGq1EJlz_nCjQoNlMHf-4wUUbgfikOQCV5iXc8-kyidlaRfjnbY9ARj77oCH9J5joJhB7f42T7Il8ktiyaDtSQuutoAMbdSluPkct8QUvmZ_JZT7CSdqx_GbZ1qeBOMaCgYKASwSARASFQHGX2Mi9xU7bQOBFmg1ixBrw9SYoQ0206","token_type":"Bearer","refresh_token":"1//0ePxnH-qqKrkhCgYIARAAGA4SNwF-L9IrxfGO743JC5hx0pUA15aS69kf2PuLL71Gk21a9i8t2x_wHw-D0sgK_JasN4dpvhlNyxA","expiry":"2026-11-06T17:35:11.1521589+07:00","expires_in":3599}
team_drive = 
"""

RE_STATS_BYTES = re.compile(
    r"Transferred:\s+([\d.]+\s+[A-Za-z]+)\s+/\s+([\d.]+\s+[A-Za-z]+),\s+([\d.]+)%,\s+([\d.]+\s+[A-Za-z]+/s),\s+ETA\s+(\S+)"
)
RE_STATS_FILES = re.compile(r"Transferred:\s+(\d+)\s+/\s+(\d+),\s+([\d.]+)%")
RE_CHECKS_FILES = re.compile(r"Checks:\s+(\d+)\s+/\s+(\d+)")
RE_FILE_COPIED = re.compile(
    r"(?:INFO|NOTICE)\s+:\s+(.+?):\s+Copied\s+\((?:new|replaced existing)\)"
)

# Các thư mục hệ thống / cache Google Drive Desktop cần tự động ẩn khỏi danh sách quét
IGNORED_FOLDER_NAMES = {
    "system volume information",
    "recycler",
    "$recycle.bin",
    "myinggo_trash_logs",
    "file rác myinggo",
    ".shortcut-targets-by-id",
    ".encrypted",
    ".tmp.drivedownload",
    ".tmp.driveupload",
}


def natural_sort_key(s):
    """Sắp xếp tự nhiên: số nhỏ trước số lớn (01, 02... 09, 10...)."""
    return [
        int(text) if text.isdigit() else text.lower()
        for text in re.split(r"(\d+)", s)
    ]


def _is_system_or_gdfs_cache_folder(name: str) -> bool:
    """Kiểm tra thư mục hệ thống hoặc thư mục cache 21 chữ số của Google Drive Desktop."""
    n = name.strip()
    if not n or n.startswith("$") or n.startswith("."):
        return True
    if n.lower() in IGNORED_FOLDER_NAMES:
        return True
    # Google Drive for Desktop tạo thư mục cache có tên là chuỗi số ID dài 18-25 chữ số (VD: 101274184026883034021)
    if n.isdigit() and len(n) >= 18:
        return True
    return False


def _fmt_bytes(num_bytes: float) -> str:
    if num_bytes <= 0:
        return "0 B"
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    idx = 0
    val = float(num_bytes)
    while val >= 1024.0 and idx < len(units) - 1:
        val /= 1024.0
        idx += 1
    return f"{val:.2f} {units[idx]}" if idx >= 2 else f"{val:.0f} {units[idx]}"


class DriveUploader(Feature):
    title = "☁️ Tải lên Drive"
    order = 13
    dock = "top"

    def __init__(self):
        super().__init__()
        self.proc = None
        self._proc_lock = threading.Lock()
        self._stop_requested = False
        self._ensure_config_exists()
        self.stats = {
            "running": False,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "--",
            "source": "",
            "target": "",
            "transfers": 1,
            "engine_mode": "rclone",
            "recent_files": [],
            "error": "",
            "warning": "",
            "finished": False,
            "start_time": 0,
            "is_batch": False,
            "batch_total": 0,
            "batch_done": 0,
            "current_subfolder": "",
            "done_folders": [],
        }

    # ── Lịch sử thư mục đã tải xong ──────────────────────────────────────
    def _load_done_history(self) -> set:
        if not HISTORY_FILE.is_file():
            return set()
        try:
            data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return set(str(x).strip().lower() for x in data if str(x).strip())
        except Exception:
            pass
        return set()

    def _save_done_history(self, done_set: set):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            HISTORY_FILE.write_text(
                json.dumps(sorted(list(done_set)), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _folder_keys(self, folder_path: str, folder_name: str) -> tuple[str, str]:
        try:
            norm_path = str(Path(folder_path).resolve()).strip().lower()
        except Exception:
            norm_path = str(folder_path).strip().lower()
        norm_name = f"name::{str(folder_name).strip().lower()}"
        return norm_path, norm_name

    def _is_folder_done(
        self, folder_path: str, folder_name: str, done_set: set | None = None
    ) -> bool:
        if done_set is None:
            done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        return (k_path in done_set) or (k_name in done_set)

    def _mark_folder_done(
        self, folder_path: str, folder_name: str, is_done: bool = True
    ):
        done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        if is_done:
            done_set.add(k_path)
            done_set.add(k_name)
        else:
            done_set.discard(k_path)
            done_set.discard(k_name)
        self._save_done_history(done_set)

    # ── Quản lý Rclone & Cấu hình ────────────────────────────────────────
    def _get_rclone_bin(self):
        if BIN_RCLONE.is_file():
            return str(BIN_RCLONE)
        found = shutil.which("rclone")
        return found if found else str(BIN_RCLONE)

    def _ensure_config_exists(self):
        """Đảm bảo file data/rclone.conf luôn có sẵn tài khoản Drive đã đăng nhập."""
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not CONFIG_FILE.is_file() or not CONFIG_FILE.read_text(encoding="utf-8").strip():
            appdata_conf = Path(os.environ.get("APPDATA", "")) / "rclone" / "rclone.conf"
            if appdata_conf.is_file() and "[gdrive]" in appdata_conf.read_text(encoding="utf-8"):
                try:
                    shutil.copy2(appdata_conf, CONFIG_FILE)
                    return
                except Exception:
                    pass
            try:
                CONFIG_FILE.write_text(DEFAULT_RCLONE_CONF, encoding="utf-8")
            except Exception:
                pass

    def _get_config_path(self):
        self._ensure_config_exists()
        return str(CONFIG_FILE)

    def _detect_gdfs_mounts(self) -> list[str]:
        """Tự động phát hiện ổ đĩa Google Drive for Desktop (VD: E:\\My Drive, G:\\My Drive)."""
        mounts = []
        for drv in "DEFGHIJKLMNOPQRSTUVWXYZ":
            for sub in ("My Drive", "Google Drive", "Drive của tôi"):
                cand = Path(f"{drv}:\\{sub}")
                try:
                    if cand.exists() and cand.is_dir():
                        mounts.append(str(cand))
                except Exception:
                    pass
        return mounts

    def _has_custom_client_id(self) -> bool:
        try:
            conf_text = Path(self._get_config_path()).read_text(encoding="utf-8")
            for line in conf_text.splitlines():
                if line.strip().startswith("client_id") and "=" in line:
                    val = line.split("=", 1)[1].strip()
                    if val and "202264815644" not in val:
                        return True
        except Exception:
            pass
        return False

    def _list_remotes(self):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        if not Path(rc).is_file():
            return []
        try:
            p = subprocess.run(
                [rc, "listremotes", "--config", conf],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            remotes = [
                r.strip().rstrip(":") for r in p.stdout.splitlines() if r.strip()
            ]
            return remotes
        except Exception:
            return []

    def act_status(self, data):
        rc = self._get_rclone_bin()
        installed = Path(rc).is_file()
        conf = self._get_config_path()
        remotes = self._list_remotes()
        connected = "gdrive" in remotes or len(remotes) > 0
        quota_info = None
        gdfs_mounts = self._detect_gdfs_mounts()
        has_custom_client = self._has_custom_client_id()

        if connected:
            primary_remote = "gdrive" if "gdrive" in remotes else remotes[0]
            try:
                p = subprocess.run(
                    [rc, "about", f"{primary_remote}:", "--json", "--config", conf],
                    capture_output=True,
                    text=True,
                    timeout=6,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if p.returncode == 0 and p.stdout.strip():
                    quota_info = json.loads(p.stdout)
            except Exception:
                pass

        return {
            "installed": installed,
            "rclone_path": rc,
            "config_path": conf,
            "connected": connected,
            "remotes": remotes,
            "primary_remote": (
                "gdrive"
                if "gdrive" in remotes
                else (remotes[0] if remotes else "gdrive")
            ),
            "quota": quota_info,
            "gdfs_mounts": gdfs_mounts,
            "has_custom_client": has_custom_client,
            "running": self.running,
            "stats": self.stats,
        }

    def act_download_rclone(self, data):
        """Tự động tải rclone.exe về thư mục bin/ (cho máy phụ khi chưa có)."""
        bin_dir = ROOT / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        target_exe = bin_dir / "rclone.exe"

        url = "https://downloads.rclone.org/rclone-current-windows-amd64.zip"
        try:
            self.log("🌐 Đang kết nối tải rclone.exe từ downloads.rclone.org...")
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MyingGo/1.0"
                },
            )
            with urllib.request.urlopen(req, timeout=40) as resp:
                data_bytes = resp.read()

            self.log(
                f"📦 Đã tải gói nén ({len(data_bytes) // 1048576} MB), đang giải nén..."
            )
            with zipfile.ZipFile(io.BytesIO(data_bytes)) as z:
                found = False
                for member in z.namelist():
                    if member.endswith("rclone.exe"):
                        with z.open(member) as src_file, open(
                            target_exe, "wb"
                        ) as dst_file:
                            shutil.copyfileobj(src_file, dst_file)
                        found = True
                        break
                if not found:
                    return {"error": "Không tìm thấy file rclone.exe trong gói nén."}

            if target_exe.is_file():
                self.log(f"✅ ĐÃ CÀI ĐẶT THÀNH CÔNG: {target_exe}")
                return {"ok": 1, "path": str(target_exe)}
            return {"error": "Lỗi lưu file rclone.exe"}
        except Exception as e:
            return {"error": f"Lỗi tải rclone: {e}"}

    def act_save_client_id(self, data):
        """Lưu Google Cloud Client ID & Secret riêng để không bị giới hạn bởi Rclone mặc định."""
        client_id = str(data.get("client_id") or "").strip()
        client_secret = str(data.get("client_secret") or "").strip()
        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"

        DATA_DIR.mkdir(parents=True, exist_ok=True)
        CLIENT_CRED_FILE.write_text(
            json.dumps(
                {"client_id": client_id, "client_secret": client_secret},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        # Cập nhật vào rclone.conf nếu đã có
        conf_path = Path(self._get_config_path())
        if conf_path.is_file():
            try:
                cfg = configparser.RawConfigParser()
                cfg.read(conf_path, encoding="utf-8")
                if not cfg.has_section(remote_name):
                    cfg.add_section(remote_name)
                    cfg.set(remote_name, "type", "drive")
                    cfg.set(remote_name, "scope", "drive")
                if client_id:
                    cfg.set(remote_name, "client_id", client_id)
                elif cfg.has_option(remote_name, "client_id"):
                    cfg.remove_option(remote_name, "client_id")
                if client_secret:
                    cfg.set(remote_name, "client_secret", client_secret)
                elif cfg.has_option(remote_name, "client_secret"):
                    cfg.remove_option(remote_name, "client_secret")
                with open(conf_path, "w", encoding="utf-8") as f:
                    cfg.write(f)
            except Exception as e:
                return {"error": f"Lỗi cập nhật rclone.conf: {e}"}

        return {
            "ok": 1,
            "message": "Đã lưu Client ID! Hệ thống sẽ mở cửa sổ xác thực lại tài khoản với Client ID mới.",
        }

    def act_connect(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"

        if not Path(rc).is_file():
            res = self.act_download_rclone({})
            if res.get("error"):
                return {
                    "error": f"Chưa có file rclone.exe và tải tự động thất bại: {res['error']}"
                }
            rc = self._get_rclone_bin()

        # Kiểm tra xem người dùng có cài Client ID riêng không
        custom_cid = ""
        custom_sec = ""
        if CLIENT_CRED_FILE.is_file():
            try:
                cred = json.loads(CLIENT_CRED_FILE.read_text(encoding="utf-8"))
                custom_cid = str(cred.get("client_id") or "").strip()
                custom_sec = str(cred.get("client_secret") or "").strip()
            except Exception:
                pass

        bat_file = DATA_DIR / "connect_gdrive.bat"
        if custom_cid and custom_sec:
            cmd_line = f'"{rc}" config create {remote_name} drive scope=drive client_id="{custom_cid}" client_secret="{custom_sec}" --config "{conf}"'
        else:
            cmd_line = f'"{rc}" config create {remote_name} drive scope=drive config_shared_client_id=true --config "{conf}"'

        bat_file.write_text(
            f"""@echo off
chcp 65001 >nul
title KẾT NỐI / ĐỔI TÀI KHOẢN GOOGLE DRIVE - MYINGGO
echo ============================================================
echo   ĐANG MỞ TRÌNH DUYỆT ĐỂ ĐĂNG NHẬP TÀI KHOẢN GOOGLE DRIVE...
echo   Hãy chọn tài khoản Google còn hạn mức tải lên (750GB/ngày)
echo ============================================================
{cmd_line}
echo.
echo [HOÀN TẤT] Bạn có thể đóng cửa sổ này!
pause
""",
            encoding="utf-8",
        )

        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        try:
            subprocess.Popen(["cmd.exe", "/c", str(bat_file)], creationflags=flags)
        except Exception as e:
            return {"error": f"Không thể khởi chạy cửa sổ kết nối: {e}"}

        return {"ok": 1, "message": "Đã mở cửa sổ kết nối Google Drive"}

    def act_export_token(self, data):
        conf = self._get_config_path()
        if not Path(conf).is_file():
            return {"error": "Chưa có file cấu hình Drive trên máy này."}
        try:
            text = Path(conf).read_text(encoding="utf-8").strip()
            if not text or "[gdrive]" not in text:
                return {
                    "error": "Chưa có tài khoản Google Drive nào được liên kết trên máy này."
                }
            return {"ok": 1, "config_text": text}
        except Exception as e:
            return {"error": f"Lỗi đọc file: {e}"}

    def act_import_token(self, data):
        text = str(data.get("config_text") or "").strip()
        if not text or "[gdrive]" not in text:
            return {
                "error": "Nội dung mã kết nối không hợp lệ (phải chứa thông tin [gdrive])."
            }
        conf = self._get_config_path()
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            Path(conf).write_text(text + "\n", encoding="utf-8")
            remotes = self._list_remotes()
            if "gdrive" in remotes or len(remotes) > 0:
                return {
                    "ok": 1,
                    "message": "Đã nhập tài khoản Google Drive thành công!",
                }
            return {"error": "Đã lưu nhưng không nhận diện được remote Drive."}
        except Exception as e:
            return {"error": f"Lỗi ghi file cấu hình: {e}"}

    def act_open_advanced_config(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        subprocess.Popen(
            [
                "cmd.exe",
                "/c",
                f'title Rclone Advanced Config & "{rc}" config --config "{conf}"',
            ],
            creationflags=flags,
        )
        return {"ok": 1}

    def act_pick_folder(self, data):
        init_dir = str(data.get("initial") or "")
        title = str(
            data.get("title") or "Chọn thư mục/ổ đĩa cần tải lên Google Drive"
        )
        picked = dialogs.pick_dir(title, init_dir)
        return {"path": picked}

    def act_scan_subfolders(self, data):
        import concurrent.futures

        p_str = str(data.get("path") or "").strip()
        if not p_str:
            return {"error": "Vui lòng chọn thư mục hoặc ổ đĩa cần quét"}

        p = Path(p_str)
        if not p.exists():
            return {"error": f"Đường dẫn không tồn tại: {p_str}"}

        done_set = self._load_done_history()
        dir_entries = []
        root_files = 0
        try:
            with os.scandir(p) as it:
                for entry in it:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if _is_system_or_gdfs_cache_folder(entry.name):
                                continue
                            dir_entries.append((entry.name, entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            root_files += 1
                    except Exception:
                        continue
        except Exception as e:
            return {"error": f"Lỗi đọc thư mục: {e}"}

        def _inspect_one(item):
            name, fpath = item
            sub_count = 0
            try:
                with os.scandir(fpath) as sub_it:
                    sub_count = sum(1 for _ in sub_it)
            except Exception:
                pass
            is_done = self._is_folder_done(fpath, name, done_set)
            return {
                "name": name,
                "path": fpath,
                "item_count": sub_count,
                "done": is_done,
                "checked": (not is_done),
            }

        with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
            folders = list(pool.map(_inspect_one, dir_entries))

        folders.sort(key=lambda x: natural_sort_key(x["name"]))
        return {
            "ok": 1,
            "parent": str(p),
            "folders": folders,
            "root_files": root_files,
            "done_count": sum(1 for f in folders if f.get("done")),
        }

    def act_mark_folders_done(self, data):
        """Đánh dấu hoặc bỏ đánh dấu danh sách thư mục là 'Đã tải xong'."""
        items = data.get("folders") or []
        is_done = bool(data.get("done", True))
        done_set = self._load_done_history()
        for it in items:
            fpath = str(it.get("path") or "")
            fname = str(it.get("name") or "")
            if fpath or fname:
                k_path, k_name = self._folder_keys(fpath, fname)
                if is_done:
                    if fpath:
                        done_set.add(k_path)
                    if fname:
                        done_set.add(k_name)
                else:
                    done_set.discard(k_path)
                    done_set.discard(k_name)
        self._save_done_history(done_set)
        return {"ok": 1}

    def act_clear_done_history(self, data):
        """Xóa lịch sử các thư mục đã tải xong."""
        self._save_done_history(set())
        self.stats["done_folders"] = []
        return {"ok": 1}

    # ── Khởi chạy tải lên ────────────────────────────────────────────────
    def act_start_upload(self, data):
        if self.running:
            return {"error": "Đang có tiến trình tải lên đang chạy"}

        engine_mode = str(data.get("engine_mode") or "rclone").strip()
        source = str(data.get("source") or "").strip()
        if not source or not Path(source).exists():
            return {"error": "Thư mục nguồn không tồn tại"}

        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"
        target = str(data.get("target") or "").strip()
        if not target:
            target = Path(source).name

        try:
            raw_transfers = int(data.get("transfers") or 1)
            transfers = max(1, min(16, raw_transfers))
        except (ValueError, TypeError):
            transfers = 1

        if engine_mode == "rclone":
            rc = self._get_rclone_bin()
            if not Path(rc).is_file():
                self.act_download_rclone({})
                rc = self._get_rclone_bin()
                if not Path(rc).is_file():
                    return {
                        "error": "Chưa có file rclone.exe. Vui lòng bấm nút '⚡ Tự Động Tải Rclone' phía trên."
                    }

        # Lọc bỏ các thư mục cache hệ thống nếu lỡ có trong danh sách
        raw_selected = data.get("selected_folders") or []
        selected_folders = [
            f for f in raw_selected if not _is_system_or_gdfs_cache_folder(str(f))
        ]
        is_batch = bool(selected_folders and len(selected_folders) > 0)

        self._stop_requested = False
        self.stats = {
            "running": True,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "Đang bắt đầu...",
            "source": source,
            "target": target,
            "transfers": transfers,
            "engine_mode": engine_mode,
            "recent_files": [],
            "error": "",
            "warning": "",
            "finished": False,
            "start_time": time.time(),
            "is_batch": is_batch,
            "batch_total": len(selected_folders) if is_batch else 1,
            "batch_done": 0,
            "current_subfolder": selected_folders[0] if is_batch else Path(source).name,
            "done_folders": [],
        }
        self.clear_log()

        if engine_mode.startswith("gdfs:"):
            gdfs_root = engine_mode.split("gdfs:", 1)[1].strip()
            self.log(
                f"💻 CHẾ ĐỘ GOOGLE DRIVE DESKTOP: Copy trực tiếp vào ổ đĩa '{gdfs_root}'"
            )
            self.run_bg(
                self._gdfs_upload_worker,
                source,
                gdfs_root,
                target,
                selected_folders if is_batch else None,
            )
        elif is_batch:
            self.log(
                f"🚀 BẮT ĐẦU TẢI LÊN CHUẨN ({transfers} luồng): Đã chọn {len(selected_folders)} thư mục từ {source}"
            )
            self.log(f"🎯 Thư mục đích trên Drive: {remote_name}:{target}")
            self.log(
                "⚡ Tải tuần tự từng thư mục gọn nhẹ, ổn định như trình duyệt Chrome — Tự động lưu trạng thái Đã tải!"
            )
            self.run_bg(
                self._batch_upload_worker,
                source,
                remote_name,
                target,
                selected_folders,
                transfers,
            )
        else:
            self.log(
                f"🚀 Bắt đầu tải lên ({transfers} luồng): {source} ➔ {remote_name}:{target}"
            )
            self.run_bg(
                self._single_upload_worker, source, remote_name, target, transfers
            )

        return {"ok": 1, "stats": self.stats}

    # ── Chế độ 1: Rclone Chuẩn Từng Thư Mục (1 - 8 luồng) ────────────────
    def _build_copy_cmd(self, rc, src_folder, dest, conf, transfers):
        """Lệnh tải chuẩn, gọn nhẹ nhất cho từng thư mục:
        - Giữ nguyên kết nối HTTP/2 mặc định để gộp luồng mượt mà như trình duyệt Chrome.
        - Hỗ trợ chuẩn từ 1 luồng (tuần tự từng file) đến 4-8 luồng mà không làm nghẽn API.
        - --size-only: Bỏ qua tức thì các file đã có trên Drive mà không tốn thời gian băm lại MD5.
        - --timeout=10m: Khi file .mp4 2.5GB đạt 100%, chờ Google Drive chốt file (40-60s) không bao giờ tự ngắt.
        """
        checkers = max(2, min(8, transfers * 2))
        cmd = [
            rc,
            "copy",
            src_folder,
            dest,
            "--config",
            conf,
            f"--transfers={transfers}",
            f"--checkers={checkers}",
            "--size-only",
            "--drive-chunk-size=64M",
            "--drive-upload-cutoff=64M",
            "--timeout=10m",
            "--contimeout=20s",
            "--low-level-retries=15",
            "--retries=5",
            "--retries-sleep=5s",
            "--stats=1s",
            "-v",
        ]
        return cmd

    def _batch_upload_worker(
        self, parent_src, remote_name, target_base, selected_folders, transfers
    ):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        total_folders = len(selected_folders)
        parent_path = Path(parent_src)

        for idx, folder_name in enumerate(selected_folders, 1):
            if self._stop_requested:
                break

            src_folder_path = parent_path / folder_name
            if not src_folder_path.exists():
                self.log(f"⚠️ Bỏ qua '{folder_name}' vì không tìm thấy trên ổ đĩa.")
                continue

            # Đếm nhanh số file và dung lượng của thư mục trên ổ cứng (<0.01s)
            local_file_count = 0
            local_bytes = 0
            for root_dir, _, files in os.walk(src_folder_path):
                for f in files:
                    local_file_count += 1
                    try:
                        local_bytes += os.path.getsize(os.path.join(root_dir, f))
                    except OSError:
                        pass

            dst_sub = (
                f"{target_base.rstrip('/')}/{folder_name}"
                if target_base
                else folder_name
            )
            dest = f"{remote_name}:{dst_sub}"

            self.stats["current_subfolder"] = folder_name
            self.stats["percent"] = 0
            self.stats["files_done"] = 0
            self.stats["files_total"] = local_file_count
            self.stats["transferred_bytes"] = "0 B"
            self.stats["total_bytes"] = _fmt_bytes(local_bytes)
            self.stats["eta"] = "Đang tải..."

            self.log(
                f"\n📂 [{idx}/{total_folders}] Đang tải thư mục: {folder_name} ({local_file_count} file — {_fmt_bytes(local_bytes)})"
            )

            cmd = self._build_copy_cmd(
                rc, str(src_folder_path), dest, conf, transfers
            )
            success = self._run_rclone_cmd(cmd)

            if self._stop_requested:
                break

            if success:
                self._mark_folder_done(str(src_folder_path), folder_name, True)
                if folder_name not in self.stats["done_folders"]:
                    self.stats["done_folders"].append(folder_name)
                self.stats["batch_done"] = len(self.stats["done_folders"])
                self.log(
                    f"✅ HOÀN TẤT 100% & ĐÃ GHI NHỚ [{idx}/{total_folders}]: {folder_name}"
                )
            else:
                self.log(
                    f"⚠️ Thư mục '{folder_name}' chưa hoàn tất 100% (xem cảnh báo phía trên)."
                )
                # Nếu gặp lỗi giới hạn 750GB/ngày của Google Drive thì dừng để tránh treo
                if "750 GB" in self.stats.get("warning", ""):
                    self.stats["error"] = self.stats["warning"]
                    break

        if not self._stop_requested and len(self.stats["done_folders"]) >= total_folders:
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất tất cả"
            self.stats["batch_done"] = total_folders
            self.log(
                f"\n🎉 TẤT CẢ {total_folders} THƯ MỤC ĐÃ ĐƯỢC TẢI LÊN DRIVE THÀNH CÔNG!"
            )
        elif not self._stop_requested:
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
        self.stats["running"] = False

    def _single_upload_worker(self, source, remote_name, target, transfers):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        dest = f"{remote_name}:{target}"

        cmd = self._build_copy_cmd(rc, source, dest, conf, transfers)
        success = self._run_rclone_cmd(cmd)
        if success and not self._stop_requested:
            self._mark_folder_done(source, Path(source).name, True)
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất"
            self.log(f"🎉 TẢI LÊN HOÀN TẤT 100% & ĐÃ GHI NHỚ: {source} ➔ {dest}")
        self.stats["running"] = False

    def _run_rclone_cmd(self, cmd):
        warned_750gb = False
        warned_client_quota = False
        try:
            with self._proc_lock:
                self.proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )

            for raw_line in self.proc.stdout:
                if self._stop_requested:
                    break
                line = raw_line.strip()
                if not line:
                    continue

                # Phát hiện lỗi chạm trần 750 GB / 24h của tài khoản Google Drive
                if not warned_750gb and (
                    "userRateLimitExceeded" in line
                    or "User rate limit exceeded" in line
                    or "domainPolicy" in line
                ):
                    warned_750gb = True
                    msg = (
                        "⚠️ TÀI KHOẢN GOOGLE DRIVE NÀY ĐÃ CHẠM GIỚI HẠN TẢI LÊN 750 GB / 24 GIỜ CỦA GOOGLE "
                        "(Hôm qua 1.01 TB ➔ Nay 1.70 TB = Đã tải ~754 GB trong chưa đầy 16 tiếng). "
                        "Google đang khóa tải file lớn (.mp4) trên tài khoản này trong 24h! "
                        "👉 Giải pháp ngay lập tức: Bấm '🔗 Kết nối / Đổi tài khoản Drive' để đăng nhập 1 Gmail phụ khác (hoặc chờ đủ 24h)."
                    )
                    self.stats["warning"] = msg
                    self.log("\n" + "=" * 72)
                    self.log(msg)
                    self.log("=" * 72 + "\n")

                # Phát hiện lỗi quá tải Client ID mặc định của Rclone (project_number:202264815644)
                if not warned_client_quota and (
                    "202264815644" in line or "Quota exceeded for quota metric" in line
                ):
                    warned_client_quota = True
                    msg = (
                        "ℹ️ Google đang giới hạn tốc độ API mặc định. Khuyên dùng chế độ '1 luồng' hoặc '2 luồng', "
                        "hoặc bấm nút '🔑 Nhập Client ID riêng' / chọn chế độ 'Ổ đĩa Google Drive Desktop'."
                    )
                    if not self.stats.get("warning"):
                        self.stats["warning"] = msg
                    self.log(msg)

                m_bytes = RE_STATS_BYTES.search(line)
                if m_bytes:
                    self.stats["transferred_bytes"] = m_bytes.group(1)
                    self.stats["total_bytes"] = m_bytes.group(2)
                    try:
                        pct_val = float(m_bytes.group(3))
                        f_done = self.stats.get("files_done", 0)
                        f_tot = self.stats.get("files_total", 0)
                        if pct_val >= 100.0 and f_tot > 0 and f_done < f_tot:
                            pct_val = 99.0
                        self.stats["percent"] = pct_val
                    except ValueError:
                        pass
                    self.stats["speed"] = m_bytes.group(4)
                    self.stats["eta"] = m_bytes.group(5)

                m_files = RE_STATS_FILES.search(line)
                if m_files:
                    try:
                        self.stats["files_done"] = int(m_files.group(1))
                        self.stats["files_total"] = int(m_files.group(2))
                        if (
                            self.stats.get("percent", 0) >= 100.0
                            and self.stats["files_total"] > 0
                            and self.stats["files_done"] < self.stats["files_total"]
                        ):
                            self.stats["percent"] = 99.0
                    except ValueError:
                        pass

                m_checks = RE_CHECKS_FILES.search(line)
                if m_checks:
                    try:
                        self.stats["checks_done"] = int(m_checks.group(1))
                        self.stats["checks_total"] = int(m_checks.group(2))
                    except ValueError:
                        pass

                m_copied = RE_FILE_COPIED.search(line)
                if m_copied:
                    fname = m_copied.group(1).strip()
                    rec = self.stats["recent_files"]
                    if fname not in rec:
                        rec.insert(0, fname)
                        if len(rec) > 10:
                            rec.pop()
                    self.log(f"  ✓ {fname}")

                if any(
                    k in line.upper()
                    for k in ("ERROR", "FAILED", "NOTICE", "TRANSFERRED", "ELAPSED")
                ):
                    if "using defaults" not in line and "Config file" not in line:
                        self.log(line)

            ret = self.proc.wait() if self.proc else 0
            return ret == 0
        except Exception as e:
            self.stats["error"] = str(e)
            self.log(f"❌ Lỗi: {e}")
            return False
        finally:
            with self._proc_lock:
                self.proc = None

    # ── Chế độ 2: Copy trực tiếp qua Ổ đĩa Google Drive Desktop (GDFS) ───
    def _gdfs_upload_worker(
        self, parent_src: str, gdfs_root: str, target_base: str, selected_folders: list[str] | None
    ):
        """Copy trực tiếp từng file nguyên bản vào ổ đĩa ảo của Google Drive for Desktop (VD: E:\\My Drive\\0 - FD ID ADD ÂM).
        Hoạt động hoàn toàn không phụ thuộc Rclone API, có thanh tiến độ thực tế, tự bỏ qua file đã có và ghi nhớ FD đã xong.
        """
        try:
            src_root = Path(parent_src)
            dst_root = Path(gdfs_root)
            if target_base:
                dst_root = dst_root / target_base.strip("/\\")
            dst_root.mkdir(parents=True, exist_ok=True)

            folders_to_process = (
                selected_folders if selected_folders else [src_root.name]
            )
            is_subfolders = bool(selected_folders)
            total_folders = len(folders_to_process)

            for idx, folder_name in enumerate(folders_to_process, 1):
                if self._stop_requested:
                    break

                s_dir = (src_root / folder_name) if is_subfolders else src_root
                d_dir = (dst_root / folder_name) if is_subfolders else dst_root
                if not s_dir.exists():
                    continue

                # Thu thập danh sách toàn bộ file trong thư mục
                all_files: list[tuple[Path, Path, int, str]] = []
                total_bytes = 0
                for r, _, files in os.walk(s_dir):
                    for f in files:
                        sp = Path(r) / f
                        rel = sp.relative_to(s_dir)
                        dp = d_dir / rel
                        try:
                            sz = sp.stat().st_size
                        except OSError:
                            sz = 0
                        all_files.append((sp, dp, sz, str(rel).replace("\\", "/")))
                        total_bytes += sz

                self.stats["current_subfolder"] = folder_name
                self.stats["files_total"] = len(all_files)
                self.stats["files_done"] = 0
                self.stats["total_bytes"] = _fmt_bytes(total_bytes)
                self.stats["transferred_bytes"] = "0 B"
                self.stats["percent"] = 0

                self.log(
                    f"\n📂 [{idx}/{total_folders}] Đang đồng bộ '{folder_name}' ({len(all_files)} file — {_fmt_bytes(total_bytes)}) ➔ {d_dir}"
                )

                copied_bytes = 0
                t0 = time.time()
                buf_size = 16 * 1024 * 1024  # 16 MB buffer

                for f_idx, (sp, dp, sz, rel_str) in enumerate(all_files, 1):
                    if self._stop_requested:
                        break
                    dp.parent.mkdir(parents=True, exist_ok=True)

                    # Nếu file đích đã tồn tại và khớp dung lượng 100% thì bỏ qua
                    if dp.exists():
                        try:
                            if dp.stat().st_size == sz:
                                copied_bytes += sz
                                self.stats["files_done"] = f_idx
                                self.stats["transferred_bytes"] = _fmt_bytes(copied_bytes)
                                if total_bytes > 0:
                                    self.stats["percent"] = min(
                                        99.9, (copied_bytes / total_bytes) * 100.0
                                    )
                                continue
                        except OSError:
                            pass

                    # Copy từng khối 16MB để cập nhật tốc độ & thanh phần trăm mượt theo thời gian thực
                    with open(sp, "rb") as fsrc, open(dp, "wb") as fdst:
                        while not self._stop_requested:
                            chunk = fsrc.read(buf_size)
                            if not chunk:
                                break
                            fdst.write(chunk)
                            copied_bytes += len(chunk)
                            elapsed = max(0.1, time.time() - t0)
                            spd = copied_bytes / elapsed
                            rem_bytes = max(0, total_bytes - copied_bytes)
                            eta_sec = int(rem_bytes / spd) if spd > 0 else 0
                            self.stats["speed"] = f"{_fmt_bytes(spd)}/s"
                            self.stats["transferred_bytes"] = _fmt_bytes(copied_bytes)
                            if total_bytes > 0:
                                self.stats["percent"] = min(
                                    99.9, (copied_bytes / total_bytes) * 100.0
                                )
                            self.stats["eta"] = (
                                f"{eta_sec // 60}m{eta_sec % 60}s"
                                if eta_sec >= 60
                                else f"{eta_sec}s"
                            )

                    if not self._stop_requested:
                        self.stats["files_done"] = f_idx
                        rec = self.stats["recent_files"]
                        disp_name = f"{folder_name}/{rel_str}"
                        if disp_name not in rec:
                            rec.insert(0, disp_name)
                            if len(rec) > 10:
                                rec.pop()
                        self.log(f"  ✓ {disp_name}")

                if not self._stop_requested:
                    self._mark_folder_done(str(s_dir), folder_name, True)
                    if folder_name not in self.stats["done_folders"]:
                        self.stats["done_folders"].append(folder_name)
                    self.stats["batch_done"] = len(self.stats["done_folders"])
                    self.stats["percent"] = 100
                    self.log(
                        f"✅ HOÀN TẤT 100% & ĐÃ GHI NHỚ [{idx}/{total_folders}]: {folder_name}"
                    )

            if not self._stop_requested:
                self.stats["percent"] = 100
                self.stats["finished"] = True
                self.stats["speed"] = "0 B/s"
                self.stats["eta"] = "Hoàn tất tất cả"
                self.log(
                    f"\n🎉 ĐÃ ĐỒNG BỘ XONG {len(self.stats['done_folders'])}/{total_folders} THƯ MỤC VÀO GOOGLE DRIVE DESKTOP!"
                )
        except Exception as e:
            self.stats["error"] = str(e)
            self.log(f"❌ Lỗi đồng bộ Google Drive Desktop: {e}")
        finally:
            self.stats["running"] = False

    def act_progress(self, data):
        since = int(data.get("since") or 0)
        logs = self.get_log(since)
        return {
            "stats": self.stats,
            "logs": logs.get("lines", []),
            "next_log": logs.get("next", 0),
            "running": self.running,
        }

    def act_stop_upload(self, data):
        self._stop_requested = True
        with self._proc_lock:
            if self.proc and self.proc.poll() is None:
                self.log("⏹ Đang gửi tín hiệu dừng tiến trình...")
                try:
                    self.proc.terminate()
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None
        self.stats["running"] = False
        self.running = False
        return {"ok": 1, "message": "Đã dừng tiến trình tải lên"}

    def act_open_drive_web(self, data):
        url = "https://drive.google.com/drive/my-drive"
        webbrowser.open(url)
        return {"ok": 1, "url": url}
