"""Tính năng: Tải lên Google Drive siêu tốc (Rclone đa luồng).

Hỗ trợ:
- Tự động tải rclone.exe về thư mục bin/ nếu máy phụ chưa có.
- Tự động đồng bộ tài khoản Google Drive đã đăng nhập giữa máy chính và máy phụ.
- Đa luồng Gigabit: 16, 24, 32, 48, 64 luồng song song (tối ưu kịch trần cho mạng 900M - 1Gbps).
- Tải từng file lẻ nguyên bản (không nén ZIP), auto-resume, bỏ qua file cũ.
- Quét danh sách toàn bộ thư mục & checkbox loại trừ.
"""
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
import zipfile
from pathlib import Path

from core import dialogs, logger
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
BIN_RCLONE = ROOT / "bin" / "rclone.exe"
DATA_DIR = ROOT / "data"
CONFIG_FILE = DATA_DIR / "rclone.conf"
HISTORY_FILE = DATA_DIR / "drive_uploaded_history.json"

# Cấu hình tài khoản Google Drive mặc định (được chia sẻ tự động sang máy phụ)
DEFAULT_RCLONE_CONF = """[gdrive]
type = drive
scope = drive
token = {"access_token":"ya29.a0AehfTOkQGay8lmS0sN2MG3-ktM9VokV78lih2zNNYvb2ErUiL8AihOpdEzqi5kt5S16MTjdTDGq1EJlz_nCjQoNlMHf-4wUUbgfikOQCV5iXc8-kyidlaRfjnbY9ARj77oCH9J5joJhB7f42T7Il8ktiyaDtSQuutoAMbdSluPkct8QUvmZ_JZT7CSdqx_GbZ1qeBOMaCgYKASwSARASFQHGX2Mi9xU7bQOBFmg1ixBrw9SYoQ0206","token_type":"Bearer","refresh_token":"1//0ePxnH-qqKrkhCgYIARAAGA4SNwF-L9IrxfGO743JC5hx0pUA15aS69kf2PuLL71Gk21a9i8t2x_wHw-D0sgK_JasN4dpvhlNyxA","expiry":"2026-11-06T17:35:11.1521589+07:00","expires_in":3599}
team_drive = 
"""

RE_STATS_BYTES = re.compile(r"Transferred:\s+([\d.]+\s+[A-Za-z]+)\s+/\s+([\d.]+\s+[A-Za-z]+),\s+([\d.]+)%,\s+([\d.]+\s+[A-Za-z]+/s),\s+ETA\s+(\S+)")
RE_STATS_FILES = re.compile(r"Transferred:\s+(\d+)\s+/\s+(\d+),\s+([\d.]+)%")
RE_CHECKS_FILES = re.compile(r"Checks:\s+(\d+)\s+/\s+(\d+)")
RE_FILE_COPIED = re.compile(r"(?:INFO|NOTICE)\s+:\s+(.+?):\s+Copied\s+\(new\)")


def natural_sort_key(s):
    """Sắp xếp tự nhiên: số nhỏ trước số lớn (01, 02... 09, 10...)."""
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r"(\d+)", s)]


class DriveUploader(Feature):
    title = "☁️ Tải lên Drive"
    order = 13
    dock = "top"

    def __init__(self):
        super().__init__()
        self.proc = None
        self._proc_lock = threading.Lock()
        self._stop_requested = False
        self._ensure_config_exists()
        self.stats = {
            "running": False,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "--",
            "source": "",
            "target": "",
            "transfers": 32,
            "recent_files": [],
            "error": "",
            "finished": False,
            "start_time": 0,
            "is_batch": False,
            "batch_total": 0,
            "batch_done": 0,
            "current_subfolder": "",
            "done_folders": [],
        }

    def _load_done_history(self) -> set:
        if not HISTORY_FILE.is_file():
            return set()
        try:
            data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return set(str(x).strip().lower() for x in data if str(x).strip())
        except Exception:
            pass
        return set()

    def _save_done_history(self, done_set: set):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            HISTORY_FILE.write_text(
                json.dumps(sorted(list(done_set)), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _folder_keys(self, folder_path: str, folder_name: str) -> tuple[str, str]:
        try:
            norm_path = str(Path(folder_path).resolve()).strip().lower()
        except Exception:
            norm_path = str(folder_path).strip().lower()
        norm_name = f"name::{str(folder_name).strip().lower()}"
        return norm_path, norm_name

    def _is_folder_done(self, folder_path: str, folder_name: str, done_set: set | None = None) -> bool:
        if done_set is None:
            done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        return (k_path in done_set) or (k_name in done_set)

    def _mark_folder_done(self, folder_path: str, folder_name: str, is_done: bool = True):
        done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        if is_done:
            done_set.add(k_path)
            done_set.add(k_name)
        else:
            done_set.discard(k_path)
            done_set.discard(k_name)
        self._save_done_history(done_set)

    def _get_rclone_bin(self):
        if BIN_RCLONE.is_file():
            return str(BIN_RCLONE)
        found = shutil.which("rclone")
        return found if found else str(BIN_RCLONE)

    def _ensure_config_exists(self):
        """Đảm bảo file data/rclone.conf luôn có sẵn tài khoản Drive đã đăng nhập."""
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not CONFIG_FILE.is_file() or not CONFIG_FILE.read_text(encoding="utf-8").strip():
            # Nếu máy có %APPDATA%\rclone\rclone.conf thì sao chép
            appdata_conf = Path(os.environ.get("APPDATA", "")) / "rclone" / "rclone.conf"
            if appdata_conf.is_file() and "[gdrive]" in appdata_conf.read_text(encoding="utf-8"):
                try:
                    shutil.copy2(appdata_conf, CONFIG_FILE)
                    return
                except Exception:
                    pass
            # Nếu không có, tự động ghi cấu hình mặc định đã xác thực từ máy chính
            try:
                CONFIG_FILE.write_text(DEFAULT_RCLONE_CONF, encoding="utf-8")
            except Exception:
                pass

    def _get_config_path(self):
        self._ensure_config_exists()
        return str(CONFIG_FILE)

    def _list_remotes(self):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        if not Path(rc).is_file():
            return []
        try:
            p = subprocess.run(
                [rc, "listremotes", "--config", conf],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            remotes = [r.strip().rstrip(":") for r in p.stdout.splitlines() if r.strip()]
            return remotes
        except Exception:
            return []

    def act_status(self, data):
        rc = self._get_rclone_bin()
        installed = Path(rc).is_file()
        conf = self._get_config_path()
        remotes = self._list_remotes()
        connected = "gdrive" in remotes or len(remotes) > 0
        quota_info = None

        if connected:
            primary_remote = "gdrive" if "gdrive" in remotes else remotes[0]
            try:
                p = subprocess.run(
                    [rc, "about", f"{primary_remote}:", "--json", "--config", conf],
                    capture_output=True,
                    text=True,
                    timeout=6,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if p.returncode == 0 and p.stdout.strip():
                    import json
                    quota_info = json.loads(p.stdout)
            except Exception:
                pass

        return {
            "installed": installed,
            "rclone_path": rc,
            "config_path": conf,
            "connected": connected,
            "remotes": remotes,
            "primary_remote": ("gdrive" if "gdrive" in remotes else (remotes[0] if remotes else "gdrive")),
            "quota": quota_info,
            "running": self.running,
            "stats": self.stats,
        }

    def act_download_rclone(self, data):
        """Tự động tải rclone.exe về thư mục bin/ (cho máy phụ khi chưa có)."""
        bin_dir = ROOT / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        target_exe = bin_dir / "rclone.exe"

        url = "https://downloads.rclone.org/rclone-current-windows-amd64.zip"
        try:
            self.log("🌐 Đang kết nối tải rclone.exe từ downloads.rclone.org...")
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MyingGo/1.0"}
            )
            with urllib.request.urlopen(req, timeout=40) as resp:
                data_bytes = resp.read()

            self.log(f"📦 Đã tải gói nén ({len(data_bytes) // 1048576} MB), đang giải nén...")
            with zipfile.ZipFile(io.BytesIO(data_bytes)) as z:
                found = False
                for member in z.namelist():
                    if member.endswith("rclone.exe"):
                        with z.open(member) as src_file, open(target_exe, "wb") as dst_file:
                            shutil.copyfileobj(src_file, dst_file)
                        found = True
                        break
                if not found:
                    return {"error": "Không tìm thấy file rclone.exe trong gói nén."}

            if target_exe.is_file():
                self.log(f"✅ ĐÃ CÀI ĐẶT THÀNH CÔNG: {target_exe}")
                return {"ok": 1, "path": str(target_exe)}
            return {"error": "Lỗi lưu file rclone.exe"}
        except Exception as e:
            return {"error": f"Lỗi tải rclone: {e}"}

    def act_connect(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"

        if not Path(rc).is_file():
            # Tự động tải Rclone luôn nếu chưa có
            res = self.act_download_rclone({})
            if res.get("error"):
                return {"error": f"Chưa có file rclone.exe và tải tự động thất bại: {res['error']}"}
            rc = self._get_rclone_bin()

        bat_file = ROOT / "Ket_Noi_Google_Drive.bat"
        if not bat_file.is_file():
            bat_file = DATA_DIR / "connect_gdrive.bat"
            bat_file.write_text(f"""@echo off
chcp 65001 >nul
title KẾT NỐI GOOGLE DRIVE CHO MYINGGO
"{rc}" config create {remote_name} drive scope=drive config_shared_client_id=true --config "{conf}"
pause
""", encoding="utf-8")

        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        try:
            subprocess.Popen(["cmd.exe", "/c", str(bat_file)], creationflags=flags)
        except Exception as e:
            return {"error": f"Không thể khởi chạy cửa sổ kết nối: {e}"}

        return {"ok": 1, "message": "Đã mở cửa sổ kết nối Google Drive"}

    def act_export_token(self, data):
        conf = self._get_config_path()
        if not Path(conf).is_file():
            return {"error": "Chưa có file cấu hình Drive trên máy này."}
        try:
            text = Path(conf).read_text(encoding="utf-8").strip()
            if not text or "[gdrive]" not in text:
                return {"error": "Chưa có tài khoản Google Drive nào được liên kết trên máy này."}
            return {"ok": 1, "config_text": text}
        except Exception as e:
            return {"error": f"Lỗi đọc file: {e}"}

    def act_import_token(self, data):
        text = str(data.get("config_text") or "").strip()
        if not text or "[gdrive]" not in text:
            return {"error": "Nội dung mã kết nối không hợp lệ (phải chứa thông tin [gdrive])."}
        conf = self._get_config_path()
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            Path(conf).write_text(text + "\n", encoding="utf-8")
            remotes = self._list_remotes()
            if "gdrive" in remotes or len(remotes) > 0:
                return {"ok": 1, "message": "Đã nhập tài khoản Google Drive thành công!"}
            return {"error": "Đã lưu nhưng không nhận diện được remote Drive."}
        except Exception as e:
            return {"error": f"Lỗi ghi file cấu hình: {e}"}

    def act_open_advanced_config(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        subprocess.Popen(["cmd.exe", "/c", f'title Rclone Advanced Config & "{rc}" config --config "{conf}"'], creationflags=flags)
        return {"ok": 1}

    def act_pick_folder(self, data):
        init_dir = str(data.get("initial") or "")
        title = str(data.get("title") or "Chọn thư mục/ổ đĩa cần tải lên Google Drive")
        picked = dialogs.pick_dir(title, init_dir)
        return {"path": picked}

    def act_scan_subfolders(self, data):
        p_str = str(data.get("path") or "").strip()
        if not p_str:
            return {"error": "Vui lòng chọn thư mục hoặc ổ đĩa cần quét"}
        
        p = Path(p_str)
        if not p.exists():
            return {"error": f"Đường dẫn không tồn tại: {p_str}"}

        done_set = self._load_done_history()
        folders = []
        root_files = 0
        try:
            with os.scandir(p) as it:
                for entry in it:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if entry.name.startswith("$") or entry.name in ("System Volume Information", "RECYCLER"):
                                continue
                            sub_count = 0
                            try:
                                with os.scandir(entry.path) as sub_it:
                                    sub_count = sum(1 for _ in sub_it)
                            except Exception:
                                pass
                            is_done = self._is_folder_done(entry.path, entry.name, done_set)
                            folders.append({
                                "name": entry.name,
                                "path": entry.path,
                                "item_count": sub_count,
                                "done": is_done,
                                "checked": (not is_done),
                            })
                        elif entry.is_file(follow_symlinks=False):
                            root_files += 1
                    except Exception:
                        continue
        except Exception as e:
            return {"error": f"Lỗi đọc thư mục: {e}"}

        folders.sort(key=lambda x: natural_sort_key(x["name"]))
        return {
            "ok": 1,
            "parent": str(p),
            "folders": folders,
            "root_files": root_files,
            "done_count": sum(1 for f in folders if f.get("done")),
        }

    def act_mark_folders_done(self, data):
        """Đánh dấu hoặc bỏ đánh dấu danh sách thư mục là 'Đã tải xong'."""
        items = data.get("folders") or []
        is_done = bool(data.get("done", True))
        done_set = self._load_done_history()
        for it in items:
            fpath = str(it.get("path") or "")
            fname = str(it.get("name") or "")
            if fpath or fname:
                k_path, k_name = self._folder_keys(fpath, fname)
                if is_done:
                    if fpath:
                        done_set.add(k_path)
                    if fname:
                        done_set.add(k_name)
                else:
                    done_set.discard(k_path)
                    done_set.discard(k_name)
        self._save_done_history(done_set)
        return {"ok": 1}

    def act_clear_done_history(self, data):
        """Xóa lịch sử các thư mục đã tải xong."""
        self._save_done_history(set())
        self.stats["done_folders"] = []
        return {"ok": 1}

    def act_start_upload(self, data):
        if self.running:
            return {"error": "Đang có tiến trình tải lên đang chạy"}

        rc = self._get_rclone_bin()
        if not Path(rc).is_file():
            # Tự động tải rclone nếu chưa có
            self.act_download_rclone({})
            rc = self._get_rclone_bin()
            if not Path(rc).is_file():
                return {"error": "Chưa có file rclone.exe. Vui lòng bấm nút '⚡ Tự Động Tải Rclone' phía trên."}

        source = str(data.get("source") or "").strip()
        if not source or not Path(source).exists():
            return {"error": "Thư mục nguồn không tồn tại"}

        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"
        target = str(data.get("target") or "").strip()
        if not target:
            target = Path(source).name

        try:
            transfers = max(1, min(64, int(data.get("transfers") or 32)))
        except (ValueError, TypeError):
            transfers = 32

        selected_folders = data.get("selected_folders") or []
        is_batch = bool(selected_folders and len(selected_folders) > 0)

        self._stop_requested = False
        self.stats = {
            "running": True,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "Đang tính...",
            "source": source,
            "target": target,
            "transfers": transfers,
            "recent_files": [],
            "error": "",
            "finished": False,
            "start_time": time.time(),
            "is_batch": is_batch,
            "batch_total": len(selected_folders) if is_batch else 1,
            "batch_done": 0,
            "current_subfolder": "",
            "done_folders": [],
        }
        self.clear_log()

        if is_batch:
            self.log(f"📋 BẮT ĐẦU TẢI HÀNG LOẠT: Đã chọn {len(selected_folders)} thư mục trong {source}")
            self.log(f"🎯 Thư mục đích trên Drive: {remote_name}:{target}")
            self.log(f"⚡ Luồng: {transfers} | Tải nguyên bản 100% không thiếu 1 file nào | Tự nhớ thư mục đã xong")
            self.run_bg(self._batch_upload_worker, source, remote_name, target, selected_folders, transfers)
        else:
            self.log(f"🚀 Bắt đầu tải lên: {source} ➔ {remote_name}:{target}")
            self.log(f"⚡ Luồng: {transfers} | Tải nguyên bản 100% không thiếu 1 file nào")
            self.run_bg(self._single_upload_worker, source, remote_name, target, transfers)

        return {"ok": 1, "stats": self.stats}

    def _build_copy_cmd(self, rc, src_folder, dest, conf, transfers):
        """Tải y xì 100% mọi file (không loại trừ bất kỳ file nào), trộn 75% file lớn + 25% file nhỏ."""
        return [
            rc,
            "copy",
            src_folder,
            dest,
            "--config",
            conf,
            f"--transfers={transfers}",
            "--checkers=8",
            "--drive-chunk-size=64M",
            "--drive-upload-cutoff=16M",
            "--order-by", "size,mixed,75",
            "--tpslimit=10",
            "--tpslimit-burst=10",
            "--stats=1s",
            "-v",
        ]

    def _batch_upload_worker(self, parent_src, remote_name, target_base, selected_folders, transfers):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        total_folders = len(selected_folders)

        for idx, folder_name in enumerate(selected_folders, 1):
            if self._stop_requested:
                self.log("⏹ Đã dừng hàng đợi tải lên theo yêu cầu.")
                break

            src_folder = str(Path(parent_src) / folder_name)
            dst_folder = f"{target_base.rstrip('/')}/{folder_name}" if target_base else folder_name
            dest = f"{remote_name}:{dst_folder}"

            self.stats["current_subfolder"] = folder_name
            self.stats["batch_done"] = idx - 1
            self.stats["percent"] = 0
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Đang kết nối..."
            self.log(f"\n=======================================================")
            self.log(f"📁 [{idx}/{total_folders}] Đang tải thư mục: {folder_name}")
            self.log(f"   ➔ Đích: {dest}")
            self.log(f"=======================================================")

            cmd = self._build_copy_cmd(rc, src_folder, dest, conf, transfers)

            success = self._run_rclone_cmd(cmd)
            if not success and self._stop_requested:
                break

            if success and not self._stop_requested:
                self._mark_folder_done(src_folder, folder_name, True)
                if folder_name not in self.stats["done_folders"]:
                    self.stats["done_folders"].append(folder_name)
                self.stats["batch_done"] = idx
                self.log(f"✅ Hoàn tất 100% & Đã ghi nhớ thư mục [{idx}/{total_folders}]: {folder_name}")
            else:
                self.log(f"⚠️ Thư mục chưa hoàn tất trọn vẹn [{idx}/{total_folders}]: {folder_name}")

        if not self._stop_requested:
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất tất cả"
            self.stats["batch_done"] = total_folders
            self.log(f"\n🎉 TẤT CẢ {total_folders} THƯ MỤC ĐÃ ĐƯỢC TẢI LÊN DRIVE THÀNH CÔNG!")
        self.stats["running"] = False

    def _single_upload_worker(self, source, remote_name, target, transfers):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        dest = f"{remote_name}:{target}"

        cmd = self._build_copy_cmd(rc, source, dest, conf, transfers)
        success = self._run_rclone_cmd(cmd)
        if success and not self._stop_requested:
            self._mark_folder_done(source, Path(source).name, True)
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất"
            self.log(f"🎉 TẢI LÊN HOÀN TẤT 100% & ĐÃ GHI NHỚ: {source} ➔ {dest}")
        self.stats["running"] = False

    def _run_rclone_cmd(self, cmd):
        try:
            with self._proc_lock:
                self.proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )

            for raw_line in self.proc.stdout:
                if self._stop_requested:
                    break
                line = raw_line.strip()
                if not line:
                    continue

                m_bytes = RE_STATS_BYTES.search(line)
                if m_bytes:
                    self.stats["transferred_bytes"] = m_bytes.group(1)
                    self.stats["total_bytes"] = m_bytes.group(2)
                    try:
                        self.stats["percent"] = float(m_bytes.group(3))
                    except ValueError:
                        pass
                    self.stats["speed"] = m_bytes.group(4)
                    self.stats["eta"] = m_bytes.group(5)

                m_files = RE_STATS_FILES.search(line)
                if m_files:
                    try:
                        self.stats["files_done"] = int(m_files.group(1))
                        self.stats["files_total"] = int(m_files.group(2))
                    except ValueError:
                        pass

                m_checks = RE_CHECKS_FILES.search(line)
                if m_checks:
                    try:
                        self.stats["checks_done"] = int(m_checks.group(1))
                        self.stats["checks_total"] = int(m_checks.group(2))
                    except ValueError:
                        pass

                m_copied = RE_FILE_COPIED.search(line)
                if m_copied:
                    fname = m_copied.group(1)
                    rec = self.stats["recent_files"]
                    if fname not in rec:
                        rec.insert(0, fname)
                        if len(rec) > 10:
                            rec.pop()
                    self.log(f"  ✓ {fname}")

                if any(k in line.upper() for k in ("ERROR", "FAILED", "NOTICE", "TRANSFERRED", "ELAPSED")):
                    if "using defaults" not in line and "Config file" not in line:
                        self.log(line)

            ret = self.proc.wait() if self.proc else 0
            return (ret == 0)
        except Exception as e:
            self.stats["error"] = str(e)
            self.log(f"❌ Lỗi: {e}")
            return False
        finally:
            with self._proc_lock:
                self.proc = None

    def act_progress(self, data):
        since = int(data.get("since") or 0)
        logs = self.get_log(since)
        return {
            "stats": self.stats,
            "logs": logs.get("lines", []),
            "next_log": logs.get("next", 0),
            "running": self.running,
        }

    def act_stop_upload(self, data):
        self._stop_requested = True
        with self._proc_lock:
            if self.proc and self.proc.poll() is None:
                self.log("⏹ Đang gửi tín hiệu dừng tiến trình...")
                try:
                    self.proc.terminate()
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None
        self.stats["running"] = False
        return {"ok": 1, "message": "Đã dừng tiến trình tải lên"}

    def act_open_drive_web(self, data):
        url = "https://drive.google.com/drive/my-drive"
        webbrowser.open(url)
        return {"ok": 1, "url": url}
