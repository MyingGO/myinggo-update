"""Tính năng: Tải lên Google Drive siêu tốc (Rclone đa luồng).

Hỗ trợ:
- Tải từng file lẻ nguyên bản (không nén ZIP) lên Google Drive.
- Quét danh sách toàn bộ thư mục trong ổ đĩa/thư mục cha.
- Checkbox chọn lọc: Dễ dàng trừ/bỏ chọn những thư mục không muốn tải lên.
- Đa luồng 16 luồng song song, auto-resume, bỏ qua file cũ.
"""
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

from core import dialogs, logger
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
BIN_RCLONE = ROOT / "bin" / "rclone.exe"
DATA_DIR = ROOT / "data"
CONFIG_FILE = DATA_DIR / "rclone.conf"

RE_STATS_BYTES = re.compile(r"Transferred:\s+([\d.]+\s+[A-Za-z]+)\s+/\s+([\d.]+\s+[A-Za-z]+),\s+([\d.]+)%,\s+([\d.]+\s+[A-Za-z]+/s),\s+ETA\s+(\S+)")
RE_STATS_FILES = re.compile(r"Transferred:\s+(\d+)\s+/\s+(\d+),\s+([\d.]+)%")
RE_CHECKS_FILES = re.compile(r"Checks:\s+(\d+)\s+/\s+(\d+)")
RE_FILE_COPIED = re.compile(r"(?:INFO|NOTICE)\s+:\s+(.+?):\s+Copied\s+\(new\)")


def natural_sort_key(s):
    """Sắp xếp tự nhiên: số nhỏ trước số lớn (01, 02... 09, 10...)."""
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r"(\d+)", s)]


class DriveUploader(Feature):
    title = "☁️ Tải lên Drive"
    order = 13
    dock = "top"

    def __init__(self):
        super().__init__()
        self.proc = None
        self._proc_lock = threading.Lock()
        self._stop_requested = False
        self.stats = {
            "running": False,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "--",
            "source": "",
            "target": "",
            "transfers": 16,
            "recent_files": [],
            "error": "",
            "finished": False,
            "start_time": 0,
            "is_batch": False,
            "batch_total": 0,
            "batch_done": 0,
            "current_subfolder": "",
        }

    def _get_rclone_bin(self):
        if BIN_RCLONE.is_file():
            return str(BIN_RCLONE)
        found = shutil.which("rclone")
        return found if found else str(BIN_RCLONE)

    def _get_config_path(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not CONFIG_FILE.exists():
            appdata_conf = Path(os.environ.get("APPDATA", "")) / "rclone" / "rclone.conf"
            if appdata_conf.is_file():
                return str(appdata_conf)
        return str(CONFIG_FILE)

    def _list_remotes(self):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        if not Path(rc).is_file():
            return []
        try:
            p = subprocess.run(
                [rc, "listremotes", "--config", conf],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            remotes = [r.strip().rstrip(":") for r in p.stdout.splitlines() if r.strip()]
            return remotes
        except Exception:
            return []

    def act_status(self, data):
        rc = self._get_rclone_bin()
        installed = Path(rc).is_file()
        conf = self._get_config_path()
        remotes = self._list_remotes()
        connected = "gdrive" in remotes or len(remotes) > 0
        quota_info = None

        if connected:
            primary_remote = "gdrive" if "gdrive" in remotes else remotes[0]
            try:
                p = subprocess.run(
                    [rc, "about", f"{primary_remote}:", "--json", "--config", conf],
                    capture_output=True,
                    text=True,
                    timeout=6,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if p.returncode == 0 and p.stdout.strip():
                    import json
                    quota_info = json.loads(p.stdout)
            except Exception:
                pass

        return {
            "installed": installed,
            "rclone_path": rc,
            "config_path": conf,
            "connected": connected,
            "remotes": remotes,
            "primary_remote": ("gdrive" if "gdrive" in remotes else (remotes[0] if remotes else "gdrive")),
            "quota": quota_info,
            "running": self.running,
            "stats": self.stats,
        }

    def act_connect(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"

        if not Path(rc).is_file():
            return {"error": "Không tìm thấy file rclone.exe"}

        bat_file = DATA_DIR / "connect_gdrive.bat"
        bat_content = f"""@echo off
chcp 65001 >nul
title KẾT NỐI GOOGLE DRIVE CHO MYINGGO
echo =====================================================================
echo           KẾT NỐI GOOGLE DRIVE (RCLONE SIÊU TỐC)
echo =====================================================================
echo.
echo [1/2] Đang mở trình duyệt web...
echo       Vui lòng chọn tài khoản Google Drive và bấm "Cho phép (Allow)".
echo.
"{rc}" config create {remote_name} drive scope=drive config_shared_client_id=true --config "{conf}"
echo.
if %errorlevel% equ 0 (
    echo =====================================================================
    echo  [2/2] KẾT NỐI THÀNH CÔNG!
    echo  Tài khoản Google Drive "{remote_name}:" đã sẵn sàng trong MyingGo.
    echo =====================================================================
) else (
    echo [LỖI] Chưa hoàn tất xác thực hoặc bạn đã đóng trình duyệt.
)
echo.
echo Bấm phím bất kỳ để đóng cửa sổ này...
pause >nul
"""
        bat_file.write_text(bat_content, encoding="utf-8")
        subprocess.Popen(["cmd.exe", "/c", str(bat_file)])
        return {"ok": 1, "message": "Đã mở cửa sổ kết nối Google Drive"}

    def act_open_advanced_config(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        subprocess.Popen(["cmd.exe", "/c", f'title Rclone Advanced Config & "{rc}" config --config "{conf}"'])
        return {"ok": 1}

    def act_pick_folder(self, data):
        init_dir = str(data.get("initial") or "")
        title = str(data.get("title") or "Chọn thư mục/ổ đĩa cần tải lên Google Drive")
        picked = dialogs.pick_dir(title, init_dir)
        return {"path": picked}

    def act_scan_subfolders(self, data):
        p_str = str(data.get("path") or "").strip()
        if not p_str:
            return {"error": "Vui lòng chọn thư mục hoặc ổ đĩa cần quét"}
        
        p = Path(p_str)
        if not p.exists():
            return {"error": f"Đường dẫn không tồn tại: {p_str}"}

        folders = []
        root_files = 0
        try:
            with os.scandir(p) as it:
                for entry in it:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if entry.name.startswith("$") or entry.name in ("System Volume Information", "RECYCLER"):
                                continue
                            sub_count = 0
                            try:
                                with os.scandir(entry.path) as sub_it:
                                    sub_count = sum(1 for _ in sub_it)
                            except Exception:
                                pass
                            folders.append({
                                "name": entry.name,
                                "path": entry.path,
                                "item_count": sub_count,
                                "checked": True,
                            })
                        elif entry.is_file(follow_symlinks=False):
                            root_files += 1
                    except Exception:
                        continue
        except Exception as e:
            return {"error": f"Lỗi đọc thư mục: {e}"}

        folders.sort(key=lambda x: natural_sort_key(x["name"]))
        return {
            "ok": 1,
            "parent": str(p),
            "folders": folders,
            "root_files": root_files,
        }

    def act_start_upload(self, data):
        if self.running:
            return {"error": "Đang có tiến trình tải lên đang chạy"}

        source = str(data.get("source") or "").strip()
        if not source or not Path(source).exists():
            return {"error": "Thư mục nguồn không tồn tại"}

        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"
        target = str(data.get("target") or "").strip()
        if not target:
            target = Path(source).name

        try:
            transfers = max(1, min(64, int(data.get("transfers") or 16)))
        except (ValueError, TypeError):
            transfers = 16

        selected_folders = data.get("selected_folders") or []
        is_batch = bool(selected_folders and len(selected_folders) > 0)

        self._stop_requested = False
        self.stats = {
            "running": True,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "Đang tính...",
            "source": source,
            "target": target,
            "transfers": transfers,
            "recent_files": [],
            "error": "",
            "finished": False,
            "start_time": time.time(),
            "is_batch": is_batch,
            "batch_total": len(selected_folders) if is_batch else 1,
            "batch_done": 0,
            "current_subfolder": "",
        }
        self.clear_log()

        if is_batch:
            self.log(f"📋 BẮT ĐẦU TẢI HÀNG LOẠT: Đã chọn {len(selected_folders)} thư mục trong {source}")
            self.log(f"🎯 Thư mục đích trên Drive: {remote_name}:{target}")
            self.log(f"⚡ Luồng song song: {transfers} • Auto-resume: ON")
            self.run_bg(self._batch_upload_worker, source, remote_name, target, selected_folders, transfers)
        else:
            self.log(f"🚀 Bắt đầu tải lên: {source} ➔ {remote_name}:{target}")
            self.log(f"⚡ Luồng song song: {transfers} • Auto-resume: ON")
            self.run_bg(self._single_upload_worker, source, remote_name, target, transfers)

        return {"ok": 1, "stats": self.stats}

    def _batch_upload_worker(self, parent_src, remote_name, target_base, selected_folders, transfers):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        total_folders = len(selected_folders)

        for idx, folder_name in enumerate(selected_folders, 1):
            if self._stop_requested:
                self.log("⏹ Đã dừng hàng đợi tải lên theo yêu cầu.")
                break

            src_folder = str(Path(parent_src) / folder_name)
            dst_folder = f"{target_base.rstrip('/')}/{folder_name}" if target_base else folder_name
            dest = f"{remote_name}:{dst_folder}"

            self.stats["current_subfolder"] = folder_name
            self.stats["batch_done"] = idx - 1
            self.stats["percent"] = 0
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Đang kết nối..."
            self.log(f"\n=======================================================")
            self.log(f"📁 [{idx}/{total_folders}] Đang tải thư mục: {folder_name}")
            self.log(f"   ➔ Đích: {dest}")
            self.log(f"=======================================================")

            cmd = [
                rc,
                "copy",
                src_folder,
                dest,
                "--config",
                conf,
                f"--transfers={transfers}",
                "--checkers=16",
                "--drive-chunk-size=64M",
                "--stats=1s",
                "-v",
            ]

            success = self._run_rclone_cmd(cmd)
            if not success and self._stop_requested:
                break
            
            self.stats["batch_done"] = idx
            self.log(f"✅ Hoàn tất thư mục [{idx}/{total_folders}]: {folder_name}")

        if not self._stop_requested:
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất tất cả"
            self.stats["batch_done"] = total_folders
            self.log(f"\n🎉 TẤT CẢ {total_folders} THƯ MỤC ĐÃ ĐƯỢC TẢI LÊN DRIVE THÀNH CÔNG!")
        self.stats["running"] = False

    def _single_upload_worker(self, source, remote_name, target, transfers):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        dest = f"{remote_name}:{target}"

        cmd = [
            rc,
            "copy",
            source,
            dest,
            "--config",
            conf,
            f"--transfers={transfers}",
            "--checkers=16",
            "--drive-chunk-size=64M",
            "--stats=1s",
            "-v",
        ]
        success = self._run_rclone_cmd(cmd)
        if success and not self._stop_requested:
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất"
            self.log(f"🎉 TẢI LÊN HOÀN TẤT THÀNH CÔNG: {source} ➔ {dest}")
        self.stats["running"] = False

    def _run_rclone_cmd(self, cmd):
        try:
            with self._proc_lock:
                self.proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )

            for raw_line in self.proc.stdout:
                if self._stop_requested:
                    break
                line = raw_line.strip()
                if not line:
                    continue

                m_bytes = RE_STATS_BYTES.search(line)
                if m_bytes:
                    self.stats["transferred_bytes"] = m_bytes.group(1)
                    self.stats["total_bytes"] = m_bytes.group(2)
                    try:
                        self.stats["percent"] = float(m_bytes.group(3))
                    except ValueError:
                        pass
                    self.stats["speed"] = m_bytes.group(4)
                    self.stats["eta"] = m_bytes.group(5)

                m_files = RE_STATS_FILES.search(line)
                if m_files:
                    try:
                        self.stats["files_done"] = int(m_files.group(1))
                        self.stats["files_total"] = int(m_files.group(2))
                    except ValueError:
                        pass

                m_checks = RE_CHECKS_FILES.search(line)
                if m_checks:
                    try:
                        self.stats["checks_done"] = int(m_checks.group(1))
                        self.stats["checks_total"] = int(m_checks.group(2))
                    except ValueError:
                        pass

                m_copied = RE_FILE_COPIED.search(line)
                if m_copied:
                    fname = m_copied.group(1)
                    rec = self.stats["recent_files"]
                    if fname not in rec:
                        rec.insert(0, fname)
                        if len(rec) > 10:
                            rec.pop()
                    self.log(f"  ✓ {fname}")

                if any(k in line.upper() for k in ("ERROR", "FAILED", "NOTICE", "TRANSFERRED", "ELAPSED")):
                    if "using defaults" not in line and "Config file" not in line:
                        self.log(line)

            ret = self.proc.wait() if self.proc else 0
            return (ret == 0)
        except Exception as e:
            self.stats["error"] = str(e)
            self.log(f"❌ Lỗi: {e}")
            return False
        finally:
            with self._proc_lock:
                self.proc = None

    def act_progress(self, data):
        since = int(data.get("since") or 0)
        logs = self.get_log(since)
        return {
            "stats": self.stats,
            "logs": logs.get("lines", []),
            "next_log": logs.get("next", 0),
            "running": self.running,
        }

    def act_stop_upload(self, data):
        self._stop_requested = True
        with self._proc_lock:
            if self.proc and self.proc.poll() is None:
                self.log("⏹ Đang gửi tín hiệu dừng tiến trình...")
                try:
                    self.proc.terminate()
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None
        self.stats["running"] = False
        return {"ok": 1, "message": "Đã dừng tiến trình tải lên"}

    def act_open_drive_web(self, data):
        url = "https://drive.google.com/drive/my-drive"
        webbrowser.open(url)
        return {"ok": 1, "url": url}
