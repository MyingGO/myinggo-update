"""Tính năng: Tải lên Google Drive Chuẩn & Tốc Độ Cao (Rclone API & Copy Ổ đĩa Google Drive Desktop).

Hỗ trợ:
- Hiển thị rõ ràng Tên & Email của tài khoản Google Drive đang kết nối trên giao diện.
- Lưu danh sách các tài khoản Google Drive đã đăng nhập và cho phép bấm đổi nhanh tài khoản trong 1 giây.
- Chế độ 1 (Copy trực tiếp vào Ổ đĩa Google Drive Desktop): Có ô điền & nút chọn đường dẫn đích bất kỳ, hỗ trợ chọn "Chuyển từng file 1" hoặc "Chuyển toàn bộ file cùng lúc".
- Chế độ 2 (Rclone Trực tiếp): Hỗ trợ "Chuyển từng file 1 (1 luồng)" hoặc "Chuyển toàn bộ cùng lúc (Đa luồng)".
- Tải nguyên vẹn 100% mọi file trong thư mục, không bỏ sót bất kỳ định dạng nào.
- Tự động ghi nhớ các thư mục (FD) đã tải xong vào data/drive_uploaded_history.json và bỏ chọn ở lần sau.
"""
import concurrent.futures
import configparser
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
import urllib.error
import urllib.request
import webbrowser
import zipfile
from pathlib import Path

from core import dialogs, logger
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
BIN_RCLONE = ROOT / "bin" / "rclone.exe"
DATA_DIR = ROOT / "data"
CONFIG_FILE = DATA_DIR / "rclone.conf"
HISTORY_FILE = DATA_DIR / "drive_uploaded_history.json"
CLIENT_CRED_FILE = DATA_DIR / "drive_client_credentials.json"
ACCOUNTS_FILE = DATA_DIR / "drive_saved_accounts.json"

DEFAULT_RCLONE_CONF = """[gdrive]
type = drive
scope = drive
token = {"access_token":"ya29.a0AehfTOkQGay8lmS0sN2MG3-ktM9VokV78lih2zNNYvb2ErUiL8AihOpdEzqi5kt5S16MTjdTDGq1EJlz_nCjQoNlMHf-4wUUbgfikOQCV5iXc8-kyidlaRfjnbY9ARj77oCH9J5joJhB7f42T7Il8ktiyaDtSQuutoAMbdSluPkct8QUvmZ_JZT7CSdqx_GbZ1qeBOMaCgYKASwSARASFQHGX2Mi9xU7bQOBFmg1ixBrw9SYoQ0206","token_type":"Bearer","refresh_token":"1//0ePxnH-qqKrkhCgYIARAAGA4SNwF-L9IrxfGO743JC5hx0pUA15aS69kf2PuLL71Gk21a9i8t2x_wHw-D0sgK_JasN4dpvhlNyxA","expiry":"2026-11-06T17:35:11.1521589+07:00","expires_in":3599}
team_drive = 
"""

RE_STATS_BYTES = re.compile(
    r"Transferred:\s+([\d.]+\s+[A-Za-z]+)\s+/\s+([\d.]+\s+[A-Za-z]+),\s+([\d.]+)%,\s+([\d.]+\s+[A-Za-z]+/s),\s+ETA\s+(\S+)"
)
RE_STATS_FILES = re.compile(r"Transferred:\s+(\d+)\s+/\s+(\d+),\s+([\d.]+)%")
RE_CHECKS_FILES = re.compile(r"Checks:\s+(\d+)\s+/\s+(\d+)")
RE_FILE_COPIED = re.compile(
    r"(?:INFO|NOTICE)\s+:\s+(.+?):\s+Copied\s+\((?:new|replaced existing)\)"
)

IGNORED_FOLDER_NAMES = {
    "system volume information",
    "recycler",
    "$recycle.bin",
    "myinggo_trash_logs",
    "file rác myinggo",
    ".shortcut-targets-by-id",
    ".encrypted",
    ".tmp.drivedownload",
    ".tmp.driveupload",
}


def natural_sort_key(s):
    """Sắp xếp tự nhiên: số nhỏ trước số lớn (01, 02... 09, 10...)."""
    return [
        int(text) if text.isdigit() else text.lower()
        for text in re.split(r"(\d+)", s)
    ]


def _is_system_or_gdfs_cache_folder(name: str) -> bool:
    """Kiểm tra thư mục hệ thống hoặc thư mục cache 21 chữ số của Google Drive Desktop."""
    n = name.strip()
    if not n or n.startswith("$") or n.startswith("."):
        return True
    if n.lower() in IGNORED_FOLDER_NAMES:
        return True
    if n.isdigit() and len(n) >= 18:
        return True
    return False


def _fmt_bytes(num_bytes: float) -> str:
    if num_bytes <= 0:
        return "0 B"
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    idx = 0
    val = float(num_bytes)
    while val >= 1024.0 and idx < len(units) - 1:
        val /= 1024.0
        idx += 1
    return f"{val:.2f} {units[idx]}" if idx >= 2 else f"{val:.0f} {units[idx]}"


class DriveUploader(Feature):
    title = "☁️ Tải lên Drive"
    order = 13
    dock = "top"

    def __init__(self):
        super().__init__()
        self.proc = None
        self._proc_lock = threading.Lock()
        self._stop_requested = False
        self._ensure_config_exists()
        self.stats = {
            "running": False,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "--",
            "source": "",
            "target": "",
            "transfers": 1,
            "engine_mode": "gdfs",
            "transfer_style": "sequential",
            "recent_files": [],
            "error": "",
            "warning": "",
            "finished": False,
            "start_time": 0,
            "is_batch": False,
            "batch_total": 0,
            "batch_done": 0,
            "current_subfolder": "",
            "done_folders": [],
        }

    # ── Lịch sử thư mục đã tải xong ──────────────────────────────────────
    def _load_done_history(self) -> set:
        if not HISTORY_FILE.is_file():
            return set()
        try:
            data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return set(str(x).strip().lower() for x in data if str(x).strip())
        except Exception:
            pass
        return set()

    def _save_done_history(self, done_set: set):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            HISTORY_FILE.write_text(
                json.dumps(sorted(list(done_set)), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _folder_keys(self, folder_path: str, folder_name: str) -> tuple[str, str]:
        try:
            norm_path = str(Path(folder_path).resolve()).strip().lower()
        except Exception:
            norm_path = str(folder_path).strip().lower()
        norm_name = f"name::{str(folder_name).strip().lower()}"
        return norm_path, norm_name

    def _is_folder_done(
        self, folder_path: str, folder_name: str, done_set: set | None = None
    ) -> bool:
        if done_set is None:
            done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        return (k_path in done_set) or (k_name in done_set)

    def _mark_folder_done(
        self, folder_path: str, folder_name: str, is_done: bool = True
    ):
        done_set = self._load_done_history()
        k_path, k_name = self._folder_keys(folder_path, folder_name)
        if is_done:
            done_set.add(k_path)
            done_set.add(k_name)
        else:
            done_set.discard(k_path)
            done_set.discard(k_name)
        self._save_done_history(done_set)

    # ── Quản lý Rclone, Cấu hình & Nhận diện Email Tài Khoản ──────────────
    def _get_rclone_bin(self):
        if BIN_RCLONE.is_file():
            return str(BIN_RCLONE)
        found = shutil.which("rclone")
        return found if found else str(BIN_RCLONE)

    def _ensure_config_exists(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not CONFIG_FILE.is_file() or not CONFIG_FILE.read_text(encoding="utf-8").strip():
            appdata_conf = Path(os.environ.get("APPDATA", "")) / "rclone" / "rclone.conf"
            if appdata_conf.is_file() and "[gdrive]" in appdata_conf.read_text(encoding="utf-8"):
                try:
                    shutil.copy2(appdata_conf, CONFIG_FILE)
                    return
                except Exception:
                    pass
            try:
                CONFIG_FILE.write_text(DEFAULT_RCLONE_CONF, encoding="utf-8")
            except Exception:
                pass

    def _get_config_path(self):
        self._ensure_config_exists()
        return str(CONFIG_FILE)

    def _load_saved_accounts(self) -> dict:
        if ACCOUNTS_FILE.is_file():
            try:
                data = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
            except Exception:
                pass
        return {}

    def _save_saved_accounts(self, acc_map: dict):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            ACCOUNTS_FILE.write_text(
                json.dumps(acc_map, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _extract_token_from_conf(self, conf_path: str, remote_name: str = "gdrive") -> tuple[dict | None, str]:
        """Đọc JSON token và toàn bộ nội dung từ rclone.conf."""
        p = Path(conf_path)
        if not p.is_file():
            return None, ""
        try:
            raw_text = p.read_text(encoding="utf-8")
            cfg = configparser.RawConfigParser()
            cfg.read_string(raw_text)
            sec = remote_name if cfg.has_section(remote_name) else (cfg.sections()[0] if cfg.sections() else "")
            if sec and cfg.has_option(sec, "token"):
                tok_str = cfg.get(sec, "token").strip()
                return json.loads(tok_str), raw_text
        except Exception:
            pass
        return None, ""

    def _query_google_about_api(self, access_token: str) -> dict | None:
        """Gọi trực tiếp Google Drive v3 about API để lấy Tên, Email và Dung lượng của tài khoản."""
        if not access_token:
            return None
        url = "https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress),storageQuota(limit,usage)"
        for attempt in range(4):
            try:
                req = urllib.request.Request(
                    url,
                    headers={"Authorization": f"Bearer {access_token}"},
                )
                with urllib.request.urlopen(req, timeout=5) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                if e.code == 401:
                    # Token hết hạn -> cần để rclone làm mới
                    return {"_expired": True}
                if e.code in (403, 429) and attempt < 3:
                    time.sleep(0.45 * (attempt + 1))
                    continue
                break
            except Exception:
                break
        return None

    def _resolve_account_identity(self, rc: str, conf: str, primary_remote: str) -> tuple[dict, dict | None, list[dict]]:
        """Trả về (account_info, quota_info, saved_accounts_list)."""
        tok, raw_conf_text = self._extract_token_from_conf(conf, primary_remote)
        acc_map = self._load_saved_accounts()
        account_info = {"email": "", "name": "", "key": ""}
        quota_info = None

        if not tok:
            return account_info, None, list(acc_map.values())

        refresh_tok = str(tok.get("refresh_token") or "")
        acc_key = refresh_tok[-28:] if len(refresh_tok) >= 28 else (refresh_tok or "default")
        account_info["key"] = acc_key

        # Lấy từ bộ nhớ đệm nếu đã từng nhận diện email của tài khoản này
        cached = acc_map.get(acc_key, {})
        now_ts = time.time()
        last_ts = float(cached.get("ts") or 0)
        if cached.get("email"):
            account_info["email"] = cached["email"]
            account_info["name"] = cached.get("name") or ""
            quota_info = cached.get("quota")

        # Chỉ gọi Google API khi tài khoản mới chưa có email hoặc đã quá 5 phút
        about_data = None
        if not account_info["email"] or "@" not in account_info["email"] or (now_ts - last_ts > 300):
            access_tok = str(tok.get("access_token") or "")
            about_data = self._query_google_about_api(access_tok)

            # Nếu access_token đã hết hạn (401), dùng rclone about để tự động refresh token rồi đọc lại
            if (about_data and about_data.get("_expired")) or (about_data is None and not account_info["email"]):
                try:
                    p = subprocess.run(
                        [rc, "about", f"{primary_remote}:", "--json", "--config", conf],
                        capture_output=True,
                        text=True,
                        timeout=7,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    )
                    if p.returncode == 0 and p.stdout.strip():
                        quota_info = json.loads(p.stdout)
                    tok_new, raw_conf_text = self._extract_token_from_conf(conf, primary_remote)
                    if tok_new and tok_new.get("access_token"):
                        about_data = self._query_google_about_api(str(tok_new["access_token"]))
                except Exception:
                    pass

        if about_data and "user" in about_data:
            u = about_data.get("user") or {}
            email = str(u.get("emailAddress") or "").strip()
            name = str(u.get("displayName") or "").strip()
            if email:
                account_info["email"] = email
                account_info["name"] = name
            sq = about_data.get("storageQuota") or {}
            if sq.get("limit"):
                limit_b = int(sq.get("limit", 0))
                used_b = int(sq.get("usage", 0))
                quota_info = {
                    "total": limit_b,
                    "used": used_b,
                    "free": max(0, limit_b - used_b),
                }

        # Lưu vào danh sách tài khoản đã kết nối để hiển thị & chuyển đổi nhanh
        if raw_conf_text:
            label_email = account_info["email"] or cached.get("email") or f"Tài khoản ({acc_key[-6:]})"
            label_name = account_info["name"] or cached.get("name") or ""
            acc_map[acc_key] = {
                "key": acc_key,
                "email": label_email,
                "name": label_name,
                "conf_text": raw_conf_text,
                "quota": quota_info,
                "ts": now_ts if about_data else (last_ts or now_ts),
                "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
            self._save_saved_accounts(acc_map)
            account_info["email"] = label_email
            account_info["name"] = label_name

        saved_list = [
            {
                "key": v["key"],
                "email": v.get("email") or "",
                "name": v.get("name") or "",
                "active": (v["key"] == acc_key),
            }
            for v in acc_map.values()
        ]
        return account_info, quota_info, saved_list

    def _detect_gdfs_mounts(self) -> list[str]:
        """Tự động phát hiện ổ đĩa Google Drive for Desktop (VD: G:\\My Drive, E:\\My Drive)."""
        mounts = []
        for drv in "DEFGHIJKLMNOPQRSTUVWXYZ":
            for sub in ("My Drive", "Google Drive", "Drive của tôi"):
                cand = Path(f"{drv}:\\{sub}")
                try:
                    if cand.exists() and cand.is_dir():
                        mounts.append(str(cand))
                except Exception:
                    pass
        return mounts

    def _has_custom_client_id(self) -> bool:
        try:
            conf_text = Path(self._get_config_path()).read_text(encoding="utf-8")
            for line in conf_text.splitlines():
                if line.strip().startswith("client_id") and "=" in line:
                    val = line.split("=", 1)[1].strip()
                    if val and "202264815644" not in val:
                        return True
        except Exception:
            pass
        return False

    def _list_remotes(self):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        if not Path(rc).is_file():
            return []
        try:
            p = subprocess.run(
                [rc, "listremotes", "--config", conf],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            remotes = [
                r.strip().rstrip(":") for r in p.stdout.splitlines() if r.strip()
            ]
            return remotes
        except Exception:
            return []

    def act_status(self, data):
        rc = self._get_rclone_bin()
        installed = Path(rc).is_file()
        conf = self._get_config_path()
        remotes = self._list_remotes()
        connected = "gdrive" in remotes or len(remotes) > 0
        quota_info = None
        account_info = {"email": "", "name": "", "key": ""}
        saved_accounts = []
        gdfs_mounts = self._detect_gdfs_mounts()
        has_custom_client = self._has_custom_client_id()

        primary_remote = (
            "gdrive"
            if "gdrive" in remotes
            else (remotes[0] if remotes else "gdrive")
        )

        if connected:
            account_info, quota_info, saved_accounts = self._resolve_account_identity(
                rc, conf, primary_remote
            )

        default_gdfs_path = ""
        if gdfs_mounts:
            default_gdfs_path = str(Path(gdfs_mounts[0]) / "0 - FD ID ADD ÂM")

        return {
            "installed": installed,
            "rclone_path": rc,
            "config_path": conf,
            "connected": connected,
            "remotes": remotes,
            "primary_remote": primary_remote,
            "account": account_info,
            "saved_accounts": saved_accounts,
            "quota": quota_info,
            "gdfs_mounts": gdfs_mounts,
            "default_gdfs_path": default_gdfs_path,
            "has_custom_client": has_custom_client,
            "running": self.running,
            "stats": self.stats,
        }

    def act_switch_saved_account(self, data):
        """Chuyển nhanh giữa các tài khoản Google Drive đã lưu chỉ bằng 1 cú nhấp chuột."""
        key = str(data.get("key") or "").strip()
        acc_map = self._load_saved_accounts()
        if not key or key not in acc_map:
            return {"error": "Không tìm thấy thông tin tài khoản đã lưu này."}
        conf_text = str(acc_map[key].get("conf_text") or "").strip()
        if not conf_text:
            return {"error": "Dữ liệu cấu hình của tài khoản này bị trống."}
        try:
            Path(self._get_config_path()).write_text(conf_text + "\n", encoding="utf-8")
            email = acc_map[key].get("email") or key
            self.log(f"🔄 Đã chuyển sang tài khoản Google Drive: {email}")
            return {"ok": 1, "email": email}
        except Exception as e:
            return {"error": f"Lỗi khi chuyển tài khoản: {e}"}

    def act_download_rclone(self, data):
        bin_dir = ROOT / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        target_exe = bin_dir / "rclone.exe"

        url = "https://downloads.rclone.org/rclone-current-windows-amd64.zip"
        try:
            self.log("🌐 Đang kết nối tải rclone.exe từ downloads.rclone.org...")
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MyingGo/1.0"
                },
            )
            with urllib.request.urlopen(req, timeout=40) as resp:
                data_bytes = resp.read()

            self.log(
                f"📦 Đã tải gói nén ({len(data_bytes) // 1048576} MB), đang giải nén..."
            )
            with zipfile.ZipFile(io.BytesIO(data_bytes)) as z:
                found = False
                for member in z.namelist():
                    if member.endswith("rclone.exe"):
                        with z.open(member) as src_file, open(
                            target_exe, "wb"
                        ) as dst_file:
                            shutil.copyfileobj(src_file, dst_file)
                        found = True
                        break
                if not found:
                    return {"error": "Không tìm thấy file rclone.exe trong gói nén."}

            if target_exe.is_file():
                self.log(f"✅ ĐÃ CÀI ĐẶT THÀNH CÔNG: {target_exe}")
                return {"ok": 1, "path": str(target_exe)}
            return {"error": "Lỗi lưu file rclone.exe"}
        except Exception as e:
            return {"error": f"Lỗi tải rclone: {e}"}

    def act_save_client_id(self, data):
        client_id = str(data.get("client_id") or "").strip()
        client_secret = str(data.get("client_secret") or "").strip()
        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"

        DATA_DIR.mkdir(parents=True, exist_ok=True)
        CLIENT_CRED_FILE.write_text(
            json.dumps(
                {"client_id": client_id, "client_secret": client_secret},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        conf_path = Path(self._get_config_path())
        if conf_path.is_file():
            try:
                cfg = configparser.RawConfigParser()
                cfg.read(conf_path, encoding="utf-8")
                if not cfg.has_section(remote_name):
                    cfg.add_section(remote_name)
                    cfg.set(remote_name, "type", "drive")
                    cfg.set(remote_name, "scope", "drive")
                if client_id:
                    cfg.set(remote_name, "client_id", client_id)
                elif cfg.has_option(remote_name, "client_id"):
                    cfg.remove_option(remote_name, "client_id")
                if client_secret:
                    cfg.set(remote_name, "client_secret", client_secret)
                elif cfg.has_option(remote_name, "client_secret"):
                    cfg.remove_option(remote_name, "client_secret")
                with open(conf_path, "w", encoding="utf-8") as f:
                    cfg.write(f)
            except Exception as e:
                return {"error": f"Lỗi cập nhật rclone.conf: {e}"}

        return {
            "ok": 1,
            "message": "Đã lưu Client ID! Hệ thống sẽ mở cửa sổ xác thực lại tài khoản với Client ID mới.",
        }

    def act_connect(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"

        if not Path(rc).is_file():
            res = self.act_download_rclone({})
            if res.get("error"):
                return {
                    "error": f"Chưa có file rclone.exe và tải tự động thất bại: {res['error']}"
                }
            rc = self._get_rclone_bin()

        custom_cid = ""
        custom_sec = ""
        if CLIENT_CRED_FILE.is_file():
            try:
                cred = json.loads(CLIENT_CRED_FILE.read_text(encoding="utf-8"))
                custom_cid = str(cred.get("client_id") or "").strip()
                custom_sec = str(cred.get("client_secret") or "").strip()
            except Exception:
                pass

        bat_file = DATA_DIR / "connect_gdrive.bat"
        if custom_cid and custom_sec:
            cmd_line = f'"{rc}" config create {remote_name} drive scope=drive client_id="{custom_cid}" client_secret="{custom_sec}" --config "{conf}"'
        else:
            cmd_line = f'"{rc}" config create {remote_name} drive scope=drive config_shared_client_id=true --config "{conf}"'

        bat_file.write_text(
            f"""@echo off
chcp 65001 >nul
title KẾT NỐI / ĐỔI TÀI KHOẢN GOOGLE DRIVE - MYINGGO
echo ============================================================
echo   ĐANG MỞ TRÌNH DUYỆT ĐỂ CHỌN TÀI KHOẢN GOOGLE DRIVE...
echo   Sau khi bấm "Cho phép (Allow)" trên trình duyệt, tên và
echo   email tài khoản sẽ tự động hiển thị trên phần mềm MyingGo!
echo ============================================================
{cmd_line}
echo.
echo [HOÀN TẤT] Đã kết nối xong! Cửa sổ sẽ tự đóng sau 2 giây...
timeout /t 2 >nul
""",
            encoding="utf-8",
        )

        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        try:
            subprocess.Popen(["cmd.exe", "/c", str(bat_file)], creationflags=flags)
        except Exception as e:
            return {"error": f"Không thể khởi chạy cửa sổ kết nối: {e}"}

        return {"ok": 1, "message": "Đã mở cửa sổ kết nối Google Drive"}

    def act_export_token(self, data):
        conf = self._get_config_path()
        if not Path(conf).is_file():
            return {"error": "Chưa có file cấu hình Drive trên máy này."}
        try:
            text = Path(conf).read_text(encoding="utf-8").strip()
            if not text or "[gdrive]" not in text:
                return {
                    "error": "Chưa có tài khoản Google Drive nào được liên kết trên máy này."
                }
            return {"ok": 1, "config_text": text}
        except Exception as e:
            return {"error": f"Lỗi đọc file: {e}"}

    def act_import_token(self, data):
        text = str(data.get("config_text") or "").strip()
        if not text or "[gdrive]" not in text:
            return {
                "error": "Nội dung mã kết nối không hợp lệ (phải chứa thông tin [gdrive])."
            }
        conf = self._get_config_path()
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            Path(conf).write_text(text + "\n", encoding="utf-8")
            remotes = self._list_remotes()
            if "gdrive" in remotes or len(remotes) > 0:
                return {
                    "ok": 1,
                    "message": "Đã nhập tài khoản Google Drive thành công!",
                }
            return {"error": "Đã lưu nhưng không nhận diện được remote Drive."}
        except Exception as e:
            return {"error": f"Lỗi ghi file cấu hình: {e}"}

    def act_open_advanced_config(self, data):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
        subprocess.Popen(
            [
                "cmd.exe",
                "/c",
                f'title Rclone Advanced Config & "{rc}" config --config "{conf}"',
            ],
            creationflags=flags,
        )
        return {"ok": 1}

    def act_pick_folder(self, data):
        init_dir = str(data.get("initial") or "")
        title = str(data.get("title") or "Chọn thư mục/ổ đĩa")
        picked = dialogs.pick_dir(title, init_dir)
        return {"path": picked}

    def act_scan_subfolders(self, data):
        p_str = str(data.get("path") or "").strip()
        if not p_str:
            return {"error": "Vui lòng chọn thư mục hoặc ổ đĩa cần quét"}

        p = Path(p_str)
        if not p.exists():
            return {"error": f"Đường dẫn không tồn tại: {p_str}"}

        done_set = self._load_done_history()
        dir_entries = []
        root_files = 0
        try:
            with os.scandir(p) as it:
                for entry in it:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if _is_system_or_gdfs_cache_folder(entry.name):
                                continue
                            dir_entries.append((entry.name, entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            root_files += 1
                    except Exception:
                        continue
        except Exception as e:
            return {"error": f"Lỗi đọc thư mục: {e}"}

        def _inspect_one(item):
            name, fpath = item
            sub_count = 0
            try:
                with os.scandir(fpath) as sub_it:
                    sub_count = sum(1 for _ in sub_it)
            except Exception:
                pass
            is_done = self._is_folder_done(fpath, name, done_set)
            return {
                "name": name,
                "path": fpath,
                "item_count": sub_count,
                "done": is_done,
                "checked": (not is_done),
            }

        with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
            folders = list(pool.map(_inspect_one, dir_entries))

        folders.sort(key=lambda x: natural_sort_key(x["name"]))
        return {
            "ok": 1,
            "parent": str(p),
            "folders": folders,
            "root_files": root_files,
            "done_count": sum(1 for f in folders if f.get("done")),
        }

    def act_mark_folders_done(self, data):
        items = data.get("folders") or []
        is_done = bool(data.get("done", True))
        done_set = self._load_done_history()
        for it in items:
            fpath = str(it.get("path") or "")
            fname = str(it.get("name") or "")
            if fpath or fname:
                k_path, k_name = self._folder_keys(fpath, fname)
                if is_done:
                    if fpath:
                        done_set.add(k_path)
                    if fname:
                        done_set.add(k_name)
                else:
                    done_set.discard(k_path)
                    done_set.discard(k_name)
        self._save_done_history(done_set)
        return {"ok": 1}

    def act_clear_done_history(self, data):
        self._save_done_history(set())
        self.stats["done_folders"] = []
        return {"ok": 1}

    # ── Khởi chạy tải lên ────────────────────────────────────────────────
    def act_start_upload(self, data):
        if self.running:
            return {"error": "Đang có tiến trình tải lên đang chạy"}

        engine_mode = str(data.get("engine_mode") or "rclone").strip()
        transfer_style = str(data.get("transfer_style") or "sequential").strip()
        source = str(data.get("source") or "").strip()
        if not source or not Path(source).exists():
            return {"error": "Thư mục nguồn không tồn tại"}

        remote_name = str(data.get("remote") or "gdrive").strip() or "gdrive"
        target = str(data.get("target") or "").strip()
        gdfs_dest = str(data.get("gdfs_dest") or "").strip()

        if engine_mode == "gdfs":
            if not gdfs_dest:
                return {
                    "error": "Vui lòng điền hoặc bấm '📂 Chọn đích...' để chọn đường dẫn thư mục đích trên ổ Google Drive Desktop!"
                }
        else:
            if not target:
                target = Path(source).name

        try:
            raw_transfers = int(data.get("transfers") or 1)
            transfers = max(1, min(32, raw_transfers))
        except (ValueError, TypeError):
            transfers = 1

        if transfer_style == "sequential":
            transfers = 1
        elif transfer_style == "parallel" and transfers <= 1:
            transfers = 20

        if engine_mode == "rclone":
            rc = self._get_rclone_bin()
            if not Path(rc).is_file():
                self.act_download_rclone({})
                rc = self._get_rclone_bin()
                if not Path(rc).is_file():
                    return {
                        "error": "Chưa có file rclone.exe. Vui lòng bấm nút '⚡ Tự Động Tải Rclone' phía trên."
                    }

        raw_selected = data.get("selected_folders") or []
        selected_folders = [
            f for f in raw_selected if not _is_system_or_gdfs_cache_folder(str(f))
        ]
        is_batch = bool(selected_folders and len(selected_folders) > 0)

        self._stop_requested = False
        self.stats = {
            "running": True,
            "percent": 0,
            "speed": "0 B/s",
            "transferred_bytes": "0 B",
            "total_bytes": "0 B",
            "files_done": 0,
            "files_total": 0,
            "checks_done": 0,
            "checks_total": 0,
            "eta": "Đang bắt đầu...",
            "source": source,
            "target": gdfs_dest if engine_mode == "gdfs" else target,
            "transfers": transfers,
            "engine_mode": engine_mode,
            "transfer_style": transfer_style,
            "recent_files": [],
            "error": "",
            "warning": "",
            "finished": False,
            "start_time": time.time(),
            "is_batch": is_batch,
            "batch_total": len(selected_folders) if is_batch else 1,
            "batch_done": 0,
            "current_subfolder": selected_folders[0] if is_batch else Path(source).name,
            "done_folders": [],
        }
        self.clear_log()

        style_label = (
            "1️⃣ Chuyển từng file 1 (Tuần tự)"
            if transfer_style == "sequential"
            else f"🚀 Chuyển toàn bộ cùng lúc ({transfers} luồng song song)"
        )

        if engine_mode == "gdfs":
            self.log(
                f"💻 CHẾ ĐỘ COPY TRỰC TIẾP VÀO Ổ ĐĨA DRIVE: {source} ➔ {gdfs_dest}"
            )
            self.log(f"⚙️ Kiểu chuyển: {style_label}")
            self.run_bg(
                self._gdfs_upload_worker,
                source,
                gdfs_dest,
                selected_folders if is_batch else None,
                transfer_style,
                transfers,
            )
        elif is_batch:
            self.log(
                f"🚀 BẮT ĐẦU TẢI LÊN DRIVE: Đã chọn {len(selected_folders)} thư mục từ {source}"
            )
            self.log(f"🎯 Thư mục đích: {remote_name}:{target} | {style_label}")
            self.run_bg(
                self._batch_upload_worker,
                source,
                remote_name,
                target,
                selected_folders,
                transfers,
                transfer_style,
            )
        else:
            self.log(
                f"🚀 Bắt đầu tải lên ({style_label}): {source} ➔ {remote_name}:{target}"
            )
            self.run_bg(
                self._single_upload_worker, source, remote_name, target, transfers
            )

        return {"ok": 1, "stats": self.stats}

    # ── Chế độ Rclone (Hỗ trợ cả Tên thư mục VÀ Link chia sẻ / ID thư mục) ──
    def _parse_drive_target(self, target_str: str) -> tuple[str | None, str]:
        """Tự động nhận diện nếu người dùng dán Link chia sẻ Google Drive hoặc Folder ID.
        Trả về (root_folder_id, sub_path).
        - Nếu dán link: https://drive.google.com/drive/folders/1irFG3QkFCt1aZ2MnbZGQHB-jMcmveRQf?usp=sharing
          -> trả về ('1irFG3QkFCt1aZ2MnbZGQHB-jMcmveRQf', '')
        - Nếu điền tên thư mục: '0 - FD ID ADD ÂM'
          -> trả về (None, '0 - FD ID ADD ÂM')
        """
        s = (target_str or "").strip()
        if not s:
            return None, ""
        m = re.search(r"/folders/([a-zA-Z0-9_-]{15,})", s)
        if not m:
            m = re.search(r"[?&]id=([a-zA-Z0-9_-]{15,})", s)
        if m:
            return m.group(1), ""
        if re.fullmatch(r"[a-zA-Z0-9_-]{25,50}", s) and " " not in s:
            return s, ""
        return None, s

    def _build_copy_cmd(self, rc, src_folder, dest, conf, transfers, root_folder_id=None):
        checkers = 4 if transfers <= 8 else 6
        cmd = [
            rc,
            "copy",
            src_folder,
            dest,
            "--config",
            conf,
            f"--transfers={transfers}",
            f"--checkers={checkers}",
            "--fast-list",
            "--check-first",
            "--order-by=size,desc",
            "--size-only",
            "--drive-chunk-size=128M",
            "--drive-upload-cutoff=128M",
            "--buffer-size=32M",
            "--disable-http2",
            "--timeout=10m",
            "--contimeout=20s",
            "--low-level-retries=20",
            "--retries=5",
            "--retries-sleep=5s",
            "--stats=1s",
            "-v",
        ]
        if root_folder_id:
            cmd.append(f"--drive-root-folder-id={root_folder_id}")
        return cmd

    def _batch_upload_worker(
        self,
        parent_src,
        remote_name,
        target_base,
        selected_folders,
        transfers,
        transfer_style="sequential",
    ):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        total_folders = len(selected_folders)
        parent_path = Path(parent_src)
        root_folder_id, clean_target = self._parse_drive_target(target_base)
        if root_folder_id:
            self.log(f"🔗 Đã nhận diện Link / ID thư mục chia sẻ Google Drive: {root_folder_id} ➔ Tải thẳng vào thư mục chia sẻ!")

        for idx, folder_name in enumerate(selected_folders, 1):
            if self._stop_requested:
                break

            src_folder_path = parent_path / folder_name
            if not src_folder_path.exists():
                self.log(f"⚠️ Bỏ qua '{folder_name}' vì không tìm thấy trên ổ đĩa.")
                continue

            local_file_count = 0
            local_bytes = 0
            for root_dir, _, files in os.walk(src_folder_path):
                for f in files:
                    local_file_count += 1
                    try:
                        local_bytes += os.path.getsize(os.path.join(root_dir, f))
                    except OSError:
                        pass

            if root_folder_id:
                dest = f"{remote_name}:{folder_name}"
            else:
                dst_sub = (
                    f"{clean_target.rstrip('/')}/{folder_name}"
                    if clean_target
                    else folder_name
                )
                dest = f"{remote_name}:{dst_sub}"

            self.stats["current_subfolder"] = folder_name
            self.stats["percent"] = 0
            self.stats["files_done"] = 0
            self.stats["files_total"] = local_file_count
            self.stats["transferred_bytes"] = "0 B"
            self.stats["total_bytes"] = _fmt_bytes(local_bytes)
            self.stats["eta"] = "Đang tải..."

            self.log(
                f"\n📂 [{idx}/{total_folders}] Đang tải thư mục: {folder_name} ({local_file_count} file — {_fmt_bytes(local_bytes)})"
            )

            cmd = self._build_copy_cmd(
                rc, str(src_folder_path), dest, conf, transfers, root_folder_id=root_folder_id
            )
            success = self._run_rclone_cmd(cmd)

            if self._stop_requested:
                break

            if success:
                self._mark_folder_done(str(src_folder_path), folder_name, True)
                if folder_name not in self.stats["done_folders"]:
                    self.stats["done_folders"].append(folder_name)
                self.stats["batch_done"] = len(self.stats["done_folders"])
                self.log(
                    f"✅ HOÀN TẤT 100% & ĐÃ GHI NHỚ [{idx}/{total_folders}]: {folder_name}"
                )
            else:
                self.log(
                    f"⚠️ Thư mục '{folder_name}' chưa hoàn tất 100% (xem cảnh báo phía trên)."
                )
                if "750 GB" in self.stats.get("warning", ""):
                    self.stats["error"] = self.stats["warning"]
                    break

        if not self._stop_requested and len(self.stats["done_folders"]) >= total_folders:
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất tất cả"
            self.stats["batch_done"] = total_folders
            self.log(
                f"\n🎉 TẤT CẢ {total_folders} THƯ MỤC ĐÃ ĐƯỢC TẢI LÊN DRIVE THÀNH CÔNG!"
            )
        elif not self._stop_requested:
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
        self.stats["running"] = False

    def _single_upload_worker(self, source, remote_name, target, transfers):
        rc = self._get_rclone_bin()
        conf = self._get_config_path()
        root_folder_id, clean_target = self._parse_drive_target(target)
        if root_folder_id:
            self.log(f"🔗 Đã nhận diện Link / ID thư mục chia sẻ Google Drive: {root_folder_id}")
            dest = f"{remote_name}:{Path(source).name}"
        else:
            dest = f"{remote_name}:{clean_target}"

        cmd = self._build_copy_cmd(rc, source, dest, conf, transfers, root_folder_id=root_folder_id)
        success = self._run_rclone_cmd(cmd)
        if success and not self._stop_requested:
            self._mark_folder_done(source, Path(source).name, True)
            self.stats["percent"] = 100
            self.stats["finished"] = True
            self.stats["speed"] = "0 B/s"
            self.stats["eta"] = "Hoàn tất"
            self.log(f"🎉 TẢI LÊN HOÀN TẤT 100% & ĐÃ GHI NHỚ: {source} ➔ {dest}")
        self.stats["running"] = False

    def _run_rclone_cmd(self, cmd):
        warned_750gb = False
        warned_client_quota = False
        try:
            with self._proc_lock:
                self.proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )

            for raw_line in self.proc.stdout:
                if self._stop_requested:
                    break
                line = raw_line.strip()
                if not line:
                    continue

                if not warned_750gb and (
                    "userRateLimitExceeded" in line
                    or "User rate limit exceeded" in line
                    or "domainPolicy" in line
                ):
                    warned_750gb = True
                    msg = (
                        "⚠️ TÀI KHOẢN GOOGLE DRIVE NÀY ĐÃ CHẠM GIỚI HẠN TẢI LÊN 750 GB / 24 GIỜ CỦA GOOGLE. "
                        "Google đang khóa tải file lớn (.mp4) trên tài khoản này trong 24h! "
                        "👉 Giải pháp: Bấm '🔗 Kết nối / Đổi tài khoản Drive' để chuyển sang 1 Gmail phụ khác."
                    )
                    self.stats["warning"] = msg
                    self.log("\n" + "=" * 72)
                    self.log(msg)
                    self.log("=" * 72 + "\n")

                if not warned_client_quota and (
                    "202264815644" in line or "Quota exceeded for quota metric" in line
                ):
                    warned_client_quota = True
                    msg = (
                        "ℹ️ Google đang giới hạn tốc độ API mặc định. Khuyên dùng nút '1️⃣ Chuyển từng file 1', "
                        "hoặc chọn chế độ '💻 Copy trực tiếp vào Ổ đĩa Google Drive Desktop'."
                    )
                    if not self.stats.get("warning"):
                        self.stats["warning"] = msg
                    self.log(msg)

                m_bytes = RE_STATS_BYTES.search(line)
                if m_bytes:
                    self.stats["transferred_bytes"] = m_bytes.group(1)
                    self.stats["total_bytes"] = m_bytes.group(2)
                    try:
                        pct_val = float(m_bytes.group(3))
                        f_done = self.stats.get("files_done", 0)
                        f_tot = self.stats.get("files_total", 0)
                        if pct_val >= 100.0 and f_tot > 0 and f_done < f_tot:
                            pct_val = 99.0
                        self.stats["percent"] = pct_val
                    except ValueError:
                        pass
                    self.stats["speed"] = m_bytes.group(4)
                    self.stats["eta"] = m_bytes.group(5)

                m_files = RE_STATS_FILES.search(line)
                if m_files:
                    try:
                        self.stats["files_done"] = int(m_files.group(1))
                        self.stats["files_total"] = int(m_files.group(2))
                        if (
                            self.stats.get("percent", 0) >= 100.0
                            and self.stats["files_total"] > 0
                            and self.stats["files_done"] < self.stats["files_total"]
                        ):
                            self.stats["percent"] = 99.0
                    except ValueError:
                        pass

                m_checks = RE_CHECKS_FILES.search(line)
                if m_checks:
                    try:
                        self.stats["checks_done"] = int(m_checks.group(1))
                        self.stats["checks_total"] = int(m_checks.group(2))
                    except ValueError:
                        pass

                m_copied = RE_FILE_COPIED.search(line)
                if m_copied:
                    fname = m_copied.group(1).strip()
                    rec = self.stats["recent_files"]
                    if fname not in rec:
                        rec.insert(0, fname)
                        if len(rec) > 10:
                            rec.pop()
                    self.log(f"  ✓ {fname}")

                if any(
                    k in line.upper()
                    for k in ("ERROR", "FAILED", "NOTICE", "TRANSFERRED", "ELAPSED")
                ):
                    if "using defaults" not in line and "Config file" not in line:
                        self.log(line)

            ret = self.proc.wait() if self.proc else 0
            return ret == 0
        except Exception as e:
            self.stats["error"] = str(e)
            self.log(f"❌ Lỗi: {e}")
            return False
        finally:
            with self._proc_lock:
                self.proc = None

    # ── Chế độ Copy trực tiếp vào Ổ đĩa Google Drive Desktop (GDFS) ──────
    def _gdfs_upload_worker(
        self,
        parent_src: str,
        dst_root_str: str,
        selected_folders: list[str] | None,
        transfer_style: str = "sequential",
        max_workers: int = 8,
    ):
        try:
            src_root = Path(parent_src)
            dst_root = Path(dst_root_str)
            dst_root.mkdir(parents=True, exist_ok=True)

            folders_to_process = (
                selected_folders if selected_folders else [src_root.name]
            )
            is_subfolders = bool(selected_folders)
            total_folders = len(folders_to_process)
            buf_size = 16 * 1024 * 1024  # 16 MB buffer

            if transfer_style == "sequential":
                for idx, folder_name in enumerate(folders_to_process, 1):
                    if self._stop_requested:
                        break

                    s_dir = (src_root / folder_name) if is_subfolders else src_root
                    d_dir = (dst_root / folder_name) if is_subfolders else dst_root
                    if not s_dir.exists():
                        continue

                    all_files: list[tuple[Path, Path, int, str]] = []
                    total_bytes = 0
                    for r, _, files in os.walk(s_dir):
                        for f in files:
                            sp = Path(r) / f
                            rel = sp.relative_to(s_dir)
                            dp = d_dir / rel
                            try:
                                sz = sp.stat().st_size
                            except OSError:
                                sz = 0
                            all_files.append((sp, dp, sz, str(rel).replace("\\", "/")))
                            total_bytes += sz

                    self.stats["current_subfolder"] = folder_name
                    self.stats["files_total"] = len(all_files)
                    self.stats["files_done"] = 0
                    self.stats["total_bytes"] = _fmt_bytes(total_bytes)
                    self.stats["transferred_bytes"] = "0 B"
                    self.stats["percent"] = 0

                    self.log(
                        f"\n📂 [{idx}/{total_folders}] Chuyển từng file 1 — Thư mục '{folder_name}' ({len(all_files)} file — {_fmt_bytes(total_bytes)}) ➔ {d_dir}"
                    )

                    copied_bytes = 0
                    t0 = time.time()

                    for f_idx, (sp, dp, sz, rel_str) in enumerate(all_files, 1):
                        if self._stop_requested:
                            break
                        dp.parent.mkdir(parents=True, exist_ok=True)

                        if dp.exists():
                            try:
                                if dp.stat().st_size == sz:
                                    copied_bytes += sz
                                    self.stats["files_done"] = f_idx
                                    self.stats["transferred_bytes"] = _fmt_bytes(
                                        copied_bytes
                                    )
                                    if total_bytes > 0:
                                        self.stats["percent"] = min(
                                            99.9, (copied_bytes / total_bytes) * 100.0
                                        )
                                    continue
                            except OSError:
                                pass

                        with open(sp, "rb") as fsrc, open(dp, "wb") as fdst:
                            while not self._stop_requested:
                                chunk = fsrc.read(buf_size)
                                if not chunk:
                                    break
                                fdst.write(chunk)
                                copied_bytes += len(chunk)
                                elapsed = max(0.1, time.time() - t0)
                                spd = copied_bytes / elapsed
                                rem_bytes = max(0, total_bytes - copied_bytes)
                                eta_sec = int(rem_bytes / spd) if spd > 0 else 0
                                self.stats["speed"] = f"{_fmt_bytes(spd)}/s"
                                self.stats["transferred_bytes"] = _fmt_bytes(
                                    copied_bytes
                                )
                                if total_bytes > 0:
                                    self.stats["percent"] = min(
                                        99.9, (copied_bytes / total_bytes) * 100.0
                                    )
                                self.stats["eta"] = (
                                    f"{eta_sec // 60}m{eta_sec % 60}s"
                                    if eta_sec >= 60
                                    else f"{eta_sec}s"
                                )

                        if not self._stop_requested:
                            self.stats["files_done"] = f_idx
                            rec = self.stats["recent_files"]
                            disp_name = f"{folder_name}/{rel_str}"
                            if disp_name not in rec:
                                rec.insert(0, disp_name)
                                if len(rec) > 10:
                                    rec.pop()
                            self.log(f"  ✓ [{f_idx}/{len(all_files)}] {disp_name}")

                    if not self._stop_requested:
                        self._mark_folder_done(str(s_dir), folder_name, True)
                        if folder_name not in self.stats["done_folders"]:
                            self.stats["done_folders"].append(folder_name)
                        self.stats["batch_done"] = len(self.stats["done_folders"])
                        self.stats["percent"] = 100
                        self.log(
                            f"✅ HOÀN TẤT 100% & ĐÃ GHI NHỚ [{idx}/{total_folders}]: {folder_name}"
                        )

            else:
                self.log(
                    "🔍 Đang gom toàn bộ danh sách file từ các thư mục đã chọn để chuyển đồng loạt..."
                )
                all_tasks: list[tuple[str, Path, Path, Path, int, str]] = []
                remaining_by_folder: dict[str, int] = {}
                grand_total_bytes = 0

                for folder_name in folders_to_process:
                    if self._stop_requested:
                        break
                    s_dir = (src_root / folder_name) if is_subfolders else src_root
                    d_dir = (dst_root / folder_name) if is_subfolders else dst_root
                    if not s_dir.exists():
                        continue
                    f_count = 0
                    for r, _, files in os.walk(s_dir):
                        for f in files:
                            sp = Path(r) / f
                            rel = sp.relative_to(s_dir)
                            dp = d_dir / rel
                            try:
                                sz = sp.stat().st_size
                            except OSError:
                                sz = 0
                            all_tasks.append(
                                (
                                    folder_name,
                                    s_dir,
                                    sp,
                                    dp,
                                    sz,
                                    str(rel).replace("\\", "/"),
                                )
                            )
                            grand_total_bytes += sz
                            f_count += 1
                    remaining_by_folder[folder_name] = f_count
                    if f_count == 0:
                        self._mark_folder_done(str(s_dir), folder_name, True)
                        if folder_name not in self.stats["done_folders"]:
                            self.stats["done_folders"].append(folder_name)
                        self.stats["batch_done"] = len(self.stats["done_folders"])

                grand_total_files = len(all_tasks)
                self.stats["files_total"] = grand_total_files
                self.stats["files_done"] = 0
                self.stats["total_bytes"] = _fmt_bytes(grand_total_bytes)
                self.stats["transferred_bytes"] = "0 B"
                self.stats["percent"] = 0

                workers = max(2, min(16, max_workers or 8))
                self.log(
                    f"🚀 BẮT ĐẦU CHUYỂN TOÀN BỘ CÙNG LÚC: {grand_total_files} file ({_fmt_bytes(grand_total_bytes)}) trên {total_folders} thư mục với {workers} luồng đồng thời ➔ {dst_root}"
                )

                lock = threading.Lock()
                state = {"copied_bytes": 0, "files_done": 0, "t0": time.time()}

                def _copy_one_task(task):
                    if self._stop_requested:
                        return
                    folder_name, s_dir, sp, dp, sz, rel_str = task
                    dp.parent.mkdir(parents=True, exist_ok=True)

                    skipped = False
                    if dp.exists():
                        try:
                            if dp.stat().st_size == sz:
                                skipped = True
                                with lock:
                                    state["copied_bytes"] += sz
                        except OSError:
                            pass

                    if not skipped:
                        with open(sp, "rb") as fsrc, open(dp, "wb") as fdst:
                            while not self._stop_requested:
                                chunk = fsrc.read(buf_size)
                                if not chunk:
                                    break
                                fdst.write(chunk)
                                with lock:
                                    state["copied_bytes"] += len(chunk)
                                    cb = state["copied_bytes"]
                                    elapsed = max(0.1, time.time() - state["t0"])
                                    spd = cb / elapsed
                                    rem = max(0, grand_total_bytes - cb)
                                    eta_sec = int(rem / spd) if spd > 0 else 0
                                    self.stats["speed"] = f"{_fmt_bytes(spd)}/s"
                                    self.stats["transferred_bytes"] = _fmt_bytes(cb)
                                    if grand_total_bytes > 0:
                                        self.stats["percent"] = min(
                                            99.9, (cb / grand_total_bytes) * 100.0
                                        )
                                    self.stats["eta"] = (
                                        f"{eta_sec // 60}m{eta_sec % 60}s"
                                        if eta_sec >= 60
                                        else f"{eta_sec}s"
                                    )

                    if self._stop_requested:
                        return

                    with lock:
                        state["files_done"] += 1
                        self.stats["files_done"] = state["files_done"]
                        self.stats["current_subfolder"] = folder_name
                        disp_name = f"{folder_name}/{rel_str}"
                        rec = self.stats["recent_files"]
                        if disp_name not in rec:
                            rec.insert(0, disp_name)
                            if len(rec) > 10:
                                rec.pop()
                        if not skipped:
                            self.log(
                                f"  ✓ [{state['files_done']}/{grand_total_files}] {disp_name}"
                            )

                        rem_f = remaining_by_folder.get(folder_name, 1) - 1
                        remaining_by_folder[folder_name] = rem_f
                        if rem_f <= 0 and folder_name not in self.stats["done_folders"]:
                            self._mark_folder_done(str(s_dir), folder_name, True)
                            self.stats["done_folders"].append(folder_name)
                            self.stats["batch_done"] = len(self.stats["done_folders"])
                            self.log(
                                f"✅ HOÀN TẤT 100% & ĐÃ GHI NHỚ THƯ MỤC [{self.stats['batch_done']}/{total_folders}]: {folder_name}"
                            )

                with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                    futures = [pool.submit(_copy_one_task, t) for t in all_tasks]
                    for fut in concurrent.futures.as_completed(futures):
                        if self._stop_requested:
                            break
                        exc = fut.exception()
                        if exc:
                            self.log(f"⚠️ Lỗi khi copy file: {exc}")

            if not self._stop_requested:
                self.stats["percent"] = 100
                self.stats["finished"] = True
                self.stats["speed"] = "0 B/s"
                self.stats["eta"] = "Hoàn tất tất cả"
                self.log(
                    f"\n🎉 ĐÃ CHUYỂN XONG {len(self.stats['done_folders'])}/{total_folders} THƯ MỤC VÀO '{dst_root}'!"
                )
        except Exception as e:
            self.stats["error"] = str(e)
            self.log(f"❌ Lỗi khi copy vào ổ đĩa Google Drive Desktop: {e}")
        finally:
            self.stats["running"] = False

    def act_progress(self, data):
        since = int(data.get("since") or 0)
        logs = self.get_log(since)
        return {
            "stats": self.stats,
            "logs": logs.get("lines", []),
            "next_log": logs.get("next", 0),
            "running": self.running,
        }

    def act_stop_upload(self, data):
        self._stop_requested = True
        with self._proc_lock:
            if self.proc and self.proc.poll() is None:
                self.log("⏹ Đang gửi tín hiệu dừng tiến trình...")
                try:
                    self.proc.terminate()
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None
        self.stats["running"] = False
        self.running = False
        return {"ok": 1, "message": "Đã dừng tiến trình tải lên"}

    def act_open_drive_web(self, data):
        url = "https://drive.google.com/drive/my-drive"
        webbrowser.open(url)
        return {"ok": 1, "url": url}
