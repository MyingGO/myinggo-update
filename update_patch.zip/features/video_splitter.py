# Tính năng: Cắt & Chia nhỏ Video (theo số phút/giây cố định hoặc chia đều N phần bằng nhau)
import os
import re
import subprocess
from pathlib import Path
from core.base import Feature
from core import dialogs
from features.downloader import find_ffmpeg

VIDEO_EXTS = {'.mp4', '.mkv', '.webm', '.avi', '.mov', '.flv', '.m4v', '.ts', '.wmv'}
NO_WIN = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def format_duration(seconds: float) -> str:
    seconds = max(0.0, float(seconds or 0.0))
    total_sec = int(round(seconds))
    h = total_sec // 3600
    m = (total_sec % 3600) // 60
    s = total_sec % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def probe_video_duration(path: str, ffmpeg_bin: str | None) -> float:
    """Đọc thời lượng video (giây) bằng ffprobe hoặc ffmpeg -i."""
    if not ffmpeg_bin or not os.path.isfile(path):
        return 0.0
    ffprobe_bin = None
    ff_dir = os.path.dirname(ffmpeg_bin)
    cand = os.path.join(ff_dir, 'ffprobe.exe' if os.name == 'nt' else 'ffprobe')
    if os.path.isfile(cand):
        ffprobe_bin = cand

    if ffprobe_bin:
        try:
            r = subprocess.run(
                [ffprobe_bin, '-v', 'error', '-show_entries', 'format=duration',
                 '-of', 'default=noprint_wrappers=1:nokey=1', path],
                capture_output=True, text=True, encoding='utf-8', errors='replace',
                timeout=15, creationflags=NO_WIN
            )
            val = (r.stdout or '').strip()
            if val:
                dur = float(val)
                if dur > 0:
                    return dur
        except Exception:
            pass

    try:
        r = subprocess.run(
            [ffmpeg_bin, '-hide_banner', '-i', path],
            capture_output=True, text=True, encoding='utf-8', errors='replace',
            timeout=15, creationflags=NO_WIN
        )
        txt = (r.stderr or '') + '\n' + (r.stdout or '')
        m = re.search(r'Duration:\s*(\d+):(\d+):([\d.]+)', txt)
        if m:
            h, mnt, sec = int(m.group(1)), int(m.group(2)), float(m.group(3))
            return h * 3600.0 + mnt * 60.0 + sec
    except Exception:
        pass
    return 0.0


def compute_segments(
    duration: float,
    mode: str = 'duration',
    seg_seconds: float = 60.0,
    parts_count: int = 5,
    tail_mode: str = 'keep',
    min_tail_sec: float = 5.0,
) -> list[tuple[float, float]]:
    """
    Tính danh sách các đoạn (start_sec, end_sec) cho 1 video:
    - mode == 'duration': Cắt mỗi đoạn dài `seg_seconds` giây.
      + tail_mode == 'keep': Giữ đoạn dư cuối (nếu >= 0.8s; nếu < 0.8s thì gộp vào đoạn cuối).
      + tail_mode == 'merge': Nếu đoạn dư < min_tail_sec thì gộp vào đoạn kế cuối.
      + tail_mode == 'drop': Bỏ qua đoạn dư nếu ngắn hơn seg_seconds (trừ khi chỉ có 1 đoạn).
    - mode == 'parts': Chia đều video thành `parts_count` phần có thời lượng bằng nhau.
    """
    duration = float(duration or 0.0)
    if duration <= 0.1:
        return []

    if mode == 'parts':
        n = max(1, int(parts_count or 1))
        step = duration / n
        return [(round(i * step, 3), round(duration if i == n - 1 else (i + 1) * step, 3)) for i in range(n)]

    # mode == 'duration'
    seg = max(1.0, float(seg_seconds or 60.0))
    if duration <= seg + 0.8:
        return [(0.0, round(duration, 3))]

    full_count = int(duration // seg)
    rem = duration - (full_count * seg)

    # Nếu phần dư cực nhỏ (< 0.8s do sai số container), gộp luôn vào đoạn cuối để tròn số video
    if rem < 0.8:
        segments = [(round(i * seg, 3), round((i + 1) * seg, 3)) for i in range(full_count)]
        if segments:
            segments[-1] = (segments[-1][0], round(duration, 3))
        return segments

    segments = [(round(i * seg, 3), round((i + 1) * seg, 3)) for i in range(full_count)]
    tail_start = round(full_count * seg, 3)
    tail_end = round(duration, 3)

    if tail_mode == 'drop':
        return segments if segments else [(0.0, tail_end)]
    if tail_mode == 'merge' and segments and rem < max(1.0, float(min_tail_sec or 5.0)):
        segments[-1] = (segments[-1][0], tail_end)
        return segments

    # Mặc định 'keep': giữ đoạn dư thành 1 phần riêng
    segments.append((tail_start, tail_end))
    return segments


class VideoSplitter(Feature):
    title = "Cắt video"
    order = 17

    def __init__(self):
        super().__init__()
        self._prog = {'pct': 0, 'text': ''}
        self.stopped = False
        self.proc = None

    def _probe_list(self, paths: list[str]) -> list[dict]:
        ff = find_ffmpeg()
        out = []
        seen = set()
        for p in paths:
            if not p:
                continue
            norm = os.path.normpath(p)
            if norm in seen or not os.path.isfile(norm):
                continue
            if Path(norm).suffix.lower() not in VIDEO_EXTS:
                continue
            seen.add(norm)
            try:
                sz_mb = round(os.path.getsize(norm) / (1024 * 1024), 2)
            except Exception:
                sz_mb = 0.0
            dur = probe_video_duration(norm, ff)
            out.append({
                'path': norm,
                'name': os.path.basename(norm),
                'size_mb': sz_mb,
                'duration': round(dur, 2),
                'duration_str': format_duration(dur) if dur > 0 else 'Không rõ',
            })
        return out

    def act_status(self, _):
        return {
            'ffmpeg': find_ffmpeg(),
            'running': self.running,
            'progress': self._prog,
        }

    def act_pick_files(self, _):
        exts = ' '.join(f'*{e}' for e in sorted(VIDEO_EXTS))
        files = dialogs.pick_files('Chọn video cần cắt', [('Video', exts), ('Tất cả file', '*.*')])
        return {'items': self._probe_list(files)}

    def act_pick_folder(self, _):
        d = dialogs.pick_folder('Chọn thư mục chứa video')
        if not d:
            return {'items': [], 'folder': ''}
        files = [
            str(p) for p in sorted(Path(d).iterdir())
            if p.is_file() and p.suffix.lower() in VIDEO_EXTS
        ]
        return {'items': self._probe_list(files), 'folder': d}

    def act_probe(self, d):
        return {'items': self._probe_list(d.get('files') or [])}

    def act_pick_out(self, _):
        return {'path': dialogs.pick_folder('Chọn thư mục lưu video sau khi cắt')}

    def act_open_folder(self, d):
        p = (d.get('path') or '').strip()
        if p and os.path.exists(p):
            os.startfile(p if os.path.isdir(p) else os.path.dirname(p))
        return {'ok': True}

    def act_progress(self, _):
        return {**self._prog, 'running': self.running}

    def act_stop(self, _):
        self.stopped = True
        if self.proc and self.proc.poll() is None:
            try:
                subprocess.run(['taskkill', '/F', '/T', '/PID', str(self.proc.pid)], capture_output=True, creationflags=NO_WIN)
            except Exception:
                pass
        return {'ok': True}

    def act_start(self, d):
        if self.running:
            return {'error': 'Đang chạy tiến trình cắt video rồi'}
        ff = find_ffmpeg()
        if not ff:
            return {'error': 'Chưa tìm thấy FFmpeg! Hãy tải FFmpeg ở mục Tải video trước.'}

        files = [f for f in (d.get('files') or []) if f and os.path.isfile(f)]
        if not files:
            return {'error': 'Hãy chọn ít nhất 1 video để cắt'}

        mode = d.get('mode') or 'duration'  # 'duration' | 'parts'
        minutes = float(d.get('minutes') or 0)
        seconds = float(d.get('seconds') or 0)
        seg_seconds = minutes * 60.0 + seconds
        parts_count = int(d.get('parts_count') or 5)
        tail_mode = d.get('tail_mode') or 'keep'  # 'keep' | 'merge' | 'drop'
        min_tail_sec = float(d.get('min_tail_sec') or 10.0)
        codec_mode = d.get('codec_mode') or 'copy'  # 'copy' | 'encode'
        out_dir = (d.get('out_dir') or '').strip()
        subfolder_per_video = bool(d.get('subfolder_per_video', True))
        overwrite = bool(d.get('overwrite', False))
        name_prefix = (d.get('name_prefix') or 'part').strip() or 'part'

        if mode == 'duration' and seg_seconds < 1.0:
            return {'error': 'Thời lượng mỗi đoạn cắt phải từ 1 giây trở lên'}
        if mode == 'parts' and parts_count < 2:
            return {'error': 'Số phần chia đều phải từ 2 phần trở lên'}

        self.clear_log()
        self.stopped = False
        self._prog = {'pct': 0, 'text': 'Đang phân tích thời lượng video...'}

        def work():
            plan = []
            total_segs = 0

            for src in files:
                if self.stopped:
                    break
                dur = probe_video_duration(src, ff)
                if dur <= 0:
                    self.log(f'⚠️ Không đọc được thời lượng: {os.path.basename(src)} (bỏ qua)')
                    continue
                segs = compute_segments(
                    duration=dur,
                    mode=mode,
                    seg_seconds=seg_seconds,
                    parts_count=parts_count,
                    tail_mode=tail_mode,
                    min_tail_sec=min_tail_sec,
                )
                plan.append((src, dur, segs))
                total_segs += len(segs)

            if not plan or total_segs == 0:
                self._prog = {'pct': 0, 'text': 'Không có đoạn video nào để cắt'}
                self.log('❌ Không tạo được kế hoạch cắt video.')
                return

            mode_desc = (
                f"Cắt mỗi đoạn {format_duration(seg_seconds)}"
                if mode == 'duration'
                else f"Chia đều mỗi video thành {parts_count} phần bằng nhau"
            )
            codec_desc = "Siêu tốc (Giữ nguyên gốc -c copy)" if codec_mode == 'copy' else "Chính xác từng khung hình (Render H.264)"
            self.log(f"✂️ Bắt đầu cắt {len(plan)} video ➔ Tổng cộng {total_segs} video nhỏ")
            self.log(f"⚙️ Chế độ: {mode_desc} | Kiểu cắt: {codec_desc}")

            done_segs = 0
            ok_segs = 0

            for vid_idx, (src, dur, segs) in enumerate(plan, 1):
                if self.stopped:
                    break
                p = Path(src)
                base_out = Path(out_dir) if out_dir else p.parent
                target_dir = (base_out / p.stem) if subfolder_per_video else base_out
                target_dir.mkdir(parents=True, exist_ok=True)

                ext = p.suffix if codec_mode == 'copy' else '.mp4'
                pad_width = max(2, len(str(len(segs))))

                self.log(
                    f"\n🎬 [{vid_idx}/{len(plan)}] {p.name} (Tổng: {format_duration(dur)}) "
                    f"➔ Cắt thành {len(segs)} phần → {target_dir}"
                )

                for seg_idx, (st, et) in enumerate(segs, 1):
                    if self.stopped:
                        break
                    seg_dur = max(0.1, et - st)
                    part_label = f"{seg_idx:0{pad_width}d}"
                    dst = target_dir / f"{p.stem}_{name_prefix}_{part_label}{ext}"
                    if not overwrite:
                        k = 1
                        while dst.exists():
                            dst = target_dir / f"{p.stem}_{name_prefix}_{part_label}_{k}{ext}"
                            k += 1

                    self._prog = {
                        'pct': int(done_segs * 100 / total_segs),
                        'text': f"Đang cắt [{done_segs + 1}/{total_segs}]: {p.name} (Phần {seg_idx}/{len(segs)})",
                    }

                    if codec_mode == 'copy':
                        cmd = [
                            ff, '-y', '-hide_banner', '-loglevel', 'error',
                            '-ss', f"{st:.3f}", '-to', f"{et:.3f}",
                            '-i', str(p),
                            '-c', 'copy',
                            '-avoid_negative_ts', 'make_zero',
                            str(dst),
                        ]
                    else:
                        cmd = [
                            ff, '-y', '-hide_banner', '-loglevel', 'error',
                            '-ss', f"{st:.3f}", '-to', f"{et:.3f}",
                            '-i', str(p),
                            '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
                            '-c:a', 'aac', '-b:a', '192k',
                            '-movflags', '+faststart',
                            str(dst),
                        ]

                    self.proc = subprocess.Popen(
                        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        text=True, encoding='utf-8', errors='replace', creationflags=NO_WIN
                    )
                    out_txt, _ = self.proc.communicate()
                    code = self.proc.returncode
                    done_segs += 1

                    if self.stopped:
                        break

                    if code == 0 and dst.exists():
                        ok_segs += 1
                        self.log(
                            f"  ✅ Phần {seg_idx}/{len(segs)}: {dst.name} "
                            f"[{format_duration(st)} ➔ {format_duration(et)} | dài {format_duration(seg_dur)}]"
                        )
                    else:
                        err_line = (out_txt or '').strip().splitlines()[-1] if (out_txt or '').strip() else 'Lỗi FFmpeg'
                        self.log(f"  ❌ Lỗi phần {seg_idx}/{len(segs)} ({dst.name}): {err_line}")

                self._prog = {
                    'pct': int(done_segs * 100 / total_segs),
                    'text': f"Đã xử lý {done_segs}/{total_segs} phần",
                }

            if self.stopped:
                self._prog['text'] = f"Đã dừng ({ok_segs}/{total_segs} phần hoàn tất)"
                self.log(f"\n⏹ Đã dừng theo yêu cầu. Hoàn tất {ok_segs}/{total_segs} video nhỏ.")
            else:
                self._prog = {'pct': 100, 'text': f"Hoàn tất {ok_segs}/{total_segs} video nhỏ!"}
                self.log(f"\n🎉 Hoàn tất! Đã tạo thành công {ok_segs}/{total_segs} video nhỏ.")

        self.run_bg(work)
        return {'ok': True}
