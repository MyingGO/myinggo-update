"""Tính năng: Yu-Gi-Oh! Academy — học combo cơ bản, tìm kiếm nâng cao, xây dựng deck (kèm đổi Alt Art, Overframe, Manga Style, ảnh riêng)
và kho dữ liệu offline (toàn bộ lá bài, banlist, bộ bài, sách luật, gói Alt Art/Overframe/Manga) có thể lưu sang ổ khác. Giao diện ở web/yugioh/."""
import importlib
import subprocess
from pathlib import Path

from core import dialogs, ygo_data
from core.base import Feature

importlib.reload(ygo_data)

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT / "web" / "yugioh"


class YugiohCombo(Feature):
    title = "Yu-Gi-Oh! Academy"
    order = 40

    def __init__(self):
        super().__init__()
        self.stop_requested = False
        self.prog = {"pct": 0, "text": ""}

    def act_open_window(self, data):
        from core import server
        return {"ok": 1, "url": server.open_sub_window("/web/yugioh/index.html?v=16", fid="yugioh_combo")}

    def act_open_folder(self, data):
        subprocess.Popen(["explorer", str(SITE)])
        return {"ok": 1, "path": str(SITE)}

    def act_status(self, data):
        st = ygo_data.status()
        try:
            st["remote"] = ygo_data.remote_version()
        except Exception as e:
            st["remote"] = {"error": str(e)}
        st["running"] = self.running
        return st

    def act_progress(self, data):
        return dict(self.prog, running=self.running)

    def act_open_data(self, data):
        subprocess.Popen(["explorer", str(ygo_data.data_dir())])
        return {"ok": 1}

    def act_pick_dir(self, data):
        if self.running:
            return {"error": "Đang chạy tác vụ khác"}
        p = dialogs.pick_dir("Chọn thư mục lưu kho dữ liệu Yu-Gi-Oh (nên chọn ổ D: hoặc F:)", str(ygo_data.data_dir()))
        if not p:
            return ygo_data.status()
        ygo_data.set_data_dir(p)
        return ygo_data.status()

    def act_stop(self, data):
        self.stop_requested = True
        return {}

    def _start(self, fn, *args):
        if self.running:
            return {"error": "Đang chạy tác vụ khác"}
        self.clear_log()
        self.stop_requested = False
        self.prog = {"pct": 0, "text": "Đang bắt đầu..."}
        self.run_bg(fn, *args)
        return {"ok": 1}

    def act_update_cards(self, data):
        return self._start(self._job_cards)

    def act_update_banlists(self, data):
        return self._start(self._job_banlists)

    def act_update_special_arts(self, data):
        return self._start(self._job_special_arts)

    def act_update_rulebook(self, data):
        return self._start(self._job_rulebook)

    def act_download_images(self, data):
        return self._start(self._job_images)

    def act_update_all(self, data):
        return self._start(self._job_all)

    def act_fetch_card_arts(self, data):
        cid = data.get("id")
        name = str(data.get("name") or "").strip()
        if not cid or not name:
            return {"error": "Thiếu thông tin lá bài"}
        variants = ygo_data.fetch_card_gallery_variants(cid, name)
        return {"ok": 1, "variants": variants}

    def act_cache_variant(self, data):
        cid = data.get("id")
        rurl = str(data.get("remote_url") or "").strip()
        if not cid or not rurl:
            return {"error": "Thiếu URL ảnh"}
        entry = ygo_data.cache_remote_variant(
            cid,
            rurl,
            label=str(data.get("label") or "Variant Art"),
            tag=str(data.get("tag") or "alt"),
            key=str(data.get("key") or ""),
        )
        return {"ok": 1, "entry": entry}

    def act_upload_custom_art(self, data):
        cid = data.get("id")
        b64 = str(data.get("data_b64") or "")
        if not cid or not b64:
            return {"error": "Thiếu dữ liệu ảnh"}
        entry = ygo_data.save_custom_art(
            cid,
            filename=str(data.get("filename") or "custom.png"),
            data_b64=b64,
            label=str(data.get("label") or "Custom Art"),
            tag=str(data.get("tag") or "custom"),
        )
        return {"ok": 1, "entry": entry}

    def act_delete_special_art(self, data):
        cid = data.get("id")
        key = str(data.get("key") or "")
        variants = ygo_data.delete_special_art(cid, key)
        return {"ok": 1, "variants": variants}

    def act_translate_card(self, data):
        cid = data.get("id") or ""
        desc = str(data.get("desc") or "").strip()
        force = bool(data.get("force"))
        if not desc:
            return {"ok": 1, "vi": "", "source": "empty"}
        return ygo_data.translate_card_vi(cid, desc, force=force)

    def act_save_card_vi(self, data):
        cid = data.get("id") or ""
        vi = str(data.get("vi") or "")
        if not cid:
            return {"error": "Thiếu mã lá bài"}
        saved = ygo_data.save_vi_translation(cid, vi)
        return {"ok": 1, "vi": saved}

    def _job_cards(self):
        meta = ygo_data.update_cards(self.log)
        self.prog = {"pct": 100, "text": f"Đã cập nhật {meta['cards']} lá bài + toàn bộ Banlist"}

    def _job_banlists(self):
        bmeta = ygo_data.update_banlists(self.log)
        self.prog = {"pct": 100, "text": f"Đã cập nhật {len(bmeta)} hệ Banlist (TCG, OCG, AE, MD...)"}

    def _job_special_arts(self):
        res = ygo_data.update_special_arts(self.log)
        self.prog = {"pct": 100, "text": f"Đã đồng bộ {res['total']} bản Overframe / Manga / Alt Art"}

    def _job_rulebook(self):
        name = ygo_data.update_rulebook(self.log)
        self.prog = {"pct": 100, "text": f"Đã lưu {name}"}

    def _job_images(self):
        def progress(p, t):
            self.prog = {"pct": p, "text": t}
        ygo_data.download_images(self.log, lambda: self.stop_requested, progress)

    def _job_all(self):
        self._job_cards()
        try:
            self._job_special_arts()
        except Exception as e:
            self.log(f"[CẢNH BÁO] Gói Overframe/Manga: {e}")
        try:
            self._job_rulebook()
        except Exception as e:
            self.log(f"[LỖI] Sách luật: {e}")
        self.log("\n✅ Hoàn tất cập nhật kho bài + Alt Art/Overframe/Manga + luật.")
        self.prog = {"pct": 100, "text": "Hoàn tất"}
