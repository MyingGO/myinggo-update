"""Tính năng: đổi giao diện (màu nền, màu nút, màu chữ, ảnh nền, độ trong suốt kính...). Lưu ở settings.json."""
from core import dialogs, settings
from core.base import Feature


class Appearance(Feature):
    title = "Giao diện"
    order = 999
    dock = "bottom"

    def act_pick_image(self, data):
        p = dialogs.pick_image()
        if not p:
            return {"settings": settings.load()}
        return {"settings": settings.set_image(p)}
