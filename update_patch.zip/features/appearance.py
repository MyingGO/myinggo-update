"""Tính năng: đổi giao diện (màu nền, màu nút, màu chữ, ảnh nền, độ trong suốt kính...). Lưu ở settings.json."""
import importlib
import sys

from core import dialogs, settings
from core.base import Feature

try:
    if "core.updater" in sys.modules:
        importlib.reload(sys.modules["core.updater"])
    from core import updater as _upd
    if hasattr(_upd, "hot_upgrade_runtime"):
        _upd.hot_upgrade_runtime()
except Exception:
    pass


class Appearance(Feature):
    title = "Giao diện"
    order = 999
    dock = "bottom"

    def act_pick_image(self, data):
        p = dialogs.pick_image()
        if not p:
            return {"settings": settings.load()}
        return {"settings": settings.set_image(p)}
