"""Tính năng: đổi giao diện (màu nền, màu nút, màu chữ, ảnh nền, độ trong suốt kính...). Lưu ở settings.json."""
import importlib
import sys

from core import dialogs, settings
from core.base import Feature

try:
    if "core.updater" in sys.modules:
        importlib.reload(sys.modules["core.updater"])
    from core import updater as _upd
    if hasattr(_upd, "hot_upgrade_runtime"):
        _upd.hot_upgrade_runtime()
except Exception:
    pass


class Appearance(Feature):
    title = "Giao diện"
    order = 999
    dock = "bottom"

    def act_pick_image(self, data):
        p = dialogs.pick_image()
        if not p:
            return {"settings": settings.load()}
        return {"settings": settings.set_image(p)}

    def act_video_info(self, data):
        try:
            cfg = settings.ensure_video_browser_safe()
        except Exception:
            cfg = settings.load()
        vname = cfg.get("bg_video") or ""
        vpath = settings.ASSETS / vname if vname else None
        vbytes = vpath.stat().st_size if (vpath and vpath.is_file()) else 0
        return {
            "ok": 1,
            "settings": cfg,
            "video_bytes": vbytes,
            "has_ffmpeg": bool(settings.find_ffmpeg()),
        }

    def act_pick_video(self, data):
        p = dialogs.pick_video()
        if not p:
            return {"cancelled": True, "settings": settings.load()}
        quality = str((data or {}).get("quality") or settings.load().get("bg_video_quality") or "light")
        try:
            res = settings.set_video(p, quality=quality)
            res["ok"] = 1
            return res
        except Exception as e:
            return {"ok": 0, "error": str(e), "settings": settings.load()}

    def act_clear_video(self, data):
        cfg = settings.update({"bg_video": "", "bg_video_poster": ""})
        return {"ok": 1, "settings": cfg}
