"""Tính năng: PhotoCraft — Trình chỉnh sửa ảnh chuyên nghiệp (kiểu Photoshop, hỗ trợ PSD, Layer, Mask, Text, Filter)
chạy trực tiếp bên trong MyingGo qua WebAssembly. Nếu máy phụ chưa có bộ WebAssembly (~11.6 MB) thì tự tải về 1 lần."""
import io
import urllib.request
import zipfile
from pathlib import Path

from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
PC_DIR = ROOT / "web" / "photocraft"
WEB_RELEASE_URL = "https://github.com/storytold/photocraft/releases/download/v0.16.0/photocraft-web-0.16.0.zip"


def is_installed() -> bool:
    return (PC_DIR / "index.html").is_file() and (PC_DIR / "app" / "parts.txt").is_file()


def ensure_bridge():
    idx = PC_DIR / "index.html"
    if idx.is_file():
        txt = idx.read_text(encoding="utf-8")
        tag = '<script src="/web/artcraft_bridge.js"></script>'
        if tag not in txt and "<title>PhotoCraft</title>" in txt:
            idx.write_text(txt.replace("<title>PhotoCraft</title>", f"<title>PhotoCraft</title>\n  {tag}", 1), encoding="utf-8")


class PhotoCraft(Feature):
    title = "PhotoCraft"
    group = "ArtCraft"
    order = 12

    def act_status(self, data):
        if is_installed():
            ensure_bridge()
        return {"installed": is_installed(), "url": "/web/photocraft/index.html"}

    def act_open_window(self, data):
        if not is_installed():
            self.act_install(data)
        ensure_bridge()
        from core import server
        full_url = server.open_sub_window("/web/photocraft/index.html", fid="photocraft")
        return {"ok": 1, "url": full_url}

    def act_install(self, data):
        if is_installed():
            ensure_bridge()
            return {"ok": 1, "installed": True, "url": "/web/photocraft/index.html"}
        req = urllib.request.Request(WEB_RELEASE_URL, headers={"User-Agent": "MyingGo"})
        raw = urllib.request.urlopen(req, timeout=90).read()
        PC_DIR.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for m in z.infolist():
                if m.is_dir():
                    continue
                parts = m.filename.replace("\\", "/").split("/")
                rel = "/".join(parts[1:]) if len(parts) > 1 and parts[0].startswith("photocraft-web") else m.filename
                out = PC_DIR / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(z.read(m))
        ensure_bridge()
        return {"ok": 1, "installed": True, "url": "/web/photocraft/index.html"}
