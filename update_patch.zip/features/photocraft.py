"""Tính năng: PhotoCraft — Trình chỉnh sửa ảnh chuyên nghiệp (kiểu Photoshop, hỗ trợ PSD, Layer, Mask, Text, Filter, AI Generative Fill & Remove)
chạy trực tiếp bên trong MyingGo qua WebAssembly. Nếu máy phụ chưa có bộ WebAssembly (~11.6 MB) thì tự tải về 1 lần."""
import importlib
import io
import sys
import urllib.request
import zipfile
from pathlib import Path

from core import logger
from core.base import Feature

# Tự động nâng cấp nóng máy chủ (core.server & core.*) khi máy phụ tải bản cập nhật mà chưa tắt mở lại app
try:
    if "core.updater" in sys.modules:
        importlib.reload(sys.modules["core.updater"])
    from core import updater as _upd
    if hasattr(_upd, "hot_upgrade_runtime"):
        _upd.hot_upgrade_runtime()
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
PC_DIR = ROOT / "web" / "photocraft"
WEB_RELEASE_URL = "https://github.com/storytold/photocraft/releases/download/v0.16.0/photocraft-web-0.16.0.zip"


def is_installed() -> bool:
    return (PC_DIR / "index.html").is_file() and (PC_DIR / "app" / "parts.txt").is_file()


def ensure_bridge():
    idx = PC_DIR / "index.html"
    if idx.is_file():
        txt = idx.read_text(encoding="utf-8")
        tag = '<script src="/web/artcraft_bridge.js"></script>'
        if tag not in txt and "<title>PhotoCraft</title>" in txt:
            idx.write_text(txt.replace("<title>PhotoCraft</title>", f"<title>PhotoCraft</title>\n  {tag}", 1), encoding="utf-8")


class PhotoCraft(Feature):
    title = "PhotoCraft"
    group = "ArtCraft"
    order = 12

    def act_status(self, data):
        if is_installed():
            ensure_bridge()
        return {"installed": is_installed(), "url": "/web/photocraft/index.html"}

    def act_open_window(self, data):
        if not is_installed():
            self.act_install(data)
        ensure_bridge()
        from core import server
        full_url = server.open_sub_window("/web/photocraft/index.html", fid="photocraft")
        return {"ok": 1, "url": full_url}

    def act_ai_config(self, data):
        from core import ai_fill
        importlib.reload(ai_fill)
        if data and isinstance(data, dict) and data.get("save"):
            cfg = ai_fill.save_config(data.get("config") or data)
            logger.log_event("photocraft", "INFO", f"⚙️ Đã lưu cấu hình AI Generative Fill (Nguồn ưu tiên: {cfg.get('provider')})")
            return {"ok": 1, "config": cfg}
        return {"ok": 1, "config": ai_fill.load_config()}

    def act_ai_fill(self, data):
        from core import ai_fill
        importlib.reload(ai_fill)
        action = str((data or {}).get("action") or "fill")
        prompt = str((data or {}).get("prompt") or "").strip()
        provider = str((data or {}).get("provider") or "auto")
        logger.log_event(
            "photocraft",
            "INFO",
            f"✨ Bắt đầu AI {'Remove (Xóa vật thể)' if action == 'remove' else 'Generative Fill'} [Nguồn: {provider}]"
            + (f" — Prompt: \"{prompt}\"" if prompt else ""),
        )
        try:
            res = ai_fill.run_ai_edit(data or {})
            logger.log_event(
                "photocraft",
                "INFO",
                f"✅ Hoàn tất {res.get('engine')} trong {res.get('elapsed_s')}s -> Tạo Layer \"{res.get('layer_name')}\" ({res.get('doc_size')})",
            )
            return res
        except Exception as e:
            logger.log_event("photocraft", "ERROR", f"❌ Lỗi AI Generative Fill / Remove: {e}")
            return {"error": str(e)}

    def act_install(self, data):
        if is_installed():
            ensure_bridge()
            return {"ok": 1, "installed": True, "url": "/web/photocraft/index.html"}
        req = urllib.request.Request(WEB_RELEASE_URL, headers={"User-Agent": "MyingGo"})
        raw = urllib.request.urlopen(req, timeout=90).read()
        PC_DIR.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for m in z.infolist():
                if m.is_dir():
                    continue
                parts = m.filename.replace("\\", "/").split("/")
                rel = "/".join(parts[1:]) if len(parts) > 1 and parts[0].startswith("photocraft-web") else m.filename
                out = PC_DIR / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(z.read(m))
        ensure_bridge()
        return {"ok": 1, "installed": True, "url": "/web/photocraft/index.html"}
