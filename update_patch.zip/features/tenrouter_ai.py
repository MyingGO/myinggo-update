"""Tab riêng: 10Router AI Gateway — Kho API Key tập trung dùng chung cho mọi tính năng AI trong T2MG/MyingGo."""
import socket
from urllib.parse import urlparse

from core import ai_gateway
from core.base import Feature


def _is_port_open(url: str) -> bool:
    try:
        u = urlparse(url if "://" in url else f"http://{url}")
        host = u.hostname or "127.0.0.1"
        port = u.port or (443 if u.scheme == "https" else 80)
        with socket.create_connection((host, port), timeout=0.6):
            return True
    except Exception:
        return False


class TenRouterAI(Feature):
    title = "10Router AI"
    order = 997
    dock = "bottom"

    def act_get(self, data=None):
        pub = ai_gateway.public_config()
        pub["reachable"] = _is_port_open(pub["base_url"])
        return {"ok": 1, "gateway": pub}

    def act_save(self, data=None):
        d = data or {}
        patch = {}
        for k in ("enabled", "base_url", "model", "timeout_sec"):
            if k in d:
                patch[k] = d[k]
        if "api_keys" in d:
            patch["api_keys"] = d["api_keys"]
        if "direct_gemini_keys" in d:
            patch["direct_gemini_keys"] = d["direct_gemini_keys"]
        ai_gateway.save_config(patch)
        pub = ai_gateway.public_config()
        pub["reachable"] = _is_port_open(pub["base_url"])
        return {"ok": 1, "gateway": pub}

    def act_add_keys(self, data=None):
        d = data or {}
        raw = d.get("keys") or ""
        replace = bool(d.get("replace"))
        cfg = ai_gateway.load_config()
        new_keys = ai_gateway._parse_keys(raw)
        if not new_keys and not replace:
            return {"ok": 0, "error": "Chưa nhập API Key nào."}
        new_router = [k for k in new_keys if not ai_gateway.is_google_key(k)]
        new_google = [k for k in new_keys if ai_gateway.is_google_key(k)]
        if replace:
            ai_gateway.save_config({"api_keys": new_router, "direct_gemini_keys": new_google})
        else:
            ai_gateway.save_config({
                "api_keys": ai_gateway._parse_keys(list(cfg["api_keys"]) + new_router),
                "direct_gemini_keys": ai_gateway._parse_keys(list(cfg["direct_gemini_keys"]) + new_google),
            })
        pub = ai_gateway.public_config()
        pub["reachable"] = _is_port_open(pub["base_url"])
        return {"ok": 1, "gateway": pub}

    def act_remove_key(self, data=None):
        d = data or {}
        idx = int(d.get("index", -1))
        field = "direct_gemini_keys" if d.get("kind") == "google" else "api_keys"
        cfg = ai_gateway.load_config()
        keys = list(cfg[field])
        if 0 <= idx < len(keys):
            keys.pop(idx)
            ai_gateway.save_config({field: keys})
        pub = ai_gateway.public_config()
        pub["reachable"] = _is_port_open(pub["base_url"])
        return {"ok": 1, "gateway": pub}

    def act_clear_keys(self, data=None):
        ai_gateway.save_config({"api_keys": [], "direct_gemini_keys": []})
        pub = ai_gateway.public_config()
        pub["reachable"] = _is_port_open(pub["base_url"])
        return {"ok": 1, "gateway": pub}

    def act_models(self, data=None):
        d = data or {}
        try:
            models = ai_gateway.list_models(base_url=d.get("base_url"), api_key=d.get("api_key"))
            return {"ok": 1, "models": models}
        except Exception as e:
            return {"ok": 0, "error": str(e), "models": []}

    def act_test(self, data=None):
        d = data or {}
        return ai_gateway.test_connection(base_url=d.get("base_url"), api_key=d.get("api_key"), model=d.get("model"))

    def act_ask(self, data=None):
        d = data or {}
        q = str(d.get("prompt") or "").strip()
        if not q:
            return {"ok": 0, "error": "Hãy nhập câu hỏi."}
        try:
            reply, meta = ai_gateway.chat_text(q, model=d.get("model") or None)
            return {"ok": 1, "reply": reply, "meta": meta}
        except Exception as e:
            return {"ok": 0, "error": str(e)}
