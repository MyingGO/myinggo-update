"""Tính năng: FilmCraft — Phần mềm dựng phim chuyên nghiệp (kiểu Premiere / DaVinci: Timeline đa lớp, Chỉnh màu, Keyframe, Audio Mixer, Phụ đề, Xuất H.264/MP4)
chạy trực tiếp trong MyingGo hoặc mở màn hình riêng qua WebAssembly."""
import io
import urllib.request
import zipfile
from pathlib import Path

from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
FC_DIR = ROOT / "web" / "filmcraft"
WEB_RELEASE_URL = "https://github.com/storytold/filmcraft/releases/download/v0.13.0/filmcraft-web-0.13.0.zip"


def is_installed() -> bool:
    return (FC_DIR / "index.html").is_file()


def ensure_bridge():
    idx = FC_DIR / "index.html"
    if idx.is_file():
        txt = idx.read_text(encoding="utf-8")
        tag = '<script src="/web/artcraft_bridge.js"></script>'
        if tag not in txt and "<title>FilmCraft</title>" in txt:
            idx.write_text(txt.replace("<title>FilmCraft</title>", f"<title>FilmCraft</title>\n  {tag}", 1), encoding="utf-8")


class FilmCraft(Feature):
    title = "FilmCraft"
    group = "ArtCraft"
    order = 13

    def act_status(self, data):
        if is_installed():
            ensure_bridge()
        return {"installed": is_installed(), "url": "/web/filmcraft/index.html"}

    def act_open_window(self, data):
        if not is_installed():
            self.act_install(data)
        ensure_bridge()
        from core import server
        full_url = server.open_sub_window("/web/filmcraft/index.html", fid="filmcraft")
        return {"ok": 1, "url": full_url}

    def act_install(self, data):
        if is_installed():
            ensure_bridge()
            return {"ok": 1, "installed": True, "url": "/web/filmcraft/index.html"}
        req = urllib.request.Request(WEB_RELEASE_URL, headers={"User-Agent": "MyingGo"})
        raw = urllib.request.urlopen(req, timeout=120).read()
        FC_DIR.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for m in z.infolist():
                if m.is_dir():
                    continue
                parts = m.filename.replace("\\", "/").split("/")
                rel = "/".join(parts[1:]) if len(parts) > 1 and parts[0].startswith("filmcraft-web") else m.filename
                out = FC_DIR / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(z.read(m))
        ensure_bridge()
        return {"ok": 1, "installed": True, "url": "/web/filmcraft/index.html"}
