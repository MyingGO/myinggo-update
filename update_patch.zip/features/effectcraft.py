"""Tính năng: EffectCraft — Kỹ xảo & Đồ họa chuyển động (kiểu After Effects: Composition, 306 hiệu ứng VFX/Particle, 3D Camera & Light, Graph Editor, Expressions, Puppet, xuất Lottie/MP4)
chạy trực tiếp trong MyingGo hoặc mở màn hình riêng qua WebAssembly (chế độ WebGL2 chống treo GPU)."""
import io
import urllib.request
import zipfile
from pathlib import Path

from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
EC_DIR = ROOT / "web" / "effectcraft"
WEB_RELEASE_URL = "https://github.com/storytold/effectcraft/releases/download/v0.17.0/effectcraft-web-0.17.0.zip"
APP_URL = "/web/effectcraft/app.html?nosw&nogpuworkers"


def is_installed() -> bool:
    return (EC_DIR / "effectcraft_web_bg.wasm").is_file() and (EC_DIR / "app.html").is_file()


def apply_webgl_patch():
    """ Vá bộ EffectCraft Web để mặc định chạy WebGL2 + gỡ ServiceWorker cũ,
    tránh lỗi Dawn/D3D12 trên Windows biên dịch 300+ compute shaders làm đơ trình duyệt và báo 'The graphics device was lost'."""
    js_file = EC_DIR / "effectcraft_web.js"
    if js_file.is_file():
        txt = js_file.read_text(encoding="utf-8")
        old = "const ret = arg0.gpu;"
        new = "if (typeof location !== 'undefined' && !location.search.includes('webgpu')) return undefined;\n            const ret = arg0.gpu;"
        if old in txt and "location.search.includes('webgpu')" not in txt:
            js_file.write_text(txt.replace(old, new, 1), encoding="utf-8")

    for host_js in EC_DIR.rglob("host.js"):
        htxt = host_js.read_text(encoding="utf-8")
        hold = "return !!(self.navigator && self.navigator.gpu);"
        hnew = "if (typeof location !== 'undefined' && !location.search.includes('webgpu')) return false;\n  return !!(self.navigator && self.navigator.gpu);"
        if hold in htxt and "location.search.includes('webgpu')" not in htxt:
            host_js.write_text(htxt.replace(hold, hnew, 1), encoding="utf-8")

    sw_file = EC_DIR / "sw.js"
    sw_file.write_text(
        'self.addEventListener("install", () => self.skipWaiting());\n'
        'self.addEventListener("activate", (event) => {\n'
        '  event.waitUntil(caches.keys().then((ks) => Promise.all(ks.map((k) => caches.delete(k)))).then(() => self.registration.unregister()));\n'
        '});\n',
        encoding="utf-8",
    )

    idx = EC_DIR / "index.html"
    app = EC_DIR / "app.html"
    if idx.is_file() and not app.is_file():
        app.write_text(idx.read_text(encoding="utf-8"), encoding="utf-8")
    for html_f in (idx, app):
        if html_f.is_file():
            htxt = html_f.read_text(encoding="utf-8")
            tag = '<script src="/web/artcraft_bridge.js"></script>'
            if tag not in htxt and "<title>EffectCraft</title>" in htxt:
                html_f.write_text(htxt.replace("<title>EffectCraft</title>", f"<title>EffectCraft</title>\n  {tag}", 1), encoding="utf-8")


class EffectCraft(Feature):
    title = "EffectCraft"
    group = "ArtCraft"
    order = 14

    def act_status(self, data):
        if (EC_DIR / "effectcraft_web_bg.wasm").is_file():
            apply_webgl_patch()
        return {"installed": is_installed(), "url": APP_URL}

    def act_open_window(self, data):
        if not is_installed():
            self.act_install(data)
        from core import server
        full_url = server.open_sub_window(APP_URL, fid="effectcraft")
        return {"ok": 1, "url": full_url}

    def act_install(self, data):
        if is_installed():
            return {"ok": 1, "installed": True, "url": APP_URL}
        req = urllib.request.Request(WEB_RELEASE_URL, headers={"User-Agent": "MyingGo"})
        raw = urllib.request.urlopen(req, timeout=180).read()
        EC_DIR.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for m in z.infolist():
                if m.is_dir():
                    continue
                parts = m.filename.replace("\\", "/").split("/")
                rel = "/".join(parts[1:]) if len(parts) > 1 and parts[0].startswith("effectcraft-web") else m.filename
                out = EC_DIR / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(z.read(m))
        apply_webgl_patch()
        return {"ok": 1, "installed": True, "url": APP_URL}
