"""Tính năng: Thumbnail Studio (tích hợp từ 3T Master).

Engine gốc (Gemini Studio v13.54 - PySide6/Selenium) nằm ở addons/thumbnail_studio và chạy ẩn ở
một tiến trình riêng. web_engine_bridge.py mở JSON-RPC nội bộ (127.0.0.1 + token); file này chỉ
khởi động/dừng engine và chuyển lệnh từ giao diện MyingGo sang engine.

Gồm 4 mảng: Thumbnail (Queue), Kho tài khoản Google, Description Studio, Brand (tên kênh + logo).
"""
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

from core import dialogs
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
ADDON_DIR = ROOT / "addons" / "thumbnail_studio"
BRIDGE_FILE = ADDON_DIR / "web_engine_bridge.py"
DASH_FILE = ADDON_DIR / "hybrid_flow_gemini_dashboard.py"
VERSION_FILE = ADDON_DIR / "app_version.json"
ENGINE_INFO_FILE = ADDON_DIR / ".myinggo_web_engine.json"

_LOCAL = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home()))
PERSIST_ROOT = Path(os.environ.get("THUMB_STUDIO_PERSIST_ROOT") or (_LOCAL / "MyingGo" / "ThumbnailStudio"))
LEGACY_3T_ROOT = _LOCAL / "HDMaster" / "ThumbnailStudio"


def _is_file(p):
    try:
        return Path(p).is_file()
    except OSError:
        return False
ENGINE_LOG_FILE = PERSIST_ROOT / "web_engine.log"
LIVE_LOG_FILE = PERSIST_ROOT / "thumbnail_studio_live.log"
FATAL_LOG_FILE = PERSIST_ROOT / "thumbnail_studio_fatal.log"
PREVIEW_DIR = PERSIST_ROOT / "preview_cache"

REQUIRED_MODULES = ["PySide6", "selenium", "PIL", "requests", "psutil"]
CONFIG_FILE = ROOT / "thumbnail_studio_config.json"          # API key + tuỳ chọn (chỉ máy này, không đóng gói)
REMOVED_ACC_FILE = PERSIST_ROOT / "myinggo_removed_accounts.json"  # email tài khoản lỗi đã xoá -> tự loại khi nhập lại
OPTIONS_FILE = PERSIST_ROOT / "myinggo_thumb_options.json"     # bản tuỳ chọn cho worker đọc (không chứa key)
DEFAULT_CFG = {
    "api_keys": [],
    "api_model": "gemini-2.5-flash-image",
    "api_mode": "auto",          # auto = tự chuyển khi tài khoản web bị giới hạn • only = chỉ dùng API • off
    "api_workers": 3,
    "variation": 30,             # % khác ảnh gốc
    "remove_logos": True,        # thêm yêu cầu xoá logo không liên quan vào prompt
    "folders": {},               # {thư mục: {"style": "...", "variation": 40}}
}
PIP_PACKAGES = ["PySide6>=6.8,<7", "selenium==4.33.0", "Pillow", "requests", "psutil", "pyperclip",
                "undetected-chromedriver==3.5.5", "selenium-stealth==1.0.6"]
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
LONG_ACTIONS = {
    "accounts.login_all", "accounts.login", "accounts.check_all", "accounts.check",
    "description.rewrite", "description.rewrite_http", "description.translate_selected",
    "description.restore_all", "brand.generate_names", "brand.more_names",
    "brand.generate_logos", "brand.swap_logo", "accounts.import_txt", "accounts.import_text",
}
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _acc_failed(a):
    """Tài khoản lỗi / không đăng nhập được (đã kiểm tra hoặc đã thử đăng nhập mà không READY)."""
    if not isinstance(a, dict) or a.get("ok") or a.get("checking"):
        return False
    cr = str(a.get("check_result") or "").strip().lower()
    if cr and cr != "ok":
        return True
    st = str(a.get("status") or "").strip().lower()
    if not st or "chưa kiểm tra" in st or st.startswith("đang") or "đang kiểm tra" in st or "đang đăng nhập" in st:
        return False
    return True


def _removed_load():
    try:
        d = json.loads(REMOVED_ACC_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d.get("emails"), dict) else {"emails": {}}
    except Exception:
        return {"emails": {}}


def _removed_save(d):
    REMOVED_ACC_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = REMOVED_ACC_FILE.with_name(REMOVED_ACC_FILE.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, REMOVED_ACC_FILE)


def _filter_removed_lines(text, removed_emails):
    """Bỏ các dòng có email nằm trong danh sách tài khoản lỗi đã xoá. Trả (text_mới, [email bị loại])."""
    keep, dropped = [], []
    for line in str(text or "").splitlines():
        email = line.split("\t", 1)[0].strip().lower()
        if email and email in removed_emails:
            dropped.append(email)
            continue
        keep.append(line)
    return "\n".join(keep), dropped


def _bridge_build():
    import re
    try:
        raw = BRIDGE_FILE.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r'^WEB_BRIDGE_BUILD\s*=\s*["\']([^"\']+)["\']', raw, re.M)
        if m:
            return m.group(1).strip()
    except Exception:
        pass
    return "?"


def _read_version():
    try:
        return str(json.loads(VERSION_FILE.read_text(encoding="utf-8-sig")).get("version") or "?")
    except Exception:
        return "?"


def _pid_alive(pid):
    pid = int(pid or 0)
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
            if h:
                code = ctypes.c_ulong()
                ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
                k32.CloseHandle(h)
                return bool(ok) and code.value == 259  # STILL_ACTIVE
            return ctypes.GetLastError() == 5  # bị từ chối truy cập = tiến trình vẫn tồn tại
        except Exception:
            pass
    try:
        if os.name == "nt":
            cp = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                                capture_output=True, text=True, timeout=4, creationflags=_NOWIN)
            out = (cp.stdout or "").lower()
            return str(pid) in out and "no tasks" not in out
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _http_json(url, token, payload=None, timeout=10.0):
    headers = {"X-Thumb-Token": token}
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method="POST" if data else "GET")
    try:
        with urllib.request.urlopen(req, timeout=max(0.5, float(timeout))) as r:
            return json.loads(r.read().decode("utf-8", "replace") or "{}")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        try:
            msg = json.loads(body).get("error") or body
        except Exception:
            msg = body
        raise RuntimeError(f"Engine HTTP {exc.code}: {msg}")


def _python_for_engine():
    """Python dùng chạy engine: ưu tiên python.exe (không phải pythonw) cùng thư mục."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").is_file():
        return str(exe.parent / "python.exe")
    return str(exe)


def _open_in_explorer(folder):
    folder = Path(folder)
    if not folder.exists():
        raise RuntimeError(f"Thư mục không tồn tại: {folder}")
    if os.name == "nt":
        subprocess.Popen(["explorer.exe", str(folder)])


class ThumbnailStudio(Feature):
    title = "Thumbnail Studio"
    order = 12

    def __init__(self):
        super().__init__()
        self._elock = threading.RLock()
        self._install_proc = None
        self._cfg_lock = threading.RLock()
        self._run_requested = False       # người dùng đã bấm Chạy Queue (để biết có cần tự chuyển sang API)
        self._limited_hits = 0
        self._monitor_started = False
        self._api_stop = threading.Event()
        self._api = {"running": False, "phase": "idle", "total": 0, "done": 0, "failed": 0, "current": [],
                     "message": "Sẵn sàng", "trigger": "", "errors": [], "keys": [], "started_at": 0}
        self._api_client = None
        self._logo = {"running": False, "phase": "idle", "total": 0, "done": 0, "message": "", "items": {}}
        self._logo_stop = threading.Event()

    # ------------------------------------------------------------------ engine
    def _info(self, validate=True):
        try:
            info = json.loads(ENGINE_INFO_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
        pid, port, token = int(info.get("pid") or 0), int(info.get("port") or 0), str(info.get("token") or "")
        if not (pid and port and token) or not _pid_alive(pid):
            ENGINE_INFO_FILE.unlink(missing_ok=True)
            return {}
        if str(info.get("build") or "") != _bridge_build():
            self._kill(info)
            return {}
        if validate:
            try:
                h = _http_json(f"http://127.0.0.1:{port}/health", token, timeout=1.5)
                if not h.get("ok"):
                    return {}
            except Exception:
                return {}
        return info

    def _kill(self, info):
        pid = int((info or {}).get("pid") or 0)
        if pid and _pid_alive(pid):
            try:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=8, creationflags=_NOWIN)
                else:
                    os.kill(pid, 15)
            except Exception:
                pass
        ENGINE_INFO_FILE.unlink(missing_ok=True)

    def _missing_modules(self):
        code = ("import importlib.util as u;print(','.join(m for m in %r if u.find_spec(m) is None))" % REQUIRED_MODULES)
        cp = subprocess.run([_python_for_engine(), "-c", code], capture_output=True, text=True, timeout=20, creationflags=_NOWIN)
        return [x for x in (cp.stdout or "").strip().split(",") if x]

    def _start(self):
        with self._elock:
            info = self._info()
            if info:
                return info
            if not BRIDGE_FILE.is_file() or not DASH_FILE.is_file():
                raise RuntimeError(f"Thiếu engine trong {ADDON_DIR}")
            missing = self._missing_modules()
            if missing:
                raise RuntimeError("Thiếu thư viện: " + ", ".join(missing) + ". Vào tab ⚙ Hệ thống → bấm 'Cài thư viện'.")
            PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
            ENGINE_INFO_FILE.unlink(missing_ok=True)
            env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", THUMBNAIL_WEB_MODE="1",
                       THUMB_STUDIO_PERSIST_ROOT=str(PERSIST_ROOT), MYINGGO_ADDON_DIR=str(ADDON_DIR),
                       MYINGGO_THUMB_OPTIONS=str(OPTIONS_FILE))
            self._write_options(self._cfg())
            marker = f"===== MYINGGO ENGINE START {time.strftime('%Y-%m-%d %H:%M:%S')} ====="
            log_f = open(ENGINE_LOG_FILE, "a", encoding="utf-8", buffering=1)
            log_f.write("\n" + marker + "\n")
            kw = {"cwd": str(ADDON_DIR), "env": env, "stdout": log_f, "stderr": log_f}
            if os.name == "nt":
                kw["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | _NOWIN
            proc = subprocess.Popen([_python_for_engine(), "-u", str(BRIDGE_FILE),
                                     "--info-file", str(ENGINE_INFO_FILE), "--port", "0"], **kw)
            self.log(f"Đang khởi động engine Thumbnail Studio (pid={proc.pid})…")
            deadline = time.time() + 40
            while time.time() < deadline:
                if proc.poll() is not None:
                    break
                info = self._info()
                if info:
                    self.log(f"Engine sẵn sàng • v{_read_version()} • port={info.get('port')}")
                    return info
                time.sleep(0.25)
            tail = ""
            try:
                lines = ENGINE_LOG_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
                idx = max((i for i, l in enumerate(lines) if marker in l), default=0)
                tail = "\n".join(lines[idx:][-30:])
            except Exception:
                pass
            raise RuntimeError("Không khởi động được engine Thumbnail Studio.\n" + tail[-3000:])

    def _rpc(self, action, args=None, timeout=30.0, autostart=True):
        info = self._info()
        if not info and autostart:
            info = self._start()
        if not info:
            raise RuntimeError("Engine chưa chạy")
        data = _http_json(f"http://127.0.0.1:{int(info['port'])}/rpc", str(info["token"]),
                          payload={"action": action, "args": args or {}, "timeout": float(timeout)},
                          timeout=timeout + 3)
        if not data.get("ok"):
            raise RuntimeError(str(data.get("error") or "Engine error"))
        return data.get("result")

    # ------------------------------------------------------------------ API
    def act_status(self, data):
        info = self._info(validate=False)
        return {
            "installed": BRIDGE_FILE.is_file() and DASH_FILE.is_file(),
            "running": bool(info),
            "pid": info.get("pid") if info else None,
            "version": _read_version(),
            "build": _bridge_build(),
            "addon_dir": str(ADDON_DIR),
            "persist_root": str(PERSIST_ROOT),
            "python": _python_for_engine(),
            "has_3t_data": _is_file(LEGACY_3T_ROOT / "account_warehouse_v12.json"),
            "installing": bool(self._install_proc and self._install_proc.poll() is None),
        }

    def act_start_engine(self, data):
        try:
            info = self._start()
            return {"ok": 1, "pid": info.get("pid")}
        except Exception as e:
            self.log(f"[LỖI] {e}")
            return {"error": str(e)}

    def act_stop_engine(self, data):
        with self._elock:
            info = self._info(validate=False)
            if not info:
                return {"ok": 1, "already": 1}
            try:
                self._rpc("shutdown", {}, timeout=4, autostart=False)
            except Exception:
                pass
            pid = int(info.get("pid") or 0)
            end = time.time() + 5
            while _pid_alive(pid) and time.time() < end:
                time.sleep(0.15)
            self._kill(info)
            self.log("Đã dừng engine Thumbnail Studio")
            return {"ok": 1}

    def act_snapshot(self, data):
        extra = {"mg_api": self._api_public(), "mg_logo": self._logo_public()}
        if not self._info(validate=False) and not data.get("autostart"):
            return {"engine_off": True, **extra}
        try:
            res = self._rpc("snapshot", {
                "job_limit": int(data.get("job_limit") or 1400),
                "desc_limit": int(data.get("desc_limit") or 1200),
                "log_limit": int(data.get("log_limit") or 260),
            }, timeout=15, autostart=bool(data.get("autostart")))
            if isinstance(res, dict):
                res.update(extra)
                for a in res.get("accounts") or []:
                    if isinstance(a, dict):
                        a["failed"] = _acc_failed(a)
                res["mg_removed_count"] = len(_removed_load()["emails"])
            return res
        except Exception as e:
            return {"error": str(e), **extra}

    def act_action(self, data):
        action = str(data.get("action") or "").strip()
        if not action:
            return {"error": "Thiếu action"}
        args = data.get("args") or {}
        timeout = 75 if action in LONG_ACTIONS else 30
        if action == "queue.start":
            cfg = self._cfg()
            self._run_requested = True
            self._limited_hits = 0
            self._ensure_monitor()
            if cfg.get("api_mode") == "only":
                r = self.act_api_run({"scope": "all", "trigger": "Chế độ chỉ dùng API"})
                return r if r.get("error") else {"ok": 1, "api": True}
        if action == "queue.stop":
            self._run_requested = False
            self._api_stop.set()
        dropped = []
        if action in ("accounts.import_txt", "accounts.import_text"):
            removed = _removed_load()["emails"]
            if removed:
                if action == "accounts.import_txt":
                    try:
                        text = Path(str(args.get("path") or "")).read_text(encoding="utf-8-sig", errors="ignore")
                    except Exception as e:
                        return {"error": f"Không đọc được file TXT: {e}"}
                else:
                    text = str(args.get("text") or "")
                text, dropped = _filter_removed_lines(text, removed)
                if dropped:
                    self.log(f"[Kho] Tự loại {len(dropped)} tài khoản lỗi đã xoá trước đó khi nhập")
                    if not text.strip():
                        return {"error": f"Tất cả {len(dropped)} tài khoản trong danh sách đều là tài khoản lỗi đã xoá trước đó — không còn gì để nhập."}
                    action, args = "accounts.import_text", {**args, "text": text}
                    args.pop("path", None)
        try:
            res = self._rpc(action, args, timeout=timeout)
            if action not in ("snapshot", "ping"):
                self.log(f"[OK] {action}")
            res = res if isinstance(res, dict) else {"ok": 1, "result": res}
            if dropped:
                res["dropped_removed"] = len(dropped)
                res["dropped_emails"] = dropped[:30]
            return res
        except Exception as e:
            self.log(f"[LỖI] {action}: {e}")
            return {"error": str(e)}

    # ---- hộp thoại / thư mục
    # ------------------------------------------------------------------ tài khoản lỗi
    def act_accounts_purge_failed(self, data):
        try:
            snap = self._rpc("snapshot", {"job_limit": 1, "desc_limit": 1, "log_limit": 1}, timeout=15, autostart=False)
        except Exception as e:
            return {"error": f"Engine chưa chạy: {e}"}
        accs = [a for a in (snap or {}).get("accounts") or [] if _acc_failed(a)]
        want = {int(x) for x in (data.get("account_nos") or [])}
        if want:
            accs = [a for a in accs if int(a.get("account_no") or 0) in want]
        if not accs:
            return {"ok": 1, "removed": 0, "message": "Không có tài khoản lỗi nào"}
        if snap.get("running") or snap.get("queue_running"):
            return {"error": "Queue đang chạy — bấm Dừng trước khi xoá tài khoản"}
        status_of = {int(a["account_no"]): str(a.get("status") or a.get("check_result") or "") for a in accs}
        try:
            r = self._rpc("accounts.remove_many", {"account_nos": sorted(status_of)}, timeout=30, autostart=False)
            removed = (r or {}).get("removed") or []
        except Exception as e:
            if "Unknown action" not in str(e):
                return {"error": str(e)}
            # Fallback tương thích ngay với tiến trình engine đang chạy (không cần tắt/bật lại engine)
            removed = []
            for a in accs:
                acc_no = int(a["account_no"])
                try:
                    self._rpc("accounts.remove", {"account_no": acc_no}, timeout=15, autostart=False)
                    removed.append({"account_no": acc_no, "email": str(a.get("email") or "")})
                except Exception as ex:
                    return {"error": f"Lỗi khi xoá A{acc_no}: {ex}"}
        bl = _removed_load()
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for x in removed:
            e = str(x.get("email") or "").strip().lower()
            if e:
                bl["emails"][e] = {"removed_at": now, "reason": status_of.get(int(x["account_no"]), "")[:160]}
        _removed_save(bl)
        self.log(f"[Kho] Đã xoá {len(removed)} tài khoản lỗi • danh sách tự loại: {len(bl['emails'])} email")
        return {"ok": 1, "removed": len(removed), "blacklist": len(bl["emails"])}

    def act_removed_accounts(self, data):
        bl = _removed_load()
        if data.get("clear"):
            bl = {"emails": {}}
            _removed_save(bl)
        for e in data.get("unban") or []:
            bl["emails"].pop(str(e).strip().lower(), None)
        if data.get("unban"):
            _removed_save(bl)
        items = [{"email": k, **(v if isinstance(v, dict) else {})} for k, v in bl["emails"].items()]
        items.sort(key=lambda x: x.get("removed_at") or "", reverse=True)
        return {"ok": 1, "items": items, "count": len(items)}

    def act_pick_folder(self, data):
        return {"path": dialogs.pick_dir(data.get("title") or "Chọn thư mục")}

    def act_pick_image(self, data):
        return {"path": dialogs.pick_image()}

    def act_pick_txt(self, data):
        return {"path": dialogs.pick_txt()}

    def act_open_folder(self, data):
        try:
            p = Path(str(data.get("path") or ""))
            _open_in_explorer(p if p.is_dir() else p.parent)
            return {"ok": 1}
        except Exception as e:
            return {"error": str(e)}

    def act_open_logs(self, data):
        PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
        _open_in_explorer(PERSIST_ROOT)
        return {"ok": 1}

    def act_engine_log(self, data):
        lim = max(20, min(2000, int(data.get("lines") or 200)))
        chunks = []
        for label, p in (("LIVE", LIVE_LOG_FILE), ("FATAL", FATAL_LOG_FILE), ("ENGINE", ENGINE_LOG_FILE)):
            if p.is_file():
                lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
                if lines:
                    chunks.append(f"===== {label}: {p} =====\n" + "\n".join(lines[-lim:]))
        return {"text": "\n\n".join(chunks) or "(chưa có log)"}

    # ---- môi trường Python
    def act_runtime_check(self, data):
        try:
            missing = self._missing_modules()
            cp = subprocess.run([_python_for_engine(), "--version"], capture_output=True, text=True, timeout=10, creationflags=_NOWIN)
            return {"python": _python_for_engine(), "python_version": (cp.stdout or cp.stderr).strip(),
                    "missing": missing, "ok": not missing}
        except Exception as e:
            return {"error": str(e)}

    def act_install_deps(self, data):
        if self._install_proc and self._install_proc.poll() is None:
            return {"error": "Đang cài thư viện"}
        self.clear_log()

        def job():
            self.log("Cài thư viện cho Thumbnail Studio vào " + _python_for_engine())
            self._install_proc = subprocess.Popen(
                [_python_for_engine(), "-m", "pip", "install", "--disable-pip-version-check", *PIP_PACKAGES],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                creationflags=_NOWIN)
            for line in self._install_proc.stdout:
                line = line.rstrip()
                if line:
                    self.log(line)
            rc = self._install_proc.wait()
            self.log("✅ Cài xong" if rc == 0 else f"[LỖI] pip trả mã {rc}")

        self.run_bg(job)
        return {"ok": 1}

    # ---- nhập dữ liệu kho từ 3T Master
    def act_import_3t(self, data):
        src_files = ["account_warehouse_v12.json", "queue_sources_v14.json", "account_ready_state_v53.json"]
        if not _is_file(LEGACY_3T_ROOT / src_files[0]):
            return {"error": f"Không thấy kho tài khoản 3T Master tại {LEGACY_3T_ROOT}"}
        was_running = bool(self._info(validate=False))
        if was_running:
            self.act_stop_engine({})
        PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
        copied = []
        for name in src_files:
            s, d = LEGACY_3T_ROOT / name, PERSIST_ROOT / name
            if s.is_file():
                if d.is_file():
                    shutil.copy2(d, d.with_name(d.stem + f".bak_{time.strftime('%Y%m%d_%H%M%S')}" + d.suffix))
                shutil.copy2(s, d)
                copied.append(name)
        self.log(f"Đã nhập từ 3T Master: {', '.join(copied)}")
        return {"ok": 1, "copied": copied, "restart": was_running}

    # ---- phục vụ ảnh xem trước (GET /api/thumbnail_studio/file?path=...&w=...)
    def serve_file(self, query):
        raw = (query.get("path") or [""])[0]
        p = Path(raw)
        if not raw or not p.is_file() or p.suffix.lower() not in IMAGE_EXT:
            return None
        try:
            w = int((query.get("w") or ["0"])[0] or 0)
        except Exception:
            w = 0
        if w <= 0:
            ctype = "image/png" if p.suffix.lower() == ".png" else "image/jpeg"
            return p.read_bytes(), ctype
        w = max(64, min(1280, w))
        st = p.stat()
        key = hashlib.sha1(f"{p.resolve()}|{st.st_mtime_ns}|{st.st_size}|{w}".encode("utf-8")).hexdigest()
        PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
        cache = PREVIEW_DIR / f"{key}.jpg"
        if not cache.is_file():
            from PIL import Image
            with Image.open(p) as im:
                im = im.convert("RGB")
                im.thumbnail((w, w * 2))
                buf = io.BytesIO()
                im.save(buf, "JPEG", quality=82)
            cache.write_bytes(buf.getvalue())
        return cache.read_bytes(), "image/jpeg"

    # ================================================================== CẤU HÌNH
    def _cfg(self):
        with self._cfg_lock:
            cfg = json.loads(json.dumps(DEFAULT_CFG))
            try:
                if CONFIG_FILE.is_file():
                    cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
            except Exception:
                pass
            if not cfg.get("api_keys"):
                try:  # dùng lại Gemini key đã nhập ở công cụ AI khác của MyingGo (nếu có)
                    k = json.loads((ROOT / "ai_fill_config.json").read_text(encoding="utf-8")).get("gemini_key", "")
                    if k:
                        cfg["api_keys"] = [k]
                except Exception:
                    pass
            return cfg

    def _write_options(self, cfg):
        try:
            PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
            opts = {"variation": cfg.get("variation", 30), "remove_logos": bool(cfg.get("remove_logos", True)),
                    "folders": cfg.get("folders") or {}}
            OPTIONS_FILE.write_text(json.dumps(opts, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            self.log(f"[LỖI] Không ghi được tuỳ chọn cho worker: {e}")

    def act_get_config(self, data):
        cfg = self._cfg()
        keys = cfg.pop("api_keys", [])
        cfg["keys_masked"] = [k[:6] + "…" + k[-4:] if len(k) > 12 else "***" for k in keys]
        cfg["keys_count"] = len(keys)
        cfg["image_models"] = ["gemini-2.5-flash-image", "gemini-3-pro-image-preview"]
        return cfg

    def act_save_config(self, data):
        with self._cfg_lock:
            cfg = self._cfg()
            for k in ("api_model", "api_mode"):
                if k in data:
                    cfg[k] = str(data[k])
            if "api_workers" in data:
                cfg["api_workers"] = max(1, min(25, int(data["api_workers"] or 5)))
            if "variation" in data:
                cfg["variation"] = max(0, min(100, int(data["variation"] or 0)))
            if "remove_logos" in data:
                cfg["remove_logos"] = bool(data["remove_logos"])
            if "new_keys" in data:
                new = [x.strip() for x in str(data["new_keys"] or "").replace(",", "\n").splitlines() if x.strip()]
                if data.get("replace_keys"):
                    cfg["api_keys"] = new
                else:
                    cfg["api_keys"] = list(dict.fromkeys((cfg.get("api_keys") or []) + new))
            if data.get("clear_keys"):
                cfg["api_keys"] = []
            if "folder" in data:  # cấu hình riêng 1 thư mục
                folder = str(data["folder"] or "").strip()
                if folder:
                    fcfg = {"style": str(data.get("style") or "").strip()}
                    v = data.get("folder_variation")
                    if v not in (None, ""):
                        fcfg["variation"] = max(0, min(100, int(v)))
                    folders = dict(cfg.get("folders") or {})
                    if not fcfg["style"] and "variation" not in fcfg:
                        folders.pop(folder, None)
                    else:
                        folders[folder] = fcfg
                    cfg["folders"] = folders
            CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            self._write_options(cfg)
            self._api_client = None
        return self.act_get_config({})

    def act_test_key(self, data):
        api = self._client(force=True)
        if not api.keys:
            return {"error": "Chưa có API key"}
        try:
            from PIL import Image
            buf = io.BytesIO()
            Image.new("RGB", (64, 36), (40, 60, 120)).save(buf, "PNG")
            items = api.detect_logos(buf.getvalue(), mime="image/png")
            return {"ok": 1, "message": f"Key hoạt động ({len(api.keys)} key) • phát hiện {len(items)} logo trên ảnh thử", "keys": api.key_status()}
        except Exception as e:
            return {"error": str(e), "keys": api.key_status()}

    # ================================================================== GEMINI API
    def _apimod(self):
        if str(ADDON_DIR) not in sys.path:
            sys.path.insert(0, str(ADDON_DIR))
        import importlib
        import myinggo_gemini_api as m
        import myinggo_thumb_opts as o
        return m, o

    def _client(self, force=False):
        m, _ = self._apimod()
        if self._api_client is None or force:
            cfg = self._cfg()
            self._api_client = m.GeminiAPI(cfg.get("api_keys"), cfg.get("api_model"), log=self.log)
        return self._api_client

    def _api_public(self):
        st = dict(self._api)
        st["current"] = list(st.get("current") or [])[-12:]
        st["errors"] = list(st.get("errors") or [])[-30:]
        if self._api_client is not None:
            st["keys"] = self._api_client.key_status()
        st["run_requested"] = self._run_requested
        return st

    def _queues(self):
        snap = self._rpc("snapshot", {"job_limit": 1, "desc_limit": 1, "log_limit": 20}, timeout=15)
        return [q for q in (snap.get("queues") or []) if q.get("root")]

    def act_api_status(self, data):
        return self._api_public()

    def act_api_stop(self, data):
        self._api_stop.set()
        return {"ok": 1}

    def act_api_run(self, data):
        if self._api.get("running"):
            return {"error": "API đang chạy"}
        cfg = self._cfg()
        if not cfg.get("api_keys"):
            return {"error": "Chưa nhập Gemini API key (tab 🔑 API & Tuỳ chọn)"}
        m, _ = self._apimod()
        scope = data.get("scope", "all")
        try:
            queues = self._queues()
        except Exception as e:
            return {"error": f"Không đọc được Queue: {e}"}
        if isinstance(scope, int) or str(scope).isdigit():
            queues = [q for q in queues if int(q.get("index", -1)) == int(scope)]
        jobs = m.scan_pending(queues)
        if data.get("paths"):
            want = {os.path.normcase(str(p)) for p in data["paths"]}
            jobs = [j for j in jobs if os.path.normcase(j["path"]) in want]
        if not jobs:
            return {"error": "Không còn ảnh nào cần vẽ (các ảnh > 1.5MB được coi là đã vẽ xong)"}
        self._api_stop.clear()
        self._api.update(running=True, phase="running", total=len(jobs), done=0, failed=0, current=[], errors=[],
                         message=f"Đang vẽ {len(jobs)} ảnh bằng Gemini API", trigger=str(data.get("trigger") or "Thủ công"),
                         started_at=time.time())
        threading.Thread(target=self._api_worker_main, args=(jobs, cfg), daemon=True, name="TS-API").start()
        return {"ok": 1, "jobs": len(jobs)}

    def _api_worker_main(self, jobs, cfg):
        m, o = self._apimod()
        api = self._client(force=True)
        opts_all = {"variation": cfg.get("variation", 30), "remove_logos": cfg.get("remove_logos", True), "folders": cfg.get("folders") or {}}
        q = list(jobs)
        lock = threading.Lock()
        exhausted = threading.Event()
        self.log(f"[API] BẮT ĐẦU • {len(jobs)} ảnh • model={api.image_model} • {len(api.keys)} key • lý do: {self._api['trigger']}")

        def worker(wid):
            while not self._api_stop.is_set() and not exhausted.is_set():
                with lock:
                    if not q:
                        return
                    job = q.pop(0)
                    self._api["current"].append(Path(job["path"]).parent.name + "/" + Path(job["path"]).name)
                p = Path(job["path"])
                try:
                    if p.stat().st_size > 1.5 * 1048576:  # worker web đã vẽ xong trong lúc chờ
                        raise FileExistsError("đã được vẽ")
                    prompt = o.build_prompt(m_base_prompt(), str(p), o.options_for(str(p), opts_all))
                    src = p.read_bytes()
                    mime = "image/png" if p.suffix.lower() == ".png" else "image/jpeg"
                    out = api.edit_image(src, prompt, mime=mime)
                    info = m.finalize_thumbnail(out, p, job.get("logo") or "")
                    with lock:
                        self._api["done"] += 1
                    self.log(f"[API W{wid}] OK • {p.parent.name}/{p.name} • {info['width']}x{info['height']} • {info['size_mb']}MB")
                except FileExistsError:
                    with lock:
                        self._api["done"] += 1
                except m.KeysExhausted as e:
                    with lock:
                        q.insert(0, job)
                    exhausted.set()
                    self.log(f"[API] DỪNG • {e}")
                    self._api["message"] = f"Hết lượt toàn bộ API key • {str(e)[:160]}"
                except Exception as e:
                    with lock:
                        self._api["failed"] += 1
                        self._api["errors"].append({"path": str(p), "error": str(e)[:300]})
                    self.log(f"[API W{wid}] LỖI • {p.parent.name}/{p.name} • {e}")
                finally:
                    with lock:
                        name = p.parent.name + "/" + p.name
                        if name in self._api["current"]:
                            self._api["current"].remove(name)

        threads = [threading.Thread(target=worker, args=(i + 1,), daemon=True) for i in range(max(1, min(int(cfg.get("api_workers") or 5), len(jobs))))]
        for t in threads:
            t.start()
            time.sleep(0.1)
        for t in threads:
            t.join()
        st = self._api
        if self._api_stop.is_set():
            st["message"] = f"Đã dừng • xong {st['done']}/{st['total']} • lỗi {st['failed']}"
        elif not exhausted.is_set():
            st["message"] = f"Hoàn tất • xong {st['done']}/{st['total']} • lỗi {st['failed']}"
        st.update(running=False, phase="idle", current=[])
        self.log(f"[API] KẾT THÚC • {st['message']}")
        try:  # cho engine quét lại để các ảnh đã vẽ hiện "Bỏ qua/xong"
            if self._info(validate=False):
                self._rpc("queue.scan", {}, timeout=20, autostart=False)
        except Exception:
            pass

    # ---- tự chuyển sang API khi tài khoản web bị giới hạn
    def _ensure_monitor(self):
        if self._monitor_started:
            return
        self._monitor_started = True
        threading.Thread(target=self._monitor_loop, daemon=True, name="TS-API-Monitor").start()

    def _monitor_loop(self):
        while True:
            time.sleep(8)
            try:
                self._monitor_tick()
            except Exception as e:
                self.log(f"[API-monitor] {e}")

    def _monitor_tick(self):
        if not self._run_requested or self._api.get("running"):
            self._limited_hits = 0
            return
        cfg = self._cfg()
        if cfg.get("api_mode") != "auto" or not cfg.get("api_keys") or not self._info(validate=False):
            return
        s = self._rpc("snapshot", {"job_limit": 5000, "desc_limit": 1, "log_limit": 20}, timeout=15, autostart=False)
        stats, accs, pl = s.get("stats") or {}, s.get("accounts") or [], s.get("prelogin") or {}
        pending = sum(1 for j in (s.get("jobs") or []) if j.get("status") in ("queued", "reserved", "error"))
        if pending == 0:
            if not (s.get("running") or s.get("queue_running")):
                self._run_requested = False
            self._limited_hits = 0
            return
        usable = [a for a in accs if a.get("ok") and not a.get("quota_hold")]
        held = [a for a in accs if a.get("quota_hold")]
        busy_login = bool(pl.get("running")) or bool(s.get("accounts_checking_all"))
        idle = not (s.get("running") or s.get("queue_running")) and int(stats.get("running") or 0) == 0
        limited = (not accs) or (accs and len(held) == len(accs)) or (not usable and idle and not busy_login)
        self._limited_hits = self._limited_hits + 1 if limited else 0
        if self._limited_hits >= 2:
            why = "Kho không có tài khoản" if not accs else (f"{len(held)}/{len(accs)} tài khoản hết quota" if held else "Không còn tài khoản READY")
            self.log(f"[API] TỰ CHUYỂN SANG GEMINI API • {why} • còn {pending} ảnh")
            try:
                self._rpc("queue.stop", {}, timeout=30, autostart=False)
            except Exception:
                pass
            time.sleep(3)
            self._limited_hits = 0
            r = self.act_api_run({"scope": "all", "trigger": why})
            if r.get("error"):
                self.log(f"[API] Không chuyển được: {r['error']}")
            self._run_requested = False

    # ================================================================== QUÉT & XOÁ LOGO
    def _logo_public(self):
        st = dict(self._logo)
        st["items"] = list(self._logo["items"].values())
        return st

    def act_logo_state(self, data):
        return self._logo_public()

    def act_logo_stop(self, data):
        self._logo_stop.set()
        return {"ok": 1}

    def act_logo_clear(self, data):
        if not self._logo["running"]:
            self._logo["items"] = {}
        return {"ok": 1}

    def _logo_run(self, label, fn, items):
        if self._logo["running"]:
            return {"error": "Đang quét/xoá logo"}
        if not self._cfg().get("api_keys"):
            return {"error": "Chưa nhập Gemini API key (tab 🔑 API & Tuỳ chọn)"}
        self._logo_stop.clear()
        self._logo.update(running=True, phase=label, total=len(items), done=0, message=f"{label} {len(items)} ảnh…")

        def main():
            api = self._client(force=True)
            lock = threading.Lock()
            todo = list(items)

            def w():
                while not self._logo_stop.is_set():
                    with lock:
                        if not todo:
                            return
                        it = todo.pop(0)
                    try:
                        fn(api, it)
                    except Exception as e:
                        rec = self._logo["items"].setdefault(it, {"path": it})
                        rec.update(status="error", error=str(e)[:300])
                        self.log(f"[LOGO] LỖI • {it} • {e}")
                    with lock:
                        self._logo["done"] += 1
            ts = [threading.Thread(target=w, daemon=True) for _ in range(min(4, len(items)) or 1)]
            for t in ts:
                t.start()
            for t in ts:
                t.join()
            self._logo.update(running=False, phase="idle",
                              message=f"{label} xong {self._logo['done']}/{self._logo['total']}" + (" (đã dừng)" if self._logo_stop.is_set() else ""))
            self.log(f"[LOGO] {self._logo['message']}")

        threading.Thread(target=main, daemon=True, name="TS-Logo").start()
        return {"ok": 1, "count": len(items)}

    def act_logo_scan(self, data):
        m, _ = self._apimod()
        root = str(data.get("root") or "").strip()
        if not root or not Path(root).is_dir():
            return {"error": "Thư mục Queue không hợp lệ"}
        srcs = m.find_sources(root)
        if not srcs:
            return {"error": "Không có thumbnail.jpg nào trong thư mục"}

        def scan_one(api, path):
            p = Path(path)
            backup = p.parent / ".myinggo_logo_backup" / p.name
            items = api.detect_logos(p.read_bytes(), mime="image/jpeg")
            with Image_open(p) as im:
                w, h = im.size
            self._logo["items"][path] = {"path": path, "folder": p.parent.name, "status": "scanned", "logos": items,
                                         "unrelated": sum(1 for i in items if not i["related"]), "w": w, "h": h,
                                         "has_backup": backup.is_file(), "mtime": int(p.stat().st_mtime)}
        return self._logo_run("Quét logo", scan_one, srcs)

    def act_logo_remove(self, data):
        m, _ = self._apimod()
        include_related = bool(data.get("include_related"))
        paths = [p for p in (data.get("paths") or []) if p in self._logo["items"]]
        targets = []
        for p in paths:
            logos = [i for i in self._logo["items"][p].get("logos") or [] if include_related or not i["related"]]
            if logos:
                targets.append(p)
        if not targets:
            return {"error": "Không có logo nào cần xoá trong các ảnh đã chọn"}

        def remove_one(api, path):
            p = Path(path)
            rec = self._logo["items"][path]
            logos = [i for i in rec.get("logos") or [] if include_related or not i["related"]]
            bdir = p.parent / ".myinggo_logo_backup"
            bdir.mkdir(exist_ok=True)
            if not (bdir / p.name).is_file():
                shutil.copy2(p, bdir / p.name)
            src = (bdir / p.name).read_bytes()  # luôn xoá trên ảnh gốc ban đầu
            out = api.remove_logos(src, logos, mime="image/jpeg")
            from PIL import Image
            with Image.open(io.BytesIO(src)) as orig:
                size = orig.size
            with Image.open(io.BytesIO(out)) as im:
                im = im.convert("RGB")
                if im.size != size:
                    im = im.resize(size, Image.Resampling.LANCZOS)
                buf = io.BytesIO()
                im.save(buf, "JPEG", quality=95)
                p.write_bytes(buf.getvalue())
                # Cập nhật các ảnh thumbnail-original-N-final chưa vẽ trong cùng thư mục
                png = m.png_under_limit(im)
            refreshed = 0
            for f in p.parent.iterdir():
                if m.THUMB_RE.match(f.name) and f.stat().st_size <= 1.5 * 1048576:
                    f.write_bytes(png)
                    refreshed += 1
            rec.update(status="cleaned", has_backup=True, refreshed=refreshed, mtime=int(p.stat().st_mtime))
            self.log(f"[LOGO] Đã xoá {len(logos)} logo • {p.parent.name} • làm mới {refreshed} ảnh gốc")
        return self._logo_run("Xoá logo", remove_one, targets)

    def act_logo_undo(self, data):
        m, _ = self._apimod()
        done = 0
        for path in data.get("paths") or []:
            p = Path(path)
            b = p.parent / ".myinggo_logo_backup" / p.name
            if not b.is_file():
                continue
            shutil.copy2(b, p)
            from PIL import Image
            with Image.open(p) as im:
                png = m.png_under_limit(im)
            for f in p.parent.iterdir():
                if m.THUMB_RE.match(f.name) and f.stat().st_size <= 1.5 * 1048576:
                    f.write_bytes(png)
            b.unlink()
            try:
                b.parent.rmdir()
            except OSError:
                pass
            rec = self._logo["items"].get(path)
            if rec:
                rec.update(status="scanned", has_backup=False, mtime=int(p.stat().st_mtime))
            done += 1
        return {"ok": 1, "restored": done}


def m_base_prompt():
    """Prompt gốc của worker web (đọc từ file worker để luôn đồng bộ)."""
    import re
    try:
        raw = (ADDON_DIR / "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py").read_text(encoding="utf-8")
        mt = re.search(r'^PROMPT = "(.*)"\s*$', raw, re.M)
        if mt:
            return mt.group(1)
    except Exception:
        pass
    return ("Edit the uploaded image into a finished realistic music thumbnail. Preserve the original singer from the "
            "uploaded image exactly unchanged as the foreground subject. Only change the background style and redesign "
            "the typography/font. Return only the final edited image.")


def Image_open(p):
    from PIL import Image
    return Image.open(p)
