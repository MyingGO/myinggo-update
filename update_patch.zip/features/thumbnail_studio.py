"""Tính năng: Thumbnail Studio (tích hợp từ 3T Master).

Engine gốc (Gemini Studio v13.54 - PySide6/Selenium) nằm ở addons/thumbnail_studio và chạy ẩn ở
một tiến trình riêng. web_engine_bridge.py mở JSON-RPC nội bộ (127.0.0.1 + token); file này chỉ
khởi động/dừng engine và chuyển lệnh từ giao diện MyingGo sang engine.

Gồm 4 mảng: Thumbnail (Queue), Kho tài khoản Google, Description Studio, Brand (tên kênh + logo).
"""
import hashlib
import base64
import concurrent.futures
import io
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

from core import dialogs
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
ADDON_DIR = ROOT / "addons" / "thumbnail_studio"
BRIDGE_FILE = ADDON_DIR / "web_engine_bridge.py"
DASH_FILE = ADDON_DIR / "hybrid_flow_gemini_dashboard.py"
VERSION_FILE = ADDON_DIR / "app_version.json"
ENGINE_INFO_FILE = ADDON_DIR / ".myinggo_web_engine.json"

_LOCAL = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home()))
PERSIST_ROOT = Path(os.environ.get("THUMB_STUDIO_PERSIST_ROOT") or (_LOCAL / "MyingGo" / "ThumbnailStudio"))
LEGACY_3T_ROOT = _LOCAL / "HDMaster" / "ThumbnailStudio"


def _is_file(p):
    try:
        return Path(p).is_file()
    except OSError:
        return False
ENGINE_LOG_FILE = PERSIST_ROOT / "web_engine.log"
LIVE_LOG_FILE = PERSIST_ROOT / "thumbnail_studio_live.log"
FATAL_LOG_FILE = PERSIST_ROOT / "thumbnail_studio_fatal.log"
PREVIEW_DIR = PERSIST_ROOT / "preview_cache"

REQUIRED_MODULES = ["PySide6", "selenium", "PIL", "requests", "psutil"]
CONFIG_FILE = ROOT / "thumbnail_studio_config.json"          # API key + tuỳ chọn (chỉ máy này, không đóng gói)
REMOVED_ACC_FILE = PERSIST_ROOT / "myinggo_removed_accounts.json"  # email tài khoản lỗi đã xoá -> tự loại khi nhập lại
OPTIONS_FILE = PERSIST_ROOT / "myinggo_thumb_options.json"     # bản tuỳ chọn cho worker đọc (không chứa key)
DEFAULT_CFG = {
    "api_keys": [],
    "api_model": "gemini-2.5-flash-image",
    "api_mode": "auto",          # auto = tự chuyển khi tài khoản web bị giới hạn • only = chỉ dùng API • off
    "api_workers": 3,
    "variation": 30,             # % khác ảnh gốc
    "remove_logos": True,        # thêm yêu cầu xoá logo không liên quan vào prompt
    "artist_restyle": True,      # đổi tư thế & trang phục người nghệ sĩ tạo kiểu dáng mới (giữ gương mặt)
    "nature_mode": False,        # chế độ ảnh thiên nhiên/cảnh vật (không thêm người, không tự thêm chữ)
    "nature_add_text": False,    # nút phụ: cho phép thêm text thu hút lên ảnh thiên nhiên
    "nature_custom_text": "",    # nội dung chữ muốn chèn cho ảnh thiên nhiên (để trống = AI tự tạo chữ hợp cảnh)
    "folders": {},               # {thư mục: {"style": "...", "variation": 40, ...}}
}
PIP_PACKAGES = ["PySide6>=6.8,<7", "selenium==4.33.0", "Pillow", "requests", "psutil", "pyperclip",
                "undetected-chromedriver==3.5.5", "selenium-stealth==1.0.6"]
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
LONG_ACTIONS = {
    "accounts.login_all", "accounts.login", "accounts.check_all", "accounts.check",
    "description.rewrite", "description.rewrite_http", "description.translate_selected",
    "description.restore_all", "brand.generate_names", "brand.more_names",
    "brand.generate_logos", "brand.swap_logo", "accounts.import_txt", "accounts.import_text",
}
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _acc_failed(a):
    """Tài khoản lỗi / không đăng nhập được (đã kiểm tra hoặc đã thử đăng nhập mà không READY)."""
    if not isinstance(a, dict) or a.get("ok") or a.get("checking"):
        return False
    cr = str(a.get("check_result") or "").strip().lower()
    if cr and cr != "ok":
        return True
    st = str(a.get("status") or "").strip().lower()
    if not st or "chưa kiểm tra" in st or st.startswith("đang") or "đang kiểm tra" in st or "đang đăng nhập" in st:
        return False
    return True


def _removed_load():
    try:
        d = json.loads(REMOVED_ACC_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d.get("emails"), dict) else {"emails": {}}
    except Exception:
        return {"emails": {}}


def _removed_save(d):
    REMOVED_ACC_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = REMOVED_ACC_FILE.with_name(REMOVED_ACC_FILE.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, REMOVED_ACC_FILE)


def _filter_removed_lines(text, removed_emails):
    """Bỏ các dòng có email nằm trong danh sách tài khoản lỗi đã xoá. Trả (text_mới, [email bị loại])."""
    keep, dropped = [], []
    for line in str(text or "").splitlines():
        email = line.split("\t", 1)[0].strip().lower()
        if email and email in removed_emails:
            dropped.append(email)
            continue
        keep.append(line)
    return "\n".join(keep), dropped


def _dpapi_protect(text):
    """Mã hoá mật khẩu bằng Windows DPAPI giống hệt engine v13.54."""
    import base64
    if os.name != "nt":
        return {"kind": "plain-local-dev", "data": base64.b64encode((text or "").encode("utf-8")).decode("ascii")}
    try:
        import ctypes
        import ctypes.wintypes
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]
        raw_b = (text or "").encode("utf-8")
        in_buf = ctypes.create_string_buffer(raw_b)
        in_blob = DATA_BLOB(len(raw_b), ctypes.cast(in_buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)):
            raise ctypes.WinError()
        try:
            protected = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
        return {"kind": "dpapi", "data": base64.b64encode(protected).decode("ascii")}
    except Exception as e:
        return {"kind": "plain-fallback", "data": base64.b64encode((text or "").encode("utf-8")).decode("ascii"), "warning": str(e)[:120]}


def _parse_tab_lines(text):
    items, invalid = [], []
    for line_no, raw_line in enumerate(str(text or "").splitlines(), 1):
        line = str(raw_line).rstrip("\r\n").lstrip("\ufeff")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        cols = line.split("\t")
        if len(cols) != 3:
            invalid.append({"line": line_no, "reason": f"expected_3_tab_columns_got_{len(cols)}"})
            continue
        email, password, recovery = (str(x or "").strip() for x in cols)
        if not email or "@" not in email or not password:
            invalid.append({"line": line_no, "reason": "missing_email_or_password"})
            continue
        items.append((email, password, recovery))
    return items, invalid


def _bridge_build():
    import re
    try:
        raw = BRIDGE_FILE.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r'^WEB_BRIDGE_BUILD\s*=\s*["\']([^"\']+)["\']', raw, re.M)
        if m:
            return m.group(1).strip()
    except Exception:
        pass
    return "?"


def _read_version():
    try:
        return str(json.loads(VERSION_FILE.read_text(encoding="utf-8-sig")).get("version") or "?")
    except Exception:
        return "?"


def _pid_alive(pid):
    pid = int(pid or 0)
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
            if h:
                code = ctypes.c_ulong()
                ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
                k32.CloseHandle(h)
                return bool(ok) and code.value == 259  # STILL_ACTIVE
            return ctypes.GetLastError() == 5  # bị từ chối truy cập = tiến trình vẫn tồn tại
        except Exception:
            pass
    try:
        if os.name == "nt":
            cp = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                                capture_output=True, text=True, timeout=4, creationflags=_NOWIN)
            out = (cp.stdout or "").lower()
            return str(pid) in out and "no tasks" not in out
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _http_json(url, token, payload=None, timeout=10.0):
    headers = {"X-Thumb-Token": token}
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method="POST" if data else "GET")
    try:
        with urllib.request.urlopen(req, timeout=max(0.5, float(timeout))) as r:
            return json.loads(r.read().decode("utf-8", "replace") or "{}")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        try:
            msg = json.loads(body).get("error") or body
        except Exception:
            msg = body
        raise RuntimeError(f"Engine HTTP {exc.code}: {msg}")


def _python_for_engine():
    """Python dùng chạy engine: ưu tiên python.exe (không phải pythonw) cùng thư mục."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").is_file():
        return str(exe.parent / "python.exe")
    return str(exe)


def _open_in_explorer(folder):
    folder = Path(folder)
    if not folder.exists():
        raise RuntimeError(f"Thư mục không tồn tại: {folder}")
    if os.name == "nt":
        subprocess.Popen(["explorer.exe", str(folder)])


class ThumbnailStudio(Feature):
    title = "Thumbnail Studio"
    order = 12

    def __init__(self):
        super().__init__()
        self._elock = threading.RLock()
        self._install_proc = None
        self._cfg_lock = threading.RLock()
        self._run_requested = False       # người dùng đã bấm Chạy Queue (để biết có cần tự chuyển sang API)
        self._limited_hits = 0
        self._monitor_started = False
        self._api_stop = threading.Event()
        self._api = {"running": False, "phase": "idle", "total": 0, "done": 0, "failed": 0, "current": [],
                     "message": "Sẵn sàng", "trigger": "", "errors": [], "keys": [], "started_at": 0}
        self._api_client = None
        self._logo = {"running": False, "phase": "idle", "total": 0, "done": 0, "message": "", "items": {}}
        self._logo_stop = threading.Event()
        self._studio_batch_lock = threading.Lock()
        self._studio_batch_stop = threading.Event()
        self._studio_batch_state = {
            "running": False, "done": 0, "total": 0, "success": 0, "failed": 0,
            "current": "", "message": "", "results": {},
        }

    # ------------------------------------------------------------------ engine
    def _info(self, validate=True):
        try:
            info = json.loads(ENGINE_INFO_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
        pid, port, token = int(info.get("pid") or 0), int(info.get("port") or 0), str(info.get("token") or "")
        if not (pid and port and token) or not _pid_alive(pid):
            ENGINE_INFO_FILE.unlink(missing_ok=True)
            return {}
        if str(info.get("build") or "") != _bridge_build():
            self._kill(info)
            return {}
        if validate:
            try:
                h = _http_json(f"http://127.0.0.1:{port}/health", token, timeout=1.5)
                if not h.get("ok"):
                    return {}
            except Exception:
                return {}
        return info

    def _kill(self, info):
        pid = int((info or {}).get("pid") or 0)
        if pid and _pid_alive(pid):
            try:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=8, creationflags=_NOWIN)
                else:
                    os.kill(pid, 15)
            except Exception:
                pass
        ENGINE_INFO_FILE.unlink(missing_ok=True)

    def _missing_modules(self):
        code = ("import importlib.util as u;print(','.join(m for m in %r if u.find_spec(m) is None))" % REQUIRED_MODULES)
        cp = subprocess.run([_python_for_engine(), "-c", code], capture_output=True, text=True, timeout=20, creationflags=_NOWIN)
        return [x for x in (cp.stdout or "").strip().split(",") if x]

    def _start(self):
        with self._elock:
            info = self._info()
            if info:
                return info
            if not BRIDGE_FILE.is_file() or not DASH_FILE.is_file():
                raise RuntimeError(f"Thiếu engine trong {ADDON_DIR}")
            missing = self._missing_modules()
            if missing:
                raise RuntimeError("Thiếu thư viện: " + ", ".join(missing) + ". Vào tab ⚙ Hệ thống → bấm 'Cài thư viện'.")
            PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
            ENGINE_INFO_FILE.unlink(missing_ok=True)
            env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", THUMBNAIL_WEB_MODE="1",
                       THUMB_STUDIO_PERSIST_ROOT=str(PERSIST_ROOT), MYINGGO_ADDON_DIR=str(ADDON_DIR),
                       MYINGGO_THUMB_OPTIONS=str(OPTIONS_FILE))
            self._write_options(self._cfg())
            marker = f"===== MYINGGO ENGINE START {time.strftime('%Y-%m-%d %H:%M:%S')} ====="
            log_f = open(ENGINE_LOG_FILE, "a", encoding="utf-8", buffering=1)
            log_f.write("\n" + marker + "\n")
            kw = {"cwd": str(ADDON_DIR), "env": env, "stdout": log_f, "stderr": log_f}
            if os.name == "nt":
                kw["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | _NOWIN
            proc = subprocess.Popen([_python_for_engine(), "-u", str(BRIDGE_FILE),
                                     "--info-file", str(ENGINE_INFO_FILE), "--port", "0"], **kw)
            self.log(f"Đang khởi động engine Thumbnail Studio (pid={proc.pid})…")
            deadline = time.time() + 40
            while time.time() < deadline:
                if proc.poll() is not None:
                    break
                info = self._info()
                if info:
                    self.log(f"Engine sẵn sàng • v{_read_version()} • port={info.get('port')}")
                    return info
                time.sleep(0.25)
            tail = ""
            try:
                lines = ENGINE_LOG_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
                idx = max((i for i, l in enumerate(lines) if marker in l), default=0)
                tail = "\n".join(lines[idx:][-30:])
            except Exception:
                pass
            raise RuntimeError("Không khởi động được engine Thumbnail Studio.\n" + tail[-3000:])

    def _rpc(self, action, args=None, timeout=30.0, autostart=True):
        info = self._info()
        if not info and autostart:
            info = self._start()
        if not info:
            raise RuntimeError("Engine chưa chạy")
        data = _http_json(f"http://127.0.0.1:{int(info['port'])}/rpc", str(info["token"]),
                          payload={"action": action, "args": args or {}, "timeout": float(timeout)},
                          timeout=timeout + 3)
        if not data.get("ok"):
            raise RuntimeError(str(data.get("error") or "Engine error"))
        return data.get("result")

    # ------------------------------------------------------------------ API
    def act_status(self, data):
        info = self._info(validate=False)
        return {
            "installed": BRIDGE_FILE.is_file() and DASH_FILE.is_file(),
            "running": bool(info),
            "pid": info.get("pid") if info else None,
            "version": _read_version(),
            "build": _bridge_build(),
            "addon_dir": str(ADDON_DIR),
            "persist_root": str(PERSIST_ROOT),
            "python": _python_for_engine(),
            "has_3t_data": _is_file(LEGACY_3T_ROOT / "account_warehouse_v12.json"),
            "installing": bool(self._install_proc and self._install_proc.poll() is None),
        }

    def act_start_engine(self, data):
        try:
            info = self._start()
            return {"ok": 1, "pid": info.get("pid")}
        except Exception as e:
            self.log(f"[LỖI] {e}")
            return {"error": str(e)}

    def act_stop_engine(self, data):
        with self._elock:
            info = self._info(validate=False)
            if not info:
                return {"ok": 1, "already": 1}
            try:
                self._rpc("shutdown", {}, timeout=4, autostart=False)
            except Exception:
                pass
            pid = int(info.get("pid") or 0)
            end = time.time() + 5
            while _pid_alive(pid) and time.time() < end:
                time.sleep(0.15)
            self._kill(info)
            self.log("Đã dừng engine Thumbnail Studio")
            return {"ok": 1}

    def act_snapshot(self, data):
        extra = {"mg_api": self._api_public(), "mg_logo": self._logo_public()}
        if not self._info(validate=False) and not data.get("autostart"):
            return {"engine_off": True, **extra}
        try:
            res = self._rpc("snapshot", {
                "job_limit": int(data.get("job_limit") or 1400),
                "desc_limit": int(data.get("desc_limit") or 1200),
                "log_limit": int(data.get("log_limit") or 260),
            }, timeout=15, autostart=bool(data.get("autostart")))
            if isinstance(res, dict):
                res.update(extra)
                for a in res.get("accounts") or []:
                    if isinstance(a, dict):
                        a["failed"] = _acc_failed(a)
                res["mg_removed_count"] = len(_removed_load()["emails"])
            return res
        except Exception as e:
            return {"error": str(e), **extra}

    def act_action(self, data):
        action = str(data.get("action") or "").strip()
        if not action:
            return {"error": "Thiếu action"}
        args = data.get("args") or {}
        timeout = 75 if action in LONG_ACTIONS else 30
        if action == "queue.start":
            cfg = self._cfg()
            self._run_requested = True
            self._limited_hits = 0
            self._ensure_monitor()
            if cfg.get("api_mode") == "only":
                r = self.act_api_run({"scope": "all", "trigger": "Chế độ chỉ dùng API"})
                return r if r.get("error") else {"ok": 1, "api": True}
        if action == "queue.stop":
            self._run_requested = False
            self._api_stop.set()
        dropped = []
        if action in ("accounts.import_txt", "accounts.import_text"):
            if action == "accounts.import_txt":
                try:
                    text = Path(str(args.get("path") or "")).read_text(encoding="utf-8-sig", errors="ignore")
                except Exception as e:
                    return {"error": f"Không đọc được file TXT: {e}"}
            else:
                text = str(args.get("text") or "")
            removed = _removed_load()["emails"]
            if removed:
                text, dropped = _filter_removed_lines(text, removed)
                if dropped:
                    self.log(f"[Kho] Tự loại {len(dropped)} tài khoản lỗi đã xoá trước đó khi nhập")
            if not bool(args.get("replace", True)):
                return self._append_accounts_safe(text, dropped)
            if dropped:
                if not text.strip():
                    return {"error": f"Tất cả {len(dropped)} tài khoản trong danh sách đều là tài khoản lỗi đã xoá trước đó — không còn gì để nhập."}
                action, args = "accounts.import_text", {**args, "text": text}
                args.pop("path", None)
        try:
            res = self._rpc(action, args, timeout=timeout)
            if action not in ("snapshot", "ping"):
                self.log(f"[OK] {action}")
            res = res if isinstance(res, dict) else {"ok": 1, "result": res}
            if dropped:
                res["dropped_removed"] = len(dropped)
                res["dropped_emails"] = dropped[:30]
            return res
        except Exception as e:
            self.log(f"[LỖI] {action}: {e}")
            return {"error": str(e)}

    # ---- hộp thoại / thư mục
    # ------------------------------------------------------------------ tài khoản lỗi & thêm bổ sung
    def _append_accounts_safe(self, text, dropped=None):
        """Thêm tài khoản bổ sung vào kho: giữ nguyên 100% tài khoản đang READY, bỏ qua trùng & lỗi đã xoá."""
        dropped = list(dropped or [])
        items, invalid_lines = _parse_tab_lines(text)
        if not items:
            if dropped:
                return {
                    "ok": True, "imported": 0, "skipped_existing": 0,
                    "dropped_removed": len(dropped), "dropped_emails": dropped[:30],
                    "skipped_lines": len(invalid_lines), "invalid_lines": invalid_lines[:20],
                    "replace": False,
                }
            return {"error": "Không đọc được tài khoản nào. TXT phải đúng 3 cột TAB: mail<TAB>pass<TAB>email khôi phục; mỗi tài khoản đúng 1 dòng."}
        vault_file = ADDON_DIR / "login_vault.json"
        try:
            vault = json.loads(vault_file.read_text(encoding="utf-8")) if vault_file.is_file() else {"version": 1, "accounts": {}}
        except Exception:
            vault = {"version": 1, "accounts": {}}
        vault.setdefault("version", 1)
        vault.setdefault("accounts", {})
        accs = vault["accounts"]
        have = {str((r or {}).get("email") or "").strip().lower() for r in accs.values() if isinstance(r, dict)}
        nums = [int(str(k).split("_", 1)[1]) for k in accs if str(k).startswith("google_") and str(k).split("_", 1)[1].isdigit()]
        next_no = (max(nums) + 1) if nums else 1
        imported = 0
        skipped_existing = []
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        for email, password, recovery in items:
            el = email.strip().lower()
            if el in have:
                skipped_existing.append(email)
                continue
            have.add(el)
            accs[f"google_{next_no}"] = {
                "email": email,
                "password": _dpapi_protect(password),
                "recovery_email": recovery,
                "imported_at": now_str,
            }
            next_no += 1
            imported += 1
        if imported > 0:
            tmp = vault_file.with_name(vault_file.name + ".mg_tmp")
            tmp.write_text(json.dumps(vault, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, vault_file)
            try:
                # Báo cho tiến trình engine đang chạy nạp lại login_vault.json, lưu kho V12 và tạo dòng cho tài khoản mới
                # mà KHÔNG đụng chạm vào trạng thái READY của các tài khoản cũ
                self._rpc("accounts.remove", {"account_no": 999999}, timeout=15, autostart=True)
            except Exception:
                pass
        self.log(f"[Kho] Thêm bổ sung: +{imported} mới • bỏ qua {len(skipped_existing)} đã có trong kho • tự loại {len(dropped)} lỗi đã xoá")
        return {
            "ok": True,
            "imported": imported,
            "skipped_existing": len(skipped_existing),
            "dropped_removed": len(dropped),
            "dropped_emails": dropped[:30],
            "skipped_lines": len(invalid_lines),
            "invalid_lines": invalid_lines[:20],
            "replace": False,
        }

    def act_accounts_purge_failed(self, data):
        try:
            snap = self._rpc("snapshot", {"job_limit": 1, "desc_limit": 1, "log_limit": 1}, timeout=15, autostart=False)
        except Exception as e:
            return {"error": f"Engine chưa chạy: {e}"}
        accs = [a for a in (snap or {}).get("accounts") or [] if _acc_failed(a)]
        want = {int(x) for x in (data.get("account_nos") or [])}
        if want:
            accs = [a for a in accs if int(a.get("account_no") or 0) in want]
        if not accs:
            return {"ok": 1, "removed": 0, "message": "Không có tài khoản lỗi nào"}
        if snap.get("running") or snap.get("queue_running"):
            return {"error": "Queue đang chạy — bấm Dừng trước khi xoá tài khoản"}
        status_of = {int(a["account_no"]): str(a.get("status") or a.get("check_result") or "") for a in accs}
        try:
            r = self._rpc("accounts.remove_many", {"account_nos": sorted(status_of)}, timeout=30, autostart=False)
            removed = (r or {}).get("removed") or []
        except Exception as e:
            if "Unknown action" not in str(e):
                return {"error": str(e)}
            # Fallback tương thích ngay với tiến trình engine đang chạy (không cần tắt/bật lại engine)
            removed = []
            for a in accs:
                acc_no = int(a["account_no"])
                try:
                    self._rpc("accounts.remove", {"account_no": acc_no}, timeout=15, autostart=False)
                    removed.append({"account_no": acc_no, "email": str(a.get("email") or "")})
                except Exception as ex:
                    return {"error": f"Lỗi khi xoá A{acc_no}: {ex}"}
        bl = _removed_load()
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for x in removed:
            e = str(x.get("email") or "").strip().lower()
            if e:
                bl["emails"][e] = {"removed_at": now, "reason": status_of.get(int(x["account_no"]), "")[:160]}
        _removed_save(bl)
        self.log(f"[Kho] Đã xoá {len(removed)} tài khoản lỗi • danh sách tự loại: {len(bl['emails'])} email")
        return {"ok": 1, "removed": len(removed), "blacklist": len(bl["emails"])}

    def act_removed_accounts(self, data):
        bl = _removed_load()
        if data.get("clear"):
            bl = {"emails": {}}
            _removed_save(bl)
        for e in data.get("unban") or []:
            bl["emails"].pop(str(e).strip().lower(), None)
        if data.get("unban"):
            _removed_save(bl)
        items = [{"email": k, **(v if isinstance(v, dict) else {})} for k, v in bl["emails"].items()]
        items.sort(key=lambda x: x.get("removed_at") or "", reverse=True)
        return {"ok": 1, "items": items, "count": len(items)}

    def act_pick_folder(self, data):
        return {"path": dialogs.pick_dir(data.get("title") or "Chọn thư mục")}

    def act_pick_image(self, data):
        return {"path": dialogs.pick_image()}

    def act_pick_txt(self, data):
        return {"path": dialogs.pick_txt()}

    def act_open_folder(self, data):
        try:
            p = Path(str(data.get("path") or ""))
            _open_in_explorer(p if p.is_dir() else p.parent)
            return {"ok": 1}
        except Exception as e:
            return {"error": str(e)}

    def act_open_logs(self, data):
        PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
        _open_in_explorer(PERSIST_ROOT)
        return {"ok": 1}

    def act_engine_log(self, data):
        lim = max(20, min(2000, int(data.get("lines") or 200)))
        chunks = []
        for label, p in (("LIVE", LIVE_LOG_FILE), ("FATAL", FATAL_LOG_FILE), ("ENGINE", ENGINE_LOG_FILE)):
            if p.is_file():
                lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
                if lines:
                    chunks.append(f"===== {label}: {p} =====\n" + "\n".join(lines[-lim:]))
        return {"text": "\n\n".join(chunks) or "(chưa có log)"}

    # ---- môi trường Python
    def act_runtime_check(self, data):
        try:
            missing = self._missing_modules()
            cp = subprocess.run([_python_for_engine(), "--version"], capture_output=True, text=True, timeout=10, creationflags=_NOWIN)
            return {"python": _python_for_engine(), "python_version": (cp.stdout or cp.stderr).strip(),
                    "missing": missing, "ok": not missing}
        except Exception as e:
            return {"error": str(e)}

    def act_install_deps(self, data):
        if self._install_proc and self._install_proc.poll() is None:
            return {"error": "Đang cài thư viện"}
        self.clear_log()

        def job():
            self.log("Cài thư viện cho Thumbnail Studio vào " + _python_for_engine())
            self._install_proc = subprocess.Popen(
                [_python_for_engine(), "-m", "pip", "install", "--disable-pip-version-check", *PIP_PACKAGES],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                creationflags=_NOWIN)
            for line in self._install_proc.stdout:
                line = line.rstrip()
                if line:
                    self.log(line)
            rc = self._install_proc.wait()
            self.log("✅ Cài xong" if rc == 0 else f"[LỖI] pip trả mã {rc}")

        self.run_bg(job)
        return {"ok": 1}

    # ---- nhập dữ liệu kho từ 3T Master
    def act_import_3t(self, data):
        src_files = ["account_warehouse_v12.json", "queue_sources_v14.json", "account_ready_state_v53.json"]
        if not _is_file(LEGACY_3T_ROOT / src_files[0]):
            return {"error": f"Không thấy kho tài khoản 3T Master tại {LEGACY_3T_ROOT}"}
        was_running = bool(self._info(validate=False))
        if was_running:
            self.act_stop_engine({})
        PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
        copied = []
        for name in src_files:
            s, d = LEGACY_3T_ROOT / name, PERSIST_ROOT / name
            if s.is_file():
                if d.is_file():
                    shutil.copy2(d, d.with_name(d.stem + f".bak_{time.strftime('%Y%m%d_%H%M%S')}" + d.suffix))
                shutil.copy2(s, d)
                copied.append(name)
        self.log(f"Đã nhập từ 3T Master: {', '.join(copied)}")
        return {"ok": 1, "copied": copied, "restart": was_running}

    # ---- phục vụ ảnh xem trước (GET /api/thumbnail_studio/file?path=...&w=...)
    def serve_file(self, query):
        raw = (query.get("path") or [""])[0]
        p = Path(raw)
        if (query.get("orig") or ["0"])[0] == "1" and raw:
            parent = p.parent
            found_orig = None
            for cname in ("thumbnail.jpg", "thumbnail.png", "thumbnail.jpeg", "thumbnail.webp", "original.jpg", "original.png"):
                cand = parent / cname
                try:
                    if cand.is_file() and cand.resolve() != p.resolve():
                        found_orig = cand
                        break
                except Exception:
                    pass
            if not found_orig:
                return None
            p = found_orig
        if not raw or not p.is_file() or p.suffix.lower() not in IMAGE_EXT:
            return None
        try:
            w = int((query.get("w") or ["0"])[0] or 0)
        except Exception:
            w = 0
        if w <= 0:
            ctype = "image/png" if p.suffix.lower() == ".png" else "image/jpeg"
            return p.read_bytes(), ctype
        w = max(64, min(1280, w))
        st = p.stat()
        key = hashlib.sha1(f"{p.resolve()}|{st.st_mtime_ns}|{st.st_size}|{w}".encode("utf-8")).hexdigest()
        PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
        cache = PREVIEW_DIR / f"{key}.jpg"
        if not cache.is_file():
            from PIL import Image
            with Image.open(p) as im:
                im = im.convert("RGB")
                im.thumbnail((w, w * 2))
                buf = io.BytesIO()
                im.save(buf, "JPEG", quality=82)
            cache.write_bytes(buf.getvalue())
        return cache.read_bytes(), "image/jpeg"

    # ================================================================== CẤU HÌNH
    def _cfg(self):
        with self._cfg_lock:
            cfg = json.loads(json.dumps(DEFAULT_CFG))
            try:
                if CONFIG_FILE.is_file():
                    cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
            except Exception:
                pass
            if not cfg.get("api_keys"):
                try:  # dùng lại Gemini key đã nhập ở công cụ AI khác của MyingGo (nếu có)
                    k = json.loads((ROOT / "ai_fill_config.json").read_text(encoding="utf-8")).get("gemini_key", "")
                    if k:
                        cfg["api_keys"] = [k]
                except Exception:
                    pass
            return cfg

    def _write_options(self, cfg):
        try:
            PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
            opts = {
                "variation": cfg.get("variation", 30),
                "remove_logos": bool(cfg.get("remove_logos", True)),
                "artist_restyle": bool(cfg.get("artist_restyle", True)),
                "nature_mode": bool(cfg.get("nature_mode", False)),
                "nature_add_text": bool(cfg.get("nature_add_text", False)),
                "nature_custom_text": str(cfg.get("nature_custom_text") or "").strip(),
                "folders": cfg.get("folders") or {},
            }
            OPTIONS_FILE.write_text(json.dumps(opts, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            self.log(f"[LỖI] Không ghi được tuỳ chọn cho worker: {e}")

    def act_get_config(self, data):
        cfg = self._cfg()
        keys = cfg.pop("api_keys", [])
        cfg["keys_masked"] = [k[:6] + "…" + k[-4:] if len(k) > 12 else "***" for k in keys]
        cfg["keys_count"] = len(keys)
        cfg["image_models"] = ["gemini-2.5-flash-image", "gemini-3-pro-image-preview"]
        return cfg

    def act_save_config(self, data):
        with self._cfg_lock:
            cfg = self._cfg()
            for k in ("api_model", "api_mode"):
                if k in data:
                    cfg[k] = str(data[k])
            if "api_workers" in data:
                cfg["api_workers"] = max(1, min(25, int(data["api_workers"] or 5)))
            if "variation" in data:
                cfg["variation"] = max(0, min(100, int(data["variation"] or 0)))
            if "remove_logos" in data:
                cfg["remove_logos"] = bool(data["remove_logos"])
            if "artist_restyle" in data:
                cfg["artist_restyle"] = bool(data["artist_restyle"])
            if "nature_mode" in data:
                cfg["nature_mode"] = bool(data["nature_mode"])
            if "nature_add_text" in data:
                cfg["nature_add_text"] = bool(data["nature_add_text"])
            if "nature_custom_text" in data:
                cfg["nature_custom_text"] = str(data["nature_custom_text"] or "").strip()
            if "new_keys" in data:
                new = [x.strip() for x in str(data["new_keys"] or "").replace(",", "\n").splitlines() if x.strip()]
                if data.get("replace_keys"):
                    cfg["api_keys"] = new
                else:
                    cfg["api_keys"] = list(dict.fromkeys((cfg.get("api_keys") or []) + new))
            if data.get("clear_keys"):
                cfg["api_keys"] = []
            if "folder" in data:  # cấu hình riêng 1 thư mục
                folder = str(data["folder"] or "").strip()
                if folder:
                    folders = dict(cfg.get("folders") or {})
                    existing_key = next((k for k in folders if os.path.normcase(os.path.abspath(k)) == os.path.normcase(os.path.abspath(folder))), folder)
                    fcfg = dict(folders.get(existing_key) or {})
                    if existing_key != folder:
                        folders.pop(existing_key, None)
                    if "style" in data:
                        st_val = str(data.get("style") or "").strip()
                        if st_val:
                            fcfg["style"] = st_val
                        else:
                            fcfg.pop("style", None)
                    if "folder_variation" in data:
                        v = data.get("folder_variation")
                        if v not in (None, ""):
                            fcfg["variation"] = max(0, min(100, int(v)))
                        else:
                            fcfg.pop("variation", None)
                    for bk, dk in (
                        ("artist_restyle", "folder_artist_restyle"),
                        ("nature_mode", "folder_nature_mode"),
                        ("nature_add_text", "folder_nature_add_text"),
                        ("remove_logos", "folder_remove_logos"),
                    ):
                        if dk in data:
                            if data.get(dk) not in (None, ""):
                                fcfg[bk] = bool(data.get(dk))
                            else:
                                fcfg.pop(bk, None)
                    if "folder_nature_custom_text" in data:
                        ct = str(data.get("folder_nature_custom_text") or "").strip()
                        if ct:
                            fcfg["nature_custom_text"] = ct
                        else:
                            fcfg.pop("nature_custom_text", None)
                    has_any = bool(
                        fcfg.get("style")
                        or "variation" in fcfg
                        or "artist_restyle" in fcfg
                        or "nature_mode" in fcfg
                        or "nature_add_text" in fcfg
                        or "nature_custom_text" in fcfg
                        or "remove_logos" in fcfg
                    )
                    if not has_any:
                        folders.pop(folder, None)
                    else:
                        folders[folder] = fcfg
                    cfg["folders"] = folders
            CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            self._write_options(cfg)
            self._api_client = None
        return self.act_get_config({})

    def act_test_key(self, data):
        api = self._client(force=True)
        if not api.keys:
            return {"error": "Chưa có API key"}
        try:
            from PIL import Image
            buf = io.BytesIO()
            Image.new("RGB", (64, 36), (40, 60, 120)).save(buf, "PNG")
            sample = buf.getvalue()
            api.detect_logos(sample, mime="image/png")
        except Exception as e:
            return {"error": f"Key lỗi ngay bước kiểm tra cơ bản: {e}", "keys": api.key_status()}
        try:
            api.edit_image(sample, "Add a small white star in the center", mime="image/png")
            return {"ok": 1, "message": f"Key hoạt động đầy đủ ({len(api.keys)} key) • Quét logo OK • Vẽ ảnh ({api.image_model}) OK!", "keys": api.key_status()}
        except Exception as e:
            return {"ok": 1, "message": f"Key hợp lệ ({len(api.keys)} key, Quét logo OK) NHƯNG chưa vẽ được ảnh bằng API: {e}", "keys": api.key_status()}

    # ================================================================== GEMINI API
    def _apimod(self):
        if str(ADDON_DIR) not in sys.path:
            sys.path.insert(0, str(ADDON_DIR))
        import importlib
        import myinggo_gemini_api as m
        import myinggo_thumb_opts as o
        return m, o

    def _client(self, force=False):
        m, _ = self._apimod()
        if self._api_client is None or force:
            cfg = self._cfg()
            self._api_client = m.GeminiAPI(cfg.get("api_keys"), cfg.get("api_model"), log=self.log)
        return self._api_client

    def _api_public(self):
        st = dict(self._api)
        st["current"] = list(st.get("current") or [])[-12:]
        st["errors"] = list(st.get("errors") or [])[-30:]
        if self._api_client is not None:
            st["keys"] = self._api_client.key_status()
        st["run_requested"] = self._run_requested
        return st

    def _queues(self):
        snap = self._rpc("snapshot", {"job_limit": 1, "desc_limit": 1, "log_limit": 20}, timeout=15)
        return [q for q in (snap.get("queues") or []) if q.get("root")]

    def act_api_status(self, data):
        return self._api_public()

    def act_api_stop(self, data):
        self._api_stop.set()
        return {"ok": 1}

    def act_api_run(self, data):
        if self._api.get("running"):
            return {"error": "API đang chạy"}
        cfg = self._cfg()
        if not cfg.get("api_keys"):
            return {"error": "Chưa nhập Gemini API key (tab 🔑 API & Tuỳ chọn)"}
        m, _ = self._apimod()
        scope = data.get("scope", "all")
        try:
            queues = self._queues()
        except Exception as e:
            return {"error": f"Không đọc được Queue: {e}"}
        if isinstance(scope, int) or str(scope).isdigit():
            queues = [q for q in queues if int(q.get("index", -1)) == int(scope)]
        jobs = m.scan_pending(queues)
        if data.get("paths"):
            want = {os.path.normcase(str(p)) for p in data["paths"]}
            jobs = [j for j in jobs if os.path.normcase(j["path"]) in want]
        if not jobs:
            return {"error": "Không còn ảnh nào cần vẽ (các ảnh > 1.5MB được coi là đã vẽ xong)"}
        self._api_stop.clear()
        self._api.update(running=True, phase="running", total=len(jobs), done=0, failed=0, current=[], errors=[],
                         message=f"Đang vẽ {len(jobs)} ảnh bằng Gemini API", trigger=str(data.get("trigger") or "Thủ công"),
                         started_at=time.time())
        threading.Thread(target=self._api_worker_main, args=(jobs, cfg), daemon=True, name="TS-API").start()
        return {"ok": 1, "jobs": len(jobs)}

    def _api_worker_main(self, jobs, cfg):
        m, o = self._apimod()
        api = self._client(force=True)
        opts_all = {
            "variation": cfg.get("variation", 30),
            "remove_logos": cfg.get("remove_logos", True),
            "artist_restyle": cfg.get("artist_restyle", True),
            "nature_mode": cfg.get("nature_mode", False),
            "nature_add_text": cfg.get("nature_add_text", False),
            "nature_custom_text": cfg.get("nature_custom_text", ""),
            "folders": cfg.get("folders") or {},
        }
        q = list(jobs)
        lock = threading.Lock()
        exhausted = threading.Event()
        self.log(f"[API] BẮT ĐẦU • {len(jobs)} ảnh • model={api.image_model} • {len(api.keys)} key • lý do: {self._api['trigger']}")

        def worker(wid):
            while not self._api_stop.is_set() and not exhausted.is_set():
                with lock:
                    if not q:
                        return
                    job = q.pop(0)
                    self._api["current"].append(Path(job["path"]).parent.name + "/" + Path(job["path"]).name)
                p = Path(job["path"])
                try:
                    if p.stat().st_size > 1.5 * 1048576:  # worker web đã vẽ xong trong lúc chờ
                        raise FileExistsError("đã được vẽ")
                    prompt = o.build_prompt(m_base_prompt(), str(p), o.options_for(str(p), opts_all))
                    src = p.read_bytes()
                    mime = "image/png" if p.suffix.lower() == ".png" else "image/jpeg"
                    out = api.edit_image(src, prompt, mime=mime)
                    info = m.finalize_thumbnail(out, p, job.get("logo") or "")
                    with lock:
                        self._api["done"] += 1
                    self.log(f"[API W{wid}] OK • {p.parent.name}/{p.name} • {info['width']}x{info['height']} • {info['size_mb']}MB")
                except FileExistsError:
                    with lock:
                        self._api["done"] += 1
                except m.KeysExhausted as e:
                    with lock:
                        q.insert(0, job)
                    exhausted.set()
                    self.log(f"[API] DỪNG • {e}")
                    self._api["message"] = f"Hết lượt toàn bộ API key • {str(e)[:160]}"
                except Exception as e:
                    with lock:
                        self._api["failed"] += 1
                        self._api["errors"].append({"path": str(p), "error": str(e)[:300]})
                    self.log(f"[API W{wid}] LỖI • {p.parent.name}/{p.name} • {e}")
                finally:
                    with lock:
                        name = p.parent.name + "/" + p.name
                        if name in self._api["current"]:
                            self._api["current"].remove(name)

        threads = [threading.Thread(target=worker, args=(i + 1,), daemon=True) for i in range(max(1, min(int(cfg.get("api_workers") or 5), len(jobs))))]
        for t in threads:
            t.start()
            time.sleep(0.1)
        for t in threads:
            t.join()
        st = self._api
        if self._api_stop.is_set():
            st["message"] = f"Đã dừng • xong {st['done']}/{st['total']} • lỗi {st['failed']}"
        elif not exhausted.is_set():
            st["message"] = f"Hoàn tất • xong {st['done']}/{st['total']} • lỗi {st['failed']}"
        st.update(running=False, phase="idle", current=[])
        self.log(f"[API] KẾT THÚC • {st['message']}")
        try:  # cho engine quét lại để các ảnh đã vẽ hiện "Bỏ qua/xong"
            if self._info(validate=False):
                self._rpc("queue.scan", {}, timeout=20, autostart=False)
        except Exception:
            pass

    # ---- tự chuyển sang API khi tài khoản web bị giới hạn
    def _ensure_monitor(self):
        if self._monitor_started:
            return
        self._monitor_started = True
        threading.Thread(target=self._monitor_loop, daemon=True, name="TS-API-Monitor").start()

    def _monitor_loop(self):
        while True:
            time.sleep(8)
            try:
                self._monitor_tick()
            except Exception as e:
                self.log(f"[API-monitor] {e}")

    def _monitor_tick(self):
        if not self._run_requested or self._api.get("running"):
            self._limited_hits = 0
            return
        cfg = self._cfg()
        if cfg.get("api_mode") != "auto" or not cfg.get("api_keys") or not self._info(validate=False):
            return
        s = self._rpc("snapshot", {"job_limit": 5000, "desc_limit": 1, "log_limit": 20}, timeout=15, autostart=False)
        stats, accs, pl = s.get("stats") or {}, s.get("accounts") or [], s.get("prelogin") or {}
        pending = sum(1 for j in (s.get("jobs") or []) if j.get("status") in ("queued", "reserved", "error"))
        if pending == 0:
            if not (s.get("running") or s.get("queue_running")):
                self._run_requested = False
            self._limited_hits = 0
            return
        usable = [a for a in accs if a.get("ok") and not a.get("quota_hold") and not a.get("exhausted")]
        held = [a for a in accs if a.get("quota_hold") or a.get("exhausted")]
        busy_login = bool(pl.get("running")) or bool(s.get("accounts_checking_all"))
        idle = not (s.get("running") or s.get("queue_running")) and int(stats.get("running") or 0) == 0
        st_text = str(s.get("status") or "").lower()
        paused_no_acc = idle and not busy_login and any(k in st_text for k in ("cần tài khoản rảnh", "không còn tài khoản rảnh", "tạm dừng", "lỗi sau", "hoàn tất"))
        limited = (not accs) or (accs and len(held) == len(accs)) or (not usable and idle and not busy_login) or paused_no_acc
        self._limited_hits = self._limited_hits + 1 if limited else 0
        if self._limited_hits >= 2:
            why = "Kho không có tài khoản" if not accs else (f"{len(held)}/{len(accs)} tài khoản hết lượt/giới hạn" if held else "Web dừng khi còn ảnh chờ → chuyển API")
            self.log(f"[API] TỰ CHUYỂN SANG GEMINI API • {why} • còn {pending} ảnh")
            try:
                self._rpc("queue.stop", {}, timeout=30, autostart=False)
            except Exception:
                pass
            time.sleep(3)
            self._limited_hits = 0
            r = self.act_api_run({"scope": "all", "trigger": why})
            if r.get("error"):
                self.log(f"[API] Không chuyển được: {r['error']}")
            self._run_requested = False

    # ================================================================== QUÉT & XOÁ LOGO
    def _logo_public(self):
        st = dict(self._logo)
        st["items"] = list(self._logo["items"].values())
        return st

    # ---------- Xoá lại ngôi sao watermark Gemini trên ảnh đã có ----------
    def act_wm_clean(self, data):
        paths = [str(p) for p in (data.get("paths") or []) if p and os.path.isfile(str(p))]
        if not paths:
            return {"error": "Không tìm thấy file ảnh nào"}
        st = getattr(self, "_wm_state", None)
        if st and st.get("running"):
            return {"error": "Đang xoá watermark, đợi xong lượt trước"}
        self._wm_state = {"running": True, "total": len(paths), "done": 0, "cleaned": 0, "errors": 0}

        def run():
            s = self._wm_state
            try:
                if str(ADDON_DIR) not in sys.path:
                    sys.path.insert(0, str(ADDON_DIR))
                import importlib
                import myinggo_wm
                importlib.reload(myinggo_wm)
                for p in paths:
                    try:
                        msg = myinggo_wm.remove_gemini_watermark(p)
                        if msg.startswith("đã xoá"):
                            s["cleaned"] += 1
                        elif msg.startswith("bỏ qua"):
                            s["errors"] += 1
                        self.log(f"🧽 {Path(p).parent.name}/{Path(p).name}: {msg}")
                    except Exception as e:  # noqa
                        s["errors"] += 1
                        self.log(f"🧽 [LỖI] {p}: {e}")
                    s["done"] += 1
            finally:
                s["running"] = False

        threading.Thread(target=run, daemon=True).start()
        return {"ok": 1, "total": len(paths)}

    def act_wm_state(self, data):
        return getattr(self, "_wm_state", None) or {"running": False, "total": 0, "done": 0, "cleaned": 0}

    def act_logo_state(self, data):
        return self._logo_public()

    def act_logo_stop(self, data):
        self._logo_stop.set()
        return {"ok": 1}

    def act_logo_clear(self, data):
        if not self._logo["running"]:
            self._logo["items"] = {}
        return {"ok": 1}

    def _logo_run(self, label, fn, items):
        if self._logo["running"]:
            return {"error": "Đang quét/xoá logo"}
        if not self._cfg().get("api_keys"):
            return {"error": "Chưa nhập Gemini API key (tab 🔑 API & Tuỳ chọn)"}
        self._logo_stop.clear()
        self._logo.update(running=True, phase=label, total=len(items), done=0, message=f"{label} {len(items)} ảnh…")

        def main():
            api = self._client(force=True)
            lock = threading.Lock()
            todo = list(items)

            def w():
                while not self._logo_stop.is_set():
                    with lock:
                        if not todo:
                            return
                        it = todo.pop(0)
                    try:
                        fn(api, it)
                    except Exception as e:
                        rec = self._logo["items"].setdefault(it, {"path": it})
                        rec.update(status="error", error=str(e)[:300])
                        self.log(f"[LOGO] LỖI • {it} • {e}")
                    with lock:
                        self._logo["done"] += 1
            ts = [threading.Thread(target=w, daemon=True) for _ in range(min(4, len(items)) or 1)]
            for t in ts:
                t.start()
            for t in ts:
                t.join()
            self._logo.update(running=False, phase="idle",
                              message=f"{label} xong {self._logo['done']}/{self._logo['total']}" + (" (đã dừng)" if self._logo_stop.is_set() else ""))
            self.log(f"[LOGO] {self._logo['message']}")

        threading.Thread(target=main, daemon=True, name="TS-Logo").start()
        return {"ok": 1, "count": len(items)}

    def act_logo_scan(self, data):
        m, _ = self._apimod()
        root = str(data.get("root") or "").strip()
        if not root or not Path(root).is_dir():
            return {"error": "Thư mục Queue không hợp lệ"}
        srcs = m.find_sources(root)
        if not srcs:
            return {"error": "Không có thumbnail.jpg nào trong thư mục"}

        def scan_one(api, path):
            p = Path(path)
            backup = p.parent / ".myinggo_logo_backup" / p.name
            items = api.detect_logos(p.read_bytes(), mime="image/jpeg")
            with Image_open(p) as im:
                w, h = im.size
            self._logo["items"][path] = {"path": path, "folder": p.parent.name, "status": "scanned", "logos": items,
                                         "unrelated": sum(1 for i in items if not i["related"]), "w": w, "h": h,
                                         "has_backup": backup.is_file(), "mtime": int(p.stat().st_mtime)}
        return self._logo_run("Quét logo", scan_one, srcs)

    def act_logo_remove(self, data):
        m, _ = self._apimod()
        include_related = bool(data.get("include_related"))
        paths = [p for p in (data.get("paths") or []) if p in self._logo["items"]]
        targets = []
        for p in paths:
            logos = [i for i in self._logo["items"][p].get("logos") or [] if include_related or not i["related"]]
            if logos:
                targets.append(p)
        if not targets:
            return {"error": "Không có logo nào cần xoá trong các ảnh đã chọn"}

        def remove_one(api, path):
            p = Path(path)
            rec = self._logo["items"][path]
            logos = [i for i in rec.get("logos") or [] if include_related or not i["related"]]
            bdir = p.parent / ".myinggo_logo_backup"
            bdir.mkdir(exist_ok=True)
            if not (bdir / p.name).is_file():
                shutil.copy2(p, bdir / p.name)
            src = (bdir / p.name).read_bytes()  # luôn xoá trên ảnh gốc ban đầu
            out = api.remove_logos(src, logos, mime="image/jpeg")
            from PIL import Image
            with Image.open(io.BytesIO(src)) as orig:
                size = orig.size
            with Image.open(io.BytesIO(out)) as im:
                im = im.convert("RGB")
                if im.size != size:
                    im = im.resize(size, Image.Resampling.LANCZOS)
                buf = io.BytesIO()
                im.save(buf, "JPEG", quality=95)
                p.write_bytes(buf.getvalue())
                # Cập nhật các ảnh thumbnail-original-N-final chưa vẽ trong cùng thư mục
                png = m.png_under_limit(im)
            refreshed = 0
            for f in p.parent.iterdir():
                if m.THUMB_RE.match(f.name) and f.stat().st_size <= 1.5 * 1048576:
                    f.write_bytes(png)
                    refreshed += 1
            rec.update(status="cleaned", has_backup=True, refreshed=refreshed, mtime=int(p.stat().st_mtime))
            self.log(f"[LOGO] Đã xoá {len(logos)} logo • {p.parent.name} • làm mới {refreshed} ảnh gốc")
        return self._logo_run("Xoá logo", remove_one, targets)

    def act_logo_undo(self, data):
        m, _ = self._apimod()
        done = 0
        for path in data.get("paths") or []:
            p = Path(path)
            b = p.parent / ".myinggo_logo_backup" / p.name
            if not b.is_file():
                continue
            shutil.copy2(b, p)
            from PIL import Image
            with Image.open(p) as im:
                png = m.png_under_limit(im)
            for f in p.parent.iterdir():
                if m.THUMB_RE.match(f.name) and f.stat().st_size <= 1.5 * 1048576:
                    f.write_bytes(png)
            b.unlink()
            try:
                b.parent.rmdir()
            except OSError:
                pass
            rec = self._logo["items"].get(path)
            if rec:
                rec.update(status="scanned", has_backup=False, mtime=int(p.stat().st_mtime))
            done += 1
        return {"ok": 1, "restored": done}

    # ------------------------------------------------------------------ Studio Video Direct Thumbnail Editing
    def _hub(self):
        try:
            from core.server import FEATURES
            h = FEATURES.get("yt_studio_hub")
            if h is not None:
                return h
        except Exception:
            pass
        from features.yt_studio_hub import YTStudioHub
        return YTStudioHub(start_scheduler=False)

    def _studio_thumb_dir(self) -> Path:
        try:
            root = Path(str(self.act_status().get("persist_root") or ""))
        except Exception:
            root = Path(__file__).resolve().parent.parent / "data" / "thumbnail_studio"
        d = root / "studio_video_thumbs"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _studio_queues_base_dir(self) -> Path:
        try:
            root = Path(str(self.act_status().get("persist_root") or ""))
        except Exception:
            root = Path(__file__).resolve().parent.parent / "data" / "thumbnail_studio"
        d = root / "studio_queues"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _studio_queue_root(self, channel_id: int = 0, channel_title: str = "") -> Path:
        import re
        safe_title = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", str(channel_title or "").strip()).strip(" ._")
        cid = int(channel_id or 0)
        if safe_title and cid:
            folder_name = f"{safe_title} ({cid})"
        elif safe_title:
            folder_name = safe_title
        else:
            folder_name = f"Studio_Channel_{cid or 'all'}"
        d = self._studio_queues_base_dir() / folder_name
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _find_drawn_thumb_for_video(self, video_id: str, channel_id: int = 0, channel_title: str = "") -> dict:
        vid = str(video_id or "").strip()
        if not vid:
            return {"drawn_path": "", "drawn_mtime": 0, "queue_status": ""}
        drawn_path = ""
        drawn_mtime = 0
        q_status = ""
        cand_dirs = [self._studio_queue_root(channel_id, channel_title) / vid]
        try:
            base_q = self._studio_queues_base_dir()
            if base_q.is_dir():
                for sub in base_q.iterdir():
                    if sub.is_dir():
                        vd = sub / vid
                        if vd.is_dir() and vd not in cand_dirs:
                            cand_dirs.append(vd)
        except Exception:
            pass
        for vd in cand_dirs:
            if not vd.is_dir():
                continue
            for fn in ("thumbnail-original-0-final.png", "thumbnail-original-1-final.png"):
                fp = vd / fn
                if fp.is_file():
                    try:
                        st = fp.stat()
                        if st.st_size > 1.5 * 1048576:
                            if int(st.st_mtime) >= drawn_mtime:
                                drawn_path = str(fp)
                                drawn_mtime = int(st.st_mtime)
                                q_status = "done"
                        elif not q_status:
                            q_status = "queued"
                    except Exception:
                        pass
        ai_p = self._studio_thumb_dir() / vid / "ai_edited.jpg"
        if ai_p.is_file():
            try:
                st = ai_p.stat()
                if st.st_size > 5000 and int(st.st_mtime) >= drawn_mtime:
                    drawn_path = str(ai_p)
                    drawn_mtime = int(st.st_mtime)
                    q_status = "done"
            except Exception:
                pass
        return {"drawn_path": drawn_path, "drawn_mtime": drawn_mtime, "queue_status": q_status}

    def _opts_mod(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("myinggo_thumb_opts", str(ADDON_DIR / "myinggo_thumb_opts.py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    @staticmethod
    def _decode_data_url(data_url: str) -> bytes:
        s = str(data_url or "").strip()
        if not s:
            return b""
        if "," in s and s.startswith("data:"):
            s = s.split(",", 1)[1]
        return base64.b64decode(s)

    @staticmethod
    def _encode_jpeg_data_url(raw: bytes, max_w: int = 1280, quality: int = 92) -> tuple[str, int, int]:
        from PIL import Image
        with Image.open(io.BytesIO(raw)) as im:
            im = im.convert("RGB")
            orig_w, orig_h = im.size
            if max_w and im.width > max_w:
                nh = max(1, int(round(im.height * max_w / im.width)))
                im = im.resize((max_w, nh), Image.Resampling.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=quality, optimize=True)
            b64 = base64.b64encode(buf.getvalue()).decode("ascii")
            return f"data:image/jpeg;base64,{b64}", orig_w, orig_h

    def _load_source_bytes_for_video(self, channel_id: int, video_id: str, thumb_url: str = "", source_data_url: str = "", source_path: str = "") -> bytes:
        if source_data_url:
            raw = self._decode_data_url(source_data_url)
            if raw:
                return raw
        if source_path and Path(source_path).is_file():
            return Path(source_path).read_bytes()
        orig_p = self._studio_thumb_dir() / str(video_id) / "original.jpg"
        if not orig_p.is_file():
            res = self._hub().studio_download_video_thumb(int(channel_id or 0), str(video_id), thumb_url=thumb_url, dest_path=str(orig_p))
            if not res.get("ok"):
                raise RuntimeError(str(res.get("error") or "Không tải được thumbnail gốc"))
        return orig_p.read_bytes()

    def _build_studio_ai_prompt(self, opts_in: dict) -> str:
        opts = self._cfg()
        custom_prompt = str(opts_in.get("custom_prompt") or "").strip()
        if bool(opts_in.get("replace_prompt")) and custom_prompt:
            return custom_prompt
        use_opts = {
            "variation": int(opts_in.get("variation") if opts_in.get("variation") is not None else (opts.get("variation") or 35)),
            "style": str(opts_in.get("style") or "").strip(),
            "nature_mode": bool(opts_in.get("nature_mode") if "nature_mode" in opts_in else opts.get("nature_mode", False)),
            "nature_add_text": bool(opts_in.get("nature_add_text") if "nature_add_text" in opts_in else opts.get("nature_add_text", False)),
            "nature_custom_text": str(opts_in.get("nature_custom_text") or "").strip(),
            "artist_restyle": bool(opts_in.get("artist_restyle") if "artist_restyle" in opts_in else opts.get("artist_restyle", True)),
            "remove_logos": bool(opts_in.get("remove_logos") if "remove_logos" in opts_in else opts.get("remove_logos", False)),
        }
        try:
            full = self._opts_mod().build_prompt(m_base_prompt(), opts=use_opts)
        except Exception:
            full = m_base_prompt()
        if custom_prompt:
            full = f"{full} Follow these extra edit instructions carefully: {custom_prompt}"
        return full

    def act_studio_channels(self, data=None):
        """Danh sách kênh từ Channel Monitor + API config + brand logos cho tab Studio Video."""
        hub = self._hub()
        chs = hub.studio_list_channels_for_thumb()
        cfg = self._cfg()
        try:
            m, _ = self._apimod()
            raw_models = list(getattr(m, "IMAGE_MODELS", []) or [])
        except Exception:
            raw_models = ["gemini-2.5-flash-image", "gemini-3-pro-image-preview"]
        models = [
            [x[0], x[1]] if isinstance(x, (list, tuple)) and len(x) >= 2 else [str(x), str(x)]
            for x in raw_models if x
        ]
        # Tìm logo mẫu đã lưu trong brand/logos nếu có
        brand_logos = []
        try:
            root = Path(str(self.act_status().get("persist_root") or ""))
            for cand_dir in (root / "brand", root / "brand" / "logos"):
                if cand_dir.is_dir():
                    for p in sorted(cand_dir.rglob("*")):
                        if p.is_file() and p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
                            brand_logos.append({"name": p.name, "path": str(p)})
        except Exception:
            pass
        return {
            "ok": 1,
            "channels": chs,
            "has_api_keys": bool(cfg.get("api_keys")),
            "keys_count": len(cfg.get("api_keys") or []),
            "api_model": str(cfg.get("api_model") or "gemini-2.5-flash-image"),
            "image_models": models,
            "brand_logos": brand_logos[:30],
            "default_opts": {
                "variation": int(cfg.get("variation") or 30),
                "artist_restyle": bool(cfg.get("artist_restyle", True)),
                "nature_mode": bool(cfg.get("nature_mode", False)),
                "nature_add_text": bool(cfg.get("nature_add_text", False)),
                "remove_logos": bool(cfg.get("remove_logos", False)),
            },
        }

    def act_studio_scan_videos(self, data=None):
        """Quét video Studio theo kênh + bộ lọc (Lên lịch / Công khai / Nháp / Video ID)."""
        d = data or {}
        cid = int(d.get("channel_id") or 0)
        mode = str(d.get("mode") or "scheduled").strip().lower()
        vq = str(d.get("video_query") or "").strip()
        limit = int(d.get("limit") or 120)
        res = self._hub().studio_list_videos_for_thumb(channel_id=cid, mode=mode, video_query=vq, limit=limit)
        if res.get("ok"):
            ch_title = str((res.get("channel") or {}).get("title") or "").strip()
            for v in res.get("videos") or []:
                info = self._find_drawn_thumb_for_video(
                    str(v.get("video_id") or ""),
                    int(v.get("channel_id") or cid or 0),
                    str(v.get("channel_title") or ch_title),
                )
                v.update(info)
        if res.get("ok") and (mode == "video_id" or vq) and len(res.get("videos") or []) == 1:
            v0 = res["videos"][0]
            try:
                orig_p = self._studio_thumb_dir() / str(v0["video_id"]) / "original.jpg"
                dl = self._hub().studio_download_video_thumb(
                    int(v0["channel_id"]), str(v0["video_id"]), thumb_url=str(v0.get("thumbnail_url") or ""), dest_path=str(orig_p)
                )
                if dl.get("ok") and orig_p.is_file():
                    raw = orig_p.read_bytes()
                    durl, w, h = self._encode_jpeg_data_url(raw, max_w=1920, quality=94)
                    v0["original_path"] = str(orig_p)
                    v0["original_data_url"] = durl
                    v0["thumb_width"] = w
                    v0["thumb_height"] = h
            except Exception:
                pass
        return res

    def act_studio_check_drawn(self, data=None):
        """Kiểm tra trạng thái các thumbnail đã vẽ xong (bởi Queue Web hoặc API) cho danh sách video Studio."""
        d = data or {}
        cid = int(d.get("channel_id") or 0)
        ch_title = str(d.get("channel_title") or "").strip()
        vids = [str(x).strip() for x in (d.get("video_ids") or []) if str(x).strip()]
        items = {}
        done_cnt = 0
        queued_cnt = 0
        for vid in vids:
            info = self._find_drawn_thumb_for_video(vid, cid, ch_title)
            items[vid] = info
            if info.get("queue_status") == "done":
                done_cnt += 1
            elif info.get("queue_status") == "queued":
                queued_cnt += 1
        q_running = False
        q_status = ""
        api_pub = self._api_public()
        if api_pub.get("running"):
            q_running = True
            q_status = f"⚡ Đang vẽ bằng API: {api_pub.get('done', 0)}/{api_pub.get('total', 0)}"
        elif self._info(validate=False):
            try:
                snap = self._rpc("snapshot", {"job_limit": 1, "desc_limit": 1, "log_limit": 5}, timeout=6, autostart=False)
                if snap.get("running") or snap.get("queue_running") or (snap.get("prelogin") or {}).get("running"):
                    q_running = True
                st = snap.get("stats") or {}
                q_status = f"{snap.get('status') or ''} • Xong: {(st.get('done') or 0) + (st.get('skip') or 0)}/{st.get('total') or 0} • Đang vẽ: {st.get('running') or 0} • Chờ: {st.get('queue') or 0}"
            except Exception:
                pass
        return {
            "ok": 1,
            "items": items,
            "done_count": done_cnt,
            "queued_count": queued_cnt,
            "queue_running": q_running,
            "queue_status": q_status,
        }

    def act_studio_delete_drawn(self, data=None):
        """Xóa ảnh AI đã vẽ (ai_edited.jpg và thumbnail-original-N-final.png) để quay về ảnh gốc hoặc vẽ lại."""
        d = data or {}
        cid = int(d.get("channel_id") or 0)
        ch_title = str(d.get("channel_title") or "").strip()
        vids = [str(x).strip() for x in (d.get("video_ids") or []) if str(x).strip()]
        if not vids and d.get("video_id"):
            vids = [str(d.get("video_id")).strip()]
        if not vids:
            return {"ok": 0, "error": "Chưa chọn video nào để xóa ảnh vẽ."}

        base_q = self._studio_queues_base_dir()
        pref_root = self._studio_queue_root(cid, ch_title) if (cid or ch_title) else None
        deleted = []
        for vid in vids:
            removed_any = False
            ai_p = self._studio_thumb_dir() / vid / "ai_edited.jpg"
            if ai_p.is_file():
                try:
                    ai_p.unlink()
                    removed_any = True
                except Exception:
                    pass
            cand_dirs = []
            if pref_root is not None:
                cand_dirs.append(pref_root / vid)
            try:
                if base_q.is_dir():
                    for sub in base_q.iterdir():
                        if sub.is_dir():
                            vd = sub / vid
                            if vd.is_dir() and vd not in cand_dirs:
                                cand_dirs.append(vd)
            except Exception:
                pass
            for vd in cand_dirs:
                if not vd.is_dir():
                    continue
                for fn in ("thumbnail-original-0-final.png", "thumbnail-original-1-final.png", "thumbnail-original-2-final.png"):
                    fp = vd / fn
                    if fp.is_file():
                        try:
                            fp.unlink()
                            removed_any = True
                        except Exception:
                            pass
            if removed_any:
                deleted.append(vid)
        if deleted:
            self.log(f"🗑 Đã xóa ảnh thumbnail AI đã vẽ của {len(deleted)} video: {', '.join(deleted[:6])}{'...' if len(deleted) > 6 else ''}")
        return {"ok": 1, "deleted": deleted, "count": len(deleted)}

    def act_studio_queue_start(self, data=None):
        """Đưa các video đã chọn từ Studio Video vào Queue thư mục và chạy vẽ bằng tài khoản Queue (Web) hoặc API."""
        d = data or {}
        items = d.get("items") or []
        if not items:
            return {"ok": 0, "error": "Chưa chọn video nào để đưa vào Queue."}
        cid = int(d.get("channel_id") or (items[0].get("channel_id") if items else 0) or 0)
        ch_title = str(d.get("channel_title") or "").strip()
        ai_opts = d.get("ai_opts") or {}
        redraw = bool(d.get("redraw", True))
        use_api = bool(d.get("use_api", False))
        logo_path = str(d.get("logo_path") or "").strip() if bool(d.get("apply_logo")) else ""

        q_root = self._studio_queue_root(cid, ch_title)
        hub = self._hub()
        m, _ = self._apimod()
        from PIL import Image

        # 1. Lưu cấu hình prompt/chế độ cho thư mục Queue của kênh này (tự lấy tên kênh làm logo text nếu bật Dùng tên kênh)
        use_channel_text = bool(ai_opts.get("use_channel_text", True))
        raw_ch_text = str(ai_opts.get("channel_text") if "channel_text" in ai_opts else ch_title).strip()
        channel_text = raw_ch_text if use_channel_text else ""
        nature_mode = bool(ai_opts.get("nature_mode", True))
        artist_restyle = bool(ai_opts.get("artist_restyle", False))
        remove_logos = bool(ai_opts.get("remove_logos", True))
        variation = int(ai_opts.get("variation") if ai_opts.get("variation") is not None else 35)
        custom_prompt = str(ai_opts.get("custom_prompt") or "").strip()

        self.act_save_config({
            "folder": str(q_root),
            "style": custom_prompt,
            "folder_variation": variation,
            "folder_nature_mode": nature_mode,
            "folder_artist_restyle": artist_restyle,
            "folder_remove_logos": remove_logos,
            "folder_nature_add_text": bool(use_channel_text and channel_text),
            "folder_nature_custom_text": channel_text,
        })

        # 2. Tải thumbnail.jpg gốc của các video được chọn và tạo thumbnail-original-0-final.png (<= 1.5MB) để Queue vẽ
        selected_vids = {str(it.get("video_id") or "").strip() for it in items if it.get("video_id")}
        # Với các thư mục video khác trong cùng q_root không nằm trong danh sách chọn lần này:
        # nếu đang có file <= 1.5MB chưa vẽ mà người dùng không chọn, tạm thời xóa file png chờ để Queue chỉ vẽ đúng các video đã chọn
        try:
            for sub in q_root.iterdir():
                if sub.is_dir() and sub.name not in selected_vids:
                    p0 = sub / "thumbnail-original-0-final.png"
                    if p0.is_file() and p0.stat().st_size <= 1.5 * 1048576:
                        try:
                            p0.unlink()
                        except Exception:
                            pass
        except Exception:
            pass

        def _prep_one(it: dict):
            vid = str(it.get("video_id") or "").strip()
            vcid = int(it.get("channel_id") or cid or 0)
            turl = str(it.get("thumb_url") or it.get("thumbnail_url") or "").strip()
            if not vid:
                return False
            vdir = q_root / vid
            vdir.mkdir(parents=True, exist_ok=True)
            orig_jpg = vdir / "thumbnail.jpg"
            target_png = vdir / "thumbnail-original-0-final.png"
            if not orig_jpg.is_file() or orig_jpg.stat().st_size < 1000:
                cached_orig = self._studio_thumb_dir() / vid / "original.jpg"
                if cached_orig.is_file() and cached_orig.stat().st_size >= 1000:
                    shutil.copy2(cached_orig, orig_jpg)
                else:
                    dl = hub.studio_download_video_thumb(vcid, vid, thumb_url=turl, dest_path=str(orig_jpg))
                    if not dl.get("ok") or not orig_jpg.is_file():
                        return False
            if redraw or not target_png.is_file() or target_png.stat().st_size > 1.5 * 1048576:
                with Image.open(orig_jpg) as im:
                    png_bytes = m.png_under_limit(im.convert("RGB"))
                target_png.write_bytes(png_bytes)
            return True

        prepared = 0
        failed = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for ok in pool.map(_prep_one, items):
                if ok:
                    prepared += 1
                else:
                    failed += 1

        if prepared == 0:
            return {"ok": 0, "error": "Không tải được thumbnail gốc của các video đã chọn."}

        # 3. Gắn thư mục q_root vào slot Queue của Engine và kích hoạt chạy
        try:
            snap = self._rpc("snapshot", {"job_limit": 1, "desc_limit": 1, "log_limit": 5}, timeout=20, autostart=True)
            queues = snap.get("queues") or []
            norm_target = os.path.normcase(os.path.abspath(str(q_root)))
            slot_idx = next(
                (int(q.get("index", 0)) for q in queues if q.get("root") and os.path.normcase(os.path.abspath(str(q["root"]))) == norm_target),
                None,
            )
            if slot_idx is None:
                slot_idx = next((int(q.get("index", 0)) for q in queues if not q.get("root")), 0)
            self._rpc("queue.set", {"index": slot_idx, "root": str(q_root), "logo": logo_path, "status": "sẵn sàng"}, timeout=20)
            self._rpc("queue.scan", {}, timeout=25)
            time.sleep(1.2)
            if use_api:
                r_api = self.act_api_run({"scope": slot_idx, "trigger": f"Studio Video • {ch_title or cid}"})
                if r_api.get("error"):
                    return {"ok": 0, "error": r_api["error"]}
            else:
                self.act_action({"action": "queue.start", "args": {}})
        except Exception as e:
            return {"ok": 0, "error": f"Không khởi chạy được Queue: {e}"}

        self.log(f"🎬 [Studio Video → Queue #{slot_idx + 1}] Đã chuẩn bị {prepared} thumbnail cho kênh '{ch_title or cid}' (Logo text: '{channel_text or 'Không'}') → bắt đầu vẽ!")
        return {
            "ok": 1,
            "slot": slot_idx,
            "queue_root": str(q_root),
            "prepared": prepared,
            "failed": failed,
            "channel_text": channel_text,
        }

    def act_studio_fetch_thumb(self, data=None):
        """Tải thumbnail chất lượng cao nhất trực tiếp từ video Studio về bộ nhớ & file cục bộ."""
        d = data or {}
        cid = int(d.get("channel_id") or 0)
        vid = str(d.get("video_id") or "").strip()
        thumb_url = str(d.get("thumb_url") or "").strip()
        if not vid:
            return {"ok": 0, "error": "Thiếu video_id."}
        orig_p = self._studio_thumb_dir() / vid / "original.jpg"
        dl = self._hub().studio_download_video_thumb(cid, vid, thumb_url=thumb_url, dest_path=str(orig_p))
        if not dl.get("ok"):
            return dl
        raw = orig_p.read_bytes()
        durl, w, h = self._encode_jpeg_data_url(raw, max_w=1920, quality=94)
        return {
            "ok": 1,
            "channel_id": cid,
            "video_id": vid,
            "path": str(orig_p),
            "width": w,
            "height": h,
            "thumb_url": dl.get("thumb_url") or thumb_url,
            "data_url": durl,
        }

    def act_studio_ai_edit(self, data=None):
        """Dùng Gemini API chỉnh sửa trực tiếp thumbnail lấy từ video Studio và trả bản xem trước."""
        d = data or {}
        cid = int(d.get("channel_id") or 0)
        vid = str(d.get("video_id") or "").strip()
        if not vid:
            return {"ok": 0, "error": "Thiếu video_id."}
        cfg = self._cfg()
        keys = cfg.get("api_keys") or []
        if not keys:
            return {"ok": 0, "error": "Chưa có Gemini API Key. Hãy thêm key ở tab ⚡ API (Gemini) hoặc chỉnh sửa trực tiếp bằng Canvas / tải ảnh lên."}
        try:
            src_bytes = self._load_source_bytes_for_video(
                cid, vid,
                thumb_url=str(d.get("thumb_url") or ""),
                source_data_url=str(d.get("source_data_url") or ""),
                source_path=str(d.get("source_path") or ""),
            )
            full_prompt = self._build_studio_ai_prompt(d)
            m, _ = self._apimod()
            model = str(d.get("model") or cfg.get("api_model") or "gemini-2.5-flash-image")
            api = m.GeminiAPI(keys, image_model=model, log=self.log)
            out_bytes = api.edit_image(src_bytes, full_prompt, mime="image/jpeg", aspect="16:9")
            from PIL import Image
            with Image.open(io.BytesIO(out_bytes)) as im_raw:
                im = m.normalize_16x9(im_raw)
            logo_path = str(d.get("logo_path") or "").strip()
            if bool(d.get("apply_logo")) and logo_path and Path(logo_path).is_file():
                im = m.add_logo(im, logo_path)
            out_p = self._studio_thumb_dir() / vid / "ai_edited.jpg"
            out_p.parent.mkdir(parents=True, exist_ok=True)
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=94, optimize=True)
            out_p.write_bytes(buf.getvalue())
            durl, w, h = self._encode_jpeg_data_url(buf.getvalue(), max_w=1920, quality=94)
            return {"ok": 1, "video_id": vid, "path": str(out_p), "data_url": durl, "prompt_used": full_prompt, "width": w, "height": h}
        except Exception as e:
            return {"ok": 0, "error": str(e)}

    def act_studio_apply_thumb(self, data=None):
        """Đẩy trực tiếp thumbnail đã chỉnh sửa lên 1 video trên YouTube Studio."""
        d = data or {}
        cid = int(d.get("channel_id") or 0)
        vid = str(d.get("video_id") or "").strip()
        raw = self._decode_data_url(str(d.get("image_data_url") or ""))
        if not raw and d.get("image_path") and Path(str(d["image_path"])).is_file():
            raw = Path(str(d["image_path"])).read_bytes()
        if not raw:
            return {"ok": 0, "error": "Chưa có ảnh thumbnail đã chỉnh sửa để đẩy lên Studio."}
        logo_path = str(d.get("logo_path") or "").strip()
        if bool(d.get("apply_logo")) and logo_path and Path(logo_path).is_file():
            try:
                from PIL import Image
                m, _ = self._apimod()
                with Image.open(io.BytesIO(raw)) as im0:
                    im1 = m.add_logo(im0.convert("RGB"), logo_path)
                b2 = io.BytesIO()
                im1.save(b2, format="JPEG", quality=94, optimize=True)
                raw = b2.getvalue()
            except Exception:
                pass
        return self._hub().studio_upload_video_thumb(cid, vid, image_bytes=raw)

    def act_studio_batch_status(self, data=None):
        with self._studio_batch_lock:
            return dict(self._studio_batch_state)

    def act_studio_batch_stop(self, data=None):
        self._studio_batch_stop.set()
        return {"ok": 1}

    def act_studio_batch_apply(self, data=None):
        """Chạy hàng loạt chỉnh sửa & cập nhật thumbnail trực tiếp cho nhiều video Studio."""
        d = data or {}
        items = d.get("items") or []
        if not items:
            return {"ok": 0, "error": "Chưa chọn video nào."}
        batch_mode = str(d.get("batch_mode") or "ai_restyle").strip()
        with self._studio_batch_lock:
            if self._studio_batch_state.get("running"):
                return {"ok": 0, "error": "Đang có tiến trình cập nhật hàng loạt chạy."}
            self._studio_batch_stop.clear()
            self._studio_batch_state = {
                "running": True,
                "done": 0,
                "total": len(items),
                "success": 0,
                "failed": 0,
                "current": "Khởi tạo...",
                "message": f"Đang xử lý {len(items)} video ({batch_mode})...",
                "results": {},
            }

        cfg = self._cfg()
        keys = cfg.get("api_keys") or []
        if batch_mode == "ai_restyle" and not keys:
            with self._studio_batch_lock:
                self._studio_batch_state["running"] = False
            return {"ok": 0, "error": "Chế độ AI hàng loạt cần Gemini API Key ở tab ⚡ API (Gemini). Bạn có thể dùng chế độ Khung chữ/Logo/Tự chọn ảnh không cần API key."}

        shared_bytes = self._decode_data_url(str(d.get("image_data_url") or "")) if batch_mode == "same_image" else b""
        if batch_mode == "same_image" and not shared_bytes:
            with self._studio_batch_lock:
                self._studio_batch_state["running"] = False
            return {"ok": 0, "error": "Chưa có ảnh mẫu để áp dụng hàng loạt."}

        workers = max(1, min(4, int(d.get("workers") or (1 if batch_mode == "same_image" else 2))))
        ai_opts = d.get("ai_opts") or {}
        overlay_opts = d.get("overlay_opts") or {}
        logo_path = str(d.get("logo_path") or "").strip()
        apply_logo = bool(d.get("apply_logo"))
        model = str(ai_opts.get("model") or cfg.get("api_model") or "gemini-2.5-flash-image")
        full_prompt = self._build_studio_ai_prompt(ai_opts) if batch_mode == "ai_restyle" else ""

        def _process_one(it: dict):
            if self._studio_batch_stop.is_set():
                return {"ok": 0, "video_id": it.get("video_id"), "error": "Đã dừng"}
            cid = int(it.get("channel_id") or 0)
            vid = str(it.get("video_id") or "").strip()
            turl = str(it.get("thumbnail_url") or it.get("thumb_url") or "")
            hub = self._hub()
            m, _ = self._apimod()
            from PIL import Image, ImageDraw, ImageEnhance, ImageFont

            if batch_mode == "same_image":
                up_bytes = shared_bytes
            elif batch_mode == "push_drawn":
                drawn_p = str(it.get("drawn_path") or "").strip()
                if not drawn_p or not Path(drawn_p).is_file():
                    info = self._find_drawn_thumb_for_video(vid, cid, str(it.get("channel_title") or ""))
                    drawn_p = str(info.get("drawn_path") or "").strip()
                if not drawn_p or not Path(drawn_p).is_file():
                    return {"ok": 0, "video_id": vid, "error": "Chưa có ảnh đã vẽ xong cho video này"}
                with Image.open(drawn_p) as im0:
                    im = m.normalize_16x9(im0.convert("RGB"))
                if apply_logo and logo_path and Path(logo_path).is_file():
                    im = m.add_logo(im, logo_path)
                buf = io.BytesIO()
                im.save(buf, format="JPEG", quality=93, optimize=True)
                up_bytes = buf.getvalue()
            else:
                src_bytes = self._load_source_bytes_for_video(cid, vid, thumb_url=turl)
                if batch_mode == "ai_restyle":
                    api = m.GeminiAPI(keys, image_model=model, log=self.log)
                    gen_bytes = api.edit_image(src_bytes, full_prompt, mime="image/jpeg", aspect="16:9")
                    with Image.open(io.BytesIO(gen_bytes)) as im0:
                        im = m.normalize_16x9(im0)
                else:
                    # canvas_overlay: chỉnh sáng/tương phản/bão hòa + chữ + viền + logo trực tiếp bằng PIL
                    with Image.open(io.BytesIO(src_bytes)) as im0:
                        im = m.normalize_16x9(im0)
                    br = float(overlay_opts.get("brightness", 1.0))
                    ct = float(overlay_opts.get("contrast", 1.0))
                    st = float(overlay_opts.get("saturation", 1.0))
                    if abs(br - 1.0) > 0.01:
                        im = ImageEnhance.Brightness(im).enhance(br)
                    if abs(ct - 1.0) > 0.01:
                        im = ImageEnhance.Contrast(im).enhance(ct)
                    if abs(st - 1.0) > 0.01:
                        im = ImageEnhance.Color(im).enhance(st)
                    ov_text = str(overlay_opts.get("text") or "").strip()
                    if ov_text:
                        rgba = im.convert("RGBA")
                        draw = ImageDraw.Draw(rgba)
                        sz = max(24, int(overlay_opts.get("font_size") or 64))
                        font = None
                        for fp in (r"C:\Windows\Fonts\impact.ttf", r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\segoeui.ttf"):
                            if Path(fp).is_file():
                                try:
                                    font = ImageFont.truetype(fp, sz)
                                    break
                                except Exception:
                                    pass
                        font = font or ImageFont.load_default()
                        pos = str(overlay_opts.get("position") or overlay_opts.get("text_pos") or "bottom")
                        color = str(overlay_opts.get("color") or overlay_opts.get("text_color") or "#ffffff")
                        stroke_col = str(overlay_opts.get("stroke") or "#000000")
                        bbox = draw.textbbox((0, 0), ov_text, font=font)
                        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
                        x = max(24, (im.width - tw) // 2)
                        y = int(im.height * 0.08) if pos == "top" else (int(im.height - th) // 2 if pos == "center" else max(24, im.height - th - int(im.height * 0.08)))
                        draw.text((x, y), ov_text, font=font, fill=color, stroke_width=max(2, sz // 14), stroke_fill=stroke_col)
                        im = rgba.convert("RGB")
                if apply_logo and logo_path and Path(logo_path).is_file():
                    im = m.add_logo(im, logo_path)
                buf = io.BytesIO()
                im.save(buf, format="JPEG", quality=93, optimize=True)
                up_bytes = buf.getvalue()

            if self._studio_batch_stop.is_set():
                return {"ok": 0, "video_id": vid, "error": "Đã dừng"}
            res = hub.studio_upload_video_thumb(cid, vid, image_bytes=up_bytes)
            res["video_id"] = vid
            return res

        def _runner():
            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                    fut_map = {pool.submit(_process_one, it): it for it in items}
                    for fut in concurrent.futures.as_completed(fut_map):
                        it = fut_map[fut]
                        vid = str(it.get("video_id") or "")
                        try:
                            r = fut.result()
                        except Exception as e:
                            r = {"ok": 0, "video_id": vid, "error": str(e)}
                        with self._studio_batch_lock:
                            st = self._studio_batch_state
                            st["done"] += 1
                            st["current"] = str(it.get("title") or vid)
                            if r.get("ok"):
                                st["success"] += 1
                            else:
                                st["failed"] += 1
                            st["results"][vid] = r
                            st["message"] = f"Đã xử lý {st['done']}/{st['total']} video (✓ {st['success']}, ✖ {st['failed']})"
            finally:
                with self._studio_batch_lock:
                    st = self._studio_batch_state
                    st["running"] = False
                    if self._studio_batch_stop.is_set():
                        st["message"] = f"⏹ Đã dừng ({st['done']}/{st['total']} • ✓ {st['success']}, ✖ {st['failed']})"
                    else:
                        st["message"] = f"✅ Hoàn tất ({st['done']}/{st['total']} • ✓ {st['success']}, ✖ {st['failed']})"

        threading.Thread(target=_runner, daemon=True, name="ts-studio-batch").start()
        return {"ok": 1, "total": len(items)}


def m_base_prompt():
    """Prompt gốc của worker web (đọc từ file worker để luôn đồng bộ)."""
    import re
    try:
        raw = (ADDON_DIR / "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py").read_text(encoding="utf-8")
        mt = re.search(r'^PROMPT = "(.*)"\s*$', raw, re.M)
        if mt:
            return mt.group(1)
    except Exception:
        pass
    return ("Edit the uploaded image into a finished realistic music thumbnail. Preserve the original singer from the "
            "uploaded image exactly unchanged as the foreground subject. Only change the background style and redesign "
            "the typography/font. Return only the final edited image.")


def Image_open(p):
    from PIL import Image
    return Image.open(p)
