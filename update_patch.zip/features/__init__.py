# Mỗi file .py trong thư mục này là một tính năng, tự được nạp vào menu.
