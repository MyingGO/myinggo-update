"""Tính năng: tạo thumbnail-original-N-final.png từ thumbnail.jpg trong từng thư mục id. Dùng làm mẫu.
Có sao lưu file cũ trước khi ghi đè để 'Khôi phục gốc', và chức năng xóa hàng loạt các file thumbnail-original-N-final.png."""
import json
import re
import shutil
from pathlib import Path

from PIL import Image

from core import dialogs
from core.base import Feature

BACKUP_DIR = ".thumb_backup"
MANIFEST = "thumb_manifest.json"
FINAL_RE = re.compile(r"^thumbnail-original-\d+-final\.png$", re.IGNORECASE)


def find_source(folder: Path):
    for name in ("thumbnail.jpg", "thumbnail.jpeg", "thumbnail.JPG"):
        p = folder / name
        if p.is_file():
            return p
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg"):
            return p
    return None


def final_files(sub: Path):
    return [p for p in sub.iterdir() if p.is_file() and FINAL_RE.match(p.name)]


class ThumbnailCopier(Feature):
    title = "Thumbnail Copier"
    order = 10

    def act_pick_folder(self, data):
        return {"path": dialogs.pick_folder()}

    def _root(self, data):
        root = Path(data.get("path", ""))
        return root if root.is_dir() else None

    def act_start(self, data):
        root = self._root(data)
        if not root:
            return {"error": "Thư mục không hợp lệ"}
        try:
            n = int(data.get("count"))
            assert n > 0
        except Exception:
            return {"error": "Số ảnh không hợp lệ"}
        if self.running:
            return {"error": "Đang chạy"}
        self.clear_log()
        self.run_bg(self.process, root, n, bool(data.get("overwrite", True)))
        return {"ok": 1}

    def act_restore(self, data):
        root = self._root(data)
        if not root:
            return {"error": "Thư mục không hợp lệ"}
        if self.running:
            return {"error": "Đang chạy"}
        if not (root / MANIFEST).is_file():
            return {"error": "Không có dữ liệu sao lưu để khôi phục trong thư mục này (chưa chạy 'Bắt đầu' lần nào)."}
        self.clear_log()
        self.run_bg(self.restore, root)
        return {"ok": 1}

    def act_delete(self, data):
        root = self._root(data)
        if not root:
            return {"error": "Thư mục không hợp lệ"}
        if self.running:
            return {"error": "Đang chạy"}
        self.clear_log()
        self.run_bg(self.delete_finals, root)
        return {"ok": 1}

    def process(self, root, count, overwrite):
        subs = sorted(p for p in root.iterdir() if p.is_dir() and p.name != BACKUP_DIR)
        # Manifest cũ (nếu có) được nạp để chạy nhiều lần vẫn khôi phục về đúng trạng thái GỐC ban đầu
        mf_path = root / MANIFEST
        manifest = {}
        if mf_path.is_file():
            try:
                manifest = json.loads(mf_path.read_text(encoding="utf-8"))
            except Exception:
                manifest = {}
        ok = skipped = 0
        for sub in subs:
            src = find_source(sub)
            if not src:
                self.log(f"[BỎ QUA] {sub.name}: không có ảnh jpg")
                skipped += 1
                continue
            entry = manifest.setdefault(sub.name, {"backed_up": [], "created": []})
            try:
                bdir = sub / BACKUP_DIR
                with Image.open(src) as im:
                    im = im.convert("RGB")
                    for i in range(count):
                        name = f"thumbnail-original-{i}-final.png"
                        dst = sub / name
                        if dst.exists() and not overwrite:
                            continue
                        if dst.exists():
                            if name not in entry["backed_up"] and name not in entry["created"]:
                                bdir.mkdir(exist_ok=True)
                                shutil.copy2(dst, bdir / name)
                                entry["backed_up"].append(name)
                        elif name not in entry["created"] and name not in entry["backed_up"]:
                            entry["created"].append(name)
                        im.save(dst, "PNG")
                self.log(f"[OK] {sub.name}: tạo {count} ảnh từ {src.name}")
                ok += 1
            except Exception as e:
                self.log(f"[LỖI] {sub.name}: {e}")
                skipped += 1
        mf_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
        self.log(f"\nXong: {ok} thành công, {skipped} bỏ qua/lỗi (tổng {len(subs)} thư mục)")

    def restore(self, root):
        mf_path = root / MANIFEST
        try:
            manifest = json.loads(mf_path.read_text(encoding="utf-8"))
        except Exception as e:
            self.log(f"[LỖI] Không đọc được dữ liệu sao lưu: {e}")
            return
        restored = removed = failed = 0
        for sub_name, entry in manifest.items():
            sub = root / sub_name
            if not sub.is_dir():
                continue
            bdir = sub / BACKUP_DIR
            try:
                for name in entry.get("backed_up", []):
                    b = bdir / name
                    if b.is_file():
                        shutil.copy2(b, sub / name)
                        b.unlink()
                        restored += 1
                for name in entry.get("created", []):
                    p = sub / name
                    if p.is_file():
                        p.unlink()
                        removed += 1
                if bdir.is_dir() and not any(bdir.iterdir()):
                    bdir.rmdir()
                self.log(f"[OK] {sub_name}: khôi phục {len(entry.get('backed_up', []))} file cũ, xóa {len(entry.get('created', []))} file mới tạo")
            except Exception as e:
                failed += 1
                self.log(f"[LỖI] {sub_name}: {e}")
        if not failed:
            mf_path.unlink(missing_ok=True)
        self.log(f"\nĐã khôi phục gốc: {restored} file cũ được trả lại, {removed} file mới tạo đã xóa, {failed} lỗi")

    def delete_finals(self, root):
        subs = sorted(p for p in root.iterdir() if p.is_dir() and p.name != BACKUP_DIR)
        total = failed = 0
        for sub in subs:
            try:
                files = final_files(sub)
                for p in files:
                    p.unlink()
                if files:
                    self.log(f"[XÓA] {sub.name}: {len(files)} file thumbnail-original-N-final.png")
                total += len(files)
            except Exception as e:
                failed += 1
                self.log(f"[LỖI] {sub.name}: {e}")
        # Sau khi xóa thủ công, dữ liệu sao lưu cũ không còn ý nghĩa
        (root / MANIFEST).unlink(missing_ok=True)
        for sub in subs:
            shutil.rmtree(sub / BACKUP_DIR, ignore_errors=True)
        self.log(f"\nĐã xóa {total} file thumbnail-original-N-final.png trong {len(subs)} thư mục ({failed} lỗi)")
