"""Tính năng: tạo thumbnail-original-N-final.png từ thumbnail.jpg trong từng thư mục id. Dùng làm mẫu."""
from pathlib import Path

from PIL import Image

from core import dialogs
from core.base import Feature


def find_source(folder: Path):
    for name in ("thumbnail.jpg", "thumbnail.jpeg", "thumbnail.JPG"):
        p = folder / name
        if p.is_file():
            return p
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg"):
            return p
    return None


class ThumbnailCopier(Feature):
    title = "Thumbnail Copier"
    order = 10

    def act_pick_folder(self, data):
        return {"path": dialogs.pick_folder()}

    def act_start(self, data):
        root = Path(data.get("path", ""))
        if not root.is_dir():
            return {"error": "Thư mục không hợp lệ"}
        try:
            n = int(data.get("count"))
            assert n > 0
        except Exception:
            return {"error": "Số ảnh không hợp lệ"}
        if self.running:
            return {"error": "Đang chạy"}
        self.clear_log()
        self.run_bg(self.process, root, n, bool(data.get("overwrite", True)))
        return {"ok": 1}

    def process(self, root, count, overwrite):
        subs = sorted(p for p in root.iterdir() if p.is_dir())
        ok = skipped = 0
        for sub in subs:
            src = find_source(sub)
            if not src:
                self.log(f"[BỎ QUA] {sub.name}: không có ảnh jpg")
                skipped += 1
                continue
            try:
                with Image.open(src) as im:
                    im = im.convert("RGB")
                    for i in range(count):
                        dst = sub / f"thumbnail-original-{i}-final.png"
                        if dst.exists() and not overwrite:
                            continue
                        im.save(dst, "PNG")
                self.log(f"[OK] {sub.name}: tạo {count} ảnh từ {src.name}")
                ok += 1
            except Exception as e:
                self.log(f"[LỖI] {sub.name}: {e}")
                skipped += 1
        self.log(f"\nXong: {ok} thành công, {skipped} bỏ qua/lỗi (tổng {len(subs)} thư mục)")
