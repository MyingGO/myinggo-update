"""Tính năng: tạo thumbnail-original-N-final.png từ thumbnail.jpg trong từng thư mục id. Dùng làm mẫu.
Có sao lưu file cũ trước khi ghi đè để 'Khôi phục gốc', chức năng xóa hàng loạt các file thumbnail-original-N-final.png,
và bộ dọn file .m4a / .mp4 / thư mục ID thiếu .mp3."""
import json
import os
import re
import shutil
import threading
import time
from pathlib import Path

from PIL import Image

from core import dialogs
from core.base import Feature

BACKUP_DIR = ".thumb_backup"
MANIFEST = "thumb_manifest.json"
FINAL_RE = re.compile(r"^thumbnail-original-\d+-final\.png$", re.IGNORECASE)
ID_DIR_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
SKIP_SCAN_DIRS = {".thumb_backup", "_gemini_before_overwrite", "outputs", "output", "$recycle.bin", "system volume information"}
ACTIVE_DL_EXTS = {".part", ".ytdl", ".tmp", ".crdownload"}


def _fmt_size(num_bytes: int) -> str:
    val = float(max(0, int(num_bytes or 0)))
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if val < 1024.0 or unit == "TB":
            return f"{int(val)} {unit}" if unit == "B" else f"{val:.1f} {unit}"
        val /= 1024.0
    return f"{val:.1f} TB"


def _dir_size(path: Path) -> int:
    total = 0
    try:
        for cur, _, files in os.walk(path):
            for fn in files:
                try:
                    total += os.path.getsize(os.path.join(cur, fn))
                except OSError:
                    pass
    except OSError:
        pass
    return total


def _has_recent_active_download(id_dir: Path, window_sec: float = 60.0) -> bool:
    now = time.time()
    try:
        for cur, _, files in os.walk(id_dir):
            for fn in files:
                ext = os.path.splitext(fn)[1].lower()
                if ext in ACTIVE_DL_EXTS:
                    try:
                        if os.path.getmtime(os.path.join(cur, fn)) >= now - window_sec:
                            return True
                    except OSError:
                        return True
    except OSError:
        pass
    return False


def _iter_id_folders(root: Path):
    """Duyệt đệ quy mọi thư mục con bên dưới root (không bao gồm root) để tìm thư mục ID video YouTube."""
    visited = set()
    try:
        visited.add(os.path.realpath(root))
    except OSError:
        pass

    def _walk(cur_dir: Path):
        try:
            children = sorted((p for p in cur_dir.iterdir() if p.is_dir()), key=lambda x: x.name.lower())
        except OSError:
            return
        for ch in children:
            if ch.is_symlink():
                continue
            name_low = ch.name.lower()
            if name_low in SKIP_SCAN_DIRS or name_low.startswith("."):
                continue
            try:
                rp = os.path.realpath(ch)
                if rp in visited:
                    continue
                visited.add(rp)
            except OSError:
                continue
            try:
                sub_dirs = [s for s in ch.iterdir() if s.is_dir()]
            except OSError:
                sub_dirs = []
            if ID_DIR_RE.match(ch.name) and not any(ID_DIR_RE.match(s.name) for s in sub_dirs):
                yield ch
            else:
                yield from _walk(ch)

    yield from _walk(root)


def find_source(folder: Path):
    for name in ("thumbnail.jpg", "thumbnail.jpeg", "thumbnail.JPG"):
        p = folder / name
        if p.is_file():
            return p
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg"):
            return p
    return None


def final_files(sub: Path):
    return [p for p in sub.iterdir() if p.is_file() and FINAL_RE.match(p.name)]


class ThumbnailCopier(Feature):
    title = "Thumbnail Copier"
    order = 10

    def __init__(self):
        super().__init__()
        self._clean_lock = threading.Lock()
        self._clean_stop = threading.Event()
        self._clean_logs = []
        self._clean_state = {
            "running": False,
            "mode": "idle",
            "root": "",
            "cycle": 0,
            "interval_sec": 30,
            "scanned_ids": 0,
            "deleted_dirs": 0,
            "deleted_outer_m4a": 0,
            "deleted_out_m4a": 0,
            "deleted_out_mp4": 0,
            "freed_bytes": 0,
            "errors": 0,
            "last_cycle_at": "",
            "message": "",
        }

    def _clean_log(self, msg: str):
        ts = time.strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        with self._clean_lock:
            self._clean_logs.append(line)
            if len(self._clean_logs) > 2000:
                self._clean_logs = self._clean_logs[-2000:]

    def act_pick_folder(self, data):
        return {"path": dialogs.pick_folder()}

    def _root(self, data):
        root = Path(data.get("path", ""))
        return root if root.is_dir() else None

    def act_start(self, data):
        root = self._root(data)
        if not root:
            return {"error": "Thư mục không hợp lệ"}
        try:
            n = int(data.get("count"))
            assert n > 0
        except Exception:
            return {"error": "Số ảnh không hợp lệ"}
        if self.running:
            return {"error": "Đang chạy"}
        self.clear_log()
        self.run_bg(self.process, root, n, bool(data.get("overwrite", True)))
        return {"ok": 1}

    def act_restore(self, data):
        root = self._root(data)
        if not root:
            return {"error": "Thư mục không hợp lệ"}
        if self.running:
            return {"error": "Đang chạy"}
        if not (root / MANIFEST).is_file():
            return {"error": "Không có dữ liệu sao lưu để khôi phục trong thư mục này (chưa chạy 'Bắt đầu' lần nào)."}
        self.clear_log()
        self.run_bg(self.restore, root)
        return {"ok": 1}

    def act_delete(self, data):
        root = self._root(data)
        if not root:
            return {"error": "Thư mục không hợp lệ"}
        if self.running:
            return {"error": "Đang chạy"}
        self.clear_log()
        self.run_bg(self.delete_finals, root)
        return {"ok": 1}

    def process(self, root, count, overwrite):
        subs = sorted(p for p in root.iterdir() if p.is_dir() and p.name != BACKUP_DIR)
        # Manifest cũ (nếu có) được nạp để chạy nhiều lần vẫn khôi phục về đúng trạng thái GỐC ban đầu
        mf_path = root / MANIFEST
        manifest = {}
        if mf_path.is_file():
            try:
                manifest = json.loads(mf_path.read_text(encoding="utf-8"))
            except Exception:
                manifest = {}
        ok = skipped = 0
        for sub in subs:
            src = find_source(sub)
            if not src:
                self.log(f"[BỎ QUA] {sub.name}: không có ảnh jpg")
                skipped += 1
                continue
            entry = manifest.setdefault(sub.name, {"backed_up": [], "created": []})
            try:
                bdir = sub / BACKUP_DIR
                with Image.open(src) as im:
                    im = im.convert("RGB")
                    for i in range(count):
                        name = f"thumbnail-original-{i}-final.png"
                        dst = sub / name
                        if dst.exists() and not overwrite:
                            continue
                        if dst.exists():
                            if name not in entry["backed_up"] and name not in entry["created"]:
                                bdir.mkdir(exist_ok=True)
                                shutil.copy2(dst, bdir / name)
                                entry["backed_up"].append(name)
                        elif name not in entry["created"] and name not in entry["backed_up"]:
                            entry["created"].append(name)
                        im.save(dst, "PNG")
                self.log(f"[OK] {sub.name}: tạo {count} ảnh từ {src.name}")
                ok += 1
            except Exception as e:
                self.log(f"[LỖI] {sub.name}: {e}")
                skipped += 1
        mf_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
        self.log(f"\nXong: {ok} thành công, {skipped} bỏ qua/lỗi (tổng {len(subs)} thư mục)")

    def restore(self, root):
        mf_path = root / MANIFEST
        try:
            manifest = json.loads(mf_path.read_text(encoding="utf-8"))
        except Exception as e:
            self.log(f"[LỖI] Không đọc được dữ liệu sao lưu: {e}")
            return
        restored = removed = failed = 0
        for sub_name, entry in manifest.items():
            sub = root / sub_name
            if not sub.is_dir():
                continue
            bdir = sub / BACKUP_DIR
            try:
                for name in entry.get("backed_up", []):
                    b = bdir / name
                    if b.is_file():
                        shutil.copy2(b, sub / name)
                        b.unlink()
                        restored += 1
                for name in entry.get("created", []):
                    p = sub / name
                    if p.is_file():
                        p.unlink()
                        removed += 1
                if bdir.is_dir() and not any(bdir.iterdir()):
                    bdir.rmdir()
                self.log(f"[OK] {sub_name}: khôi phục {len(entry.get('backed_up', []))} file cũ, xóa {len(entry.get('created', []))} file mới tạo")
            except Exception as e:
                failed += 1
                self.log(f"[LỖI] {sub_name}: {e}")
        if not failed:
            mf_path.unlink(missing_ok=True)
        self.log(f"\nĐã khôi phục gốc: {restored} file cũ được trả lại, {removed} file mới tạo đã xóa, {failed} lỗi")

    def delete_finals(self, root):
        subs = sorted(p for p in root.iterdir() if p.is_dir() and p.name != BACKUP_DIR)
        total = failed = 0
        for sub in subs:
            try:
                files = final_files(sub)
                for p in files:
                    p.unlink()
                if files:
                    self.log(f"[XÓA] {sub.name}: {len(files)} file thumbnail-original-N-final.png")
                total += len(files)
            except Exception as e:
                failed += 1
                self.log(f"[LỖI] {sub.name}: {e}")
        # Sau khi xóa thủ công, dữ liệu sao lưu cũ không còn ý nghĩa
        (root / MANIFEST).unlink(missing_ok=True)
        for sub in subs:
            shutil.rmtree(sub / BACKUP_DIR, ignore_errors=True)
        self.log(f"\nĐã xóa {total} file thumbnail-original-N-final.png trong {len(subs)} thư mục ({failed} lỗi)")

    # ================================================================== DỌN M4A / MP4 & ID THIẾU MP3
    def _clean_pass(self, root: Path, opts: dict, dry_run: bool) -> dict:
        del_no_mp3 = bool(opts.get("delete_no_mp3_dir", True))
        del_outer_m4a = bool(opts.get("delete_outer_m4a", True))
        del_out_media = bool(opts.get("delete_output_media", True))

        st = {
            "scanned_ids": 0,
            "deleted_dirs": 0,
            "deleted_outer_m4a": 0,
            "deleted_out_m4a": 0,
            "deleted_out_mp4": 0,
            "freed_bytes": 0,
            "errors": 0,
            "skipped_active": 0,
        }

        for id_dir in _iter_id_folders(root):
            if self._clean_stop.is_set():
                break
            st["scanned_ids"] += 1
            try:
                entries = list(id_dir.iterdir())
            except OSError as e:
                st["errors"] += 1
                self._clean_log(f"[LỖI ĐỌC] {id_dir}: {e}")
                continue

            try:
                rel = str(id_dir.relative_to(root))
            except ValueError:
                rel = id_dir.name

            has_mp3 = any(p.is_file() and p.suffix.lower() == ".mp3" for p in entries)
            if not has_mp3:
                if del_no_mp3:
                    if _has_recent_active_download(id_dir):
                        st["skipped_active"] += 1
                        self._clean_log(f"[BỎ QUA - ĐANG TẢI] {rel}")
                        continue
                    sz = _dir_size(id_dir)
                    if dry_run:
                        st["deleted_dirs"] += 1
                        st["freed_bytes"] += sz
                        self._clean_log(f"[DỰ KIẾN XÓA ID] {rel} (không có .mp3 • {_fmt_size(sz)})")
                    else:
                        try:
                            shutil.rmtree(id_dir)
                            st["deleted_dirs"] += 1
                            st["freed_bytes"] += sz
                            self._clean_log(f"[XÓA THƯ MỤC ID] {rel} (không có .mp3 • {_fmt_size(sz)})")
                        except OSError as e:
                            st["errors"] += 1
                            self._clean_log(f"[ĐANG DÙNG/BỎ QUA] Không xóa được thư mục {rel}: {e}")
                continue

            if del_outer_m4a:
                for p in entries:
                    if self._clean_stop.is_set():
                        break
                    if not (p.is_file() and p.suffix.lower() == ".m4a"):
                        continue
                    try:
                        sz = p.stat().st_size
                    except OSError:
                        sz = 0
                    if dry_run:
                        st["deleted_outer_m4a"] += 1
                        st["freed_bytes"] += sz
                        self._clean_log(f"[DỰ KIẾN XÓA M4A] {rel}\\{p.name} ({_fmt_size(sz)})")
                    else:
                        try:
                            p.unlink()
                            st["deleted_outer_m4a"] += 1
                            st["freed_bytes"] += sz
                            self._clean_log(f"[XÓA M4A] {rel}\\{p.name} ({_fmt_size(sz)})")
                        except OSError as e:
                            st["errors"] += 1
                            self._clean_log(f"[ĐANG DÙNG/BỎ QUA] {rel}\\{p.name}: {e}")

            if del_out_media:
                for sub in entries:
                    if self._clean_stop.is_set():
                        break
                    if not (sub.is_dir() and sub.name.lower() in ("outputs", "output")):
                        continue
                    try:
                        out_files = list(sub.rglob("*"))
                    except OSError as e:
                        st["errors"] += 1
                        self._clean_log(f"[LỖI ĐỌC] {rel}\\{sub.name}: {e}")
                        continue
                    for f in out_files:
                        if self._clean_stop.is_set():
                            break
                        if not f.is_file():
                            continue
                        ext = f.suffix.lower()
                        if ext not in (".m4a", ".mp4"):
                            continue
                        try:
                            sz = f.stat().st_size
                        except OSError:
                            sz = 0
                        if dry_run:
                            if ext == ".m4a":
                                st["deleted_out_m4a"] += 1
                            else:
                                st["deleted_out_mp4"] += 1
                            st["freed_bytes"] += sz
                            self._clean_log(f"[DỰ KIẾN XÓA OUTPUT] {rel}\\{sub.name}\\{f.name} ({_fmt_size(sz)})")
                        else:
                            try:
                                f.unlink()
                                if ext == ".m4a":
                                    st["deleted_out_m4a"] += 1
                                else:
                                    st["deleted_out_mp4"] += 1
                                st["freed_bytes"] += sz
                                self._clean_log(f"[XÓA OUTPUT] {rel}\\{sub.name}\\{f.name} ({_fmt_size(sz)})")
                            except OSError as e:
                                st["errors"] += 1
                                self._clean_log(f"[ĐANG DÙNG/BỎ QUA] {rel}\\{sub.name}\\{f.name}: {e}")
        return st

    def _run_clean_worker(self, root: Path, mode: str, interval_sec: int, opts: dict):
        dry_run = mode == "preview"
        continuous = mode == "watch"
        cycle = 0
        try:
            while not self._clean_stop.is_set():
                cycle += 1
                with self._clean_lock:
                    self._clean_state["cycle"] = cycle
                    self._clean_state["message"] = (
                        f"Đang quét thử thư mục..." if dry_run
                        else (f"Đang quét & dọn vòng #{cycle}..." if continuous else "Đang quét & dọn thư mục...")
                    )
                res = self._clean_pass(root, opts, dry_run=dry_run)
                changed = (
                    res["deleted_dirs"]
                    + res["deleted_outer_m4a"]
                    + res["deleted_out_m4a"]
                    + res["deleted_out_mp4"]
                )
                with self._clean_lock:
                    self._clean_state["scanned_ids"] = res["scanned_ids"]
                    self._clean_state["deleted_dirs"] += res["deleted_dirs"]
                    self._clean_state["deleted_outer_m4a"] += res["deleted_outer_m4a"]
                    self._clean_state["deleted_out_m4a"] += res["deleted_out_m4a"]
                    self._clean_state["deleted_out_mp4"] += res["deleted_out_mp4"]
                    self._clean_state["freed_bytes"] += res["freed_bytes"]
                    self._clean_state["errors"] += res["errors"]
                    self._clean_state["last_cycle_at"] = time.strftime("%H:%M:%S")
                if (not continuous) or cycle == 1 or changed > 0 or res["errors"] > 0 or res["skipped_active"] > 0:
                    verb = "Dự kiến" if dry_run else "Đã xóa"
                    self._clean_log(
                        f"Vòng #{cycle}: quét {res['scanned_ids']} thư mục ID • "
                        f"{verb}: {res['deleted_dirs']} ID thiếu .mp3, "
                        f"{res['deleted_outer_m4a']} .m4a ngoài, "
                        f"{res['deleted_out_m4a']} .m4a + {res['deleted_out_mp4']} .mp4 trong outputs • "
                        f"{'Sẽ giải phóng' if dry_run else 'Giải phóng'} {_fmt_size(res['freed_bytes'])}"
                        + (f" • bỏ qua đang tải: {res['skipped_active']}" if res["skipped_active"] else "")
                        + (f" • lỗi: {res['errors']}" if res["errors"] else "")
                    )
                if (not continuous) or self._clean_stop.is_set():
                    break
                with self._clean_lock:
                    self._clean_state["message"] = f"Đang canh liên tục (Vòng #{cycle}) • Chờ {interval_sec}s tới vòng tiếp theo..."
                if self._clean_stop.wait(interval_sec):
                    break
        except Exception as e:
            self._clean_log(f"[LỖI] {e}")
            with self._clean_lock:
                self._clean_state["errors"] += 1
        finally:
            with self._clean_lock:
                self._clean_state["running"] = False
                if self._clean_stop.is_set():
                    self._clean_state["message"] = "Đã dừng"
                elif dry_run:
                    self._clean_state["message"] = "Hoàn tất quét thử"
                else:
                    self._clean_state["message"] = "Hoàn tất dọn 1 lần"

    def act_clean_start(self, data):
        data = data or {}
        root = self._root(data)
        if not root:
            return {"error": "Thư mục không hợp lệ"}
        mode = str(data.get("mode") or "once").strip().lower()
        if mode not in ("preview", "once", "watch"):
            return {"error": "Chế độ quét không hợp lệ"}
        try:
            interval_sec = max(5, min(3600, int(data.get("interval_sec") or 30)))
        except Exception:
            interval_sec = 30
        opts = {
            "delete_no_mp3_dir": bool(data.get("delete_no_mp3_dir", True)),
            "delete_outer_m4a": bool(data.get("delete_outer_m4a", True)),
            "delete_output_media": bool(data.get("delete_output_media", True)),
        }
        with self._clean_lock:
            if self._clean_state.get("running"):
                return {"error": "Bộ dọn file đang chạy — hãy bấm Dừng trước"}
            self._clean_stop.clear()
            self._clean_logs.clear()
            self._clean_state = {
                "running": True,
                "mode": mode,
                "root": str(root),
                "cycle": 0,
                "interval_sec": interval_sec,
                "scanned_ids": 0,
                "deleted_dirs": 0,
                "deleted_outer_m4a": 0,
                "deleted_out_m4a": 0,
                "deleted_out_mp4": 0,
                "freed_bytes": 0,
                "errors": 0,
                "last_cycle_at": "",
                "message": "Đang khởi tạo quét...",
            }
        mode_lbl = {"preview": "Quét thử (xem trước)", "once": "Dọn ngay 1 lần", "watch": f"Quét & dọn liên tục mỗi {interval_sec}s"}[mode]
        self._clean_log(f"Bắt đầu {mode_lbl}: {root}")
        threading.Thread(
            target=self._run_clean_worker,
            args=(root, mode, interval_sec, opts),
            daemon=True,
            name="tc-media-cleaner",
        ).start()
        return {"ok": 1}

    def act_clean_stop(self, data):
        with self._clean_lock:
            was_running = bool(self._clean_state.get("running"))
        self._clean_stop.set()
        if was_running:
            self._clean_log("⏹ Đã gửi lệnh dừng quét dọn...")
        return {"ok": 1}

    def act_clean_status(self, data):
        try:
            since = max(0, int((data or {}).get("since") or 0))
        except Exception:
            since = 0
        with self._clean_lock:
            return {
                "ok": 1,
                "state": dict(self._clean_state),
                "lines": list(self._clean_logs[since:]),
                "next": len(self._clean_logs),
            }
