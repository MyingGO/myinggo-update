"""Tính năng: chuyển định dạng ảnh (Pillow) và video/âm thanh (ffmpeg)."""
import contextlib
import os
import re
import subprocess
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from PIL import Image

from core import dialogs
from core.base import Feature
from features.downloader import find_ffmpeg

NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
IMG_EXT = {"png", "jpg", "jpeg", "webp", "bmp", "gif", "tif", "tiff", "ico"}
VID_EXT = {"mp4", "mkv", "webm", "avi", "mov", "flv", "wmv", "m4v", "mpg", "mpeg", "ts", "3gp"}
AUD_EXT = {"mp3", "wav", "aac", "m4a", "flac", "ogg", "opus", "wma"}
IMG_TARGETS = ["png", "jpg", "webp", "bmp", "gif", "tiff", "ico"]
VID_TARGETS = ["mp4", "mkv", "webm", "avi", "mov", "gif"]
AUD_TARGETS = ["mp3", "wav", "m4a", "flac", "ogg"]
PIL_FORMAT = {"png": "PNG", "jpg": "JPEG", "webp": "WEBP", "bmp": "BMP", "gif": "GIF", "tiff": "TIFF", "ico": "ICO"}
CRF = {"high": 20, "balanced": 23, "small": 28}
CQ_NVENC = {"high": 19, "balanced": 23, "small": 29}
TIME = re.compile(r"Duration:\s*(\d+):(\d+):([\d.]+)")
KV = re.compile(r"^([a-z_0-9]+)=(\S*)$")
VSTREAM = re.compile(r"Stream\s+#\d+:\d+.*?:\s*Video:\s*([a-zA-Z0-9_]+)", re.I)
ASTREAM = re.compile(r"Stream\s+#\d+:\d+.*?:\s*Audio:\s*([a-zA-Z0-9_]+)", re.I)

CONTAINER_VCODECS = {
    "mkv": {"h264", "hevc", "vp8", "vp9", "av1", "mpeg4", "mpeg2video", "mpeg1video", "mjpeg", "prores", "msmpeg4v3", "wmv3", "vc1"},
    "mp4": {"h264", "hevc", "mpeg4", "av1"},
    "mov": {"h264", "hevc", "mpeg4", "prores", "mjpeg"},
    "webm": {"vp8", "vp9", "av1"},
}
CONTAINER_ACODECS = {
    "mkv": {"aac", "mp3", "opus", "vorbis", "flac", "ac3", "eac3", "dts", "alac", "mp2", "pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm_f32le"},
    "mp4": {"aac", "mp3", "ac3", "eac3", "alac", "mp2"},
    "mov": {"aac", "mp3", "alac", "pcm_s16le", "pcm_s24le", "pcm_s32le"},
    "webm": {"opus", "vorbis"},
}
AUD_COPY_CODECS = {
    "m4a": {"aac", "alac"},
    "mp3": {"mp3"},
    "flac": {"flac"},
    "ogg": {"vorbis"},
}

_HW_CACHE = {}
_HW_LOCK = threading.Lock()


def ext_of(p):
    return Path(p).suffix.lower().lstrip(".")


def is_media(p):
    e = ext_of(p)
    return e in IMG_EXT or e in VID_EXT or e in AUD_EXT


def unique(path: Path, reserved: set | None = None):
    def _taken(p: Path):
        return p.exists() or (reserved is not None and str(p).lower() in reserved)

    if not _taken(path):
        return path
    i = 1
    while True:
        c = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not _taken(c):
            return c
        i += 1


def detect_hw_encoder(ff: str):
    """Tự kiểm tra GPU encoder khả dụng (NVENC / QSV / AMF) và cache theo đường dẫn ffmpeg."""
    if not ff:
        return {"encoder": None, "label": ""}
    with _HW_LOCK:
        if ff in _HW_CACHE:
            return dict(_HW_CACHE[ff])

    res = {"encoder": None, "label": "CPU nhanh (libx264)"}
    try:
        r = subprocess.run([ff, "-hide_banner", "-encoders"], capture_output=True, text=True, timeout=5, creationflags=NOWIN)
        enc_txt = (r.stdout or "") + "\n" + (r.stderr or "")
        candidates = [
            ("h264_nvenc", "GPU NVIDIA NVENC", ["-c:v", "h264_nvenc", "-preset", "p4"]),
            ("h264_qsv", "GPU Intel QSV", ["-c:v", "h264_qsv", "-preset", "faster"]),
            ("h264_amf", "GPU AMD AMF", ["-c:v", "h264_amf", "-quality", "speed"]),
        ]
        for name, label, enc_args in candidates:
            if name not in enc_txt:
                continue
            test = subprocess.run(
                [ff, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=black:s=256x256:d=0.1",
                 "-frames:v", "1", *enc_args, "-f", "null", "-"],
                capture_output=True, timeout=4, creationflags=NOWIN,
            )
            if test.returncode == 0:
                res = {"encoder": name, "label": label}
                break
    except Exception:
        pass

    with _HW_LOCK:
        _HW_CACHE[ff] = dict(res)
    return dict(res)


def probe_media(ff: str, src: Path):
    """Đọc nhanh codec video/âm thanh và thời lượng nguồn bằng ffmpeg -i."""
    info = {"duration": 0.0, "vcodec": "", "acodec": ""}
    try:
        r = subprocess.run(
            [ff, "-hide_banner", "-nostdin", "-i", str(src)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, creationflags=NOWIN,
        )
        out = (r.stdout or b"").decode("utf-8", "replace")
        for line in out.splitlines():
            if not info["duration"]:
                m = TIME.search(line)
                if m:
                    info["duration"] = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
            low = line.lower()
            if "attached pic" in low:
                continue
            if not info["vcodec"]:
                mv = VSTREAM.search(line)
                if mv:
                    info["vcodec"] = mv.group(1).lower()
            if not info["acodec"]:
                ma = ASTREAM.search(line)
                if ma:
                    info["acodec"] = ma.group(1).lower()
    except Exception:
        pass
    return info


class Converter(Feature):
    title = "Chuyển định dạng"
    order = 18

    def __init__(self):
        super().__init__()
        self._conv_lock = threading.Lock()
        self._procs = set()
        self.stopped = False
        self.prog = {"pct": 0, "text": ""}

    # ---- chọn file ----
    def act_pick_files(self, data):
        return {"files": dialogs.pick_files()}

    def act_pick_folder(self, data):
        p = dialogs.pick_folder()
        if not p:
            return {"files": []}
        return {"files": sorted(str(x) for x in Path(p).iterdir() if x.is_file() and is_media(x))}

    def act_pick_out(self, data):
        return {"path": dialogs.pick_folder()}

    def act_status(self, data):
        ff = find_ffmpeg()
        hw = detect_hw_encoder(ff) if ff else {"encoder": None, "label": ""}
        return {
            "ffmpeg": ff,
            "hw": hw,
            "running": self.running,
            "cpu_count": os.cpu_count() or 4,
            "formats": {"image": IMG_TARGETS, "video": VID_TARGETS, "audio": AUD_TARGETS},
        }

    def act_progress(self, data):
        return dict(self.prog, running=self.running)

    def act_stop(self, data):
        self.stopped = True
        with self._conv_lock:
            procs = list(self._procs)
        for p in procs:
            try:
                if p.poll() is None:
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True, creationflags=NOWIN)
            except Exception:
                pass
        return {}

    def act_open_folder(self, data):
        p = data.get("path")
        if p and Path(p).exists():
            os.startfile(p)
        return {}

    def act_start(self, data):
        files = [f for f in data.get("files", []) if Path(f).is_file()]
        target = (data.get("target") or "").lower()
        if not files:
            return {"error": "Chưa chọn file nào"}
        if target not in IMG_TARGETS + VID_TARGETS + AUD_TARGETS:
            return {"error": "Chưa chọn định dạng đầu ra"}
        out_dir = (data.get("out_dir") or "").strip()
        if out_dir:
            try:
                Path(out_dir).mkdir(parents=True, exist_ok=True)
            except Exception as e:
                return {"error": f"Không tạo được thư mục: {e}"}
        if self.running:
            return {"error": "Đang chạy"}
        self.clear_log()
        self.stopped = False
        self.prog = {"pct": 0, "text": "Đang bắt đầu..."}
        mode = data.get("mode") if data.get("mode") in ("fast", "reencode") else "fast"
        try:
            workers = max(1, min(8, int(data.get("workers") or 3)))
        except (TypeError, ValueError):
            workers = 3
        opts = {
            "quality": int(data.get("quality") or 90),
            "vq": data.get("vq", "balanced"),
            "overwrite": bool(data.get("overwrite")),
            "mode": mode,
            "workers": workers,
        }
        self.run_bg(self.work, files, target, out_dir, opts)
        return {"ok": 1}

    # ---- xử lý ----
    def work(self, files, target, out_dir, opts):
        t_start = time.monotonic()
        ff = find_ffmpeg()
        hw = detect_hw_encoder(ff) if ff else {"encoder": None, "label": ""}
        total = len(files)
        workers = max(1, min(int(opts.get("workers", 3)), total))
        hw_sem = threading.Semaphore(min(workers, 3))
        mode = opts.get("mode", "fast")
        vq = opts.get("vq", "balanced")

        mode_label = "Siêu nhanh (Copy luồng nếu tương thích)" if (mode == "fast" and vq != "small") else "Mã hóa lại"
        hw_label = hw.get("label") or "Không có ffmpeg"
        self.log(f"[BẮT ĐẦU] {total} file -> {target.upper()} | Chế độ: {mode_label} | {workers} luồng | Tăng tốc: {hw_label}")

        file_fracs = [0.0] * total
        active = {}
        reserved = set()
        counts = {"ok": 0, "fail": 0, "skip": 0, "done": 0}

        def update_prog(idx, frac=None, label=None, finished=False):
            with self._conv_lock:
                if frac is not None:
                    file_fracs[idx] = max(0.0, min(1.0, float(frac)))
                if finished:
                    active.pop(idx, None)
                    counts["done"] += 1
                elif label is not None:
                    active[idx] = (label, file_fracs[idx])
                elif idx in active:
                    active[idx] = (active[idx][0], file_fracs[idx])
                pct = sum(file_fracs) / total * 100.0 if total else 100.0
                done_cnt = counts["done"]
                parts = [f"{name} {f * 100:.0f}%" for _, (name, f) in list(active.items())[:2]]
                extra = f" (+{len(active) - 2})" if len(active) > 2 else ""
                tail_txt = (" | ".join(parts) + extra) if parts else "Đang xử lý..."
                self.prog = {"pct": round(pct, 1), "text": f"[{done_cnt}/{total}] {tail_txt}"}

        def process_one(idx, f):
            if self.stopped:
                return
            src = Path(f)
            e = ext_of(src)
            dst_dir = Path(out_dir) if out_dir else src.parent

            with self._conv_lock:
                dst = dst_dir / f"{src.stem}.{target}"
                try:
                    same_file = dst.resolve() == src.resolve()
                except Exception:
                    same_file = str(dst).lower() == str(src).lower()
                if same_file:
                    self.log(f"[BỎ QUA] {src.name}: đã đúng định dạng {target}")
                    counts["skip"] += 1
                    file_fracs[idx] = 1.0
                    counts["done"] += 1
                    return
                if (not opts["overwrite"]) or (str(dst).lower() in reserved):
                    dst = unique(dst, reserved)
                reserved.add(str(dst).lower())

            if e in IMG_EXT and target not in IMG_TARGETS:
                self.log(f"[BỎ QUA] {src.name}: ảnh không chuyển được sang {target}")
                with self._conv_lock:
                    counts["skip"] += 1
                update_prog(idx, frac=1.0, finished=True)
                return

            if e not in IMG_EXT:
                if not ff:
                    self.log(f"[LỖI] {src.name}: cần ffmpeg (chọn ở tab Tải video / MP3)")
                    with self._conv_lock:
                        counts["fail"] += 1
                    update_prog(idx, frac=1.0, finished=True)
                    return
                if e in AUD_EXT and target in VID_TARGETS + IMG_TARGETS:
                    self.log(f"[BỎ QUA] {src.name}: file âm thanh không chuyển sang {target}")
                    with self._conv_lock:
                        counts["skip"] += 1
                    update_prog(idx, frac=1.0, finished=True)
                    return

            update_prog(idx, frac=0.0, label=src.name)
            t0 = time.monotonic()
            try:
                if e in IMG_EXT:
                    self.convert_image(src, dst, target, opts["quality"])
                    tag = "Ảnh"
                else:
                    tag = self.convert_media(
                        ff, src, dst, target, vq, mode, hw.get("encoder"), hw_sem,
                        lambda frac: update_prog(idx, frac=frac),
                    )
                dt = time.monotonic() - t0
                self.log(f"[OK • {tag} • {dt:.1f}s] {src.name} -> {dst.name}")
                with self._conv_lock:
                    counts["ok"] += 1
            except Exception as ex:
                self.log(f"[LỖI] {src.name}: {ex}")
                with self._conv_lock:
                    counts["fail"] += 1
                try:
                    if dst.exists() and (dst.stat().st_size == 0 or self.stopped):
                        dst.unlink()
                except Exception:
                    pass
            finally:
                update_prog(idx, frac=1.0, finished=True)

        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(process_one, idx, f) for idx, f in enumerate(files)]
            for fut in as_completed(futs):
                try:
                    fut.result()
                except Exception as ex:
                    self.log(f"[LỖI] {ex}")

        total_dt = time.monotonic() - t_start
        self.prog = {
            "pct": 100 if not self.stopped else self.prog["pct"],
            "text": "Đã dừng" if self.stopped else f"Hoàn tất ({total_dt:.1f}s)",
        }
        self.log(f"\nXong: {counts['ok']} thành công, {counts['fail']} lỗi, {counts['skip']} bỏ qua ({total_dt:.1f}s).")

    def convert_image(self, src, dst, target, quality):
        with Image.open(src) as im:
            fmt = PIL_FORMAT[target]
            kw = {}
            animated = getattr(im, "is_animated", False) and target in ("gif", "webp")
            if animated:
                kw["save_all"] = True
                kw["loop"] = 0
            if target in ("jpg", "bmp"):
                im = im.convert("RGBA")
                bg = Image.new("RGB", im.size, (255, 255, 255))
                bg.paste(im, mask=im.split()[3])
                im = bg
            elif target == "ico":
                im = im.convert("RGBA")
                im.thumbnail((256, 256))
            elif im.mode in ("P", "LA", "CMYK") and target in ("png", "webp", "tiff"):
                im = im.convert("RGBA" if "transparency" in im.info or im.mode == "LA" else "RGB")
            elif im.mode not in ("RGB", "RGBA", "L", "P") and target == "gif":
                im = im.convert("RGB")
            if target in ("jpg", "webp"):
                kw["quality"] = max(1, min(100, quality))
            elif target == "png":
                kw["compress_level"] = 3
            im.save(dst, fmt, **kw)

    def codec_args(self, target, vq):
        crf = CRF.get(vq, 23)
        if target in ("mp4", "mov", "mkv"):
            preset = "superfast" if vq == "small" else "veryfast"
            ab = "128k" if vq == "small" else "192k"
            a = ["-c:v", "libx264", "-crf", str(crf), "-preset", preset, "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", ab]
            return a + (["-movflags", "+faststart"] if target != "mkv" else [])
        if target == "webm":
            return ["-c:v", "libvpx-vp9", "-crf", str(crf + 9), "-b:v", "0", "-deadline", "good", "-cpu-used", "4", "-row-mt", "1", "-c:a", "libopus", "-b:a", "128k"]
        if target == "avi":
            return ["-c:v", "mpeg4", "-q:v", "4", "-c:a", "libmp3lame", "-q:a", "3"]
        if target == "gif":
            return ["-vf", "fps=12,scale=480:-1:flags=lanczos,split[s0][s1];[s0]palettegen=stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3", "-loop", "0"]
        if target == "mp3":
            return ["-vn", "-c:a", "libmp3lame", "-q:a", "2"]
        if target == "wav":
            return ["-vn", "-c:a", "pcm_s16le"]
        if target == "m4a":
            return ["-vn", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart"]
        if target == "flac":
            return ["-vn", "-c:a", "flac"]
        if target == "ogg":
            return ["-vn", "-c:a", "libvorbis", "-q:a", "5"]
        if target in IMG_TARGETS:  # lấy khung hình đầu tiên
            return ["-frames:v", "1"]
        return []

    def plan_media_args(self, target, vq, mode, info, hw_enc):
        """Lập danh sách phương án ffmpeg theo thứ tự nhanh nhất -> dự phòng an toàn."""
        vcodec = info.get("vcodec", "")
        acodec = info.get("acodec", "")
        attempts = []

        if target in ("mp4", "mov", "mkv"):
            map_args = ["-map", "0:v:0?", "-map", "0:a?", "-dn"]
            faststart = ["-movflags", "+faststart"] if target != "mkv" else []
            vtag = ["-tag:v", "hvc1"] if vcodec == "hevc" and target in ("mp4", "mov") else []
            if mode == "fast" and vq != "small" and vcodec:
                v_ok = vcodec in CONTAINER_VCODECS[target]
                a_ok = (not acodec) or (acodec in CONTAINER_ACODECS[target])
                if v_ok and a_ok:
                    attempts.append((["-fflags", "+genpts"], map_args + ["-c", "copy"] + vtag + faststart, "Copy luồng", False))
                elif v_ok:
                    attempts.append((["-fflags", "+genpts"], map_args + ["-c:v", "copy"] + vtag + ["-c:a", "aac", "-b:a", "192k", "-threads", "0"] + faststart, "Copy video + AAC", False))

            if mode == "fast" and vq != "small" and acodec and acodec in CONTAINER_ACODECS[target]:
                aargs = ["-c:a", "copy"]
            else:
                ab = "128k" if vq == "small" else "192k"
                aargs = ["-c:a", "aac", "-b:a", ab]

            if hw_enc == "h264_nvenc":
                gv = ["-c:v", "h264_nvenc", "-preset", "p4", "-tune", "hq", "-rc", "vbr", "-cq", str(CQ_NVENC.get(vq, 23)), "-b:v", "0", "-pix_fmt", "yuv420p"]
                attempts.append(([], ["-threads", "0"] + map_args + gv + aargs + faststart, "GPU NVENC", True))
            elif hw_enc == "h264_qsv":
                gv = ["-c:v", "h264_qsv", "-preset", "faster", "-global_quality", str(CRF.get(vq, 23)), "-pix_fmt", "nv12"]
                attempts.append(([], ["-threads", "0"] + map_args + gv + aargs + faststart, "GPU QSV", True))
            elif hw_enc == "h264_amf":
                gv = ["-c:v", "h264_amf", "-quality", "speed", "-rc", "cqp", "-qp_i", str(CRF.get(vq, 23)), "-qp_p", str(CRF.get(vq, 23)), "-pix_fmt", "yuv420p"]
                attempts.append(([], ["-threads", "0"] + map_args + gv + aargs + faststart, "GPU AMF", True))

            preset = "superfast" if vq == "small" else "veryfast"
            cpu_v = ["-c:v", "libx264", "-crf", str(CRF.get(vq, 23)), "-preset", preset, "-pix_fmt", "yuv420p"]
            attempts.append(([], ["-threads", "0"] + map_args + cpu_v + aargs + faststart, f"CPU {preset}", False))
            return attempts

        if target == "webm":
            map_args = ["-map", "0:v:0?", "-map", "0:a?", "-dn"]
            if mode == "fast" and vq != "small" and vcodec in CONTAINER_VCODECS["webm"]:
                if (not acodec) or (acodec in CONTAINER_ACODECS["webm"]):
                    attempts.append((["-fflags", "+genpts"], map_args + ["-c", "copy"], "Copy luồng", False))
                else:
                    attempts.append((["-fflags", "+genpts"], map_args + ["-c:v", "copy", "-c:a", "libopus", "-b:a", "128k", "-threads", "0"], "Copy video + Opus", False))
            attempts.append(([], ["-threads", "0"] + map_args + self.codec_args("webm", vq), "VP9 nhanh", False))
            return attempts

        if target in AUD_TARGETS:
            if mode == "fast" and target in AUD_COPY_CODECS and acodec in AUD_COPY_CODECS[target]:
                extra = ["-movflags", "+faststart"] if target == "m4a" else []
                attempts.append(([], ["-vn", "-c:a", "copy"] + extra, "Copy âm thanh", False))
            attempts.append(([], ["-threads", "0"] + self.codec_args(target, vq), f"Âm thanh {target.upper()}", False))
            return attempts

        return [([], ["-threads", "0"] + self.codec_args(target, vq), target.upper(), False)]

    def _run_ffmpeg_once(self, cmd, dur_hint, on_frac):
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=NOWIN)
        with self._conv_lock:
            self._procs.add(proc)
        dur = dur_hint or 0.0
        tail = deque(maxlen=12)
        try:
            for raw in iter(proc.stdout.readline, b""):
                line = raw.decode("utf-8", "replace").strip()
                if not dur:
                    m = TIME.search(line)
                    if m:
                        dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
                kv = KV.match(line)
                if kv:
                    if kv.group(1) == "out_time_us" and dur and kv.group(2).lstrip("-").isdigit():
                        frac = max(0.0, min(1.0, int(kv.group(2)) / 1e6 / dur))
                        on_frac(frac)
                elif line:
                    tail.append(line)
            code = proc.wait()
            return code, list(tail)
        finally:
            with self._conv_lock:
                self._procs.discard(proc)

    def convert_media(self, ff, src, dst, target, vq, mode, hw_enc, hw_sem, on_frac):
        info = probe_media(ff, src)
        attempts = self.plan_media_args(target, vq, mode, info, hw_enc)
        last_tail = []
        for i, (in_args, out_args, tag, is_hw) in enumerate(attempts):
            if self.stopped:
                raise RuntimeError("đã dừng")
            cmd = [ff, "-hide_banner", "-nostdin", "-y"] + in_args + ["-i", str(src)] + out_args + ["-progress", "pipe:1", str(dst)]
            ctx = hw_sem if is_hw else contextlib.nullcontext()
            with ctx:
                if self.stopped:
                    raise RuntimeError("đã dừng")
                code, tail = self._run_ffmpeg_once(cmd, info.get("duration", 0.0), on_frac)
            if code == 0:
                return tag
            if self.stopped:
                try:
                    if dst.exists():
                        dst.unlink()
                except Exception:
                    pass
                raise RuntimeError("đã dừng")
            last_tail = tail
            if i + 1 < len(attempts):
                try:
                    if dst.exists():
                        dst.unlink()
                except Exception:
                    pass
                next_tag = attempts[i + 1][2]
                self.log(f"[THỬ LẠI] {src.name}: {tag} chưa phù hợp, tự chuyển sang {next_tag}...")
                on_frac(0.0)
        raise RuntimeError("ffmpeg lỗi: " + " | ".join(last_tail[-3:]))
