"""Tính năng: chuyển định dạng ảnh (Pillow) và video/âm thanh (ffmpeg)."""
import os
import re
import subprocess
from collections import deque
from pathlib import Path

from PIL import Image

from core import dialogs
from core.base import Feature
from features.downloader import find_ffmpeg

NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
IMG_EXT = {"png", "jpg", "jpeg", "webp", "bmp", "gif", "tif", "tiff", "ico"}
VID_EXT = {"mp4", "mkv", "webm", "avi", "mov", "flv", "wmv", "m4v", "mpg", "mpeg", "ts", "3gp"}
AUD_EXT = {"mp3", "wav", "aac", "m4a", "flac", "ogg", "opus", "wma"}
IMG_TARGETS = ["png", "jpg", "webp", "bmp", "gif", "tiff", "ico"]
VID_TARGETS = ["mp4", "mkv", "webm", "avi", "mov", "gif"]
AUD_TARGETS = ["mp3", "wav", "m4a", "flac", "ogg"]
PIL_FORMAT = {"png": "PNG", "jpg": "JPEG", "webp": "WEBP", "bmp": "BMP", "gif": "GIF", "tiff": "TIFF", "ico": "ICO"}
CRF = {"high": 20, "balanced": 23, "small": 28}
TIME = re.compile(r"Duration:\s*(\d+):(\d+):([\d.]+)")
KV = re.compile(r"^([a-z_0-9]+)=(\S*)$")


def ext_of(p):
    return Path(p).suffix.lower().lstrip(".")


def is_media(p):
    e = ext_of(p)
    return e in IMG_EXT or e in VID_EXT or e in AUD_EXT


def unique(path: Path):
    if not path.exists():
        return path
    i = 1
    while True:
        c = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not c.exists():
            return c
        i += 1


class Converter(Feature):
    title = "Chuyển định dạng"
    order = 18

    def __init__(self):
        super().__init__()
        self.proc = None
        self.stopped = False
        self.prog = {"pct": 0, "text": ""}

    # ---- chọn file ----
    def act_pick_files(self, data):
        return {"files": dialogs.pick_files()}

    def act_pick_folder(self, data):
        p = dialogs.pick_folder()
        if not p:
            return {"files": []}
        return {"files": sorted(str(x) for x in Path(p).iterdir() if x.is_file() and is_media(x))}

    def act_pick_out(self, data):
        return {"path": dialogs.pick_folder()}

    def act_status(self, data):
        return {"ffmpeg": find_ffmpeg(), "running": self.running,
                "formats": {"image": IMG_TARGETS, "video": VID_TARGETS, "audio": AUD_TARGETS}}

    def act_progress(self, data):
        return dict(self.prog, running=self.running)

    def act_stop(self, data):
        self.stopped = True
        if self.proc and self.proc.poll() is None:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.proc.pid)], capture_output=True, creationflags=NOWIN)
        return {}

    def act_open_folder(self, data):
        p = data.get("path")
        if p and Path(p).exists():
            os.startfile(p)
        return {}

    def act_start(self, data):
        files = [f for f in data.get("files", []) if Path(f).is_file()]
        target = (data.get("target") or "").lower()
        if not files:
            return {"error": "Chưa chọn file nào"}
        if target not in IMG_TARGETS + VID_TARGETS + AUD_TARGETS:
            return {"error": "Chưa chọn định dạng đầu ra"}
        out_dir = (data.get("out_dir") or "").strip()
        if out_dir:
            try:
                Path(out_dir).mkdir(parents=True, exist_ok=True)
            except Exception as e:
                return {"error": f"Không tạo được thư mục: {e}"}
        if self.running:
            return {"error": "Đang chạy"}
        self.clear_log()
        self.stopped = False
        self.prog = {"pct": 0, "text": "Đang bắt đầu..."}
        opts = {"quality": int(data.get("quality") or 90), "vq": data.get("vq", "balanced"),
                "overwrite": bool(data.get("overwrite"))}
        self.run_bg(self.work, files, target, out_dir, opts)
        return {"ok": 1}

    # ---- xử lý ----
    def work(self, files, target, out_dir, opts):
        ff = find_ffmpeg()
        ok = fail = skip = 0
        total = len(files)
        for idx, f in enumerate(files):
            if self.stopped:
                break
            src = Path(f)
            e = ext_of(src)
            dst_dir = Path(out_dir) if out_dir else src.parent
            dst = dst_dir / f"{src.stem}.{target}"
            self.prog = {"pct": idx / total * 100, "text": f"[{idx + 1}/{total}] {src.name}"}
            if dst.resolve() == src.resolve():
                self.log(f"[BỎ QUA] {src.name}: đã đúng định dạng {target}")
                skip += 1
                continue
            if not opts["overwrite"]:
                dst = unique(dst)
            try:
                if e in IMG_EXT:
                    if target not in IMG_TARGETS:
                        self.log(f"[BỎ QUA] {src.name}: ảnh không chuyển được sang {target}")
                        skip += 1
                        continue
                    self.convert_image(src, dst, target, opts["quality"])
                else:
                    if not ff:
                        self.log(f"[LỖI] {src.name}: cần ffmpeg (chọn ở tab Tải video / MP3)")
                        fail += 1
                        continue
                    if e in AUD_EXT and target in VID_TARGETS + IMG_TARGETS:
                        self.log(f"[BỎ QUA] {src.name}: file âm thanh không chuyển sang {target}")
                        skip += 1
                        continue
                    self.convert_media(ff, src, dst, target, opts["vq"], idx, total)
                self.log(f"[OK] {src.name} -> {dst.name}")
                ok += 1
            except Exception as ex:
                self.log(f"[LỖI] {src.name}: {ex}")
                fail += 1
                try:
                    if dst.exists() and dst.stat().st_size == 0:
                        dst.unlink()
                except Exception:
                    pass
        self.prog = {"pct": 100 if not self.stopped else self.prog["pct"], "text": "Đã dừng" if self.stopped else "Hoàn tất"}
        self.log(f"\nXong: {ok} thành công, {fail} lỗi, {skip} bỏ qua.")

    def convert_image(self, src, dst, target, quality):
        with Image.open(src) as im:
            fmt = PIL_FORMAT[target]
            kw = {}
            animated = getattr(im, "is_animated", False) and target in ("gif", "webp")
            if animated:
                kw["save_all"] = True
                kw["loop"] = 0
            if target in ("jpg", "bmp"):
                im = im.convert("RGBA")
                bg = Image.new("RGB", im.size, (255, 255, 255))
                bg.paste(im, mask=im.split()[3])
                im = bg
            elif target == "ico":
                im = im.convert("RGBA")
                im.thumbnail((256, 256))
            elif im.mode in ("P", "LA", "CMYK") and target in ("png", "webp", "tiff"):
                im = im.convert("RGBA" if "transparency" in im.info or im.mode == "LA" else "RGB")
            elif im.mode not in ("RGB", "RGBA", "L", "P") and target == "gif":
                im = im.convert("RGB")
            if target in ("jpg", "webp"):
                kw["quality"] = max(1, min(100, quality))
            if target == "jpg":
                kw["optimize"] = True
            im.save(dst, fmt, **kw)

    def codec_args(self, target, vq):
        crf = CRF.get(vq, 23)
        if target == "mp4" or target == "mov" or target == "mkv":
            a = ["-c:v", "libx264", "-crf", str(crf), "-preset", "medium", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k"]
            return a + (["-movflags", "+faststart"] if target != "mkv" else [])
        if target == "webm":
            return ["-c:v", "libvpx-vp9", "-crf", str(crf + 9), "-b:v", "0", "-c:a", "libopus"]
        if target == "avi":
            return ["-c:v", "mpeg4", "-q:v", "4", "-c:a", "libmp3lame", "-q:a", "3"]
        if target == "gif":
            return ["-vf", "fps=12,scale=480:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse", "-loop", "0"]
        if target == "mp3":
            return ["-vn", "-c:a", "libmp3lame", "-q:a", "2"]
        if target == "wav":
            return ["-vn", "-c:a", "pcm_s16le"]
        if target == "m4a":
            return ["-vn", "-c:a", "aac", "-b:a", "192k"]
        if target == "flac":
            return ["-vn", "-c:a", "flac"]
        if target == "ogg":
            return ["-vn", "-c:a", "libvorbis", "-q:a", "5"]
        if target in IMG_TARGETS:  # lấy khung hình đầu tiên
            return ["-frames:v", "1"]
        return []

    def convert_media(self, ff, src, dst, target, vq, idx, total):
        cmd = [ff, "-hide_banner", "-nostdin", "-y", "-i", str(src)] + self.codec_args(target, vq) + \
              ["-progress", "pipe:1", str(dst)]
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=NOWIN)
        dur = 0.0
        tail = deque(maxlen=12)
        for raw in iter(self.proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            m = TIME.search(line)
            if m and not dur:
                dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
            kv = KV.match(line)
            if kv:
                if kv.group(1) == "out_time_us" and dur and kv.group(2).lstrip("-").isdigit():
                    frac = max(0.0, min(1.0, int(kv.group(2)) / 1e6 / dur))
                    self.prog = {"pct": (idx + frac) / total * 100, "text": f"[{idx + 1}/{total}] {src.name} {frac * 100:.0f}%"}
            elif line:
                tail.append(line)
        code = self.proc.wait()
        if self.stopped:
            raise RuntimeError("đã dừng")
        if code != 0:
            raise RuntimeError("ffmpeg lỗi: " + " | ".join(list(tail)[-3:]))
