"""Tính năng: bốc video ngẫu nhiên theo thư mục con (bội của 30) sang NHIỀU thư mục xuất cùng lúc,
xuất TXT và hỗ trợ KHÔI PHỤC (trả video đã bốc về đúng vị trí cũ trong thư mục gốc)."""
from __future__ import annotations

import csv
import os
import random
import shutil
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from core import dialogs
from core.base import Feature

VIDEO_EXTENSIONS = {
    ".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".wmv", ".flv",
    ".mpeg", ".mpg", ".ts", ".m2ts", ".3gp", ".mts", ".vob"
}
BLOCK_SIZE = 30
LOG_NAME = "selected_videos_log.csv"


@dataclass
class FolderInfo:
    name: str
    path: Path
    videos: List[Path]
    available_blocks: int
    per_target_blocks: List[int] = field(default_factory=list)

    @property
    def available_count(self) -> int:
        return len(self.videos)

    @property
    def allocated_blocks(self) -> int:
        return sum(self.per_target_blocks)

    @property
    def allocated_count(self) -> int:
        return self.allocated_blocks * BLOCK_SIZE


@dataclass
class TargetSpec:
    output: Path
    total: int


def is_video_file(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS


def normalize_for_compare(path: Path) -> str:
    try:
        return str(path.resolve()).casefold()
    except Exception:
        return str(path.absolute()).casefold()


def is_child_or_same(child: Path, parent: Path) -> bool:
    child_s = normalize_for_compare(child).rstrip("\\/")
    parent_s = normalize_for_compare(parent).rstrip("\\/")
    return child_s == parent_s or child_s.startswith(parent_s + os.sep)


def find_category_folders(source_root: Path) -> List[Path]:
    return [p for p in sorted(source_root.iterdir(), key=lambda x: x.name.lower()) if p.is_dir()]


def scan_videos_in_folder(folder: Path) -> List[Path]:
    skip = {"$recycle.bin", "system volume information"}
    videos: List[Path] = []
    stack = [str(folder)]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            if e.name.lower() not in skip:
                                stack.append(e.path)
                        elif os.path.splitext(e.name)[1].lower() in VIDEO_EXTENSIONS and e.is_file():
                            videos.append(Path(e.path))
                    except OSError:
                        continue
        except OSError:
            continue
    videos.sort(key=lambda p: str(p).lower())
    return videos


def scan_source(source_root: Path, progress_cb=None) -> List[FolderInfo]:
    folders = find_category_folders(source_root)
    if not folders:
        return []
    # Giới hạn 4 luồng quét (trên ổ HDD cơ học hoặc ổ mạng ở máy khác, 8 luồng sẽ gây nghẽn đầu đọc và treo lâu)
    total_f = len(folders)
    results: List[FolderInfo] = []
    done = 0
    with ThreadPoolExecutor(max_workers=min(4, total_f)) as ex:
        fut_map = {ex.submit(scan_videos_in_folder, f): f for f in folders}
        from concurrent.futures import as_completed
        for fut in as_completed(fut_map):
            f = fut_map[fut]
            v = fut.result()
            done += 1
            if progress_cb:
                progress_cb(done, total_f, f.name, len(v))
            results.append(FolderInfo(name=f.name, path=f, videos=v, available_blocks=len(v) // BLOCK_SIZE))
    results.sort(key=lambda x: x.name.lower())
    return results


def allocate_multi_targets(folders: List[FolderInfo], targets: List[TargetSpec]) -> None:
    if not targets:
        raise ValueError("Chưa có mục xuất nào.")
    for idx, t in enumerate(targets, 1):
        if t.total <= 0:
            raise ValueError(f"Mục xuất #{idx} ({t.output}): số video cần lấy phải lớn hơn 0.")
        if t.total % BLOCK_SIZE != 0:
            raise ValueError(f"Mục xuất #{idx} ({t.output}): số video ({t.total}) phải là bội của {BLOCK_SIZE}.")

    total_videos = sum(t.total for t in targets)
    total_blocks = total_videos // BLOCK_SIZE
    total_capacity_blocks = sum(f.available_blocks for f in folders)
    if total_blocks > total_capacity_blocks:
        max_take = total_capacity_blocks * BLOCK_SIZE
        raise ValueError(
            f"Tổng số video các mục xuất là {total_videos}, vượt quá khả năng nguồn. "
            f"Tối đa có thể lấy hiện tại (theo bội {BLOCK_SIZE}): {max_take} video."
        )

    for f in folders:
        f.per_target_blocks = [0] * len(targets)

    # Phân bổ tuần tự từng mục xuất; bên trong mỗi mục xuất chia cân bằng giữa các thư mục con
    # còn dư block (ưu tiên thư mục đang lấy ít nhất trong mục xuất đó, rồi còn dư nhiều nhất).
    for ti, t in enumerate(targets):
        need_blocks = t.total // BLOCK_SIZE
        for _ in range(need_blocks):
            candidates = [f for f in folders if f.allocated_blocks < f.available_blocks]
            if not candidates:
                raise ValueError("Không còn thư mục nào đủ video để phân bổ tiếp.")
            min_cur = min(f.per_target_blocks[ti] for f in candidates)
            lowest = [f for f in candidates if f.per_target_blocks[ti] == min_cur]
            lowest.sort(key=lambda f: (-(f.available_blocks - f.allocated_blocks), f.name.lower()))
            lowest[0].per_target_blocks[ti] += 1


def unique_destination_path(dest_folder: Path, source_path: Path) -> Path:
    dest = dest_folder / source_path.name
    if not dest.exists():
        return dest
    n = 2
    while True:
        candidate = dest_folder / f"{source_path.stem}__{n}{source_path.suffix}"
        if not candidate.exists():
            return candidate
        n += 1


def move_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))


class VideoPicker(Feature):
    title = "Bốc video"
    order = 25

    def __init__(self):
        super().__init__()
        self.folders: List[FolderInfo] = []
        self.targets: List[TargetSpec] = []
        self.stop_requested = False
        self.prog = {"pct": 0, "text": ""}

    def act_pick_folder(self, data):
        return {"path": dialogs.pick_folder()}

    def _validate(self, data):
        source_raw = (data.get("source") or "").strip()
        if not source_raw:
            raise ValueError("Bạn chưa chọn thư mục gốc chứa video.")
        source_root = Path(source_raw)
        if not source_root.is_dir():
            raise ValueError("Thư mục gốc chứa video không tồn tại.")

        raw_targets = data.get("targets")
        if not raw_targets:
            # Tương thích giao diện 1 mục cũ nếu có
            out_single = (data.get("output") or "").strip()
            tot_single = data.get("total", "")
            raw_targets = [{"output": out_single, "total": tot_single}] if out_single else []

        specs: List[TargetSpec] = []
        seen = set()
        for idx, item in enumerate(raw_targets, 1):
            out_raw = (item.get("output") or "").strip()
            tot_raw = str(item.get("total", "")).strip().replace(",", "")
            if not out_raw:
                raise ValueError(f"Mục xuất #{idx}: chưa chọn thư mục xuất.")
            if not tot_raw.isdigit():
                raise ValueError(f"Mục xuất #{idx}: số video phải là số nguyên (bội của 30).")
            out_path = Path(out_raw)
            if is_child_or_same(out_path, source_root) or is_child_or_same(source_root, out_path):
                raise ValueError(f"Mục xuất #{idx} ({out_path}): không được nằm trong hoặc chứa thư mục nguồn.")
            norm = normalize_for_compare(out_path)
            if norm in seen:
                raise ValueError(f"Mục xuất #{idx} ({out_path}) bị trùng với một mục xuất khác.")
            seen.add(norm)
            specs.append(TargetSpec(output=out_path, total=int(tot_raw)))

        if not specs:
            raise ValueError("Bạn chưa thêm mục xuất nào.")
        return source_root, specs

    def _rows(self):
        return [{
            "name": f.name,
            "available": f.available_count,
            "available_blocks": f.available_blocks,
            "take": f.allocated_count,
            "take_blocks": f.allocated_blocks,
            "per_target": [b * BLOCK_SIZE for b in f.per_target_blocks],
        } for f in self.folders]

    def act_scan(self, data):
        if self.running:
            return {"error": "Đang chạy"}
        try:
            source_root, specs = self._validate(data)
        except Exception as e:
            return {"error": str(e)}
        self.clear_log()
        self.stop_requested = False
        self.prog = {"pct": 0, "text": "Đang quét thư mục nguồn..."}
        self.last_scan_error = None
        self.run_bg(self.scan_work, source_root, specs)
        return {"ok": 1}

    def scan_work(self, source_root: Path, specs: List[TargetSpec]):
        try:
            self.log(f"Đang quét nguồn: {source_root} ...")

            def on_prog(done, total_f, fname, count):
                self.prog = {
                    "pct": done / max(1, total_f) * 100,
                    "text": f"Đang quét {done}/{total_f}: {fname} ({count} video)",
                }
                self.log(f"  [{done}/{total_f}] {fname}: {count} video ({count // BLOCK_SIZE} block 30)")

            self.folders = scan_source(source_root, progress_cb=on_prog)
            if not self.folders:
                raise ValueError("Không tìm thấy thư mục con nào trong thư mục nguồn.")
            allocate_multi_targets(self.folders, specs)
            self.targets = specs
            ta = sum(f.available_count for f in self.folders)
            tt = sum(f.allocated_count for f in self.folders)
            self.log(f"Tìm thấy {len(self.folders)} thư mục con, tổng video có sẵn: {ta}.")
            for i, s in enumerate(specs, 1):
                self.log(f"  • Mục xuất #{i}: {s.output} — {s.total} video")
            self.log(f"Tổng sẽ DI CHUYỂN: {tt} video (mỗi thư mục con theo bội của {BLOCK_SIZE}).")
            self.prog = {"pct": 100, "text": f"Quét xong: {ta} video có sẵn, sẽ lấy {tt}"}
        except Exception as e:
            self.folders = []
            self.targets = []
            self.last_scan_error = str(e)
            self.log(f"LỖI: {e}")
            self.prog = {"pct": 0, "text": f"Lỗi: {e}"}

    def act_scan_result(self, data):
        return {
            "running": self.running,
            "error": getattr(self, "last_scan_error", None),
            "rows": self._rows(),
            "targets": [str(s.output) for s in self.targets],
            "total_take": sum(f.allocated_count for f in self.folders),
        }

    def act_stop(self, data):
        self.stop_requested = True
        self.log("Đã yêu cầu dừng. Tool sẽ dừng sau khi xử lý xong file hiện tại.")
        return {}

    def act_progress(self, data):
        return dict(self.prog, running=self.running)

    def act_start(self, data):
        if self.running:
            return {"error": "Đang chạy"}
        try:
            source_root, specs = self._validate(data)
            for s in specs:
                s.output.mkdir(parents=True, exist_ok=True)
            if not self.folders:
                self.folders = scan_source(source_root)
            allocate_multi_targets(self.folders, specs)
            self.targets = specs
        except Exception as e:
            return {"error": str(e)}
        self.stop_requested = False
        self.prog = {"pct": 0, "text": "Đang bắt đầu..."}
        try:
            threads = max(1, min(16, int(data.get("threads") or 4)))
        except Exception:
            threads = 4
        self.run_bg(self.work, specs, threads)
        return {"ok": 1, "rows": self._rows(), "targets": [str(s.output) for s in specs]}

    def work(self, specs: List[TargetSpec], threads: int = 4):
        rng = random.Random()
        lock = threading.Lock()
        total_to_move = sum(f.allocated_count for f in self.folders)
        moved_global = 0
        self.log(f"Bắt đầu DI CHUYỂN tổng {total_to_move} video vào {len(specs)} mục xuất (luồng: {threads})...")

        # Chọn ngẫu nhiên không trùng từ mỗi thư mục con rồi chia lát cho từng mục xuất
        per_target_selections: List[dict[str, List[Path]]] = [dict() for _ in specs]
        for folder in self.folders:
            total_take = folder.allocated_count
            if total_take <= 0:
                continue
            picked = rng.sample(folder.videos, total_take)
            pos = 0
            for ti, blocks in enumerate(folder.per_target_blocks):
                cnt = blocks * BLOCK_SIZE
                if cnt > 0:
                    per_target_selections[ti][folder.name] = picked[pos:pos + cnt]
                    pos += cnt

        for ti, spec in enumerate(specs):
            if self.stop_requested:
                break
            output_root = spec.output
            output_root.mkdir(parents=True, exist_ok=True)
            self.log(f"\n=== Mục xuất #{ti + 1}/{len(specs)}: {output_root} ({spec.total} video) ===")

            for folder in self.folders:
                (output_root / folder.name).mkdir(parents=True, exist_ok=True)

            log_rows = []
            counts: dict[str, int] = {}
            moved_this = 0

            for folder in self.folders:
                if self.stop_requested:
                    break
                selected = per_target_selections[ti].get(folder.name, [])
                if not selected:
                    continue
                self.log(f"  {folder.name}: di chuyển {len(selected)} video -> {output_root.name}")
                dest = output_root / folder.name
                jobs, reserved = [], set()
                for src in selected:
                    dst = unique_destination_path(dest, src)
                    n = 2
                    while str(dst).lower() in reserved:
                        dst = dest / f"{src.stem}__{n}{src.suffix}"
                        n += 1
                    reserved.add(str(dst).lower())
                    jobs.append((src, dst))

                def run_job(job, folder=folder, dest=dest):
                    nonlocal moved_global, moved_this
                    if self.stop_requested:
                        return
                    src, dst = job
                    move_file(src, dst)
                    with lock:
                        moved_global += 1
                        moved_this += 1
                        counts[str(dest)] = counts.get(str(dest), 0) + 1
                        log_rows.append([folder.name, str(src), str(dst), "MOVE"])
                        self.prog = {
                            "pct": moved_global / max(1, total_to_move) * 100,
                            "text": f"Mục #{ti + 1}: {moved_global}/{total_to_move}",
                        }

                with ThreadPoolExecutor(max_workers=threads) as ex:
                    list(ex.map(run_job, jobs))

            # Ghi nối vào selected_videos_log.csv để nếu xuất nhiều lần vào cùng thư mục vẫn khôi phục được hết
            log_path = output_root / LOG_NAME
            write_header = not log_path.exists()
            with log_path.open("a", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                if write_header:
                    w.writerow(["folder", "source", "destination", "action"])
                w.writerows(log_rows)

            txt = output_root / "thu_muc_co_video.txt"
            with txt.open("w", encoding="utf-8-sig") as f:
                for p, c in sorted(counts.items(), key=lambda x: x[0].lower()):
                    if c > 0:
                        f.write(p + "\n")
            self.log(f"  -> Đã di chuyển {moved_this} video, xuất TXT: {txt}")

        if self.stop_requested:
            self.log(f"\nĐÃ DỪNG. Đã di chuyển {moved_global}/{total_to_move} video.")
        else:
            self.log(f"\nHOÀN TẤT. Đã di chuyển {moved_global}/{total_to_move} video vào {len(specs)} thư mục xuất.")
        self.prog = {"pct": self.prog["pct"], "text": "Đã dừng" if self.stop_requested else "Hoàn tất"}
        self.folders = []

    # ---- KHÔI PHỤC VỀ THƯ MỤC GỐC ----
    def act_restore(self, data):
        if self.running:
            return {"error": "Đang chạy"}
        raw_outs = data.get("outputs") or []
        outs = []
        seen = set()
        for r in raw_outs:
            s = (r or "").strip()
            if not s:
                continue
            p = Path(s)
            norm = normalize_for_compare(p)
            if norm not in seen and p.is_dir():
                seen.add(norm)
                outs.append(p)
        if not outs:
            return {"error": "Chưa có thư mục xuất hợp lệ nào để khôi phục."}

        source_raw = (data.get("source") or "").strip()
        fallback_root = Path(source_raw) if source_raw else None
        try:
            threads = max(1, min(16, int(data.get("threads") or 4)))
        except Exception:
            threads = 4

        self.clear_log()
        self.stop_requested = False
        self.prog = {"pct": 0, "text": "Đang chuẩn bị khôi phục..."}
        self.run_bg(self.restore_work, outs, fallback_root, threads)
        return {"ok": 1}

    def restore_work(self, outs: List[Path], fallback_root: Path | None, threads: int = 4):
        lock = threading.Lock()
        all_jobs: List[tuple[Path, Path, Path]] = []  # (out_root, current_dst_file, restore_src_target)

        for out_root in outs:
            log_path = out_root / LOG_NAME
            logged_dsts = set()
            if log_path.is_file():
                try:
                    with log_path.open("r", newline="", encoding="utf-8-sig") as f:
                        reader = csv.DictReader(f)
                        for row in reader:
                            src_s = (row.get("source") or "").strip()
                            dst_s = (row.get("destination") or "").strip()
                            if not src_s or not dst_s:
                                continue
                            dst_p = Path(dst_s)
                            src_p = Path(src_s)
                            if dst_p.is_file():
                                all_jobs.append((out_root, dst_p, src_p))
                                logged_dsts.add(normalize_for_compare(dst_p))
                except Exception as e:
                    self.log(f"[CẢNH BÁO] Không đọc được {log_path}: {e}")

            # Nếu còn video trong các thư mục con của out_root mà không nằm trong log (hoặc mất log),
            # khôi phục về <Thư mục gốc>/<Tên thư mục con>/<Tên file> nếu biết thư mục gốc.
            if fallback_root and fallback_root.is_dir():
                for sub in find_category_folders(out_root):
                    for vf in scan_videos_in_folder(sub):
                        if normalize_for_compare(vf) not in logged_dsts:
                            clean_name = vf.stem.split("__")[0] + vf.suffix
                            all_jobs.append((out_root, vf, fallback_root / sub.name / clean_name))

        total = len(all_jobs)
        if total == 0:
            self.log("Không tìm thấy video nào cần khôi phục trong các thư mục xuất đã chọn.")
            self.prog = {"pct": 100, "text": "Không có file"}
            return

        self.log(f"Bắt đầu KHÔI PHỤC {total} video từ {len(outs)} thư mục xuất về thư mục gốc...")
        restored = 0
        failed = 0

        # Tránh đè nếu vị trí gốc đã có file trùng tên
        prepared: List[tuple[Path, Path, Path]] = []
        reserved = set()
        for out_root, cur_file, target_orig in all_jobs:
            dst = target_orig
            if dst.exists() or str(dst).lower() in reserved:
                dst = unique_destination_path(target_orig.parent, target_orig)
                n = 2
                while str(dst).lower() in reserved:
                    dst = target_orig.parent / f"{target_orig.stem}__{n}{target_orig.suffix}"
                    n += 1
            reserved.add(str(dst).lower())
            prepared.append((out_root, cur_file, dst))

        def run_restore(item):
            nonlocal restored, failed
            if self.stop_requested:
                return
            _, cur_file, dst = item
            try:
                move_file(cur_file, dst)
                with lock:
                    restored += 1
                    self.prog = {"pct": (restored + failed) / total * 100, "text": f"Khôi phục {restored}/{total}"}
            except Exception as e:
                with lock:
                    failed += 1
                self.log(f"[LỖI] {cur_file.name}: {e}")

        with ThreadPoolExecutor(max_workers=threads) as ex:
            list(ex.map(run_restore, prepared))

        # Dọn log, file TXT và các thư mục con rỗng sau khi khôi phục xong
        if not self.stop_requested and failed == 0:
            for out_root in outs:
                for aux in (out_root / LOG_NAME, out_root / "thu_muc_co_video.txt"):
                    try:
                        if aux.is_file():
                            aux.unlink()
                    except OSError:
                        pass
                for sub in find_category_folders(out_root):
                    try:
                        if not any(sub.iterdir()):
                            sub.rmdir()
                    except OSError:
                        pass

        self.log(f"HOÀN TẤT KHÔI PHỤC: {restored}/{total} video đã trả về thư mục gốc" + (f" ({failed} lỗi)." if failed else "."))
        self.prog = {"pct": 100 if not self.stop_requested else self.prog["pct"],
                     "text": "Đã dừng" if self.stop_requested else f"Đã khôi phục {restored} video"}
        self.folders = []

    def act_open_folder(self, data):
        p = data.get("path")
        if p and Path(p).exists():
            os.startfile(p)
        return {}
