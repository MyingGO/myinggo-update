"""Tính năng: Bốc video ngẫu nhiên theo thư mục con (tối thiểu 25 video/thư mục, ưu tiên cụm 30) từ NHIỀU thư mục gốc (nhiều ổ cứng)
sang NHIỀU thư mục xuất cùng lúc, tự động bỏ qua thư mục < 25 video, không chia lẻ ≤ 10 video/thư mục,
tự động đổi sang video/thư mục khác khi gặp file lỗi ([WinError 5], file đang bận),
xuất TXT và hỗ trợ KHÔI PHỤC (trả video đã bốc về đúng ổ cứng & thư mục gốc ban đầu)."""
from __future__ import annotations

import csv
import os
import random
import shutil
import stat
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from core import dialogs
from core.base import Feature

VIDEO_EXTENSIONS = {
    ".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".wmv", ".flv",
    ".mpeg", ".mpg", ".ts", ".m2ts", ".3gp", ".mts", ".vob"
}
BLOCK_SIZE = 30
MIN_PER_FOLDER_DEFAULT = 25
LOG_NAME = "selected_videos_log.csv"


@dataclass
class FolderInfo:
    name: str
    path: Path
    root_path: Path
    root_index: int
    videos: List[Path]
    available_blocks: int
    display_name: str = ""
    dest_name: str = ""
    per_target_blocks: List[int] = field(default_factory=list)
    per_target_counts: List[int] = field(default_factory=list)
    remaining_pool: List[Path] = field(default_factory=list)
    broken: bool = False
    min_per_folder: int = MIN_PER_FOLDER_DEFAULT

    @property
    def key(self) -> str:
        return normalize_for_compare(self.path)

    @property
    def available_count(self) -> int:
        return len(self.videos)

    @property
    def eligible(self) -> bool:
        return len(self.videos) >= self.min_per_folder

    @property
    def allocated_blocks(self) -> int:
        if self.per_target_counts:
            return sum(1 if c > 0 else 0 for c in self.per_target_counts)
        return sum(self.per_target_blocks)

    @property
    def allocated_count(self) -> int:
        if self.per_target_counts:
            return sum(self.per_target_counts)
        return self.allocated_blocks * BLOCK_SIZE


@dataclass
class TargetSpec:
    output: Path
    total: int


def is_video_file(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS


def normalize_for_compare(path: Path) -> str:
    try:
        return str(path.resolve()).casefold()
    except Exception:
        return str(path.absolute()).casefold()


def is_child_or_same(child: Path, parent: Path) -> bool:
    child_s = normalize_for_compare(child).rstrip("\\/")
    parent_s = normalize_for_compare(parent).rstrip("\\/")
    return child_s == parent_s or child_s.startswith(parent_s + os.sep)


def find_category_folders(source_root: Path) -> List[Path]:
    try:
        return [p for p in sorted(source_root.iterdir(), key=lambda x: x.name.lower()) if p.is_dir()]
    except OSError:
        return []


def scan_videos_in_folder(folder: Path) -> List[Path]:
    skip = {"$recycle.bin", "system volume information"}
    videos: List[Path] = []
    stack = [str(folder)]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            if e.name.lower() not in skip:
                                stack.append(e.path)
                        elif os.path.splitext(e.name)[1].lower() in VIDEO_EXTENSIONS and e.is_file():
                            videos.append(Path(e.path))
                    except OSError:
                        continue
        except OSError:
            continue
    videos.sort(key=lambda p: str(p).lower())
    return videos


def _calc_available_blocks(video_count: int, min_per_folder: int = MIN_PER_FOLDER_DEFAULT) -> int:
    if video_count < min_per_folder:
        return 0
    return max(1, video_count // BLOCK_SIZE)


def scan_sources(
    source_roots: List[Path],
    progress_cb=None,
    min_per_folder: int = MIN_PER_FOLDER_DEFAULT,
) -> List[FolderInfo]:
    """Quét danh sách các thư mục con từ NHIỀU thư mục gốc (nhiều ổ cứng khác nhau)."""
    tasks: List[tuple[int, Path, Path]] = []
    seen_folders = set()
    for r_idx, root in enumerate(source_roots, 1):
        for sub in find_category_folders(root):
            norm = normalize_for_compare(sub)
            if norm not in seen_folders:
                seen_folders.add(norm)
                tasks.append((r_idx, root, sub))

    if not tasks:
        return []

    multi_roots = len(source_roots) > 1
    total_f = len(tasks)
    results: List[FolderInfo] = []
    done = 0

    with ThreadPoolExecutor(max_workers=min(4, total_f)) as ex:
        fut_map = {ex.submit(scan_videos_in_folder, sub): (r_idx, root, sub) for r_idx, root, sub in tasks}
        for fut in as_completed(fut_map):
            r_idx, root, sub = fut_map[fut]
            try:
                v = fut.result()
            except Exception:
                v = []
            done += 1
            disp = f"[Nguồn #{r_idx} • {root.drive or root.name}] {sub.name}" if multi_roots else sub.name
            if progress_cb:
                progress_cb(done, total_f, disp, len(v))
            results.append(
                FolderInfo(
                    name=sub.name,
                    path=sub,
                    root_path=root,
                    root_index=r_idx,
                    videos=v,
                    available_blocks=_calc_available_blocks(len(v), min_per_folder),
                    display_name=disp,
                    dest_name=sub.name,
                    min_per_folder=min_per_folder,
                )
            )

    # Nếu có nhiều thư mục gốc có thư mục con trùng tên (VD: D:\Nguon1\001 và E:\Nguon2\001),
    # đặt tên thư mục con ở nơi xuất phân biệt nhẹ hoặc giữ nguyên tên (file trùng tên đã tự thêm __2)
    name_counts: dict[str, int] = {}
    for f in results:
        k = f.name.lower()
        name_counts[k] = name_counts.get(k, 0) + 1
    if multi_roots:
        for f in results:
            if name_counts.get(f.name.lower(), 0) > 1:
                drv = (f.root_path.drive or f"N{f.root_index}").replace(":", "")
                f.dest_name = f"{f.name}_{drv}"

    results.sort(key=lambda x: (x.root_index, x.name.lower()))
    return results


def allocate_multi_targets(
    folders: List[FolderInfo],
    targets: List[TargetSpec],
    min_per_folder: int = MIN_PER_FOLDER_DEFAULT,
) -> None:
    """Phân bổ số video cho từng mục xuất với điều kiện:
    - Bỏ qua mọi thư mục con có dưới `min_per_folder` (mặc định 25) video.
    - Nếu khi chia đều tổng số video cho các thư mục mà mức trung bình bị rơi xuống thấp (≤ 10 hoặc < 25 video),
      tự động giới hạn số thư mục được bốc để MỖI thư mục đã được chọn phải lấy tối thiểu `min_per_folder` (25) video.
    - Cho phép bốc cả các thư mục có từ 25–29 video (không bắt buộc phải tròn 30 mới được bốc).
    - Ưu tiên phân bổ theo cụm 30 video khi thư mục đủ rộng, và tự cân bằng phần lẻ vào các thư mục đã chọn (≥ 25 video).
    """
    if not targets:
        raise ValueError("Chưa có mục xuất nào.")
    min_pf = max(1, int(min_per_folder or MIN_PER_FOLDER_DEFAULT))

    for idx, t in enumerate(targets, 1):
        if t.total <= 0:
            raise ValueError(f"Mục xuất #{idx} ({t.output}): số video cần lấy phải lớn hơn 0.")
        if t.total < min_pf:
            raise ValueError(
                f"Mục xuất #{idx} ({t.output}): số video cần lấy ({t.total}) phải tối thiểu bằng mức tối thiểu mỗi thư mục ({min_pf} video)."
            )

    for f in folders:
        f.min_per_folder = min_pf
        f.available_blocks = _calc_available_blocks(len(f.videos), min_pf)
        f.per_target_counts = [0] * len(targets)
        f.per_target_blocks = [0] * len(targets)

    rem_map: dict[int, int] = {id(f): len(f.videos) for f in folders}
    eligible_total = sum(len(f.videos) for f in folders if len(f.videos) >= min_pf)
    total_videos_req = sum(t.total for t in targets)
    if total_videos_req > eligible_total:
        skipped_small = sum(1 for f in folders if len(f.videos) < min_pf)
        raise ValueError(
            f"Tổng số video các mục xuất cần lấy là {total_videos_req}, vượt quá tổng video khả dụng ({eligible_total} video) "
            f"từ các thư mục đạt tối thiểu {min_pf} video/thư mục"
            + (f" (đã bỏ qua {skipped_small} thư mục có dưới {min_pf} video)." if skipped_small else ".")
        )

    num_targets = len(targets)
    for ti, t in enumerate(targets):
        need = t.total
        has_future_targets = (ti + 1) < num_targets

        # Chỉ xét các thư mục còn ít nhất `min_pf` (25) video chưa phân bổ
        cands = [f for f in folders if rem_map[id(f)] >= min_pf]
        cap_now = sum(rem_map[id(f)] for f in cands)
        if cap_now < need:
            raise ValueError(
                f"Mục xuất #{ti + 1} ({t.output}) cần {need} video nhưng các thư mục đủ điều kiện (≥ {min_pf} video) "
                f"chỉ còn tổng cộng {cap_now} video khả dụng."
            )

        # Sắp xếp ưu tiên: thư mục chưa được lấy ở các mục xuất trước -> còn nhiều video khả dụng nhất -> thứ tự gốc
        cands.sort(
            key=lambda f: (
                sum(1 for c in f.per_target_counts[:ti] if c > 0),
                sum(f.per_target_counts[:ti]),
                -rem_map[id(f)],
                f.root_index,
                f.name.lower(),
            )
        )

        # Số thư mục tối đa được phép bốc để không thư mục nào bị dưới `min_pf` (25) video
        max_k = min(len(cands), need // min_pf)
        if max_k <= 0:
            raise ValueError(f"Mục xuất #{ti + 1}: không thể phân bổ tối thiểu {min_pf} video/thư mục.")

        # Ưu tiên số lượng thư mục theo cụm chuẩn 30 (hoặc mở rộng tới max_k nếu có thư mục 25-29 video)
        pref_step = max(min_pf, BLOCK_SIZE)
        k = min(max_k, max(1, need // pref_step))
        while k < max_k and sum(rem_map[id(cands[i])] for i in range(k)) < need:
            k += 1

        # Nếu k thư mục đầu tiên theo thứ tự xoay vòng chưa đủ tổng dung lượng (do ưu tiên xoay vòng trước dung lượng),
        # chọn lại hoặc mở rộng thêm các thư mục có dung lượng lớn nhất trong `cands`
        selected = list(cands[:k])
        if sum(rem_map[id(f)] for f in selected) < need:
            # Sắp xếp lại thuần theo dung lượng giảm dần để đảm bảo lấy đủ `need`
            by_cap = sorted(cands, key=lambda f: (-rem_map[id(f)], f.root_index, f.name.lower()))
            k_cap = k
            while k_cap < max_k and sum(rem_map[id(by_cap[i])] for i in range(k_cap)) < need:
                k_cap += 1
            selected = list(by_cap[:k_cap])
            if sum(rem_map[id(f)] for f in selected) < need:
                raise ValueError(
                    f"Mục xuất #{ti + 1} ({t.output}): không đủ tổ hợp thư mục (mỗi thư mục ≥ {min_pf} video) để gom đủ {need} video."
                )

        # Bước 1: Cấp nền tối thiểu `min_pf` (25) video cho toàn bộ thư mục đã chọn
        # -> Đảm bảo 100% không có bất kỳ thư mục được chọn nào bị ≤ 10 hay < 25 video!
        alloc: dict[int, int] = {id(f): min_pf for f in selected}
        rem_need = need - (len(selected) * min_pf)

        def _usable_extra(f: FolderInfo, phase: int) -> int:
            """Tính số video có thể lấy thêm từ thư mục `f` (ngoài mức nền `min_pf` đã cấp):
            - phase 0 (khi còn mục xuất phía sau): chỉ lấy hết phần dư của các thư mục 1-lần (`avail < 2 * min_pf`),
              vì phần dư < 25 đằng nào cũng không đủ dùng cho mục xuất sau; chưa lấy thêm từ thư mục lớn (`avail >= 2 * min_pf`).
            - phase 1 (khi còn mục xuất phía sau): cho phép lấy thêm từ thư mục lớn nhưng giữ lại ít nhất `pref_step` (30) video cho mục sau.
            - phase 2 (khi còn mục xuất phía sau): giữ lại ít nhất `min_pf` (25) video ở các thư mục lớn.
            - phase 3: lấy tối đa toàn bộ số video còn lại (`avail - cur`).
            """
            cur = alloc[id(f)]
            avail = rem_map[id(f)]
            max_add = avail - cur
            if max_add <= 0:
                return 0
            if not has_future_targets or phase >= 3:
                return max_add
            if avail < 2 * min_pf:
                return max_add
            if phase == 0:
                return 0
            reserve = pref_step if phase == 1 else min_pf
            return max(0, (avail - reserve) - cur)

        # Bước 2 & 3: Theo từng phase (ưu tiên tận dụng hết thư mục 1-lần ở phase 0 trước để bảo toàn thư mục lớn cho các mục xuất sau),
        # nâng từ `min_pf` (25) lên `pref_step` (30) rồi chia tiếp phần còn thiếu
        for phase in (0, 1, 2, 3):
            if rem_need <= 0:
                break
            for f in selected:
                if rem_need <= 0:
                    break
                want_to_30 = max(0, pref_step - alloc[id(f)])
                if want_to_30 <= 0:
                    continue
                can_add = min(want_to_30, _usable_extra(f, phase), rem_need)
                if can_add > 0:
                    alloc[id(f)] += can_add
                    rem_need -= can_add

            while rem_need > 0:
                growable = [f for f in selected if _usable_extra(f, phase) > 0]
                if not growable:
                    break
                growable.sort(
                    key=lambda f: (
                        0 if (has_future_targets and rem_map[id(f)] < 2 * min_pf) else 1,
                        alloc[id(f)],
                        -_usable_extra(f, phase),
                        f.root_index,
                        f.name.lower(),
                    )
                )
                chosen = growable[0]
                extra_cap = _usable_extra(chosen, phase)
                step = min(pref_step, extra_cap, rem_need) if rem_need >= pref_step else min(extra_cap, rem_need)
                if step <= 0:
                    break
                alloc[id(chosen)] += step
                rem_need -= step

        if rem_need > 0:
            raise ValueError(
                f"Mục xuất #{ti + 1} ({t.output}): còn thiếu {rem_need} video không thể phân bổ (điều kiện ≥ {min_pf} video/thư mục)."
            )

        # Ghi nhận kết quả phân bổ cho mục xuất `ti`
        for f in selected:
            cnt = alloc[id(f)]
            f.per_target_counts[ti] = cnt
            f.per_target_blocks[ti] = max(1, round(cnt / BLOCK_SIZE)) if cnt > 0 else 0
            rem_map[id(f)] -= cnt


def unique_destination_path(dest_folder: Path, source_path: Path, reserved: set | None = None) -> Path:
    dest = dest_folder / source_path.name
    if not dest.exists() and (reserved is None or str(dest).lower() not in reserved):
        return dest
    n = 2
    while True:
        candidate = dest_folder / f"{source_path.stem}__{n}{source_path.suffix}"
        if not candidate.exists() and (reserved is None or str(candidate).lower() not in reserved):
            return candidate
        n += 1


def _clear_readonly(p: Path) -> None:
    try:
        os.chmod(str(p), stat.S_IWRITE | stat.S_IREAD)
    except Exception:
        pass


def move_file(src: Path, dst: Path) -> None:
    """Di chuyển file an toàn; nếu gặp lỗi Read-Only ([WinError 5]) thì tự gỡ Read-Only và thử lại.
    Nếu copy khác ổ đĩa mà không xóa được file nguồn đang bị khóa thì tự dọn bản nháp ở đích."""
    if not src.is_file():
        raise FileNotFoundError(f"Không tìm thấy file: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.move(str(src), str(dst))
    except PermissionError:
        _clear_readonly(src)
        _clear_readonly(dst.parent)
        try:
            shutil.move(str(src), str(dst))
        except Exception:
            if src.exists() and dst.exists():
                try:
                    _clear_readonly(dst)
                    dst.unlink()
                except Exception:
                    pass
            raise
    except Exception:
        if src.exists() and dst.exists():
            try:
                dst.unlink()
            except Exception:
                pass
        raise


class VideoPicker(Feature):
    title = "Bốc video"
    order = 25

    def __init__(self):
        super().__init__()
        self.folders: List[FolderInfo] = []
        self.targets: List[TargetSpec] = []
        self.source_roots: List[Path] = []
        self.min_per_folder: int = MIN_PER_FOLDER_DEFAULT
        self.stop_requested = False
        self.prog = {"pct": 0, "text": ""}

    def act_pick_folder(self, data):
        return {"path": dialogs.pick_folder()}

    def _parse_sources(self, data) -> List[Path]:
        raw_sources = data.get("sources")
        if not raw_sources:
            single = (data.get("source") or "").strip()
            raw_sources = [single] if single else []

        roots: List[Path] = []
        seen = set()
        for idx, item in enumerate(raw_sources, 1):
            s = (item.get("path") if isinstance(item, dict) else str(item or "")).strip()
            if not s:
                continue
            p = Path(s)
            if not p.is_dir():
                raise ValueError(f"Thư mục gốc #{idx} không tồn tại: {p}")
            norm = normalize_for_compare(p)
            if norm not in seen:
                seen.add(norm)
                roots.append(p)
        if not roots:
            raise ValueError("Bạn chưa chọn thư mục gốc nào chứa video.")
        return roots

    def _parse_min_per_folder(self, data) -> int:
        raw = str(data.get("min_per_folder", MIN_PER_FOLDER_DEFAULT) or MIN_PER_FOLDER_DEFAULT).strip()
        try:
            val = int(raw)
        except Exception:
            val = MIN_PER_FOLDER_DEFAULT
        return max(1, min(1000, val))

    def _validate(self, data) -> tuple[List[Path], List[TargetSpec], int]:
        source_roots = self._parse_sources(data)
        min_pf = self._parse_min_per_folder(data)

        raw_targets = data.get("targets")
        if not raw_targets:
            out_single = (data.get("output") or "").strip()
            tot_single = data.get("total", "")
            raw_targets = [{"output": out_single, "total": tot_single}] if out_single else []

        specs: List[TargetSpec] = []
        seen = set()
        for idx, item in enumerate(raw_targets, 1):
            out_raw = (item.get("output") or "").strip()
            tot_raw = str(item.get("total", "")).strip().replace(",", "")
            if not out_raw:
                raise ValueError(f"Mục xuất #{idx}: chưa chọn thư mục xuất.")
            if not tot_raw.isdigit():
                raise ValueError(f"Mục xuất #{idx}: số video phải là số nguyên dương (tối thiểu {min_pf}).")
            tot_val = int(tot_raw)
            if tot_val < min_pf:
                raise ValueError(f"Mục xuất #{idx}: số video ({tot_val}) phải tối thiểu bằng {min_pf} video.")
            out_path = Path(out_raw)
            for sroot in source_roots:
                if is_child_or_same(out_path, sroot) or is_child_or_same(sroot, out_path):
                    raise ValueError(f"Mục xuất #{idx} ({out_path}): không được nằm trong hoặc chứa thư mục gốc ({sroot}).")
            norm = normalize_for_compare(out_path)
            if norm in seen:
                raise ValueError(f"Mục xuất #{idx} ({out_path}) bị trùng với một mục xuất khác.")
            seen.add(norm)
            specs.append(TargetSpec(output=out_path, total=tot_val))

        if not specs:
            raise ValueError("Bạn chưa thêm mục xuất nào.")
        return source_roots, specs, min_pf

    def _rows(self):
        return [{
            "name": f.display_name or f.name,
            "available": f.available_count,
            "available_blocks": f.available_blocks,
            "eligible": f.eligible,
            "min_per_folder": f.min_per_folder,
            "take": f.allocated_count,
            "take_blocks": f.allocated_blocks,
            "per_target": list(f.per_target_counts) if f.per_target_counts else [b * BLOCK_SIZE for b in f.per_target_blocks],
        } for f in self.folders]

    def act_scan(self, data):
        if self.running:
            return {"error": "Đang chạy"}
        try:
            source_roots, specs, min_pf = self._validate(data)
        except Exception as e:
            return {"error": str(e)}
        self.clear_log()
        self.stop_requested = False
        self.prog = {"pct": 0, "text": "Đang quét các thư mục gốc..."}
        self.last_scan_error = None
        self.run_bg(self.scan_work, source_roots, specs, min_pf)
        return {"ok": 1}

    def scan_work(self, source_roots: List[Path], specs: List[TargetSpec], min_pf: int = MIN_PER_FOLDER_DEFAULT):
        try:
            self.source_roots = source_roots
            self.min_per_folder = min_pf
            self.log(f"Đang quét {len(source_roots)} thư mục gốc (điều kiện bốc tối thiểu: ≥ {min_pf} video/thư mục):")
            for i, r in enumerate(source_roots, 1):
                self.log(f"  • Nguồn #{i}: {r}")

            def on_prog(done, total_f, fname, count):
                self.prog = {
                    "pct": done / max(1, total_f) * 100,
                    "text": f"Đang quét {done}/{total_f}: {fname} ({count} video)",
                }
                status_tag = f"đủ ĐK (≥{min_pf})" if count >= min_pf else f"bỏ qua (<{min_pf} video)"
                self.log(f"  [{done}/{total_f}] {fname}: {count} video — {status_tag}")

            self.folders = scan_sources(source_roots, progress_cb=on_prog, min_per_folder=min_pf)
            if not self.folders:
                raise ValueError("Không tìm thấy thư mục con nào trong các thư mục gốc đã chọn.")
            allocate_multi_targets(self.folders, specs, min_per_folder=min_pf)
            self.targets = specs
            ta = sum(f.available_count for f in self.folders)
            tt = sum(f.allocated_count for f in self.folders)
            eligible_cnt = sum(1 for f in self.folders if f.eligible)
            skipped_cnt = len(self.folders) - eligible_cnt
            picked_cnt = sum(1 for f in self.folders if f.allocated_count > 0)
            self.log(
                f"\nTìm thấy {len(self.folders)} thư mục con trên {len(source_roots)} nguồn (tổng {ta} video): "
                f"{eligible_cnt} thư mục đủ ≥{min_pf} video, bỏ qua {skipped_cnt} thư mục <{min_pf} video."
            )
            for i, s in enumerate(specs, 1):
                t_folders = sum(1 for f in self.folders if (f.per_target_counts[i - 1] if i - 1 < len(f.per_target_counts) else 0) > 0)
                self.log(f"  • Mục xuất #{i}: {s.output} — {s.total} video (bốc từ {t_folders} thư mục, mỗi thư mục ≥ {min_pf} video)")
            self.log(f"Tổng sẽ DI CHUYỂN: {tt} video trên {picked_cnt} thư mục con (tối thiểu {min_pf} video/thư mục, không chia lẻ ≤ 10 video).")
            self.prog = {"pct": 100, "text": f"Quét xong: {ta} video có sẵn, sẽ lấy {tt} video ({picked_cnt} thư mục)"}
        except Exception as e:
            self.folders = []
            self.targets = []
            self.last_scan_error = str(e)
            self.log(f"[LỖI] {e}")
            self.prog = {"pct": 0, "text": f"Lỗi: {e}"}

    def act_scan_result(self, data):
        return {
            "running": self.running,
            "error": getattr(self, "last_scan_error", None),
            "rows": self._rows(),
            "targets": [str(s.output) for s in self.targets],
            "total_take": sum(f.allocated_count for f in self.folders),
            "min_per_folder": self.min_per_folder,
        }

    def act_stop(self, data):
        self.stop_requested = True
        self.log("Đã yêu cầu dừng. Tool sẽ dừng sau khi xử lý xong file hiện tại.")
        return {}

    def act_progress(self, data):
        return dict(self.prog, running=self.running)

    def act_start(self, data):
        if self.running:
            return {"error": "Đang chạy"}
        try:
            source_roots, specs, min_pf = self._validate(data)
            for s in specs:
                s.output.mkdir(parents=True, exist_ok=True)
            if not self.folders or self.source_roots != source_roots or self.min_per_folder != min_pf:
                self.folders = scan_sources(source_roots, min_per_folder=min_pf)
                self.source_roots = source_roots
                self.min_per_folder = min_pf
            allocate_multi_targets(self.folders, specs, min_per_folder=min_pf)
            self.targets = specs
        except Exception as e:
            return {"error": str(e)}
        self.stop_requested = False
        self.prog = {"pct": 0, "text": "Đang bắt đầu..."}
        try:
            threads = max(1, min(16, int(data.get("threads") or 4)))
        except Exception:
            threads = 4
        self.run_bg(self.work, specs, threads, min_pf)
        return {"ok": 1, "rows": self._rows(), "targets": [str(s.output) for s in specs]}

    def work(self, specs: List[TargetSpec], threads: int = 4, min_pf: int = MIN_PER_FOLDER_DEFAULT):
        rng = random.Random()
        lock = threading.Lock()
        total_to_move = sum(f.allocated_count for f in self.folders)
        moved_global = 0
        skipped_files_total = 0
        skipped_folders_total = 0

        self.log(
            f"Bắt đầu DI CHUYỂN tổng {total_to_move} video từ {len(self.source_roots)} nguồn "
            f"vào {len(specs)} mục xuất (luồng: {threads}, tối thiểu ≥ {min_pf} video/thư mục)..."
        )
        self.log("🛡️ Chế độ chống dừng khi gặp lỗi: Tự động đổi sang video khác hoặc lấy bù từ thư mục khác nếu gặp file [WinError 5] / đang bị khóa.")

        # Khởi tạo kho video ngẫu nhiên còn lại cho từng thư mục con
        for folder in self.folders:
            pool = list(folder.videos)
            rng.shuffle(pool)
            folder.remaining_pool = pool
            folder.broken = False

        def move_Quota_from_folder(
            folder: FolderInfo,
            need_cnt: int,
            output_root: Path,
            ti: int,
            min_required: int = min_pf,
        ) -> tuple[int, List[list], str | None]:
            """Cố gắng di chuyển đủ `need_cnt` video từ `folder.remaining_pool` sang `output_root / folder.dest_name`.
            - Nếu gặp 1 vài video lỗi / bị khóa ([WinError 5], [WinError 32]), tự động rút video khác trong `folder.remaining_pool` bù vào ngay.
            - Nếu thư mục vẫn chuyển được ≥ `min_required` (mặc định 25) video thì giữ lại toàn bộ số video sạch đó (không bắt buộc tròn 30).
            - Nếu thư mục bị khóa hoặc cạn video sạch không đủ `min_required` (25) video, tự hoàn trả số lẻ (< 25) về lại thư mục gốc để tránh có thư mục xuất bị lẻ ≤ 10 hay < 25 video."""
            nonlocal moved_global, skipped_files_total
            dest = output_root / folder.dest_name
            try:
                dest.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                folder.broken = True
                self.log(f"  ⚠️ [BỎ QUA THƯ MỤC LỖI] Không tạo được thư mục đích cho {folder.display_name}: {e}")
                return 0, [], None

            succeeded_pairs: List[tuple[Path, Path]] = []
            reserved: set[str] = set()
            consecutive_errors = 0

            while len(succeeded_pairs) < need_cnt and folder.remaining_pool and not self.stop_requested:
                still_need = need_cnt - len(succeeded_pairs)
                batch_srcs: List[Path] = []
                while len(batch_srcs) < still_need and folder.remaining_pool:
                    batch_srcs.append(folder.remaining_pool.pop())

                jobs: List[tuple[Path, Path]] = []
                for src in batch_srcs:
                    dst = unique_destination_path(dest, src, reserved)
                    reserved.add(str(dst).lower())
                    jobs.append((src, dst))

                batch_ok: List[tuple[Path, Path]] = []
                batch_err = 0

                def _try_move(job):
                    nonlocal moved_global, skipped_files_total, batch_err
                    if self.stop_requested:
                        return
                    src, dst = job
                    try:
                        move_file(src, dst)
                        with lock:
                            moved_global += 1
                            batch_ok.append((src, dst))
                            self.prog = {
                                "pct": min(100.0, moved_global / max(1, total_to_move) * 100),
                                "text": f"Mục #{ti + 1}: {moved_global}/{total_to_move}",
                            }
                    except Exception as err:
                        with lock:
                            skipped_files_total += 1
                            batch_err += 1
                        self.log(
                            f"  ⚠️ [BỎ QUA VIDEO LỖI] {folder.display_name}/{src.name}: {err} "
                            f"-> Tự động chọn video khác thay thế..."
                        )

                with ThreadPoolExecutor(max_workers=min(threads, max(1, len(jobs)))) as ex:
                    list(ex.map(_try_move, jobs))

                succeeded_pairs.extend(batch_ok)
                if len(batch_ok) == 0 and batch_err > 0:
                    consecutive_errors += batch_err
                    # Nếu thử liên tiếp >= min_pf file trong thư mục này mà đều bị Access Denied cả thư mục -> đánh dấu thư mục lỗi ngay
                    if consecutive_errors >= max(min_pf, BLOCK_SIZE):
                        folder.broken = True
                        self.log(
                            f"  ⚠️ [THƯ MỤC BỊ KHÓA] {folder.display_name} gặp {consecutive_errors} file lỗi liên tiếp -> Bỏ qua thư mục này!"
                        )
                        break
                else:
                    consecutive_errors = 0

            # Đảm bảo không bao giờ để lại thư mục xuất có dưới `min_required` (25) video (nếu chưa bấm Dừng)
            if not self.stop_requested and len(succeeded_pairs) < min_required:
                if succeeded_pairs:
                    self.log(
                        f"  ↩ Hoàn trả {len(succeeded_pairs)} video lẻ (chưa đủ tối thiểu {min_required} video) của {folder.display_name} về vị trí cũ để lấy bù từ thư mục khác..."
                    )
                    for src, dst in succeeded_pairs:
                        try:
                            move_file(dst, src)
                            with lock:
                                moved_global = max(0, moved_global - 1)
                        except Exception:
                            pass
                    succeeded_pairs = []
                try:
                    if dest.is_dir() and not any(dest.iterdir()):
                        dest.rmdir()
                except OSError:
                    pass

            rows = [[folder.dest_name, str(src), str(dst), "MOVE"] for src, dst in succeeded_pairs]
            return len(succeeded_pairs), rows, (str(dest) if succeeded_pairs else None)

        for ti, spec in enumerate(specs):
            if self.stop_requested:
                break
            output_root = spec.output
            output_root.mkdir(parents=True, exist_ok=True)
            self.log(f"\n=== Mục xuất #{ti + 1}/{len(specs)}: {output_root} ({spec.total} video • tối thiểu {min_pf} video/thư mục) ===")

            log_rows: List[list] = []
            counts: dict[str, int] = {}
            picked_in_target: dict[int, FolderInfo] = {}
            moved_this = 0
            deficit_videos = 0

            # Bước 1: Di chuyển theo phân bổ ban đầu của từng thư mục con
            for folder in self.folders:
                if self.stop_requested:
                    break
                need_cnt = (
                    folder.per_target_counts[ti]
                    if ti < len(folder.per_target_counts)
                    else (folder.per_target_blocks[ti] * BLOCK_SIZE if ti < len(folder.per_target_blocks) else 0)
                )
                if need_cnt <= 0:
                    continue
                if folder.broken or len(folder.remaining_pool) < min_pf:
                    deficit_videos += need_cnt
                    skipped_folders_total += 1
                    self.log(
                        f"  ⚠️ [BỎ QUA THƯ MỤC] {folder.display_name} không đủ tối thiểu {min_pf} video khả dụng -> Chuyển {need_cnt} video sang lấy bù từ thư mục khác."
                    )
                    continue

                self.log(f"  • {folder.display_name}: di chuyển {need_cnt} video -> {output_root.name}\\{folder.dest_name}")
                got_cnt, rows, dest_str = move_Quota_from_folder(folder, need_cnt, output_root, ti, min_required=min_pf)
                moved_this += got_cnt
                log_rows.extend(rows)
                if dest_str and got_cnt > 0:
                    counts[dest_str] = counts.get(dest_str, 0) + got_cnt
                    picked_in_target[id(folder)] = folder

                if not self.stop_requested and got_cnt < need_cnt:
                    shortfall = need_cnt - got_cnt
                    deficit_videos += shortfall
                    skipped_folders_total += 1
                    self.log(
                        f"  ⚠️ [THIẾU QUOTA] {folder.display_name} lấy được {got_cnt}/{need_cnt} video "
                        f"-> Cần lấy bù {shortfall} video từ thư mục khác!"
                    )

            # Bước 2: Nếu có thư mục bị lỗi/khóa dẫn đến thiếu video, tự động lấy bù
            # - Nếu thiếu ít (< min_pf, ví dụ thiếu 1..24 video): ưu tiên cộng dồn vào các thư mục ĐÃ ĐƯỢC BỐC (≥ 25 video) trong mục xuất này.
            # - Nếu cần mở thư mục dự phòng mới: thư mục mới cũng luôn được bốc tối thiểu `min_pf` (25) video.
            while deficit_videos > 0 and not self.stop_requested:
                # 2A: Nếu số thiếu nhỏ hơn `min_pf`, ưu tiên lấy thêm từ các thư mục đã bốc trong mục xuất này
                if deficit_videos < min_pf and picked_in_target:
                    topup_cands = []
                    for f in picked_in_target.values():
                        if f.broken or not f.remaining_pool:
                            continue
                        future_need = sum(f.per_target_counts[ti + 1 :]) if ti + 1 < len(f.per_target_counts) else 0
                        free_now = max(0, len(f.remaining_pool) - future_need)
                        if free_now > 0:
                            topup_cands.append((free_now, f))
                    if not topup_cands:
                        for f in picked_in_target.values():
                            if not f.broken and len(f.remaining_pool) > 0:
                                topup_cands.append((len(f.remaining_pool), f))
                    if topup_cands:
                        topup_cands.sort(key=lambda x: (-x[0], x[1].root_index, x[1].name.lower()))
                        avail_v, top_folder = topup_cands[0]
                        take_cnt = min(deficit_videos, avail_v)
                        self.log(
                            f"  🔄 [BÙ THÊM VÀO THƯ MỤC ĐÃ BỐC] Lấy thêm {take_cnt} video từ \"{top_folder.display_name}\"..."
                        )
                        got_cnt, rows, dest_str = move_Quota_from_folder(top_folder, take_cnt, output_root, ti, min_required=1)
                        if got_cnt > 0:
                            moved_this += got_cnt
                            log_rows.extend(rows)
                            if dest_str:
                                counts[dest_str] = counts.get(dest_str, 0) + got_cnt
                            deficit_videos = max(0, deficit_videos - got_cnt)
                            continue
                        else:
                            top_folder.broken = True
                            continue

                # 2B: Chọn thư mục dự phòng mới (hoặc còn dư ≥ min_pf video) để lấy bù tối thiểu `min_pf` (25) video
                candidates = []
                for f in self.folders:
                    if f.broken:
                        continue
                    already_picked = id(f) in picked_in_target
                    min_need_for_f = 1 if already_picked else min_pf
                    future_need = sum(f.per_target_counts[ti + 1 :]) if ti + 1 < len(f.per_target_counts) else 0
                    free_now = len(f.remaining_pool) - future_need
                    if free_now >= min_need_for_f:
                        candidates.append((0 if not already_picked else 1, free_now, f, min_need_for_f))
                if not candidates:
                    for f in self.folders:
                        if f.broken:
                            continue
                        already_picked = id(f) in picked_in_target
                        min_need_for_f = 1 if already_picked else min_pf
                        if len(f.remaining_pool) >= min_need_for_f:
                            candidates.append((0 if not already_picked else 1, len(f.remaining_pool), f, min_need_for_f))

                if not candidates:
                    self.log(
                        f"  ❌ [CẢNH BÁO] Không còn thư mục con nào khác đủ điều kiện (≥ {min_pf} video) để bù thêm {deficit_videos} video!"
                    )
                    break

                # Ưu tiên thư mục mới còn dư nhiều video nhất, sau đó tới thư mục đã bốc
                candidates.sort(key=lambda x: (x[0], -x[1], x[2].root_index, x[2].name.lower()))
                _, avail_v, backup_folder, min_req = candidates[0]
                take_cnt = min(avail_v, max(deficit_videos, min_req))

                self.log(
                    f"  🔄 [LẤY BÙ TỰ ĐỘNG] Chọn thư mục \"{backup_folder.display_name}\" lấy bù {take_cnt} video (tối thiểu ≥ {min_req})..."
                )
                got_cnt, rows, dest_str = move_Quota_from_folder(backup_folder, take_cnt, output_root, ti, min_required=min_req)
                if got_cnt > 0:
                    moved_this += got_cnt
                    log_rows.extend(rows)
                    if dest_str:
                        counts[dest_str] = counts.get(dest_str, 0) + got_cnt
                    picked_in_target[id(backup_folder)] = backup_folder
                    deficit_videos = max(0, deficit_videos - got_cnt)
                else:
                    backup_folder.broken = True

            # Ghi nối vào selected_videos_log.csv để phục vụ Khôi phục chính xác về từng ổ đĩa nguồn
            log_path = output_root / LOG_NAME
            write_header = not log_path.exists()
            with log_path.open("a", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                if write_header:
                    w.writerow(["folder", "source", "destination", "action"])
                w.writerows(log_rows)

            txt = output_root / "thu_muc_co_video.txt"
            with txt.open("w", encoding="utf-8-sig") as f:
                for p, c in sorted(counts.items(), key=lambda x: x[0].lower()):
                    if c > 0:
                        f.write(p + "\n")
            self.log(f"  -> Đã di chuyển thành công {moved_this}/{spec.total} video, xuất TXT: {txt}")

        summary_extra = ""
        if skipped_files_total or skipped_folders_total:
            summary_extra = (
                f" (Đã tự động bỏ qua & lấy bù thay thế cho {skipped_files_total} video lỗi/bận "
                f"và {skipped_folders_total} thư mục thiếu quota)."
            )
        if self.stop_requested:
            self.log(f"\nĐÃ DỪNG. Đã di chuyển {moved_global}/{total_to_move} video.{summary_extra}")
        else:
            self.log(f"\n✅ HOÀN TẤT. Đã di chuyển {moved_global}/{total_to_move} video vào {len(specs)} thư mục xuất.{summary_extra}")
        self.prog = {"pct": 100 if not self.stop_requested else self.prog["pct"], "text": "Đã dừng" if self.stop_requested else "Hoàn tất"}
        self.folders = []

    # ---- KHÔI PHỤC VỀ THƯ MỤC GỐC (HỖ TRỢ NHIỀU Ổ CỨNG NGUỒN) ----
    def act_restore(self, data):
        if self.running:
            return {"error": "Đang chạy"}
        raw_outs = data.get("outputs") or []
        outs = []
        seen = set()
        for r in raw_outs:
            s = (r or "").strip()
            if not s:
                continue
            p = Path(s)
            norm = normalize_for_compare(p)
            if norm not in seen and p.is_dir():
                seen.add(norm)
                outs.append(p)
        if not outs:
            return {"error": "Chưa có thư mục xuất hợp lệ nào để khôi phục."}

        fallback_roots: List[Path] = []
        raw_sources = data.get("sources") or []
        if not raw_sources and data.get("source"):
            raw_sources = [data.get("source")]
        for item in raw_sources:
            s = (item.get("path") if isinstance(item, dict) else str(item or "")).strip()
            if s and Path(s).is_dir():
                fallback_roots.append(Path(s))

        try:
            threads = max(1, min(16, int(data.get("threads") or 4)))
        except Exception:
            threads = 4

        self.clear_log()
        self.stop_requested = False
        self.prog = {"pct": 0, "text": "Đang chuẩn bị khôi phục..."}
        self.run_bg(self.restore_work, outs, fallback_roots, threads)
        return {"ok": 1}

    def restore_work(self, outs: List[Path], fallback_roots: List[Path], threads: int = 4):
        lock = threading.Lock()
        all_jobs: List[tuple[Path, Path, Path]] = []

        for out_root in outs:
            log_path = out_root / LOG_NAME
            logged_dsts = set()
            if log_path.is_file():
                try:
                    with log_path.open("r", newline="", encoding="utf-8-sig") as f:
                        reader = csv.DictReader(f)
                        for row in reader:
                            src_s = (row.get("source") or "").strip()
                            dst_s = (row.get("destination") or "").strip()
                            if not src_s or not dst_s:
                                continue
                            dst_p = Path(dst_s)
                            src_p = Path(src_s)
                            if dst_p.is_file():
                                all_jobs.append((out_root, dst_p, src_p))
                                logged_dsts.add(normalize_for_compare(dst_p))
                except Exception as e:
                    self.log(f"[CẢNH BÁO] Không đọc được {log_path}: {e}")

            # Nếu còn video trong các thư mục con của out_root mà không nằm trong log (hoặc mất log),
            # tìm thư mục gốc phù hợp trong danh sách fallback_roots để trả về.
            if fallback_roots:
                for sub in find_category_folders(out_root):
                    target_root = fallback_roots[0]
                    for r in fallback_roots:
                        if (r / sub.name).is_dir():
                            target_root = r
                            break
                    for vf in scan_videos_in_folder(sub):
                        if normalize_for_compare(vf) not in logged_dsts:
                            clean_name = vf.stem.split("__")[0] + vf.suffix
                            all_jobs.append((out_root, vf, target_root / sub.name / clean_name))

        total = len(all_jobs)
        if total == 0:
            self.log("Không tìm thấy video nào cần khôi phục trong các thư mục xuất đã chọn.")
            self.prog = {"pct": 100, "text": "Không có file"}
            return

        self.log(f"Bắt đầu KHÔI PHỤC {total} video từ {len(outs)} thư mục xuất về đúng các ổ đĩa & thư mục gốc ban đầu...")
        restored = 0
        failed = 0

        prepared: List[tuple[Path, Path, Path]] = []
        reserved = set()
        for out_root, cur_file, target_orig in all_jobs:
            dst = target_orig
            if dst.exists() or str(dst).lower() in reserved:
                dst = unique_destination_path(target_orig.parent, target_orig, reserved)
            reserved.add(str(dst).lower())
            prepared.append((out_root, cur_file, dst))

        def run_restore(item):
            nonlocal restored, failed
            if self.stop_requested:
                return
            _, cur_file, dst = item
            try:
                move_file(cur_file, dst)
                with lock:
                    restored += 1
                    self.prog = {"pct": (restored + failed) / total * 100, "text": f"Khôi phục {restored}/{total}"}
            except Exception as e:
                with lock:
                    failed += 1
                self.log(f"[BỎ QUA FILE LỖI KHI KHÔI PHỤC] {cur_file.name}: {e}")

        with ThreadPoolExecutor(max_workers=threads) as ex:
            list(ex.map(run_restore, prepared))

        if not self.stop_requested and failed == 0:
            for out_root in outs:
                for aux in (out_root / LOG_NAME, out_root / "thu_muc_co_video.txt"):
                    try:
                        if aux.is_file():
                            aux.unlink()
                    except OSError:
                        pass
                for sub in find_category_folders(out_root):
                    try:
                        if not any(sub.iterdir()):
                            sub.rmdir()
                    except OSError:
                        pass

        self.log(f"HOÀN TẤT KHÔI PHỤC: {restored}/{total} video đã trả về thư mục gốc" + (f" ({failed} file đang bận chưa chuyển được)." if failed else "."))
        self.prog = {"pct": 100 if not self.stop_requested else self.prog["pct"],
                     "text": "Đã dừng" if self.stop_requested else f"Đã khôi phục {restored} video"}
        self.folders = []

    def act_open_folder(self, data):
        p = data.get("path")
        if p and Path(p).exists():
            os.startfile(p)
        return {}
