"""Tính năng: tải video / mp3 từ YouTube ngay trong MyingGo.
Hỗ trợ chống chặn 429 / Sign in to confirm you're not a bot bằng:
- Tự xoay vòng player_client (tv_embedded, android_vr, ios, web...)
- Tùy chọn lấy cookies trực tiếp từ trình duyệt (Edge/Chrome/Firefox/Brave) hoặc file cookies.txt."""
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from core import dialogs
from core.base import Feature

CFG = Path(__file__).with_name("downloader_config.json")
LOCAL = Path(os.environ.get("LOCALAPPDATA", ""))
ROAM = Path(os.environ.get("APPDATA", ""))
BIN_YTDLP = Path(__file__).resolve().parent.parent / "bin" / "yt-dlp.exe"
YTDLP_CANDIDATES = [BIN_YTDLP, LOCAL / "Youwee" / "youwee-yt-dlp.exe", LOCAL / "Youwee" / "yt-dlp.exe"]
FFMPEG_CANDIDATES = [
    Path(r"C:\Users\MixiComputer\Music\DgtAutoTTSMM_v3\ffmpeg.exe"),
    Path(r"C:\Program Files\FormatFactory5.20.0.0\ffmpeg.exe"),
]
DENO_DIR = ROAM / "com.vanloctech.youwee" / "bin"
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PROG = re.compile(r"\[download\]\s+([\d.]+)%")

# Các chiến lược vượt chặn YouTube (429 / bot check / missing visitor_data)
BYPASS_STRATEGIES = [
    ("tv,android_vr", "client TV + Android VR"),
    ("mweb,ios", "client Mobile Web + iOS"),
    ("web_embedded,tv", "client Web Embedded + TV"),
]


def _cfg():
    try:
        return json.loads(CFG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(**kw):
    c = _cfg()
    c.update(kw)
    CFG.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")


def find_ytdlp():
    p = _cfg().get("ytdlp")
    if p and Path(p).is_file():
        return p
    for c in YTDLP_CANDIDATES:
        if c.is_file():
            return str(c)
    return shutil.which("yt-dlp")


def find_ffmpeg():
    p = _cfg().get("ffmpeg")
    if p and Path(p).is_file():
        return p
    b = BIN_YTDLP.parent / "ffmpeg.exe"
    if b.is_file():
        return str(b)
    w = shutil.which("ffmpeg")
    if w:
        return w
    for c in FFMPEG_CANDIDATES:
        if c.is_file():
            return str(c)
    return None


def default_folder():
    return _cfg().get("folder") or str(Path.home() / "Downloads" / "MyingGo")


class Downloader(Feature):
    title = "Tải video / MP3"
    order = 15

    def __init__(self):
        super().__init__()
        self.proc = None
        self.prog = {"pct": 0, "text": ""}
        self.stopped = False

    def act_status(self, data):
        c = _cfg()
        y, f = find_ytdlp(), find_ffmpeg()
        return {
            "ytdlp": y,
            "ffmpeg": f,
            "folder": default_folder(),
            "running": self.running,
            "cookie_src": c.get("cookie_src", "none"),
            "cookie_file": c.get("cookie_file", ""),
        }

    def act_pick_folder(self, data):
        p = dialogs.pick_folder()
        if p:
            _save(folder=p)
        return {"path": p}

    def act_pick_ffmpeg(self, data):
        p = dialogs.pick_exe()
        if p:
            _save(ffmpeg=p)
        return self.act_status(data)

    def act_pick_cookie_file(self, data):
        p = dialogs.pick_txt()
        if p:
            _save(cookie_file=p, cookie_src="file")
        return self.act_status(data)

    def act_open_folder(self, data):
        p = Path(data.get("path") or default_folder())
        p.mkdir(parents=True, exist_ok=True)
        os.startfile(str(p))
        return {}

    def act_progress(self, data):
        return dict(self.prog, running=self.running)

    def act_stop(self, data):
        self.stopped = True
        if self.proc and self.proc.poll() is None:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.proc.pid)], capture_output=True,
                           creationflags=NOWIN)
        return {}

    def act_start(self, data):
        urls = [u.strip() for u in re.split(r"\s+", data.get("urls", "")) if u.strip()]
        if not urls:
            return {"error": "Chưa nhập link"}
        y = find_ytdlp()
        if not y:
            return {"error": "Không tìm thấy yt-dlp.exe"}
        mode = data.get("mode", "video")
        ff = find_ffmpeg()
        if mode == "mp3" and not ff:
            return {"error": "Cần ffmpeg để chuyển sang MP3, hãy chọn ffmpeg.exe ở phía dưới"}
        folder = (data.get("folder") or default_folder()).strip()
        try:
            Path(folder).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return {"error": f"Không tạo được thư mục: {e}"}
        cookie_src = data.get("cookie_src") or "none"
        cookie_file = (data.get("cookie_file") or "").strip()
        _save(folder=folder, cookie_src=cookie_src, cookie_file=cookie_file)
        if self.running:
            return {"error": "Đang tải"}
        self.clear_log()
        self.stopped = False
        self.prog = {"pct": 0, "text": "Đang bắt đầu..."}
        opts = {
            "mode": mode,
            "quality": data.get("quality", "best"),
            "folder": folder,
            "playlist": bool(data.get("playlist")),
            "cookie_src": cookie_src,
            "cookie_file": cookie_file,
        }
        self.run_bg(self.work, y, ff, urls, opts)
        return {"ok": 1}

    def build_cmd(self, y, ff, opts, player_client=None):
        mode = opts["mode"]
        quality = opts["quality"]
        folder = opts["folder"]
        playlist = opts["playlist"]
        cookie_src = opts.get("cookie_src", "none")
        cookie_file = opts.get("cookie_file", "")

        cmd = [y, "--newline", "--windows-filenames", "--no-colors", "-P", folder,
               "-o", "%(title).150B [%(id)s].%(ext)s"]
        cmd.append("--yes-playlist" if playlist else "--no-playlist")
        if ff:
            cmd += ["--ffmpeg-location", ff]
        if player_client:
            cmd += ["--extractor-args", f"youtube:player_client={player_client}"]
        if cookie_src == "file" and cookie_file and Path(cookie_file).is_file():
            cmd += ["--cookies", cookie_file]
        elif cookie_src in ("edge", "chrome", "firefox", "brave", "opera"):
            cmd += ["--cookies-from-browser", cookie_src]

        if mode == "mp3":
            cmd += ["-x", "--audio-format", "mp3", "--audio-quality", "0"]
        else:
            h = "" if quality == "best" else f"[height<={int(quality)}]"
            if ff:
                cmd += ["-f", f"bv*{h}+ba/b{h}/b", "--merge-output-format", "mp4"]
            else:
                cmd += ["-f", f"b{h}/b"]
                self.log("[LƯU Ý] Không có ffmpeg: tải file gộp sẵn (chất lượng có thể thấp hơn).")
        return cmd

    def work(self, y, ff, urls, opts):
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        extra = [str(BIN_YTDLP.parent)] + ([str(DENO_DIR)] if DENO_DIR.is_dir() else [])
        env["PATH"] = os.pathsep.join(extra) + os.pathsep + env.get("PATH", "")
        ok = fail = 0
        for i, url in enumerate(urls, 1):
            if self.stopped:
                break
            self.log(f"\n=== [{i}/{len(urls)}] {url}")
            cmd = self.build_cmd(y, ff, opts) + [url]
            code, err_kind = self.run_once(cmd, env)

            # Nếu bị 429 / Bot check / thiếu Visitor Data -> tự thử xoay vòng các player_client khác
            if code != 0 and err_kind in ("bot_429", "403") and not self.stopped:
                for client_arg, label in BYPASS_STRATEGIES:
                    if self.stopped:
                        break
                    self.log(f"[TỰ SỬA] YouTube chặn IP/bot ({err_kind}) -> thử sang {label}...")
                    cmd_alt = self.build_cmd(y, ff, opts, player_client=client_arg) + [url]
                    code, err_kind = self.run_once(cmd_alt, env)
                    if code == 0:
                        break

            # Nếu vẫn lỗi 403/bot -> cập nhật yt-dlp lên bản mới nhất rồi thử lại
            if code != 0 and err_kind in ("bot_429", "403") and not self.stopped:
                self.log("[TỰ SỬA] Đang cập nhật yt-dlp lên bản mới nhất rồi thử lại...")
                self.update_ytdlp(y, env)
                if BIN_YTDLP.is_file():
                    y = str(BIN_YTDLP)
                cmd_u = self.build_cmd(y, ff, opts, player_client="tv,android_vr") + [url]
                code, err_kind = self.run_once(cmd_u, env)

            if code != 0 and err_kind == "bot_429":
                self.log(
                    "[GỢI Ý] IP mạng trên máy này đang bị YouTube chặn gắt (HTTP 429 / Sign in to confirm you're not a bot). "
                    "Hãy chọn mục 'Cookies vượt chặn' = File cookies.txt (hoặc trình duyệt đang đăng nhập YouTube) ở bên trên rồi bấm Tải lại."
                )
            if code == 0:
                ok += 1
            else:
                fail += 1
        self.prog = {"pct": 100 if not fail and not self.stopped else self.prog["pct"],
                     "text": "Đã dừng" if self.stopped else "Hoàn tất"}
        self.log(f"\nXong: {ok} thành công, {fail} lỗi. Thư mục: {opts['folder']}")

    def run_once(self, cmd, env):
        err_kind = None
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env,
                                     creationflags=NOWIN)
        for raw in iter(self.proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").rstrip()
            m = PROG.search(line)
            if m:
                self.prog = {"pct": float(m.group(1)), "text": line.replace("[download]", "").strip()}
            elif line:
                self.log(line)
                low = line.lower()
                if ("429" in line or "not a bot" in low or "visitor data" in low or "po token" in low):
                    err_kind = "bot_429"
                elif "403" in line and "forbidden" in low and not err_kind:
                    err_kind = "403"
        return self.proc.wait(), err_kind

    def update_ytdlp(self, y, env):
        if not BIN_YTDLP.is_file():
            try:
                BIN_YTDLP.parent.mkdir(exist_ok=True)
                shutil.copyfile(y, BIN_YTDLP)
            except Exception as e:
                self.log(f"[LỖI] Không sao chép được yt-dlp: {e}")
                return
        r = subprocess.run([str(BIN_YTDLP), "-U"], capture_output=True, env=env, creationflags=NOWIN)
        self.log(r.stdout.decode("utf-8", "replace").strip().splitlines()[-1] if r.stdout.strip() else "")
