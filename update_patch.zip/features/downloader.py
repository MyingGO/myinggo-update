"""Tính năng: tải video / mp3 đa nền tảng (YouTube, TikTok, Douyin, Facebook...).
Hỗ trợ:
- Tự động tách link hợp lệ từ văn bản chia sẻ của TikTok, Douyin, Facebook...
- Giải mã link rút gọn (v.douyin.com, vt.tiktok.com, fb.watch, fb share, modal_id...).
- Bộ bóc tách chuyên sâu cho Douyin: tự giải mã RENDER_DATA URL-encoded, hỗ trợ không logo/watermark, không phụ thuộc vào yt-dlp khi bị 403.
- Chống chặn 429 / bot check YouTube (xoay player_client).
- Tải video Facebook nhóm kín / hạn chế bằng cookies trình duyệt (Edge/Chrome/Firefox).
- Tải video không logo / watermark từ TikTok và Douyin.
- Cập nhật tự động hoặc thủ công yt-dlp.
"""
import json
import os
import random
import re
import shutil
import subprocess
import time
import urllib.parse
import urllib.request
from pathlib import Path

from core import dialogs
from core.base import Feature

CFG = Path(__file__).with_name("downloader_config.json")
LOCAL = Path(os.environ.get("LOCALAPPDATA", ""))
ROAM = Path(os.environ.get("APPDATA", ""))
BIN_YTDLP = Path(__file__).resolve().parent.parent / "bin" / "yt-dlp.exe"
YTDLP_CANDIDATES = [BIN_YTDLP, LOCAL / "Youwee" / "youwee-yt-dlp.exe", LOCAL / "Youwee" / "yt-dlp.exe"]
FFMPEG_CANDIDATES = [
    Path(r"C:\ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin\ffmpeg.exe"),
    Path(r"C:\Program Files\FormatFactory5.20.0.0\ffmpeg.exe"),
    Path(r"C:\Users\MixiComputer\Music\DgtAutoTTSMM_v3\ffmpeg.exe"),
]
DENO_DIR = ROAM / "com.vanloctech.youwee" / "bin"
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PROG = re.compile(r"\[download\]\s+([\d.]+)%")

BYPASS_STRATEGIES = [
    ("tv,android_vr", "client TV + Android VR"),
    ("mweb,ios", "client Mobile Web + iOS"),
    ("web_embedded,tv", "client Web Embedded + TV"),
]

MOBILE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"


def _cfg():
    try:
        return json.loads(CFG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(**kw):
    c = _cfg()
    c.update(kw)
    CFG.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")


def find_ytdlp():
    p = _cfg().get("ytdlp")
    if p and Path(p).is_file():
        return p
    for c in YTDLP_CANDIDATES:
        if c.is_file():
            return str(c)
    return shutil.which("yt-dlp")


def find_ffmpeg():
    p = _cfg().get("ffmpeg")
    if p and Path(p).is_file():
        try:
            if Path(p).stat().st_size > 10_000_000:
                return p
        except Exception:
            pass
    b = BIN_YTDLP.parent / "ffmpeg.exe"
    if b.is_file():
        try:
            if b.stat().st_size > 10_000_000:
                return str(b)
        except Exception:
            pass
    for c in FFMPEG_CANDIDATES:
        if c.is_file():
            try:
                if c.stat().st_size > 10_000_000:
                    return str(c)
            except Exception:
                pass
    w = shutil.which("ffmpeg")
    if w and "chocolatey\\bin" not in w.lower():
        try:
            if Path(w).stat().st_size > 10_000_000:
                return w
        except Exception:
            pass
    return None


def default_folder():
    return _cfg().get("folder") or str(Path.home() / "Downloads" / "T2MG_Downloads")


def extract_urls(raw_text: str) -> list[str]:
    """Trích xuất các liên kết từ văn bản nhập vào."""
    if not raw_text:
        return []
    found = re.findall(r'https?://[^\s<>"\',;()[\]{}|\\^`]+', raw_text)
    cleaned = []
    seen = set()
    for u in found:
        u = re.sub(r'[\.,:;!?]+$', '', u).strip()
        if u and u not in seen:
            seen.add(u)
            cleaned.append(u)
    return cleaned


def detect_platform(url: str) -> tuple[str, str, str]:
    """Trả về (platform_id, icon, display_name)"""
    u = url.lower()
    if any(k in u for k in ("youtube.com", "youtu.be")):
        return ("youtube", "🎬", "YouTube")
    if any(k in u for k in ("douyin.com", "iesdouyin.com")):
        return ("douyin", "🏮", "Douyin")
    if any(k in u for k in ("tiktok.com",)):
        return ("tiktok", "🎵", "TikTok")
    if any(k in u for k in ("facebook.com", "fb.watch", "fb.com", "messenger.com")):
        return ("facebook", "📘", "Facebook")
    if any(k in u for k in ("instagram.com", "instagr.am")):
        return ("instagram", "📸", "Instagram")
    if any(k in u for k in ("twitter.com", "x.com")):
        return ("twitter", "🐦", "Twitter/X")
    if any(k in u for k in ("threads.net",)):
        return ("threads", "🧵", "Threads")
    return ("general", "🌐", "Web Video")


def extract_douyin_video_id(url: str) -> str | None:
    """Lấy item_id từ URL Douyin (video/note/modal_id/aweme_id)"""
    m = re.search(r'/(?:video|note|share/video)/(\d+)', url)
    if m:
        return m.group(1)
    m = re.search(r'modal_id=(\d+)', url)
    if m:
        return m.group(1)
    m = re.search(r'aweme_id=(\d+)', url)
    if m:
        return m.group(1)
    return None


def resolve_short_url(url: str, timeout: float = 6.0) -> str:
    """Giải mã link rút gọn hoặc định dạng đặc biệt (v.douyin.com, fb.watch, modal_id...)."""
    try:
        # Xử lý link dạng modal_id (VD: https://www.douyin.com/jingxuan?modal_id=7703997413695219810)
        m_modal = re.search(r'modal_id=(\d+)', url)
        if m_modal and "douyin.com" in url:
            return f"https://www.douyin.com/video/{m_modal.group(1)}"

        u_lower = url.lower()
        needs_resolve = any(d in u_lower for d in (
            "v.douyin.com", "fb.watch", "facebook.com/share/", "vt.tiktok.com", "vm.tiktok.com"
        ))
        if not needs_resolve:
            return url

        req = urllib.request.Request(url, headers={"User-Agent": DESKTOP_UA})
        opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler)
        with opener.open(req, timeout=timeout) as resp:
            final_url = resp.geturl()
            if final_url:
                m_douyin = re.search(r'(https?://(?:www\.)?douyin\.com/video/\d+)', final_url)
                if m_douyin:
                    return m_douyin.group(1)
                return final_url
    except Exception:
        pass
    return url


def gen_verify_fp() -> str:
    """Tạo s_v_web_id theo chuẩn ByteDance"""
    base_str = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    t = len(base_str)
    milliseconds = int(round(time.time() * 1000))
    base36 = ""
    while milliseconds > 0:
        milliseconds, remainder = divmod(milliseconds, t)
        base36 = base_str[remainder] + base36
    random_str = "".join(random.choices(base_str, k=16))
    return f"verify_{base36}_{random_str}"


def get_douyin_visitor_cookies_file() -> Path | None:
    """Tạo file cookies Netscape chứa ttwid + s_v_web_id cho yt-dlp."""
    try:
        cookie_path = Path(__file__).resolve().parent / "douyin_guest_cookies.txt"
        if cookie_path.exists() and (time.time() - cookie_path.stat().st_mtime) < 43200:
            return cookie_path

        ttwid = None
        try:
            reg_url = "https://ttwid.bytedance.com/ttwid/union/register/"
            payload = json.dumps({
                "region": "cn",
                "aid": 1768,
                "needFid": False,
                "service": "www.ixigua.com",
                "migrate_info": {"ticket": "", "source": "node"},
                "cbUrlProtocol": "https",
                "union": True
            }).encode("utf-8")
            req = urllib.request.Request(
                reg_url, data=payload,
                headers={"Content-Type": "application/json; charset=utf-8", "User-Agent": DESKTOP_UA}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                headers = resp.headers.get_all("Set-Cookie") or []
                for h in headers:
                    m = re.search(r'ttwid=([^;]+)', h)
                    if m:
                        ttwid = m.group(1)
                        break
        except Exception:
            pass

        if not ttwid:
            try:
                req = urllib.request.Request("https://www.douyin.com/", headers={"User-Agent": DESKTOP_UA})
                with urllib.request.urlopen(req, timeout=5) as resp:
                    headers = resp.headers.get_all("Set-Cookie") or []
                    for h in headers:
                        m = re.search(r'ttwid=([^;]+)', h)
                        if m:
                            ttwid = m.group(1)
                            break
            except Exception:
                pass

        if not ttwid:
            ttwid = f"1%7C{''.join(random.choices('0123456789abcdef', k=32))}%7C{int(time.time())}%7C{''.join(random.choices('0123456789abcdef', k=64))}"

        s_v_web_id = gen_verify_fp()
        expiry = int(time.time()) + 86400 * 30

        lines = [
            "# Netscape HTTP Cookie File",
            f".douyin.com\tTRUE\t/\tFALSE\t{expiry}\tttwid\t{ttwid}",
            f".douyin.com\tTRUE\t/\tFALSE\t{expiry}\ts_v_web_id\t{s_v_web_id}",
            f".douyin.com\tTRUE\t/\tFALSE\t{expiry}\tpassport_csrf_token\t{''.join(random.choices('0123456789abcdef', k=32))}",
            f"www.douyin.com\tFALSE\t/\tFALSE\t{expiry}\ts_v_web_id\t{s_v_web_id}",
        ]
        cookie_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return cookie_path
    except Exception:
        return None


class Downloader(Feature):
    title = "Tải video / MP3"
    order = 15

    def __init__(self):
        super().__init__()
        self.proc = None
        self.prog = {"pct": 0, "text": ""}
        self.stopped = False

    def act_status(self, data):
        c = _cfg()
        y, f = find_ytdlp(), find_ffmpeg()
        return {
            "ytdlp": y,
            "ffmpeg": f,
            "folder": default_folder(),
            "running": self.running,
            "cookie_src": c.get("cookie_src", "none"),
            "cookie_file": c.get("cookie_file", ""),
        }

    def act_open_douyin(self, data):
        import webbrowser
        webbrowser.open("https://www.douyin.com/")
        return {"ok": True}

    def act_pick_folder(self, data):
        p = dialogs.pick_folder()
        if p:
            _save(folder=p)
        return {"path": p}

    def act_pick_ffmpeg(self, data):
        p = dialogs.pick_exe()
        if p:
            _save(ffmpeg=p)
        return self.act_status(data)

    def act_pick_cookie_file(self, data):
        p = dialogs.pick_txt()
        if p:
            _save(cookie_file=p, cookie_src="file")
        return self.act_status(data)

    def act_open_folder(self, data):
        p = Path(data.get("path") or default_folder())
        p.mkdir(parents=True, exist_ok=True)
        os.startfile(str(p))
        return {}

    def act_progress(self, data):
        return dict(self.prog, running=self.running)

    def act_stop(self, data):
        self.stopped = True
        if self.proc and self.proc.poll() is None:
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.proc.pid)], capture_output=True,
                               creationflags=NOWIN)
            except Exception:
                pass
        return {}

    def act_update_ytdlp(self, data):
        y = find_ytdlp()
        if not y:
            return {"error": "Không tìm thấy yt-dlp.exe"}
        try:
            r = subprocess.run([y, "-U"], capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=NOWIN)
            out = (r.stdout or "").strip()
            err = (r.stderr or "").strip()
            msg = out or err or "Đã kiểm tra cập nhật yt-dlp."
            return {"msg": msg}
        except Exception as e:
            return {"error": f"Lỗi khi cập nhật yt-dlp: {e}"}

    def act_start(self, data):
        raw_urls = data.get("urls", "")
        urls = extract_urls(raw_urls)
        if not urls:
            lines = [line.strip() for line in raw_urls.splitlines() if line.strip()]
            for line in lines:
                if any(domain in line.lower() for domain in ("youtube.com", "youtu.be", "tiktok.com", "douyin.com", "facebook.com", "fb.watch")):
                    m = re.search(r'([a-zA-Z0-9.\-_]+\.(com|be|watch)/[^\s]+)', line)
                    if m:
                        urls.append("https://" + m.group(1))

        if not urls:
            return {"error": "Chưa tìm thấy link hợp lệ. Hãy dán link YouTube, TikTok, Douyin hoặc Facebook!"}

        y = find_ytdlp()
        if not y:
            return {"error": "Không tìm thấy yt-dlp.exe"}
        mode = data.get("mode", "video")
        ff = find_ffmpeg()
        if mode == "mp3" and not ff:
            return {"error": "Cần ffmpeg để chuyển sang MP3, hãy chọn ffmpeg.exe ở phía dưới"}
        folder = (data.get("folder") or default_folder()).strip()
        try:
            Path(folder).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return {"error": f"Không tạo được thư mục: {e}"}

        cookie_src = data.get("cookie_src") or "none"
        cookie_file = (data.get("cookie_file") or "").strip()
        _save(folder=folder, cookie_src=cookie_src, cookie_file=cookie_file)
        if self.running:
            return {"error": "Đang có tiến trình tải đang chạy"}
        self.clear_log()
        self.stopped = False
        self.prog = {"pct": 0, "text": "Đang bắt đầu..."}
        opts = {
            "mode": mode,
            "quality": data.get("quality", "best"),
            "folder": folder,
            "playlist": bool(data.get("playlist")),
            "cookie_src": cookie_src,
            "cookie_file": cookie_file,
        }
        self.run_bg(self.work, y, ff, urls, opts)
        return {"ok": 1, "count": len(urls)}

    def build_cmd(self, y, ff, opts, url, player_client=None):
        mode = opts["mode"]
        quality = opts["quality"]
        folder = opts["folder"]
        playlist = opts["playlist"]
        cookie_src = opts.get("cookie_src", "none")
        cookie_file = opts.get("cookie_file", "")
        plat_id, _, _ = detect_platform(url)

        cmd = [
            y,
            "--newline",
            "--windows-filenames",
            "--no-colors",
            "-P", folder,
            "-o", "%(title).150B [%(id)s].%(ext)s",
            "--user-agent", DESKTOP_UA,
        ]

        cmd.append("--yes-playlist" if playlist else "--no-playlist")
        if ff:
            cmd += ["--ffmpeg-location", ff]

        # Chỉ áp dụng player_client khi là YouTube
        if plat_id == "youtube" and player_client:
            cmd += ["--extractor-args", f"youtube:player_client={player_client}"]

        # Cookies từ file hoặc trực tiếp từ trình duyệt
        if cookie_src == "file" and cookie_file and Path(cookie_file).is_file():
            cmd += ["--cookies", cookie_file]
        elif cookie_src in ("edge", "chrome", "firefox", "brave", "opera"):
            cmd += ["--cookies-from-browser", cookie_src]
        elif plat_id == "douyin" and cookie_src == "none":
            guest_cookie = get_douyin_visitor_cookies_file()
            if guest_cookie and guest_cookie.is_file():
                cmd += ["--cookies", str(guest_cookie)]

        if mode == "mp3":
            cmd += ["-x", "--audio-format", "mp3", "--audio-quality", "0"]
        else:
            if quality == "best":
                # Ưu tiên H.264 (avc1) + AAC (mp4a) chuẩn để kéo thẳng vào Premiere Pro, CapCut, DaVinci Resolve
                # Nếu không có hoặc video 4K chỉ có VP9/AV1, tự động gộp thành mp4
                fmt = "bv*[vcodec^=avc1]+ba[acodec^=mp4a]/bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b"
            else:
                q = int(quality)
                fmt = (
                    f"bv*[height<={q}][vcodec^=avc1]+ba[acodec^=mp4a]/"
                    f"bv*[height<={q}][ext=mp4]+ba[ext=m4a]/"
                    f"bv*[height<={q}]+ba/b[height<={q}]/b"
                )

            if ff:
                cmd += [
                    "-f", fmt,
                    "--merge-output-format", "mp4",
                    "--postprocessor-args", "MergerName:-c:a aac"
                ]
            else:
                cmd += ["-f", "b"]
                self.log("[LƯU Ý] Không có ffmpeg: tải file gộp sẵn (chất lượng có thể thấp hơn).")
        return cmd

    def download_douyin_direct(self, video_id: str, dest_folder: str, mode: str, ff_path: str | None) -> bool:
        """Bộ bóc tách link gốc Douyin trực tiếp (không watermark, giải mã RENDER_DATA)."""
        headers_mobile = {
            "User-Agent": MOBILE_UA,
            "Referer": "https://www.iesdouyin.com/",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }
        self.log(f"  🔍 Đang quét dữ liệu video Douyin ID [{video_id}] qua cổng chia sẻ iesdouyin...")

        video_url = None
        audio_url = None
        title = f"douyin_{video_id}"

        # 1. Bóc tách từ trang chia sẻ iesdouyin.com/share/video/{video_id}/
        try:
            share_url = f"https://www.iesdouyin.com/share/video/{video_id}/"
            req = urllib.request.Request(share_url, headers=headers_mobile)
            with urllib.request.urlopen(req, timeout=12) as resp:
                html = resp.read().decode("utf-8", errors="replace")

            # Tìm script RENDER_DATA hoặc _ROUTER_DATA
            raw_script_content = None
            for pattern in (
                r'<script[^>]*id=["\']RENDER_DATA["\'][^>]*>(.*?)</script>',
                r'<script[^>]*id=["\']_ROUTER_DATA["\'][^>]*>(.*?)</script>',
                r'window\._ROUTER_DATA\s*=\s*(.+?);\s*</script>',
                r'window\._SSR_DATA\s*=\s*(.+?);\s*</script>',
            ):
                m = re.search(pattern, html, re.DOTALL)
                if m:
                    raw_script_content = m.group(1).strip()
                    break

            if raw_script_content:
                # Giải mã URL-encode nếu có (Douyin thường encode %7B...%7D)
                if "%7B" in raw_script_content or "%22" in raw_script_content:
                    raw_script_content = urllib.parse.unquote(raw_script_content)

                if raw_script_content.startswith('"') and raw_script_content.endswith('"'):
                    raw_script_content = json.loads(raw_script_content)

                data = json.loads(raw_script_content)

                def scan(obj):
                    nonlocal video_url, audio_url, title
                    if isinstance(obj, dict):
                        if "desc" in obj and isinstance(obj["desc"], str) and obj["desc"].strip() and title == f"douyin_{video_id}":
                            title = obj["desc"].strip()
                        if "video" in obj and isinstance(obj["video"], dict) and not video_url:
                            v = obj["video"]
                            p_addr = v.get("play_addr") or v.get("play_addr_h264") or v.get("play_addr_265")
                            if isinstance(p_addr, dict) and p_addr.get("url_list"):
                                video_url = p_addr["url_list"][0]
                        if "music" in obj and isinstance(obj["music"], dict) and not audio_url:
                            m = obj["music"]
                            p_addr = m.get("play_url")
                            if isinstance(p_addr, dict) and p_addr.get("url_list"):
                                audio_url = p_addr["url_list"][0]
                        for val in obj.values():
                            if not video_url:
                                scan(val)
                    elif isinstance(obj, list):
                        for it in obj:
                            if not video_url:
                                scan(it)

                scan(data)
        except Exception as e:
            self.log(f"  ⚠️ Quét trang iesdouyin: {e}")

        # 2. Nếu chưa ra link, thử qua API v2 iteminfo
        if not video_url:
            try:
                api_url = f"https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/?item_ids={video_id}"
                req = urllib.request.Request(api_url, headers=headers_mobile)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    resp_text = resp.read().decode("utf-8", errors="replace")
                    if resp_text.strip().startswith("{"):
                        api_data = json.loads(resp_text)
                        items = api_data.get("item_list") or []
                        if items:
                            it = items[0]
                            if it.get("desc"):
                                title = it.get("desc")
                            p_addr = it.get("video", {}).get("play_addr", {})
                            if p_addr.get("url_list"):
                                video_url = p_addr["url_list"][0]
                            m_addr = it.get("music", {}).get("play_url", {})
                            if m_addr.get("url_list"):
                                audio_url = m_addr["url_list"][0]
            except Exception as e:
                self.log(f"  ⚠️ Quét API v2: {e}")

        # 3. Quét trực tiếp link aweme play trong HTML nếu JSON bị thay đổi
        if not video_url and "html" in locals():
            m_play = re.search(r'https?://[^\s"\'<>]+(?:aweme/v1/play|douyinvod)[^\s"\'<>]+', html)
            if m_play:
                video_url = m_play.group(0).replace("&amp;", "&")

        if not video_url and not audio_url:
            self.log("  ❌ Không trích xuất được link stream video từ Douyin.")
            return False

        # Đổi playwm (watermark) thành play (không watermark)
        if video_url:
            video_url = video_url.replace("playwm", "play")

        target_url = audio_url if (mode == "mp3" and audio_url) else video_url
        ext = ".mp3" if (mode == "mp3" and audio_url) else ".mp4"

        clean_title = re.sub(r'[\\/*?:"<>|]', '_', title)[:120].strip() or f"douyin_{video_id}"
        out_dir = Path(dest_folder)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"{clean_title} [{video_id}]{ext}"

        if out_path.exists():
            k = 1
            while out_path.exists():
                out_path = out_dir / f"{clean_title} [{video_id}]_{k}{ext}"
                k += 1

        self.log(f"  📥 Bắt đầu tải video không logo: {out_path.name}")
        dl_headers = {
            "User-Agent": MOBILE_UA,
            "Referer": "https://www.douyin.com/",
        }

        dl_req = urllib.request.Request(target_url, headers=dl_headers)
        try:
            with urllib.request.urlopen(dl_req, timeout=35) as stream, open(out_path, "wb") as f_out:
                total_size = int(stream.headers.get("Content-Length") or 0)
                downloaded = 0
                chunk_size = 128 * 1024
                while True:
                    if self.stopped:
                        self.log("  ⏹ Đã dừng tải theo yêu cầu.")
                        f_out.close()
                        out_path.unlink(missing_ok=True)
                        return False
                    chunk = stream.read(chunk_size)
                    if not chunk:
                        break
                    f_out.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        pct = round(downloaded * 100.0 / total_size, 1)
                        self.prog = {
                            "pct": pct,
                            "text": f"{pct}% ({downloaded // (1024*1024)}MB / {total_size // (1024*1024)}MB) - {out_path.name}"
                        }

            # Nếu chọn mode MP3 mà tải file mp4 về, convert sang MP3
            if mode == "mp3" and out_path.suffix.lower() == ".mp4" and ff_path:
                mp3_path = out_path.with_suffix(".mp3")
                self.log(f"  🎵 Đang trích xuất MP3 qua FFmpeg: {mp3_path.name}")
                cmd = [ff_path, "-y", "-hide_banner", "-loglevel", "error", "-i", str(out_path), "-vn", "-c:a", "libmp3lame", "-q:a", "0", str(mp3_path)]
                subprocess.run(cmd, creationflags=NOWIN)
                if mp3_path.exists() and mp3_path.stat().st_size > 0:
                    try:
                        out_path.unlink()
                    except Exception:
                        pass
                    out_path = mp3_path

            file_size_mb = round(out_path.stat().st_size / (1024 * 1024), 2)
            self.log(f"  ✅ Tải thành công: {out_path.name} ({file_size_mb} MB)")
            self.prog = {"pct": 100, "text": f"Đã xong: {out_path.name}"}
            return True
        except Exception as e:
            self.log(f"  ❌ Lỗi trong quá trình tải: {e}")
            try:
                out_path.unlink(missing_ok=True)
            except Exception:
                pass
            return False

    def work(self, y, ff, urls, opts):
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        extra = [str(BIN_YTDLP.parent)] + ([str(DENO_DIR)] if DENO_DIR.is_dir() else [])
        env["PATH"] = os.pathsep.join(extra) + os.pathsep + env.get("PATH", "")
        ok = fail = 0
        total = len(urls)

        self.log(f"🚀 Bắt đầu tải {total} liên kết...")

        for i, raw_url in enumerate(urls, 1):
            if self.stopped:
                break

            url = resolve_short_url(raw_url)
            plat_id, icon, plat_name = detect_platform(url)

            self.log(f"\n=== [{i}/{total}] {icon} {plat_name}: {url}")
            if url != raw_url:
                self.log(f"    ➔ Đã giải mã link gốc: {url}")

            # Với Douyin, nếu người dùng không chọn cookie file/trình duyệt, ưu tiên bộ bóc tách trực tiếp iesdouyin trước
            if plat_id == "douyin" and opts.get("cookie_src") == "none":
                douyin_id = extract_douyin_video_id(url)
                if douyin_id:
                    self.log("[DOUYIN VIP] Kích hoạt bộ bóc tách link gốc Douyin không watermark...")
                    if self.download_douyin_direct(douyin_id, opts["folder"], opts["mode"], ff):
                        ok += 1
                        continue
                    else:
                        self.log("[CHUYỂN TIẾP] Thử tải qua yt-dlp...")

            cmd = self.build_cmd(y, ff, opts, url) + [url]
            code, err_kind = self.run_once(cmd, env)

            # Nếu yt-dlp thất bại với Douyin, thử lại lần 2 bằng bộ bóc tách trực tiếp
            if code != 0 and plat_id == "douyin" and not self.stopped:
                douyin_id = extract_douyin_video_id(url)
                if douyin_id:
                    self.log("[TỰ ĐỘNG BÙ] Douyin chặn yt-dlp (403/cookies) ➔ Kích hoạt bộ bóc tách link gốc iesdouyin...")
                    if self.download_douyin_direct(douyin_id, opts["folder"], opts["mode"], ff):
                        code = 0

            # Xử lý tự động khi YouTube bị chặn bot/429
            if code != 0 and plat_id == "youtube" and err_kind in ("bot_429", "403") and not self.stopped:
                for client_arg, label in BYPASS_STRATEGIES:
                    if self.stopped:
                        break
                    self.log(f"[TỰ SỬA] YouTube chặn IP/bot ({err_kind}) -> thử sang {label}...")
                    cmd_alt = self.build_cmd(y, ff, opts, url, player_client=client_arg) + [url]
                    code, err_kind = self.run_once(cmd_alt, env)
                    if code == 0:
                        break

            # Nếu vẫn lỗi -> thử cập nhật yt-dlp lên bản mới nhất rồi thử lại
            if code != 0 and err_kind in ("bot_429", "403", "extractor_error") and not self.stopped:
                self.log("[TỰ SỬA] Thử cập nhật yt-dlp lên bản mới nhất rồi thử lại...")
                self.update_ytdlp(y, env)
                if BIN_YTDLP.is_file():
                    y = str(BIN_YTDLP)
                cmd_u = self.build_cmd(y, ff, opts, url, player_client="tv,android_vr" if plat_id == "youtube" else None) + [url]
                code, err_kind = self.run_once(cmd_u, env)

            if code != 0:
                if plat_id == "youtube" and err_kind == "bot_429":
                    self.log(
                        "💡 [GỢI Ý YOUTUBE] IP mạng đang bị YouTube chặn (HTTP 429). "
                        "Hãy chọn mục 'Cookies' = Trình duyệt bạn đang đăng nhập YouTube (Edge/Chrome/Firefox) hoặc cookies.txt rồi bấm Tải lại."
                    )
                elif plat_id == "facebook":
                    self.log(
                        "💡 [GỢI Ý FACEBOOK] Nếu đây là video nhóm kín/riêng tư hoặc Facebook yêu cầu đăng nhập: "
                        "Hãy chọn mục 'Cookies' = Microsoft Edge hoặc Google Chrome (trình duyệt bạn đang đăng nhập Facebook) rồi bấm Tải lại."
                    )
                elif plat_id in ("douyin", "tiktok"):
                    self.log(
                        f"💡 [GỢI Ý {plat_name.upper()}] Nếu video bị giới hạn vùng hoặc tài khoản đặt chế độ riêng tư, "
                        "hãy chọn mục 'Cookies' = Microsoft Edge / Google Chrome (trình duyệt bạn đang mở Douyin/TikTok)."
                    )

            if code == 0:
                ok += 1
            else:
                fail += 1

        self.prog = {
            "pct": 100 if not fail and not self.stopped else self.prog["pct"],
            "text": "Đã dừng" if self.stopped else f"Hoàn tất ({ok}/{total})",
        }
        self.log(f"\n🎉 Xong: {ok} thành công, {fail} lỗi. Thư mục: {opts['folder']}")

    def run_once(self, cmd, env):
        err_kind = None
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env,
                                     creationflags=NOWIN)
        for raw in iter(self.proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").rstrip()
            m = PROG.search(line)
            if m:
                self.prog = {"pct": float(m.group(1)), "text": line.replace("[download]", "").strip()}
            elif line:
                self.log(line)
                low = line.lower()
                if any(k in low for k in ("429", "not a bot", "visitor data", "po token")):
                    err_kind = "bot_429"
                elif "403" in low or "forbidden" in low:
                    err_kind = "403"
                elif "extractorerror" in low or "unsupported url" in low or "unable to extract" in low:
                    err_kind = "extractor_error"
        return self.proc.wait(), err_kind

    def update_ytdlp(self, y, env):
        if not BIN_YTDLP.is_file():
            try:
                BIN_YTDLP.parent.mkdir(exist_ok=True)
                shutil.copyfile(y, BIN_YTDLP)
            except Exception as e:
                self.log(f"[LỖI] Không sao chép được yt-dlp: {e}")
                return
        r = subprocess.run([str(BIN_YTDLP), "-U"], capture_output=True, env=env, creationflags=NOWIN)
        txt = r.stdout.decode("utf-8", "replace").strip()
        self.log(txt.splitlines()[-1] if txt else "yt-dlp đã được cập nhật.")
