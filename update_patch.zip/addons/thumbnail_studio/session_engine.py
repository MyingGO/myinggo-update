# -*- coding: utf-8 -*-
"""
Persistent Hybrid Session Engine for Gemini/Flow workers.

Mục tiêu:
- Tách phiên đăng nhập khỏi vòng đời Selenium/WebDriver.
- Cache cookie + User-Agent + proxy theo profile/service.
- Tái sử dụng requests.Session cho các request nền (probe/download).
- Browser vẫn là bootstrap/fallback cho các thao tác DOM chưa có API adapter ổn định.

Không ghi mật khẩu. Bundle chỉ chứa cookie phiên và metadata cần cho HTTP session.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple
from urllib.parse import urlparse

import requests

BUNDLE_VERSION = 1
DEFAULT_TIMEOUT = 20
AUTH_COOKIE_HINTS = (
    "SID", "HSID", "SSID", "APISID", "SAPISID",
    "__Secure-1PSID", "__Secure-3PSID", "__Secure-1PAPISID", "__Secure-3PAPISID",
)


def _now() -> int:
    return int(time.time())


def _atomic_json_write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        os.replace(tmp, path)
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def normalize_proxy(proxy_value: str) -> str:
    """Chuyển proxy phổ biến sang URL requests. Hỗ trợ host:port[:user:pass] và scheme://..."""
    raw = str(proxy_value or "").strip()
    if not raw:
        return ""
    if "://" in raw:
        return raw
    parts = raw.split(":")
    if len(parts) >= 4:
        host, port = parts[0], parts[1]
        user = parts[2]
        password = ":".join(parts[3:])
        return f"http://{user}:{password}@{host}:{port}"
    if len(parts) == 2:
        return f"http://{parts[0]}:{parts[1]}"
    return "http://" + raw


def _cookie_is_live(cookie: dict, now: Optional[int] = None) -> bool:
    now = _now() if now is None else int(now)
    expiry = cookie.get("expiry")
    if expiry in (None, "", 0):
        return True
    try:
        return int(float(expiry)) > now + 30
    except Exception:
        return True


@dataclass
class ProbeResult:
    ok: bool
    status_code: int = 0
    final_url: str = ""
    elapsed_ms: int = 0
    reason: str = ""
    auth_cookie_count: int = 0


class SessionEngine:
    """Một session cache bền theo profile + service (gemini/flow)."""

    def __init__(self, profile_path: str | os.PathLike, service: str, base_url: str,
                 proxy_value: str = "", account_label: str = ""):
        self.profile_path = Path(profile_path)
        self.service = str(service or "google").strip().lower()
        self.base_url = str(base_url or "").strip()
        self.proxy_value = str(proxy_value or "").strip()
        self.account_label = str(account_label or self.profile_path.name)
        self.root = self.profile_path / ".session_engine"
        self.bundle_path = self.root / f"{self.service}.json"
        self._lock = threading.RLock()
        self._session: Optional[requests.Session] = None
        self._bundle: Dict[str, Any] = {}
        self._last_probe: Optional[ProbeResult] = None
        self.load()

    # ---------- bundle ----------
    def load(self) -> Dict[str, Any]:
        with self._lock:
            try:
                if self.bundle_path.is_file():
                    data = json.loads(self.bundle_path.read_text(encoding="utf-8"))
                    if isinstance(data, dict) and int(data.get("bundle_version", 0) or 0) == BUNDLE_VERSION:
                        self._bundle = data
                    else:
                        self._bundle = {}
                else:
                    self._bundle = {}
            except Exception:
                self._bundle = {}
            self._session = None
            return dict(self._bundle)

    def bundle_age_seconds(self) -> Optional[int]:
        try:
            return max(0, _now() - int(self._bundle.get("updated_at", 0) or 0))
        except Exception:
            return None

    def cookie_count(self, live_only: bool = True) -> int:
        cookies = self._bundle.get("cookies") or []
        if not live_only:
            return len(cookies)
        return sum(1 for c in cookies if isinstance(c, dict) and _cookie_is_live(c))

    def auth_cookie_count(self) -> int:
        count = 0
        for c in self._bundle.get("cookies") or []:
            if not isinstance(c, dict) or not _cookie_is_live(c):
                continue
            name = str(c.get("name") or "")
            if name in AUTH_COOKIE_HINTS or name.startswith("__Secure-") and "SID" in name:
                count += 1
        return count

    def has_usable_cache(self) -> bool:
        return bool(self.cookie_count(True) >= 2 and self.auth_cookie_count() >= 1)

    def status_line(self) -> str:
        age = self.bundle_age_seconds()
        age_text = "NONE" if age is None else f"{age}s"
        return (
            f"SESSION {'CACHED' if self.has_usable_cache() else 'EMPTY'} • service={self.service} • "
            f"cookies={self.cookie_count(True)} • authCookies={self.auth_cookie_count()} • age={age_text} • "
            f"proxy={'PINNED' if (self.proxy_value or self._bundle.get('proxy_value')) else 'DIRECT'}"
        )

    def export_from_driver(self, driver, referer: str = "", proxy_value: Optional[str] = None,
                           extra: Optional[dict] = None) -> Dict[str, Any]:
        """Snapshot cookie + UA từ browser đang login vào bundle bền."""
        cookies = []
        try:
            for c in driver.get_cookies() or []:
                if not isinstance(c, dict) or not c.get("name"):
                    continue
                item = {
                    "name": c.get("name"),
                    "value": c.get("value", ""),
                    "domain": c.get("domain", ""),
                    "path": c.get("path", "/"),
                    "expiry": c.get("expiry"),
                    "secure": bool(c.get("secure", False)),
                    "httpOnly": bool(c.get("httpOnly", False)),
                    "sameSite": c.get("sameSite"),
                }
                cookies.append(item)
        except Exception:
            cookies = []
        try:
            ua = str(driver.execute_script("return navigator.userAgent") or "Mozilla/5.0")
        except Exception:
            ua = str(self._bundle.get("user_agent") or "Mozilla/5.0")
        try:
            current_url = str(driver.current_url or "")
        except Exception:
            current_url = ""
        pxy = self.proxy_value if proxy_value is None else str(proxy_value or "")
        payload = {
            "bundle_version": BUNDLE_VERSION,
            "service": self.service,
            "account_label": self.account_label,
            "base_url": self.base_url,
            "referer": str(referer or current_url or self.base_url),
            "current_url": current_url,
            "user_agent": ua,
            "proxy_value": pxy,
            "cookies": cookies,
            "updated_at": _now(),
            "last_browser_refresh_at": _now(),
            "extra": dict(extra or {}),
        }
        with self._lock:
            _atomic_json_write(self.bundle_path, payload)
            self._bundle = payload
            self._session = None
        return dict(payload)

    def mark_probe(self, result: ProbeResult) -> None:
        with self._lock:
            self._last_probe = result
            if self._bundle:
                self._bundle["last_probe_at"] = _now()
                self._bundle["last_probe"] = {
                    "ok": bool(result.ok), "status_code": int(result.status_code or 0),
                    "final_url": result.final_url, "elapsed_ms": int(result.elapsed_ms or 0),
                    "reason": result.reason,
                }
                try:
                    _atomic_json_write(self.bundle_path, self._bundle)
                except Exception:
                    pass

    def invalidate(self, reason: str = "") -> None:
        with self._lock:
            if self._bundle:
                self._bundle["invalidated_at"] = _now()
                self._bundle["invalidated_reason"] = str(reason or "")[:500]
                try:
                    _atomic_json_write(self.bundle_path, self._bundle)
                except Exception:
                    pass
            self._session = None

    # ---------- HTTP transport ----------
    def build_requests_session(self, accept: str = "*/*", force_new: bool = False) -> requests.Session:
        with self._lock:
            if self._session is not None and not force_new:
                return self._session
            s = requests.Session()
            ua = str(self._bundle.get("user_agent") or "Mozilla/5.0")
            referer = str(self._bundle.get("referer") or self.base_url or "")
            s.headers.update({
                "User-Agent": ua,
                "Accept": accept,
                "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
                "Referer": referer,
            })
            for c in self._bundle.get("cookies") or []:
                if not isinstance(c, dict) or not c.get("name") or not _cookie_is_live(c):
                    continue
                kwargs = {}
                if c.get("domain"):
                    kwargs["domain"] = c.get("domain")
                if c.get("path"):
                    kwargs["path"] = c.get("path")
                try:
                    s.cookies.set(c.get("name"), c.get("value", ""), **kwargs)
                except Exception:
                    try:
                        s.cookies.set(c.get("name"), c.get("value", ""))
                    except Exception:
                        pass
            pxy = normalize_proxy(self.proxy_value or self._bundle.get("proxy_value") or "")
            if pxy:
                s.proxies.update({"http": pxy, "https": pxy})
            self._session = s
            return s

    def probe(self, url: str = "", timeout: int = DEFAULT_TIMEOUT) -> ProbeResult:
        target = str(url or self.base_url or "").strip()
        if not target:
            res = ProbeResult(False, reason="no probe url", auth_cookie_count=self.auth_cookie_count())
            self.mark_probe(res)
            return res
        if not self.has_usable_cache():
            res = ProbeResult(False, reason="no usable cached auth cookies", auth_cookie_count=self.auth_cookie_count())
            self.mark_probe(res)
            return res
        t0 = time.time()
        try:
            s = self.build_requests_session(force_new=True)
            r = s.get(target, timeout=max(5, int(timeout)), allow_redirects=True)
            elapsed = int((time.time() - t0) * 1000)
            final_url = str(r.url or "")
            # 2xx/3xx tới Google host + auth cookie bundle được coi là transport session còn dùng được.
            # Trạng thái login thật vẫn được browser verify ở bootstrap/fallback.
            host = (urlparse(final_url).hostname or "").lower()
            ok = 200 <= int(r.status_code) < 400 and ("google" in host or "youtube" in host or not host)
            res = ProbeResult(ok, int(r.status_code), final_url, elapsed,
                              "transport_ok" if ok else f"http_{r.status_code}", self.auth_cookie_count())
        except Exception as e:
            res = ProbeResult(False, elapsed_ms=int((time.time() - t0) * 1000),
                              reason=f"{type(e).__name__}: {str(e)[:240]}", auth_cookie_count=self.auth_cookie_count())
        self.mark_probe(res)
        return res

    def fetch_bytes(self, url: str, timeout: int = 90, referer: str = "") -> Tuple[bytes, requests.Response]:
        s = self.build_requests_session(
            accept="image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
        )
        headers = {"Referer": str(referer or self.base_url)} if (referer or self.base_url) else None
        r = s.get(url, headers=headers, timeout=max(5, int(timeout)), allow_redirects=True)
        r.raise_for_status()
        return r.content, r


def create_engine(profile_path, service, base_url, proxy_value="", account_label="") -> SessionEngine:
    return SessionEngine(profile_path, service, base_url, proxy_value=proxy_value, account_label=account_label)
