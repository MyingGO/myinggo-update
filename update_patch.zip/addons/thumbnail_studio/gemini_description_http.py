from __future__ import annotations

import base64
import ctypes
import hashlib
import json
import os
import re
import shutil
import sqlite3
import tempfile
import time
import uuid
from pathlib import Path
from typing import Dict, Iterable, Optional

import requests

GEMINI_APP_URL = "https://gemini.google.com/app"
GEMINI_STREAM_URL = "https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
MODEL_HEADER_NAME = "x-goog-ext-525001261-jspb"
MODEL_HEADERS = {
    "flash": '[1,null,null,null,"9ec249fc9ad08861",null,null,0,[4]]',
    "pro": '[1,null,null,null,"4af6c7f5da75d65d",null,null,0,[4]]',
    "gemini-2.5-flash": '[1,null,null,null,"9ec249fc9ad08861",null,null,0,[4]]',
    "gemini-2.5-pro": '[1,null,null,null,"4af6c7f5da75d65d",null,null,0,[4]]',
    "gemini-3-pro": '[1,null,null,null,"9d8ca3786ebdfbea",null,null,0,[4]]',
}
MODEL_MODE_IDS = {"flash": 1, "gemini-2.5-flash": 1, "pro": 3, "gemini-2.5-pro": 3, "gemini-3-pro": 3, "auto": 4}
REQUIRED_COOKIE_NAMES = ("__Secure-1PSID",)

DESCRIPTION_REWRITE_PROMPT = """Rewrite the ORIGINAL_DESCRIPTION below for a YouTube video.

CRITICAL LANGUAGE RULES:
- Detect the language from ORIGINAL_DESCRIPTION only.
- Return the rewritten description in exactly the same dominant language as ORIGINAL_DESCRIPTION.
- Never switch to Vietnamese unless the original itself is predominantly Vietnamese.
- If the original mixes languages, use the dominant language.

CONTENT RULES:
- Return only the rewritten description. No greeting, heading, explanation, markdown fence, or quotation marks.
- Make it clearer, more attractive, natural, and suitable for YouTube while preserving the core meaning.
- Remove channel names, brand names, website names, fan pages, competitor names, and private signatures.
- Remove URLs, email addresses, contact details, donation links, social links, subscription links, and channel links.
- Remove branded calls to action and branded copyright notices.
- Do not invent facts, links, contacts, channel names, or brand names.
- Generic copyright/usage notes, generic hashtags, music/visual descriptions, and entertainment-purpose notes may remain when relevant.
- Keep the result concise and clean; avoid repetitive keyword stuffing.

ORIGINAL_DESCRIPTION:
<<<START>>>
{description}
<<<END>>>

Return only the rewritten description now.
"""


def build_rewrite_prompt(text: str) -> str:
    return DESCRIPTION_REWRITE_PROMPT.format(description=str(text or "").strip())


def clean_response(text: str) -> str:
    t = str(text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not t:
        return ""
    # Strip accidental markdown fences / labels without touching the body.
    t = re.sub(r"^```(?:text|markdown)?\s*", "", t, flags=re.I).strip()
    t = re.sub(r"\s*```$", "", t).strip()
    t = re.sub(r"^(?:rewritten\s+description|description|mô\s*tả(?:\s*đã\s*viết\s*lại)?)\s*[:：-]\s*", "", t, flags=re.I).strip()
    t = re.sub(r"^here(?:'s| is)\s+(?:the\s+)?(?:rewritten\s+)?description\s*[:：-]?\s*", "", t, flags=re.I).strip()
    return t


def _dpapi_unprotect(blob: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("DPAPI cookie decrypt chỉ hỗ trợ Windows")

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", ctypes.c_uint), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

    data = bytes(blob or b"")
    if not data:
        return b""
    buf = ctypes.create_string_buffer(data, len(data))
    in_blob = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)))
    out_blob = DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
    )
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out_blob.pbData)


def _master_key(profile_root: Path) -> bytes:
    state = profile_root / "Local State"
    if not state.is_file():
        # Some Chromium layouts keep Local State one directory above Default/Profile N.
        if profile_root.name.lower() in ("default",) or profile_root.name.lower().startswith("profile "):
            state = profile_root.parent / "Local State"
    if not state.is_file():
        raise RuntimeError(f"Không tìm thấy Local State: {state}")
    raw = json.loads(state.read_text(encoding="utf-8", errors="ignore"))
    enc = ((raw.get("os_crypt") or {}).get("encrypted_key") or "").strip()
    if not enc:
        raise RuntimeError("Local State không có os_crypt.encrypted_key")
    key = base64.b64decode(enc)
    if key.startswith(b"DPAPI"):
        key = key[5:]
    return _dpapi_unprotect(key)


def _decrypt_cookie_value(encrypted: bytes, key: bytes, host_key: str = "") -> str:
    data = bytes(encrypted or b"")
    if not data:
        return ""
    if data.startswith(b"v20"):
        raise RuntimeError("Cookie Chrome dùng App-Bound Encryption v20; chưa thể đọc trực tiếp. Hãy dùng runtime/profile Chromium cũ của Thumbnail Studio hoặc đăng nhập lại bằng profile tương thích.")
    if data.startswith((b"v10", b"v11")):
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        except Exception as exc:
            raise RuntimeError("Thiếu cryptography để đọc cookie Chromium trực tiếp") from exc
        iv = data[3:15]
        ciphertext_and_tag = data[15:]
        plain = AESGCM(key).decrypt(iv, ciphertext_and_tag, None)
        # Chrome cookie DB v24+ prepends SHA256(host_key) to plaintext.
        digest = hashlib.sha256(str(host_key or "").encode("utf-8")).digest()
        if plain.startswith(digest):
            plain = plain[32:]
        return plain.decode("utf-8", errors="replace")
    return _dpapi_unprotect(data).decode("utf-8", errors="replace")


def _cookie_db(profile_root: Path) -> Path:
    candidates = [
        profile_root / "Default" / "Network" / "Cookies",
        profile_root / "Default" / "Cookies",
        profile_root / "Network" / "Cookies",
        profile_root / "Cookies",
    ]
    for p in candidates:
        if p.is_file():
            return p
    raise RuntimeError(f"Không tìm thấy Cookies DB trong {profile_root}")




def load_thumbnail_session_bundle(profile_root: str | os.PathLike):
    """Prefer Thumbnail Studio's own persistent Gemini session cache.

    This is the cleanest path for Description Studio: it reuses the exact cookies/UA
    already captured by Thumbnail Studio and does not start or control a browser.
    """
    root = Path(profile_root)
    bundle_path = root / ".session_engine" / "gemini.json"
    if not bundle_path.is_file():
        return {}, ""
    try:
        data = json.loads(bundle_path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return {}, ""
    cookies = {}
    now = int(time.time())
    for c in data.get("cookies") or []:
        if not isinstance(c, dict):
            continue
        name = str(c.get("name") or "").strip()
        value = str(c.get("value") or "")
        if not name or not value:
            continue
        expiry = c.get("expiry")
        try:
            if expiry not in (None, "", 0) and int(float(expiry)) <= now + 15:
                continue
        except Exception:
            pass
        cookies[name] = value
    if not all(cookies.get(x) for x in REQUIRED_COOKIE_NAMES):
        return {}, str(data.get("user_agent") or "")
    return cookies, str(data.get("user_agent") or "")

def load_google_cookies(profile_root: str | os.PathLike) -> Dict[str, str]:
    root = Path(profile_root)
    if not root.exists():
        raise RuntimeError(f"Profile không tồn tại: {root}")
    key = _master_key(root)
    db = _cookie_db(root)
    tmp_dir = Path(tempfile.mkdtemp(prefix="hd_desc_cookie_"))
    tmp_db = tmp_dir / "Cookies"
    try:
        shutil.copy2(db, tmp_db)
        conn = sqlite3.connect(str(tmp_db))
        try:
            cur = conn.cursor()
            cur.execute("SELECT host_key,name,value,encrypted_value FROM cookies WHERE host_key LIKE '%google.com%' OR host_key LIKE '%gemini.google.com%'")
            rows = cur.fetchall()
        finally:
            conn.close()
        cookies: Dict[str, str] = {}
        errors = []
        for host, name, value, encrypted in rows:
            name = str(name or "")
            if not name:
                continue
            val = str(value or "")
            if not val and encrypted:
                try:
                    val = _decrypt_cookie_value(encrypted, key, str(host or ""))
                except Exception as exc:
                    errors.append(f"{name}:{exc}")
                    continue
            if val:
                cookies[name] = val
        missing = [x for x in REQUIRED_COOKIE_NAMES if not cookies.get(x)]
        if missing:
            reason = f"Thiếu cookie Gemini: {', '.join(missing)}"
            if errors:
                reason += f" • decrypt lỗi: {errors[0][:180]}"
            raise RuntimeError(reason)
        return cookies
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def _nested(value, path: Iterable[int]):
    cur = value
    for idx in path:
        if not isinstance(cur, list) or idx >= len(cur):
            return None
        cur = cur[idx]
    return cur


def _candidate_text(parsed) -> str:
    candidates = _nested(parsed, [4])
    if not isinstance(candidates, list) or not candidates:
        return ""
    texts = []
    for cand in candidates:
        if not isinstance(cand, list):
            continue
        part = cand[1] if len(cand) > 1 else None
        if isinstance(part, list):
            texts.extend(x for x in part if isinstance(x, str) and x.strip())
        direct = _nested(cand, [1, 0])
        if isinstance(direct, str) and direct.strip():
            texts.append(direct)
        alt = _nested(cand, [22, 0])
        if isinstance(alt, str) and alt.strip():
            texts.append(alt)
    if not texts:
        return ""
    # Stream frames may contain progressively longer versions; longest is usually final.
    usable = [x for x in texts if not re.match(r"^http://googleusercontent\.com/card_content/\d+", x)] or texts
    return max(usable, key=len)


def parse_stream_response(raw: str) -> str:
    text = str(raw or "")
    latest = ""

    # Most current responses are line-delimited wrb.fr frames.
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("["):
            continue
        try:
            frame = json.loads(line)
        except Exception:
            continue
        frames = frame if isinstance(frame, list) else [frame]
        # A line is often [["wrb.fr",...,"<json>",...]]
        stack = list(frames) if isinstance(frames, list) else []
        while stack:
            item = stack.pop(0)
            if isinstance(item, list):
                if len(item) > 2 and isinstance(item[2], str):
                    try:
                        parsed = json.loads(item[2])
                        got = _candidate_text(parsed)
                        if got:
                            latest = got
                    except Exception:
                        pass
                stack.extend(x for x in item if isinstance(x, list))

    if latest:
        return latest

    # Fallback for a single JSON envelope.
    start = text.find("[")
    end = text.rfind("]")
    if start >= 0 and end > start:
        try:
            outer = json.loads(text[start:end + 1])
            stack = [outer]
            while stack:
                item = stack.pop(0)
                if isinstance(item, list):
                    if len(item) > 2 and isinstance(item[2], str):
                        try:
                            parsed = json.loads(item[2])
                            got = _candidate_text(parsed)
                            if got:
                                latest = got
                        except Exception:
                            pass
                    stack.extend(x for x in item if isinstance(x, list))
        except Exception:
            pass
    if not latest:
        raise RuntimeError("Gemini trả về nhưng không đọc được nội dung text")
    return latest


class GeminiProfileClient:
    def __init__(self, profile_root: str | os.PathLike, model: str = "auto", proxy: str = ""):
        self.profile_root = Path(profile_root)
        self.model = str(model or "auto").lower()
        self.proxy = str(proxy or "").strip()
        cached_cookies, cached_ua = load_thumbnail_session_bundle(self.profile_root)
        self.session_source = "thumbnail-session-cache" if cached_cookies else "chromium-cookie-db"
        self.cookies = cached_cookies or load_google_cookies(self.profile_root)
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": cached_ua or USER_AGENT,
            "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
        })
        for k, v in self.cookies.items():
            self.session.cookies.set(k, v, domain=".google.com")
        if self.proxy:
            p = self.proxy if "://" in self.proxy else "http://" + self.proxy
            self.session.proxies.update({"http": p, "https": p})
        self._access_token = ""
        self._access_token_at = 0.0
        self._build_label = ""
        self._reqid = int(time.time() * 1000) % 1000000

    def _fallback_cookie_db(self) -> bool:
        if self.session_source == "chromium-cookie-db":
            return False
        try:
            fresh = load_google_cookies(self.profile_root)
        except Exception:
            return False
        if not fresh:
            return False
        self.cookies = fresh
        self.session_source = "chromium-cookie-db"
        self.session.cookies.clear()
        for k, v in fresh.items():
            self.session.cookies.set(k, v, domain=".google.com")
        self._access_token = ""
        self._access_token_at = 0.0
        return True

    def _token(self, force=False) -> str:
        if self._access_token and not force and (time.time() - self._access_token_at) < 300:
            return self._access_token
        r = self.session.get(GEMINI_APP_URL, timeout=25, allow_redirects=True)
        if r.status_code >= 400:
            raise RuntimeError(f"Gemini auth page HTTP {r.status_code}")
        html = r.text
        bl = re.search(r'"cfb2h":"([^"]+)"', html) or re.search(r'(boq_assistant-bard-web-server_[0-9.]+_p[0-9]+)', html)
        if bl:
            self._build_label = bl.group(1)
        for key in ("SNlM0e", "thykhd"):
            m = re.search(rf'"{re.escape(key)}":"(.*?)"', html)
            if m and m.group(1):
                self._access_token = m.group(1)
                self._access_token_at = time.time()
                return self._access_token
        if self._fallback_cookie_db():
            return self._token(force=True)
        raise RuntimeError("Không lấy được token Gemini từ profile READY")

    def _modern_f_req(self, prompt: str) -> str:
        # Current Gemini Web StreamGenerate payload uses a fixed-position request array.
        inner = [None] * 80
        inner[0] = [str(prompt or ""), 0, None, None, None, None, 0]
        inner[1] = ["en"]
        inner[2] = ["", "", "", None, None, None, None, None, None, ""]
        inner[6] = [0]
        inner[7] = 1
        inner[10] = 1
        inner[11] = 0
        inner[17] = [[4]]
        inner[18] = 0
        inner[27] = 1
        inner[30] = [4]
        inner[41] = [2]
        inner[53] = 0
        inner[59] = str(uuid.uuid4())
        inner[61] = []
        inner[68] = 1
        inner[79] = MODEL_MODE_IDS.get(self.model, 4)
        return json.dumps([None, json.dumps(inner, ensure_ascii=False)], ensure_ascii=False)

    def generate(self, prompt: str, timeout: int = 120) -> str:
        at = self._token()
        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
            "Origin": "https://gemini.google.com",
            "Referer": "https://gemini.google.com/app",
            "X-Same-Domain": "1",
        }
        model_header = MODEL_HEADERS.get(self.model)
        if model_header:
            headers[MODEL_HEADER_NAME] = model_header
        sapisid = self.cookies.get("SAPISID") or self.cookies.get("__Secure-1PAPISID") or ""
        if sapisid:
            ts = int(time.time())
            digest = hashlib.sha1(f"{ts} {sapisid} https://gemini.google.com".encode()).hexdigest()
            headers["Authorization"] = f"SAPISIDHASH {ts}_{digest}"
        self._reqid += 100000
        params = {"hl": "en", "_reqid": str(self._reqid), "rt": "c"}
        if self._build_label:
            params["bl"] = self._build_label
        data = {"at": at, "f.req": self._modern_f_req(prompt)}

        def do_post():
            return self.session.post(
                GEMINI_STREAM_URL, params=params, headers=headers, data=data,
                timeout=max(30, int(timeout)),
            )

        r = None
        for attempt in range(3):
            r = do_post()
            if r.status_code in (401, 403, 405):
                # Refresh anti-CSRF token + deployment build label.
                at = self._token(force=True)
                data["at"] = at
                if self._build_label:
                    params["bl"] = self._build_label
                self._reqid += 100000
                params["_reqid"] = str(self._reqid)
                if attempt < 2:
                    continue
            if r.status_code == 429 or r.status_code >= 500:
                if attempt < 2:
                    time.sleep(1.4 * (attempt + 1))
                    continue
            break
        if r is None or r.status_code >= 400:
            raise RuntimeError(f"Gemini StreamGenerate HTTP {getattr(r, 'status_code', 0)}")
        if "BardErrorInfo" in r.text:
            m = re.search(r"BardErrorInfo\s*\[(\d+)\]", r.text)
            raise RuntimeError(f"Gemini upstream từ chối request{(' • code '+m.group(1)) if m else ''}")
        return clean_response(parse_stream_response(r.text))

    def rewrite_description(self, original: str, timeout: int = 120) -> str:
        result = self.generate(build_rewrite_prompt(original), timeout=timeout)
        if len(result.strip()) < 20:
            raise RuntimeError("Gemini trả mô tả quá ngắn")
        return result.strip()
