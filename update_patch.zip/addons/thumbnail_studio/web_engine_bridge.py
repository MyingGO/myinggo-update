from __future__ import annotations

import argparse
import json
import os
import queue
import re
import secrets
import signal
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

# This process keeps the original v13.54 Qt engine alive but never shows its native window.
# All business logic stays in the original dashboard/worker modules; 3T's web UI talks
# to this bridge through localhost JSON RPC. That avoids a risky rewrite of the worker engine.
BASE = Path(__file__).resolve().parent

def _thumb_persistent_root():
    """Persistent data lives OUTSIDE the install folder so replacing/updating 3T cannot wipe it."""
    raw = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
    root = Path(os.environ.get("THUMB_STUDIO_PERSIST_ROOT") or (Path(raw) / "HDMaster" / "ThumbnailStudio"))
    root.mkdir(parents=True, exist_ok=True)
    return root

PERSIST_ROOT = _thumb_persistent_root()
WEB_BRIDGE_BUILD = "v67-hd-full-rebrand-20260915"
PERSIST_LIVE_LOG = PERSIST_ROOT / "thumbnail_studio_live.log"
PERSIST_FATAL_LOG = PERSIST_ROOT / "thumbnail_studio_fatal.log"

# V20: crash diagnostics must survive a tool update and remain available even if the hidden
# Qt/Gemini engine dies before the Web drawer can refresh.  faulthandler also catches many
# native crashes that normal Python traceback logging cannot see.
try:
    import faulthandler as _faulthandler
    _fatal_stream = open(PERSIST_FATAL_LOG, "a", encoding="utf-8", buffering=1)
    _fatal_stream.write(f"\n===== V24 ENGINE BOOT {time.strftime('%Y-%m-%d %H:%M:%S')} pid={os.getpid()} =====\n")
    _faulthandler.enable(file=_fatal_stream, all_threads=True)
except Exception:
    _fatal_stream = None

def _persist_diag(line: str):
    try:
        PERSIST_ROOT.mkdir(parents=True, exist_ok=True)
        with PERSIST_LIVE_LOG.open("a", encoding="utf-8", errors="replace") as _f:
            _f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
    except Exception:
        pass

os.chdir(BASE)
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
os.environ.setdefault("GEMINI_VISIBLE_DEBUG", "0")
os.environ.setdefault("GEMINI_NO_MANUAL_LOGIN_POPUP", "1")
os.environ.setdefault("GEMINI_NPT_EXACT_9999", "0")
os.environ.setdefault("GEMINI_LOGIN_STABLE_OFFSCREEN", "1")
os.environ.setdefault("GEMINI_THUMB_HEADLESS", "1")
os.environ.setdefault("GEMINI_HEADLESS_BROWSER_UI", "1")
os.environ.setdefault("GEMINI_DISABLE_CHROME_BG_GUARD", "1")
os.environ.setdefault("GEMINI_FAST_REUSE_MODE", "1")
os.environ.setdefault("GEMINI_PROFILE_FAST_ASSUME_OK", "1")
os.environ.setdefault("GEMINI_VERIFY_MARKER_LOGIN", "0")
os.environ.setdefault("GEMINI_STRICT_SIGNIN_CHECK", "1")
os.environ.setdefault("GEMINI_FAST_READY_ONLY", "1")
os.environ["GEMINI_FAST_BOOTSTRAP_IF_NONE_READY"] = "0"
os.environ.setdefault("GEMINI_START_AS_SOON_AS_READY", "1")
os.environ["GEMINI_BACKGROUND_BOOTSTRAP_20"] = "0"
os.environ.setdefault("GEMINI_BACKGROUND_BOOTSTRAP_DELAY_SECONDS", "0")
os.environ.setdefault("GEMINI_FAST_REUSE_MAX_WORKERS", "8")
os.environ.setdefault("GEMINI_PROFILE_KEEP", "20")
os.environ.setdefault("GEMINI_MACHINE_POOL_LIMIT", "20")
os.environ.setdefault("GEMINI_PROFILE_REUSE_DAYS", "120")
os.environ.setdefault("GEMINI_ROTATE_POOL_PER_WORKER", "1")
os.environ.setdefault("GEMINI_POOL_LOGIN_PARALLEL", "3")
os.environ.setdefault("GEMINI_START_WAVE_SIZE", "8")
os.environ.setdefault("GEMINI_START_WAVE_DELAY_SECONDS", "0")
os.environ.setdefault("GEMINI_START_WAVE_INNER_STAGGER_SECONDS", "0")
os.environ.setdefault("GEMINI_WORKER_MINI_STAGGER_SECONDS", "0.05")
os.environ.setdefault("GEMINI_LOGIN_USE_PROXY", "0")
os.environ.setdefault("GEMINI_PROXY_SAFE_CHECK", "1")
os.environ.setdefault("GEMINI_PROXY_CHECK_TIMEOUT", "2.5")
os.environ.setdefault("GEMINI_PROXY_STRICT", "0")
os.environ.setdefault("GEMINI_EXTRA_CAPTURE_WAIT", "5")
os.environ.setdefault("GEMINI_UPLOAD_SERIAL_LOCK", "0")
os.environ.setdefault("GEMINI_UPLOAD_PREVIEW_TIMEOUT", "18")
os.environ.setdefault("GEMINI_UPLOAD_SETTLE_TIMEOUT", "6.5")
os.environ.setdefault("GEMINI_UPLOAD_SETTLE_ROUNDS", "6")
os.environ.setdefault("GEMINI_PRE_SEND_UPLOAD_CONFIRM_TIMEOUT", "12")
os.environ.setdefault("GEMINI_PRE_SEND_UPLOAD_SETTLE_TIMEOUT", "5.0")
os.environ.setdefault("GEMINI_WRITE_PROMPT_EDITOR_TIMEOUT", "24")
os.environ.setdefault("GEMINI_UPLOAD_MENU_TIMEOUT", "10")
os.environ.setdefault("GEMINI_AFTER_MENU_INPUT_TIMEOUT", "7")
os.environ.setdefault("GEMINI_REGULAR_DOM_INPUT_TIMEOUT", "12")
os.environ.setdefault("GEMINI_PRO_DOM_INPUT_TIMEOUT", "16")
os.environ.setdefault("GEMINI_AFTER_UPLOAD_ITEM_CLICK_WAIT", "0.45")
os.environ.setdefault("GEMINI_UPLOAD_LOCK_STALE_SECONDS", "45")
os.environ.setdefault("GEMINI_PROFILE_NEVER_PRUNE_MACHINE_POOL", "1")
os.environ.setdefault("GEMINI_PROFILE_SYNC_BACK_ALWAYS", "1")
os.environ.setdefault("GEMINI_TAIL_BOOST_READY_PROFILES", "1")
os.environ.setdefault("THUMBNAIL_WEB_MODE", "1")
os.environ["GEMINI_RUN_READY_ONLY_NO_LOGIN"] = "1"
# V23: Queue already receives only READY profiles from the warehouse. Do not open Gemini once
# merely to re-check login and then open it a second time for the first job. Worker starts Chrome
# headless immediately and the normal STEP 1 / open_new_chat performs the real sign-in assertion.
os.environ.setdefault("GEMINI_READY_PROFILE_FAST_START", "1")
os.environ.setdefault("GEMINI_PAGE_READY_SETTLE_SECONDS", "0.65")
os.environ.setdefault("GEMINI_FAST_PAGE_LOAD_STRATEGY", "eager")
os.environ.setdefault("GEMINI_WORKER_PROFILE_ALREADY_PREPARED", "1")

import hybrid_flow_gemini_dashboard as dashmod  # noqa: E402
import gemini_description_http as desc_http  # noqa: E402
from PySide6.QtCore import QObject, QTimer, Signal, Slot  # noqa: E402
from PySide6.QtWidgets import QApplication, QMessageBox  # noqa: E402

# Native message boxes are unusable when the engine has no visible window. Web UI performs
# confirmations itself, so convert them to log-only/non-blocking responses.
def _msg_noop(*args, **kwargs):
    try:
        text = args[2] if len(args) > 2 else (args[1] if len(args) > 1 else "")
        print("[WEB-MSG]", str(text).replace("\n", " | ")[:500], flush=True)
    except Exception:
        pass
    return QMessageBox.Ok


def _msg_yes(*args, **kwargs):
    _msg_noop(*args, **kwargs)
    return QMessageBox.Yes


QMessageBox.information = staticmethod(_msg_noop)
QMessageBox.warning = staticmethod(_msg_noop)
QMessageBox.critical = staticmethod(_msg_noop)
QMessageBox.question = staticmethod(_msg_yes)
# Disable native updater UI in web-engine mode. 3T owns the application shell.
dashmod.QtDashboard._setup_online_update = lambda self: None


def _safe_text(widget, default=""):
    try:
        return str(widget.text())
    except Exception:
        return str(default)


def _safe_plain(widget, default=""):
    try:
        return str(widget.toPlainText())
    except Exception:
        return str(default)


def _mtime(path: str) -> int:
    try:
        return int(Path(path).stat().st_mtime_ns)
    except Exception:
        return 0


def _size(path: str) -> int:
    try:
        return int(Path(path).stat().st_size)
    except Exception:
        return 0


def _parse_tab_account_warehouse(text: str, start_google: int = 1):
    """Parse the user's warehouse TXT exactly as: email<TAB>password<TAB>recovery_email.

    One non-empty valid line is exactly one account. We deliberately do not parse pipe, colon,
    google_N prefixes, or UI-state rows here, so a 250-line TXT can never become 500 accounts.
    """
    items = []
    invalid = []
    acc = int(start_google or 1)
    for line_no, raw in enumerate((text or "").splitlines(), 1):
        line = str(raw).rstrip("\r\n").lstrip("\ufeff")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        cols = line.split("\t")
        if len(cols) != 3:
            invalid.append({"line": line_no, "reason": f"expected_3_tab_columns_got_{len(cols)}"})
            continue
        email, password, recovery = (str(x or "").strip() for x in cols)
        if not email or "@" not in email or not password:
            invalid.append({"line": line_no, "reason": "missing_email_or_password"})
            continue
        items.append((acc, email, password, recovery))
        acc += 1
    return items, invalid


@dataclass
class Call:
    action: str
    args: dict
    done: threading.Event = field(default_factory=threading.Event)
    result: object = None
    error: str = ""


class Dispatcher(QObject):
    requested = Signal(object)
    login_result = Signal(object)

    def __init__(self, dashboard):
        super().__init__()
        self.dashboard = dashboard
        self.requested.connect(self._run)
        self.login_result.connect(self._on_web_login_result)
        # Web-only account warehouse gate. The original v13.54 login/check implementation
        # remains untouched; this coordinator only decides when Queue is allowed to start.
        self._prelogin_gate = {
            "running": False,
            "phase": "idle",
            "run_after": False,
            "total": 0,
            "ready": 0,
            "failed": 0,
            "message": "Chưa kiểm tra kho tài khoản",
            "started_at": 0.0,
            "saw_checking": False,
            "login_total": 0,
            "login_processed": 0,
            "login_success": 0,
            "login_failed": 0,
            "current_account": 0,
            "current_email": "",
        }
        self._web_login_queue = []
        self._web_login_busy = False
        self._web_login_active = 0
        try:
            self._web_login_parallel = max(1, min(3, int(os.environ.get("GEMINI_POOL_LOGIN_PARALLEL", "3") or 3)))
        except Exception:
            self._web_login_parallel = 3
        self._web_login_stop = threading.Event()
        self._login_guard_held = False
        self._queue_start_scheduled = False
        # V48 Description Studio: direct Gemini Web HTTP engine. It reuses the exact
        # Thumbnail Studio account vault + Chromium profiles, but never starts Selenium.
        self._desc_http_stop = threading.Event()
        self._desc_http_lock = threading.RLock()
        self._desc_http_run_id = 0
        # V23 account-load cache: login_vault is static during normal running, but V22 decrypted
        # every password several times per 1.6s snapshot. Cache canonical records by file mtime/size.
        self._vault_records_cache = None
        self._vault_records_cache_sig = None
        self._vault_records_cache_hits = 0
        self._profile_exists_cache = {}
        self._prelogin_timer = QTimer(self)
        self._prelogin_timer.setInterval(450)
        self._prelogin_timer.timeout.connect(self._poll_prelogin_gate)
        self._ready_state_signature_v53 = None
        self._ready_state_timer_v53 = QTimer(self)
        self._ready_state_timer_v53.setInterval(1200)
        self._ready_state_timer_v53.timeout.connect(lambda: self._persist_account_ready_state_v53(force=False))
        # V12 external restart/update safety: restore the last imported Web warehouse before any legacy-state repair.
        self._restore_persisted_vault_v10()
        # V14: queue roots/logo are persistent outside the install folder too.  Replacing the
        # 3T ZIP must never make the four Queue sources disappear.
        self._restore_queue_sources_v14()
        # v13.54 canonical warehouse: login_vault.json is the source of truth.
        # Web v1/v2 could accidentally inflate login_vault.json from the legacy 500-row UI state.
        # Before mirroring rows, repair that one-time contamination from the untouched v13.54 seed.
        # This never deletes Chrome profiles and never runs again after the V4 migration marker exists.
        self._repair_polluted_vault_once()
        self._prune_unusable_vault_records_v6()
        self._prune_empty_decrypted_credentials_v7()
        self._reconcile_rows_to_vault(save=True)
        self._restore_account_ready_state_v53()
        self._persist_vault_v10(reason="startup-bootstrap")
        self._ready_state_timer_v53.start()
        try:
            app = QApplication.instance()
            if app is not None:
                app.aboutToQuit.connect(lambda: self._persist_account_ready_state_v53(force=True))
        except Exception:
            pass

    @Slot(object)
    def _run(self, call: Call):
        try:
            call.result = self.execute(call.action, call.args or {})
        except BaseException as exc:
            call.error = f"{type(exc).__name__}: {exc}"
            try:
                self.dashboard.append_log(f"[web] {call.action} ERROR • {call.error}")
            except Exception:
                pass
            traceback.print_exc()
        finally:
            call.done.set()

    def invoke(self, action: str, args: dict | None = None, timeout: float = 45.0):
        call = Call(action=action, args=args or {})
        self.requested.emit(call)
        if not call.done.wait(max(0.2, float(timeout))):
            raise TimeoutError(f"RPC timeout: {action}")
        if call.error:
            raise RuntimeError(call.error)
        return call.result

    def _snapshot_jobs(self, limit=1200):
        d = self.dashboard
        jobs = list(getattr(d, "jobs", []) or [])
        out = []
        for j in jobs[: max(1, int(limit))]:
            path = str(j.get("image_path") or "")
            try:
                qidx = int(j.get("queue_index")) if str(j.get("queue_index", "")).lstrip("-").isdigit() else -1
            except Exception:
                qidx = -1
            try:
                size_mb = float(j.get("size_mb") or (_size(path) / (1024 * 1024) if path else 0.0))
            except Exception:
                size_mb = 0.0
            out.append({
                "path": path,
                "name": Path(path).name if path else "",
                "folder": str(j.get("direct_parent_root") or j.get("parent_root") or (Path(path).parent if path else "")),
                "folder_name": Path(path).parent.name if path else "",
                "status": str(j.get("status") or "queued"),
                "worker": str(j.get("worker") or ""),
                "note": str(j.get("note") or ""),
                "queue_index": qidx,
                "size_mb": round(size_mb, 3),
                "mtime": _mtime(path),
                "restorable": bool(path and d._job_thumb_jpg_from_job(j) is not None),
                "selected": bool(d._is_thumbnail_selected(j)),
            })
        return out

    def _warehouse_persist_path_v10(self):
        # Compatibility name retained for existing call sites. Since V12 this path is external
        # to the application install, so extracting a new ZIP over 3T cannot reset the vault.
        return PERSIST_ROOT / "account_warehouse_v12.json"

    def _legacy_warehouse_paths(self):
        return [BASE / "web_account_warehouse_v10.json", BASE / "login_vault.json"]

    def _queue_persist_path_v14(self):
        return PERSIST_ROOT / "queue_sources_v14.json"

    def _account_ready_state_path_v53(self):
        return PERSIST_ROOT / "account_ready_state_v53.json"

    def _persist_account_ready_state_v53(self, force=False):
        """Persist the visible READY/check state outside the install folder.

        The login vault already persists the account list/credentials.  This companion file
        preserves the last known account status so reopening 3T does not visually reset
        hundreds of accounts to an unknown state. Queue start still performs a fresh progressive
        check before assigning workers.
        """
        d = self.dashboard
        rows = self._row_map()
        payload_accounts = {}
        for acc, row in rows.items():
            try:
                status_text = _safe_text(getattr(row, "status", None), "")
            except Exception:
                status_text = ""
            try:
                email_text = _safe_text(getattr(row, "display_email", None), "")
                email_text = str(email_text or "").replace("Mail đang đăng nhập:", "").strip().strip("-")
            except Exception:
                email_text = ""
            payload_accounts[str(int(acc))] = {
                "ok": bool(getattr(row, "ok", False)),
                "status": status_text,
                "email": email_text,
            }
        signature = json.dumps(payload_accounts, ensure_ascii=False, sort_keys=True)
        if not force and signature == getattr(self, "_ready_state_signature_v53", None):
            return True
        payload = {
            "version": 53,
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "count": len(payload_accounts),
            "accounts": payload_accounts,
        }
        target = self._account_ready_state_path_v53()
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_suffix(target.suffix + ".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(str(tmp), str(target))
            self._ready_state_signature_v53 = signature
            return True
        except Exception as exc:
            try:
                d.append_log(f"[V53-READY-PERSIST] warning • {exc}")
            except Exception:
                pass
            return False

    def _restore_account_ready_state_v53(self):
        d = self.dashboard
        target = self._account_ready_state_path_v53()
        if not target.is_file():
            return 0
        try:
            raw = json.loads(target.read_text(encoding="utf-8-sig", errors="ignore") or "{}")
            saved = dict(raw.get("accounts") or {})
        except Exception as exc:
            try:
                d.append_log(f"[V53-READY-PERSIST] load warning • {exc}")
            except Exception:
                pass
            return 0
        rows = self._row_map()
        restored = 0
        profiles_root = Path(getattr(d, "backend_dir", BASE)) / "profiles"
        for key, rec in saved.items():
            try:
                acc = int(key)
            except Exception:
                continue
            row = rows.get(acc)
            if row is None:
                continue
            rec = dict(rec or {})
            ok = bool(rec.get("ok"))
            if ok and not self._profile_exists_v23(profiles_root, acc):
                ok = False
            try:
                if ok and d._force_login_marker_path_for_account(acc).is_file():
                    ok = False
            except Exception:
                pass
            msg = str(rec.get("status") or ("READY • trạng thái đã lưu" if ok else "Chưa kiểm tra")).strip()
            msg = re.sub(r"^[✅⚠]\s*", "", msg).strip()
            email = str(rec.get("email") or "").strip()
            try:
                row.set_status(ok, msg or ("READY • trạng thái đã lưu" if ok else "Chưa kiểm tra"), email)
                restored += 1
            except Exception:
                pass
        try:
            d.append_log(f"[V53-READY-PERSIST] RESTORE • {restored}/{len(rows)} trạng thái tài khoản • Queue vẫn fresh-check khi bấm Chạy")
        except Exception:
            pass
        self._persist_account_ready_state_v53(force=True)
        return restored

    def _queue_sources_v14(self):
        d = self.dashboard
        try:
            d._ensure_project_queue_slots()
        except Exception:
            pass
        out = []
        for idx in range(5):
            try:
                q = (list(getattr(d, "project_queue", []) or []) + [{}] * 5)[idx] or {}
            except Exception:
                q = {}
            out.append({
                "index": idx,
                "root": str(q.get("root") or ""),
                "logo": str(q.get("logo") or ""),
            })
        return out

    def _persist_queue_sources_v14(self, reason="update"):
        d = self.dashboard
        try:
            payload = {
                "version": 14,
                "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "reason": str(reason or "update"),
                "queues": self._queue_sources_v14(),
            }
            target = self._queue_persist_path_v14()
            tmp = target.with_suffix(target.suffix + ".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(str(tmp), str(target))
            return True
        except Exception as exc:
            try:
                d.append_log(f"[web-queue-persist] save warning: {exc}")
            except Exception:
                pass
            return False

    def _restore_queue_sources_v14(self):
        d = self.dashboard
        target = self._queue_persist_path_v14()
        try:
            current = self._queue_sources_v14()
            if target.is_file():
                raw = json.loads(target.read_text(encoding="utf-8"))
                saved = list(raw.get("queues") or [])[:5]
                saved += [{}] * max(0, 5 - len(saved))
                # External queue store is authoritative once it exists.
                for idx in range(5):
                    q = saved[idx] or {}
                    d.add_project_queue_item_to_slot(
                        idx, str(q.get("root") or ""), str(q.get("logo") or ""), status="chờ"
                    )
                try:
                    d.save_state()
                except Exception:
                    pass
                try:
                    d.append_log(f"[web-queue-persist] RESTORE OK • {sum(1 for q in saved if str((q or {}).get('root') or '').strip())}/5 nguồn")
                except Exception:
                    pass
                return True
            # First V14 run: migrate the queue sources already present in the old desktop state.
            if any(str((q or {}).get("root") or "").strip() for q in current):
                self._persist_queue_sources_v14(reason="first-v14-migration")
                try:
                    d.append_log(f"[web-queue-persist] MIGRATE OK • {sum(1 for q in current if str((q or {}).get('root') or '').strip())}/5 nguồn")
                except Exception:
                    pass
            return True
        except Exception as exc:
            try:
                d.append_log(f"[web-queue-persist] restore warning: {exc}")
            except Exception:
                pass
            return False

    def _post_import_reconcile_v14(self, imported=0):
        d = self.dashboard
        try:
            d.append_log(f"[web-account-warehouse] POST-SYNC START • target={int(imported or 0)}")
        except Exception:
            pass
        try:
            self._reconcile_rows_to_vault(save=True)
            for row in list(getattr(d, "rows", []) or []):
                try:
                    row.ok = False
                    row.status.setText("Chưa đăng nhập")
                except Exception:
                    pass
            try:
                d.save_state()
            except Exception:
                pass
            try:
                d.append_log(f"[web-account-warehouse] POST-SYNC DONE • ui_rows={len(getattr(d, 'rows', []) or [])}")
            except Exception:
                pass
        except Exception as exc:
            try:
                d.append_log(f"[web-account-warehouse] POST-SYNC ERROR • {type(exc).__name__}: {exc}")
            except Exception:
                pass

    def _persist_vault_v10(self, vault=None, reason="update"):
        """Durable Web warehouse mirror so imported TXT survives a full tool restart.

        The password values remain the same DPAPI-protected objects already used by v13.54;
        this file never stores plaintext passwords. login_vault.json remains the runtime source,
        while this mirror is only a restart-safety copy managed by Thumbnail Studio Web.
        """
        d = self.dashboard
        try:
            if vault is None:
                vault = d._load_login_vault() or {"version": 1, "accounts": {}}
            accounts = dict((vault or {}).get("accounts") or {})
            payload = {
                "version": 12,
                "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "reason": str(reason or "update"),
                "count": len(accounts),
                "vault": {"version": int((vault or {}).get("version") or 1), "accounts": accounts},
            }
            target = self._warehouse_persist_path_v10()
            tmp = target.with_suffix(target.suffix + ".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(str(tmp), str(target))
            return True
        except Exception as exc:
            try:
                d.append_log(f"[web-account-warehouse] V12 PERSIST warning: {exc}")
            except Exception:
                pass
            return False

    def _restore_persisted_vault_v10(self):
        """V12 durable restore/migration.

        External PERSIST_ROOT is authoritative once created. On the first V12 run we migrate the
        best existing in-install vault/mirror into that external store. This is what makes
        "extract/overwrite tool" safe for the account warehouse.
        """
        d = self.dashboard
        target = self._warehouse_persist_path_v10()

        def _extract_payload(path: Path):
            try:
                if not path.is_file():
                    return None
                raw = json.loads(path.read_text(encoding="utf-8"))
                vault = dict(raw.get("vault") or raw)
                accounts = dict(vault.get("accounts") or {})
                valid = {}
                for key, rec in accounts.items():
                    if not re.fullmatch(r"google_\d+", str(key), re.I):
                        continue
                    rec = dict(rec or {})
                    email = str(rec.get("email") or "").strip()
                    if not email or not rec.get("password"):
                        continue
                    valid[str(key)] = rec
                if not valid:
                    return None
                return {"version": int(vault.get("version") or 1), "accounts": valid}
            except Exception:
                return None

        try:
            external = _extract_payload(target)
            if external:
                live = d._load_login_vault() or {"version": 1, "accounts": {}}
                if json.dumps(live, sort_keys=True, ensure_ascii=False) != json.dumps(external, sort_keys=True, ensure_ascii=False):
                    if not d._save_login_vault(external):
                        raise RuntimeError("Không khôi phục được login_vault.json từ kho ngoài thư mục cài đặt")
                try:
                    d.append_log(f"[web-account-warehouse] V12 EXTERNAL RESTORE • {len(external['accounts'])} tài khoản • {target}")
                except Exception:
                    pass
                return True

            # First V12 run: migrate the largest valid existing source BEFORE any legacy repair.
            candidates = []
            for source in self._legacy_warehouse_paths():
                vault = _extract_payload(source)
                if vault:
                    candidates.append((len(vault.get("accounts") or {}), source, vault))
            if candidates:
                _count, source, best = max(candidates, key=lambda x: x[0])
                if not d._save_login_vault(best):
                    raise RuntimeError("Không thể chuẩn hóa login_vault.json trong lần migrate V12")
                self._persist_vault_v10(best, reason=f"v12-migrate:{source.name}")
                try:
                    d.append_log(f"[web-account-warehouse] V12 MIGRATE OUTSIDE INSTALL • {_count} tài khoản • {source.name} → {target}")
                except Exception:
                    pass
                return True
            return False
        except Exception as exc:
            try:
                d.append_log(f"[web-account-warehouse] V12 RESTORE warning: {exc}")
            except Exception:
                pass
            return False

    def _repair_polluted_vault_once(self):
        """One-time recovery for the old Web warehouse inflation bug.

        The original v13.54 package supplied by the user contains 225 real DPAPI credentials
        (google_3..google_227) while the legacy Qt state contains 500 UI placeholder rows.
        Earlier Web builds could turn those placeholders into vault records with no password.
        V4 detects only that contamination pattern, backs it up, and restores/prunes credentials.
        A marker prevents this migration from touching future legitimate TXT imports.
        """
        d = self.dashboard
        marker = BASE / ".vault_web_v4_migrated.json"
        seed_path = BASE / "login_vault_seed_v13_54_original.json"
        live_path = BASE / "login_vault.json"
        if marker.exists():
            return
        report = {"version": 4, "at": time.strftime("%Y-%m-%d %H:%M:%S"), "restored": False}
        try:
            live = d._load_login_vault() or {"version": 1, "accounts": {}}
            seed = json.loads(seed_path.read_text(encoding="utf-8")) if seed_path.exists() else {"version": 1, "accounts": {}}
            la = dict(live.get("accounts") or {})
            sa = dict(seed.get("accounts") or {})
            def credentialed(items):
                return {k:v for k,v in items.items() if str((v or {}).get("email") or "").strip() and (v or {}).get("password")}
            lc = credentialed(la)
            sc = credentialed(sa)
            live_n, seed_n, cred_n = len(la), len(sa), len(lc)
            report.update({"live_before": live_n, "live_credentials_before": cred_n, "seed": seed_n})
            # Strong signature of the broken builds: inflated vault (typically 500) and a
            # large tail of rows that exists only in the legacy UI state. Those UI rows never
            # stored passwords. Use both total credential coverage and tail coverage so a
            # future legitimate large warehouse is never truncated.
            tail_keys = [k for k in la if k not in sa]
            tail_missing = sum(1 for k in tail_keys if not (la.get(k) or {}).get("password"))
            tail_bad_ratio = (tail_missing / len(tail_keys)) if tail_keys else 0.0
            suspicious = bool(seed_n and live_n > seed_n and (
                cred_n < max(seed_n, int(live_n * 0.60)) or
                (len(tail_keys) >= 100 and tail_bad_ratio >= 0.90)
            ))
            report.update({"tail_rows": len(tail_keys), "tail_missing_password": tail_missing})
            if suspicious:
                backup = BASE / f"login_vault.before_web_v4_fix_{time.strftime('%Y%m%d_%H%M%S')}.json"
                try:
                    backup.write_text(json.dumps(live, ensure_ascii=False, indent=2), encoding="utf-8")
                    report["backup"] = backup.name
                except Exception:
                    pass
                # If the real credentialed subset is still complete, preserve it and only
                # remove password-less placeholders. Otherwise restore the untouched seed.
                if len(lc) >= seed_n:
                    fixed = {"version": int(live.get("version") or 1), "accounts": lc}
                    mode = "prune-passwordless-placeholders"
                else:
                    fixed = seed
                    mode = "restore-original-v13.54-seed"
                if not d._save_login_vault(fixed):
                    raise RuntimeError("Không lưu được login_vault.json sau khi sửa kho ảo")
                report.update({"restored": True, "mode": mode, "live_after": len(fixed.get("accounts") or {})})
                try:
                    d.append_log(f"[web-account-warehouse] V4 FIX • {live_n} dòng ảo → {report['live_after']} tài khoản thật • mode={mode} • Chrome profiles giữ nguyên")
                except Exception:
                    pass
            else:
                report["live_after"] = live_n
                report["mode"] = "no-change"
            marker.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            report["error"] = str(exc)
            # Do not create the success marker on failure; the next engine start may retry.
            try:
                (BASE / ".vault_web_v4_migration_failed.json").write_text(
                    json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
                )
            except Exception:
                pass
            try:
                d.append_log(f"[web-account-warehouse] V4 migration warning: {exc}")
            except Exception:
                pass

    def _prune_unusable_vault_records_v6(self):
        """V6 safety repair: remove email-only placeholder records from the live vault.

        Old Web builds could persist legacy 500-row UI placeholders into login_vault.json.
        A record without a stored password cannot be logged in by the original v13.54 engine,
        so it is not a usable warehouse account. We back up once, prune only those unusable
        rows, keep every credentialed account (including legitimate future imports), and never
        touch Chrome profiles. A new V6 marker intentionally ignores the older V4 marker.
        """
        d = self.dashboard
        marker = BASE / ".vault_web_v6_pruned.json"
        if marker.exists():
            return
        report = {"version": 6, "at": time.strftime("%Y-%m-%d %H:%M:%S"), "changed": False}
        try:
            vault = d._load_login_vault() or {"version": 1, "accounts": {}}
            accounts = dict(vault.get("accounts") or {})
            valid, removed = {}, []
            for key, rec in accounts.items():
                rec = rec or {}
                email = str(rec.get("email") or "").strip()
                password = rec.get("password")
                if email and password:
                    valid[key] = rec
                else:
                    removed.append(key)
            report.update({"before": len(accounts), "after": len(valid), "removed": len(removed)})
            if removed:
                backup = BASE / f"login_vault.before_web_v6_prune_{time.strftime('%Y%m%d_%H%M%S')}.json"
                try:
                    backup.write_text(json.dumps(vault, ensure_ascii=False, indent=2), encoding="utf-8")
                    report["backup"] = backup.name
                except Exception:
                    pass
                fixed = {"version": int(vault.get("version") or 1), "accounts": valid}
                if not d._save_login_vault(fixed):
                    raise RuntimeError("Không lưu được login_vault.json sau khi loại tài khoản ảo")
                report["changed"] = True
                try:
                    d.append_log(f"[web-account-warehouse] V6 PRUNE • {len(accounts)} → {len(valid)} tài khoản dùng được • removed={len(removed)} • Chrome profiles giữ nguyên")
                except Exception:
                    pass
            marker.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            report["error"] = str(exc)
            try:
                (BASE / ".vault_web_v6_prune_failed.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

    def _prune_empty_decrypted_credentials_v7(self):
        """V7 repair for the remaining 500-account contamination case.

        Some old Web builds encrypted an EMPTY password into a non-empty DPAPI object.
        Checking only ``bool(rec["password"])`` therefore treated those placeholder rows as
        real accounts. On Windows the original v13.54 ``_get_login_credential`` decrypts that
        object back to an empty string. V7 uses the decrypted value, backs up the vault, and
        removes only rows that cannot produce both a real email and a non-empty decrypted
        password. Chrome profile folders are never deleted.
        """
        d = self.dashboard
        try:
            vault = d._load_login_vault() or {"version": 1, "accounts": {}}
            accounts = dict(vault.get("accounts") or {})
            if not accounts:
                return
            valid, removed = {}, []
            for key, rec in accounts.items():
                m = re.fullmatch(r"google_(\d+)", str(key).strip(), re.I)
                if not m:
                    removed.append(key)
                    continue
                acc = int(m.group(1))
                try:
                    email, password, _recovery = d._get_login_credential(acc)
                except Exception:
                    email = str((rec or {}).get("email") or "").strip()
                    password = ""
                if str(email or "").strip() and str(password or "").strip():
                    valid[key] = rec
                else:
                    removed.append(key)
            if not removed:
                return
            backup = BASE / f"login_vault.before_web_v7_decrypted_prune_{time.strftime('%Y%m%d_%H%M%S')}.json"
            try:
                backup.write_text(json.dumps(vault, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
            fixed = {"version": int(vault.get("version") or 1), "accounts": valid}
            if not d._save_login_vault(fixed):
                raise RuntimeError("Không lưu được login_vault.json sau V7 decrypted prune")
            try:
                d.append_log(
                    f"[web-account-warehouse] V7 DECRYPTED PRUNE • {len(accounts)} → {len(valid)} tài khoản có mật khẩu thật "
                    f"• removed={len(removed)} • Chrome profiles giữ nguyên"
                )
            except Exception:
                pass
        except Exception as exc:
            try:
                d.append_log(f"[web-account-warehouse] V7 decrypted prune warning: {exc}")
            except Exception:
                pass

    def _invalidate_vault_records_cache(self, reason=""):
        self._vault_records_cache = None
        self._vault_records_cache_sig = None
        self._profile_exists_cache = {}
        if reason:
            try:
                self.dashboard.append_log(f"[V23-ACCOUNT-CACHE] invalidate • {reason}")
            except Exception:
                pass

    def _vault_signature_v23(self):
        try:
            p = BASE / "login_vault.json"
            st = p.stat()
            return (int(st.st_mtime_ns), int(st.st_size))
        except Exception:
            return None

    def _vault_records(self):
        """Return canonical account records, cached until login_vault.json actually changes.

        V22 called this from accounts snapshot + prelogin snapshot + persisted-count, causing
        252 DPAPI decrypts multiple times on every poll. V23 decrypts once per vault revision.
        """
        d = self.dashboard
        sig = self._vault_signature_v23()
        if self._vault_records_cache is not None and sig == self._vault_records_cache_sig:
            self._vault_records_cache_hits += 1
            return self._vault_records_cache
        t0 = time.perf_counter()
        try:
            vault = d._load_login_vault() or {}
        except Exception:
            vault = {}
        out = []
        for key, rec in (vault.get("accounts") or {}).items():
            m = re.fullmatch(r"google_(\d+)", str(key).strip(), re.I)
            if not m:
                continue
            rec = rec or {}
            acc = int(m.group(1))
            try:
                email, decrypted_password, recovery_email = d._get_login_credential(acc)
            except Exception:
                email = str(rec.get("email") or "").strip()
                decrypted_password = ""
                recovery_email = str(rec.get("recovery_email") or rec.get("recovery") or rec.get("backup_email") or "").strip()
            email = str(email or "").strip()
            decrypted_password = str(decrypted_password or "").strip()
            if not email or not decrypted_password:
                continue
            out.append({
                "account_no": acc,
                "email": email,
                "has_credentials": True,
                "recovery_email": str(recovery_email or "").strip(),
                "imported_at": str(rec.get("imported_at") or ""),
            })
        out.sort(key=lambda x: int(x["account_no"]))
        self._vault_records_cache = out
        self._vault_records_cache_sig = sig
        try:
            ms=(time.perf_counter()-t0)*1000.0
            d.append_log(f"[V23-ACCOUNT-CACHE] vault warm • {len(out)} account • decrypt once={ms:.0f}ms • các snapshot sau dùng RAM cache")
        except Exception:
            pass
        return out

    def _row_map(self):
        out = {}
        for row in list(getattr(self.dashboard, "rows", []) or []):
            try:
                out[int(row.account_no())] = row
            except Exception:
                pass
        return out

    def _reconcile_rows_to_vault(self, save=False):
        """Mirror hidden Qt rows to the real login vault without touching Chrome profiles.

        This fixes the legacy-state inflation bug: old state files can contain google_228..
        google_502 placeholders even though the v13.54 vault only contains google_3..227.
        """
        d = self.dashboard
        records = self._vault_records()
        wanted = {int(x["account_no"]): x for x in records}
        old_suspend = bool(getattr(d, "_suspend_state_save", False))
        try:
            d._suspend_state_save = True
            for row in list(getattr(d, "rows", []) or []):
                try:
                    acc = int(row.account_no())
                except Exception:
                    acc = -1
                if acc not in wanted:
                    d.remove_account_row(row)
            rows = self._row_map()
            for acc, rec in wanted.items():
                row = rows.get(acc)
                if row is None:
                    row = d.add_account_row(account_no=acc, display_email=rec["email"])
                    rows[acc] = row
                try:
                    row.email_edit.setText(rec["email"])
                    row.pass_edit.setText("")
                    # Keep live check/login status, but keep the visible email canonical.
                    row.display_email.setText(f"Mail đang đăng nhập: {rec['email']}")
                except Exception:
                    pass
            try:
                d.reindex_rows(save=False)
            except Exception:
                pass
        finally:
            d._suspend_state_save = old_suspend
        if save:
            try:
                d.save_state()
            except Exception:
                pass
        try:
            d.append_log(f"[web-account-warehouse] canonical vault sync • vault={len(records)} • ui_rows={len(getattr(d, 'rows', []) or [])} • stale_rows_removed=YES")
        except Exception:
            pass
        return records

    def _profile_exists_v23(self, profiles_root, acc):
        now = time.monotonic()
        cached = self._profile_exists_cache.get(int(acc))
        if cached and (now - float(cached[0])) < 4.0:
            return bool(cached[1])
        exists = bool((profiles_root / f"google_{int(acc)}").exists())
        self._profile_exists_cache[int(acc)] = (now, exists)
        return exists

    def _snapshot_accounts(self):
        d = self.dashboard
        records = self._vault_records()
        rows = self._row_map()
        out = []
        held = set()
        try:
            held = set(d._daily_quota_held_accounts())
        except Exception:
            pass
        checking_set = set(getattr(d, "_checking_account_nos", set()) or set())
        profiles_root = Path(getattr(d, "backend_dir", BASE)) / "profiles"
        for idx, rec in enumerate(records, 1):
            acc = int(rec["account_no"])
            row = rows.get(acc)
            ok = bool(getattr(row, "ok", False)) if row is not None else False
            status = _safe_text(getattr(row, "status", None), "Chưa kiểm tra") if row is not None else "Chưa kiểm tra"
            out.append({
                "index": idx,
                "account_no": acc,
                "ok": ok,
                "status": status,
                "email": rec["email"],
                "quota_hold": acc in held,
                "checking": acc in checking_set,
                "check_result": (getattr(d, "_web_check_results", {}) or {}).get(acc) or ("ok" if ok else ""),
                "has_credentials": bool(rec.get("has_credentials")),
                "has_recovery": bool(rec.get("recovery_email")),
                "profile_exists": self._profile_exists_v23(profiles_root, acc),
                "imported_at": rec.get("imported_at") or "",
            })
        return out

    def _prelogin_snapshot(self):
        gate = dict(self._prelogin_gate or {})
        records = self._vault_records()
        rows = self._row_map()
        total = len(records)
        ready = sum(1 for rec in records if bool(getattr(rows.get(int(rec["account_no"])), "ok", False)))
        gate["total"] = total
        gate["ready"] = ready
        if not gate.get("running") and total and ready == total and gate.get("phase") not in ("running_queue",):
            gate["phase"] = "ready"
            gate["message"] = f"Kho tài khoản READY {ready}/{total}"
        return gate

    def _account_gate_rows(self):
        # Always gate against the exact vault, never against stale desktop state rows.
        records = self._reconcile_rows_to_vault(save=False)
        rows_by_no = self._row_map()
        rows = []
        missing = []
        for rec in records:
            acc = int(rec["account_no"])
            row = rows_by_no.get(acc)
            if row is not None:
                rows.append(row)
            if not rec.get("has_credentials"):
                missing.append(acc)
        return rows, missing

    def _cancel_prelogin_gate(self, message="Đã dừng chuẩn bị kho tài khoản"):
        try:
            self._web_login_stop.set()
        except Exception:
            pass
        try:
            ev = getattr(self.dashboard, "_login_all_stop_event", None)
            if ev is not None:
                ev.set()
        except Exception:
            pass
        try:
            ev = getattr(self.dashboard, "_check_stop_event", None)
            if ev is not None:
                ev.set()
        except Exception:
            pass
        self._web_login_queue = []
        self._web_login_busy = False
        self._web_login_active = 0
        try:
            if getattr(self, "_login_guard_held", False):
                self.dashboard._release_chrome_background_guard(grace=0.2)
                self._login_guard_held = False
        except Exception:
            self._login_guard_held = False
        self._prelogin_timer.stop()
        self._prelogin_gate.update({
            "running": False, "phase": "idle", "run_after": False,
            "current_account": 0, "current_email": "", "message": str(message)
        })

    def _resolve_login_runtime(self):
        """Resolve Chrome and let Selenium Manager supply chromedriver when the bundled driver is absent."""
        d = self.dashboard
        try:
            chrome = Path(getattr(d, "chrome_binary", "") or "")
        except Exception:
            chrome = Path("__missing_chrome__")
        if not chrome.is_file():
            try:
                chrome = Path(dashmod._auto_detect_npt_chromium_binary())
                d.chrome_binary = chrome
            except Exception:
                pass
        try:
            driver = Path(getattr(d, "driver_binary", "") or "")
        except Exception:
            driver = Path("__missing_driver__")
        if not chrome.is_file():
            raise RuntimeError(
                "Không tìm thấy Chrome/Chromium để đăng nhập tự động. "
                f"Đường dẫn hiện tại: {chrome}. Cài Google Chrome hoặc đặt GEMINI_CHROME_BINARY."
            )
        mode = "local-driver" if driver.is_file() else "selenium-manager"
        return chrome, driver, mode

    def _start_web_login_all(self):
        """Web-mode login-all with visible progress. Reuses the original v13.54 Selenium login helper."""
        d = self.dashboard
        chrome, driver, mode = self._resolve_login_runtime()
        # V17: DO NOT install the dashboard-wide WinEvent Chrome guard in Web mode.
        # 3T itself may be hosted by the same installed Chrome binary; the old guard
        # could mistake the main tool window for an automation window and move it off-screen,
        # causing the whole UI to blink/disappear and become unclickable. Login Chrome is
        # already started hidden=True and is managed by its own ChromeDriver process only.
        self._login_guard_held = False
        d.append_log("[web-login-all] V17 global Chrome guard=OFF • hidden login is PID-scoped • main 3T window protected")
        rows, missing = self._account_gate_rows()
        if missing:
            raise RuntimeError(f"Có {len(missing)} tài khoản thiếu credential trong Vault")
        targets = []
        for row in rows:
            try:
                acc = int(row.account_no())
                email, password, recovery = d._get_login_credential(acc)
                if not email or not password:
                    continue
                if bool(getattr(row, "ok", False)):
                    continue
                targets.append((acc, email, recovery))
                row.set_status(False, "Chờ auto-login...", email)
            except Exception:
                pass
        if not targets:
            # V16: Login All only prepares login profiles. Do NOT launch a mass check-all
            # afterwards: that used to spawn many short-lived headless Chrome processes and
            # could make Windows/taskbar flash. Worker runtime validates/rotates accounts itself.
            ready_now = sum(1 for r in rows if bool(getattr(r, "ok", False)))
            self._prelogin_gate.update({
                "running": False, "phase": "ready" if ready_now else "idle",
                "login_total": 0, "login_processed": 0,
                "login_success": 0, "login_failed": 0,
                "current_account": 0, "current_email": "",
                "message": f"Không còn tài khoản cần login • READY {ready_now}/{len(rows)} • không tự Check All"
            })
            try:
                if getattr(self, "_login_guard_held", False):
                    d._release_chrome_background_guard(grace=0.2)
                    self._login_guard_held = False
            except Exception:
                self._login_guard_held = False
            d.append_log(f"[web-login-all] không còn target login • READY {ready_now}/{len(rows)} • AUTO CHECK ALL=OFF")
            return
        self._web_login_stop.clear()
        self._web_login_queue = list(targets)
        self._web_login_busy = False
        self._web_login_active = 0
        self._prelogin_gate.update({
            "phase": "login", "login_total": len(targets), "login_processed": 0,
            "login_success": 0, "login_failed": 0,
            "current_account": 0, "current_email": "",
            "message": f"Chuẩn bị đăng nhập {len(targets)} tài khoản • {self._web_login_parallel} luồng song song • runtime={mode}"
        })
        d.append_log(f"[web-login-all] V24 PARALLEL START • targets={len(targets)} • parallel={self._web_login_parallel} • chrome={chrome} • driver_mode={mode}")
        QTimer.singleShot(0, self._start_next_web_login)

    def _finalize_web_login_all_if_done(self):
        if self._web_login_queue or int(getattr(self, "_web_login_active", 0) or 0) > 0:
            return False
        d = self.dashboard
        rows, _missing = self._account_gate_rows()
        ready_now = sum(1 for r in rows if bool(getattr(r, "ok", False)))
        self._web_login_busy = False
        self._prelogin_gate.update({
            "running": False, "phase": "ready" if ready_now else "idle",
            "current_account": 0, "current_email": "",
            "message": f"Đăng nhập kho xong • READY {ready_now}/{len(rows)} • không tự Check All"
        })
        self._prelogin_timer.stop()
        d.append_log(
            f"[web-login-all] V24 PARALLEL DONE • ok={self._prelogin_gate.get('login_success',0)} "
            f"• fail={self._prelogin_gate.get('login_failed',0)} • READY={ready_now}/{len(rows)} • AUTO CHECK ALL=OFF"
        )
        return True

    def _start_next_web_login(self):
        """V24: pump up to 3 independent hidden login profiles in parallel."""
        if not self._prelogin_gate.get("running") or self._web_login_stop.is_set():
            return
        d = self.dashboard
        limit = max(1, int(getattr(self, "_web_login_parallel", 3) or 3))
        launched = 0
        while int(getattr(self, "_web_login_active", 0) or 0) < limit and self._web_login_queue:
            acc, email, recovery = self._web_login_queue.pop(0)
            row = self._row_map().get(int(acc))
            if row is None:
                self._prelogin_gate["login_processed"] = int(self._prelogin_gate.get("login_processed",0)) + 1
                self._prelogin_gate["login_failed"] = int(self._prelogin_gate.get("login_failed",0)) + 1
                continue
            try:
                _email, password, recovery2 = d._get_login_credential(acc)
                if recovery2:
                    recovery = recovery2
            except Exception:
                password = ""
            if not password:
                self._prelogin_gate["login_processed"] = int(self._prelogin_gate.get("login_processed",0)) + 1
                self._prelogin_gate["login_failed"] = int(self._prelogin_gate.get("login_failed",0)) + 1
                try: row.set_status(False, "Thiếu mật khẩu trong Vault", email)
                except Exception: pass
                continue
            self._web_login_active = int(getattr(self, "_web_login_active", 0) or 0) + 1
            self._web_login_busy = True
            launched += 1
            done_before = int(self._prelogin_gate.get("login_processed", 0))
            total_login = int(self._prelogin_gate.get("login_total", 0))
            active_now = int(self._web_login_active)
            self._prelogin_gate.update({
                "current_account": int(acc), "current_email": str(email),
                "message": f"Đăng nhập song song {active_now}/{limit} • đã xử lý {done_before}/{total_login} • {email}"
            })
            try: row.set_status(False, "Đang tự đăng nhập...", email)
            except Exception: pass
            d.append_log(f"[web-login-all] V24 launch • A{acc} • active={active_now}/{limit} • {email}")
            chrome, driver, _mode = self._resolve_login_runtime()
            proxy = None
            try: proxy = d._proxy_value_for_account(acc)
            except Exception: pass
            stop_event = self._web_login_stop

            def work(acc=acc, email=email, password=password, recovery=recovery, row=row, chrome=chrome, driver=driver, proxy=proxy):
                try:
                    ok, msg = dashmod._auto_google_login_once(
                        chrome, driver, row.profile_path(), email, password, recovery,
                        log_fn=d.append_log, stop_event=stop_event, hidden=True, proxy_value=proxy
                    )
                except BaseException as exc:
                    ok, msg = False, f"{type(exc).__name__}: {str(exc)[:220]}"
                self.login_result.emit({"account_no": int(acc), "email": str(email), "ok": bool(ok), "msg": str(msg or "")})

            threading.Thread(target=work, name=f"ThumbLoginA{acc}", daemon=True).start()
        if not self._web_login_queue and int(getattr(self, "_web_login_active", 0) or 0) <= 0:
            self._finalize_web_login_all_if_done()
        elif launched:
            self._prelogin_gate["message"] = (
                f"Đang đăng nhập {int(self._web_login_active)}/{limit} tài khoản song song • "
                f"đã xử lý {int(self._prelogin_gate.get('login_processed',0))}/{int(self._prelogin_gate.get('login_total',0))}"
            )

    @Slot(object)
    def _on_web_login_result(self, result):
        d = self.dashboard
        acc = int((result or {}).get("account_no") or 0)
        email = str((result or {}).get("email") or "")
        ok = bool((result or {}).get("ok"))
        msg = str((result or {}).get("msg") or ("OK" if ok else "FAIL"))
        row = self._row_map().get(acc)
        try:
            if row is not None:
                if ok:
                    row.set_status(True, "READY • Login OK", email)
                    try:
                        d._mark_account_login_ok(acc, msg or "Web login OK")
                    except Exception:
                        pass
                else:
                    row.set_status(False, msg or "Cần đăng nhập thủ công", email)
        except Exception:
            pass
        self._web_login_active = max(0, int(getattr(self, "_web_login_active", 0) or 0) - 1)
        self._web_login_busy = self._web_login_active > 0
        self._prelogin_gate["login_processed"] = int(self._prelogin_gate.get("login_processed",0)) + 1
        key = "login_success" if ok else "login_failed"
        self._prelogin_gate[key] = int(self._prelogin_gate.get(key,0)) + 1
        done = int(self._prelogin_gate.get("login_processed",0))
        total_login = int(self._prelogin_gate.get("login_total",0))
        self._prelogin_gate.update({
            "current_account": 0, "current_email": "",
            "message": f"Đăng nhập kho {done}/{total_login} • active {self._web_login_active}/{self._web_login_parallel} • OK {self._prelogin_gate.get('login_success',0)} • lỗi {self._prelogin_gate.get('login_failed',0)}"
        })
        d.append_log(f"[web-login-all] V24 result • {done}/{total_login} • A{acc} {'OK' if ok else 'FAIL'} • active={self._web_login_active} • {msg}")
        if not self._web_login_stop.is_set() and self._prelogin_gate.get("running"):
            if not self._finalize_web_login_all_if_done():
                QTimer.singleShot(20, self._start_next_web_login)

    def _schedule_queue_start(self, reason="web"):
        """Return the RPC immediately, then start Queue on the Qt event loop.

        V20 isolates a queue-start failure to the hidden Thumbnail engine.  The 3T API
        request completes before any Chromium/worker bootstrap begins, so the main tool/browser
        cannot look like it crashed just because the draw engine faults.
        """
        if self._queue_start_scheduled or bool(getattr(self.dashboard, "running", False)):
            return False
        self._queue_start_scheduled = True
        d = self.dashboard
        try:
            d.append_log(f"[V20-SAFE-START] QUEUE SCHEDULED • reason={reason} • no global Chrome cleanup")
        except Exception:
            pass
        _persist_diag(f"[V20-SAFE-START] QUEUE SCHEDULED reason={reason}")

        def _go():
            self._queue_start_scheduled = False
            try:
                _persist_diag("[V20-SAFE-START] ENTER start_project_queue")
                d.append_log("[V20-SAFE-START] ENTER • khởi động Queue trong hidden engine")
                d.start_project_queue()
                _persist_diag("[V20-SAFE-START] RETURN start_project_queue")
            except BaseException as exc:
                msg = f"{type(exc).__name__}: {exc}"
                _persist_diag(f"[V20-SAFE-START] ERROR {msg}")
                try:
                    d.append_log(f"[V20-SAFE-START] ERROR • {msg}")
                except Exception:
                    pass
                try:
                    with PERSIST_FATAL_LOG.open("a", encoding="utf-8", errors="replace") as _f:
                        _f.write("\n" + "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)) + "\n")
                except Exception:
                    pass

        QTimer.singleShot(0, _go)
        return True

    def _begin_prelogin_gate(self, run_after=False):
        d = self.dashboard
        rows, missing = self._account_gate_rows()
        if not rows:
            raise RuntimeError("Kho tài khoản đang trống. Hãy mở Kho tài khoản → Nhập TXT trước khi chạy.")

        total = len(rows)
        ready = sum(1 for r in rows if bool(getattr(r, "ok", False)))

        # V53 progressive start: pressing Chạy always triggers a fresh account check.
        # The Queue starts as soon as enough accounts are GREEN/READY for the requested
        # worker count, while the remaining accounts continue checking in background.
        if run_after:
            if bool(getattr(d, "running", False)):
                return {"ok": True, "started": True, "prelogin": self._prelogin_snapshot()}
            try:
                workers = max(1, int(d.worker_spin.value()))
            except Exception:
                workers = 1
            if total < workers:
                raise RuntimeError(f"Kho chỉ có {total} tài khoản nhưng đang chọn {workers} luồng.")

            # Do not trust cached READY as a fresh run gate. Cached state is only for visual
            # persistence; every new Chạy request revalidates accounts progressively.
            try:
                d._web_strict_ready_accounts = set()
            except Exception:
                pass

            self._prelogin_gate.update({
                "running": True,
                "phase": "checking",
                "run_after": True,
                "queue_started": False,
                "background_check": True,
                "target_ready": workers,
                "total": total,
                "ready": 0,
                "failed": 0,
                "message": f"Đang kiểm tra tài khoản • đủ {workers} READY sẽ tự chạy Queue",
                "started_at": time.monotonic(),
                "saw_checking": False,
            })
            d.append_log(
                f"[V53-PROGRESSIVE-RUN] START • workers={workers} • warehouse={total} • "
                "fresh-check=YES • start-when-ready=YES • continue-check-after-start=YES"
            )
            if not bool(getattr(d, "_checking_all", False)):
                d.check_all()
            else:
                d.append_log("[V53-PROGRESSIVE-RUN] reuse existing Check All cycle")
            self._prelogin_timer.start()
            return {"ok": True, "started": False, "checking": True, "prelogin": self._prelogin_snapshot()}

        # Login All remains an optional warehouse preparation action. Missing credentials are
        # reported, but valid accounts are still allowed to continue.
        if self._prelogin_gate.get("running"):
            return {"ok": True, "started": False, "prelogin": self._prelogin_snapshot()}

        self._prelogin_gate.update({
            "running": True,
            "phase": "login",
            "run_after": False,
            "queue_started": False,
            "background_check": False,
            "target_ready": 0,
            "total": total,
            "ready": ready,
            "failed": 0,
            "message": f"Đang đăng nhập các tài khoản chưa READY {ready}/{total} • có thể dừng bất kỳ lúc nào",
            "started_at": time.monotonic(),
            "saw_checking": False,
        })
        d.append_log(f"[web-account-login] START OPTIONAL • total={total} • ready={ready} • không bắt buộc đủ kho để chạy Queue")
        try:
            self._start_web_login_all()
        except Exception as exc:
            self._prelogin_gate.update({"running": False, "phase": "failed", "run_after": False, "message": str(exc)})
            d.append_log(f"[web-account-login] START FAILED • {exc}")
            raise
        if self._prelogin_gate.get("running"):
            self._prelogin_timer.start()
        return {"ok": True, "started": False, "prelogin": self._prelogin_snapshot()}

    def _poll_prelogin_gate(self):
        if not self._prelogin_gate.get("running"):
            self._prelogin_timer.stop()
            return
        d = self.dashboard
        rows, _missing = self._account_gate_rows()
        total = len(rows)
        checking = bool(getattr(d, "_checking_all", False)) or bool(getattr(d, "_checking_account_nos", set()) or set())
        statuses = [_safe_text(getattr(r, "status", None), "").lower() for r in rows]
        busy_words = ("đang tự đăng nhập", "chờ auto-login", "đang kiểm tra", "chờ kiểm tra", "headless", "checking")
        error_words = ("cần đăng nhập thủ công", "lỗi auto-login", "login fail", "login failed", "không đăng nhập", "hết hạn")
        login_busy = checking or int(getattr(self, "_web_login_active", 0) or 0) > 0 or bool(self._web_login_queue) or any(any(w in st for w in busy_words) for st in statuses)
        failed_rows = [r for r, st in zip(rows, statuses) if not bool(getattr(r, "ok", False)) and any(w in st for w in error_words)]
        elapsed = max(0.0, time.monotonic() - float(self._prelogin_gate.get("started_at") or time.monotonic()))
        if checking:
            self._prelogin_gate["saw_checking"] = True

        # V53 progressive Queue gate. Only freshly GREEN rows are admitted to the strict
        # runtime pool. As more accounts finish checking, they are appended to the allow-list
        # while drawing continues, so replacements/failover can use them immediately.
        progressive = bool(self._prelogin_gate.get("background_check")) or int(self._prelogin_gate.get("target_ready", 0) or 0) > 0
        if progressive:
            usable = []
            held = set()
            try:
                held = set(d._daily_quota_held_accounts() or set())
            except Exception:
                pass
            for r in rows:
                try:
                    acc = int(r.account_no())
                    if not bool(getattr(r, "ok", False)):
                        continue
                    if acc in held:
                        continue
                    if not r.profile_path().exists():
                        continue
                    try:
                        if d._force_login_marker_path_for_account(acc).is_file():
                            continue
                    except Exception:
                        pass
                    if acc not in usable:
                        usable.append(acc)
                except Exception:
                    pass
            try:
                usable = list(d._sorted_candidate_accounts(usable))
            except Exception:
                usable = sorted(set(usable))
            try:
                d._web_strict_ready_accounts = set(usable)
            except Exception:
                pass

            ready = len(usable)
            target = max(1, int(self._prelogin_gate.get("target_ready", 1) or 1))
            queue_started = bool(self._prelogin_gate.get("queue_started")) or bool(getattr(d, "running", False))
            done_count = int(getattr(d, "_web_check_done", 0) or 0)
            total_check = int(getattr(d, "_web_check_total", total) or total)
            self._prelogin_gate.update({
                "total": total, "ready": ready, "failed": len(failed_rows),
                "checked": done_count, "check_total": total_check,
            })

            if not queue_started and ready >= target:
                scheduled = self._schedule_queue_start(f"V53 progressive READY {ready}/{target}")
                if scheduled or bool(getattr(d, "running", False)):
                    queue_started = True
                    self._prelogin_gate.update({
                        "queue_started": True, "run_after": False,
                        "phase": "running_queue_checking",
                        "message": f"Đủ {ready}/{target} READY → Queue bắt đầu • tiếp tục kiểm tra {done_count}/{total_check} tài khoản",
                    })
                    d.append_log(
                        f"[V53-PROGRESSIVE-RUN] PASS • READY={ready}/{target} • "
                        f"checked={done_count}/{total_check} • Queue start NOW • background check continues"
                    )
            elif queue_started:
                self._prelogin_gate.update({
                    "queue_started": True, "run_after": False,
                    "phase": "running_queue_checking" if checking else "running_queue",
                    "message": (
                        f"Queue đang chạy • READY {ready}/{total} • đang kiểm tra nền {done_count}/{total_check}"
                        if checking else f"Queue đang chạy • kiểm tra xong • READY {ready}/{total}"
                    ),
                })
            else:
                self._prelogin_gate.update({
                    "phase": "checking", "run_after": True,
                    "message": f"Đang kiểm tra tài khoản {done_count}/{total_check} • READY {ready}/{target} • đủ {target} sẽ tự chạy",
                })

            # A full Check All cycle ending no longer stops an already-started Queue.
            # If Queue has not started yet, only then report not-enough-READY.
            check_finished = not bool(getattr(d, "_checking_all", False)) and not bool(getattr(d, "_checking_account_nos", set()) or set()) and bool(self._prelogin_gate.get("saw_checking"))
            if check_finished:
                self._persist_account_ready_state_v53(force=True)
                self._prelogin_timer.stop()
                if queue_started or bool(getattr(d, "running", False)):
                    self._prelogin_gate.update({
                        "running": False, "phase": "running_queue", "run_after": False,
                        "background_check": False, "queue_started": True,
                        "message": f"Queue đang chạy • kiểm tra toàn kho xong • READY {ready}/{total}",
                    })
                    d.append_log(f"[V53-PROGRESSIVE-RUN] BACKGROUND CHECK DONE • READY={ready}/{total} • Queue continues")
                else:
                    self._prelogin_gate.update({
                        "running": False, "phase": "failed", "run_after": False,
                        "background_check": False, "queue_started": False,
                        "message": f"Đã kiểm tra xong nhưng chỉ có {ready}/{target} tài khoản READY. Queue chưa chạy.",
                    })
                    d.append_log(f"[V53-PROGRESSIVE-RUN] NOT ENOUGH • READY={ready}/{target} • checked={done_count}/{total_check}")
                return

            if elapsed > 1800:
                self._persist_account_ready_state_v53(force=True)
                self._prelogin_timer.stop()
                if queue_started or bool(getattr(d, "running", False)):
                    self._prelogin_gate.update({
                        "running": False, "phase": "running_queue", "run_after": False,
                        "background_check": False, "queue_started": True,
                        "message": f"Queue đang chạy • dừng kiểm tra nền do timeout • READY {ready}/{total}",
                    })
                else:
                    self._prelogin_gate.update({
                        "running": False, "phase": "failed", "run_after": False,
                        "background_check": False, "message": f"Hết thời gian kiểm tra • READY {ready}/{target}. Queue chưa chạy.",
                    })
                return
            return

        # Existing optional Login All flow.
        ready = sum(1 for r in rows if bool(getattr(r, "ok", False)))
        phase_now = "checking" if checking else ("login" if (int(getattr(self, "_web_login_active", 0) or 0) > 0 or self._web_login_queue) else self._prelogin_gate.get("phase", "login"))
        self._prelogin_gate.update({"total": total, "ready": ready, "failed": len(failed_rows), "phase": phase_now})
        if phase_now == "checking":
            self._prelogin_gate["message"] = f"Đang kiểm tra Gemini • READY {ready}/{total}"
        elif not (int(getattr(self, "_web_login_active", 0) or 0) > 0 or self._web_login_queue):
            self._prelogin_gate["message"] = f"Đang chuẩn bị kho {ready}/{total}"

        if total > 0 and ready == total:
            self._prelogin_timer.stop()
            self._prelogin_gate.update({"running": False, "phase": "ready", "run_after": False, "failed": 0, "message": f"Kho tài khoản READY {ready}/{total}"})
            self._persist_account_ready_state_v53(force=True)
            d.append_log(f"[web-account-gate] READY • {ready}/{total}")
            return

        finished_check_cycle = bool(self._prelogin_gate.get("saw_checking")) and not checking and not login_busy and elapsed > 5.0
        if (failed_rows or finished_check_cycle) and ready < total and not login_busy and elapsed > 8.0:
            self._prelogin_timer.stop()
            bad_rows = [r for r in rows if not bool(getattr(r, "ok", False))]
            failed_labels = []
            for r in bad_rows[:8]:
                try:
                    failed_labels.append(f"google_{int(r.account_no())}")
                except Exception:
                    pass
            self._prelogin_gate.update({
                "running": False, "phase": "failed", "run_after": False,
                "failed": len(bad_rows),
                "message": f"{len(bad_rows)} tài khoản đăng nhập/kiểm tra chưa đạt: {', '.join(failed_labels)}.",
            })
            self._persist_account_ready_state_v53(force=True)
            return
        if elapsed > 1800:
            self._prelogin_timer.stop()
            self._prelogin_gate.update({"running": False, "phase": "failed", "run_after": False, "message": f"Hết thời gian chuẩn bị kho • READY {ready}/{total}."})
            self._persist_account_ready_state_v53(force=True)

    def _snapshot_brand(self):
        d = self.dashboard
        w = getattr(d, "_channel_brand_dialog", None)
        if w is None:
            return {}
        names = []
        for btn in list(getattr(w, "_name_buttons", []) or []):
            try:
                name = str(btn.property("brand_name") or btn.text() or "").strip()
            except Exception:
                name = ""
            if name and not name.startswith("Tên "):
                names.append(name)
        logos = []
        for p in list(getattr(w, "_all_logo_paths", []) or []):
            p = str(p or "").strip()
            if p:
                logos.append({"path": p, "name": Path(p).name, "mtime": _mtime(p), "size": _size(p)})
        return {
            "key": _safe_text(getattr(w, "key_edit", None), ""),
            "notes": _safe_plain(getattr(w, "notes_edit", None), ""),
            "busy": bool(getattr(w, "_busy", False)),
            "status": _safe_text(getattr(w, "status", None), "Sẵn sàng"),
            "names": names,
            "selected_name": str(getattr(w, "_selected_name", "") or ""),
            "logos": logos,
            "selected_logo_index": int(getattr(w, "_selected_logo_idx", -1) or -1),
            "can_more_names": bool(getattr(w, "_can_more_names", False)),
        }

    def _snapshot_desc(self, limit=1000):
        d = self.dashboard
        out = []
        for j in list(getattr(d, "desc_jobs", []) or [])[: max(1, int(limit))]:
            p = str(j.get("description_path") or "")
            preview = str(j.get("preview") or "").strip()
            if not preview and p and Path(p).is_file():
                try:
                    raw_preview = Path(p).read_text(encoding="utf-8-sig", errors="ignore")
                    preview = " ".join(raw_preview.split())[:320]
                    j["preview"] = preview
                except Exception:
                    preview = ""
            out.append({
                "path": p,
                "folder": str(j.get("folder") or (Path(p).parent if p else "")),
                "folder_name": Path(p).parent.name if p else "",
                "status": str(j.get("status") or "queued"),
                "note": str(j.get("note") or ""),
                "preview": preview,
                "size": int(j.get("size") or (_size(p) if p else 0)),
                "checked": str(p).lower() in {str(x).lower() for x in (getattr(d, "desc_checked_paths", set()) or set())},
                "mtime": _mtime(p),
            })
        rows = self._row_map()
        ready_accounts = sum(1 for r in rows.values() if bool(getattr(r, "ok", False)))
        try:
            available_accounts = len(self._description_http_accounts())
            candidate_accounts = len(self._description_http_candidates())
        except Exception:
            available_accounts = 0
            candidate_accounts = ready_accounts
        return {
            "running": bool(getattr(d, "desc_running", False)),
            "operation": str(getattr(d, "desc_operation", "idle") or "idle"),
            "message": str(getattr(d, "desc_last_message", "") or ""),
            "stats": dict(getattr(d, "desc_stats", {}) or {}),
            "roots": list(getattr(d, "desc_custom_roots", []) or []),
            "all_roots": list(d._description_queue_roots()),
            "language": str(getattr(d, "desc_translate_language", "English") or "English"),
            "engine": "Gemini Web Direct HTTP",
            "selenium": False,
            "account_source": "Thumbnail Studio Vault",
            "ready_accounts": int(ready_accounts),
            "available_accounts": int(available_accounts),
            "candidate_accounts": int(candidate_accounts),
            "jobs": out,
        }

    def snapshot(self, args):
        d = self.dashboard
        stats = {
            "total": len(list(getattr(d, "jobs", []) or [])),
            "queue": sum(1 for j in (d.jobs or []) if str(j.get("status") or "") in ("queued", "reserved")),
            "running": sum(1 for j in (d.jobs or []) if str(j.get("status") or "") == "running"),
            "done": sum(1 for j in (d.jobs or []) if str(j.get("status") or "") == "done"),
            "error": sum(1 for j in (d.jobs or []) if str(j.get("status") or "") == "error"),
            "skip": sum(1 for j in (d.jobs or []) if str(j.get("status") or "") == "skipped"),
        }
        queues = []
        d._ensure_project_queue_slots()
        for idx, q in enumerate(list(d.project_queue or [])):
            q = q or {}
            queues.append({
                "index": idx,
                "root": str(q.get("root") or ""),
                "logo": str(q.get("logo") or ""),
                "status": str(q.get("status") or "chờ"),
                "total": q.get("total", "?"),
                "done": int(q.get("done") or 0),
                "error": int(q.get("error") or 0),
                "skip": int(q.get("skip") or 0),
            })
        workers = []
        for w in list(getattr(d, "workers", []) or []):
            try:
                workers.append({
                    "id": int(getattr(w, "worker_id", 0) or 0),
                    "account": int(getattr(w, "account_no", 0) or 0),
                    "queue_index": int(getattr(w, "queue_index", -1) if str(getattr(w, "queue_index", "")).lstrip("-").isdigit() else -1),
                    "finished": bool(getattr(w, "finished", False)),
                    "alive": bool(getattr(w, "proc", None) and getattr(w, "proc").poll() is None),
                })
            except Exception:
                pass

        # V64: self-heal stale run flags after a genuinely completed queue.
        # The dashboard's generic ``running`` flag may remain true for a short time
        # after every worker has exited. Web UI must not keep showing "Đang chạy"
        # when all jobs are terminal and there is no live worker.
        try:
            _live_workers = any(bool(w.get("alive")) and not bool(w.get("finished")) for w in workers)
            _fully_done = (
                int(stats.get("total") or 0) > 0
                and int(stats.get("queue") or 0) == 0
                and int(stats.get("running") or 0) == 0
                and int(stats.get("error") or 0) == 0
                and int(stats.get("done") or 0) + int(stats.get("skip") or 0) >= int(stats.get("total") or 0)
            )
            if _fully_done and not _live_workers:
                if bool(getattr(d, "running", False)) or bool(getattr(d, "queue_running", False)):
                    d.running = False
                    d.queue_running = False
                    try:
                        d._queue_advance_pending = False
                    except Exception:
                        pass
                    try:
                        d.current_queue_index = -1
                    except Exception:
                        pass
                    try:
                        if getattr(d, "run_started_at", None) and getattr(d, "run_finished_at", None) is None:
                            d.run_finished_at = time.monotonic()
                    except Exception:
                        pass
                    try:
                        cur = _safe_text(getattr(d, "status_label", None), "")
                        if not cur or "Đang chạy" in cur or "Gemini Headless" in cur:
                            d.status_label.setText("Hoàn tất toàn bộ")
                    except Exception:
                        pass
                    try:
                        d.append_log("[V64-WEB-RUN-HEAL] tất cả job đã hoàn tất • tự hạ running/queue_running bị kẹt")
                    except Exception:
                        pass
        except Exception:
            pass

        runtime = 0
        try:
            if d.run_started_at:
                end = d.run_finished_at or time.monotonic()
                runtime = max(0, int(end - d.run_started_at))
        except Exception:
            pass
        log_limit = int(args.get("log_limit", 260) or 260)
        logs = list(getattr(d, "_web_log_lines", []) or [])[-log_limit:]
        if not logs:
            try:
                widget = getattr(d, "log", None)
                if widget is not None:
                    logs = str(widget.toPlainText() or "").splitlines()[-log_limit:]
            except Exception:
                logs = []
        if not logs:
            try:
                if PERSIST_LIVE_LOG.is_file():
                    logs = PERSIST_LIVE_LOG.read_text(encoding="utf-8", errors="ignore").splitlines()[-log_limit:]
            except Exception:
                logs = []
        if not logs:
            try:
                live_log = Path(getattr(d, "backend_dir", BASE)) / "_debug" / "thumbnail_studio_live.log"
                if live_log.is_file():
                    logs = live_log.read_text(encoding="utf-8", errors="ignore").splitlines()[-log_limit:]
            except Exception:
                logs = []
        model = "auto"
        try:
            model = str(d.thumb_model_combo.currentData() or "auto")
        except Exception:
            pass
        return {
            "ok": True,
            "version": str(getattr(dashmod, "APP_VERSION", "13.54")),
            "engine": "v13.54 core • V24 Fast Account + Progress",
            "running": bool(getattr(d, "running", False)),
            "queue_running": bool(getattr(d, "queue_running", False)),
            "scan_running": bool(getattr(d, "_scan_running", False)),
            "status": _safe_text(getattr(d, "status_label", None), "Sẵn sàng"),
            "runtime_seconds": runtime,
            "stats": stats,
            "config": {
                "workers": int(d.worker_spin.value()),
                "model": model,
                "proxy_enabled": bool(d._is_proxy_enabled()),
                "proxy_status": _safe_text(getattr(d, "proxy_status_label", None), ""),
            },
            "queues": queues,
            "jobs": self._snapshot_jobs(args.get("job_limit", 1400)),
            "workers": workers,
            "accounts": self._snapshot_accounts(),
            "accounts_checking_all": bool(getattr(d, "_checking_all", False)),
            "accounts_check_progress": {
                "total": int(getattr(d, "_web_check_total", 0) or 0),
                "done": int(getattr(d, "_web_check_done", 0) or 0),
                "ok": int(getattr(d, "_web_check_ok", 0) or 0),
                "fail": int(getattr(d, "_web_check_fail", 0) or 0),
            },
            "prelogin": self._prelogin_snapshot(),
            "warehouse_persisted": self._warehouse_persist_path_v10().is_file(),
            "warehouse_persist_path": str(self._warehouse_persist_path_v10()),
            "warehouse_persisted_count": len(self._vault_records()),
            "brand": self._snapshot_brand(),
            "description": self._snapshot_desc(args.get("desc_limit", 1200)),
            "logs": logs,
            "paths": {
                "addon": str(BASE),
                "run": str(getattr(d, "run_dir", "") or ""),
                "live_log": str(PERSIST_LIVE_LOG),
                "fatal_log": str(PERSIST_FATAL_LOG),
            },
        }

    def _find_job(self, path):
        want = str(path or "").lower()
        for j in list(getattr(self.dashboard, "jobs", []) or []):
            if str(j.get("image_path") or "").lower() == want:
                return j
        return None

    def _find_desc_job(self, path):
        want = str(path or "").lower()
        for j in list(getattr(self.dashboard, "desc_jobs", []) or []):
            if str(j.get("description_path") or "").lower() == want:
                return j
        return None

    def _description_http_candidates(self):
        """Return Thumbnail Studio account/profile candidates for Description Studio.

        A profile marker means the account is worth checking, but it is NOT considered
        HTTP-ready until Thumbnail Studio has exported a live Gemini session bundle.
        """
        d = self.dashboard
        records = self._vault_records()
        rows = self._row_map()
        profiles_root = Path(getattr(d, "backend_dir", BASE)) / "profiles"
        held = set()
        try:
            held = set(d._daily_quota_held_accounts())
        except Exception:
            pass
        try:
            for w in list(getattr(d, "workers", []) or []):
                if bool(getattr(w, "alive", True)) and not bool(getattr(w, "finished", False)):
                    acc = int(getattr(w, "account_no", 0) or 0)
                    if acc:
                        held.add(acc)
        except Exception:
            pass
        out = []
        for rec in records:
            try:
                acc = int(rec.get("account_no") or 0)
            except Exception:
                continue
            if not acc or acc in held:
                continue
            row = rows.get(acc)
            try:
                profile = Path(row.profile_path()) if row is not None else Path(d._profile_dir_for_account(acc))
            except Exception:
                profile = profiles_root / f"google_{acc}"
            if not profile.exists():
                continue
            row_ready = bool(getattr(row, "ok", False)) if row is not None else False
            marker_ready = False
            marker_reason = ""
            try:
                marker_ready, marker_reason = d._profile_ready_for_fast_draw(acc)
            except Exception:
                marker_ready = False
            cache_ready = False
            cache_age = None
            try:
                cached_cookies, _cached_ua = desc_http.load_thumbnail_session_bundle(profile)
                cache_ready = bool(cached_cookies)
                bp = profile / ".session_engine" / "gemini.json"
                if bp.is_file():
                    cache_age = max(0, int(time.time() - bp.stat().st_mtime))
            except Exception:
                cache_ready = False
            # Keep only accounts that Thumbnail Studio itself knows about as logged/usable,
            # or accounts that already have a captured HTTP session.
            if not (cache_ready or row_ready or marker_ready):
                continue
            proxy = ""
            try:
                proxy = str(d._proxy_value_for_account(acc) or "") if d._is_proxy_enabled() else ""
            except Exception:
                proxy = ""
            out.append({
                "account_no": acc,
                "email": str(rec.get("email") or ""),
                "profile": profile,
                "proxy": proxy,
                "row_ready": row_ready,
                "marker_ready": marker_ready,
                "cache_ready": cache_ready,
                "cache_age": cache_age,
                "ready_source": "session-cache" if cache_ready else ("row" if row_ready else "profile-marker"),
                "ready_note": str(marker_reason or "")[:180],
            })
        rank = {"session-cache": 0, "row": 1, "profile-marker": 2}
        out.sort(key=lambda x: (rank.get(str(x.get("ready_source") or ""), 9), int(x.get("account_no") or 0)))
        return out

    def _description_http_accounts(self):
        """Only accounts with an actual exported Gemini HTTP session are HTTP-ready."""
        return [x for x in self._description_http_candidates() if bool(x.get("cache_ready"))]

    def _description_prepare_http_accounts(self, needed=1):
        """Populate HTTP session bundles via Thumbnail Studio's own account checker.

        Description rewriting remains Direct HTTP. The existing Thumbnail Studio login/check
        mechanism is used only as an authentication bootstrap so Chrome can decrypt its own
        App-Bound cookies and export them into .session_engine/gemini.json.
        """
        d = self.dashboard
        needed = max(1, int(needed or 1))
        ready = self._description_http_accounts()
        if len(ready) >= needed:
            return ready
        candidates = [x for x in self._description_http_candidates() if not x.get("cache_ready")]
        if not candidates:
            return ready
        d.desc_last_message = f"Đang chuẩn bị phiên HTTP từ Kho tài khoản • {len(ready)}/{needed} READY"
        _persist_diag(f"[desc-http] PREP START needed={needed} cached={len(ready)} candidates={len(candidates)}")

        # Keep bootstrap conservative: at most 3 hidden account checks at once.
        prep_q = queue.Queue()
        for item in candidates:
            prep_q.put(item)
        prep_lock = threading.RLock()

        def prep_worker(pid):
            nonlocal ready
            while not self._desc_http_stop.is_set():
                with prep_lock:
                    if len(ready) >= needed:
                        return
                try:
                    item = prep_q.get_nowait()
                except queue.Empty:
                    return
                acc = int(item.get("account_no") or 0)
                profile = Path(item.get("profile"))
                try:
                    d.append_log(f"[desc-http prep P{pid}] A{acc} • kiểm tra Gemini bằng Kho tài khoản")
                    ok, msg, _email = dashmod.check_gemini_logged_in(
                        str(d.chrome_binary), str(d.driver_binary), str(profile), stop_event=self._desc_http_stop
                    )
                    cookies, _ua = desc_http.load_thumbnail_session_bundle(profile)
                    cache_ok = bool(cookies)
                    _persist_diag(f"[desc-http] PREP A{acc} ok={ok} cache={cache_ok} msg={str(msg)[:120]}")
                    if cache_ok:
                        with prep_lock:
                            # Re-read canonical account record so proxy/source flags stay current.
                            current = [x for x in self._description_http_accounts() if int(x.get('account_no') or 0) == acc]
                            if current and not any(int(x.get('account_no') or 0) == acc for x in ready):
                                ready.append(current[0])
                            d.desc_last_message = f"Đang chuẩn bị phiên HTTP • {len(ready)}/{needed} READY"
                    elif not ok:
                        d.append_log(f"[desc-http prep P{pid}] A{acc} FAIL • {msg}")
                except Exception as exc:
                    d.append_log(f"[desc-http prep P{pid}] A{acc} ERROR • {exc}")
                    _persist_diag(f"[desc-http] PREP ERROR A{acc} {type(exc).__name__}: {str(exc)[:200]}")
                finally:
                    prep_q.task_done()

        threads = []
        for i in range(min(3, len(candidates), needed)):
            t = threading.Thread(target=prep_worker, args=(i + 1,), name=f"DescHTTP-Prep-{i+1}", daemon=True)
            t.start(); threads.append(t)
        for t in threads:
            t.join()
        final = self._description_http_accounts()
        _persist_diag(f"[desc-http] PREP DONE ready={len(final)} needed={needed}")
        return final

    def _description_atomic_write(self, path: Path, text: str):
        tmp = path.with_name(path.name + f".hd_desc_{os.getpid()}_{threading.get_ident()}.tmp")
        tmp.write_text(str(text or "").rstrip("\n") + "\n", encoding="utf-8", errors="replace")
        os.replace(str(tmp), str(path))

    def _description_http_start(self, paths=None, model="auto", workers=None):
        d = self.dashboard
        if bool(getattr(d, "desc_running", False)):
            raise RuntimeError("Sửa mô tả đang chạy")
        if not getattr(d, "desc_jobs", None):
            jobs = d._scan_description_jobs_sync()
            with d.desc_lock:
                d.desc_jobs = jobs
                d.desc_stats = d._desc_compute_stats()
        wanted = {str(x).lower() for x in (paths or []) if str(x).strip()}
        with d.desc_lock:
            if wanted:
                jobs_to_run = [j for j in d.desc_jobs if str(j.get("description_path") or "").lower() in wanted]
                for j in jobs_to_run:
                    if j.get("status") in ("done", "error", "skipped"):
                        j["status"] = "queued"
                        j["note"] = "Đã chọn chạy lại bằng Gemini HTTP"
            else:
                # Errors from a previous failed HTTP bootstrap are retriable.
                for j in d.desc_jobs:
                    if j.get("status") == "error":
                        j["status"] = "queued"
                        j["note"] = "Chạy lại bằng Gemini HTTP"
                jobs_to_run = [j for j in d.desc_jobs if j.get("status") == "queued"]
            d.desc_stats = d._desc_compute_stats()
        if not jobs_to_run:
            raise RuntimeError("Không có description.txt nào cần sửa")

        try:
            requested = int(workers if workers is not None else d.worker_spin.value())
        except Exception:
            requested = 4
        requested = max(1, min(requested, 12, len(jobs_to_run)))
        model = str(model or "auto").lower()
        if model == "auto":
            try:
                model = str(d.thumb_model_combo.currentData() or "auto").lower()
            except Exception:
                model = "auto"

        # There may be many profile-marker accounts but zero exported HTTP sessions on first V50 run.
        # Do not mark the jobs as errors. Prepare the session cache asynchronously first.
        candidates = self._description_http_candidates()
        if not candidates:
            raise RuntimeError("Kho tài khoản chưa có account Gemini dùng được. Hãy đăng nhập/kiểm tra tài khoản bên Thumbnail Studio trước.")

        self._desc_http_run_id += 1
        run_id = self._desc_http_run_id
        self._desc_http_stop.clear()
        d.desc_running = True
        d.desc_operation = "rewrite_http"
        cached_now = len(self._description_http_accounts())
        if cached_now:
            d.desc_last_message = f"Chuẩn bị sửa {len(jobs_to_run)} mô tả • HTTP READY {cached_now}"
        else:
            d.desc_last_message = "Đang chuẩn bị phiên HTTP từ Kho tài khoản Thumbnail Studio…"
        try:
            d.append_log(f"[desc-http] START • jobs={len(jobs_to_run)} • requested={requested} • model={model} • cached={cached_now} • SELENIUM_REWRITE=OFF")
            _persist_diag(f"[desc-http] START jobs={len(jobs_to_run)} requested={requested} model={model} cached={cached_now}")
        except Exception:
            pass

        q = queue.Queue()
        for job in jobs_to_run:
            q.put(job)

        def worker_loop(worker_id, account):
            acc = int(account["account_no"])
            try:
                client = desc_http.GeminiProfileClient(account["profile"], model=model, proxy=account.get("proxy") or "")
                # Validate real Gemini auth before taking any job from the queue.
                client._token(force=True)
                d.append_log(f"[desc-http W{worker_id}] A{acc} HTTP READY • {client.session_source}")
                _persist_diag(f"[desc-http W{worker_id}] A{acc} HTTP READY source={client.session_source}")
            except Exception as exc:
                d.append_log(f"[desc-http W{worker_id}] A{acc} session FAIL • {exc}")
                _persist_diag(f"[desc-http W{worker_id}] A{acc} SESSION FAIL {type(exc).__name__}: {str(exc)[:220]}")
                return
            while not self._desc_http_stop.is_set():
                try:
                    job = q.get_nowait()
                except queue.Empty:
                    break
                p = Path(str(job.get("description_path") or ""))
                if not p.is_file():
                    with d.desc_lock:
                        job["status"] = "error"; job["note"] = "description.txt không tồn tại"; d.desc_stats = d._desc_compute_stats()
                    q.task_done(); continue
                try:
                    with d.desc_lock:
                        job["status"] = "running"
                        job["note"] = f"HTTP Direct • A{acc} • W{worker_id}"
                        d.desc_stats = d._desc_compute_stats()
                        d.desc_last_message = f"Đang sửa • {d.desc_stats.get('done',0)}/{d.desc_stats.get('total',0)} • A{acc}"
                    original = p.read_text(encoding="utf-8-sig", errors="ignore").strip()
                    if not original:
                        raise RuntimeError("Mô tả gốc trống")
                    d._description_first_backup_path(p, create_from_text=original)
                    result = client.rewrite_description(original, timeout=120)
                    if len(result) < max(20, int(len(original) * 0.08)):
                        raise RuntimeError("Kết quả Gemini quá ngắn so với mô tả gốc")
                    self._description_atomic_write(p, result)
                    with d.desc_lock:
                        job["status"] = "done"
                        job["note"] = f"OK • HTTP Direct • A{acc}"
                        job["preview"] = " ".join(result.split())[:320]
                        job["size"] = len(result)
                        d.desc_stats = d._desc_compute_stats()
                        d.desc_last_message = f"Đã sửa {d.desc_stats.get('done',0)}/{d.desc_stats.get('total',0)} • lỗi {d.desc_stats.get('error',0)}"
                    d.append_log(f"[desc-http W{worker_id}] OK • A{acc} • {p}")
                    _persist_diag(f"[desc-http W{worker_id}] OK A{acc} {p}")
                except Exception as exc:
                    with d.desc_lock:
                        job["status"] = "error"
                        job["note"] = f"A{acc} • {str(exc)[:180]}"
                        d.desc_stats = d._desc_compute_stats()
                        d.desc_last_message = f"HTTP Direct • lỗi {d.desc_stats.get('error',0)} • còn chờ {d.desc_stats.get('queued',0)}"
                    d.append_log(f"[desc-http W{worker_id}] ERROR • A{acc} • {p} • {exc}")
                    _persist_diag(f"[desc-http W{worker_id}] JOB ERROR A{acc} {p} • {type(exc).__name__}: {str(exc)[:220]}")
                finally:
                    q.task_done()

        def run_all():
            try:
                desired = min(requested, len(jobs_to_run))
                accounts = self._description_http_accounts()
                if len(accounts) < desired and not self._desc_http_stop.is_set():
                    accounts = self._description_prepare_http_accounts(desired)
                if self._desc_http_stop.is_set():
                    return
                if not accounts:
                    # Critical V50 behavior: auth bootstrap failure must NOT poison every description row.
                    with d.desc_lock:
                        for j in jobs_to_run:
                            if j.get("status") in ("running", "error") and str(j.get("note") or "").startswith("Không có account"):
                                j["status"] = "queued"
                        d.desc_stats = d._desc_compute_stats()
                        d.desc_last_message = "0 HTTP READY • hãy Kiểm tra/Đăng nhập tài khoản trong Kho tài khoản Thumbnail Studio rồi chạy lại"
                    _persist_diag("[desc-http] ABORT no HTTP READY after bootstrap")
                    return
                worker_count = max(1, min(desired, len(accounts), len(jobs_to_run)))
                selected_accounts = accounts[:worker_count]
                with d.desc_lock:
                    d.desc_last_message = f"Đang sửa {len(jobs_to_run)} mô tả • HTTP Direct • {worker_count} luồng"
                d.append_log(f"[desc-http] HTTP READY • workers={worker_count} • accounts={','.join('A'+str(x['account_no']) for x in selected_accounts)}")
                _persist_diag(f"[desc-http] RUN workers={worker_count} accounts={','.join('A'+str(x['account_no']) for x in selected_accounts)}")

                threads = []
                for wid, account in enumerate(selected_accounts, 1):
                    t = threading.Thread(target=worker_loop, args=(wid, account), name=f"DescHTTP-W{wid}", daemon=True)
                    t.start(); threads.append(t)
                for t in threads:
                    t.join()

                with d.desc_lock:
                    untouched = [j for j in jobs_to_run if j.get("status") == "queued"]
                    stats = d._desc_compute_stats()
                    d.desc_stats = stats
                    stopped = self._desc_http_stop.is_set()
                    if stopped:
                        d.desc_last_message = "Đã dừng sửa mô tả"
                    elif untouched and stats.get("done", 0) == 0:
                        d.desc_last_message = f"Phiên HTTP chưa dùng được • {len(untouched)} mục vẫn giữ CHỜ • xem ghi chú/log"
                    else:
                        d.desc_last_message = f"Sửa mô tả xong • {stats.get('done',0)}/{stats.get('total',0)} • lỗi {stats.get('error',0)}"
            except Exception as exc:
                d.append_log(f"[desc-http] FATAL • {exc}")
                _persist_diag(f"[desc-http] FATAL {type(exc).__name__}: {str(exc)[:260]}")
                with d.desc_lock:
                    # Leave untouched jobs queued so the user can retry after auth/session recovery.
                    for j in jobs_to_run:
                        if j.get("status") == "running":
                            j["status"] = "queued"; j["note"] = f"HTTP engine dừng: {str(exc)[:160]}"
                    d.desc_stats = d._desc_compute_stats()
                    d.desc_last_message = f"HTTP engine lỗi: {str(exc)[:160]}"
            finally:
                if run_id == self._desc_http_run_id:
                    d.desc_running = False
                    d.desc_operation = "idle"
                try:
                    d.append_log(f"[desc-http] DONE • {d.desc_last_message}")
                    _persist_diag(f"[desc-http] DONE {d.desc_last_message}")
                except Exception:
                    pass

        threading.Thread(target=run_all, name=f"DescriptionHTTP-{run_id}", daemon=True).start()
        return {
            "ok": True, "started": True, "jobs": len(jobs_to_run), "workers_requested": requested,
            "http_ready_now": cached_now, "preparing": cached_now < min(requested, len(jobs_to_run)),
            "engine": "Gemini Web Direct HTTP", "selenium_rewrite": False,
        }

    def _description_http_stop_now(self):
        self._desc_http_stop.set()
        d = self.dashboard
        if str(getattr(d, "desc_operation", "")) == "rewrite_http":
            d.desc_last_message = "Đang dừng HTTP Direct…"
        return {"ok": True}

    def execute(self, action: str, args: dict):
        d = self.dashboard
        if action not in ("snapshot", "status"):
            _persist_diag(f"[RPC] START action={action}")
        if action in ("snapshot", "status"):
            return self.snapshot(args)
        if action == "ping":
            return {"ok": True, "version": str(getattr(dashmod, "APP_VERSION", "13.54"))}
        if action == "config.set":
            if "workers" in args:
                d.worker_spin.setValue(max(1, min(50, int(args["workers"]))))
            if "model" in args:
                model = str(args["model"] or "auto").lower()
                idx = d.thumb_model_combo.findData(model)
                if idx >= 0:
                    d.thumb_model_combo.setCurrentIndex(idx)
            if "proxy_enabled" in args:
                want = bool(args.get("proxy_enabled"))
                if bool(d._is_proxy_enabled()) != want:
                    d._toggle_proxy_enabled()
            d.save_state()
            return self.snapshot({"job_limit": 1, "desc_limit": 1, "log_limit": 20})
        if action == "queue.set":
            idx = int(args.get("index", -1))
            root = str(args.get("root") or "").strip()
            logo = str(args.get("logo") or "").strip()
            d.add_project_queue_item_to_slot(idx, root, logo, status=str(args.get("status") or "chờ"))
            d.save_state()
            self._persist_queue_sources_v14(reason=f"queue-set-{idx+1}")
            return {"ok": True}
        if action == "queue.remove":
            idx = int(args.get("index", -1))
            d.remove_project_queue_item_at(idx, ask=False)
            d.save_state()
            self._persist_queue_sources_v14(reason=f"queue-remove-{idx+1}")
            return {"ok": True}
        if action == "queue.scan":
            d.scan_project_queue_only()
            return {"ok": True, "started": True}
        if action == "queue.start":
            # V16: run with the READY/profile-cache pool immediately; do not require all vault accounts.
            return self._begin_prelogin_gate(run_after=True)
        if action == "queue.stop":
            self._cancel_prelogin_gate("Đã dừng đăng nhập kho / Queue")
            d.stop_all(silent=False)
            return {"ok": True, "prelogin": self._prelogin_snapshot()}
        if action == "queue.create_thumbs":
            idx = int(args.get("index", -1)); count = max(1, min(200, int(args.get("count", 4) or 4)))
            d._ensure_project_queue_slots(); q = d.project_queue[idx]
            root = Path(str(q.get("root") or ""))
            if d.running or d.desc_running:
                raise RuntimeError("Hãy dừng worker trước khi tạo thumbnail từ gốc")
            if not root.exists():
                raise RuntimeError("Thư mục Queue không tồn tại")
            thumbs = dashmod.find_thumbnail_jpg_files(root)
            written = ok = failed = 0
            for thumb in thumbs:
                try:
                    data = d._png_data_from_thumb_source(thumb)
                    for n in range(count):
                        out = Path(thumb).parent / f"thumbnail-original-{n}-final.png"
                        out.write_bytes(data); written += 1
                    ok += 1
                except Exception as exc:
                    failed += 1; d.append_log(f"[web-thumb-factory] ERROR • {thumb} • {exc}")
            d.append_log(f"[web-thumb-factory] Queue #{idx+1} • file={written} • folder_ok={ok} • error={failed}")
            d.scan_project_queue_only()
            return {"ok": True, "written": written, "folders_ok": ok, "folders_error": failed}
        if action == "queue.restore":
            idx = int(args.get("index", -1)); d._ensure_project_queue_slots()
            if idx < 0 or idx >= len(d.project_queue):
                raise RuntimeError("Queue không hợp lệ")
            q = d.project_queue[idx]
            root = Path(str(q.get("root") or ""))
            # Description Studio only edits description.txt and must NOT block a
            # thumbnail-file restore. Older builds incorrectly treated desc_running
            # as a thumbnail worker and made the Queue restore button look dead.
            live_worker = False
            try:
                live_worker = bool(d._has_live_worker_process())
            except Exception:
                live_worker = False
            job_busy = any(str(j.get("status") or "").lower() in {"running", "reserved"} for j in list(getattr(d, "jobs", []) or []))
            if live_worker or job_busy:
                raise RuntimeError("Thumbnail worker vẫn đang chạy nền. Đợi worker kết thúc rồi Phục hồi lại.")
            if not root.exists():
                raise RuntimeError("Thư mục Queue không tồn tại")
            thumbs = dashmod.find_thumbnail_jpg_files(root)
            if not thumbs:
                raise RuntimeError("Không tìm thấy thumbnail.jpg nào trong Queue để phục hồi")
            d.append_log(f"[web-restore] START • Queue #{idx+1} • root={root} • thumbs={len(thumbs)} • desc_running={int(bool(getattr(d,'desc_running',False)))}")
            ok = failed = 0
            for thumb in thumbs:
                try:
                    size_kb, outputs = dashmod.restore_original_thumbnail_set(thumb); ok += 1
                    d.append_log(f"[web-restore] OK • {thumb} • outputs={len(outputs)} • ~{size_kb:.1f}KB")
                except Exception as exc:
                    failed += 1; d.append_log(f"[web-restore] ERROR • {thumb} • {exc}")
            d.append_log(f"[web-restore] DONE • Queue #{idx+1} • OK={ok} • error={failed}")
            d.scan_project_queue_only()
            return {"ok": True, "folders_ok": ok, "folders_error": failed, "folders_total": len(thumbs)}
        if action == "thumb.restore_paths":
            # V22: không cho restore khi Qt flag đã idle nhưng worker process cũ vẫn còn sống.
            # Đây là race đã thấy trong log V21: UI báo xong, restore xảy ra trong lúc W9/W13/W14 còn chạy.
            _live_worker = False
            try:
                _live_worker = bool(d._has_live_worker_process())
            except Exception:
                _live_worker = False
            if d.running or _live_worker:
                raise RuntimeError("Worker Thumbnail vẫn đang đóng/chạy nền. Đợi trạng thái Hoàn tất hẳn rồi Phục hồi lại (không cần bấm Dừng nếu đang ở bước đóng worker).")
            paths = {str(x).lower() for x in (args.get("paths") or [])}
            d.append_log(f"[V22-RESTORE] START • selected={len(paths)} • worker_live=0")
            ok = failed = 0
            for j in list(d.jobs or []):
                if str(j.get("image_path") or "").lower() not in paths:
                    continue
                try:
                    d._restore_job_original_now(j); ok += 1
                except Exception as exc:
                    failed += 1; d.append_log(f"[web-restore-one] ERROR • {j.get('image_path')} • {exc}")
            d.refresh_stats(); d.request_preview_refresh(force=True)
            d.append_log(f"[V22-RESTORE] DONE • restored={ok} • errors={failed} • các job restored đã về queued để vẽ lại")
            return {"ok": True, "restored": ok, "errors": failed}
        if action == "thumb.open_folder":
            path = Path(str(args.get("path") or ""))
            folder = path if path.is_dir() else path.parent
            if not folder.exists():
                raise RuntimeError("Thư mục không tồn tại")
            if os.name == "nt": os.startfile(str(folder))
            return {"ok": True}
        if action == "brand.generate_names":
            w = d._channel_brand_dialog
            key = str(args.get("key") or "").strip(); notes = str(args.get("notes") or "").strip()
            if not key: raise RuntimeError("Hãy nhập KEY / chủ đề chính")
            w.key_edit.setText(key); w.notes_edit.setPlainText(notes); w._start_generate_names(); return {"ok": True}
        if action == "brand.more_names":
            d._channel_brand_dialog._start_generate_more_names(); return {"ok": True}
        if action == "brand.select_name":
            name = str(args.get("name") or "").strip(); w = d._channel_brand_dialog
            found = -1
            for i, btn in enumerate(w._name_buttons):
                if str(btn.property("brand_name") or btn.text() or "").strip() == name:
                    found = i; break
            if found < 0: raise RuntimeError("Tên kênh không còn trong danh sách")
            w._select_name(found); return {"ok": True}
        if action == "brand.generate_logos":
            w = d._channel_brand_dialog
            if args.get("name"):
                name = str(args.get("name") or "").strip()
                for i, btn in enumerate(w._name_buttons):
                    if str(btn.property("brand_name") or btn.text() or "").strip() == name:
                        w._select_name(i); break
            w._start_generate_logo(); return {"ok": True}
        if action == "brand.swap_logo":
            d._channel_brand_dialog._swap_logo_preview(int(args.get("index", -1))); return {"ok": True}
        if action == "brand.select_logo":
            idx = int(args.get("index", -1)); w = d._channel_brand_dialog
            w._select_logo(idx); return {"ok": True}
        if action == "brand.export_logo":
            idx = int(args.get("index", -1)); dest_root = Path(str(args.get("folder") or "").strip())
            w = d._channel_brand_dialog
            if idx < 0 or idx >= len(w._all_logo_paths):
                raise RuntimeError("Logo không hợp lệ")
            src = Path(str(w._all_logo_paths[idx] or ""))
            if not src.is_file():
                raise RuntimeError("Logo chưa sẵn sàng")
            if not dest_root.is_dir():
                raise RuntimeError("Thư mục đích không tồn tại")
            channel = w._selected_logo_channel_name or w._selected_name or "channel_logo"
            name = w._safe_logo_slug(channel) + "_" + src.name
            dest = dest_root / name
            import shutil
            shutil.copy2(src, dest)
            w._select_logo(idx)
            w._set_status(f"Đã tải logo: {dest.name}")
            return {"ok": True, "path": str(dest)}
        if action == "brand.export_all":
            dest_root = Path(str(args.get("folder") or "").strip()); w = d._channel_brand_dialog
            if not dest_root.is_dir():
                raise RuntimeError("Thư mục đích không tồn tại")
            channel = w._selected_logo_channel_name or w._selected_name or "channel_logo"
            slug = w._safe_logo_slug(channel); count = 0; paths = []
            import shutil
            for i, raw in enumerate(list(w._all_logo_paths or []), start=1):
                src = Path(str(raw or ""))
                if not src.is_file():
                    continue
                dest = dest_root / f"{slug}_logo_{i}.png"
                shutil.copy2(src, dest); count += 1; paths.append(str(dest))
            if not count:
                raise RuntimeError("Chưa có logo nào để tải")
            w._set_status(f"Đã tải {count} logo vào: {dest_root}")
            return {"ok": True, "count": count, "paths": paths}
        if action == "brand.open_folder":
            d._channel_brand_dialog._open_output_folder(); return {"ok": True}
        if action == "description.set_roots":
            roots = [str(x).strip() for x in (args.get("roots") or []) if str(x).strip()]
            d.desc_custom_roots = list(dict.fromkeys(roots)); d.save_state(); d._refresh_description_sources_ui(force=True)
            return {"ok": True}
        if action == "description.set_language":
            lang = str(args.get("language") or "English").strip() or "English"
            d.desc_translate_language = lang
            try:
                idx = d.desc_language_combo.findText(lang)
                if idx >= 0: d.desc_language_combo.setCurrentIndex(idx)
                else: d.desc_language_combo.setCurrentText(lang)
            except Exception: pass
            d.save_state(); return {"ok": True}
        if action == "description.scan":
            jobs = d._scan_description_jobs_sync()
            with d.desc_lock:
                d.desc_jobs = jobs; d.desc_stats = d._desc_compute_stats(); d.desc_last_message = f"Đã quét {len(jobs)} mô tả"
            d._refresh_description_workspace(); return {"ok": True, "count": len(jobs)}
        if action in ("description.rewrite", "description.rewrite_http"):
            return self._description_http_start(paths=args.get("paths") or [], model=args.get("model") or "auto", workers=args.get("workers"))
        if action == "description.stop":
            if str(getattr(d, "desc_operation", "")) == "rewrite_http":
                return self._description_http_stop_now()
            d.stop_description_only(); return {"ok": True}
        if action == "description.restore_all":
            d.restore_original_descriptions(); return {"ok": True}
        if action == "description.check_paths":
            d.desc_checked_paths = {str(x) for x in (args.get("paths") or [])}
            return {"ok": True, "count": len(d.desc_checked_paths)}
        if action == "description.select_vietnamese":
            if not getattr(d, "desc_jobs", None):
                d.desc_jobs = d._scan_description_jobs_sync()
            selected = []
            for job in list(getattr(d, "desc_jobs", []) or []):
                raw = str(job.get("description_path") or "").strip()
                if not raw:
                    continue
                path = Path(raw)
                if not path.is_file():
                    continue
                try:
                    text = path.read_text(encoding="utf-8-sig", errors="ignore")
                except Exception:
                    text = ""
                if d._description_is_vietnamese_text(text):
                    selected.append(str(path))
            d.desc_checked_paths = {x.lower() for x in selected}
            d.desc_last_message = f"Đã chọn {len(selected)} mô tả tiếng Việt để dịch"
            try:
                d._description_update_checked_ui()
            except Exception:
                pass
            return {"ok": True, "paths": selected, "count": len(selected)}
        if action == "description.translate_selected":
            d.desc_checked_paths = {str(x) for x in (args.get("paths") or [])}
            if args.get("language"):
                d.desc_translate_language = str(args.get("language"))
                try: d.desc_language_combo.setCurrentText(d.desc_translate_language)
                except Exception: pass
            d.start_description_translation(selected_only="multi"); return {"ok": True}
        if action == "description.read":
            p = Path(str(args.get("path") or ""))
            if not p.is_file(): raise RuntimeError("description.txt không tồn tại")
            current = p.read_text(encoding="utf-8-sig", errors="ignore")
            first = d._description_first_backup_path(p, create_from_text=None)
            original = Path(first).read_text(encoding="utf-8-sig", errors="ignore") if first and Path(first).is_file() else current
            return {"ok": True, "path": str(p), "folder": str(p.parent), "current": current, "original": original}
        if action == "description.save":
            p = Path(str(args.get("path") or "")); text = str(args.get("text") or "").strip()
            if d.desc_running: raise RuntimeError("Đang chạy sửa/dịch mô tả")
            if not p.is_file(): raise RuntimeError("description.txt không tồn tại")
            if not text: raise RuntimeError("Mô tả không được để trống")
            old = p.read_text(encoding="utf-8-sig", errors="ignore"); d._description_first_backup_path(p, create_from_text=old)
            p.write_text(text.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
            j = self._find_desc_job(str(p))
            if j is not None:
                st, note = d._description_persisted_status(p, text); j["status"] = st; j["note"] = "Đã lưu thủ công" if st == "done" else note; j["preview"] = " ".join(text.split())[:320]; j["size"] = len(text)
                d.desc_stats = d._desc_compute_stats()
            return {"ok": True}
        if action == "description.restore_one":
            p = Path(str(args.get("path") or "")); first = d._description_first_backup_path(p, create_from_text=None)
            if not first or not Path(first).is_file(): raise RuntimeError("Mục này chưa có backup mô tả gốc")
            text = Path(first).read_text(encoding="utf-8-sig", errors="ignore"); p.write_text(text.rstrip("\n") + "\n", encoding="utf-8")
            j = self._find_desc_job(str(p))
            if j is not None: j["status"]="queued"; j["note"]="Đã khôi phục mô tả gốc"; j["preview"]=" ".join(text.split())[:320]; j["size"]=len(text); d.desc_stats=d._desc_compute_stats()
            return {"ok": True}
        if action == "description.undo_translation":
            p = Path(str(args.get("path") or "")); backup = d._description_latest_translation_backup(p)
            if not backup or not Path(backup).is_file(): raise RuntimeError("Không tìm thấy backup dịch gần nhất")
            text = Path(backup).read_text(encoding="utf-8-sig", errors="ignore"); p.write_text(text.rstrip("\n")+"\n", encoding="utf-8")
            return {"ok": True}
        if action == "description.open_folder":
            p = Path(str(args.get("path") or "")); folder = p.parent
            if os.name == "nt" and folder.exists(): os.startfile(str(folder))
            return {"ok": True}
        if action == "accounts.check_all":
            d.append_log("[web-check-all] MANUAL START • headless • chỉ chạy khi người dùng bấm Kiểm tra tất cả")
            d.check_all(); return {"ok": True}
        if action == "accounts.check":
            acc = int(args.get("account_no")); row = next((r for r in d.rows if int(r.account_no()) == acc), None)
            if row is None: raise RuntimeError("Không tìm thấy tài khoản")
            d.check_account_row_hidden(row); return {"ok": True}
        if action == "accounts.login":
            acc = int(args.get("account_no")); row = next((r for r in d.rows if int(r.account_no()) == acc), None)
            if row is None: raise RuntimeError("Không tìm thấy tài khoản")
            if not d.start_login_assist_for_row(row): row.login_manual()
            return {"ok": True}
        if action in ("accounts.login_all", "accounts.prelogin_all"):
            self._reconcile_rows_to_vault(save=False)
            return self._begin_prelogin_gate(run_after=False)
        if action == "accounts.stop_login":
            self._cancel_prelogin_gate("Đã dừng đăng nhập toàn bộ kho")
            return {"ok": True, "prelogin": self._prelogin_snapshot()}
        if action == "accounts.remove":
            acc = int(args.get("account_no"))
            vault = d._load_login_vault(); vault.setdefault("accounts", {})
            vault["accounts"].pop(f"google_{acc}", None)
            if not d._save_login_vault(vault):
                raise RuntimeError("Không lưu được login vault sau khi xóa")
            self._invalidate_vault_records_cache("remove-account")
            self._persist_vault_v10(vault, reason="remove-account")
            self._reconcile_rows_to_vault(save=True)
            self._cancel_prelogin_gate(f"Kho tài khoản đã thay đổi • cần kiểm tra lại trước khi chạy")
            return {"ok": True, "prelogin": self._prelogin_snapshot()}
        if action == "accounts.remove_many":
            # MyingGo: xoá nhiều tài khoản trong 1 lần ghi vault (tránh đánh số lại giữa chừng)
            accs = {int(x) for x in (args.get("account_nos") or [])}
            vault = d._load_login_vault(); vault.setdefault("accounts", {})
            removed = []
            for acc in sorted(accs):
                rec = vault["accounts"].pop(f"google_{acc}", None)
                if rec is not None:
                    removed.append({"account_no": acc, "email": str(rec.get("email") or "")})
            if removed:
                if not d._save_login_vault(vault):
                    raise RuntimeError("Không lưu được login vault sau khi xóa")
                self._invalidate_vault_records_cache("remove-many")
                self._persist_vault_v10(vault, reason="remove-many")
                self._reconcile_rows_to_vault(save=True)
                self._cancel_prelogin_gate(f"Đã xoá {len(removed)} tài khoản lỗi • cần kiểm tra lại trước khi chạy")
            return {"ok": True, "removed": removed, "prelogin": self._prelogin_snapshot()}
        if action == "accounts.move":
            acc = int(args.get("account_no")); delta = int(args.get("delta", 0)); row = next((r for r in d.rows if int(r.account_no()) == acc), None)
            if row is not None: d.move_account_row(row, delta)
            return {"ok": True}
        if action in ("accounts.import_txt", "accounts.import_text"):
            replace = bool(args.get("replace", True))
            if action == "accounts.import_txt":
                p = Path(str(args.get("path") or ""))
                if not p.is_file():
                    raise RuntimeError("Không tìm thấy file TXT")
                text = p.read_text(encoding="utf-8-sig", errors="ignore")
                source_name = str(p)
            else:
                text = str(args.get("text") or "")
                source_name = "web-paste"
            # V8 warehouse format is intentionally strict and simple:
            #   email<TAB>password<TAB>recovery_email
            # Exactly one valid TXT line becomes exactly one account. No legacy pipe/colon parser,
            # no old UI rows, and no google_N inference are involved.
            items, invalid_lines = _parse_tab_account_warehouse(text, start_google=1)
            if not items:
                raise RuntimeError("Không đọc được tài khoản nào. TXT phải đúng 3 cột TAB: mail<TAB>pass<TAB>email khôi phục; mỗi tài khoản đúng 1 dòng.")

            if replace:
                # V14 FAST REPLACE: parse first, backup old vault, then replace the canonical JSON
                # immediately.  Do NOT synchronously destroy/recreate hundreds of hidden Qt rows
                # inside this RPC: that was why the Web button could spin for a very long time.
                old_vault = d._load_login_vault() or {"version": 1, "accounts": {}}
                old_count = len((old_vault.get("accounts") or {}))
                try:
                    d.append_log(f"[web-account-warehouse] IMPORT START • source={source_name} • old={old_count} • parsed={len(items)}")
                except Exception:
                    pass
                if old_count:
                    try:
                        backup = BASE / f"login_vault.before_web_v14_replace_{time.strftime('%Y%m%d_%H%M%S')}.json"
                        backup.write_text(json.dumps(old_vault, ensure_ascii=False, indent=2), encoding="utf-8")
                    except Exception:
                        pass
                vault = {"version": 1, "accounts": {}}
            else:
                old_count = len(((d._load_login_vault() or {}).get("accounts") or {}))
                vault = d._load_login_vault()
                vault.setdefault("version", 1)
                vault.setdefault("accounts", {})
                # MyingGo: chế độ THÊM — đánh số tiếp sau tài khoản cuối và bỏ email đã có,
                # tránh ghi đè google_1..N của kho cũ.
                _have = {str((r or {}).get("email") or "").strip().lower() for r in vault["accounts"].values()}
                _nums = [int(str(k).split("_", 1)[1]) for k in vault["accounts"] if str(k).startswith("google_") and str(k).split("_", 1)[1].isdigit()]
                _next = (max(_nums) + 1) if _nums else 1
                _fresh = []
                for _acc, _email, _pw, _rec in items:
                    _e = str(_email).strip().lower()
                    if _e in _have:
                        continue
                    _have.add(_e)
                    _fresh.append((_next, _email, _pw, _rec))
                    _next += 1
                items = _fresh

            imported = 0
            for acc, email, password, recovery_email in items:
                vault["accounts"][f"google_{int(acc)}"] = {
                    "email": email,
                    "password": dashmod._dpapi_protect_text(password),
                    "recovery_email": recovery_email,
                    "imported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                }
                imported += 1
            if not d._save_login_vault(vault):
                raise RuntimeError("Không lưu được login vault")
            self._invalidate_vault_records_cache("import-txt-replace")
            if not self._persist_vault_v10(vault, reason="import-txt-replace"):
                raise RuntimeError("Đã ghi login_vault.json nhưng không lưu được kho tài khoản bền V12 ngoài thư mục cài đặt")
            # V14: respond to the Web UI first; reconcile the legacy hidden Qt rows on the next
            # event-loop tick. Snapshot/account rendering already reads the new canonical Vault,
            # so there is no reason to block the import RPC while 200+ widgets are removed/rebuilt.
            QTimer.singleShot(80, lambda n=imported: self._post_import_reconcile_v14(n))
            # New warehouse means old account-number history/quota/pool must not leak into the new
            # credentials. Reset only account metadata; Chrome profile folders are intentionally kept.
            for sidecar, empty_payload in (() if not replace else (
                (BASE / "account_selection_history.json", {"version":"13.48.2","updated_at":time.strftime("%Y-%m-%dT%H:%M:%S"),"accounts":{},"note":"Reset by Web V8 warehouse replace"}),
                (BASE / "account_quota_hold_today.json", {"version":"13.54","date":"","accounts":[],"details":{},"note":"Reset by Web V8 warehouse replace"}),
            )):
                try:
                    sidecar.write_text(json.dumps(empty_payload, ensure_ascii=False, indent=2), encoding="utf-8")
                except Exception:
                    pass
            self._cancel_prelogin_gate(f"Đã nhập kho mới {imported} tài khoản • cần đăng nhập trước khi chạy")
            # Important: keep the user's stock TXT untouched. The legacy tool renamed it to
            # *.imported_delete_me; warehouse mode intentionally does not modify the source file.
            try:
                (BASE / ".vault_web_v4_migrated.json").write_text(json.dumps({
                    "version": 4, "at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "restored": False, "mode": "user-import", "live_after": imported, "source": source_name
                }, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
            valid_lines = imported
            skipped_lines = len(invalid_lines)
            d.append_log(f"[web-account-warehouse] V14 FAST TAB3 REPLACE OK • old={old_count} → new={imported} • valid_lines={valid_lines} • skipped={skipped_lines} • source={source_name} • source_kept=YES • post_sync=DEFERRED")
            return {"ok": True, "imported": imported, "old_count": old_count, "new_count": imported, "valid_lines": valid_lines, "skipped_lines": skipped_lines, "invalid_lines": invalid_lines[:20], "replace": replace, "source_kept": True, "persisted": True, "format": "email<TAB>password<TAB>recovery_email", "prelogin": self._prelogin_snapshot()}
        if action == "shutdown":
            QTimer.singleShot(50, QApplication.instance().quit)
            return {"ok": True}
        raise RuntimeError(f"Unknown action: {action}")


class RpcHandler(BaseHTTPRequestHandler):
    dispatcher: Dispatcher = None
    token: str = ""

    def log_message(self, fmt, *args):
        return

    def _json(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers(); self.wfile.write(data)

    def _authorized(self):
        return secrets.compare_digest(str(self.headers.get("X-Thumb-Token") or ""), self.token)

    def do_GET(self):
        if urlparse(self.path).path == "/health":
            if not self._authorized(): return self._json(403, {"ok": False})
            return self._json(200, {"ok": True, "pid": os.getpid(), "version": str(getattr(dashmod, "APP_VERSION", "13.54")), "build": WEB_BRIDGE_BUILD})
        return self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        if urlparse(self.path).path != "/rpc": return self._json(404, {"ok": False, "error": "not found"})
        if not self._authorized(): return self._json(403, {"ok": False, "error": "forbidden"})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
            action = str(body.get("action") or "")
            args = body.get("args") or {}
            timeout = float(body.get("timeout") or 45)
            result = self.dispatcher.invoke(action, args, timeout=timeout)
            self._json(200, {"ok": True, "result": result})
        except Exception as exc:
            self._json(500, {"ok": False, "error": str(exc)})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--info-file", required=True)
    ap.add_argument("--port", type=int, default=0)
    ns = ap.parse_args()

    app = QApplication(sys.argv)
    app.setApplicationName("Gemini Studio Web Engine")
    dash = dashmod.QtDashboard()
    dash.setWindowTitle("Gemini Studio Web Engine")
    dash.hide()
    dispatcher = Dispatcher(dash)
    try:
        dash.append_log(f"[web-engine] V66 READY • build={WEB_BRIDGE_BUILD} • FAST ACCOUNT LOAD • LOGIN x3 • CHECK x8 • PROGRESS % • CHECK COLOR • RESTORE/REDRAW RACE SAFE • RUN PROGRESSIVE CHECK • START WHEN N READY • BACKGROUND CHECK CONTINUES • READY STATE PERSIST • NO GLOBAL CHROME KILL")
    except Exception:
        pass

    token = secrets.token_urlsafe(32)
    RpcHandler.dispatcher = dispatcher
    RpcHandler.token = token
    server = ThreadingHTTPServer(("127.0.0.1", int(ns.port or 0)), RpcHandler)
    port = int(server.server_address[1])
    info_path = Path(ns.info_file)
    info = {"pid": os.getpid(), "port": port, "token": token, "started_at": time.time(), "version": str(getattr(dashmod, "APP_VERSION", "13.54")), "mode": "web-engine", "build": WEB_BRIDGE_BUILD}
    tmp = info_path.with_suffix(info_path.suffix + ".tmp")
    tmp.write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(info_path)
    print(f"THUMB_WEB_ENGINE_READY port={port} pid={os.getpid()}", flush=True)

    th = threading.Thread(target=server.serve_forever, name="ThumbWebRPC", daemon=True)
    th.start()

    def _shutdown(*_):
        try: server.shutdown()
        except Exception: pass
        QTimer.singleShot(0, app.quit)

    try:
        signal.signal(signal.SIGTERM, _shutdown)
        signal.signal(signal.SIGINT, _shutdown)
    except Exception:
        pass
    rc = app.exec()
    try: server.shutdown(); server.server_close()
    except Exception: pass
    try: dash.stop_all(silent=True)
    except Exception: pass
    try: info_path.unlink(missing_ok=True)
    except Exception: pass
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
