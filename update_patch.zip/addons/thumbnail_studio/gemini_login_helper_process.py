# -*- coding: utf-8 -*-
"""Subprocess login helper for Gemini tool.
Runs Selenium auto-login outside the Qt dashboard process so ChromeDriver native crashes do not kill the GUI.
"""
import os, sys, json, traceback, importlib.util
from pathlib import Path


def _emit_log(msg):
    try:
        print("__LOG__" + str(msg), flush=True)
    except Exception:
        pass


_RESULT_PATH = None


def _write_result_file(ok, msg):
    try:
        if _RESULT_PATH:
            Path(str(_RESULT_PATH)).write_text(json.dumps({"ok": bool(ok), "msg": str(msg)}, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def _emit_result(ok, msg):
    try:
        _write_result_file(ok, msg)
        print("__RESULT__" + json.dumps({"ok": bool(ok), "msg": str(msg)}, ensure_ascii=False), flush=True)
    except Exception:
        try:
            _write_result_file(False, "emit result failed")
        except Exception:
            pass
        print("__RESULT__" + json.dumps({"ok": False, "msg": "emit result failed"}), flush=True)


def main():
    if len(sys.argv) < 2:
        _emit_result(False, "missing config path")
        return 2
    cfg_path = Path(sys.argv[1])
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    global _RESULT_PATH
    _RESULT_PATH = cfg.get("result_path") or os.environ.get("GEMINI_LOGIN_HELPER_RESULT_PATH") or ""
    os.environ["GEMINI_LOGIN_HELPER_SUBPROCESS"] = "0"
    os.environ["GEMINI_LOGIN_HELPER_CHILD"] = "1"
    os.environ.setdefault("GEMINI_HELPER_NO_QT_IMPORT", "1")
    os.environ["GEMINI_SERIALIZE_WEBDRIVER_LIFECYCLE"] = "1"
    # Keep helper's own remote quit disabled too. Parent will survive even if helper aborts.
    os.environ.setdefault("GEMINI_USE_REMOTE_DRIVER_QUIT", "0")
    os.environ["GEMINI_KEEP_LOGIN_CHROME_ON_FAIL"] = os.environ.get("GEMINI_KEEP_LOGIN_CHROME_ON_FAIL", "0")
    dashboard_py = Path(cfg.get("dashboard_py") or (Path(__file__).with_name("hybrid_flow_gemini_dashboard.py")))
    spec = importlib.util.spec_from_file_location("gemini_dashboard_login_mod", str(dashboard_py))
    if spec is None or spec.loader is None:
        _emit_result(False, "cannot import dashboard module")
        return 3
    mod = importlib.util.module_from_spec(spec)
    sys.modules["gemini_dashboard_login_mod"] = mod
    try:
        spec.loader.exec_module(mod)
    except BaseException as e:
        _emit_log("helper import dashboard failed: " + traceback.format_exc(limit=10))
        _emit_result(False, f"helper import failed {type(e).__name__}: {str(e)[:180]}")
        return 4
    try:
        ok, msg = mod._auto_google_login_once_direct(
            Path(cfg.get("chrome_binary", "")),
            Path(cfg.get("driver_binary", "")),
            Path(cfg.get("profile_dir", "")),
            cfg.get("email", ""),
            cfg.get("password", ""),
            cfg.get("recovery_email", ""),
            log_fn=_emit_log,
            stop_event=None,
            hidden=bool(cfg.get("hidden", False)),
            proxy_value=cfg.get("proxy_value") or None,
        )
        _emit_result(ok, msg)
        return 0 if ok else 1
    except Exception as e:
        _emit_log("helper exception: " + traceback.format_exc(limit=8))
        _emit_result(False, f"helper exception {type(e).__name__}: {str(e)[:180]}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
