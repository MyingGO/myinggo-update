"""MyingGo • Gemini API cho Thumbnail Studio.

- Vẽ thumbnail bằng Gemini API (Nano Banana / gemini-2.5-flash-image …) khi tài khoản web bị giới hạn.
- Quét logo/watermark trong ảnh gốc (gemini-2.5-flash, trả JSON toạ độ) và xoá logo không liên quan.
- Chuẩn hoá ảnh cuối giống worker gốc: 16:9, tối thiểu 1280x720, chèn logo góc phải dưới, PNG > 2.05MB
  (để engine nhận là đã vẽ xong: file > 1.5MB => "Bỏ qua").
"""
import base64
import io
import json
import os
import re
import threading
import time
import zlib
from pathlib import Path

import requests
from PIL import Image

API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"
IMAGE_MODELS = ["gemini-2.5-flash-image", "gemini-3-pro-image-preview"]
DETECT_MODEL = "gemini-2.5-flash"
FINAL_MIN_BYTES = int(2.05 * 1024 * 1024)
ORIGINAL_MAX_BYTES = int(1.45 * 1024 * 1024)
LOGO_RIGHT_MARGIN, LOGO_BOTTOM_MARGIN = 50, 45
THUMB_RE = re.compile(r"^thumbnail-original-(\d+)-final\.(png|jpg|jpeg|webp)$", re.I)
LOGO_NAMES = ("logo.png", "logo.jpg", "logo.jpeg", "logo.webp")
SKIP_DIRS = {"_debug", "_v11_dashboard_runs", "_simple_parallel_runs", "outputs", "__pycache__", ".myinggo_logo_backup"}


class KeysExhausted(RuntimeError):
    pass


class RefusedError(RuntimeError):
    pass


def _mask(k):
    k = str(k or "")
    return k[:6] + "…" + k[-4:] if len(k) > 12 else "***"


class GeminiAPI:
    """Gọi Gemini REST với nhiều API key, tự xoay key khi gặp 429/hết quota."""

    def __init__(self, keys, image_model="gemini-2.5-flash-image", detect_model=DETECT_MODEL, log=print):
        self.keys = [k.strip() for k in (keys or []) if str(k).strip()]
        self.image_model = image_model or IMAGE_MODELS[0]
        self.detect_model = detect_model or DETECT_MODEL
        self.log = log
        self._lock = threading.Lock()
        self._cool = {}      # key -> thời điểm được dùng lại
        self._idx = 0
        self.stats = {k: {"ok": 0, "fail": 0, "last": ""} for k in self.keys}

    def key_status(self):
        now = time.time()
        return [{"key": _mask(k), "ok": self.stats[k]["ok"], "fail": self.stats[k]["fail"], "last": self.stats[k]["last"],
                 "cooldown": max(0, int(self._cool.get(k, 0) - now))} for k in self.keys]

    def _next_key(self):
        with self._lock:
            now = time.time()
            for _ in range(len(self.keys)):
                k = self.keys[self._idx % len(self.keys)]
                self._idx += 1
                if self._cool.get(k, 0) <= now:
                    return k
        return None

    def _cooldown(self, key, seconds, why):
        with self._lock:
            self._cool[key] = time.time() + seconds
            self.stats[key]["fail"] += 1
            self.stats[key]["last"] = why[:160]
        self.log(f"[API] key {_mask(key)} tạm nghỉ {int(seconds)}s • {why[:140]}")

    def _post(self, model, body, timeout=180):
        if not self.keys:
            raise KeysExhausted("Chưa nhập Gemini API key")
        last = ""
        for _ in range(max(1, len(self.keys)) * 2):
            key = self._next_key()
            if not key:
                wait = min(self._cool.values()) - time.time() if self._cool else 0
                raise KeysExhausted(f"Tất cả API key đang bị giới hạn (thử lại sau ~{max(1, int(wait))}s). {last}")
            try:
                r = requests.post(f"{API_BASE}/{model}:generateContent", json=body, timeout=timeout,
                                  headers={"x-goog-api-key": key, "Content-Type": "application/json"})
            except requests.RequestException as e:
                last = f"Mạng lỗi: {e}"
                time.sleep(2)
                continue
            if r.status_code == 200:
                with self._lock:
                    self.stats[key]["ok"] += 1
                    self.stats[key]["last"] = "OK"
                return r.json()
            txt = r.text[:600]
            last = f"HTTP {r.status_code}: {txt}"
            low = txt.lower()
            if r.status_code == 429 or "resource_exhausted" in low or "quota" in low:
                per_day = "perday" in low.replace(" ", "").replace("_", "") or "per day" in low or "daily" in low
                self._cooldown(key, 6 * 3600 if per_day else 65, last)
                continue
            if r.status_code in (401, 403) or "api key not valid" in low or "permission" in low:
                self._cooldown(key, 24 * 3600, last)
                continue
            if r.status_code in (500, 502, 503, 504):
                time.sleep(3)
                continue
            raise RuntimeError(last)
        raise KeysExhausted(last or "Không gọi được Gemini API")

    @staticmethod
    def _img_part(data, mime="image/png"):
        return {"inline_data": {"mime_type": mime, "data": base64.b64encode(data).decode("ascii")}}

    def edit_image(self, image_bytes, prompt, mime="image/png", aspect="16:9"):
        body = {
            "contents": [{"role": "user", "parts": [{"text": prompt}, self._img_part(image_bytes, mime)]}],
            "generationConfig": {"responseModalities": ["TEXT", "IMAGE"], "imageConfig": {"aspectRatio": aspect}},
        }
        data = self._post(self.image_model, body)
        texts = []
        for cand in data.get("candidates") or []:
            for part in (cand.get("content") or {}).get("parts") or []:
                inline = part.get("inlineData") or part.get("inline_data")
                if inline and inline.get("data"):
                    return base64.b64decode(inline["data"])
                if part.get("text"):
                    texts.append(part["text"])
            if cand.get("finishReason") and cand.get("finishReason") not in ("STOP", "MAX_TOKENS"):
                texts.append(f"finishReason={cand.get('finishReason')}")
        fb = data.get("promptFeedback") or {}
        if fb.get("blockReason"):
            texts.append(f"blockReason={fb['blockReason']}")
        raise RefusedError("Gemini không trả ảnh: " + (" | ".join(texts)[:300] or "phản hồi rỗng"))

    def detect_logos(self, image_bytes, mime="image/jpeg"):
        prompt = (
            "You are checking a YouTube music thumbnail. Find every logo, watermark, channel badge, TV station mark, "
            "social media icon, URL/handle text or brand mark that is overlaid on the image. Do NOT list the singer, "
            "the song title or artist name typography. For each item return label, box_2d as [ymin, xmin, ymax, xmax] "
            "normalised 0-1000, related (true only if it is clearly the official logo of the singer/song itself), and a "
            "short reason. Return an empty list if there are none."
        )
        body = {
            "contents": [{"role": "user", "parts": [{"text": prompt}, self._img_part(image_bytes, mime)]}],
            "generationConfig": {
                "responseMimeType": "application/json",
                "responseSchema": {
                    "type": "ARRAY",
                    "items": {"type": "OBJECT", "properties": {
                        "label": {"type": "STRING"},
                        "box_2d": {"type": "ARRAY", "items": {"type": "INTEGER"}},
                        "related": {"type": "BOOLEAN"},
                        "reason": {"type": "STRING"},
                    }, "required": ["label", "box_2d", "related"]},
                },
                "temperature": 0.1,
            },
        }
        data = self._post(self.detect_model, body, timeout=90)
        raw = ""
        for cand in data.get("candidates") or []:
            for part in (cand.get("content") or {}).get("parts") or []:
                raw += part.get("text") or ""
        try:
            items = json.loads(raw or "[]")
        except Exception:
            m = re.search(r"\[.*\]", raw, re.S)
            items = json.loads(m.group(0)) if m else []
        out = []
        for it in items if isinstance(items, list) else []:
            box = [int(x) for x in (it.get("box_2d") or [])[:4]] if isinstance(it, dict) else []
            if len(box) == 4:
                out.append({"label": str(it.get("label") or "logo"), "box": box, "related": bool(it.get("related")),
                            "reason": str(it.get("reason") or "")})
        return out

    def remove_logos(self, image_bytes, items, mime="image/jpeg"):
        desc = "; ".join(f"'{i['label']}' near box [ymin,xmin,ymax,xmax]={i['box']} (0-1000 scale)" for i in items)
        prompt = ("Remove ONLY these overlaid logos/watermarks from the image and fill each area naturally so it matches "
                  f"the surrounding background: {desc}. Keep everything else exactly identical: the singer, faces, text, "
                  "colours, composition and resolution. Return only the edited image.")
        with Image.open(io.BytesIO(image_bytes)) as im:
            w, h = im.size
        aspect = _closest_aspect(w, h)
        return self.edit_image(image_bytes, prompt, mime=mime, aspect=aspect)


def _closest_aspect(w, h):
    opts = {"16:9": 16 / 9, "9:16": 9 / 16, "1:1": 1.0, "4:3": 4 / 3, "3:4": 3 / 4, "3:2": 1.5, "2:3": 2 / 3, "21:9": 21 / 9}
    r = w / max(1, h)
    return min(opts, key=lambda k: abs(opts[k] - r))


# ----------------------------------------------------------------- xử lý ảnh
def _png_pad(png_bytes, extra):
    if extra <= 0 or not png_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
        return png_bytes
    i = png_bytes.rfind(b"IEND") - 4
    data = b"P" * int(extra)
    chunk = len(data).to_bytes(4, "big") + b"npAD" + data + (zlib.crc32(data, zlib.crc32(b"npAD")) & 0xFFFFFFFF).to_bytes(4, "big")
    return png_bytes[:i] + chunk + png_bytes[i:]


def normalize_16x9(img, min_w=1280, min_h=720):
    img = img.convert("RGB")
    w, h = img.size
    target = 16 / 9
    if abs(w / h - target) > 0.01:
        if w / h < target:
            nh = int(round(w / target)); top = (h - nh) // 2
            img = img.crop((0, top, w, top + nh))
        else:
            nw = int(round(h * target)); left = (w - nw) // 2
            img = img.crop((left, 0, left + nw, h))
        w, h = img.size
    if w < min_w or h < min_h:
        img = img.resize((min_w, int(round(min_w / target))), Image.Resampling.LANCZOS)
    return img


def add_logo(img, logo_path):
    if not logo_path or not Path(logo_path).is_file():
        return img
    base = img.convert("RGBA")
    with Image.open(logo_path) as lg:
        logo = lg.convert("RGBA")
    nw = max(36, int(base.width * 0.085))
    logo = logo.resize((nw, max(1, int(logo.height * nw / max(1, logo.width)))), Image.LANCZOS)
    base.alpha_composite(logo, (max(0, base.width - logo.width - LOGO_RIGHT_MARGIN), max(0, base.height - logo.height - LOGO_BOTTOM_MARGIN)))
    return base.convert("RGB")


def finalize_thumbnail(result_bytes, out_path, logo_path=""):
    with Image.open(io.BytesIO(result_bytes)) as im:
        img = normalize_16x9(im)
    img = add_logo(img, logo_path)
    buf = io.BytesIO()
    img.save(buf, "PNG", compress_level=1)
    data = buf.getvalue()
    if len(data) < FINAL_MIN_BYTES:
        data = _png_pad(data, FINAL_MIN_BYTES - len(data) + 80 * 1024)
    out = Path(out_path)
    tmp = out.with_name(out.name + ".mg_tmp")
    tmp.write_bytes(data)
    os.replace(tmp, out)
    return {"width": img.width, "height": img.height, "size_mb": round(len(data) / 1048576, 2)}


def png_under_limit(img, max_bytes=ORIGINAL_MAX_BYTES):
    img = img.convert("RGB")
    best = None
    for scale in (1.0, 0.9, 0.8, 0.7, 0.6, 0.5):
        work = img if scale == 1.0 else img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        work.save(buf, "PNG", optimize=True, compress_level=9)
        data = buf.getvalue()
        if best is None or len(data) < len(best):
            best = data
        if len(data) <= max_bytes:
            return data
    return best


# ----------------------------------------------------------------- quét file
def nearest_logo(folder, stop_root, fallback=""):
    cur, stop = Path(folder), Path(stop_root) if stop_root else None
    while True:
        for n in LOGO_NAMES:
            if (cur / n).is_file():
                return str(cur / n)
        if stop is None or os.path.normcase(str(cur)) == os.path.normcase(str(stop)) or cur.parent == cur:
            break
        try:
            Path(cur).relative_to(stop)
        except ValueError:
            break
        cur = cur.parent
    return fallback if fallback and Path(fallback).is_file() else ""


def scan_pending(queues, size_limit_mb=1.5):
    """Tìm các ảnh thumbnail-original-N-final chưa vẽ (<= 1.5MB) trong các Queue."""
    jobs = []
    for q in queues:
        root = Path(str(q.get("root") or ""))
        if not root.is_dir():
            continue
        for dp, dns, fns in os.walk(root):
            dns[:] = [d for d in dns if d.lower() not in SKIP_DIRS]
            for n in fns:
                if THUMB_RE.match(n):
                    p = Path(dp) / n
                    try:
                        if p.stat().st_size / 1048576 <= size_limit_mb:
                            jobs.append({"path": str(p), "logo": nearest_logo(dp, root, q.get("logo") or ""), "queue_index": q.get("index", -1)})
                    except OSError:
                        pass
    return jobs


def find_sources(root):
    out = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d.lower() not in SKIP_DIRS]
        for n in fns:
            if n.lower() == "thumbnail.jpg":
                out.append(str(Path(dp) / n))
    return sorted(out)
