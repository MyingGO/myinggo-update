# -*- coding: utf-8 -*-
r"""
Flow Auto Router Project X4 - compatible worker for Gemini Thumbnail Studio style dashboard.

Logic chính:
- 1 thư mục = 1 Flow project mới.
- Mỗi lần tạo chọn 16:9 + x4.
- Cần N file trong thư mục => tạo ceil(N/4) lần, lấy đúng N ảnh mới.
- Lưu đè vào các file thumbnail-original-*-final.* tương ứng.

Chạy độc lập ví dụ:
python flow_auto_router_project_x4_complete.py --root "D:\thumbs" --logo "D:\logo.png" --num-accounts 1 --chrome-binary "...\chrome.exe" --driver-path "...\chromedriver.exe"

Dùng với dashboard hiện tại:
- Đổi tên file này thành: gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py
- Sao lưu file Gemini cũ trước khi thay.
"""

import os
import sys
import re
import io
import json
import time
import threading
import math
import zlib
import base64
import hashlib
import shutil
import ctypes
import ctypes.wintypes
import argparse
import subprocess
import zipfile
from pathlib import Path
from urllib.parse import urljoin

import requests
from PIL import Image, ImageChops, ImageStat

try:
    import psutil
except Exception:
    psutil = None

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

# ----------------------------- Defaults -----------------------------
FLOW_URL = os.environ.get("FLOW_URL", "https://labs.google/fx/vi/tools/flow")
EVENT_MARKER = "__GEMINI_EVENT__"  # giữ marker cũ để dashboard parse được
MODE_CACHE_FILENAME = ".gemini_account_mode.json"
TARGET_ASPECT_W = 16
TARGET_ASPECT_H = 9
RESULTS_PER_ROUND = 4
LOGO_RIGHT_MARGIN = 50  # dịch logo sang trái để che kín watermark Gemini
LOGO_BOTTOM_MARGIN = 45  # dịch logo lên trên để che kín watermark Gemini

DEFAULT_PROMPT = """Edit the uploaded image into a finished realistic music thumbnail. Preserve the original singer from the uploaded image exactly unchanged as the foreground subject: do not alter the face, hair, skin tone, pose, body, clothing, expression, or position. Only change the background style and redesign the typography/font. If any visible year such as 2024 or 2025 appears in the image, replace it with 2026. Return only the final edited image, no explanation and no text response.""".strip()

HEADLESS_FOR_REGULAR = False
HEADLESS_FOR_PRO = False
HIDE_AUTOMATION_CHROME_WINDOWS = True
HIDE_STYLE = "minimize"  # hide | minimize


def _no_window_creationflags():
    if os.name != "nt":
        return 0
    try:
        return int(getattr(subprocess, "CREATE_NO_WINDOW", 0) or 0)
    except Exception:
        return 0


def has_interactive_stdin():
    try:
        return sys.stdin is not None and sys.stdin.isatty()
    except Exception:
        return False


def parse_cli_args():
    parser = argparse.ArgumentParser(description="Flow thumbnail backend worker project-x4")
    parser.add_argument("--root", default=os.environ.get("GEMINI_ROOT", ""), help="Thư mục chứa thumbnail-original-*-final.*")
    parser.add_argument("--logo", default=os.environ.get("GEMINI_LOGO", ""), help="Đường dẫn logo PNG, có thể bỏ trống")
    parser.add_argument("--num-accounts", type=int, default=int(os.environ.get("GEMINI_NUM_ACCOUNTS", "0") or 0))
    parser.add_argument("--chrome-binary", default=os.environ.get("GEMINI_CHROME_BINARY", ""))
    parser.add_argument("--driver-path", default=os.environ.get("GEMINI_DRIVER_PATH", ""))
    parser.add_argument("--proxy-config", default=os.environ.get("HYBRID_PROXY_CONFIG", ""), help="proxy_accounts.txt dạng google_1=ip:port:user:pass")
    parser.add_argument("--account-modes", default=os.environ.get("GEMINI_ACCOUNT_MODES", ""))
    parser.add_argument("--manifest", default=os.environ.get("GEMINI_JOB_MANIFEST", ""))
    parser.add_argument("--events", default=os.environ.get("GEMINI_EVENTS", "1"))
    parser.add_argument("--final-min-mb", type=float, default=float(os.environ.get("GEMINI_FINAL_MIN_MB", "2.05") or 2.05))
    parser.add_argument("--input-skip-over-mb", type=float, default=float(os.environ.get("GEMINI_INPUT_SKIP_OVER_MB", "1.5") or 1.5))
    parser.add_argument("--headless-regular", default=os.environ.get("GEMINI_HEADLESS_REGULAR", ""))
    parser.add_argument("--headless-pro", default=os.environ.get("GEMINI_HEADLESS_PRO", ""))
    parser.add_argument("--hide-style", default=os.environ.get("GEMINI_HIDE_STYLE", "offscreen"), choices=("", "hide", "minimize", "offscreen"))
    parser.add_argument("--validate-min-width", type=int, default=int(os.environ.get("GEMINI_VALIDATE_MIN_WIDTH", "1280") or 1280))
    parser.add_argument("--validate-min-height", type=int, default=int(os.environ.get("GEMINI_VALIDATE_MIN_HEIGHT", "720") or 720))
    parser.add_argument("--validate-aspect-epsilon", type=float, default=float(os.environ.get("GEMINI_VALIDATE_ASPECT_EPS", "0.025") or 0.025))
    parser.add_argument("--max-job-retries", type=int, default=int(os.environ.get("GEMINI_MAX_JOB_RETRIES", "0") or 0))
    parser.add_argument("--flow-folder-retries", type=int, default=int(os.environ.get("FLOW_FOLDER_RETRIES", "0") or 0),
                        help="Số lần retry kỹ thuật bằng cách tạo lại project Flow khi lỗi upload/input")
    parser.add_argument("--flow-card-retries", type=int, default=int(os.environ.get("FLOW_CARD_RETRIES", "0") or 0),
                        help="Số lần bấm nút Thử lại/Retry ngay trên card lỗi Flow trước khi fallback Gemini")
    parser.add_argument("--flow-safe-delay-min", type=float, default=float(os.environ.get("FLOW_SAFE_DELAY_MIN", "0") or 0),
                        help="Flow Safe: nghỉ tối thiểu giữa các thư mục Flow")
    parser.add_argument("--flow-safe-delay-max", type=float, default=float(os.environ.get("FLOW_SAFE_DELAY_MAX", "0") or 0),
                        help="Flow Safe: nghỉ tối đa giữa các thư mục Flow")
    parser.add_argument("--result-stable-seconds", type=float, default=float(os.environ.get("GEMINI_RESULT_STABLE_SECONDS", "0.8") or 0.8))
    parser.add_argument("--result-stable-rounds", default=os.environ.get("GEMINI_RESULT_STABLE_ROUNDS", "1"))
    parser.add_argument("--auto-upscale-final", default=os.environ.get("GEMINI_AUTO_UPSCALE_FINAL", "1"))
    parser.add_argument("--no-hash-validate", action="store_true")
    parser.add_argument("--flow-url", default=FLOW_URL)
    parser.add_argument("--prompt", default=os.environ.get("FLOW_PROMPT", ""), help="Prompt Flow. Nếu trống sẽ đọc flow_prompt.txt hoặc dùng prompt mặc định.")
    parser.add_argument("--create-new-project", default=os.environ.get("FLOW_CREATE_NEW_PROJECT", "1"), help="1 = mỗi thư mục bấm tạo project mới")
    parser.add_argument("--results-per-round", type=int, default=int(os.environ.get("FLOW_RESULTS_PER_ROUND", "4") or 4), help="Flow tối đa 4 ảnh/lần")
    parser.add_argument("--download-timeout", type=int, default=int(os.environ.get("FLOW_DOWNLOAD_TIMEOUT", "90") or 90))
    parser.add_argument("--flow-max-consecutive-folder-errors", type=int, default=int(os.environ.get("FLOW_MAX_CONSECUTIVE_FOLDER_ERRORS", "1") or 1),
                        help="Hybrid grouped: 0 = không dừng sớm; mỗi thư mục sẽ thử Flow trước, Gemini chỉ fallback sau khi Flow của thư mục đó thất bại")
    args, unknown = parser.parse_known_args()
    if unknown:
        print("ℹ Bỏ qua tham số dashboard không dùng:", " ".join(map(str, unknown)))
    return args


def _resolve_path(value, prompt_text=""):
    value = str(value or "").strip().strip('"')
    if value:
        return os.path.abspath(os.path.expandvars(os.path.expanduser(value)))
    if prompt_text and has_interactive_stdin():
        return os.path.abspath(input(prompt_text).strip().strip('"'))
    return ""


ARGS = parse_cli_args()
EVENTS_ENABLED = str(ARGS.events).strip().lower() not in ("0", "false", "no", "off")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_FOLDER = _resolve_path(ARGS.root, "Nhập đường dẫn thư mục cha: ")
LOGO_PATH = _resolve_path(ARGS.logo, "Nhập đường dẫn file logo PNG, bỏ trống nếu không dùng: ")
JOB_MANIFEST_PATH = _resolve_path(ARGS.manifest)
INPUT_SKIP_OVER_MB = float(ARGS.input_skip_over_mb or 1.5)
FINAL_MIN_IMAGE_MB = float(ARGS.final_min_mb or 2.05)
FINAL_MIN_IMAGE_BYTES = int(FINAL_MIN_IMAGE_MB * 1024 * 1024)
VALIDATE_MIN_WIDTH = int(ARGS.validate_min_width or 1280)
VALIDATE_MIN_HEIGHT = int(ARGS.validate_min_height or 720)
VALIDATE_ASPECT_EPSILON = float(ARGS.validate_aspect_epsilon or 0.025)
VALIDATE_HASH = not bool(ARGS.no_hash_validate)
MAX_JOB_RETRIES = max(0, int(ARGS.max_job_retries or 0))
FLOW_FOLDER_RETRIES = max(0, int(getattr(ARGS, "flow_folder_retries", 0) or 0))
FLOW_CARD_RETRIES = max(0, int(getattr(ARGS, "flow_card_retries", 0) or 0))
FLOW_SAFE_DELAY_MIN = max(0.0, float(getattr(ARGS, "flow_safe_delay_min", 0) or 0))
FLOW_SAFE_DELAY_MAX = max(FLOW_SAFE_DELAY_MIN, float(getattr(ARGS, "flow_safe_delay_max", 0) or FLOW_SAFE_DELAY_MIN))
RESULT_STABLE_SECONDS = max(0.1, float(ARGS.result_stable_seconds or 0.8))
AUTO_UPSCALE_FINAL = str(ARGS.auto_upscale_final).strip().lower() not in ("0", "false", "no", "off")
FLOW_RESULTS_PER_ROUND = max(1, min(4, int(ARGS.results_per_round or 4)))
CREATE_NEW_PROJECT = str(ARGS.create_new_project).strip().lower() not in ("0", "false", "no", "off")
FLOW_URL = str(ARGS.flow_url or FLOW_URL).strip()
DOWNLOAD_TIMEOUT = int(ARGS.download_timeout or 90)
FLOW_MAX_CONSECUTIVE_FOLDER_ERRORS = max(0, int(getattr(ARGS, "flow_max_consecutive_folder_errors", 2) or 0))
# v134.8: dashboard có thể giao bớt job chưa chạy sang account rảnh; worker đọc file này để bỏ qua file đã bị lấy bớt.
WORKER_SKIPLIST_PATH = os.environ.get("FLOW_SKIPLIST", "") or os.path.join(BASE_DIR, "worker_skiplist.json")

chrome_binary = _resolve_path(ARGS.chrome_binary) or os.path.join(BASE_DIR, "chrome-win64", "chrome.exe")
driver_path = _resolve_path(ARGS.driver_path) or os.path.join(BASE_DIR, "chromedriver-win64", "chromedriver.exe")
CONFIG_FILE = os.path.join(BASE_DIR, "accounts.json")
DEBUG_DIR = os.path.join(BASE_DIR, "_debug")
os.makedirs(DEBUG_DIR, exist_ok=True)

# ---------- v3.8 Portable Proxy helpers ----------
def _proxy_config_path():
    try:
        p = str(getattr(ARGS, "proxy_config", "") or "").strip().strip('"')
        if p:
            return p
    except Exception:
        pass
    p = os.environ.get("HYBRID_PROXY_CONFIG", "") or ""
    if p:
        return p
    try:
        return os.path.join(BASE_DIR, "proxy_accounts.txt")
    except Exception:
        return "proxy_accounts.txt"


def _load_proxy_map():
    path = _proxy_config_path()
    out = {}
    try:
        if not path or not os.path.isfile(path):
            return out
        seq = 1
        for raw in open(path, "r", encoding="utf-8", errors="ignore"):
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith(";"):
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                k = k.strip().lower(); v = v.strip()
                if k and v: out[k] = v
            else:
                out[f"google_{seq}"] = line; seq += 1
    except Exception as e:
        print(f"⚠ Không đọc được proxy config: {e}", flush=True)
    return out


def _parse_proxy_value(value):
    value = str(value or "").strip().strip('"').strip("'")
    if not value: return None
    scheme = "http"
    try:
        from urllib.parse import urlparse, unquote
        vv = value if "://" in value else "http://" + value
        u = urlparse(vv)
        if u.hostname and u.port:
            return {"scheme": (u.scheme or "http").lower(), "host": u.hostname, "port": str(u.port), "username": unquote(u.username or ""), "password": unquote(u.password or ""), "raw": value}
    except Exception:
        pass
    parts = value.split(":")
    if len(parts) >= 4:
        host, port, username = parts[0].strip(), parts[1].strip(), parts[2].strip()
        password = ":".join(parts[3:]).strip()
    elif len(parts) >= 2:
        host, port = parts[0].strip(), parts[1].strip(); username = password = ""
    else:
        return None
    if not host or not port: return None
    return {"scheme": scheme, "host": host, "port": port, "username": username, "password": password, "raw": value}


def _profile_key_from_path(profile_path):
    try: return os.path.basename(os.path.normpath(str(profile_path))).lower()
    except Exception: return ""


def _proxy_for_profile(profile_path):
    mp = _load_proxy_map(); key = _profile_key_from_path(profile_path)
    val = mp.get(key) or mp.get(key.replace("google_", ""))
    return _parse_proxy_value(val) if val else None


def _proxy_extension_zip(proxy, profile_key="default"):
    if not proxy or not proxy.get("username"): return ""
    try:
        import zipfile, json as _json
        ext_root = os.path.join(BASE_DIR, "_proxy_extensions"); os.makedirs(ext_root, exist_ok=True)
        safe_key = re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(profile_key or "default"))
        zip_path = os.path.join(ext_root, f"proxy_auth_{safe_key}_{os.getpid()}.zip")
        scheme = proxy.get("scheme") or "http"; host = proxy.get("host") or ""; port = int(proxy.get("port") or 0)
        user = (proxy.get("username") or "").replace('"','\\"'); pwd = (proxy.get("password") or "").replace('"','\\"')
        # v12.60: Chrome mới chặn Manifest V2, dùng MV3 service_worker cho proxy auth.
        manifest = {"version":"1.0.0","manifest_version":3,"name":"Hybrid Proxy Auth MV3","permissions":["proxy","storage","webRequest","webRequestAuthProvider"],"host_permissions":["<all_urls>"],"background":{"service_worker":"background.js"},"minimum_chrome_version":"88.0.0"}
        bg = """
const config = {mode: "fixed_servers", rules: {singleProxy: {scheme: "%s", host: "%s", port: %s}, bypassList: ["localhost", "127.0.0.1", "<local>"]}};
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
chrome.webRequest.onAuthRequired.addListener(function(details, callback) { callback({authCredentials: {username: "%s", password: "%s"}}); }, {urls: ["<all_urls>"]}, ["asyncBlocking"]);
""" % (scheme, host, port, user, pwd)
        with zipfile.ZipFile(zip_path, "w") as z:
            z.writestr("manifest.json", _json.dumps(manifest, ensure_ascii=False)); z.writestr("background.js", bg)
        return zip_path
    except Exception as e:
        print(f"⚠ Tạo proxy extension lỗi: {e}", flush=True); return ""


def apply_proxy_to_chrome_options(options, profile_path):
    try:
        proxy = _proxy_for_profile(profile_path)
        if not proxy: return ""
        scheme = proxy.get("scheme") or "http"; host = proxy.get("host") or ""; port = proxy.get("port") or ""
        if not host or not port: return ""
        options.add_argument(f"--proxy-server={scheme}://{host}:{port}")
        key = _profile_key_from_path(profile_path); ext = _proxy_extension_zip(proxy, key)
        if ext: options.add_extension(ext)
        print(f"🌐 Proxy active cho {key}: {scheme}://{host}:{port}" + (" • auth" if proxy.get("username") else ""), flush=True)
        return f"{scheme}://{host}:{port}"
    except Exception as e:
        print(f"⚠ Không gắn proxy vào Chrome: {e}", flush=True)
    return ""


# v106 stable hidden mode: vẫn không headless để Flow ổn định, nhưng tự thu cửa sổ Chrome xuống taskbar.
HEADLESS_FOR_REGULAR = False
HEADLESS_FOR_PRO = False
HIDE_AUTOMATION_CHROME_WINDOWS = True
HIDE_STYLE = str(ARGS.hide_style or "minimize").strip() or "minimize"
print(f"🪟 v134 direct-fetch-first+chip-candidate-fix+x3-tabs+source-guard+1x-fix+anti-flash+hard-stop: headless=False, tự ẩn Chrome style={HIDE_STYLE}")

PROVIDED_ACCOUNT_MODES = [m.strip().lower() for m in str(ARGS.account_modes or "").split(",") if m.strip().lower() in ("regular", "pro")]

# ----------------------------- Events / Manifest -----------------------------

def emit_event(event_type, **payload):
    if not EVENTS_ENABLED:
        return
    try:
        data = {"type": str(event_type), "ts": time.time(), **payload}
        print(EVENT_MARKER + json.dumps(data, ensure_ascii=False, separators=(",", ":")), flush=True)
    except Exception:
        pass


def _manifest_now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def load_job_manifest():
    if not JOB_MANIFEST_PATH:
        return {"version": 1, "jobs": {}}
    try:
        if os.path.isfile(JOB_MANIFEST_PATH):
            with open(JOB_MANIFEST_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("jobs"), dict):
                return data
    except Exception as e:
        print(f"⚠ Không đọc được job_manifest: {e}")
    return {"version": 1, "created_at": _manifest_now(), "jobs": {}}


JOB_MANIFEST = load_job_manifest()


def save_job_manifest():
    if not JOB_MANIFEST_PATH:
        return
    if EVENTS_ENABLED:
        return
    tmp = None
    try:
        os.makedirs(os.path.dirname(os.path.abspath(JOB_MANIFEST_PATH)), exist_ok=True)
        tmp = JOB_MANIFEST_PATH + f".{os.getpid()}.{threading.get_ident()}.tmp"
        JOB_MANIFEST["updated_at"] = _manifest_now()
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(JOB_MANIFEST, f, ensure_ascii=False, indent=2)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        os.replace(tmp, JOB_MANIFEST_PATH)
    except Exception as e:
        print(f"⚠ Không lưu được job_manifest: {e}")
    finally:
        if tmp:
            try:
                if os.path.exists(tmp): os.remove(tmp)
            except Exception:
                pass


def manifest_key(image_path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(image_path)))
    except Exception:
        return str(image_path)


def update_job_manifest(image_path, status, **extra):
    try:
        key = manifest_key(image_path)
        jobs = JOB_MANIFEST.setdefault("jobs", {})
        old = jobs.get(key, {}) if isinstance(jobs.get(key, {}), dict) else {}
        item = dict(old)
        item.update({"path": image_path, "status": status, "updated_at": _manifest_now()})
        item.update({k: v for k, v in extra.items() if v is not None})
        jobs[key] = item
        save_job_manifest()
    except Exception as e:
        print(f"⚠ update manifest lỗi: {e}")


def manifest_status(image_path):
    try:
        return str(JOB_MANIFEST.get("jobs", {}).get(manifest_key(image_path), {}).get("status") or "")
    except Exception:
        return ""

# ----------------------------- Chrome / Account -----------------------------

def read_mode_cache(profile_path):
    try:
        cache_path = os.path.join(profile_path, MODE_CACHE_FILENAME)
        if not os.path.isfile(cache_path):
            return ""
        data = json.load(open(cache_path, "r", encoding="utf-8"))
        mode = str(data.get("mode") or "").strip().lower()
        if mode in ("regular", "pro"):
            return mode
    except Exception:
        pass
    return ""


def write_mode_cache(profile_path, mode):
    try:
        mode = str(mode or "regular").strip().lower()
        if mode not in ("regular", "pro"):
            return
        with open(os.path.join(profile_path, MODE_CACHE_FILENAME), "w", encoding="utf-8") as f:
            json.dump({"mode": mode, "updated_at": int(time.time())}, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def ensure_browser_files():
    missing = []
    if not os.path.isfile(chrome_binary):
        missing.append(chrome_binary)
    if not os.path.isfile(driver_path):
        print("⚠️ Không có chromedriver bundle; dùng Selenium Manager tự resolve driver cho Chrome hiện tại")
    if missing:
        print("❌ Thiếu file chạy Chrome/ChromeDriver:")
        for item in missing:
            print(" -", item)
        raise SystemExit(1)


def load_num_accounts():
    if int(ARGS.num_accounts or 0) > 0:
        n = int(ARGS.num_accounts)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump({"num_accounts": n}, f)
        return n
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return int(json.load(f).get("num_accounts") or 1)
    if has_interactive_stdin():
        n = int(input("👉 Bạn muốn dùng bao nhiêu tài khoản Google: "))
    else:
        n = 1
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"num_accounts": n}, f)
    return n


def make_options(profile_path, headless):
    options = webdriver.ChromeOptions()
    options.binary_location = chrome_binary
    options.add_argument(f"--user-data-dir={profile_path}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--password-store=basic")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    # v105: cho phép tải file tự động từ menu Flow "Tải xuống".
    try:
        _download_pref_dir = os.path.join(BASE_DIR, "_flow_downloads", f"pid_{os.getpid()}")
        os.makedirs(_download_pref_dir, exist_ok=True)
        options.add_experimental_option("prefs", {
            "download.default_directory": _download_pref_dir,
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "profile.default_content_setting_values.automatic_downloads": 1,
            "safebrowsing.enabled": True,
        })
    except Exception:
        pass
    options.add_argument("--remote-debugging-port=0")
    options.add_argument("--disable-backgrounding-occluded-windows")
    options.add_argument("--disable-renderer-backgrounding")
    options.add_argument("--force-device-scale-factor=1")
    options.add_argument("--window-size=1600,2400")
    apply_proxy_to_chrome_options(options, profile_path)
    if headless:
        # v95 override: nhánh này hầu như không dùng vì headless đã bị ép False.
        options.add_argument("--headless=new")
        options.add_argument("--hide-scrollbars")
        options.add_argument("--disable-gpu")
    else:
        # v112: chống flash lúc Chrome mới bật.
        # Cho Chrome khởi động dạng minimized trước, sau đó guard sẽ restore ra ngoài màn hình.
        # Cách này vẫn cho Flow render vì cửa sổ sẽ được show offscreen, không bị hide/minimize lâu.
        if HIDE_STYLE in ("hide", "offscreen"):
            options.add_argument("--start-minimized")
            options.add_argument("--window-position=-32000,-32000")
        elif HIDE_STYLE == "minimize":
            options.add_argument("--start-minimized")
            options.add_argument("--window-position=40,40")
        else:
            options.add_argument("--window-position=40,40")
    return options


def _get_descendant_pids(root_pid):
    if not root_pid or psutil is None:
        return set()
    try:
        root = psutil.Process(root_pid)
        return {p.pid for p in root.children(recursive=True)} | {int(root_pid)}
    except Exception:
        return {int(root_pid)} if root_pid else set()


def _enum_visible_windows_for_pids(pids):
    if os.name != "nt" or not pids:
        return []
    try:
        user32 = ctypes.windll.user32
        wins = []
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def _callback(hwnd, _lparam):
            try:
                if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
                    return True
                pid = ctypes.c_ulong()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if int(pid.value) in pids:
                    wins.append(hwnd)
            except Exception:
                pass
            return True

        user32.EnumWindows(EnumWindowsProc(_callback), 0)
        return wins
    except Exception:
        return []



def _get_hwnd_pid(hwnd):
    if os.name != "nt" or not hwnd:
        return 0
    try:
        user32 = ctypes.windll.user32
        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value or 0)
    except Exception:
        return 0


def _is_portable_chrome_hwnd(hwnd):
    if os.name != "nt" or not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
            return False
        pid = _get_hwnd_pid(hwnd)
        if not pid:
            return False
        if psutil is not None:
            try:
                chrome_bin = str(Path(chrome_binary).resolve()).lower()
                proc = psutil.Process(pid)
                exe = str(proc.exe() or "").lower()
                name = str(proc.name() or "").lower()
                return exe == chrome_bin or (name == "chrome.exe" and "chrome-win64" in exe)
            except Exception:
                return False
    except Exception:
        return False
    return False


def _enum_visible_portable_chrome_windows():
    """Liệt kê cửa sổ Chrome portable của tool theo đúng chrome_binary.
    Dùng cho v110 để đẩy Chrome automation ra ngoài màn hình ngay khi nó vừa bật,
    tránh nhảy lên che dashboard nhưng vẫn không minimize/hide nên Flow vẫn render preview.
    """
    if os.name != "nt":
        return []
    try:
        chrome_bin = str(Path(chrome_binary).resolve()).lower()
        user32 = ctypes.windll.user32
    except Exception:
        return []
    wins = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def _cb(hwnd, _lparam):
        try:
            if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
                return True
            if _is_portable_chrome_hwnd(hwnd):
                wins.append(hwnd)
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(EnumWindowsProc(_cb), 0)
    except Exception:
        pass
    return wins


def _move_hwnd_offscreen_no_activate(hwnd):
    if os.name != "nt" or not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        HWND_BOTTOM = 1
        SW_SHOWNOACTIVATE = 4
        SWP_NOSIZE = 0x0001
        SWP_NOACTIVATE = 0x0010
        SWP_NOOWNERZORDER = 0x0200
        SWP_SHOWWINDOW = 0x0040
        # v112: nếu Chrome vừa khởi động dạng minimized để chống flash,
        # restore nó ở ngoài màn hình, không activate, để Flow vẫn render preview.
        user32.SetWindowPos(hwnd, HWND_BOTTOM, -32000, -32000, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_SHOWWINDOW)
        user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
        user32.SetWindowPos(hwnd, HWND_BOTTOM, -32000, -32000, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_SHOWWINDOW)
        return True
    except Exception:
        return False


def _apply_background_style_to_hwnd(hwnd):
    if os.name != "nt" or not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        SW_HIDE = 0
        SW_SHOWMINNOACTIVE = 7
        SW_MINIMIZE = 6
        if HIDE_STYLE == "hide":
            user32.ShowWindow(hwnd, SW_HIDE)
            return True
        if HIDE_STYLE == "minimize":
            user32.ShowWindow(hwnd, SW_SHOWMINNOACTIVE)
            user32.ShowWindow(hwnd, SW_MINIMIZE)
            return True
        # offscreen: không minimize để upload preview/menu vẫn render.
        return _move_hwnd_offscreen_no_activate(hwnd)
    except Exception:
        return False


def start_portable_chrome_background_guard(label="", startup_seconds=8.0):
    """Guard chạy từ trước lúc webdriver.Chrome tạo cửa sổ.
    Nó quét Chrome portable liên tục và đẩy ra ngoài màn hình thật nhanh để giảm flash/pop-up.
    """
    if not HIDE_AUTOMATION_CHROME_WINDOWS or os.name != "nt":
        return None
    stop_event = __import__('threading').Event()

    def _loop():
        # v112: vừa dùng WinEvent hook theo sự kiện SHOW/FOREGROUND,
        # vừa polling dự phòng. Hook giúp bắt cửa sổ ngay khi Windows vừa tạo,
        # giảm tình trạng nháy 1 tích tắc trước khi poll kịp chạy.
        first_until = time.time() + max(0.5, float(startup_seconds or 8.0))
        tick = 0
        hooks = []
        callback_ref = None
        try:
            user32 = ctypes.windll.user32
            EVENT_SYSTEM_FOREGROUND = 0x0003
            EVENT_OBJECT_SHOW = 0x8002
            WINEVENT_OUTOFCONTEXT = 0x0000
            WINEVENT_SKIPOWNPROCESS = 0x0002
            OBJID_WINDOW = 0
            WinEventProc = ctypes.WINFUNCTYPE(None, ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_long, ctypes.c_long, ctypes.c_uint, ctypes.c_uint)
            try:
                user32.SetWinEventHook.restype = ctypes.c_void_p
                user32.UnhookWinEvent.argtypes = [ctypes.c_void_p]
            except Exception:
                pass

            def _event_cb(_hook, event, hwnd, id_object, _id_child, _thread, _time_ms):
                try:
                    hwnd = int(hwnd or 0)
                    if id_object not in (OBJID_WINDOW, 0):
                        return
                    if hwnd and _is_portable_chrome_hwnd(hwnd):
                        _apply_background_style_to_hwnd(hwnd)
                except Exception:
                    pass

            callback_ref = WinEventProc(_event_cb)
            for ev in (EVENT_OBJECT_SHOW, EVENT_SYSTEM_FOREGROUND):
                h = user32.SetWinEventHook(ev, ev, 0, callback_ref, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS)
                if h:
                    hooks.append(h)
        except Exception:
            hooks = []
            callback_ref = None

        try:
            while not stop_event.is_set():
                try:
                    for hwnd in _enum_visible_portable_chrome_windows():
                        _apply_background_style_to_hwnd(hwnd)
                except Exception:
                    pass
                tick += 1
                try:
                    # message pump cho WinEvent hook nếu Windows yêu cầu.
                    msg = ctypes.wintypes.MSG()
                    PM_REMOVE = 0x0001
                    user32 = ctypes.windll.user32
                    while user32.PeekMessageW(ctypes.byref(msg), 0, 0, 0, PM_REMOVE):
                        user32.TranslateMessage(ctypes.byref(msg))
                        user32.DispatchMessageW(ctypes.byref(msg))
                except Exception:
                    pass
                if time.time() < first_until:
                    time.sleep(0.006 if tick < 260 else 0.02)
                else:
                    time.sleep(0.10)
        finally:
            try:
                user32 = ctypes.windll.user32
                for h in hooks:
                    try:
                        user32.UnhookWinEvent(h)
                    except Exception:
                        pass
            except Exception:
                pass
            _ = callback_ref

    try:
        t = __import__('threading').Thread(target=_loop, daemon=True)
        t.start()
        if label:
            print(f"🪟 Chrome background guard ON: {label} • style={HIDE_STYLE}")
        return stop_event
    except Exception:
        return None


def keep_browser_in_background(driver, force=False):
    if not HIDE_AUTOMATION_CHROME_WINDOWS or os.name != "nt":
        return
    try:
        root_pid = int(driver.service.process.pid)
        pids = _get_descendant_pids(root_pid)
        for hwnd in _enum_visible_windows_for_pids(pids):
            _apply_background_style_to_hwnd(hwnd)
    except Exception:
        pass


def start_selenium(profile_path, headless):
    print(f"🪟 Mở Chrome automation • headless={headless} • hide_style={HIDE_STYLE}")
    # v112: bật guard trước khi tạo Chrome để giảm hiện tượng cửa sổ bật lên giữa màn hình.
    guard_stop = start_portable_chrome_background_guard("webdriver startup", startup_seconds=12.0)
    service = Service(driver_path) if os.path.isfile(driver_path) else None
    # v113: ChromeDriver không bật console riêng khi worker chạy ngầm.
    try:
        if service is not None:
            service.creation_flags = _no_window_creationflags()
    except Exception:
        pass
    if service is not None:
        drv = webdriver.Chrome(service=service, options=make_options(profile_path, headless))
    else:
        print("⚠️ ChromeDriver bundle không có • Selenium Manager đang tự resolve driver")
        drv = webdriver.Chrome(options=make_options(profile_path, headless))
    try:
        drv._flow_bg_guard_stop = guard_stop
    except Exception:
        pass
    # v116: ép Chrome về trạng thái normal rồi đặt ngoài màn hình.
    # Một số máy khác giữ cửa sổ ở trạng thái minimized làm drag/upload preview chập chờn.
    try:
        win = drv.execute_cdp_cmd("Browser.getWindowForTarget", {})
        wid = win.get("windowId")
        if wid:
            if HIDE_STYLE in ("hide", "offscreen"):
                drv.execute_cdp_cmd("Browser.setWindowBounds", {"windowId": wid, "bounds": {"windowState": "normal", "left": -32000, "top": -32000, "width": 1600, "height": 1200}})
            else:
                drv.execute_cdp_cmd("Browser.setWindowBounds", {"windowId": wid, "bounds": {"windowState": "normal", "left": 40, "top": 40, "width": 1600, "height": 1200}})
    except Exception:
        pass
    try:
        drv.set_window_size(1600, 1200)
        if HIDE_STYLE in ("hide", "offscreen"):
            drv.set_window_position(-32000, -32000)
        else:
            drv.set_window_position(40, 40)
    except Exception:
        pass
    keep_browser_in_background(drv, force=True)
    return drv, WebDriverWait(drv, 60)


def safe_quit_driver(drv):
    try:
        if drv:
            try:
                drv.get("about:blank")
                time.sleep(0.3)
            except Exception:
                pass
            try:
                stop = getattr(drv, "_flow_bg_guard_stop", None)
                if stop:
                    stop.set()
            except Exception:
                pass
            drv.quit()
    except Exception:
        pass


def is_flow_logged_in(drv):
    try:
        url = (drv.current_url or "").lower()
        if "accounts.google.com" in url:
            return False
    except Exception:
        pass
    try:
        body = (drv.find_element(By.TAG_NAME, "body").text or "").lower()
        if "đăng nhập" in body or "sign in" in body:
            # Nếu vẫn thấy ô prompt thì vẫn coi là vào được.
            if not find_prompt_box(drv, required=False):
                return False
    except Exception:
        pass
    try:
        if drv.find_elements(By.CSS_SELECTOR, "textarea, div[role='textbox'], [contenteditable='true'], input[type='file']"):
            return True
    except Exception:
        pass
    return True


def launch_normal_chrome_for_login(profile_path, account_label):
    print(f"\n🔑 Mở Chrome thường để đăng nhập Flow account {account_label}")
    args = [chrome_binary, f"--user-data-dir={profile_path}", "--profile-directory=Default", "--start-maximized", "--no-first-run", "--no-default-browser-check", FLOW_URL]
    proc = subprocess.Popen(args)
    input("👉 Đăng nhập xong, đóng cửa sổ Chrome đó rồi nhấn Enter...")
    if proc.poll() is None:
        print("⚠ Chrome vẫn đang mở. Nếu Selenium báo profile đang dùng, hãy đóng hẳn cửa sổ Chrome này.")


def ensure_flow_session(profile_path, account_label, headless):
    drv, wait = start_selenium(profile_path, headless=headless)
    drv.get(FLOW_URL)
    time.sleep(3)
    if is_flow_logged_in(drv):
        return drv, wait
    if headless:
        safe_quit_driver(drv)
        raise RuntimeError("Chưa đăng nhập Google/Flow. Hãy bấm Mở đăng nhập trong dashboard cho tài khoản này trước.")
    safe_quit_driver(drv)
    launch_normal_chrome_for_login(profile_path, account_label)
    drv, wait = start_selenium(profile_path, headless=headless)
    drv.get(FLOW_URL)
    time.sleep(3)
    if not is_flow_logged_in(drv):
        safe_quit_driver(drv)
        raise RuntimeError("Vẫn chưa đăng nhập được Flow")
    return drv, wait

# ----------------------------- Files / Images -----------------------------

THUMB_RE = re.compile(r"^thumbnail-original-(\d+)-final\.(png|jpg|jpeg|webp)$", re.I)


def scan_target_files(root_folder):
    root = Path(root_folder)
    all_files = []
    skipped = []

    # Dashboard khi chạy worker sẽ copy jobs vào:
    #   _simple_parallel_runs/run_xxx/workers/worker_x_independent/jobs/...
    # Nếu giữ rule skip "_simple_parallel_runs" thì backend sẽ quét ra 0 file,
    # dashboard tưởng worker lỗi/hết lượt và requeue vô hạn.
    root_parts_lower = {str(part).lower() for part in root.parts}
    is_worker_jobs_root = "_simple_parallel_runs" in root_parts_lower and "jobs" in root_parts_lower
    skip_dirs = {"_debug", "_v11_dashboard_runs", "outputs", "_flow_extra"}
    if not is_worker_jobs_root:
        skip_dirs.add("_simple_parallel_runs")

    for path in root.rglob("*"):
        if not path.is_file() or not THUMB_RE.match(path.name):
            continue
        if any(str(part).lower() in skip_dirs for part in path.parts):
            continue
        if manifest_status(str(path)) == "done":
            skipped.append((str(path), "manifest done"))
            continue
        try:
            mb = path.stat().st_size / (1024 * 1024)
        except Exception:
            mb = 0
        if mb > INPUT_SKIP_OVER_MB:
            skipped.append((str(path), f"> {INPUT_SKIP_OVER_MB:.1f}MB"))
            update_job_manifest(str(path), "skipped", reason=f"> {INPUT_SKIP_OVER_MB:.1f}MB")
            emit_event("job_skipped", path=str(path), reason=f"> {INPUT_SKIP_OVER_MB:.1f}MB")
            continue
        all_files.append(path)
    all_files.sort(key=lambda p: (str(p.parent).lower(), int(THUMB_RE.match(p.name).group(1)) if THUMB_RE.match(p.name) else 999999, p.name.lower()))
    # v3.1 GROUPED FLOW FIRST:
    # Gom các thumbnail cùng thư mục thành 1 job Flow để tận dụng x2/x3/x4.
    # Mỗi thư mục phải được thử Flow trước; chỉ sau khi Flow của thư mục đó thất bại
    # thì Hybrid mới đưa các thumbnail chưa xong của chính thư mục đó sang Gemini fallback.
    groups_map = {}
    for p in all_files:
        folder = Path(p.parent)
        groups_map.setdefault(folder, []).append(p)
    groups = []
    for folder, files in groups_map.items():
        files.sort(key=lambda p: (int(THUMB_RE.match(p.name).group(1)) if THUMB_RE.match(p.name) else 999999, p.name.lower()))
        groups.append((folder, files))
    groups.sort(key=lambda x: str(x[0]).lower())
    return groups, skipped


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_final_image_geometry(image_path):
    if not AUTO_UPSCALE_FINAL:
        return {"changed": False}
    target_ratio = TARGET_ASPECT_W / TARGET_ASPECT_H
    with Image.open(image_path) as src:
        img = src.convert("RGB")
        w, h = img.size
        ratio = w / max(1, h)
        changed = False
        notes = []
        if abs(ratio - target_ratio) > VALIDATE_ASPECT_EPSILON:
            if ratio < target_ratio:
                new_h = max(1, int(round(w / target_ratio)))
                top = max(0, (h - new_h) // 2)
                img = img.crop((0, top, w, min(h, top + new_h)))
            else:
                new_w = max(1, int(round(h * target_ratio)))
                left = max(0, (w - new_w) // 2)
                img = img.crop((left, 0, min(w, left + new_w), h))
            changed = True
            notes.append("crop16x9")
        w, h = img.size
        scale = max(1.0, VALIDATE_MIN_WIDTH / max(1, w), VALIDATE_MIN_HEIGHT / max(1, h))
        if scale > 1.0001:
            new_w = max(VALIDATE_MIN_WIDTH, int(round(w * scale)))
            new_h = int(round(new_w / target_ratio))
            if new_h < VALIDATE_MIN_HEIGHT:
                new_h = VALIDATE_MIN_HEIGHT
                new_w = int(round(new_h * target_ratio))
            img = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
            changed = True
            notes.append(f"upscale {w}x{h}->{new_w}x{new_h}")
        if changed:
            img.save(image_path, format="PNG", compress_level=1, optimize=False)
        return {"changed": changed, "note": " • ".join(notes), "width": img.size[0], "height": img.size[1]}


def add_logo_to_image(image_path, logo_path):
    if not logo_path or not os.path.isfile(logo_path):
        return False
    try:
        with Image.open(image_path).convert("RGBA") as base, Image.open(logo_path).convert("RGBA") as logo:
            bw, bh = base.size
            # Logo nhỏ hơn một chút: tối đa 8.5% chiều rộng, không phóng quá nếu logo nhỏ.
            max_w = max(16, int(bw * 0.085))
            if logo.width > max_w:
                new_h = max(1, int(logo.height * (max_w / logo.width)))
                logo = logo.resize((max_w, new_h), Image.Resampling.LANCZOS)
            # Giữ nguyên độ đậm của logo để che kín watermark Gemini bên dưới.
            if logo.mode != "RGBA":
                logo = logo.convert("RGBA")
            x = max(0, bw - logo.width - LOGO_RIGHT_MARGIN)
            y = max(0, bh - logo.height - LOGO_BOTTOM_MARGIN)
            base.alpha_composite(logo, (x, y))
            base.convert("RGB").save(image_path, format="PNG", compress_level=1, optimize=False)
        return True
    except Exception as e:
        print(f"⚠ Chèn logo lỗi: {e}")
        return False


def add_png_pad_chunk(png_bytes, extra_payload_len):
    if not png_bytes.startswith(b"\x89PNG\r\n\x1a\n") or extra_payload_len <= 0:
        return png_bytes
    sig = png_bytes[:8]
    data = png_bytes[8:]
    out = bytearray(sig)
    i = 0
    inserted = False
    while i + 8 <= len(data):
        length = int.from_bytes(data[i:i+4], "big")
        ctype = data[i+4:i+8]
        chunk_total = 12 + length
        if ctype == b"IEND" and not inserted:
            pad_data = b"P" * int(extra_payload_len)
            pad_type = b"npAD"
            out.extend(len(pad_data).to_bytes(4, "big"))
            out.extend(pad_type)
            out.extend(pad_data)
            crc = zlib.crc32(pad_type)
            crc = zlib.crc32(pad_data, crc) & 0xffffffff
            out.extend(crc.to_bytes(4, "big"))
            inserted = True
        out.extend(data[i:i+chunk_total])
        i += chunk_total
    return bytes(out)


def ensure_png_over_min_size(image_path, min_mb=2.05):
    min_bytes = int(float(min_mb) * 1024 * 1024)
    with Image.open(image_path) as img:
        rgb = img.convert("RGB")
        buf = io.BytesIO()
        rgb.save(buf, format="PNG", compress_level=0, optimize=False)
        data = buf.getvalue()
    if len(data) < min_bytes:
        data = add_png_pad_chunk(data, min_bytes - len(data) + 4096)
    with open(image_path, "wb") as f:
        f.write(data)
    # Verify lại sau padding.
    with Image.open(image_path) as verify:
        verify.verify()
    return os.path.getsize(image_path) >= min_bytes


def validate_final_image_file(image_path):
    size_bytes = os.path.getsize(image_path)
    with Image.open(image_path) as img:
        width, height = img.size
        fmt = str(img.format or "").upper()
        img.verify()
    if size_bytes <= 2 * 1024 * 1024:
        raise RuntimeError(f"Ảnh cuối chưa >2MB: {size_bytes/(1024*1024):.3f}MB")
    if width < VALIDATE_MIN_WIDTH or height < VALIDATE_MIN_HEIGHT:
        raise RuntimeError(f"Ảnh cuối quá nhỏ: {width}x{height}")
    ratio = width / max(1, height)
    target = TARGET_ASPECT_W / TARGET_ASPECT_H
    if abs(ratio - target) > VALIDATE_ASPECT_EPSILON:
        raise RuntimeError(f"Ảnh cuối sai tỷ lệ 16:9: {width}x{height}, ratio={ratio:.4f}")
    info = {"path": image_path, "size_bytes": int(size_bytes), "size_mb": round(size_bytes/(1024*1024), 4), "width": int(width), "height": int(height), "format": fmt, "aspect": round(ratio, 6)}
    if VALIDATE_HASH:
        info["sha256"] = sha256_file(image_path)
    return info



def _image_rms_difference_bytes_vs_file(raw_bytes, source_path, size=(256, 144)):
    """RMS khác biệt giữa ảnh Flow tải về và ảnh gốc đã upload.
    RMS rất thấp nghĩa là Flow trả lại đúng ảnh gốc / upload preview chứ chưa phải ảnh đã vẽ.
    """
    try:
        if not source_path or not os.path.isfile(str(source_path)):
            return None
        with Image.open(io.BytesIO(raw_bytes)) as a, Image.open(source_path) as b:
            ia = a.convert("RGB").resize(size, Image.Resampling.LANCZOS)
            ib = b.convert("RGB").resize(size, Image.Resampling.LANCZOS)
            diff = ImageChops.difference(ia, ib)
            stat = ImageStat.Stat(diff)
            rms = sum(float(x) for x in stat.rms) / max(1, len(stat.rms))
            mean = sum(float(x) for x in stat.mean) / max(1, len(stat.mean))
            return {"rms": rms, "mean": mean}
    except Exception:
        return None


def assert_download_not_uploaded_source(raw_bytes, source_path, target_path=None):
    """Chặn lỗi nghiêm trọng: URL tải về chính là ảnh gốc upload.
    Không mark done nếu ảnh tải về gần như y hệt ảnh gốc; nếu không, tool sẽ chỉ đè logo rồi tính là vẽ xong.
    """
    score = _image_rms_difference_bytes_vs_file(raw_bytes, source_path)
    if not score:
        return True
    rms = float(score.get("rms") or 0.0)
    mean = float(score.get("mean") or 0.0)
    # Ngưỡng thấp để chỉ chặn trường hợp giống gần như tuyệt đối / re-encode nhẹ.
    # Ảnh thật do Flow sửa nền/chữ sẽ vượt xa ngưỡng này.
    if rms < 7.5 and mean < 4.0:
        name = Path(target_path).name if target_path else "ảnh đích"
        raise FlowGenerationFailed(
            f"Flow trả về ảnh quá giống ảnh gốc upload cho {name} (rms={rms:.2f}, mean={mean:.2f}) - không tính là vẽ xong"
        )
    return True


def prepare_download_to_final(raw_bytes, final_path, source_path=None):
    if source_path:
        assert_download_not_uploaded_source(raw_bytes, source_path, target_path=final_path)
    tmp_path = str(final_path) + ".flow_tmp.png"
    with Image.open(io.BytesIO(raw_bytes)) as img:
        img.convert("RGB").save(tmp_path, format="PNG", compress_level=1, optimize=False)
    normalize_final_image_geometry(tmp_path)
    add_logo_to_image(tmp_path, LOGO_PATH)
    ensure_png_over_min_size(tmp_path, FINAL_MIN_IMAGE_MB)
    info = validate_final_image_file(tmp_path)
    os.replace(tmp_path, str(final_path))
    return info

# ----------------------------- Flow DOM helpers -----------------------------

def js_click(driver, element):
    driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center'});", element)
    time.sleep(0.1)
    driver.execute_script("arguments[0].click();", element)


def _dom_event_click(driver, element, label="element"):
    """v127: click bằng JS event trực tiếp trên DOM element, không phụ thuộc tọa độ viewport."""
    if not element:
        return False
    try:
        ok = driver.execute_script(r"""
            const el = arguments[0];
            if (!el) return false;
            try { el.scrollIntoView({block:'center', inline:'center', behavior:'instant'}); } catch(e) {}
            const r = el.getBoundingClientRect();
            const opts = {
                bubbles: true, cancelable: true, composed: true,
                view: window,
                clientX: Math.max(1, Math.min(window.innerWidth - 2, r.left + r.width / 2)),
                clientY: Math.max(1, Math.min(window.innerHeight - 2, r.top + r.height / 2)),
                button: 0, buttons: 1
            };
            try { el.focus && el.focus(); } catch(e) {}
            for (const type of ['pointerover','mouseover','pointerenter','mouseenter','pointerdown','mousedown','pointerup','mouseup','click']) {
                let ev;
                try {
                    if (type.startsWith('pointer')) ev = new PointerEvent(type, opts);
                    else ev = new MouseEvent(type, opts);
                } catch(e) {
                    ev = new MouseEvent(type.replace('pointer','mouse'), opts);
                }
                el.dispatchEvent(ev);
            }
            try { el.click && el.click(); } catch(e) {}
            return true;
        """, element)
        if ok:
            print(f"🖱️ DOM event click: {label}")
            return True
    except Exception as e:
        print(f"⚠️ DOM event click {label} lỗi: {e}")
    return False


def cdp_click_element(driver, element, rel_x=0.5, rel_y=0.5, double=False, label=""):
    """v127: click thật bằng CDP, nhưng nếu tọa độ nằm ngoài viewport thì chuyển sang DOM click.
    F12 user cho thấy point 526,912 trả về null, tức CDP click cũ có thể đang bắn ra ngoài viewport.
    """
    try:
        # Không scroll các nút fixed/prompt xuống vị trí lạ quá nhiều; chỉ scroll nếu element thật sự ngoài viewport phía trên/trái.
        driver.execute_script(r"""
            const el=arguments[0], r=el.getBoundingClientRect();
            if (r.top < 0 || r.left < 0 || r.bottom > window.innerHeight + 80 || r.right > window.innerWidth + 80) {
                try { el.scrollIntoView({block:'center', inline:'center', behavior:'instant'}); } catch(e) {}
            }
        """, element)
    except Exception:
        pass
    time.sleep(0.08)
    r = _get_rect(driver, element) or {}
    x = float(r.get('left', 0)) + max(2, min(float(r.get('width', 1))-2, float(r.get('width', 1)) * float(rel_x)))
    y = float(r.get('top', 0)) + max(2, min(float(r.get('height', 1))-2, float(r.get('height', 1)) * float(rel_y)))
    try:
        vp = driver.execute_script("return {w:window.innerWidth,h:window.innerHeight, dpr:window.devicePixelRatio||1};") or {}
    except Exception:
        vp = {}
    vw, vh = float(vp.get('w') or 0), float(vp.get('h') or 0)
    if vw and vh and (x < 0 or y < 0 or x >= vw or y >= vh):
        print(f"⚠️ CDP click {label or 'element'} ngoài viewport @({x:.0f},{y:.0f}) vp={vw:.0f}x{vh:.0f} -> DOM click")
        return _dom_event_click(driver, element, label=label or "element-outside-viewport")

    # Nếu elementFromPoint tại điểm này không trỏ về element/button cha, vẫn thử DOM click trước với nút quan trọng.
    if label and any(k in label for k in ("composer-plus", "add-to-prompt", "top-add", "sidebar")):
        try:
            hit_ok = driver.execute_script(r"""
                const el=arguments[0], x=arguments[1], y=arguments[2];
                const hit=document.elementFromPoint(x,y);
                return !!(hit && (hit===el || el.contains(hit) || (hit.closest && hit.closest('button,[role="button"]')===el)));
            """, element, x, y)
        except Exception:
            hit_ok = True
        if not hit_ok:
            print(f"⚠️ elementFromPoint không trúng {label} @({x:.0f},{y:.0f}) -> DOM click")
            return _dom_event_click(driver, element, label=label)

    for n in range(2 if double else 1):
        driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseMoved", "x":x, "y":y, "button":"left", "buttons":0})
        time.sleep(0.05)
        driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mousePressed", "x":x, "y":y, "button":"left", "buttons":1, "clickCount":1})
        time.sleep(0.08)
        driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseReleased", "x":x, "y":y, "button":"left", "buttons":0, "clickCount":1})
        time.sleep(0.16)
    if label:
        print(f"🖱️ CDP click thật: {label} @({x:.0f},{y:.0f}) vp={vw:.0f}x{vh:.0f} double={double}")
    return True


def _visible_button_by_js(driver, predicate_js):
    return driver.execute_script(r"""
        const pred = new Function('e', arguments[0]);
        function visible(e){
            const r=e.getBoundingClientRect();
            const st=getComputedStyle(e);
            return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
        }
        const nodes=[...document.querySelectorAll('button,[role="button"],div,li')].filter(visible);
        return nodes.find(e => {
            try { return pred(e); } catch(err) { return false; }
        }) || null;
    """, predicate_js)


def _find_composer_plus_button(driver):
    """v127: tìm đúng nút + add_2 ở composer bằng DOM, không phụ thuộc tọa độ log cũ.
    F12 user xác nhận button thật có aria-haspopup="dialog" và text add_2/Tạo.
    """
    return driver.execute_script(r"""
        function visible(e){
            const r=e.getBoundingClientRect();
            const st=getComputedStyle(e);
            return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
        }
        function txt(e){return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim().toLowerCase();}
        const btns=[...document.querySelectorAll('button,[role="button"]')].filter(visible).map(b=>({b,r:b.getBoundingClientRect(),t:txt(b), html:(b.outerHTML||'').toLowerCase()}));
        // Ưu tiên button có aria-haspopup dialog + add_2, đúng F12.
        let found = btns.find(x =>
            (x.b.getAttribute('aria-haspopup') === 'dialog' || x.html.includes('aria-haspopup="dialog"')) &&
            x.t.includes('add_2') &&
            !x.t.includes('arrow_forward') &&
            x.r.width <= 90 && x.r.height <= 90
        );
        if (found) return found.b;
        // Fallback: button add_2 nhỏ gần khu composer, không phải submit arrow_forward.
        found = btns.find(x => x.t.includes('add_2') && !x.t.includes('arrow_forward') && x.r.width <= 90 && x.r.height <= 90);
        if (found) return found.b;
        // Fallback cuối: button nhỏ có text Tạo nhưng không arrow_forward.
        found = btns.find(x => x.t.includes('tạo') && !x.t.includes('arrow_forward') && x.r.width <= 90 && x.r.height <= 90);
        return found ? found.b : null;
    """)


def _find_top_add_media_button(driver):
    return driver.execute_script(r"""
        function visible(e){
            const r=e.getBoundingClientRect();
            const st=getComputedStyle(e);
            return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
        }
        function txt(e){return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim().toLowerCase();}
        const btns=[...document.querySelectorAll('button,[role="button"]')].filter(visible).map(b=>({b,r:b.getBoundingClientRect(),t:txt(b)}));
        let found = btns.find(x => x.r.top < 90 && (x.t.includes('thêm nội dung nghe nhìn') || x.t.includes('add') || x.t.includes('add_2')));
        return found ? found.b : null;
    """)


def _find_uploaded_asset_node(driver, uploaded_name=None):
    """v121: chọn đúng thumbnail nhỏ theo alt/tên file trong picker.
    Theo F12 của user, phần tử đúng là <img alt="thumbnail-original-0-final.png" ...>.
    """
    wanted = ''
    full = ''
    try:
        full = os.path.basename(str(uploaded_name or '')).lower().strip()
        wanted = os.path.splitext(full)[0].lower().strip()
    except Exception:
        pass

    return driver.execute_script(r"""
        const wanted = (arguments[0] || '').toLowerCase().trim();
        const full = (arguments[1] || '').toLowerCase().trim();
        function visible(el){
            const st=getComputedStyle(el), r=el.getBoundingClientRect();
            return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
        }
        function txt(e){ return (e.innerText || e.textContent || e.getAttribute('aria-label') || e.getAttribute('alt') || '').trim().toLowerCase(); }
        function promote(el){
            // Không promote lên container quá lớn; chỉ lấy img hoặc wrapper vừa phải.
            let best = el;
            let n = el.parentElement;
            for (let d=0; n && d<4; d++, n=n.parentElement){
                const r = n.getBoundingClientRect();
                if (r.width <= 220 && r.height <= 120 && r.left > window.innerWidth*0.20 && r.left < window.innerWidth*0.60){
                    best = n;
                }
            }
            return best;
        }

        const imgs = [...document.querySelectorAll('img')].filter(visible);
        // 1) match đúng alt filename, ưu tiên thumb nhỏ ở cột trái.
        let exact = imgs.filter(img => {
            const alt = (img.getAttribute('alt') || '').trim().toLowerCase();
            const r = img.getBoundingClientRect();
            return full && alt === full && r.width <= 80 && r.height <= 80 && r.left > window.innerWidth*0.20 && r.left < window.innerWidth*0.62 && r.top > 120;
        });
        if (exact.length){
            exact.sort((a,b)=>{
                const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                return (ar.left-br.left) || (ar.top-br.top) || ((ar.width*ar.height)-(br.width*br.height));
            });
            return promote(exact[0]);
        }

        // 2) match text filename trên row/card nhỏ.
        let nodes = [...document.querySelectorAll('button,[role="button"],div,li')].filter(n => visible(n));
        let named = nodes.filter(n => {
            const t = txt(n);
            const r = n.getBoundingClientRect();
            return ((full && t.includes(full)) || (wanted && t.includes(wanted))) && r.width <= 260 && r.height <= 120 && r.left > window.innerWidth*0.20 && r.left < window.innerWidth*0.62 && r.top > 120;
        });
        if (named.length){
            named.sort((a,b)=>{
                const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                return (ar.left-br.left) || (ar.top-br.top) || ((ar.width*ar.height)-(br.width*br.height));
            });
            return named[0];
        }

        // 3) fallback: media thumb nhỏ trong cột trái.
        const bad=['flower-placeholder.svg','lh3.googleusercontent.com/a/'];
        let thumbs = imgs.filter(img => {
            const src = img.currentSrc || img.src || '';
            const r = img.getBoundingClientRect();
            return src.includes('media.getMediaUrlRedirect') && !bad.some(b=>src.includes(b)) && r.width <= 90 && r.height <= 90 && r.left > window.innerWidth*0.20 && r.left < window.innerWidth*0.62 && r.top > 120;
        });
        if (thumbs.length){
            thumbs.sort((a,b)=>{
                const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                return (ar.left-br.left) || (ar.top-br.top) || ((ar.width*ar.height)-(br.width*br.height));
            });
            return promote(thumbs[0]);
        }
        return null;
    """, wanted, full)


def _click_uploads_tab_if_visible(driver):
    """v123: nếu picker đã mở, ưu tiên tab 'Tệp tải lên' thật ở cột trái.
    Bản trước đôi khi click lệch sang vùng preview/detail.
    """
    try:
        tab = driver.execute_script(r"""
            function visible(e){
                const r=e.getBoundingClientRect();
                const st=getComputedStyle(e);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
            }
            function txt(e){return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim().toLowerCase();}
            const nodes=[...document.querySelectorAll('button,[role="button"],div,li')].filter(visible).map(e=>({e,t:txt(e),r:e.getBoundingClientRect()}));
            let found = nodes.filter(x =>
                (x.t.includes('tệp tải lên') || x.t.includes('tep tai len') || x.t.includes('uploads') || x.t.includes('drive_folder_upload')) &&
                x.r.left >= 360 && x.r.left <= 620 && x.r.width >= 90 && x.r.width <= 180 && x.r.height >= 24 && x.r.height <= 60 &&
                x.r.top >= 220 && x.r.top <= 520
            );
            found.sort((a,b)=>(a.r.left-b.r.left)||(a.r.top-b.r.top));
            return found.length ? found[0].e : null;
        """)
        if tab:
            cdp_click_element(driver, tab, 0.5, 0.5, double=False, label='picker-upload-tab-strict')
            time.sleep(0.35)
            return True
    except Exception as e:
        print(f"⚠️ Click tab Tệp tải lên lỗi: {e}")
    return False


def _asset_picker_visible(driver):
    """v126: kiểm tra bảng/picker asset đã mở chưa."""
    try:
        return bool(driver.execute_script(r"""
            function visible(e){
                const r=e.getBoundingClientRect();
                const st=getComputedStyle(e);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
            }
            function txt(e){return (e.innerText || e.textContent || e.getAttribute('aria-label') || e.getAttribute('alt') || '').trim().toLowerCase();}
            const nodes=[...document.querySelectorAll('button,[role="button"],div,span,img')].filter(visible).map((e,i)=>({e,i,t:txt(e),r:e.getBoundingClientRect(),tag:e.tagName,src:e.src||''}));
            // Picker thật thường có nhóm tab tất cả/hình ảnh/video/giọng nói/tệp tải lên ở vùng giữa màn hình.
            const hasPickerTabs = nodes.filter(x => x.r.left >= 330 && x.r.left <= 650 && x.r.top >= 120 && x.r.top <= 520)
                .some(x => x.t.includes('tất cả') || x.t.includes('hình ảnh') || x.t.includes('video') || x.t.includes('giọng nói') || x.t.includes('tệp tải lên') || x.t.includes('uploads'));
            const hasSearch = nodes.some(x => x.r.left >= 500 && x.r.top >= 100 && x.r.top <= 260 && (x.t.includes('tìm kiếm thành phần') || x.t.includes('search')));
            const hasMediaInPicker = nodes.some(x => x.tag === 'IMG' && x.src.includes('media.getMediaUrlRedirect') && x.r.left >= 350 && x.r.left <= 1200 && x.r.top >= 120 && x.r.top <= 760 && x.r.width >= 24 && x.r.height >= 24);
            const hasAddButton = nodes.some(x => x.t.includes('thêm vào câu lệnh') || x.t.includes('add to prompt'));
            return hasAddButton || hasPickerTabs || hasSearch || hasMediaInPicker;
        """))
    except Exception:
        return False


def _click_element_safely(driver, el, label='element'):
    """v127: click 3 kiểu; với nút picker/add dùng DOM event trước vì CDP có thể bắn ngoài viewport."""
    if not el:
        return False
    important = any(k in str(label) for k in ("composer-plus", "top-add", "sidebar", "add-to-prompt"))
    if important:
        if _dom_event_click(driver, el, label=f"{label}-dom"):
            time.sleep(0.35)
            return True
    try:
        cdp_click_element(driver, el, 0.5, 0.5, double=False, label=label)
        return True
    except Exception as e:
        print(f"⚠️ CDP click {label} lỗi: {e}")
    try:
        js_click(driver, el)
        print(f"🖱️ JS click: {label}")
        return True
    except Exception as e:
        print(f"⚠️ JS click {label} lỗi: {e}")
    try:
        ActionChains(driver).move_to_element(el).pause(0.1).click().perform()
        print(f"🖱️ Action click: {label}")
        return True
    except Exception as e:
        print(f"⚠️ Action click {label} lỗi: {e}")
    return False


def flow_force_open_asset_picker(driver):
    """v127: mở picker asset bền hơn theo F12 quy trình thật.
    Không dùng tọa độ 526,912 nữa; click trực tiếp DOM button aria-haspopup=dialog/add_2.
    """
    if _find_add_to_prompt_button(driver) or _asset_picker_visible(driver):
        return True

    # 1) Direct DOM query + event dispatch đúng button add_2/aria-haspopup.
    try:
        ok = driver.execute_script(r"""
            function visible(e){
                const r=e.getBoundingClientRect();
                const st=getComputedStyle(e);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
            }
            function txt(e){return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim().toLowerCase();}
            const btns=[...document.querySelectorAll('button,[role="button"]')].filter(visible);
            let b = btns.find(x => (x.getAttribute('aria-haspopup') === 'dialog') && txt(x).includes('add_2') && !txt(x).includes('arrow_forward'));
            if(!b) b = btns.find(x => txt(x).includes('add_2') && !txt(x).includes('arrow_forward'));
            if(!b) return false;
            try { b.focus && b.focus(); } catch(e) {}
            const r=b.getBoundingClientRect();
            const opts={bubbles:true,cancelable:true,composed:true,view:window,clientX:Math.max(1,Math.min(window.innerWidth-2,r.left+r.width/2)),clientY:Math.max(1,Math.min(window.innerHeight-2,r.top+r.height/2)),button:0,buttons:1};
            for(const type of ['pointerover','mouseover','pointerenter','mouseenter','pointerdown','mousedown','pointerup','mouseup','click']){
                let ev;
                try{ ev=type.startsWith('pointer')?new PointerEvent(type,opts):new MouseEvent(type,opts); }catch(e){ ev=new MouseEvent(type.replace('pointer','mouse'),opts); }
                b.dispatchEvent(ev);
            }
            try { b.click(); } catch(e) {}
            return {text:txt(b), rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)}, html:(b.outerHTML||'').slice(0,300)};
        """)
        if ok:
            print(f"➕ DOM direct mở picker bằng add_2: {ok}")
            time.sleep(1.0)
            if _find_add_to_prompt_button(driver) or _asset_picker_visible(driver):
                print("➕ Picker asset đã mở sau DOM direct add_2")
                return True
    except Exception as e:
        print(f"⚠️ DOM direct mở picker lỗi: {e}")

    attempts = []
    try:
        plus = _find_composer_plus_button(driver)
        if plus:
            attempts.append(('composer-plus-dom', plus))
            attempts.append(('composer-plus-cdp', plus))
            attempts.append(('composer-plus-js', plus))
    except Exception:
        pass
    try:
        top = _find_top_add_media_button(driver)
        if top:
            attempts.append(('top-add-media', top))
    except Exception:
        pass
    try:
        side = driver.execute_script(r"""
            function visible(e){const r=e.getBoundingClientRect(); const st=getComputedStyle(e); return st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0;}
            function txt(e){return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim().toLowerCase();}
            const nodes=[...document.querySelectorAll('button,[role="button"],div')].filter(visible).map(e=>({e,t:txt(e),r:e.getBoundingClientRect()}));
            let found = nodes.find(x => x.r.left < 140 && x.r.top > 240 && x.r.top < 380 && (x.t.includes('drive_folder_upload') || x.t.includes('tải lên') || x.t.includes('uploaded')));
            return found ? found.e : null;
        """)
        if side:
            attempts.append(('sidebar-uploaded-media', side))
    except Exception:
        pass

    for label, el in attempts:
        try:
            if label.endswith('-dom'):
                _dom_event_click(driver, el, label)
            elif label.endswith('-js'):
                try:
                    js_click(driver, el)
                    print(f"🖱️ JS click mở picker: {label}")
                except Exception:
                    _click_element_safely(driver, el, label)
            else:
                _click_element_safely(driver, el, label)
            time.sleep(1.0)
            if _find_add_to_prompt_button(driver) or _asset_picker_visible(driver):
                print(f"➕ Picker asset đã mở sau {label}")
                return True
        except Exception as e:
            print(f"⚠️ thử mở picker bằng {label} lỗi: {e}")
    return _asset_picker_visible(driver)


def flow_open_asset_picker_and_select(driver, uploaded_name=None):
    """v126: mở picker thật bền rồi chọn asset/thêm vào prompt.
    v125 log cho thấy chỉ click dấu + nhưng picker không mở, nên thêm force-open nhiều đường.
    """
    try:
        attached = prompt_media_attached_ok(driver)
        if attached:
            return True
    except Exception:
        pass
    try:
        if _find_add_to_prompt_button(driver):
            return True
    except Exception:
        pass

    opened = flow_force_open_asset_picker(driver)
    if not opened:
        print('⚠️ Chưa mở được picker asset sau các cách click dấu +/top add/sidebar')
    time.sleep(0.4)

    # Nếu picker đã mở, chọn tab upload nếu thấy.
    _click_uploads_tab_if_visible(driver)
    time.sleep(0.25)

    # Chọn đúng thumbnail/list item nếu thấy.
    for dbl in (False, True, False):
        try:
            asset = _find_uploaded_asset_node(driver, uploaded_name=uploaded_name)
            if asset:
                _click_element_safely(driver, asset, label=f'select-uploaded-thumb/list dbl={dbl}')
                if dbl:
                    try:
                        cdp_click_element(driver, asset, 0.5, 0.5, double=True, label=f'select-uploaded-thumb/list-double')
                    except Exception:
                        pass
                time.sleep(0.8)
                attached = prompt_media_attached_ok(driver)
                if attached:
                    print(f"➕ Flow đã gắn ảnh vào prompt sau khi chọn asset: {attached}")
                    return True
                btn = _wait_for_add_to_prompt_button(driver, timeout=2.0)
                if btn:
                    print('➕ Đã thấy nút Thêm vào câu lệnh sau khi chọn asset')
                    return True
        except Exception as e:
            print(f"⚠️ chọn asset trong picker lỗi: {e}")

    # Nếu không thấy asset nhưng có nút Add thì coi là picker/detail đã sẵn sàng.
    try:
        if _find_add_to_prompt_button(driver):
            return True
    except Exception:
        pass
    return False


def element_text(el):
    try:
        return (el.text or el.get_attribute("innerText") or "").strip()
    except Exception:
        return ""


def find_buttons(driver):
    try:
        return driver.find_elements(By.CSS_SELECTOR, "button,[role='button'],[role='tab']")
    except Exception:
        return []


def click_button_contains(driver, includes, excludes=(), timeout=8, required=False):
    if isinstance(includes, str):
        includes = [includes]
    if isinstance(excludes, str):
        excludes = [excludes]
    inc = [x.lower() for x in includes]
    exc = [x.lower() for x in excludes]
    end = time.time() + timeout
    last = None
    while time.time() < end:
        for b in find_buttons(driver):
            try:
                txt = " | ".join([element_text(b), b.get_attribute("aria-label") or "", b.get_attribute("title") or ""]).lower()
                if all(x in txt for x in inc) and not any(x in txt for x in exc):
                    if b.is_displayed() and b.is_enabled():
                        js_click(driver, b)
                        return True
                    last = txt
            except Exception as e:
                last = e
        time.sleep(0.25)
    if required:
        raise TimeoutException(f"Không click được button chứa {includes}, last={last}")
    return False


def wait_flow_ready(driver, timeout=60):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if driver.find_elements(By.CSS_SELECTOR, "textarea, div[role='textbox'], [contenteditable='true']"):
                return True
            if driver.find_elements(By.CSS_SELECTOR, "input[type='file']"):
                return True
        except Exception:
            pass
        time.sleep(0.5)
    raise TimeoutException("Flow chưa sẵn sàng: không thấy prompt hoặc input upload")


def close_popups(driver):
    labels = ["got it", "ok", "okay", "đóng", "bỏ qua", "continue", "tiếp tục", "understood", "đồng ý", "agree", "i agree"]
    for _ in range(3):
        clicked = False
        for b in find_buttons(driver):
            try:
                txt = " | ".join([element_text(b), b.get_attribute("aria-label") or "", b.get_attribute("title") or ""]).lower()
                if any(k in txt for k in labels) and b.is_displayed() and b.is_enabled():
                    js_click(driver, b)
                    clicked = True
                    time.sleep(0.6)
                    break
            except Exception:
                pass
        if not clicked:
            return


def flow_open(driver):
    print(f"🌐 Mở Flow URL: {FLOW_URL}")
    driver.get(FLOW_URL)
    time.sleep(3)
    print(f"🌐 Flow loaded: url={driver.current_url} title={driver.title}")
    close_popups(driver)
    wait_flow_ready(driver, timeout=60)


def flow_create_new_project(driver):
    """Không cần selector F12 riêng: ưu tiên nút top-right có material icon add_2 + chữ Tạo.
    Nếu không click được, vẫn tiếp tục dùng composer hiện tại.
    """
    if not CREATE_NEW_PROJECT:
        return False
    # Button top-right trong F12 thường có text: add_2\nTạo. Tránh nút submit: arrow_forward\nTạo.
    try:
        for b in find_buttons(driver):
            txt = element_text(b).lower()
            aria = (b.get_attribute("aria-label") or "").lower()
            combo = txt + " " + aria
            if "add_2" in combo and "arrow_forward" not in combo:
                if b.is_displayed() and b.is_enabled():
                    js_click(driver, b)
                    time.sleep(2.0)
                    close_popups(driver)
                    return True
    except Exception:
        pass
    # Fallback đa ngôn ngữ: dự án mới/new project/create. Không bắt buộc.
    for keys in (["dự án mới"], ["new project"], ["create new"], ["new"]):
        if click_button_contains(driver, keys, excludes=["arrow_forward"], timeout=1.2, required=False):
            time.sleep(2.0)
            close_popups(driver)
            return True
    return False


def find_prompt_box(driver, required=True):
    selectors = [
        "textarea[aria-label*='Văn bản']",
        "textarea",
        "div[role='textbox']",
        "[contenteditable='true']",
        "rich-textarea",
    ]
    for css in selectors:
        try:
            elems = driver.find_elements(By.CSS_SELECTOR, css)
            for e in elems:
                try:
                    if e.is_displayed() and e.is_enabled():
                        return e
                except Exception:
                    if e.is_displayed():
                        return e
        except Exception:
            pass
    if required:
        raise TimeoutException("Không tìm thấy ô prompt Flow")
    return None


def flow_set_prompt(driver, prompt):
    box = find_prompt_box(driver, required=True)
    js_click(driver, box)
    time.sleep(0.2)
    try:
        box.send_keys(Keys.CONTROL, "a")
        box.send_keys(Keys.BACKSPACE)
        time.sleep(0.1)
        box.send_keys(prompt)
        print(f"📝 Prompt đã nhập: {len(prompt)} ký tự")
        return True
    except Exception:
        # contenteditable fallback
        driver.execute_script("arguments[0].focus(); arguments[0].innerText = arguments[1]; arguments[0].dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:arguments[1]}));", box, prompt)
        print(f"📝 Prompt đã nhập: {len(prompt)} ký tự")
        return True


def find_file_input(driver, timeout=30):
    end = time.time() + timeout
    last_error = None
    while time.time() < end:
        try:
            inputs = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
            for inp in inputs:
                try:
                    accept = (inp.get_attribute("accept") or "").lower()
                    if "image" in accept or accept == "" or "*" in accept:
                        driver.execute_script("arguments[0].style.display='block'; arguments[0].style.visibility='visible'; arguments[0].removeAttribute('hidden'); arguments[0].removeAttribute('disabled');", inp)
                        return inp
                except Exception:
                    return inp
        except Exception as e:
            last_error = e
        time.sleep(0.3)
    raise TimeoutException(f"Không tìm thấy input[type=file] của Flow. last={last_error}")


def _visible_non_avatar_imgs(driver):
    js = r"""
    const out = [];
    const bad = ['flower-placeholder.svg', 'lh3.googleusercontent.com/a/'];
    for (const img of [...document.querySelectorAll('img')]) {
      const src = img.currentSrc || img.src || '';
      if (!src) continue;
      const st = getComputedStyle(img);
      const rect = img.getBoundingClientRect();
      if (st.display === 'none' || st.visibility === 'hidden' || rect.width < 24 || rect.height < 24) continue;
      if (bad.some(x => src.includes(x))) continue;
      out.push({src, w: Math.round(rect.width), h: Math.round(rect.height), top: Math.round(rect.top)});
    }
    return out;
    """
    try:
        return driver.execute_script(js) or []
    except Exception:
        return []


def wait_for_uploaded_preview(driver, before_count=0, timeout=45):
    """Đợi ảnh upload thật sự xuất hiện trong Flow trước khi nhập prompt và chọn option."""
    end = time.time() + timeout
    last = []
    while time.time() < end:
        close_popups(driver)
        imgs = _visible_non_avatar_imgs(driver)
        last = imgs
        if len(imgs) > before_count:
            top = max(imgs, key=lambda x: (x.get('w', 0) * x.get('h', 0), -(x.get('top', 99999))))
            print(f"📎 Upload preview OK: {top.get('w')}x{top.get('h')} total={len(imgs)}")
            return True
        time.sleep(0.35)
    raise TimeoutException(f"Upload ảnh chưa xong / chưa thấy preview mới trong Flow. before={before_count} last={last[:3]}")


def flow_upload_image(driver, image_path):
    before_count = len(_visible_non_avatar_imgs(driver))
    try:
        driver.execute_script("window.focus();")
    except Exception:
        pass
    inp = find_file_input(driver, timeout=30)
    abs_path = os.path.abspath(image_path)
    print(f"📎 Gửi file upload vào Flow: {abs_path}")
    inp.send_keys(abs_path)
    # Với Flow, nếu cửa sổ bị minimize/ẩn quá sớm preview có thể không render. v107 chờ lâu hơn và log rõ hơn.
    wait_for_uploaded_preview(driver, before_count=before_count, timeout=150)
    return True


def _get_rect(driver, el):
    try:
        return driver.execute_script("const r=arguments[0].getBoundingClientRect(); return {left:r.left, top:r.top, right:r.right, bottom:r.bottom, width:r.width, height:r.height};", el)
    except Exception:
        return None


def composer_has_attached_image(driver):
    """v115: nhận diện thumb/media trong composer rộng tay hơn để chịu được máy khác.
    Không chỉ dò đúng alt 50x50, mà còn kiểm tra media nhỏ nằm trong vùng composer gần nút gửi.
    """
    try:
        info = driver.execute_script("""
            const bad = ['flower-placeholder.svg', 'lh3.googleusercontent.com/a/'];
            function visible(el){
                const st = getComputedStyle(el);
                const r = el.getBoundingClientRect();
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width >= 12 && r.height >= 12;
            }
            function txt(e){ return (e && (e.innerText || e.textContent) || '').trim(); }
            const buttons = [...document.querySelectorAll('button,[role="button"]')];
            const send = buttons.find(b => txt(b).includes('arrow_forward'));
            let composer = null;
            if (send){
                let n = send;
                for (let d=0; n && d<12; d++, n=n.parentElement){
                    const r = n.getBoundingClientRect();
                    if (r.width >= 260 && r.height >= 70 && r.width <= 1200 && r.height <= 420 && r.top > window.innerHeight * 0.35){
                        composer = n;
                    }
                }
            }
            const imgs = [...document.querySelectorAll('img')].map((img, i) => {
                const r = img.getBoundingClientRect();
                const src = img.currentSrc || img.src || '';
                const alt = img.alt || '';
                const st = getComputedStyle(img);
                let inComposer = false;
                if (composer){
                    try { inComposer = composer.contains(img); } catch(e) {}
                }
                return {i, src, alt, w:r.width, h:r.height, x:r.left, y:r.top, display:st.display, visibility:st.visibility, inComposer};
            }).filter(x =>
                x.src &&
                x.display !== 'none' &&
                x.visibility !== 'hidden' &&
                !bad.some(b => x.src.includes(b)) &&
                x.src.includes('media.getMediaUrlRedirect') &&
                x.w >= 12 && x.h >= 12
            );

            const thumbs = imgs.filter(x => {
                const alt = (x.alt || '').toLowerCase();
                if (x.inComposer) return true;
                if (alt.includes('nội dung nghe nhìn')) return true;
                if (x.w <= 140 && x.h <= 140 && x.y > window.innerHeight * 0.42) return true;
                if (composer){
                    const cr = composer.getBoundingClientRect();
                    if (x.x >= cr.left - 20 && x.x <= cr.right + 20 && x.y >= cr.top - 20 && x.y <= cr.bottom + 20 && x.w <= 160 && x.h <= 160) return true;
                }
                return false;
            });
            if (!thumbs.length) return null;
            thumbs.sort((a,b) => (Number(!!b.inComposer) - Number(!!a.inComposer)) || (b.y - a.y));
            const t = thumbs[0];
            return {i:t.i, alt:t.alt, src:t.src, w:Math.round(t.w), h:Math.round(t.h), x:Math.round(t.x), y:Math.round(t.y), inComposer:!!t.inComposer};
        """)
        return info
    except Exception:
        return None


def composer_has_prompt_media_token_v124(driver):
    """v124: Flow mới có thể đã gắn ảnh vào ô prompt dù không thấy/bấm được nút Add.
    Dấu hiệu chắc: thumbnail media 40-60px ở vùng composer dưới cùng + nút close/cancel gần đó.
    """
    try:
        info = driver.execute_script(r"""
            function visible(e){
                const r=e.getBoundingClientRect();
                const st=getComputedStyle(e);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
            }
            function txt(e){return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim().toLowerCase();}
            const bad=['flower-placeholder.svg','lh3.googleusercontent.com/a/'];
            const imgs=[...document.querySelectorAll('img')].map((img,i)=>{
                const r=img.getBoundingClientRect();
                const src=img.currentSrc||img.src||'';
                const alt=img.alt||'';
                return {el:img,i,src,alt,w:r.width,h:r.height,x:r.left,y:r.top,b:r.bottom};
            }).filter(x =>
                x.src.includes('media.getMediaUrlRedirect') &&
                !bad.some(b=>x.src.includes(b)) &&
                x.w >= 24 && x.h >= 24 &&
                x.w <= 90 && x.h <= 90 &&
                x.y > window.innerHeight*0.55 &&
                x.x > window.innerWidth*0.20 &&
                x.x < window.innerWidth*0.55
            );
            if(!imgs.length) return null;

            const controls=[...document.querySelectorAll('button,[role="button"]')].filter(visible).map((b,i)=>{
                const r=b.getBoundingClientRect();
                return {i,t:txt(b),x:r.left,y:r.top,w:r.width,h:r.height};
            });
            for(const im of imgs){
                const nearClose = controls.find(c =>
                    (c.t.includes('cancel') || c.t.includes('close') || c.t.includes('xoá') || c.t.includes('xóa')) &&
                    Math.abs(c.x - im.x) < 120 &&
                    Math.abs(c.y - im.y) < 120
                );
                // Nếu không có close gần, vẫn nhận thumb nhỏ ở composer vì picker thumb/list thường cao hơn và không nằm sát ô prompt.
                return {
                    i:im.i, alt:im.alt, w:Math.round(im.w), h:Math.round(im.h),
                    x:Math.round(im.x), y:Math.round(im.y), nearClose: !!nearClose,
                    closeText: nearClose ? nearClose.t : ''
                };
            }
            return null;
        """)
        return info
    except Exception:
        return None


def prompt_media_attached_ok(driver):
    """v125: kiểm tra ảnh đã gắn vào prompt/composer, không gọi đệ quy.
    v124 bị lỗi maximum recursion depth vì hàm này tự gọi lại chính nó.
    """
    try:
        token = composer_has_prompt_media_token_v124(driver)
        if token:
            return token
    except Exception:
        pass
    try:
        existing = composer_has_attached_image(driver)
        if existing:
            return existing
    except Exception:
        pass
    return None


def flow_has_any_uploaded_media_image(driver):
    """Sau khi upload, Flow thường tự gắn ảnh vào composer.
    Chỉ cần thấy media.getMediaUrlRedirect là có thể đi tiếp, không bắt buộc drag gây lỗi.
    """
    try:
        items = driver.execute_script("""
            return [...document.querySelectorAll('img')].map((img, i) => {
                const r = img.getBoundingClientRect();
                const src = img.currentSrc || img.src || '';
                const alt = img.alt || '';
                const st = getComputedStyle(img);
                return {i, src, alt, w: Math.round(r.width), h: Math.round(r.height), x: Math.round(r.left), y: Math.round(r.top), display: st.display, visibility: st.visibility};
            }).filter(x => 
                x.src &&
                x.display !== 'none' &&
                x.visibility !== 'hidden' &&
                x.w >= 16 && x.h >= 16 &&
                !x.src.includes('flower-placeholder.svg') &&
                !x.src.includes('lh3.googleusercontent.com/a/') &&
                (x.src.includes('media.getMediaUrlRedirect') || (x.alt || '').toLowerCase().includes('hình ảnh'))
            );
        """) or []
        return items
    except Exception:
        return []


def _media_image_candidates_debug(driver, limit=8):
    try:
        return driver.execute_script("""
            return [...document.querySelectorAll('img')].map((img, i) => {
                const r = img.getBoundingClientRect();
                const src = img.currentSrc || img.src || '';
                return {
                    i,
                    alt: img.alt || '',
                    src: src.slice(0, 160),
                    w: Math.round(r.width),
                    h: Math.round(r.height),
                    x: Math.round(r.left),
                    y: Math.round(r.top),
                    displayed: getComputedStyle(img).display,
                    visibility: getComputedStyle(img).visibility
                };
            }).filter(x => x.src.includes('media.getMediaUrlRedirect') || (x.alt || '').toLowerCase().includes('hình ảnh'))
              .slice(0, arguments[0]);
        """, int(limit)) or []
    except Exception as e:
        return [{"error": str(e)}]


def find_best_uploaded_preview_element(driver):
    """Tìm đúng ảnh sau khi 'ném ảnh' vào Flow.

    User F12 cho thấy ảnh upload có dạng:
    <img src="/fx/api/trpc/media.getMediaUrlRedirect?name=..." alt="Hình ảnh được tạo" ...>
    Bản cũ lọc theo kích thước >=120 nên có thể bỏ sót thumbnail/card.
    Bản v98 tìm theo src/alt trước, rồi trả về parent/card có thể kéo được.
    """
    try:
        el = driver.execute_script("""
            const bad = ['flower-placeholder.svg', 'lh3.googleusercontent.com/a/'];
            function visible(img) {
                const src = img.currentSrc || img.src || '';
                if (!src || bad.some(x => src.includes(x))) return false;
                const st = getComputedStyle(img);
                const r = img.getBoundingClientRect();
                if (st.display === 'none' || st.visibility === 'hidden') return false;
                if (r.width < 16 || r.height < 16) return false;
                return true;
            }
            const imgs = [...document.querySelectorAll('img')].filter(img => {
                const src = img.currentSrc || img.src || '';
                const alt = (img.alt || '').toLowerCase();
                return visible(img) && (
                    src.includes('media.getMediaUrlRedirect') ||
                    src.includes('/fx/api/trpc/media.getMediaUrlRedirect') ||
                    alt.includes('hình ảnh được tạo') ||
                    alt.includes('generated image')
                );
            });

            if (!imgs.length) return null;

            // Ưu tiên ảnh lớn/card preview, nhưng không loại thumbnail nhỏ.
            imgs.sort((a, b) => {
                const ar = a.getBoundingClientRect();
                const br = b.getBoundingClientRect();
                return (br.width * br.height) - (ar.width * ar.height);
            });

            const img = imgs[0];
            const ir = img.getBoundingClientRect();

            // Trả về ancestor/card để ActionChains kéo dễ hơn vì img có draggable=false.
            let best = img;
            let node = img;
            for (let d = 0; node && d < 7; d++, node = node.parentElement) {
                const r = node.getBoundingClientRect();
                if (r.width >= ir.width && r.height >= ir.height && r.width <= Math.max(1200, ir.width + 260) && r.height <= Math.max(900, ir.height + 260)) {
                    best = node;
                }
            }
            return best;
        """)
        if el:
            dbg = _media_image_candidates_debug(driver, limit=5)
            print(f"🧲 Tìm thấy media image để kéo theo src/alt • candidates={dbg}")
            return el
    except Exception as e:
        print(f"⚠️ Lỗi JS tìm media image: {e}")

    dbg = _media_image_candidates_debug(driver, limit=8)
    raise TimeoutException(f"Không tìm thấy preview/media image sau upload. candidates={dbg}")


def _drag_element_to_target(driver, source, target):
    last = None

    # 1) ActionChains kéo bằng offset thật vào giữa composer
    try:
        sr = _get_rect(driver, source) or {}
        tr = _get_rect(driver, target) or {}
        sx = int((sr.get('width') or 1) / 2)
        sy = int((sr.get('height') or 1) / 2)
        tx = min(80, max(20, int((tr.get('width') or 120) * 0.18)))
        ty = min(80, max(20, int((tr.get('height') or 120) * 0.28)))
        ActionChains(driver).move_to_element_with_offset(source, sx, sy).pause(0.15).click_and_hold().pause(0.35).move_to_element_with_offset(target, tx, ty).pause(0.35).release().perform()
        return True
    except Exception as e:
        last = e

    # 2) Selenium drag_and_drop
    try:
        ActionChains(driver).drag_and_drop(source, target).perform()
        return True
    except Exception as e:
        last = e

    # 3) JS drag event fallback: dùng src media làm text/uri-list.
    try:
        driver.execute_script("""
            const srcEl = arguments[0], dst = arguments[1];
            const img = srcEl.matches && srcEl.matches('img') ? srcEl : srcEl.querySelector('img');
            const url = img ? (img.currentSrc || img.src || '') : '';
            const dt = new DataTransfer();
            if (url) {
                dt.setData('text/plain', url);
                dt.setData('text/uri-list', url);
            }
            const events = ['pointerdown','mousedown','dragstart','dragenter','dragover','drop','dragend','mouseup','pointerup'];
            for (const name of events) {
                const ev = name.startsWith('drag') || name === 'drop'
                    ? new DragEvent(name, {dataTransfer: dt, bubbles: true, cancelable: true})
                    : new MouseEvent(name, {bubbles: true, cancelable: true, view: window});
                (name === 'dragstart' || name === 'pointerdown' || name === 'mousedown' ? srcEl : dst).dispatchEvent(ev);
            }
        """, source, target)
        return True
    except Exception as e:
        last = e

    raise TimeoutException(f'Kéo ảnh vào composer thất bại. last={last}')


def find_large_uploaded_media_element(driver):
    """Tìm ảnh/card lớn sau khi upload để kéo vào composer.
    Dựa trên F12 user gửi: alt="Hình ảnh được tạo", parent A, rect khoảng 711x400.
    """
    el = driver.execute_script("""
        const bad = ['flower-placeholder.svg', 'lh3.googleusercontent.com/a/'];
        const imgs = [...document.querySelectorAll('img')].filter(img => {
            const src = img.currentSrc || img.src || '';
            const alt = (img.alt || '').toLowerCase();
            const st = getComputedStyle(img);
            const r = img.getBoundingClientRect();
            return src &&
                src.includes('media.getMediaUrlRedirect') &&
                !bad.some(b => src.includes(b)) &&
                st.display !== 'none' &&
                st.visibility !== 'hidden' &&
                r.width >= 180 && r.height >= 120 &&
                (
                    alt.includes('hình ảnh được tạo') ||
                    alt.includes('generated') ||
                    r.top < window.innerHeight * 0.55
                );
        });
        if (!imgs.length) return null;
        imgs.sort((a,b) => {
            const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect();
            return (br.width*br.height) - (ar.width*ar.height);
        });
        return imgs[0];
    """)
    if not el:
        dbg = _media_image_candidates_debug(driver, limit=8)
        raise TimeoutException(f"Không tìm thấy ảnh media lớn để kéo. candidates={dbg}")
    return el


def find_composer_drop_target(driver):
    """Tìm vùng composer để drop. Ưu tiên ancestor quanh nút arrow_forward/prompt box."""
    el = driver.execute_script("""
        function txt(e){ return (e.innerText || e.textContent || '').trim(); }
        const buttons = [...document.querySelectorAll('button,[role="button"]')];
        let arrow = buttons.find(b => txt(b).includes('arrow_forward') && !txt(b).includes('add_2'));
        let seed = arrow || document.querySelector('div[role="textbox"], input[aria-label*="Văn bản"], textarea');

        function good(node){
            if (!node) return false;
            const r = node.getBoundingClientRect();
            if (r.width < 260 || r.height < 70 || r.width > 1000 || r.height > 360) return false;
            if (r.top < window.innerHeight * 0.35) return false;
            return true;
        }

        let best = null;
        let n = seed;
        for (let d=0; n && d<12; d++, n=n.parentElement) {
            if (good(n)) best = n;
        }
        if (best) return best;

        const boxes = [...document.querySelectorAll('div[role="textbox"], input[aria-label*="Văn bản"], textarea')];
        for (const b of boxes) {
            let n=b;
            for (let d=0; n && d<10; d++, n=n.parentElement) {
                if (good(n)) return n;
            }
        }
        return seed;
    """)
    if not el:
        raise TimeoutException("Không tìm thấy vùng composer/drop target")
    return el


def cdp_drag_element_to_composer(driver, source, target):
    sr = _get_rect(driver, source) or {}
    tr = _get_rect(driver, target) or {}
    sx = float(sr.get('left', 0)) + float(sr.get('width', 1)) / 2
    sy = float(sr.get('top', 0)) + float(sr.get('height', 1)) / 2

    # Drop vào góc trên-trái composer, nơi sau khi kéo xuất hiện thumb 50x50.
    tx = float(tr.get('left', 0)) + min(85, max(35, float(tr.get('width', 320)) * 0.10))
    ty = float(tr.get('top', 0)) + min(70, max(35, float(tr.get('height', 120)) * 0.28))

    print(f"🧲 CDP drag media -> composer: ({sx:.0f},{sy:.0f}) -> ({tx:.0f},{ty:.0f})")

    driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseMoved", "x":sx, "y":sy, "button":"left", "buttons":0})
    time.sleep(0.12)
    driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mousePressed", "x":sx, "y":sy, "button":"left", "buttons":1, "clickCount":1})
    time.sleep(0.35)
    steps = 24
    for k in range(1, steps+1):
        x = sx + (tx - sx) * k / steps
        y = sy + (ty - sy) * k / steps
        driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseMoved", "x":x, "y":y, "button":"left", "buttons":1})
        time.sleep(0.025)
    time.sleep(0.25)
    driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseReleased", "x":tx, "y":ty, "button":"left", "buttons":0, "clickCount":1})


def _cdp_drag_element_to_composer_point(driver, source, target, rel_x=0.10, rel_y=0.28):
    sr = _get_rect(driver, source) or {}
    tr = _get_rect(driver, target) or {}
    sx = float(sr.get('left', 0)) + float(sr.get('width', 1)) / 2
    sy = float(sr.get('top', 0)) + float(sr.get('height', 1)) / 2
    tx = float(tr.get('left', 0)) + max(35, min(float(tr.get('width', 320)) - 35, float(tr.get('width', 320)) * float(rel_x)))
    ty = float(tr.get('top', 0)) + max(30, min(float(tr.get('height', 120)) - 25, float(tr.get('height', 120)) * float(rel_y)))
    print(f"🧲 CDP drag thử điểm composer rel=({rel_x:.2f},{rel_y:.2f}): ({sx:.0f},{sy:.0f}) -> ({tx:.0f},{ty:.0f})")
    driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseMoved", "x":sx, "y":sy, "button":"left", "buttons":0})
    time.sleep(0.12)
    driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mousePressed", "x":sx, "y":sy, "button":"left", "buttons":1, "clickCount":1})
    time.sleep(0.35)
    steps = 30
    for k in range(1, steps + 1):
        x = sx + (tx - sx) * k / steps
        y = sy + (ty - sy) * k / steps
        driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseMoved", "x":x, "y":y, "button":"left", "buttons":1})
        time.sleep(0.018)
    time.sleep(0.28)
    driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseReleased", "x":tx, "y":ty, "button":"left", "buttons":0, "clickCount":1})


def _wait_for_composer_thumb(driver, timeout=6.0):
    end = time.time() + float(timeout)
    last_dbg = None
    while time.time() < end:
        close_popups(driver)
        attached = composer_has_attached_image(driver)
        if attached:
            print(f"🧲 Attach ảnh vào composer OK: {attached.get('w')}x{attached.get('h')} y={attached.get('y')} inComposer={attached.get('inComposer')}")
            return True
        last_dbg = _media_image_candidates_debug(driver, limit=5)
        time.sleep(0.35)
    return False


def _scroll_into_view_center(driver, el):
    try:
        driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center', behavior:'instant'});", el)
        time.sleep(0.18)
    except Exception:
        pass


def _click_preview_then_composer(driver, source, target):
    """Một số máy attach ổn hơn khi click preview/card rồi click vào vùng composer."""
    try:
        _scroll_into_view_center(driver, source)
        _scroll_into_view_center(driver, target)
        ActionChains(driver).move_to_element(source).pause(0.10).click().pause(0.25).move_to_element_with_offset(target, 45, 35).pause(0.12).click().perform()
        return True
    except Exception as e:
        print(f"⚠️ Click preview->composer lỗi: {e}")
        return False


def _double_click_preview(driver, source):
    try:
        _scroll_into_view_center(driver, source)
        ActionChains(driver).move_to_element(source).pause(0.10).double_click().perform()
        return True
    except Exception as e:
        print(f"⚠️ Double-click preview lỗi: {e}")
        return False


def flow_attach_uploaded_image_to_prompt(driver, timeout=35):
    """v115: kéo/gắn ảnh vào composer ổn hơn.
    Bổ sung: click preview/card, double click, scroll center, nhiều điểm drop hơn và chờ lâu hơn.
    """
    existing = prompt_media_attached_ok(driver)
    if existing:
        print(f"🧲 Composer đã có thumbnail media: {existing.get('w')}x{existing.get('h')} y={existing.get('y')}")
        return True

    # Chờ ngắn để Flow auto-attach nếu UI đang tự xử lý sau upload.
    if _wait_for_composer_thumb(driver, timeout=2.0):
        return True

    end_all = time.time() + max(16, float(timeout or 35))
    last_dbg = None
    attempt = 0
    while time.time() < end_all:
        attempt += 1
        close_popups(driver)
        source = find_large_uploaded_media_element(driver)
        target = find_composer_drop_target(driver)
        _scroll_into_view_center(driver, source)
        _scroll_into_view_center(driver, target)
        src_rect = _get_rect(driver, source) or {}
        tgt_rect = _get_rect(driver, target) or {}
        print(f"🧲 Kéo ảnh lớn vào composer attempt {attempt}: src={int(src_rect.get('width',0))}x{int(src_rect.get('height',0))} y={int(src_rect.get('top',0))} -> composer={int(tgt_rect.get('width',0))}x{int(tgt_rect.get('height',0))} y={int(tgt_rect.get('top',0))}")

        # 0) Một số máy chỉ cần click card preview rồi click composer là đủ attach.
        if _click_preview_then_composer(driver, source, target) and _wait_for_composer_thumb(driver, timeout=2.5):
            return True
        if _double_click_preview(driver, source) and _wait_for_composer_thumb(driver, timeout=2.0):
            return True

        # 1) Thử nhiều vị trí drop hơn vì trên máy khác UI composer có thể lệch khác nhau.
        points = (
            (0.08, 0.18), (0.10, 0.28), (0.14, 0.40), (0.18, 0.56),
            (0.28, 0.32), (0.50, 0.50), (0.12, 0.78)
        )
        for rx, ry in points:
            try:
                _cdp_drag_element_to_composer_point(driver, source, target, rx, ry)
                if _wait_for_composer_thumb(driver, timeout=5.5):
                    return True
            except Exception as e:
                print(f"⚠️ CDP drag điểm ({rx:.2f},{ry:.2f}) lỗi: {e}")

        # 2) Fallback kéo chậm kiểu Selenium/JS.
        try:
            print("🧲 Fallback ActionChains drag/drop")
            _drag_element_to_target(driver, source, target)
            if _wait_for_composer_thumb(driver, timeout=6.0):
                return True
        except Exception as e:
            print(f"⚠️ ActionChains/JS drag fallback lỗi: {e}")

        # 3) Thử click lại preview rồi click composer lần nữa trước khi bỏ attempt này.
        if _click_preview_then_composer(driver, source, target) and _wait_for_composer_thumb(driver, timeout=3.0):
            return True

        last_dbg = _media_image_candidates_debug(driver, limit=6)
        time.sleep(1.0)

    raise TimeoutException(f"Đã kéo ảnh nhưng chưa thấy thumbnail/media trong composer sau nhiều lần thử. media={last_dbg}")


def _flow_add_prompt_button_debug(driver, limit=18):
    try:
        return driver.execute_script(r"""
            return [...document.querySelectorAll('button,[role="button"]')].map((e,i)=>{
                const r=e.getBoundingClientRect();
                const t=(e.innerText||e.textContent||'').trim();
                const st=getComputedStyle(e);
                return {
                    i,
                    tag:e.tagName,
                    text:t,
                    aria:e.getAttribute('aria-label'),
                    disabled:!!e.disabled || e.getAttribute('aria-disabled') === 'true',
                    rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)},
                    visible:st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0
                };
            }).filter(x=>x.visible).slice(0, arguments[0]);
        """, int(limit)) or []
    except Exception as e:
        return [{"error": str(e)}]


def flow_select_latest_uploaded_asset(driver, uploaded_name=None):
    """v117: cố chọn đúng asset đã upload trong panel/browser.
    Ưu tiên row/card có tên file, nếu không có thì fallback chọn preview media lớn như v116.
    """
    wanted = ''
    try:
        if uploaded_name:
            wanted = os.path.splitext(os.path.basename(str(uploaded_name)))[0].lower().strip()
    except Exception:
        wanted = ''

    try:
        el = driver.execute_script(r"""
            const wanted = (arguments[0] || '').toLowerCase().trim();
            function visible(el){
                const st = getComputedStyle(el), r = el.getBoundingClientRect();
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
            }
            function textOf(el){ return (el.innerText || el.textContent || '').trim(); }
            function scoreNode(n){
                const r = n.getBoundingClientRect();
                const txt = textOf(n).toLowerCase();
                let score = 0;
                if (wanted && txt.includes(wanted)) score += 1000000;
                if (txt.includes('hình ảnh') || txt.includes('image')) score += 800;
                if (r.width >= 120 && r.height >= 32) score += Math.round(r.width * r.height);
                if (r.left > window.innerWidth * 0.25) score += 2500;
                if (r.top > 60 && r.top < window.innerHeight * 0.85) score += 1500;
                return score;
            }

            // 1) Ưu tiên card/row chứa tên file trong modal/panel.
            const nodes = [...document.querySelectorAll('button,[role="button"],div,li')].filter(visible);
            let named = nodes.filter(n => {
                const t = textOf(n).toLowerCase();
                if (!t) return false;
                if (wanted && t.includes(wanted)) return true;
                return false;
            });
            if (named.length){
                named.sort((a,b)=>scoreNode(b)-scoreNode(a));
                return named[0];
            }

            // 2) Fallback ảnh media/card như v116.
            const bad = ['flower-placeholder.svg', 'lh3.googleusercontent.com/a/'];
            const imgs = [...document.querySelectorAll('img')].filter(img => {
                const src = img.currentSrc || img.src || '';
                const st = getComputedStyle(img);
                const r = img.getBoundingClientRect();
                return src && src.includes('media.getMediaUrlRedirect') && !bad.some(b => src.includes(b)) &&
                       st.display !== 'none' && st.visibility !== 'hidden' && r.width >= 24 && r.height >= 24;
            });
            if (!imgs.length) return null;
            imgs.sort((a,b)=>{
                const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                const as=(ar.width*ar.height) + (ar.top < window.innerHeight*0.75 ? 100000 : 0);
                const bs=(br.width*br.height) + (br.top < window.innerHeight*0.75 ? 100000 : 0);
                return bs-as;
            });
            let img = imgs[0];
            let best = img;
            let n = img;
            for (let d=0; n && d<8; d++, n=n.parentElement){
                const r = n.getBoundingClientRect();
                if (r.width >= img.getBoundingClientRect().width && r.height >= img.getBoundingClientRect().height &&
                    r.width <= 1100 && r.height <= 700) best = n;
            }
            return best;
        """, wanted)
        if el:
            try:
                driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center', behavior:'instant'});", el)
            except Exception:
                pass
            time.sleep(0.15)
            try:
                cdp_click_element(driver, el, 0.5, 0.5, double=False, label=f"select asset wanted={wanted or '-'}")
                # Double click nhẹ giúp mở detail panel trên Flow mới.
                try:
                    if not _find_add_to_prompt_button(driver):
                        cdp_click_element(driver, el, 0.5, 0.5, double=True, label=f"open asset detail wanted={wanted or '-'}")
                except Exception:
                    pass
                time.sleep(0.55)
                return True
            except Exception:
                try:
                    ActionChains(driver).move_to_element(el).pause(0.1).click().perform()
                    print(f"🖱️ Đã click chọn asset upload trong panel bằng ActionChains • wanted={wanted or '-'}")
                    time.sleep(0.45)
                    return True
                except Exception as e:
                    print(f"⚠️ Click chọn asset upload không thành: {e}")
    except Exception as e:
        print(f"⚠️ flow_select_latest_uploaded_asset lỗi: {e}")
    return False


def _find_add_to_prompt_button(driver):
    """v123: bám đúng button 'Thêm vào câu lệnh' theo class/text từ F12 user."""
    return driver.execute_script(r"""
        function visible(e){
            const r=e.getBoundingClientRect();
            const st=getComputedStyle(e);
            return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
        }
        function txt(e){ return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim(); }
        const keys = ['thêm vào câu lệnh','them vao cau lenh','add to prompt'];
        const buttons = [...document.querySelectorAll('button,[role="button"]')].filter(visible);

        // 1) Match đúng class/button user F12.
        let found = buttons.find(b => {
            const cls = String(b.className || '');
            const t = txt(b).toLowerCase();
            const r = b.getBoundingClientRect();
            return t.includes('thêm vào câu lệnh') &&
                   cls.includes('sc-16c4830a-1') && cls.includes('sc-e7a64add-3') && cls.includes('sc-d7495885-10') &&
                   r.left >= 650 && r.top >= 400 && r.width >= 140 && r.height >= 28;
        });
        if (found) return found;

        // 2) Match button text ở vùng bên phải modal.
        found = buttons.find(b => {
            const t = txt(b).toLowerCase();
            const r = b.getBoundingClientRect();
            return keys.some(k => t.includes(k)) && r.left >= 650 && r.top >= 350 && r.width >= 120 && r.height >= 28;
        });
        if (found) return found;

        // 3) Nếu text nằm ở div/span con, lấy closest button.
        const nodes = [...document.querySelectorAll('div,span')].filter(visible);
        const child = nodes.find(n => {
            const t = txt(n).toLowerCase();
            const r = n.getBoundingClientRect();
            return keys.some(k => t.includes(k)) && r.left >= 650 && r.top >= 350;
        });
        if (child && child.closest) {
            const b = child.closest('button,[role="button"]');
            if (b && visible(b)) return b;
        }

        // 4) fallback theo class tương tự ở vùng bên phải.
        found = buttons.find(b => {
            const cls = String(b.className || '');
            const r = b.getBoundingClientRect();
            return cls.includes('sc-16c4830a-1') && cls.includes('sc-e7a64add-3') && r.left >= 650 && r.top >= 350 && r.width >= 120;
        });
        return found || null;
    """)


def _click_add_to_prompt_by_layout(driver, uploaded_name=None):
    """v122: fallback click nút 'Thêm vào câu lệnh' theo layout khi DOM không bắt được text.
    Picker Flow thường có preview asset bên phải; nút trắng Add nằm dưới preview.
    """
    # 1) Quét cực rộng: nếu thấy text ở bất kỳ node nào, click vào chính node/closest button.
    try:
        el = driver.execute_script(r"""
            function visible(e){
                const r=e.getBoundingClientRect();
                const st=getComputedStyle(e);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
            }
            function txt(e){ return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim().toLowerCase(); }
            const keys=['thêm vào câu lệnh','them vao cau lenh','add to prompt'];
            const all=[...document.querySelectorAll('button,[role="button"],div,span')].filter(visible);
            let n=all.find(e=>keys.some(k=>txt(e).includes(k)));
            if(!n) return null;
            if(n.closest){
                const b=n.closest('button,[role="button"]');
                if(b && visible(b)) return b;
            }
            return n;
        """)
        if el:
            cdp_click_element(driver, el, 0.5, 0.5, double=False, label="add-to-prompt-text-wide")
            time.sleep(0.8)
            return True
    except Exception as e:
        print(f"⚠️ fallback text-wide add-to-prompt lỗi: {e}")

    # 2) Layout fallback: click vùng nút trắng dưới preview bên phải.
    try:
        pt = driver.execute_script(r"""
            function visible(e){
                const r=e.getBoundingClientRect();
                const st=getComputedStyle(e);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
            }
            const bad=['lh3.googleusercontent.com/a/','flower-placeholder.svg'];
            const imgs=[...document.querySelectorAll('img')].filter(img=>{
                const src=img.currentSrc||img.src||'';
                const r=img.getBoundingClientRect();
                return visible(img) && src.includes('media.getMediaUrlRedirect') && !bad.some(b=>src.includes(b)) &&
                       r.width >= 150 && r.height >= 90 && r.left > window.innerWidth*0.42 && r.top > 120;
            });
            if(!imgs.length) return null;
            imgs.sort((a,b)=>{
                const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                return (br.width*br.height)-(ar.width*ar.height);
            });
            const r=imgs[0].getBoundingClientRect();
            // Nút Add thường nằm dưới preview, full width hoặc giữa cột phải.
            let x = Math.round(r.left + r.width/2);
            let y1 = Math.round(r.bottom + Math.max(55, Math.min(135, r.height*0.55)));
            let y2 = Math.round(r.bottom + Math.max(85, Math.min(170, r.height*0.75)));
            y1 = Math.min(window.innerHeight-80, Math.max(r.bottom+35, y1));
            y2 = Math.min(window.innerHeight-70, Math.max(r.bottom+45, y2));
            return {x:x, y1:y1, y2:y2, rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)}};
        """)
        if pt:
            print(f"➕ Fallback layout add-to-prompt theo preview rect={pt.get('rect')}")
            driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseMoved", "x":pt["x"], "y":pt["y1"], "button":"left", "buttons":0})
            time.sleep(0.06)
            driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mousePressed", "x":pt["x"], "y":pt["y1"], "button":"left", "buttons":1, "clickCount":1})
            time.sleep(0.08)
            driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseReleased", "x":pt["x"], "y":pt["y1"], "button":"left", "buttons":0, "clickCount":1})
            time.sleep(0.8)
            if composer_has_attached_image(driver):
                return True
            # thử điểm thứ hai thấp hơn
            driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseMoved", "x":pt["x"], "y":pt["y2"], "button":"left", "buttons":0})
            time.sleep(0.06)
            driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mousePressed", "x":pt["x"], "y":pt["y2"], "button":"left", "buttons":1, "clickCount":1})
            time.sleep(0.08)
            driver.execute_cdp_cmd("Input.dispatchMouseEvent", {"type":"mouseReleased", "x":pt["x"], "y":pt["y2"], "button":"left", "buttons":0, "clickCount":1})
            time.sleep(0.8)
            return True
    except Exception as e:
        print(f"⚠️ fallback layout add-to-prompt lỗi: {e}")
    return False


def _wait_for_add_to_prompt_button(driver, timeout=4.0):
    end = time.time() + float(timeout)
    while time.time() < end:
        try:
            btn = _find_add_to_prompt_button(driver)
            if btn:
                return btn
        except Exception:
            pass
        time.sleep(0.25)
    return None


def flow_click_add_to_prompt_button(driver, uploaded_name=None, timeout=40):
    """v116: thay thế kéo thả bằng nút 'Thêm vào câu lệnh'.
    Luồng mới: upload ảnh -> nhập prompt -> click Thêm vào câu lệnh -> đợi thumb/media vào composer.
    """
    # Nếu Flow đã tự attach sẵn thì đi tiếp luôn.
    existing = prompt_media_attached_ok(driver)
    if existing:
        print(f"➕ Ảnh đã nằm trong câu lệnh sẵn: {existing.get('w')}x{existing.get('h')} y={existing.get('y')}")
        return True

    end = time.time() + max(10, float(timeout or 40))
    last_dbg = None
    attempt = 0
    while time.time() < end:
        attempt += 1
        close_popups(driver)
        # Theo flow mới: phải mở picker asset trước rồi chọn đúng ảnh.
        flow_open_asset_picker_and_select(driver, uploaded_name=uploaded_name)
        time.sleep(0.35)
        attached_now = prompt_media_attached_ok(driver)
        if attached_now:
            print(f"➕ Ảnh đã được gắn vào prompt, bỏ qua nút Thêm vào câu lệnh: {attached_now}")
            return True
        # Không click lại asset kiểu mơ hồ nữa; chỉ chờ nút add xuất hiện.
        try:
            btn = _wait_for_add_to_prompt_button(driver, timeout=1.8)
            if not btn:
                flow_open_asset_picker_and_select(driver, uploaded_name=uploaded_name)
                time.sleep(0.35)
                attached_now = prompt_media_attached_ok(driver)
                if attached_now:
                    print(f"➕ Ảnh đã được gắn vào prompt sau retry, bỏ qua nút Add: {attached_now}")
                    return True
                btn = _wait_for_add_to_prompt_button(driver, timeout=2.5)
            if btn:
                try:
                    cdp_click_element(driver, btn, 0.5, 0.5, double=False, label="add-to-prompt-button-exact")
                except Exception:
                    try:
                        js_click(driver, btn)
                    except Exception:
                        ActionChains(driver).move_to_element(btn).pause(0.1).click().perform()
                print(f"➕ Đã bấm 'Thêm vào câu lệnh' attempt {attempt}")
                # Sau khi bấm, đợi modal/panel đóng hoặc thumb xuất hiện.
                if _wait_for_composer_thumb(driver, timeout=10.0) or prompt_media_attached_ok(driver):
                    return True
                # Có máy Flow attach chậm sau khi panel đóng, chờ thêm một nhịp.
                time.sleep(1.2)
                attached = prompt_media_attached_ok(driver)
                if attached:
                    print(f"➕ Attach bằng nút OK: {attached.get('w')}x{attached.get('h')} y={attached.get('y')}")
                    return True
                # v122: nếu bấm DOM không ăn, thử fallback layout ngay.
                if _click_add_to_prompt_by_layout(driver, uploaded_name=uploaded_name):
                    if _wait_for_composer_thumb(driver, timeout=8.0) or prompt_media_attached_ok(driver):
                        return True
            else:
                # v122: trước khi log fail, thử click nút Add theo text rộng/layout.
                if _click_add_to_prompt_by_layout(driver, uploaded_name=uploaded_name):
                    if _wait_for_composer_thumb(driver, timeout=8.0) or prompt_media_attached_ok(driver):
                        return True
                last_dbg = _flow_add_prompt_button_debug(driver, limit=40)
                print(f"⚠️ Chưa thấy nút 'Thêm vào câu lệnh' attempt {attempt}. picker={_asset_picker_visible(driver)} wanted={os.path.basename(str(uploaded_name or ''))} buttons={last_dbg}")
        except Exception as e:
            last_dbg = _flow_add_prompt_button_debug(driver, limit=24)
            print(f"⚠️ Bấm 'Thêm vào câu lệnh' lỗi attempt {attempt}: {e} buttons={last_dbg}")
        time.sleep(0.8)

    last_dbg = _flow_add_prompt_button_debug(driver, limit=60)
    media_dbg = _media_image_candidates_debug(driver, limit=8)
    raise TimeoutException(f"Không bấm/attach được bằng nút Thêm vào câu lệnh. buttons={last_dbg} media={media_dbg}")

def _flow_option_debug(driver):
    try:
        return driver.execute_script(r"""
            return [...document.querySelectorAll('button,[role="button"],[role="tab"]')].map((e,i)=>{
              const r=e.getBoundingClientRect();
              const t=(e.innerText||e.textContent||'').trim();
              const html=e.outerHTML||'';
              const st=getComputedStyle(e);
              return {
                i,
                tag:e.tagName,
                role:e.getAttribute('role'),
                text:t,
                aria:e.getAttribute('aria-label'),
                disabled:!!e.disabled || e.getAttribute('aria-disabled') === 'true',
                expanded:e.getAttribute('aria-expanded'),
                state:e.getAttribute('data-state'),
                rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)},
                visible:st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0,
                html:html.slice(0,260)
              };
            }).filter(x => x.visible && /nano banana|1x|x1|x2|x3|x4|crop_16_9|16:9|hình ảnh|image|video|arrow_drop_down/i.test((x.text||'')+' '+(x.html||''))).slice(0,100);
        """) or []
    except Exception as e:
        return [{"error": str(e)}]


def flow_get_chip_state(driver):
    """Đọc chip composer hiện tại: button aria-haspopup=menu chứa Nano Banana / crop_16_9 / xN."""
    try:
        return driver.execute_script(r"""
            const els=[...document.querySelectorAll('button,[role="button"]')].map((e,i)=>{
              const r=e.getBoundingClientRect();
              const t=(e.innerText||e.textContent||'').trim();
              const html=e.outerHTML||'';
              const st=getComputedStyle(e);
              return {e,i,t,html,r,visible:st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0};
            }).filter(x =>
              x.visible &&
              x.r.top > window.innerHeight*0.45 &&
              (
                x.e.getAttribute('aria-haspopup') === 'menu' ||
                /nano banana|crop_16_9|1x|x1|x2|x3|x4/i.test(x.t + ' ' + x.html)
              ) &&
              !/arrow_forward|add_2|cancel/i.test(x.t + ' ' + x.html)
            );

            function score(x){
              const s=x.t+' '+x.html;
              return (/aria-haspopup="menu"/i.test(s) ? 40 : 0) +
                     (/nano banana/i.test(s) ? 30 : 0) +
                     (/crop_16_9|16:9/i.test(s) ? 20 : 0) +
                     (/1x|x1|x2|x3|x4/i.test(x.t) ? 20 : 0) +
                     (x.r.width > 90 ? 5 : 0) +
                     x.r.left/1000;
            }
            els.sort((a,b)=>score(b)-score(a));
            if(!els.length) return null;
            const x=els[0];
            return {
              i:x.i,
              text:x.t,
              expanded:x.e.getAttribute('aria-expanded'),
              state:x.e.getAttribute('data-state'),
              rect:{x:Math.round(x.r.x),y:Math.round(x.r.y),w:Math.round(x.r.width),h:Math.round(x.r.height)}
            };
        """)
    except Exception:
        return None


def flow_options_panel_open(driver):
    """v132: nhận panel option theo đúng F12:
    <button role="tab" class="flow_tab_slider_trigger">1x/x2/x3/x4</button>
    """
    try:
        return bool(driver.execute_script(r"""
            function visible(e){
              const r=e.getBoundingClientRect();
              const st=getComputedStyle(e);
              return st.display!=='none' && st.visibility!=='hidden' &&
                     r.width>0 && r.height>0 &&
                     r.top >= 0 && r.top <= window.innerHeight &&
                     r.left >= 0 && r.left <= window.innerWidth;
            }
            function txt(e){ return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim(); }
            const countTabs=[...document.querySelectorAll('button[role="tab"],[role="tab"],button.flow_tab_slider_trigger')]
              .filter(visible)
              .filter(e => ['1x','x1','x2','x3','x4'].includes(txt(e)));
            const countTablist=[...document.querySelectorAll('[role="tablist"]')]
              .filter(visible)
              .filter(e => (e.innerText||e.textContent||'').match(/1x|x1|x2|x3|x4/i));
            const ratioTabs=[...document.querySelectorAll('button[role="tab"],[role="tab"],button.flow_tab_slider_trigger')]
              .filter(visible)
              .filter(e => {
                const t=txt(e);
                return t.includes('crop_16_9') || t === '16:9' || (t.includes('16:9') && !t.includes('9:16'));
              });
            return countTabs.length >= 2 || countTablist.length >= 1 || ratioTabs.length >= 1;
        """))
    except Exception:
        return False


def flow_click_menu_button_by_id_or_text(driver, timeout=8):
    """v133: mở menu option bằng chip Nano Banana chắc hơn.
    v132 bị 'no chip candidates' vì filter loại nhầm chip; bản này chọn chip theo điểm số và KHÔNG loại theo html chứa add_2/more_vert.
    """
    end = time.time() + float(timeout)
    last = None

    def _find_chip():
        return driver.execute_script(r"""
            function visible(e){
              const r=e.getBoundingClientRect();
              const st=getComputedStyle(e);
              return st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0 &&
                     r.top>=0 && r.left>=0 && r.top<=window.innerHeight && r.left<=window.innerWidth;
            }
            function txt(e){return (e.innerText||e.textContent||e.getAttribute('aria-label')||'').trim();}
            const items=[...document.querySelectorAll('button,[role="button"]')]
              .map((e,i)=>({e,i,t:txt(e),html:e.outerHTML||'',r:e.getBoundingClientRect(),visible:visible(e)}))
              .filter(x=>x.visible);

            function score(x){
              const low=(x.t+' '+x.html).toLowerCase();
              let s=0;
              if(x.e.getAttribute('aria-haspopup')==='menu') s+=200;
              if(low.includes('nano banana')) s+=2000;
              if(low.includes('crop_16_9') || low.includes('16:9')) s+=1200;
              if(/(^|\s)(1x|x1|x2|x3|x4)(\s|$)/i.test(x.t.replace(/\n/g,' '))) s+=900;
              // chip nằm ở thanh prompt dưới, rộng khoảng 120-190, nhưng không bắt buộc.
              if(x.r.top > window.innerHeight*0.55) s+=150;
              if(x.r.left > window.innerWidth*0.45 && x.r.left < window.innerWidth*0.80) s+=100;
              if(x.r.width>=90 && x.r.width<=240 && x.r.height>=24 && x.r.height<=60) s+=150;
              // Trừ nhẹ các nút chắc chắn không phải chip theo TEXT, không dựa outerHTML.
              const t=x.t.toLowerCase();
              if(t.includes('arrow_forward') || t.includes('add_2') || t.includes('cancel') || t.includes('close') || t.includes('xoá') || t.includes('xóa')) s-=1000;
              if(t.includes('more_vert') || t.includes('filter_list') || t.includes('settings_2') || t.includes('help')) s-=400;
              return s;
            }
            const ranked=items.map(x=>({x,s:score(x)})).filter(o=>o.s>700).sort((a,b)=>b.s-a.s);
            if(ranked.length) return ranked[0].x.e;

            // Fallback cực rộng: button aria-haspopup=menu ở hàng prompt dưới, bỏ qua các menu topbar.
            const fallback=items.filter(x=>x.e.getAttribute('aria-haspopup')==='menu' && x.r.top>window.innerHeight*0.55 && x.r.width>=80)
              .sort((a,b)=>b.r.width-a.r.width);
            return fallback.length ? fallback[0].e : null;
        """)

    def _chip_debug_small():
        try:
            return driver.execute_script(r"""
                function visible(e){const r=e.getBoundingClientRect(); const st=getComputedStyle(e); return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0;}
                function txt(e){return (e.innerText||e.textContent||e.getAttribute('aria-label')||'').trim();}
                return [...document.querySelectorAll('button,[role="button"]')].map((e,i)=>({e,i,t:txt(e),has:e.getAttribute('aria-haspopup'),exp:e.getAttribute('aria-expanded'),r:e.getBoundingClientRect(),vis:visible(e)}))
                  .filter(x=>x.vis && (/nano banana|crop_16_9|1x|x1|x2|x3|x4|menu/i.test((x.t||'')+' '+(x.has||''))))
                  .map(x=>({i:x.i,text:x.t,has:x.has,exp:x.exp,rect:{x:Math.round(x.r.x),y:Math.round(x.r.y),w:Math.round(x.r.width),h:Math.round(x.r.height)}})).slice(0,10);
            """)
        except Exception:
            return []

    def _wait_panel(seconds=1.8):
        stop = time.time() + seconds
        while time.time() < stop:
            if flow_options_panel_open(driver):
                return True
            time.sleep(0.18)
        return False

    while time.time() < end:
        try:
            if flow_options_panel_open(driver):
                print("⚙️ Panel option đã mở")
                return True

            chip = _find_chip()
            if not chip:
                last = {"reason":"no chip candidates", "candidates": _chip_debug_small()}
                time.sleep(0.25)
                continue

            chip_before = flow_get_chip_state(driver)
            try:
                chip_info = driver.execute_script(r"""
                    const e=arguments[0], r=e.getBoundingClientRect();
                    return {text:(e.innerText||e.textContent||'').trim(), has:e.getAttribute('aria-haspopup'), exp:e.getAttribute('aria-expanded'), rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)}};
                """, chip)
                print(f"⚙️ Chip candidate: {chip_info}")
            except Exception:
                pass

            try:
                if chip_before and str(chip_before.get("expanded")).lower() == "true" and not flow_options_panel_open(driver):
                    driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ESCAPE)
                    time.sleep(0.25)
            except Exception:
                pass

            methods = [
                ("center-cdp", lambda: cdp_click_element(driver, chip, 0.50, 0.50, double=False, label="open-nano-chip-center")),
                ("arrow-cdp", lambda: cdp_click_element(driver, chip, 0.90, 0.50, double=False, label="open-nano-chip-arrow")),
                ("dom-event", lambda: _dom_event_click(driver, chip, label="open-nano-chip-dom")),
                ("native-click", lambda: driver.execute_script("arguments[0].click(); return true;", chip)),
                ("enter-key", lambda: (chip.send_keys(Keys.ENTER), True)[1]),
                ("space-key", lambda: (chip.send_keys(Keys.SPACE), True)[1]),
                ("action-click", lambda: (ActionChains(driver).move_to_element(chip).pause(0.08).click().perform(), True)[1]),
            ]

            for label, fn in methods:
                try:
                    fn()
                    time.sleep(0.45)
                    chip_after = flow_get_chip_state(driver)
                    print(f"⚙️ Mở chip bằng {label}: before={chip_before} after={chip_after}")
                    if _wait_panel(1.5):
                        return True
                    if chip_after and str(chip_after.get("expanded")).lower() == "true" and not flow_options_panel_open(driver):
                        try:
                            driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ESCAPE)
                            time.sleep(0.18)
                        except Exception:
                            pass
                except Exception as e:
                    last = f"{label}: {e}"

            last = {"chip_before": chip_before, "chip_now": flow_get_chip_state(driver), "debug": _chip_debug_small()}
        except Exception as e:
            last = e
        time.sleep(0.25)

    print(f"⚠️ Không mở được panel option bằng chip/menu. last={last} debug={_flow_option_debug(driver)[:15]}")
    return False


def flow_open_settings_if_needed(driver, timeout=8):
    if flow_options_panel_open(driver):
        print("⚙️ Panel option đã mở sẵn")
        return True
    opened = flow_click_menu_button_by_id_or_text(driver, timeout=timeout)
    if not opened:
        print("⚠️ Panel option chưa mở thật, vẫn thử tìm option trực tiếp")
    return opened


def click_flow_exact_option(driver, kind, value, timeout=6, required=False):
    """v132: click option theo F12 chắc chắn.
    Count: button[role="tab"].flow_tab_slider_trigger text 1x/x2/x3/x4.
    """
    value = (value or "").lower().strip()
    end = time.time() + float(timeout)
    last = None

    def _click_js():
        return driver.execute_script(r"""
            const kind = arguments[0];
            const value = (arguments[1] || '').toLowerCase().trim();

            function visible(e){
              const r=e.getBoundingClientRect();
              const st=getComputedStyle(e);
              return st.display!=='none' && st.visibility!=='hidden' &&
                     r.width>0 && r.height>0 &&
                     r.top >= 0 && r.top <= window.innerHeight &&
                     r.left >= 0 && r.left <= window.innerWidth &&
                     !(e.disabled || e.getAttribute('aria-disabled') === 'true');
            }
            function text(e){ return (e.innerText || e.textContent || e.getAttribute('aria-label') || '').trim(); }
            function norm(s){ return (s||'').toLowerCase().replace(/\s+/g,' ').trim(); }
            function info(e){
              const r=e.getBoundingClientRect();
              return {
                text:text(e),
                role:e.getAttribute('role'),
                selected:e.getAttribute('aria-selected'),
                state:e.getAttribute('data-state'),
                cls:String(e.className||''),
                rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)}
              };
            }
            function clickFull(el){
              try { el.scrollIntoView({block:'nearest', inline:'center', behavior:'instant'}); } catch(e) {}
              try { el.focus && el.focus(); } catch(e) {}
              const r=el.getBoundingClientRect();
              const opts={
                bubbles:true,cancelable:true,composed:true,view:window,
                clientX:Math.max(1,Math.min(window.innerWidth-2,r.left+r.width/2)),
                clientY:Math.max(1,Math.min(window.innerHeight-2,r.top+r.height/2)),
                button:0,buttons:1
              };
              for (const type of ['pointerover','mouseover','pointerenter','mouseenter','pointerdown','mousedown','pointerup','mouseup','click']) {
                let ev;
                try { ev = type.startsWith('pointer') ? new PointerEvent(type, opts) : new MouseEvent(type, opts); }
                catch(e) { ev = new MouseEvent(type.replace('pointer','mouse'), opts); }
                el.dispatchEvent(ev);
              }
              try { el.click && el.click(); } catch(e) {}
            }

            let all=[...document.querySelectorAll('button[role="tab"],[role="tab"],button.flow_tab_slider_trigger,button')].filter(visible);
            let candidates = all.filter(e => {
              const raw=text(e);
              const t=norm(raw);
              const html=(e.outerHTML||'').toLowerCase();

              if(kind === 'count'){
                const alt = value === '1x' ? 'x1' : (value === 'x1' ? '1x' : value);
                return (t === value || t === alt) &&
                       (e.getAttribute('role') === 'tab' || String(e.className||'').includes('flow_tab_slider_trigger') || html.includes('flow_tab_slider_trigger'));
              }

              if(kind === 'ratio'){
                return (t.includes('crop_16_9') || t === '16:9' || (t.includes('16:9') && !t.includes('9:16'))) &&
                       !t.includes('9:16') &&
                       (e.getAttribute('role') === 'tab' || String(e.className||'').includes('flow_tab_slider_trigger') || html.includes('flow_tab_slider_trigger'));
              }

              if(kind === 'image'){
                return (raw.includes('Hình ảnh') || t === 'image hình ảnh' || (t.includes('image') && !t.includes('video'))) &&
                       !t.includes('video') &&
                       (e.getAttribute('role') === 'tab' || String(e.className||'').includes('flow_tab_slider_trigger') || html.includes('flow_tab_slider_trigger'));
              }
              return false;
            });

            if(!candidates.length) return {ok:false, last:all.slice(-30).map(info)};

            candidates.sort((a,b)=>{
              const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
              const as=(a.getAttribute('role')==='tab'?100:0) +
                       (String(a.className||'').includes('flow_tab_slider_trigger')?80:0) +
                       (a.getAttribute('aria-selected')==='false'?10:0) -
                       Math.abs(ar.width-32)/50;
              const bs=(b.getAttribute('role')==='tab'?100:0) +
                       (String(b.className||'').includes('flow_tab_slider_trigger')?80:0) +
                       (b.getAttribute('aria-selected')==='false'?10:0) -
                       Math.abs(br.width-32)/50;
              return bs-as;
            });

            const el=candidates[0];
            clickFull(el);
            return {ok:true, clicked:info(el), count:candidates.length};
        """, kind, value)

    while time.time() < end:
        try:
            # Với count/ratio/image, nếu chưa thấy option thật thì mở menu bằng chip.
            if kind in ("count", "ratio", "image") and not flow_options_panel_open(driver):
                flow_click_menu_button_by_id_or_text(driver, timeout=2.8)

            clicked_info = _click_js()
            if clicked_info and clicked_info.get("ok"):
                c = clicked_info.get("clicked", {})
                print(f"⚙️ Click option {kind}={value}: text={c.get('text')!r} role={c.get('role')} selected={c.get('selected')} state={c.get('state')} rect={c.get('rect')}")
                time.sleep(0.65)
                return True

            last = clicked_info
        except Exception as ex:
            last = ex
        time.sleep(0.25)

    if required:
        raise TimeoutException(f"Không click được option {kind}={value}. last={last}")
    print(f"⚠️ Không thấy option {kind}={value}. last={last} debug={_flow_option_debug(driver)[:25]}")
    return False



def _parse_chip_count_number(chip_text):
    """v128: đọc số lượng hiện tại trên chip Nano Banana, ví dụ x2/x4/1x."""
    t = (chip_text or '').lower().replace(' ', '')
    for n in (4, 3, 2, 1):
        if f'x{n}' in t or f'{n}x' in t:
            return n
    return 0


def _flow_effective_results_per_round():
    """v129: trả về số ảnh/round theo cấu hình thực, hỗ trợ x1/x2/x3/x4.
    User đã F12 xác nhận Flow mới có tab x3 thật.
    """
    try:
        return max(1, min(4, int(FLOW_RESULTS_PER_ROUND or 2)))
    except Exception:
        return 2

def flow_select_options(driver, desired_count=None):
    print("⚙️ Bắt đầu chọn option Flow: Hình ảnh + 16:9 + số lượng")

    desired = desired_count if desired_count is not None else _flow_effective_results_per_round()
    try:
        desired = int(desired)
    except Exception:
        desired = _flow_effective_results_per_round()
    desired = max(1, min(4, desired))
    if desired >= 4:
        count = "x4"
    elif desired == 3:
        count = "x3"
    elif desired == 2:
        count = "x2"
    else:
        count = "1x"

    chip_before = flow_get_chip_state(driver)
    chip_text = ((chip_before or {}).get("text") or "").lower()
    chip_count = _parse_chip_count_number(chip_text)
    print(f"⚙️ Chip trước option: {chip_before} • cần tối thiểu={desired} ({count}) • chip_count={chip_count}")

    ratio_ok = ("crop_16_9" in chip_text) or ("16:9" in chip_text)
    # v129: ưu tiên đúng số lượng user yêu cầu. F12 xác nhận có tab x3 thật.
    count_aliases = [count]
    if count == "1x":
        count_aliases.append("x1")
    elif count == "x1":
        count_aliases.append("1x")

    exact_count_required = True
    count_ok = False
    if any(alias in chip_text for alias in count_aliases):
        count_ok = True
    elif not exact_count_required and chip_count >= desired:
        count_ok = True

    if ratio_ok and count_ok:
        print(f"⚙️ Option đủ dùng trên chip: 16:9 + chip_count={chip_count} >= cần {desired}")
        return True

    opened = flow_open_settings_if_needed(driver)
    print(f"⚙️ Panel opened={opened}")
    time.sleep(0.45)

    # v133: chip đã là Nano Banana/crop_16_9 nên không cần ép tab Hình ảnh; việc này từng làm mất thời gian khi menu chưa mở.
    if not ratio_ok:
        click_flow_exact_option(driver, "ratio", "16:9", timeout=4, required=False)
    else:
        print("⚙️ Tỷ lệ 16:9 đã đúng trên chip, bỏ qua")

    if not count_ok:
        # v129: thử chọn đúng xN trước. Với x3, Flow mới có role=tab text x3 theo F12 user.
        ok_count = click_flow_exact_option(driver, "count", count, timeout=5, required=False)
        if not ok_count and count == "1x":
            ok_count = click_flow_exact_option(driver, "count", "x1", timeout=3, required=False)
        if not ok_count and count == "x1":
            ok_count = click_flow_exact_option(driver, "count", "1x", timeout=3, required=False)

        # Xác nhận lại chip sau khi click.
        chip_now = flow_get_chip_state(driver)
        chip_now_text = ((chip_now or {}).get("text") or "").lower()
        chip_now_count = _parse_chip_count_number(chip_now_text)
        if any(alias in chip_now_text for alias in count_aliases):
            ok_count = True
            print(f"⚙️ Đã xác nhận chip đổi sang đúng {count}: {chip_now}")

        if not ok_count:
            # fallback mềm: nếu không set được đúng xN thì mới dùng chip hiện tại.
            if chip_now_count >= 1:
                print(f"⚠️ Không chọn được đúng {count}, tạm dùng chip hiện tại x{chip_now_count}: {chip_now}")
            else:
                print(f"⚠️ Không chọn được đúng {count}, tiếp tục với mặc định Flow để tránh fail cứng")
    else:
        print(f"⚙️ Số lượng trên chip đã đúng {count}, bỏ qua chọn count")

    time.sleep(0.5)
    chip_after = flow_get_chip_state(driver)
    print(f"⚙️ Chip sau option: {chip_after}")

    try:
        driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ESCAPE)
    except Exception:
        pass
    time.sleep(0.35)
    return True


def collect_flow_result_urls(driver):
    js = r"""
    return [...document.querySelectorAll('img')]
      .map(img => img.currentSrc || img.src || '')
      .filter(src => src && !src.includes('lh3.googleusercontent.com') && src.includes('media.getMediaUrlRedirect'));
    """
    try:
        urls = driver.execute_script(js) or []
    except Exception:
        urls = []
    # Giữ thứ tự DOM, bỏ trùng.
    out, seen = [], set()
    for u in urls:
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    return out



def click_flow_error_retry_buttons(driver, max_clicks=4):
    """Bấm nút retry/Thử lại ngay trên card lỗi Flow.
    F12 user gửi: button text thường là "refresh\nThử lại" và card có "Không thành công".
    """
    try:
        clicked = driver.execute_script(r"""
            function visible(el){
                const r=el.getBoundingClientRect(), st=getComputedStyle(el);
                return st.display!=='none' && st.visibility!=='hidden' && r.width>10 && r.height>10;
            }
            function norm(s){ return String(s||'').toLowerCase(); }
            const nodes=[...document.querySelectorAll('button,[role="button"],div[aria-label],span[aria-label]')].filter(visible);
            const candidates=[];
            for(const e of nodes){
                const text=norm((e.innerText||e.textContent||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.getAttribute('data-testid')||'')+' '+(e.className||'')+' '+(e.outerHTML||''));
                const hasRetry = text.includes('thử lại') || text.includes('thu lai') || text.includes('try again') || text.includes('retry') || text.includes('refresh');
                const badAction = text.includes('delete_forever') || text.includes('xoá') || text.includes('xóa') || text.includes('close') || text.includes('add_2') || text.includes('tạo') || text.includes('arrow_forward');
                if(hasRetry && !badAction){
                    const r=e.getBoundingClientRect();
                    candidates.push({el:e, text:(e.innerText||e.textContent||e.getAttribute('aria-label')||'').trim(), x:Math.round(r.x), y:Math.round(r.y), w:Math.round(r.width), h:Math.round(r.height)});
                }
            }
            // ưu tiên nút nằm trong/ gần card lỗi có chữ không thành công
            candidates.sort((a,b)=> b.y-a.y);
            const out=[];
            for(const c of candidates.slice(0, arguments[0] || 4)){
                try{
                    c.el.scrollIntoView({block:'center', inline:'center'});
                    c.el.dispatchEvent(new MouseEvent('mouseover',{bubbles:true,clientX:c.x+c.w/2,clientY:c.y+c.h/2}));
                    c.el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:c.x+c.w/2,clientY:c.y+c.h/2}));
                    c.el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,clientX:c.x+c.w/2,clientY:c.y+c.h/2}));
                    c.el.click();
                    out.push({text:c.text, x:c.x, y:c.y, w:c.w, h:c.h});
                }catch(e){}
            }
            return out;
        """, int(max_clicks or 4))
        if clicked:
            print(f"🔁 Flow card retry: đã bấm {len(clicked)} nút Thử lại: {clicked}")
            return len(clicked)
    except Exception as e:
        print(f"⚠️ Không bấm được nút retry card Flow: {e}")
    return 0

def flow_click_generate(driver):
    """v105: bấm đúng nút mũi tên theo F12 user gửi.

    F12 nút gửi thật:
    - text: arrow_forward\nTạo
    - disabled: false
    - rect: x≈496, y≈847, w=32, h=32
    Dùng CDP click theo tọa độ để chắc chắn React nhận sự kiện thật.
    """
    print("▶ Chuẩn bị bấm mũi tên gửi Flow v105 exact...")

    try:
        info = driver.execute_script(r"""
            const all=[...document.querySelectorAll('button,[role="button"]')].map((b,i)=>{
              const r=b.getBoundingClientRect();
              const t=(b.innerText||b.textContent||'').trim();
              const html=b.outerHTML||'';
              const st=getComputedStyle(b);
              const disabled=!!b.disabled || b.getAttribute('aria-disabled')==='true';
              return {b,i,t,html,r,disabled,visible:st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0};
            });

            const candidates = all.filter(x => {
              const combo=(x.t+' '+x.html).toLowerCase();
              return x.visible &&
                     !x.disabled &&
                     x.r.width >= 24 && x.r.width <= 70 &&
                     x.r.height >= 24 && x.r.height <= 70 &&
                     x.r.top > window.innerHeight * 0.50 &&
                     (
                       x.t.includes('arrow_forward') ||
                       x.html.includes('arrow_forward')
                     ) &&
                     !/add_2|nano banana|crop_16_9|1x|x1|x2|x3|x4|close|cancel|xoá|xóa/i.test(combo);
            });

            candidates.sort((a,b)=>{
              const as = (a.t.includes('arrow_forward')?100:0) + a.r.left/10 + a.r.top/100 - Math.abs(a.r.width-32);
              const bs = (b.t.includes('arrow_forward')?100:0) + b.r.left/10 + b.r.top/100 - Math.abs(b.r.width-32);
              return bs-as;
            });

            const sample = all.filter(x => x.visible && x.r.top > window.innerHeight*0.50)
              .map(x => ({i:x.i,text:x.t,disabled:x.disabled,rect:{x:Math.round(x.r.x),y:Math.round(x.r.y),w:Math.round(x.r.width),h:Math.round(x.r.height)}}))
              .slice(-12);

            if(!candidates.length){
              return {ok:false, reason:'no exact arrow_forward candidate', sample};
            }

            const x=candidates[0], el=x.b;
            el.scrollIntoView({block:'center', inline:'center'});
            el.focus();
            window.__flowSendButton = el;
            const r=el.getBoundingClientRect();
            return {
              ok:true,
              index:x.i,
              text:x.t,
              disabled:x.disabled,
              rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)},
              center:{x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)},
              sample
            };
        """)

        if not info or not info.get('ok'):
            print(f"⚠️ Không tìm được arrow_forward exact. info={info}")
        else:
            c = info.get('center') or {}
            x = int(c.get('x') or 0)
            y = int(c.get('y') or 0)
            print(f"▶ Tìm thấy mũi tên gửi: text={info.get('text')!r} rect={info.get('rect')} center=({x},{y})")

            try:
                driver.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mouseMoved', 'x':x, 'y':y, 'button':'left', 'buttons':0})
                time.sleep(0.08)
                driver.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mousePressed', 'x':x, 'y':y, 'button':'left', 'buttons':1, 'clickCount':1})
                time.sleep(0.08)
                driver.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mouseReleased', 'x':x, 'y':y, 'button':'left', 'buttons':0, 'clickCount':1})
                print("▶ CDP click mũi tên gửi OK")
            except Exception as e:
                print(f"⚠️ CDP click lỗi, fallback JS click: {e}")
                driver.execute_script("if(window.__flowSendButton){ window.__flowSendButton.click(); return true; } return false;")

            time.sleep(0.5)
            try:
                still = driver.execute_script(r"""
                    const b=window.__flowSendButton;
                    if(!b) return false;
                    const r=b.getBoundingClientRect();
                    const st=getComputedStyle(b);
                    const visible=st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0;
                    const disabled=!!b.disabled || b.getAttribute('aria-disabled')==='true';
                    const hasProgress=[...document.querySelectorAll('*')].some(e=>/\b\d{1,3}%\b/.test((e.innerText||e.textContent||'')));
                    if(visible && !disabled && !hasProgress){ b.click(); return true; }
                    return false;
                """)
                if still:
                    print("▶ JS fallback click mũi tên gửi thêm 1 lần")
            except Exception:
                pass

            print("⏳ Đã gửi lệnh Tạo, chờ Flow trả ảnh...")
            return True
    except Exception as e:
        print(f"⚠️ Lỗi click mũi tên gửi v104: {e}")

    for b in reversed(find_buttons(driver)):
        try:
            txt = element_text(b).lower()
            combo = " | ".join([txt, b.get_attribute('aria-label') or '', b.get_attribute('title') or '']).lower()
            if 'arrow_forward' in combo and 'add_2' not in combo:
                if b.is_displayed() and b.is_enabled():
                    js_click(driver, b)
                    print(f"▶ Đã bấm mũi tên gửi Flow fallback selenium: {element_text(b)!r}")
                    print("⏳ Đã gửi lệnh Tạo, chờ Flow trả ảnh...")
                    return True
        except Exception:
            pass
    return click_button_contains(driver, 'Tạo', excludes=['add_2'], timeout=5, required=True)

def wait_for_new_flow_results(driver, before_urls, expected=4, timeout=300, card_retry_limit=None):
    before = set(before_urls or [])
    end = time.time() + timeout
    stable_start = None
    last_count = 0
    last_new = []
    fail_seen_at = None
    card_retry_count = 0
    if card_retry_limit is None:
        card_retry_limit = FLOW_CARD_RETRIES

    while time.time() < end:
        urls = collect_flow_result_urls(driver)
        new_urls = [u for u in urls if u not in before]
        if len(new_urls) != last_count:
            last_count = len(new_urls)
            stable_start = time.time()
            last_new = new_urls
            print(f"🖼️ Flow ảnh mới: {len(new_urls)}/{expected}")

        fail_msg = detect_flow_generation_failed(driver)
        if fail_msg:
            if fail_seen_at is None:
                fail_seen_at = time.time()
                print(f"⚠️ Flow báo tạo lỗi: {fail_msg} • ảnh mới hiện có {len(new_urls)}/{expected}")
            # Nếu đã có đủ ảnh mới thì cứ lấy, nếu không đủ sau vài giây thì báo retry round.
            if len(new_urls) >= expected:
                if stable_start is None:
                    stable_start = time.time()
                if time.time() - stable_start >= RESULT_STABLE_SECONDS:
                    return new_urls[:expected]
            elif time.time() - fail_seen_at >= 5:
                if card_retry_count < int(card_retry_limit or 0):
                    clicked = click_flow_error_retry_buttons(driver, max_clicks=max(1, expected))
                    if clicked:
                        card_retry_count += 1
                        print(f"🔁 Flow bấm Retry trên card lỗi lần {card_retry_count}/{card_retry_limit}; tiếp tục chờ kết quả")
                        fail_seen_at = None
                        stable_start = None
                        time.sleep(6)
                        continue
                close_failed_generation_cards(driver)
                raise FlowGenerationFailed(f"{fail_msg}; đã bấm retry card {card_retry_count}/{card_retry_limit}; mới có {len(new_urls)}/{expected} ảnh")

        if len(new_urls) >= expected:
            if stable_start is None:
                stable_start = time.time()
            if time.time() - stable_start >= RESULT_STABLE_SECONDS:
                return new_urls[:expected]
        time.sleep(1.0)

    # Timeout nhưng nếu đang có lỗi policy thì phân biệt để retry round, không khóa account.
    fail_msg = detect_flow_generation_failed(driver)
    if fail_msg:
        close_failed_generation_cards(driver)
        raise FlowGenerationFailed(f"{fail_msg}; timeout, mới có {len(last_new)}/{expected} ảnh")
    raise TimeoutException(f"Không thấy đủ {expected} ảnh mới từ Flow. Hiện có {len(last_new)} ảnh mới")


def build_requests_session_from_driver(driver):
    s = requests.Session()
    try:
        ua = driver.execute_script("return navigator.userAgent") or "Mozilla/5.0"
    except Exception:
        ua = "Mozilla/5.0"
    s.headers.update({
        "User-Agent": ua,
        "Referer": FLOW_URL,
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    })
    try:
        for c in driver.get_cookies():
            domain = c.get("domain") or None
            s.cookies.set(c.get("name"), c.get("value"), domain=domain)
    except Exception:
        pass
    return s


def browser_fetch_bytes(driver, url, timeout=90):
    abs_url = urljoin("https://labs.google", url)
    script = r"""
    const url = arguments[0];
    const done = arguments[arguments.length - 1];
    fetch(url, {credentials:'include'})
      .then(r => { if(!r.ok) throw new Error('HTTP '+r.status); return r.blob(); })
      .then(blob => {
        const reader = new FileReader();
        reader.onloadend = () => done({ok:true, data:String(reader.result)});
        reader.onerror = () => done({ok:false, error:'FileReader error'});
        reader.readAsDataURL(blob);
      })
      .catch(e => done({ok:false, error:String(e)}));
    """
    old_timeout = None
    try:
        old_timeout = driver.timeouts.script
    except Exception:
        pass
    try:
        driver.set_script_timeout(timeout)
    except Exception:
        pass
    res = driver.execute_async_script(script, abs_url)
    if not res or not res.get("ok"):
        raise RuntimeError(f"browser fetch lỗi: {res}")
    data_url = res.get("data") or ""
    if "," not in data_url:
        raise RuntimeError("browser fetch không trả data URL")
    return base64.b64decode(data_url.split(",", 1)[1])


def download_flow_image_bytes(driver, url):
    abs_url = urljoin("https://labs.google", url)
    # 1) requests + cookie
    try:
        s = build_requests_session_from_driver(driver)
        r = s.get(abs_url, stream=True, timeout=DOWNLOAD_TIMEOUT, allow_redirects=True)
        r.raise_for_status()
        data = r.content
        # verify nhanh là ảnh
        with Image.open(io.BytesIO(data)) as im:
            im.verify()
        return data
    except Exception as e:
        print(f"⚠ requests tải ảnh lỗi, fallback browser fetch: {e}")
    # 2) fetch trong browser đang đăng nhập
    data = browser_fetch_bytes(driver, abs_url, timeout=DOWNLOAD_TIMEOUT)
    with Image.open(io.BytesIO(data)) as im:
        im.verify()
    return data



def _flow_download_dir():
    p = Path(BASE_DIR) / "_flow_downloads" / f"pid_{os.getpid()}"
    p.mkdir(parents=True, exist_ok=True)
    return str(p)


def ensure_browser_download_dir(driver, download_dir=None):
    """Ép Chrome tải file về folder đã biết để tool đọc lại file từ menu Tải xuống."""
    download_dir = download_dir or _flow_download_dir()
    os.makedirs(download_dir, exist_ok=True)
    try:
        driver.execute_cdp_cmd("Page.setDownloadBehavior", {"behavior": "allow", "downloadPath": download_dir})
    except Exception:
        try:
            driver.execute_cdp_cmd("Browser.setDownloadBehavior", {"behavior": "allow", "downloadPath": download_dir})
        except Exception as e:
            print(f"⚠ Không set được download dir CDP, dùng prefs mặc định. err={e}")
    return download_dir


def snapshot_download_dir(download_dir):
    p = Path(download_dir)
    p.mkdir(parents=True, exist_ok=True)
    return {str(x.resolve()) for x in p.glob("*")}


def wait_new_download_file(download_dir, before_set, timeout=DOWNLOAD_TIMEOUT):
    """Chờ file mới tải xong, bỏ qua .crdownload/.tmp."""
    end = time.time() + max(20, int(timeout or DOWNLOAD_TIMEOUT))
    dl = Path(download_dir)
    last = []
    while time.time() < end:
        files = list(dl.glob("*"))
        new_files = [x for x in files if str(x.resolve()) not in before_set]
        last = [x.name for x in new_files]
        if any(x.name.endswith(".crdownload") or x.name.endswith(".tmp") for x in new_files):
            time.sleep(0.7)
            continue
        finished = [x for x in new_files if x.is_file() and not x.name.endswith(".crdownload") and not x.name.endswith(".tmp")]
        if finished:
            finished.sort(key=lambda x: x.stat().st_mtime, reverse=True)
            # đợi size ổn định 2 nhịp ngắn
            f = finished[0]
            s1 = f.stat().st_size
            time.sleep(0.5)
            s2 = f.stat().st_size if f.exists() else -1
            if s1 == s2 and s2 > 1024:
                return str(f)
        time.sleep(0.7)
    raise TimeoutException(f"Timeout chờ file tải xong từ Flow. last={last}")


def _media_name_from_url(url):
    m = re.search(r"[?&]name=([^&]+)", str(url or ""))
    return m.group(1) if m else ""


def flow_open_more_menu_for_result_url(driver, url, timeout=20):
    """Mở menu more_vert đúng card ảnh kết quả theo src/name."""
    target = str(url or "")
    name = _media_name_from_url(target)
    end = time.time() + timeout
    last = None
    while time.time() < end:
        try:
            res = driver.execute_script(r"""
                const target = arguments[0] || '';
                const name = arguments[1] || '';
                function visible(el){
                    if(!el) return false;
                    const st=getComputedStyle(el);
                    const r=el.getBoundingClientRect();
                    return st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0;
                }
                function mediaMatch(img){
                    const src = img.currentSrc || img.src || '';
                    if(!src || !src.includes('media.getMediaUrlRedirect')) return false;
                    if(target && src === target) return true;
                    if(name && src.includes(name)) return true;
                    return false;
                }
                const imgs = [...document.querySelectorAll('img')].filter(img=>{
                    if(!visible(img) || !mediaMatch(img)) return false;
                    const r=img.getBoundingClientRect();
                    return r.width >= 100 && r.height >= 100;
                });
                if(!imgs.length) return {ok:false, reason:'no img match', target, name, count:[...document.querySelectorAll('img')].length};
                imgs.sort((a,b)=>{
                    const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                    return (br.width*br.height) - (ar.width*ar.height);
                });
                const img = imgs[0];
                const ir = img.getBoundingClientRect();

                let card = img;
                let node = img;
                for(let k=0; node && k<10; k++, node=node.parentElement){
                    const r=node.getBoundingClientRect();
                    if(r.width >= ir.width && r.height >= ir.height && r.width <= Math.max(1400, ir.width+450) && r.height <= Math.max(1000, ir.height+450)) card = node;
                }

                let scope = card;
                let menu = null;
                for(let up=0; scope && up<6 && !menu; up++, scope=scope.parentElement){
                    const buttons=[...scope.querySelectorAll('button,[role="button"]')].filter(visible);
                    menu = buttons.find(b=>{
                        const t=((b.innerText||b.textContent||'')+' '+(b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'')+' '+(b.outerHTML||'')).toLowerCase();
                        return t.includes('more_vert') || t.includes('tùy chọn khác') || t.includes('tuy chon khac');
                    });
                    if(!menu){
                        const cr=card.getBoundingClientRect();
                        menu = buttons.find(b=>{
                            const r=b.getBoundingClientRect();
                            return r.width<=70 && r.height<=70 && r.x > cr.x + cr.width*0.65 && r.y < cr.y + cr.height*0.35;
                        });
                    }
                }
                if(!menu) return {ok:false, reason:'no more_vert button', imgRect:{x:Math.round(ir.x),y:Math.round(ir.y),w:Math.round(ir.width),h:Math.round(ir.height)}};
                menu.scrollIntoView({block:'center', inline:'center'});
                menu.focus();
                for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
                    const ev = type.startsWith('pointer')
                        ? new PointerEvent(type, {bubbles:true, cancelable:true, pointerType:'mouse'})
                        : new MouseEvent(type, {bubbles:true, cancelable:true, view:window});
                    menu.dispatchEvent(ev);
                }
                if(typeof menu.click === 'function') menu.click();
                const mr=menu.getBoundingClientRect();
                return {ok:true, imgRect:{x:Math.round(ir.x),y:Math.round(ir.y),w:Math.round(ir.width),h:Math.round(ir.height)}, menuText:(menu.innerText||menu.textContent||'').trim(), menuRect:{x:Math.round(mr.x),y:Math.round(mr.y),w:Math.round(mr.width),h:Math.round(mr.height)}};
            """, target, name)
            if res and res.get('ok'):
                print(f"⋮ Mở menu ảnh OK: rect={res.get('imgRect')} menu={res.get('menuText')!r}")
                time.sleep(0.6)
                return True
            last = res
        except Exception as e:
            last = e
        time.sleep(0.5)
    raise TimeoutException(f"Không mở được menu more_vert cho ảnh Flow. last={last}")


def flow_click_download_in_open_menu(driver, timeout=20):
    """Click mục Tải xuống trong menu đang mở."""
    end = time.time() + timeout
    last = None
    while time.time() < end:
        try:
            res = driver.execute_script(r"""
                function visible(el){
                    if(!el) return false;
                    const st=getComputedStyle(el);
                    const r=el.getBoundingClientRect();
                    return st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0;
                }
                const elems=[...document.querySelectorAll('button,[role="button"],[role="menuitem"],div,span,a')].filter(visible);
                const item = elems.find(el=>{
                    const t=((el.innerText||el.textContent||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')).toLowerCase();
                    return t.includes('tải xuống') || t.includes('tai xuong') || t.includes('download');
                });
                if(!item){
                    const sample=elems.map((e,i)=>({i,text:(e.innerText||e.textContent||'').trim(), role:e.getAttribute('role')})).filter(x=>x.text).slice(-15);
                    return {ok:false, reason:'no download item', sample};
                }
                item.scrollIntoView({block:'center', inline:'center'});
                item.focus();
                for (const type of ['pointerdown','mousedown','pointerup','mouseup','click']) {
                    const ev = type.startsWith('pointer')
                        ? new PointerEvent(type, {bubbles:true, cancelable:true, pointerType:'mouse'})
                        : new MouseEvent(type, {bubbles:true, cancelable:true, view:window});
                    item.dispatchEvent(ev);
                }
                if(typeof item.click === 'function') item.click();
                const r=item.getBoundingClientRect();
                return {ok:true, text:(item.innerText||item.textContent||'').trim(), rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)}};
            """)
            if res and res.get('ok'):
                print(f"⬇ Bấm menu Tải xuống OK: {res.get('text')!r}")
                time.sleep(0.8)
                return True
            last = res
        except Exception as e:
            last = e
        time.sleep(0.4)
    raise TimeoutException(f"Không click được mục Tải xuống trong menu. last={last}")


def download_flow_image_via_ui_menu(driver, url, timeout=DOWNLOAD_TIMEOUT):
    """Tải ảnh qua UI Flow: more_vert -> Tải xuống -> đọc file download. Fallback sẽ dùng direct fetch."""
    dl = ensure_browser_download_dir(driver)
    before = snapshot_download_dir(dl)
    flow_open_more_menu_for_result_url(driver, url, timeout=20)
    flow_click_download_in_open_menu(driver, timeout=20)
    file_path = wait_new_download_file(dl, before, timeout=max(timeout, 90))
    print(f"✅ File Flow tải về: {file_path}")
    raw = Path(file_path).read_bytes()
    try:
        Path(file_path).unlink(missing_ok=True)
    except Exception:
        pass
    # verify ảnh
    with Image.open(io.BytesIO(raw)) as im:
        im.verify()
    return raw


def read_prompt():
    if str(ARGS.prompt or "").strip():
        return str(ARGS.prompt).strip()
    p = Path(BASE_DIR) / "flow_prompt.txt"
    if p.is_file():
        try:
            text = p.read_text(encoding="utf-8").strip()
            if text:
                return text
        except Exception:
            pass
    return DEFAULT_PROMPT

# ----------------------------- Processing -----------------------------

class ImageQuotaReached(Exception):
    pass


class FlowGenerationFailed(Exception):
    pass


def detect_flow_generation_failed(driver):
    """Detect và phân loại lỗi Flow: abnormal / content-policy / general failed."""
    try:
        body = (driver.find_element(By.TAG_NAME, "body").text or "").lower()
    except Exception:
        return ""
    abnormal_keys = ["hoạt động bất thường", "hoat dong bat thuong", "abnormal activity", "unusual activity", "suspicious"]
    if any(k in body for k in abnormal_keys):
        return "FlowAbnormalActivity: Flow báo hoạt động bất thường / session bị nghi ngờ"
    policy_keys = [
        "không thành công", "khong thanh cong", "có thể vi phạm", "co the vi pham",
        "chính sách", "chinh sach", "try another prompt", "generation failed", "failed",
    ]
    if any(k in body for k in policy_keys):
        # tránh nhầm với footer cảnh báo chung của Flow nếu không có chữ Không thành công/failed
        if ("không thành công" in body or "khong thanh cong" in body or "generation failed" in body or "try another prompt" in body or "có thể vi phạm" in body or "co the vi pham"):
            return "FlowContentPolicy: Flow tạo ảnh không thành công / nghiêng về nội dung, prompt hoặc policy"
    return ""


def close_failed_generation_cards(driver):
    """Thử đóng/xóa card lỗi để lần retry không bị cản UI."""
    try:
        driver.execute_script(r"""
            function visible(el){
                const r=el.getBoundingClientRect(), st=getComputedStyle(el);
                return st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0;
            }
            const nodes=[...document.querySelectorAll('button,[role="button"]')].filter(visible);
            const badButtons=nodes.filter(b=>{
                const t=((b.innerText||b.textContent||'')+' '+(b.getAttribute('aria-label')||'')+' '+(b.outerHTML||'')).toLowerCase();
                return t.includes('delete') || t.includes('xóa') || t.includes('xoá') || t.includes('close');
            });
            for(const b of badButtons.slice(0,4)){
                try{ b.click(); }catch(e){}
            }
        """)
    except Exception:
        pass


def looks_like_quota_or_account_error(driver):
    try:
        body = (driver.find_element(By.TAG_NAME, "body").text or "").lower()
    except Exception:
        return ""
    quota_keys = ["hết lượt", "limit", "quota", "try again tomorrow", "tạm thời không thể", "not enough", "usage"]
    if any(k in body for k in quota_keys):
        return "quota_or_limit"
    if "accounts.google.com" in (driver.current_url or "").lower() or "đăng nhập" in body or "sign in" in body:
        return "login_required"
    return ""


def process_folder_project(driver, folder, target_files, prompt):
    need = len(target_files)
    if need <= 0:
        return []
    print(f"\n📁 Flow project: {folder} • cần {need} ảnh • rounds={math.ceil(need / _flow_effective_results_per_round())} • v134 direct-fetch-first+chip-candidate-fix+x3-tabs+source-guard+1x-fix+anti-flash+hard-stop")
    for p in target_files:
        emit_event("job_start", path=str(p), account=current_account_label())
        update_job_manifest(str(p), "running", note="Flow project đang xử lý")

    flow_open(driver)
    created = flow_create_new_project(driver)
    print("🆕 Project mới:" , "OK" if created else "không cần/không bấm được, dùng composer hiện tại")
    wait_flow_ready(driver, timeout=60)

    input_image = str(target_files[0])
    collected_urls = []
    seen_all = set(collect_flow_result_urls(driver))
    per_round = _flow_effective_results_per_round()
    rounds = math.ceil(need / per_round)

    for round_idx in range(1, rounds + 1):
        remaining = need - len(collected_urls)
        expected = min(per_round, max(1, remaining if remaining < per_round else per_round))
        print(f"🎬 Flow round {round_idx}/{rounds} • lấy tối đa {expected}/{per_round} (safe per-round)")
        # Quy trình chuẩn theo yêu cầu user:
        # upload ảnh -> đợi upload xong -> ghi prompt -> chọn 16:9 và số ảnh -> bấm mũi tên.
        round_ok = False
        # v3.3: Retry Flow được điều khiển ở cấp thư mục (FLOW_FOLDER_RETRIES).
        # Không retry lồng thêm trong process_folder_project, tránh 1 thư mục bị thử 6 lần làm chờ 8-10 phút chưa ra ảnh.
        max_round_retry = max(0, int(os.environ.get("FLOW_MAX_ROUND_RETRY", "0") or 0))
        for gen_attempt in range(1, max_round_retry + 2):
            before = set(collect_flow_result_urls(driver)) | seen_all
            print(f"🪜 Quy trình round {round_idx} attempt {gen_attempt}: upload ảnh -> đợi preview -> prompt -> force mở picker -> chọn thumb exact -> nhận thumb prompt/Thêm vào câu lệnh -> 16:9/x{expected} -> tạo")

            # Nếu retry sau lỗi policy, tạo project mới sạch để tránh card lỗi cản UI.
            if gen_attempt > 1:
                print(f"🔁 Retry Flow round {round_idx} do lần trước tạo lỗi/không đủ ảnh")
                try:
                    flow_open(driver)
                    flow_create_new_project(driver)
                    wait_flow_ready(driver, timeout=60)
                except Exception as e:
                    print(f"⚠️ Retry tạo project mới không thành, tiếp tục composer hiện tại: {e}")
                before = set(collect_flow_result_urls(driver)) | seen_all

            try:
                flow_upload_image(driver, input_image)
                time.sleep(0.8)
                # v116: bỏ kéo ảnh. Nhập prompt trước, sau đó bấm nút "Thêm vào câu lệnh" trong panel upload.
                flow_set_prompt(driver, prompt)
                time.sleep(0.35)
                attach_ok = flow_click_add_to_prompt_button(driver, uploaded_name=input_image, timeout=45)
                print(f"➕ Add-to-prompt step result: {attach_ok}")
                time.sleep(0.45)
                flow_select_options(driver, expected)
                time.sleep(0.35)
                # v111/v114: cập nhật mốc BEFORE sau khi upload/attach, ngay trước lúc bấm Tạo.
                # Nếu không, URL preview của ảnh gốc upload sẽ bị tính nhầm là ảnh Flow mới,
                # dẫn đến file final chỉ là ảnh gốc + logo nhưng vẫn báo done.
                before = set(collect_flow_result_urls(driver)) | seen_all
                print(f"🛡️ Source-guard before generate: đang loại {len(before)} URL có sẵn/upload khỏi kết quả mới")
                flow_click_generate(driver)

                err = looks_like_quota_or_account_error(driver)
                if err == "quota_or_limit":
                    raise ImageQuotaReached("Flow báo hết lượt / limit")
                if err == "login_required":
                    raise RuntimeError("Flow yêu cầu đăng nhập lại")

                new_urls = wait_for_new_flow_results(driver, before, expected=expected, timeout=420, card_retry_limit=FLOW_CARD_RETRIES)
                print(f"✅ Flow round {round_idx}: thấy {len(new_urls)} ảnh mới")
                collected_urls.extend(new_urls)
                seen_all.update(new_urls)
                time.sleep(1.0)
                round_ok = True
                break
            except ImageQuotaReached:
                raise
            except Exception as e:
                print(f"⚠️ Flow round {round_idx} attempt {gen_attempt} lỗi trước/trong lúc tạo: {e}")
                if gen_attempt > max_round_retry:
                    raise
                # v116: trên máy chậm/scale khác, upload/add-to-prompt đôi khi không gắn thumb.
                # Tạo lại project sạch rồi thử lại thay vì mark job lỗi ngay.
                try:
                    flow_open(driver)
                    flow_create_new_project(driver)
                    wait_flow_ready(driver, timeout=80)
                    time.sleep(1.0)
                except Exception as e2:
                    print(f"⚠️ Reset project sau lỗi attempt không thành: {e2}")
                continue

        if not round_ok:
            raise FlowGenerationFailed(f"Round {round_idx} không tạo đủ ảnh sau retry")

    final_infos = []
    # v111: giữ một bản copy ảnh gốc đã upload để so sánh. Không dùng trực tiếp input_image,
    # vì target_files[0] sẽ bị ghi đè trước, làm guard mất mốc gốc cho các ảnh sau.
    source_guard_path = input_image
    try:
        source_guard_path = os.path.join(DEBUG_DIR, f"_source_guard_{os.getpid()}_{int(time.time()*1000)}.png")
        shutil.copy2(input_image, source_guard_path)
    except Exception:
        source_guard_path = input_image
    try:
        for idx, target_path in enumerate(target_files):
            url = collected_urls[idx]
            print(f"⬇ Tải ảnh {idx+1}/{need} ưu tiên direct_fetch -> {target_path.name}")
            try:
                raw = download_flow_image_bytes(driver, url)
                info = prepare_download_to_final(raw, target_path, source_path=source_guard_path)
                download_method = "direct_fetch"
            except Exception as e:
                print(f"⚠ direct_fetch lỗi, fallback UI menu: {e}")
                raw = download_flow_image_via_ui_menu(driver, url, timeout=DOWNLOAD_TIMEOUT)
                download_method = "ui_menu"
                info = prepare_download_to_final(raw, target_path, source_path=source_guard_path)
            info["flow_url"] = url[:200]
            info["download_method"] = download_method
            final_infos.append(info)
            update_job_manifest(str(target_path), "done", final=info)
            emit_event("job_done", path=str(target_path), final=info, account=current_account_label())
            print(f"✅ Final OK: {target_path} • {info.get('width')}x{info.get('height')} • {info.get('size_mb')}MB • method={download_method}")
    finally:
        try:
            if source_guard_path and os.path.abspath(source_guard_path) != os.path.abspath(input_image):
                os.remove(source_guard_path)
        except Exception:
            pass
    return final_infos


_current_account = 1

def current_account_label():
    return _current_account


def flow_safe_sleep_between_folders():
    """v3.7 Flow Safe: nghỉ ngẫu nhiên giữa các thư mục Flow để giảm lỗi hoạt động bất thường.
    Các worker khác/Gemini lane vẫn chạy nên tổng thể không bị đứng.
    """
    try:
        lo = float(FLOW_SAFE_DELAY_MIN)
        hi = float(FLOW_SAFE_DELAY_MAX)
        if hi < lo:
            hi = lo
        delay = random.uniform(lo, hi)
        if delay > 0:
            print(f"🛌 Flow Safe nghỉ {delay:.1f}s trước thư mục Flow tiếp theo; Gemini lanes vẫn chạy")
            time.sleep(delay)
    except Exception:
        pass


def _norm_skip_path(path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(str(path))))
    except Exception:
        return os.path.normcase(os.path.normpath(str(path)))


def load_worker_skiplist():
    try:
        if not WORKER_SKIPLIST_PATH or not os.path.isfile(WORKER_SKIPLIST_PATH):
            return set()
        with open(WORKER_SKIPLIST_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            items = data.get("skip") or []
        elif isinstance(data, list):
            items = data
        else:
            items = []
        return {_norm_skip_path(x) for x in items}
    except Exception:
        return set()


def is_worker_path_cancelled(path):
    return _norm_skip_path(path) in load_worker_skiplist()


def process_all_with_account(profile_path, account_index, groups, prompt, mode="regular"):
    global _current_account
    _current_account = account_index
    headless = HEADLESS_FOR_PRO if mode == "pro" else HEADLESS_FOR_REGULAR
    print(f"🔑 Đang dùng account local {account_index} • mode={mode} • headless={headless}")
    emit_event("account_switch", account=account_index, mode=mode)
    drv = None
    try:
        drv, _wait = ensure_flow_session(profile_path, account_index, headless=headless)
        emit_event("worker_ready", account=account_index)
        ok = 0
        failed = 0
        skipped = 0
        consecutive_folder_errors = 0
        for folder, files in groups:
            active_files = []
            for p in files:
                if manifest_status(str(p)) == "done":
                    continue
                if is_worker_path_cancelled(p):
                    print(f"↪ Skip job đã được tài khoản rảnh nhận bớt: {p}")
                    emit_event("job_skipped", path=str(p), reason="Đã chuyển sang worker/account khác", account=account_index)
                    continue
                active_files.append(p)
            files = active_files
            if not files:
                continue
            attempt = 0
            while True:
                attempt += 1
                try:
                    print(f"🔁 Flow thử thư mục lần {attempt}/{FLOW_FOLDER_RETRIES + 1}: {folder}")
                    process_folder_project(drv, folder, files, prompt)
                    ok += len(files)
                    consecutive_folder_errors = 0
                    break
                except ImageQuotaReached as e:
                    for p in files:
                        emit_event("quota", path=str(p), message=str(e), error_type="quota", account_exhaust=True, account=account_index)
                    raise
                except Exception as e:
                    err_msg = str(e)
                    print(f"⚠ Lỗi folder {folder}: {err_msg}")
                    policy_like = ("FlowContentPolicy" in err_msg or "Flow tạo ảnh không thành công" in err_msg or "có thể bị policy" in err_msg or "không thành công" in err_msg or "khong thanh cong" in err_msg)
                    abnormal_like = ("FlowAbnormalActivity" in err_msg or "hoạt động bất thường" in err_msg.lower() or "abnormal" in err_msg.lower())
                    # Với lỗi card "Không thành công", wait_for_new_flow_results đã bấm nút Thử lại trên card đủ FLOW_CARD_RETRIES.
                    # Không retry cả project nữa để tránh mất 8-10 phút; chuyển Gemini ngay.
                    # v4.3: abnormal là lỗi account/session/proxy bị nghi ngờ, không retry Flow project lần 2 nữa.
                    # Retry project chỉ dành cho lỗi kỹ thuật/UI như input/upload/timeout.
                    if (not policy_like) and (not abnormal_like) and attempt <= FLOW_FOLDER_RETRIES:
                        for p in files:
                            emit_event("job_retry", path=str(p), attempt=attempt, max_attempts=FLOW_FOLDER_RETRIES, message=err_msg, error_type=type(e).__name__, account=account_index)
                        try:
                            drv.refresh(); time.sleep(4); close_popups(drv)
                        except Exception:
                            pass
                        continue
                    if abnormal_like:
                        print("⏭ FlowAbnormalActivity: cooldown Flow/proxy, chuyển Gemini fallback")
                    elif policy_like:
                        print("⏭ FlowContentPolicy: lỗi nội dung/policy sau retry card; chuyển Gemini fallback, không retry project nữa")
                    failed += len(files)
                    consecutive_folder_errors += 1
                    for p in files:
                        update_job_manifest(str(p), "error", message=err_msg, error_type=type(e).__name__)
                        emit_event("job_error", path=str(p), message=err_msg, error_type=type(e).__name__, account_exhaust=False, account=account_index)
                    if FLOW_MAX_CONSECUTIVE_FOLDER_ERRORS and consecutive_folder_errors >= FLOW_MAX_CONSECUTIVE_FOLDER_ERRORS:
                        print(f"⏭ Flow lỗi liên tiếp {consecutive_folder_errors} folder trên account local {account_index}; Flow Safe bật cooldown/fallback sớm")
                        emit_event("job_retry", path=str(files[-1]) if files else "", attempt="Flow", max_attempts="Gemini", message=f"Flow lỗi liên tiếp {consecutive_folder_errors} folder; Flow Safe chuyển sớm sang Gemini fallback", error_type="FlowEarlyFallback", account=account_index)
                        return ok, failed, skipped
                    break
            flow_safe_sleep_between_folders()
        return ok, failed, skipped
    finally:
        safe_quit_driver(drv)


def main():
    print("🚀 Flow Auto Router Project X4 • v4.3 Safe Proxy Lane")
    print("🌐 Flow URL:", FLOW_URL)
    print("📁 Root:", ROOT_FOLDER)
    emit_event("config", root=ROOT_FOLDER, logo=LOGO_PATH, flow_url=FLOW_URL, results_per_round=FLOW_RESULTS_PER_ROUND, final_min_mb=FINAL_MIN_IMAGE_MB, input_skip_over_mb=INPUT_SKIP_OVER_MB)

    if not ROOT_FOLDER or not os.path.isdir(ROOT_FOLDER):
        print("❌ Thư mục root không tồn tại")
        raise SystemExit(1)
    if LOGO_PATH and not os.path.isfile(LOGO_PATH):
        print("⚠ Logo không tồn tại, sẽ chạy không chèn logo:", LOGO_PATH)
    ensure_browser_files()

    num_accounts = load_num_accounts()
    profiles = []
    for i in range(num_accounts):
        profile_path = os.path.join(BASE_DIR, "profiles", f"google_{i+1}")
        os.makedirs(profile_path, exist_ok=True)
        profiles.append(profile_path)

    groups, skipped = scan_target_files(ROOT_FOLDER)
    for path, reason in skipped:
        print(f"⏭ Skip: {path} • {reason}")
    total_files = sum(len(files) for _folder, files in groups)
    print(f"📦 Tìm thấy {len(groups)} thư mục cần vẽ, tổng {total_files} ảnh")
    if total_files <= 0:
        emit_event("worker_summary", success=0, failed=0, skipped=len(skipped))
        print("✅ Không có ảnh cần xử lý")
        return

    prompt = read_prompt()
    print("🧾 Prompt Flow:", prompt[:180].replace("\n", " ") + ("..." if len(prompt) > 180 else ""))

    # Bản worker này dùng 1 account local trong mỗi worker do dashboard đã clone/chia account.
    # Nếu chạy độc lập nhiều account, sẽ thử account tiếp theo khi account hiện tại quota/login lỗi.
    success = 0
    failed = 0
    skipped_count = len(skipped)
    remaining_groups = groups
    last_error = None

    for idx, profile_path in enumerate(profiles, start=1):
        mode = PROVIDED_ACCOUNT_MODES[idx-1] if idx-1 < len(PROVIDED_ACCOUNT_MODES) else (read_mode_cache(profile_path) or "regular")
        try:
            ok, err, sk = process_all_with_account(profile_path, idx, remaining_groups, prompt, mode=mode)
            success += ok
            failed += err
            skipped_count += sk
            last_error = None
            break
        except ImageQuotaReached as e:
            last_error = e
            print(f"⏸ Account {idx} hết lượt, thử account tiếp nếu có")
            continue
        except Exception as e:
            last_error = e
            print(f"✖ Account {idx} lỗi: {e}")
            # lỗi login/account thì thử account tiếp; nếu chỉ có 1 acc sẽ kết thúc lỗi.
            continue

    if last_error is not None and success == 0:
        print("❌ Worker lỗi:", last_error)
        # Không emit job_error hàng loạt ở đây nếu từng folder đã emit, chỉ summary.

    emit_event("worker_summary", success=success, failed=failed, skipped=skipped_count)
    print(f"\n📊 Tổng kết Flow: OK={success} • Lỗi={failed} • Skip={skipped_count}")


if __name__ == "__main__":
    main()
