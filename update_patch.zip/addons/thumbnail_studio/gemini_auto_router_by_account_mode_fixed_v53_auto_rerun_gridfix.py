
import os
import sys
import time
import threading
import json
import requests
import re
import subprocess
import zlib
import ctypes
import argparse
import hashlib
import tempfile
import contextlib
import shutil
from pathlib import Path
from io import BytesIO
try:
    import psutil
except Exception:
    psutil = None
from PIL import Image

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import (
    TimeoutException,
    ElementClickInterceptedException,
    ElementNotInteractableException,
    StaleElementReferenceException,
    WebDriverException,
)

PROMPT = "Edit the uploaded image into a finished realistic music thumbnail. Preserve the original singer from the uploaded image exactly unchanged as the foreground subject: do not alter the face, hair, skin tone, pose, body, clothing, expression, or position. Only change the background style and redesign the typography/font. If any visible year such as 2024 or 2025 appears in the image, replace it with 2026. Return only the final edited image, no explanation and no text response."
def _myinggo_job_prompt(image_path):
    """MyingGo: gắn % khác gốc + style theo thư mục + xoá logo không liên quan. Lỗi => dùng PROMPT gốc."""
    try:
        _addon = os.environ.get("MYINGGO_ADDON_DIR") or os.path.dirname(os.path.abspath(__file__))
        if _addon and _addon not in sys.path:
            sys.path.insert(0, _addon)
        import myinggo_thumb_opts as _mg_opts
        _p = _mg_opts.build_prompt(PROMPT, image_path)
        if _p != PROMPT:
            print("🎨 MyingGo prompt:", _p[len(PROMPT):].strip()[:300])
        return _p
    except Exception as _e:
        print("⚠ MyingGo prompt fallback:", _e)
        return PROMPT


LOGO_RIGHT_MARGIN = 50  # dịch logo sang trái để che kín watermark Gemini
LOGO_BOTTOM_MARGIN = 45  # dịch logo lên trên để che kín watermark Gemini
TARGET_ASPECT_W = 16
TARGET_ASPECT_H = 9
ASPECT_EPSILON = 0.01

HEADLESS_FOR_REGULAR = False   # tài khoản thường -> headless
HEADLESS_FOR_PRO = False       # tài khoản pro -> chạy ẩn, DOM-only giống nhánh thường
PRO_SWITCH_AFTER_ERRORS = 2
REGULAR_SWITCH_AFTER_ERRORS = 2
HIDE_AUTOMATION_CHROME_WINDOWS = True
HIDE_STYLE = ''  # v12.20: TRUE visible worker, không offscreen guard; chỉ ẩn khi --hide-style hide/minimize
MODE_CACHE_FILENAME = '.gemini_account_mode.json'
CAPTURE_RETRY_LIMIT = 3
# v13.48 CDN403 fix: Google image CDN may reject raw requests.get() even when Chrome can render the image.
# Once a worker sees a 403 from googleusercontent, skip repeated raw HTTP downloads and capture through Chrome instead.
REMOTE_CDN_DIRECT_BLOCKED = False
REMOTE_CAPTURE_FIX_VERSION = "v13.48-CDN403-browser-capture"

# v79.3/v53: fast mode mặc định.
# 0 = không chờ thêm sau khi capture fail, chạy job kế tiếp nhanh hơn.
# Muốn safe mode chậm hơn thì set GEMINI_EXTRA_CAPTURE_WAIT=45.
EXTRA_CAPTURE_WAIT_SECONDS = int(os.getenv("GEMINI_EXTRA_CAPTURE_WAIT", "0") or "0")
# v45: luôn đảm bảo ảnh cuối cùng lớn hơn 2MB. Có thể đổi bằng biến môi trường GEMINI_FINAL_MIN_MB.
FINAL_MIN_IMAGE_MB = float(os.environ.get('GEMINI_FINAL_MIN_MB', '2.05'))
FINAL_MIN_IMAGE_BYTES = int(FINAL_MIN_IMAGE_MB * 1024 * 1024)

# v12.16 first-upload agree lock
FIRST_UPLOAD_FLOW_DONE = False
FIRST_UPLOAD_AGREE_DONE = False
LAST_UPLOAD_CONFIRMED_PATH = None


def dismiss_unexpected_dialogs(note=""):
    """v12.77: dọn alert/dialog/popup nhỏ làm kẹt 1 luồng."""
    handled = False
    try:
        alert = driver.switch_to.alert
        txt = ''
        try:
            txt = str(alert.text or '')
        except Exception:
            txt = ''
        try:
            alert.accept()
            print(f"🧹 Đã accept alert bất ngờ{(' • ' + note) if note else ''}: {txt[:80]}")
            handled = True
        except Exception:
            try:
                alert.dismiss()
                print(f"🧹 Đã dismiss alert bất ngờ{(' • ' + note) if note else ''}: {txt[:80]}")
                handled = True
            except Exception:
                pass
    except Exception:
        pass
    try:
        selectors = [
            "button[aria-label='Close']", "button[aria-label='Đóng']",
        ]
        xpaths = [
            "//button[normalize-space()='OK' or normalize-space()='Ok' or normalize-space()='Đồng ý' or normalize-space()='Đóng' or normalize-space()='Close' or normalize-space()='Continue' or normalize-space()='Tiếp tục']",
            "//div[@role='dialog']//button"
        ]
        for css in selectors:
            for el in driver.find_elements(By.CSS_SELECTOR, css)[:3]:
                try:
                    if el.is_displayed():
                        driver.execute_script('arguments[0].click();', el)
                        print(f"🧹 Đã đóng popup bằng CSS{(' • ' + note) if note else ''}")
                        handled = True
                        return handled
                except Exception:
                    pass
        for xp in xpaths:
            for el in driver.find_elements(By.XPATH, xp)[:5]:
                try:
                    if el.is_displayed():
                        label = (el.text or '').strip()
                        if label and label.lower() not in ('hủy', 'cancel', 'không'):
                            driver.execute_script('arguments[0].click();', el)
                            print(f"🧹 Đã đóng popup '{label}'{(' • ' + note) if note else ''}")
                            handled = True
                            return handled
                except Exception:
                    pass
    except Exception:
        pass
    return handled



def read_mode_cache(profile_path):
    try:
        cache_path = os.path.join(profile_path, MODE_CACHE_FILENAME)
        if not os.path.isfile(cache_path):
            return ''
        data = json.load(open(cache_path, 'r', encoding='utf-8'))
        mode = str(data.get('mode') or '').strip().lower()
        if mode in ('regular', 'pro'):
            return mode
    except Exception:
        pass
    return ''


def write_mode_cache(profile_path, mode):
    try:
        if str(mode).strip().lower() not in ('regular', 'pro'):
            return
        cache_path = os.path.join(profile_path, MODE_CACHE_FILENAME)
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump({'mode': str(mode).strip().lower(), 'updated_at': int(time.time())}, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def safe_quit_driver(drv, settle_seconds=1.2):
    if drv is None:
        return
    try:
        try:
            drv.get('about:blank')
        except Exception:
            pass
        time.sleep(max(0.2, float(settle_seconds)))
    except Exception:
        pass
    try:
        drv.quit()
    except Exception:
        pass


def has_interactive_stdin():
    try:
        return sys.stdin is not None and sys.stdin.isatty()
    except Exception:
        return False


def _env_bool(name, default=False):
    val = os.environ.get(name)
    if val is None:
        return bool(default)
    return str(val).strip().lower() in ("1", "true", "yes", "y", "on")



@contextlib.contextmanager
def upload_serial_lock(label="upload"):
    """v12.53: atomic folder upload lock + tự dọn lock chết.
    Sửa lỗi mọi worker chờ mãi ở "Đợi khóa upload serial" do lock dir cũ còn sót.
    Không dùng msvcrt.locking nên không còn [Errno 13] Permission denied.
    """
    enabled = str(os.environ.get("GEMINI_UPLOAD_SERIAL_LOCK", "1")).strip().lower() not in ("0", "false", "no")
    if not enabled:
        yield
        return

    raw_lock = os.environ.get("GEMINI_UPLOAD_LOCK_FILE") or os.path.join(tempfile.gettempdir(), "gemini_upload_serial.lock")
    lock_dir = raw_lock + ".dir"
    parent = os.path.dirname(lock_dir) or tempfile.gettempdir()
    os.makedirs(parent, exist_ok=True)

    stale_after = float(os.environ.get("GEMINI_UPLOAD_LOCK_STALE_SECONDS", "120") or 120)
    no_owner_stale_after = float(os.environ.get("GEMINI_UPLOAD_LOCK_NO_OWNER_STALE_SECONDS", "15") or 15)
    poll = float(os.environ.get("GEMINI_UPLOAD_LOCK_POLL_SECONDS", "0.25") or 0.25)
    start = time.time()
    last_log = 0.0
    acquired = False

    def _owner_path():
        return os.path.join(lock_dir, "owner.txt")

    def _read_owner_pid():
        try:
            p = _owner_path()
            if not os.path.exists(p):
                return None
            data = open(p, "r", encoding="utf-8", errors="ignore").read()
            m = re.search(r"pid=(\d+)", data)
            return int(m.group(1)) if m else None
        except Exception:
            return None

    def _pid_alive(pid):
        if not pid:
            return False
        try:
            if os.name == "nt":
                import ctypes
                PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
                SYNCHRONIZE = 0x00100000
                h = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, int(pid))
                if not h:
                    return False
                try:
                    code = ctypes.c_ulong()
                    if ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code)):
                        return code.value == 259  # STILL_ACTIVE
                    return True
                finally:
                    ctypes.windll.kernel32.CloseHandle(h)
            else:
                os.kill(int(pid), 0)
                return True
        except Exception:
            return False

    def _try_remove_lockdir(reason):
        try:
            p = _owner_path()
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass
            os.rmdir(lock_dir)
            print(f"♻️ Dọn khóa upload serial cũ ({reason}): {label}")
            return True
        except Exception:
            return False

    def _write_owner():
        try:
            with open(_owner_path(), "w", encoding="utf-8") as f:
                f.write(f"pid={os.getpid()}\nlabel={label}\ntime={time.time()}\n")
        except Exception:
            pass

    try:
        print(f"🔒 Chờ khóa upload serial: {label}")
        while True:
            try:
                os.mkdir(lock_dir)
                acquired = True
                _write_owner()
                break
            except FileExistsError:
                now = time.time()
                owner_pid = _read_owner_pid()
                owner_alive = _pid_alive(owner_pid) if owner_pid else False
                try:
                    age = now - os.path.getmtime(lock_dir)
                except Exception:
                    age = now - start

                if owner_pid and not owner_alive:
                    if _try_remove_lockdir(f"pid {owner_pid} đã chết"):
                        continue
                elif (not owner_pid) and age >= no_owner_stale_after:
                    if _try_remove_lockdir(f"không có owner > {int(no_owner_stale_after)}s"):
                        continue
                elif stale_after > 0 and age >= stale_after and not owner_alive:
                    if _try_remove_lockdir(f"quá stale {int(stale_after)}s"):
                        continue

                if now - last_log >= 5:
                    extra = f" • owner pid={owner_pid} alive={owner_alive}" if owner_pid else " • lock cũ không owner"
                    print(f"⏳ Đợi khóa upload serial: {label} • {int(now-start)}s{extra}")
                    last_log = now
                time.sleep(poll)
            except PermissionError:
                now = time.time()
                if now - last_log >= 5:
                    print(f"⏳ Đợi khóa upload serial: {label} • {int(now-start)}s")
                    last_log = now
                time.sleep(poll)
            except OSError:
                now = time.time()
                if now - last_log >= 5:
                    print(f"⏳ Đợi khóa upload serial: {label} • {int(now-start)}s")
                    last_log = now
                time.sleep(poll)

        print(f"🔐 Đã giữ khóa upload serial: {label}")
        try:
            yield
        finally:
            pass
    finally:
        if acquired:
            try:
                p = _owner_path()
                if os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass
            try:
                os.rmdir(lock_dir)
            except Exception as e:
                print(f"⚠ Nhả khóa upload serial lỗi nhẹ: {e}")
        print(f"🔓 Nhả khóa upload serial: {label}")

def parse_cli_args():
    parser = argparse.ArgumentParser(description="Gemini thumbnail backend worker v47 speed stability")
    parser.add_argument("--root", default=os.environ.get("GEMINI_ROOT", ""), help="Thư mục chứa job ảnh thumbnail-original-*-final.png")
    parser.add_argument("--logo", default=os.environ.get("GEMINI_LOGO", ""), help="Đường dẫn logo PNG")
    parser.add_argument("--num-accounts", type=int, default=int(os.environ.get("GEMINI_NUM_ACCOUNTS", "0") or 0), help="Số account cục bộ trong thư mục profiles")
    parser.add_argument("--chrome-binary", default=os.environ.get("GEMINI_CHROME_BINARY", ""), help="Đường dẫn chrome.exe shared từ dashboard, không cần copy Chrome vào worker")
    parser.add_argument("--driver-path", default=os.environ.get("GEMINI_DRIVER_PATH", ""), help="Đường dẫn chromedriver.exe shared từ dashboard, không cần copy chromedriver vào worker")
    parser.add_argument("--account-modes", default=os.environ.get("GEMINI_ACCOUNT_MODES", ""), help="Danh sách mode account cục bộ, ví dụ: regular,pro. Có để bỏ bước detect mode")
    parser.add_argument("--manifest", default=os.environ.get("GEMINI_JOB_MANIFEST", ""), help="File job_manifest.json để resume và ghi trạng thái job")
    parser.add_argument("--events", default=os.environ.get("GEMINI_EVENTS", "1"), help="Bật/tắt JSON event stdout: 1/0")
    parser.add_argument("--final-min-mb", type=float, default=float(os.environ.get("GEMINI_FINAL_MIN_MB", "2.05") or 2.05), help="Dung lượng ảnh cuối tối thiểu, mặc định 2.05MB để chắc chắn >2MB")
    parser.add_argument("--input-skip-over-mb", type=float, default=float(os.environ.get("GEMINI_INPUT_SKIP_OVER_MB", "1.5") or 1.5), help="Bỏ qua ảnh đầu vào lớn hơn ngưỡng MB này")
    parser.add_argument("--headless-regular", default=os.environ.get("GEMINI_HEADLESS_REGULAR", ""), help="Override headless account thường: 1/0")
    parser.add_argument("--headless-pro", default=os.environ.get("GEMINI_HEADLESS_PRO", ""), help="Override headless account PRO: 1/0")
    parser.add_argument("--hide-style", default=os.environ.get("GEMINI_HIDE_STYLE", ""), choices=("", "hide", "minimize"), help="Kiểu ẩn Chrome automation")
    parser.add_argument("--validate-min-width", type=int, default=int(os.environ.get("GEMINI_VALIDATE_MIN_WIDTH", "1280") or 1280), help="Chiều rộng tối thiểu của ảnh cuối")
    parser.add_argument("--validate-min-height", type=int, default=int(os.environ.get("GEMINI_VALIDATE_MIN_HEIGHT", "720") or 720), help="Chiều cao tối thiểu của ảnh cuối")
    parser.add_argument("--validate-aspect-epsilon", type=float, default=float(os.environ.get("GEMINI_VALIDATE_ASPECT_EPS", "0.025") or 0.025), help="Sai số tỷ lệ 16:9 cho ảnh cuối")
    parser.add_argument("--max-job-retries", type=int, default=int(os.environ.get("GEMINI_MAX_JOB_RETRIES", "2") or 2), help="Số lần retry cho lỗi nhẹ của từng job trước khi đánh lỗi")
    parser.add_argument("--result-stable-rounds", type=int, default=int(os.environ.get("GEMINI_RESULT_STABLE_ROUNDS", "1") or 1), help="Số vòng DOM phải ổn định trước khi tải ảnh kết quả")
    parser.add_argument("--auto-upscale-final", default=os.environ.get("GEMINI_AUTO_UPSCALE_FINAL", "1"), help="Tự upscale/crop ảnh cuối lên chuẩn min 1280x720 nếu Gemini trả 1024x576: 1/0")
    parser.add_argument("--proxy-list", default=os.environ.get("GEMINI_PROXY_LIST", ""), help="Danh sách proxy tương ứng account cục bộ, phân tách bằng ||")
    parser.add_argument("--proxy", default=os.environ.get("GEMINI_PROXY", ""), help="Proxy fallback cho worker/account hiện tại")
    parser.add_argument("--result-stable-seconds", type=float, default=float(os.environ.get("GEMINI_RESULT_STABLE_SECONDS", "1.2") or 1.2), help="Thời gian nghỉ sau khi ảnh ổn định trước khi capture")
    parser.add_argument("--target-model", default=os.environ.get("GEMINI_TARGET_MODEL", "auto"), choices=("auto", "flash", "pro"), help="Model vẽ: auto/flash/pro")
    parser.add_argument("--no-hash-validate", action="store_true", help="Tắt ghi hash sha256 vào manifest")
    return parser.parse_args()


def _parse_worker_proxy_value(value):
    """Parse proxy ip:port:user:pass hoặc scheme://user:pass@host:port."""
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        from urllib.parse import urlparse
        scheme = "http"
        host = port = username = password = ""
        if "://" in raw:
            u = urlparse(raw)
            scheme = (u.scheme or "http").lower()
            host = u.hostname or ""
            port = str(u.port or "")
            username = u.username or ""
            password = u.password or ""
        else:
            parts = raw.split(":")
            if len(parts) >= 4:
                host, port, username = parts[0].strip(), parts[1].strip(), parts[2].strip()
                password = ":".join(parts[3:]).strip()
            elif len(parts) >= 2:
                host, port = parts[0].strip(), parts[1].strip()
        if not host or not port:
            return None
        return {"scheme": scheme, "host": host, "port": int(port), "username": username, "password": password, "raw": raw}
    except Exception:
        return None


def _worker_proxy_extension_dir(proxy_value, profile_path):
    """Tạo extension proxy auth cục bộ nếu proxy có user/pass."""
    px = _parse_worker_proxy_value(proxy_value)
    if not px or not (px.get("username") or px.get("password")):
        return ""
    try:
        import json as _json
        ext_dir = os.path.join(str(profile_path), "_proxy_auth_ext")
        os.makedirs(ext_dir, exist_ok=True)
        # v12.60: Chrome mới không còn nhận Manifest V2, dùng MV3 service_worker.
        manifest = {
            "version": "1.0",
            "manifest_version": 3,
            "name": "Gemini Proxy Auth MV3",
            "permissions": ["proxy", "storage", "webRequest", "webRequestAuthProvider"],
            "host_permissions": ["<all_urls>"],
            "background": {"service_worker": "background.js"},
            "minimum_chrome_version": "88.0.0"
        }
        bg = f"""
const config = {{
  mode: "fixed_servers",
  rules: {{
    singleProxy: {{
      scheme: "{px.get('scheme') or 'http'}",
      host: "{px.get('host')}",
      port: {int(px.get('port'))}
    }},
    bypassList: ["localhost", "127.0.0.1", "<local>"]
  }}
}};
chrome.proxy.settings.set({{value: config, scope: "regular"}}, function() {{}});
chrome.webRequest.onAuthRequired.addListener(
  function(details, callback) {{
    callback({{authCredentials: {{username: "{str(px.get('username') or '').replace('"', '\\"')}", password: "{str(px.get('password') or '').replace('"', '\\"')}"}}}});
  }},
  {{urls: ["<all_urls>"]}},
  ["asyncBlocking"]
);
"""
        with open(os.path.join(ext_dir, "manifest.json"), "w", encoding="utf-8") as f:
            _json.dump(manifest, f, ensure_ascii=False, indent=2)
        with open(os.path.join(ext_dir, "background.js"), "w", encoding="utf-8") as f:
            f.write(bg)
        return ext_dir
    except Exception:
        return ""


def _apply_worker_proxy_options(options, proxy_value, profile_path):
    px = _parse_worker_proxy_value(proxy_value)
    if not px:
        return False
    try:
        options.add_argument(f"--proxy-server={px.get('scheme') or 'http'}://{px.get('host')}:{int(px.get('port'))}")
        options.add_argument("--proxy-bypass-list=<-loopback>")
        ext_dir = _worker_proxy_extension_dir(proxy_value, profile_path)
        if ext_dir:
            options.add_argument(f"--load-extension={ext_dir}")
            options.add_argument(f"--disable-extensions-except={ext_dir}")
        print(f"🌐 Proxy ON: {px.get('host')}:{px.get('port')}")
        return True
    except Exception as e:
        print(f"⚠ Proxy setup lỗi: {e}")
        return False


def _proxy_for_local_account_index(idx):
    try:
        proxy_list = globals().get("PROVIDED_PROXY_LIST", []) or []
        if 0 <= int(idx) < len(proxy_list):
            return proxy_list[int(idx)]
    except Exception:
        pass
    return globals().get("GLOBAL_PROXY_VALUE", "") or ""


def _resolve_required_path(value, prompt_text):
    value = str(value or "").strip().strip('"')
    if value:
        return value
    if has_interactive_stdin():
        return input(prompt_text).strip('"')
    return value


ARGS = parse_cli_args()
EVENTS_ENABLED = str(getattr(ARGS, "events", "1")).strip().lower() not in ("0", "false", "no", "off")
EVENT_MARKER = "__GEMINI_EVENT__"
JOB_MANIFEST_PATH = str(getattr(ARGS, "manifest", "") or "").strip()
INPUT_SKIP_OVER_MB = float(getattr(ARGS, "input_skip_over_mb", 1.5) or 1.5)
VALIDATE_MIN_WIDTH = int(getattr(ARGS, "validate_min_width", 1280) or 1280)
VALIDATE_MIN_HEIGHT = int(getattr(ARGS, "validate_min_height", 720) or 720)
VALIDATE_ASPECT_EPSILON = float(getattr(ARGS, "validate_aspect_epsilon", 0.025) or 0.025)
VALIDATE_HASH = not bool(getattr(ARGS, "no_hash_validate", False))
MAX_JOB_RETRIES = max(0, int(getattr(ARGS, "max_job_retries", 2) or 0))
RESULT_STABLE_ROUNDS = max(1, int(getattr(ARGS, "result_stable_rounds", 1) or 1))
RESULT_STABLE_SECONDS = max(0.1, float(getattr(ARGS, "result_stable_seconds", 0.6) or 0.6))
FINAL_MIN_IMAGE_MB = float(getattr(ARGS, "final_min_mb", FINAL_MIN_IMAGE_MB) or FINAL_MIN_IMAGE_MB)
FINAL_MIN_IMAGE_BYTES = int(FINAL_MIN_IMAGE_MB * 1024 * 1024)
AUTO_UPSCALE_FINAL = str(getattr(ARGS, "auto_upscale_final", "1") or "1").strip().lower() not in ("0", "false", "no", "off")
TARGET_MODEL = str(getattr(ARGS, "target_model", "auto") or "auto").strip().lower()
if TARGET_MODEL not in ("auto", "flash", "pro"):
    TARGET_MODEL = "auto"
PROVIDED_ACCOUNT_MODES = [m.strip().lower() for m in str(getattr(ARGS, "account_modes", "") or "").split(",") if m.strip().lower() in ("regular", "pro")]
PROVIDED_PROXY_LIST = [p.strip() for p in str(getattr(ARGS, "proxy_list", "") or "").split("||") if p.strip()]
GLOBAL_PROXY_VALUE = str(getattr(ARGS, "proxy", "") or "").strip()
if str(getattr(ARGS, "headless_regular", "") or "").strip() != "":
    HEADLESS_FOR_REGULAR = str(ARGS.headless_regular).strip().lower() in ("1", "true", "yes", "on")
if str(getattr(ARGS, "headless_pro", "") or "").strip() != "":
    HEADLESS_FOR_PRO = str(ARGS.headless_pro).strip().lower() in ("1", "true", "yes", "on")
if str(getattr(ARGS, "hide_style", "") or "").strip():
    HIDE_STYLE = str(ARGS.hide_style).strip().lower()
else:
    HIDE_STYLE = ""
    HIDE_AUTOMATION_CHROME_WINDOWS = False
    print("🚀 v12.1 Staged Start + Quiet Login: upload ổn định, Send nhanh")
print(f"🫥 HEADLESS-GEMINI • regular={HEADLESS_FOR_REGULAR} • pro={HEADLESS_FOR_PRO} • Chrome UI={'OFF' if (HEADLESS_FOR_REGULAR and HEADLESS_FOR_PRO) else 'MIXED'} • model={TARGET_MODEL}")


def emit_event(event_type, **payload):
    if not EVENTS_ENABLED:
        return
    try:
        data = {"type": str(event_type), "ts": time.time(), **payload}
        print(EVENT_MARKER + json.dumps(data, ensure_ascii=False, separators=(",", ":")), flush=True)
    except Exception:
        pass


def _manifest_now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def load_job_manifest():
    if not JOB_MANIFEST_PATH:
        return {"version": 1, "jobs": {}}
    try:
        if os.path.isfile(JOB_MANIFEST_PATH):
            with open(JOB_MANIFEST_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("jobs"), dict):
                return data
    except Exception as e:
        print(f"⚠ Không đọc được job_manifest: {e}")
    return {"version": 1, "created_at": _manifest_now(), "jobs": {}}


JOB_MANIFEST = load_job_manifest()


def save_job_manifest():
    if not JOB_MANIFEST_PATH:
        return
    # v13.43 hotfix: dưới Dashboard, manager là nguồn duy nhất ghi manifest.
    # Worker chỉ emit JSON event; tránh nhiều process cùng thay job_manifest.json.
    if EVENTS_ENABLED:
        return
    tmp = None
    try:
        os.makedirs(os.path.dirname(os.path.abspath(JOB_MANIFEST_PATH)), exist_ok=True)
        tmp = JOB_MANIFEST_PATH + f".{os.getpid()}.{threading.get_ident()}.tmp"
        JOB_MANIFEST["updated_at"] = _manifest_now()
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(JOB_MANIFEST, f, ensure_ascii=False, indent=2)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        os.replace(tmp, JOB_MANIFEST_PATH)
        tmp = None
    except Exception as e:
        print(f"⚠ Không lưu được job_manifest: {e}")
    finally:
        if tmp:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass


def manifest_key(image_path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(image_path)))
    except Exception:
        return str(image_path)


def update_job_manifest(image_path, status, **extra):
    try:
        key = manifest_key(image_path)
        jobs = JOB_MANIFEST.setdefault("jobs", {})
        old = jobs.get(key, {}) if isinstance(jobs.get(key, {}), dict) else {}
        item = dict(old)
        item.update({"path": image_path, "status": status, "updated_at": _manifest_now()})
        item.update({k: v for k, v in extra.items() if v is not None})
        jobs[key] = item
        save_job_manifest()
    except Exception as e:
        print(f"⚠ update manifest lỗi: {e}")


def manifest_status(image_path):
    try:
        item = JOB_MANIFEST.get("jobs", {}).get(manifest_key(image_path), {})
        return str(item.get("status") or "")
    except Exception:
        return ""


def sha256_file(path, max_bytes=None):
    h = hashlib.sha256()
    total = 0
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            if max_bytes is not None and total + len(chunk) > max_bytes:
                chunk = chunk[:max(0, max_bytes - total)]
            if not chunk:
                break
            h.update(chunk)
            total += len(chunk)
            if max_bytes is not None and total >= max_bytes:
                break
    return h.hexdigest()



def normalize_final_image_geometry(image_path):
    """v53 speed-fix: Gemini đôi khi trả ảnh 1024x576 dù prompt/input là 1280x720.
    Thay vì báo validate_fail rồi vẽ lại rất chậm, ta crop/resize cục bộ lên chuẩn tối thiểu.
    Giữ tỷ lệ 16:9, không đổi nội dung nếu ảnh đã đạt chuẩn.
    """
    if not AUTO_UPSCALE_FINAL:
        return {"changed": False, "reason": "auto_upscale_disabled"}
    target_ratio = TARGET_ASPECT_W / TARGET_ASPECT_H
    try:
        with Image.open(image_path) as src:
            img = src.convert("RGB")
            w, h = img.size
            if w <= 0 or h <= 0:
                raise RuntimeError("Ảnh cuối có kích thước không hợp lệ")
            ratio = w / h
            changed = False
            note_parts = []

            # Crop nhẹ về 16:9 nếu sai tỷ lệ. Ưu tiên crop giữa ảnh để không méo thumbnail.
            if abs(ratio - target_ratio) > VALIDATE_ASPECT_EPSILON:
                if ratio < target_ratio:
                    new_h = max(1, int(round(w / target_ratio)))
                    top = max(0, (h - new_h) // 2)
                    img = img.crop((0, top, w, min(h, top + new_h)))
                else:
                    new_w = max(1, int(round(h * target_ratio)))
                    left = max(0, (w - new_w) // 2)
                    img = img.crop((left, 0, min(w, left + new_w), h))
                changed = True
                note_parts.append(f"crop16x9 {w}x{h}->{img.size[0]}x{img.size[1]}")
                w, h = img.size

            # Upscale lên tối thiểu yêu cầu nếu Gemini trả 1024x576.
            scale = max(1.0, VALIDATE_MIN_WIDTH / max(1, w), VALIDATE_MIN_HEIGHT / max(1, h))
            if scale > 1.0001:
                new_w = max(VALIDATE_MIN_WIDTH, int(round(w * scale)))
                new_h = max(VALIDATE_MIN_HEIGHT, int(round(h * scale)))
                # Ép lại đúng tỷ lệ 16:9 theo chiều rộng mới.
                new_h = max(1, int(round(new_w / target_ratio)))
                if new_h < VALIDATE_MIN_HEIGHT:
                    new_h = VALIDATE_MIN_HEIGHT
                    new_w = int(round(new_h * target_ratio))
                img = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
                changed = True
                note_parts.append(f"upscale {w}x{h}->{new_w}x{new_h}")

            if changed:
                img.save(image_path, format="PNG", compress_level=1, optimize=False)
                print("🧩 Đã chuẩn hóa kích thước ảnh cuối:", " • ".join(note_parts))
            return {"changed": bool(changed), "note": " • ".join(note_parts), "width": img.size[0], "height": img.size[1]}
    except Exception as e:
        raise RuntimeError(f"Không chuẩn hóa được kích thước ảnh cuối: {e}")

def validate_final_image_file(image_path):
    """Validate cuối: PNG hợp lệ, >2MB, tỷ lệ 16:9, kích thước tối thiểu, hash."""
    info = {"path": image_path}
    size_bytes = os.path.getsize(image_path)
    info["size_bytes"] = int(size_bytes)
    info["size_mb"] = round(size_bytes / (1024 * 1024), 4)
    if size_bytes <= 2 * 1024 * 1024:
        raise RuntimeError(f"Ảnh cuối chưa >2MB: {info['size_mb']}MB")
    with Image.open(image_path) as img:
        width, height = img.size
        fmt = str(img.format or "").upper()
        img.verify()
    info.update({"width": int(width), "height": int(height), "format": fmt})
    if width < VALIDATE_MIN_WIDTH or height < VALIDATE_MIN_HEIGHT:
        raise RuntimeError(f"Ảnh cuối quá nhỏ: {width}x{height}, yêu cầu tối thiểu {VALIDATE_MIN_WIDTH}x{VALIDATE_MIN_HEIGHT}")
    ratio = width / max(1, height)
    target = TARGET_ASPECT_W / TARGET_ASPECT_H
    info["aspect"] = round(ratio, 6)
    if abs(ratio - target) > VALIDATE_ASPECT_EPSILON:
        raise RuntimeError(f"Ảnh cuối sai tỷ lệ 16:9: {width}x{height}, ratio={ratio:.4f}")
    if VALIDATE_HASH:
        info["sha256"] = sha256_file(image_path)
    return info


root_folder = _resolve_required_path(getattr(ARGS, "root", ""), "Nhập đường dẫn thư mục cha: ")
success_count = 0
fail_count = 0
skipped_count = 0
failed_files = []
last_error_reason = None

class ImageQuotaReached(Exception):
    pass


class GeminiPolicyRefusal(Exception):
    pass

# v12.77: Logo là tuỳ chọn. Để trống nghĩa là không chèn logo vào ảnh cuối.
logo_path = str(getattr(ARGS, "logo", "") or "").strip().strip('"')
if logo_path:
    logo_path = os.path.abspath(os.path.expandvars(os.path.expanduser(logo_path)))
    if not os.path.isfile(logo_path):
        print("❌ File logo không tồn tại")
        raise SystemExit(1)
    if not logo_path.lower().endswith(".png"):
        print("❌ Logo phải là file PNG")
        raise SystemExit(1)
    print("✅ Logo sử dụng:", logo_path)
else:
    print("✅ Không dùng logo: ô Logo để trống")
emit_event("config", root=root_folder, logo=logo_path, final_min_mb=FINAL_MIN_IMAGE_MB, input_skip_over_mb=INPUT_SKIP_OVER_MB, validate_min_width=VALIDATE_MIN_WIDTH, validate_min_height=VALIDATE_MIN_HEIGHT, max_job_retries=MAX_JOB_RETRIES, result_stable_rounds=RESULT_STABLE_ROUNDS, auto_upscale_final=AUTO_UPSCALE_FINAL)

if not os.path.exists(root_folder):
    print("❌ Thư mục không tồn tại")
    raise SystemExit(1)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def _norm_optional_path(value):
    value = str(value or "").strip().strip('"')
    if not value:
        return ""
    try:
        return os.path.abspath(os.path.expandvars(os.path.expanduser(value)))
    except Exception:
        return value

# v47: dashboard truyền Chrome/ChromeDriver shared path để không phải copy cả thư mục Chrome vào từng worker.


def _auto_detect_npt_chromium_binary_engine():
    try:
        env_bin = os.environ.get("GEMINI_CHROMIUM_BINARY") or os.environ.get("GEMINI_CHROME_BINARY")
        if env_bin and os.path.isfile(env_bin):
            return os.path.abspath(env_bin)
    except Exception:
        pass
    try:
        local = os.environ.get("LOCALAPPDATA") or ""
        # v12.34: ưu tiên Chromium đã copy vào thư mục tool để tool độc lập, sau đó mới fallback sang NPT.
        candidates = [
            os.path.join(BASE_DIR, "chromium", "chrome.exe"),
            os.path.join(BASE_DIR, "chromium", "chromium.exe"),
        ]
        if local:
            candidates.append(os.path.join(local, "Programs", "NPT Veo Auto", "resources", "chromium", "chrome.exe"))
        candidates += [
            os.path.join(BASE_DIR, "chrome-win64", "chrome.exe"),
        ]
        for c in candidates:
            if os.path.isfile(c):
                return os.path.abspath(c)
    except Exception:
        pass
    return os.path.join(BASE_DIR, "chrome-win64", "chrome.exe")


def _auto_detect_driver_binary_engine():
    try:
        env_drv = os.environ.get("GEMINI_CHROMEDRIVER_BINARY") or os.environ.get("GEMINI_DRIVER_BINARY")
        if env_drv and os.path.isfile(env_drv):
            return os.path.abspath(env_drv)
    except Exception:
        pass
    return os.path.join(BASE_DIR, "chromedriver-win64", "chromedriver.exe")

chrome_binary = _norm_optional_path(getattr(ARGS, "chrome_binary", "")) or _auto_detect_npt_chromium_binary_engine()
driver_path = _norm_optional_path(getattr(ARGS, "driver_path", "")) or _auto_detect_driver_binary_engine()
CONFIG_FILE = os.path.join(BASE_DIR, "accounts.json")
DEBUG_DIR = os.path.join(BASE_DIR, "_debug")
os.makedirs(DEBUG_DIR, exist_ok=True)

if int(getattr(ARGS, "num_accounts", 0) or 0) > 0:
    num_accounts = int(getattr(ARGS, "num_accounts", 1) or 1)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"num_accounts": num_accounts}, f)
    print(f"✅ Tool đang dùng {num_accounts} tài khoản Google từ CLI/config")
elif os.path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        num_accounts = int(json.load(f)["num_accounts"])
    print(f"✅ Tool đang dùng {num_accounts} tài khoản Google")
else:
    if has_interactive_stdin():
        num_accounts = int(input("👉 Bạn muốn dùng bao nhiêu tài khoản Google: "))
    else:
        num_accounts = 1
        print("⚠ Không có accounts.json và không có --num-accounts, tạm dùng 1 account")
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"num_accounts": num_accounts}, f)
    print("✅ Đã lưu cấu hình tài khoản")

profiles = []
for i in range(num_accounts):
    profile_path = os.path.join(BASE_DIR, "profiles", f"google_{i+1}")
    os.makedirs(profile_path, exist_ok=True)
    profiles.append(profile_path)

driver = None
wait = None
account_modes = []
current_account = 0
fail_streak = 0
current_runtime_headless = None

class ProDomOnlyUnavailable(Exception):
    pass



def _get_service_pid():
    global driver
    try:
        return int(driver.service.process.pid)
    except Exception:
        return None


def _get_descendant_pids(root_pid):
    if not root_pid or psutil is None:
        return set()
    try:
        root = psutil.Process(root_pid)
        return {p.pid for p in root.children(recursive=True)}
    except Exception:
        return set()


def _enum_visible_windows_for_pids(pids):
    user32 = ctypes.windll.user32
    windows = []

    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def _callback(hwnd, lparam):
        try:
            if not user32.IsWindow(hwnd):
                return True
            if not user32.IsWindowVisible(hwnd):
                return True

            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if int(pid.value) not in pids:
                return True

            length = user32.GetWindowTextLengthW(hwnd)
            title_buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title_buf, length + 1)
            windows.append((hwnd, title_buf.value))
        except Exception:
            pass
        return True

    user32.EnumWindows(EnumWindowsProc(_callback), 0)
    return windows


def keep_browser_in_background(force=False):
    """
    Giữ cửa sổ Chrome automation ở nền để không nhảy lên màn hình và không click được.
    Không áp dụng cho cửa sổ login thủ công.
    """
    global driver, current_runtime_headless
    if not HIDE_AUTOMATION_CHROME_WINDOWS:
        return
    if current_runtime_headless is True and not force:
        return

    try:
        root_pid = _get_service_pid()
        pids = _get_descendant_pids(root_pid)
        if not pids:
            return

        user32 = ctypes.windll.user32
        SW_HIDE = 0
        SW_SHOWMINNOACTIVE = 7
        SW_MINIMIZE = 6

        for hwnd, title in _enum_visible_windows_for_pids(pids):
            try:
                npt_taskbar_style = str(os.environ.get("GEMINI_NPT_TASKBAR_STYLE", "0")).strip().lower() in ("1", "true", "yes", "on")
                taskbar_disable_window = str(os.environ.get("GEMINI_TASKBAR_DISABLE_WINDOW", "0")).strip().lower() in ("1", "true", "yes", "on")
                if HIDE_STYLE == 'hide' and not npt_taskbar_style:
                    user32.ShowWindow(hwnd, SW_HIDE)
                else:
                    # v12.34: kiểu NPT - cửa sổ có thumbnail taskbar, không offscreen, không disable.
                    user32.ShowWindow(hwnd, SW_SHOWMINNOACTIVE)
                    user32.ShowWindow(hwnd, SW_MINIMIZE)
                if taskbar_disable_window:
                    user32.EnableWindow(hwnd, False)
            except Exception:
                pass
    except Exception:
        pass


def ensure_browser_files():
    missing = []
    if not os.path.isfile(chrome_binary):
        missing.append(chrome_binary)
    if not os.path.isfile(driver_path):
        print("⚠️ Không có chromedriver bundle; dùng Selenium Manager tự resolve driver cho Chrome hiện tại")
    if missing:
        print("❌ Thiếu file chạy Chrome/ChromeDriver:")
        for item in missing:
            print(" -", item)
        raise SystemExit(1)



def clean_external_extensions_from_profile(profile_path):
    """v13.30: dọn dữ liệu extension ngoài khỏi profile riêng của worker.
    Không đụng Chrome cá nhân. Proxy auth extension nằm ở _proxy_auth_ext và được giữ lại.
    """
    removed = 0
    try:
        default_dir = Path(profile_path) / "Default"
        targets = [
            default_dir / "Extensions",
            default_dir / "Extension State",
            default_dir / "Extension Rules",
            default_dir / "Extension Scripts",
            default_dir / "Local Extension Settings",
            default_dir / "Sync Extension Settings",
            default_dir / "Managed Extension Settings",
            default_dir / "Extension Cookies",
            default_dir / "Extension Activity",
        ]
        for target in targets:
            try:
                if target.exists():
                    if target.is_dir():
                        shutil.rmtree(target, ignore_errors=True)
                    else:
                        target.unlink(missing_ok=True)
                    removed += 1
            except Exception:
                pass
        if removed:
            print(f"🧹 Extension Guard: đã dọn {removed} dữ liệu extension ngoài khỏi profile worker")
    except Exception as e:
        print(f"⚠ Extension Guard cleanup lỗi nhẹ: {e}")
    return removed

def profile_has_local_data(profile_path):
    indicators = [
        os.path.join(profile_path, "Default"),
        os.path.join(profile_path, "Local State"),
        os.path.join(profile_path, "First Run"),
    ]
    return any(os.path.exists(item) for item in indicators)


def launch_normal_chrome_for_login(profile_path, account_label):
    if str(os.environ.get("GEMINI_NO_MANUAL_LOGIN_POPUP", "1")).strip().lower() in ("1", "true", "yes", "on"):
        print(f"❌ SESSION_FAIL: không mở Chrome login nổi cho account {account_label} vì GEMINI_NO_MANUAL_LOGIN_POPUP=1")
        raise RuntimeError("session_fail: manual login popup disabled / v12.77 no visible popup")
    print(f"\n🔑 Mở Chrome thường để đăng nhập account {account_label}")
    args = [
        chrome_binary,
        f"--user-data-dir={profile_path}",
        "--profile-directory=Default",
        "--start-maximized",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-extensions",
        "--disable-component-extensions-with-background-pages",
        "--disable-default-apps",
        "https://accounts.google.com/",
    ]
    proc = subprocess.Popen(args)
    input("👉 Đăng nhập xong, đóng cửa sổ Chrome đó rồi nhấn Enter...")
    if proc.poll() is None:
        print("⚠ Chrome vẫn đang mở. Nếu Selenium báo lỗi profile đang dùng, hãy đóng hẳn cửa sổ Chrome của profile này.")


def make_options(profile_path, headless, proxy_value=None):
    # V23: manager already cloned/prepared/extension-cleaned every READY worker profile.
    # Avoid walking/deleting the same profile directories again inside each worker process.
    if str(os.environ.get("GEMINI_WORKER_PROFILE_ALREADY_PREPARED", "0")).strip().lower() not in ("1", "true", "yes", "on"):
        try:
            clean_external_extensions_from_profile(profile_path)
        except Exception:
            pass
    options = webdriver.ChromeOptions()
    try:
        _pls = str(os.environ.get("GEMINI_FAST_PAGE_LOAD_STRATEGY", "")).strip().lower()
        if _pls in ("eager", "none", "normal"):
            options.page_load_strategy = _pls
    except Exception:
        pass
    options.binary_location = chrome_binary
    options.add_argument(f"--user-data-dir={profile_path}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option('excludeSwitches', ['enable-automation'])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument("--password-store=basic")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--disable-sync")
    options.add_argument("--disable-session-crashed-bubble")
    options.add_argument("--hide-crash-restore-bubble")
    options.add_argument("--disable-signin-scoped-device-id")
    options.add_argument("--disable-features=FileSystemAccessAPI,NativeFileSystemAPI,ChromeSigninIntercept,SigninInterceptBubble,PasswordManagerOnboarding,AutofillServerCommunication,AccountConsistency,SigninProfileCreation,UnoDesktop,DiceWebSigninInterception,SigninInterception,SyncPromoAfterSigninIntercept,ExplicitBrowserSigninUIOnDesktop,ChromeSignIn")
    options.add_argument("--disable-backgrounding-occluded-windows")
    options.add_argument("--disable-renderer-backgrounding")
    options.add_argument("--force-device-scale-factor=1")
    options.add_argument("--window-size=1600,2400")
    _apply_worker_proxy_options(options, proxy_value or "", profile_path)
    try:
        _px_ext = _parse_worker_proxy_value(proxy_value or "")
        _needs_proxy_ext = bool(_px_ext and (_px_ext.get("username") or _px_ext.get("password")))
    except Exception:
        _needs_proxy_ext = False
    if not _needs_proxy_ext:
        options.add_argument("--disable-extensions")
    options.add_argument("--disable-component-extensions-with-background-pages")
    options.add_argument("--disable-default-apps")
    if headless:
        options.add_argument("--headless=new")
        options.add_argument("--hide-scrollbars")
    else:
        options.add_argument("--window-size=1600,2400")
        normal_then_minimize = str(os.environ.get("GEMINI_NORMAL_THEN_MINIMIZE", "0")).strip().lower() in ("1", "true", "yes", "on")
        npt_taskbar_style = str(os.environ.get("GEMINI_NPT_TASKBAR_STYLE", "0")).strip().lower() in ("1", "true", "yes", "on")
        npt_exact_9999 = str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on")
        if npt_exact_9999:
            # v12.34: giống NPT app.asar: headless=false + window-position=9999,9999, không minimize/hide.
            options.add_argument("--window-position=9999,9999")
            options.add_argument("--window-size=1280,900")
        elif HIDE_STYLE == 'hide' and not normal_then_minimize and not npt_taskbar_style:
            options.add_argument("--window-position=-32000,-32000")
            options.add_argument("--start-minimized")
        else:
            options.add_argument("--window-position=60,40")
            options.add_argument("--start-maximized")
    try:
        options.add_experimental_option("prefs", {
            "session.restore_on_startup": 0,
            "profile.exit_type": "Normal",
            "profile.exited_cleanly": True,
            "credentials_enable_service": False,
            "profile.password_manager_enabled": False,
            "extensions.alerts.initialized": True,
            "extensions.ui.developer_mode": False,
        })
    except Exception:
        pass
    return options


def start_selenium(profile_path, headless, proxy_value=None, _proxy_retry=False):
    print(f"🫥 HEADLESS browser start • profile={os.path.basename(os.path.normpath(str(profile_path)))} • headless={bool(headless)} • proxy={'ON' if proxy_value else 'OFF'}")
    options = make_options(profile_path, headless, proxy_value=proxy_value)
    try:
        drv = webdriver.Chrome(service=Service(driver_path), options=options) if os.path.isfile(driver_path) else webdriver.Chrome(options=options)
    except Exception as e:
        proxy_strict = str(os.environ.get("GEMINI_PROXY_STRICT", "0")).strip().lower() in ("1", "true", "yes", "on")
        if proxy_value and not _proxy_retry and not proxy_strict:
            print(f"⚠ Proxy làm Chrome lỗi hoặc extension lỗi: {type(e).__name__}: {str(e)[:120]}")
            print("↪ Tự tắt proxy cho worker này và chạy lại bằng IP gốc")
            return start_selenium(profile_path, headless, proxy_value="", _proxy_retry=True)
        raise
    try:
        if str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on"):
            drv.set_window_rect(9999, 9999, 1280, 900)
        else:
            drv.set_window_size(1600, 2400)
    except Exception:
        pass
    try:
        globals()['driver'] = drv
        globals()['current_runtime_headless'] = headless
        npt_exact_9999 = str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on")
        if npt_exact_9999:
            # Giữ cửa sổ ở 9999,9999 như NPT; không minimize, không disable, nhưng ép lại vị trí để Chrome không restore về màn hình chính.
            try:
                drv.set_window_rect(9999, 9999, 1280, 900)
            except Exception:
                pass
        elif HIDE_STYLE in ('hide', 'minimize') or str(os.environ.get("GEMINI_NPT_TASKBAR_STYLE", "0")).strip().lower() in ("1", "true", "yes", "on"):
            try:
                time.sleep(float(os.environ.get("GEMINI_NPT_MINIMIZE_AFTER_LAUNCH_SECONDS", "1.2") or 1.2))
            except Exception:
                pass
            keep_browser_in_background(force=True)
    except Exception:
        pass
    return drv, WebDriverWait(drv, 60)


def wait_for_page_ready(drv, timeout=20):
    WebDriverWait(drv, timeout).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
    try:
        _settle = float(os.environ.get("GEMINI_PAGE_READY_SETTLE_SECONDS", "2.5") or 2.5)
    except Exception:
        _settle = 2.5
    if _settle > 0:
        time.sleep(max(0.0, min(2.5, _settle)))
    try:
        if str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on"):
            try:
                drv.set_window_rect(9999, 9999, 1280, 900)
            except Exception:
                pass
        elif HIDE_STYLE in ('hide', 'minimize') or str(os.environ.get("GEMINI_NPT_TASKBAR_STYLE", "0")).strip().lower() in ("1", "true", "yes", "on"):
            keep_browser_in_background()
    except Exception:
        pass



def _google_account_verify_required_page(drv):
    """Nhận diện trang Google bắt xác minh danh tính / challenge.
    Gặp trang này không nên cố login tiếp trong batch; phải bỏ account và chuyển account khác.
    Lưu ý: /challenge/pwd là trang nhập mật khẩu bình thường, không phải checkpoint.
    """
    try:
        url = (drv.current_url or "").lower()
    except Exception:
        url = ""
    body = ""
    try:
        body = (drv.find_element(By.TAG_NAME, "body").text or "").lower()
    except Exception:
        pass
    try:
        for _pwd in drv.find_elements(By.CSS_SELECTOR, 'input[type="password"], input[name="Passwd"]'):
            if _pwd.is_displayed():
                return False
    except Exception:
        pass
    hay = (url + "\n" + body).lower()
    # v12.93: accounts.google.com/signin/rejected / "Không thể đăng nhập cho bạn" => bỏ account và đổi account.
    if ("signin/rejected" in hay) or ("/rejected" in hay) or ("không thể đăng nhập cho bạn" in hay) or ("google không thể xác minh" in hay) or ("couldn't sign you in" in hay) or ("could not sign you in" in hay):
        return True
    if "challenge/pwd" in hay:
        return False
    keys = (
        "verify it", "verify it\'s you", "verify it’s you", "verify your identity",
        "signin/rejected", "/rejected?", "không thể đăng nhập cho bạn", "khong the dang nhap cho ban",
        "google không thể xác minh rằng tài khoản này là của bạn",
        "google khong the xac minh rang tai khoan nay la cua ban",
        "couldn't sign you in", "couldn’t sign you in", "could not sign you in",
        "google couldn't verify that this account belongs to you",
        "google could not verify that this account belongs to you",

        "confirm it's you", "confirm it’s you", "check if it's really you", "check if it’s really you",
        "this helps show that this account really belongs to you",
        "choose how you want to sign in", "try another way",
        "xác minh danh tính", "xác minh đó là bạn", "xác minh bạn",
        "để giữ an toàn cho tài khoản", "chọn cách bạn muốn đăng nhập", "thử cách khác"
    )
    if any(k in hay for k in keys):
        return True
    challenge_url_keys = ("signin/rejected", "/rejected", "challenge/selection", "challenge/recaptcha", "challenge/ipp", "challenge/dp", "challenge/ootp", "challenge/phone")
    return any(k in hay for k in challenge_url_keys)


def gemini_signin_required_visible(drv):
    """Return True khi Gemini đang ở trạng thái chưa login.
    Gemini bản mới vẫn hiện ô Ask Gemini khi chưa đăng nhập, nên không được coi chỉ cần thấy editor là OK.
    """
    try:
        url = (drv.current_url or '').lower()
    except Exception:
        url = ''
    if 'accounts.google.com' in url:
        return True
    try:
        return bool(drv.execute_script(r"""
            const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
            const visible = (el) => {
                if (!el) return false;
                try {
                    const r = el.getBoundingClientRect();
                    const cs = getComputedStyle(el);
                    return r.width > 2 && r.height > 2 && cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0';
                } catch(e) { return false; }
            };
            const body = norm(document.body && document.body.innerText);
            const hardKeys = [
                'sign in to try tools', 'sign in to try', 'sign in to use', 'sign in to upload',
                'sign in to add files', 'sign in to create', 'sign in to continue',
                'đăng nhập để dùng', 'đăng nhập để thử', 'đăng nhập để tải', 'đăng nhập để tiếp tục'
            ];
            if (hardKeys.some(k => body.includes(k))) return true;
            const nodes = Array.from(document.querySelectorAll('a,button,[role="button"],[role="menuitem"]'));
            for (const el of nodes) {
                if (!visible(el)) continue;
                const tx = norm([el.innerText, el.textContent, el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' '));
                if (!tx) continue;
                if (tx === 'sign in' || tx === 'đăng nhập' || tx.startsWith('sign in ') || tx.startsWith('đăng nhập ')) return true;
                if (tx.includes('sign in to try tools') || tx.includes('sign in to upload') || tx.includes('đăng nhập để')) return true;
            }
            return false;
        """))
    except Exception:
        try:
            body = (drv.find_element(By.TAG_NAME, 'body').text or '').lower()
            if any(k in body for k in ('sign in to try tools', 'sign in to upload', 'đăng nhập để', 'sign in')):
                return True
        except Exception:
            pass
    return False


def assert_gemini_logged_in_or_raise(drv=None, context=''):
    """Chặn worker vẽ/upload khi Gemini thật ra chưa đăng nhập."""
    global driver
    d = drv or globals().get('driver')
    if d is None:
        return
    try:
        if _google_account_verify_required_page(d):
            print(f"❌ ACCOUNT_VERIFY_REQUIRED: Google yêu cầu xác minh danh tính/challenge khi {context or 'mở Gemini'}; bỏ account này.")
            raise RuntimeError('account_verify_required: Google verify identity checkpoint')
    except RuntimeError:
        raise
    except Exception:
        pass
    if gemini_signin_required_visible(d):
        print(f"❌ SESSION_FAIL: Gemini đang hiện Sign in / Sign in to try tools khi {context or 'mở Gemini'}; profile chưa đăng nhập, không vẽ/upload.")
        raise RuntimeError('session_fail: Gemini sign-in required / chưa đăng nhập thật')

def is_logged_in(drv):
    try:
        current_url = (drv.current_url or "").lower()
    except Exception:
        current_url = ""
    if "accounts.google.com" in current_url:
        return False
    try:
        click_google_cookie_consent_if_present(timeout=1.2, relabel='is_logged_in cookie check', drv=drv)
    except Exception:
        pass
    try:
        if _google_account_verify_required_page(drv):
            return False
    except Exception:
        pass
    try:
        if gemini_signin_required_visible(drv):
            return False
    except Exception:
        pass
    return True


def click_google_cookie_consent_if_present(timeout=5, relabel="google cookie consent", drv=None):
    """Tự xử lý bảng cookie đầu tiên của Google/Gemini:
    Before you continue to Google -> Read more -> Accept all.
    Bảng này thường che editor/login nên phải bấm trước khi dò đăng nhập hoặc editor.
    """
    global driver
    d = drv or globals().get('driver')
    if d is None:
        return False
    end_time = time.time() + float(timeout or 0)
    last_state = None
    while time.time() < end_time:
        try:
            state = d.execute_script(r"""
                const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
                const visible = (el) => {
                    if (!el) return false;
                    try {
                        const r = el.getBoundingClientRect();
                        const cs = getComputedStyle(el);
                        return r.width > 8 && r.height > 8 && cs.display !== 'none' && cs.visibility !== 'hidden' && r.bottom > 0 && r.right > 0 && r.left < innerWidth && r.top < innerHeight;
                    } catch(e) { return false; }
                };
                const body = norm((document.body && document.body.innerText) || '');
                const cookieKeys = [
                    'before you continue to google',
                    'we use cookies and data',
                    'if you choose “accept all”',
                    'if you choose "accept all"',
                    'trước khi tiếp tục sử dụng google',
                    'chúng tôi sử dụng cookie',
                    'cookie và dữ liệu'
                ];
                const hasCookie = cookieKeys.some(k => body.includes(k));
                if (!hasCookie) return {hasCookie:false};

                const nodes = Array.from(document.querySelectorAll('button, [role="button"], a, span, div'));
                const actionable = (el) => {
                    if (!el) return null;
                    if (el.matches && el.matches('button, [role="button"], a, .mat-mdc-button, .mdc-button')) return el;
                    return (el.closest && el.closest('button, [role="button"], a, .mat-mdc-button, .mdc-button')) || null;
                };
                const textOf = (el, child) => norm([
                    el && el.innerText, el && el.textContent, el && el.getAttribute && el.getAttribute('aria-label'), el && el.getAttribute && el.getAttribute('title'), el && el.getAttribute && el.getAttribute('data-test-id'),
                    child && child.innerText, child && child.textContent, child && child.getAttribute && child.getAttribute('aria-label'), child && child.getAttribute && child.getAttribute('title'), child && child.getAttribute && child.getAttribute('data-test-id')
                ].filter(Boolean).join(' '));
                function candidatesFor(words, rejectWords) {
                    const seen = new Set();
                    const out = [];
                    for (const child of nodes) {
                        const t = actionable(child);
                        if (!t || seen.has(t) || !visible(t)) continue;
                        const tx = textOf(t, child);
                        if (!tx) continue;
                        if (rejectWords && rejectWords.some(w => tx.includes(w))) continue;
                        if (words.some(w => tx.includes(w))) {
                            const r = t.getBoundingClientRect();
                            seen.add(t);
                            out.push({el:t, text:tx, x:r.x, y:r.y, w:r.width, h:r.height, isButton:(t.tagName === 'BUTTON')});
                        }
                    }
                    out.sort((a,b) => ((b.isButton?1000:0)+b.y) - ((a.isButton?1000:0)+a.y));
                    return out;
                }
                function clickPick(c) {
                    const el = c.el;
                    try { el.scrollIntoView({block:'center', inline:'center'}); } catch(e) {}
                    try { el.dispatchEvent(new MouseEvent('mouseover', {bubbles:true})); } catch(e) {}
                    try { el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true})); } catch(e) {}
                    try { el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true})); } catch(e) {}
                    try { el.click(); } catch(e) {}
                    return {text:c.text, x:Math.round(c.x), y:Math.round(c.y), w:Math.round(c.w), h:Math.round(c.h)};
                }

                const acceptWords = ['accept all', 'i agree', 'agree to all', 'chấp nhận tất cả', 'chap nhan tat ca', 'đồng ý tất cả', 'dong y tat ca'];
                const rejectWords = ['reject all', 'từ chối tất cả', 'tu choi tat ca'];
                const accept = candidatesFor(acceptWords, rejectWords);
                if (accept.length) return {hasCookie:true, clickedAccept:clickPick(accept[0]), acceptCount:accept.length};

                const readWords = ['read more', 'đọc thêm', 'doc them', 'xem thêm', 'xem them', 'more options', 'thêm tùy chọn', 'them tuy chon', 'read-more-button'];
                const read = candidatesFor(readWords, []);
                if (read.length) return {hasCookie:true, clickedReadMore:clickPick(read[0]), readCount:read.length};
                return {hasCookie:true, acceptCount:0, readCount:0, sample: nodes.slice(0,20).map(n => norm(n.innerText || n.textContent || n.getAttribute && n.getAttribute('aria-label') || '').slice(0,80)).filter(Boolean)};
            """)
            last_state = state
            if not (state and state.get('hasCookie')):
                return False
            if state.get('clickedReadMore'):
                print(f"✅ {relabel}: đã bấm Read more: {state.get('clickedReadMore')}")
                time.sleep(0.8)
                continue
            if state.get('clickedAccept'):
                print(f"✅ {relabel}: đã bấm Accept all cookie Google: {state.get('clickedAccept')}")
                end2 = time.time() + 8
                while time.time() < end2:
                    try:
                        body_l = (d.find_element(By.TAG_NAME, 'body').text or '').lower()
                        if 'before you continue to google' not in body_l and 'we use cookies and data' not in body_l and 'chúng tôi sử dụng cookie' not in body_l:
                            break
                    except Exception:
                        break
                    time.sleep(0.4)
                time.sleep(0.5)
                return True
        except Exception as e:
            last_state = {'error': str(e)[:120]}
        time.sleep(0.35)
    if last_state and last_state.get('hasCookie'):
        try:
            print(f"⚠ {relabel}: thấy bảng cookie Google nhưng chưa bấm xong. state={last_state}")
        except Exception:
            pass
    return False

def close_possible_popups():
    global driver
    try:
        if click_google_cookie_consent_if_present(timeout=1.2, relabel='auto popup cookie'):
            return
    except Exception:
        pass
    labels = [
        "got it", "ok", "okay", "đóng", "dong", "bỏ qua", "bo qua",
        "continue", "tiếp tục", "tiep tuc", "understood", "hiểu rồi", "hieu roi",
        "đồng ý", "dong y", "i agree", "agree"
    ]
    for _ in range(4):
        clicked_any = False
        try:
            elements = driver.find_elements(By.CSS_SELECTOR, "button, [role='button']")
        except Exception:
            return
        for el in elements:
            try:
                if not el.is_displayed():
                    continue
                desc = " | ".join([
                    el.text or "",
                    el.get_attribute("aria-label") or "",
                    el.get_attribute("title") or "",
                    str(el.get_attribute("class") or ""),
                ]).lower()
                if any(k in desc for k in labels):
                    try:
                        el.click()
                    except Exception:
                        try:
                            driver.execute_script("arguments[0].click();", el)
                        except Exception:
                            continue
                    clicked_any = True
                    time.sleep(1)
                    break
            except Exception:
                pass
        if not clicked_any:
            return


def ensure_logged_in(profile_path, account_label, headless):
    print("🌐 Đang mở Gemini...")
    _proxy_value = _proxy_for_local_account_index(int(account_label) - 1)
    drv, drv_wait = start_selenium(profile_path, headless=headless, proxy_value=_proxy_value)
    drv.get("https://gemini.google.com/app/new")
    wait_for_page_ready(drv)
    click_google_cookie_consent_if_present(timeout=6, relabel='login cookie consent', drv=drv)
    if _google_account_verify_required_page(drv):
        print("❌ ACCOUNT_VERIFY_REQUIRED: Google yêu cầu xác minh danh tính/challenge; bỏ account này và chuyển account khác.")
        safe_quit_driver(drv)
        raise RuntimeError("account_verify_required: Google verify identity checkpoint")
    if is_logged_in(drv):
        print("✅ Đã đăng nhập.")
        return drv, drv_wait
    # v12.61: nhiều proxy làm Google/Gemini hiện Sign in/verify dù profile IP gốc vẫn còn phiên.
    # Nếu gặp vậy, tắt proxy riêng account này và thử lại bằng IP gốc trước khi bắt login thủ công.
    if _proxy_value:
        print("⚠ Proxy có thể gây checkpoint/Sign in. Thử lại account này bằng IP gốc...")
        safe_quit_driver(drv)
        try:
            PROVIDED_PROXY_LIST[int(account_label) - 1] = ""
        except Exception:
            pass
        drv, drv_wait = start_selenium(profile_path, headless=headless, proxy_value="")
        drv.get("https://gemini.google.com/app/new")
        wait_for_page_ready(drv)
        click_google_cookie_consent_if_present(timeout=6, relabel='login cookie consent retry', drv=drv)
        if _google_account_verify_required_page(drv):
            print("❌ ACCOUNT_VERIFY_REQUIRED: Google yêu cầu xác minh danh tính/challenge; bỏ account này và chuyển account khác.")
            safe_quit_driver(drv)
            raise RuntimeError("account_verify_required: Google verify identity checkpoint")
        if is_logged_in(drv):
            print("✅ Đã đăng nhập bằng profile cũ sau khi tắt proxy cho account này.")
            return drv, drv_wait
    print("🔐 Chưa đăng nhập Google.")
    safe_quit_driver(drv)
    if str(os.environ.get("GEMINI_NO_MANUAL_LOGIN_POPUP", "1")).strip().lower() in ("1", "true", "yes", "on"):
        print("❌ SESSION_FAIL: profile mất phiên đăng nhập; không mở cửa sổ login nổi. Manager sẽ đánh dấu profile này để login lại bằng luồng nền/9999 ở lần sau.")
        raise RuntimeError("session_fail: profile logged out; manual login popup disabled / v12.77 no visible popup")
    launch_normal_chrome_for_login(profile_path, account_label)
    drv, drv_wait = start_selenium(profile_path, headless=headless, proxy_value="")
    drv.get("https://gemini.google.com/app/new")
    wait_for_page_ready(drv)
    click_google_cookie_consent_if_present(timeout=6, relabel='manual login cookie consent', drv=drv)
    if not is_logged_in(drv):
        print("❌ Vẫn chưa đăng nhập.")
        safe_quit_driver(drv)
        raise SystemExit(1)
    print("✅ Đăng nhập thành công.")
    return drv, drv_wait


def detect_account_mode(profile_path, account_label):
    cached_mode = read_mode_cache(profile_path)
    if cached_mode:
        print(f"🧠 Account {account_label}: dùng mode cache = {cached_mode.upper()}")
        return cached_mode
    print(f"🔎 Kiểm tra loại account {account_label}...")
    drv, _ = ensure_logged_in(profile_path, account_label, headless=False)
    try:
        # dùng driver tạm để đóng popup nhẹ
        tmp_old = globals().get("driver", None)
        try:
            globals()["driver"] = drv
            close_possible_popups()
            time.sleep(1.2)
        finally:
            globals()["driver"] = tmp_old

        # 1) Ưu tiên nhận THƯỜNG nếu thấy đúng nút nâng cấp Google AI Plus
        try:
            upgrade_candidates = drv.find_elements(
                By.XPATH,
                "//*[self::a or self::button or self::div or self::span]"
                "[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZÀÁẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬĐÈÉẺẼẸÊẾỀỂỄỆÌÍỈĨỊÒÓỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÙÚỦŨỤƯỨỪỬỮỰỲÝỶỸỴ', 'abcdefghijklmnopqrstuvwxyzàáảãạăắằẳẵặâấầẩẫậđèéẻẽẹêếềểễệìíỉĩịòóỏõọôốồổỗộơớờởỡợùúủũụưứừửữựỳýỷỹỵ'), 'nâng cấp lên google ai plus') "
                "or contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'upgrade to google ai plus')]"
            )
            if any(_safe_displayed(el) for el in upgrade_candidates):
                print(f"✅ Account {account_label}: THƯỜNG (thấy nút 'Nâng cấp lên Google AI Plus')")
                write_mode_cache(profile_path, "regular")
                return "regular"
        except Exception:
            pass

        # 2) Chỉ nhận PRO khi có badge PRO thật sự
        try:
            pro_badge_candidates = drv.find_elements(
                By.XPATH,
                "//*[self::span or self::div or self::button or self::a]"
                "[normalize-space(.)='PRO' or normalize-space(@aria-label)='PRO' or contains(@class,'pro-badge') or contains(@class,'badge-pro')]"
            )
            if any(_safe_displayed(el) for el in pro_badge_candidates):
                print(f"✅ Account {account_label}: PRO (có badge PRO thật)")
                write_mode_cache(profile_path, "pro")
                return "pro"
        except Exception:
            pass

        # 3) Mặc định an toàn: THƯỜNG
        print(f"✅ Account {account_label}: THƯỜNG (không thấy badge PRO thật)")
        write_mode_cache(profile_path, "regular")
        return "regular"
    finally:
        try:
            safe_quit_driver(drv)
        except Exception:
            pass


def _safe_displayed(el):
    try:
        return el.is_displayed()
    except Exception:
        return False


def save_debug_artifacts(prefix):
    global driver
    ts = time.strftime("%Y%m%d_%H%M%S")
    safe_prefix = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in prefix)
    screenshot_path = os.path.join(DEBUG_DIR, f"{safe_prefix}_{ts}.png")
    html_path = os.path.join(DEBUG_DIR, f"{safe_prefix}_{ts}.html")
    try:
        driver.save_screenshot(screenshot_path)
        print("🧩 Đã lưu screenshot lỗi:", screenshot_path)
    except Exception as e:
        print("⚠ Không lưu được screenshot:", e)
    try:
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        print("🧩 Đã lưu HTML lỗi:", html_path)
    except Exception as e:
        print("⚠ Không lưu được HTML:", e)


def visible_elements(css_selector):
    global driver
    result = []
    for el in driver.find_elements(By.CSS_SELECTOR, css_selector):
        try:
            if el.is_displayed():
                result.append(el)
        except Exception:
            pass
    return result


def safe_click(element, label="element"):
    global driver
    last_error = None
    for mode in ("normal", "action", "js"):
        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
            time.sleep(0.25)
            if mode == "normal":
                element.click()
            elif mode == "action":
                ActionChains(driver).move_to_element(element).pause(0.15).click(element).perform()
            else:
                driver.execute_script("arguments[0].click();", element)
            return
        except (ElementClickInterceptedException, ElementNotInteractableException, StaleElementReferenceException, WebDriverException) as e:
            last_error = e
            time.sleep(0.5)
    raise Exception(f"Không click được {label}: {type(last_error).__name__}: {last_error}")



def click_pre_upload_consent_if_present(timeout=4, relabel="pre-upload consent"):
    """v11.6: Gemini can block the first image upload with a modal:
    "Creating content from images and files" / "Tạo nội dung từ hình ảnh và tệp".
    If this modal is visible, click Agree/Đồng ý and return True.
    This must run immediately after clicking the upload menu item, then upload menu must be opened again.
    """
    global driver
    end_time = time.time() + timeout
    modal_words = [
        "creating content from images and files",
        "tạo nội dung từ hình ảnh và tệp",
        "content from images and files",
        "hình ảnh và tệp",
    ]
    agree_words = [
        "agree", "i agree", "accept", "continue",
        "đồng ý", "tôi đồng ý", "tiếp tục",
    ]
    last_state = None
    while time.time() < end_time:
        try:
            state = driver.execute_script(r"""
                const modalWords = arguments[0].map(s => s.toLowerCase());
                const agreeWords = arguments[1].map(s => s.toLowerCase());
                const visible = (el) => {
                    try {
                        const r = el.getBoundingClientRect();
                        const cs = getComputedStyle(el);
                        return r.width > 5 && r.height > 5 && cs.display !== 'none' && cs.visibility !== 'hidden';
                    } catch(e) { return false; }
                };
                const bodyText = ((document.body && document.body.innerText) || '').toLowerCase();
                const hasModalText = modalWords.some(w => bodyText.includes(w));
                const candidates = Array.from(document.querySelectorAll('button, [role="button"], span, div'))
                  .map(e => {
                    const btn = e.closest('button,[role="button"]') || e;
                    const text = [
                        e.innerText, e.textContent, e.getAttribute('aria-label'), e.getAttribute('title'),
                        btn.innerText, btn.textContent, btn.getAttribute('aria-label'), btn.getAttribute('title')
                    ].filter(Boolean).join(' ').replace(/\s+/g,' ').trim();
                    const r = btn.getBoundingClientRect();
                    return {el: btn, text, low: text.toLowerCase(), x:r.x, y:r.y, w:r.width, h:r.height, visible: visible(btn)};
                  })
                  .filter(x => x.visible && agreeWords.some(w => x.low.includes(w)));
                // Prefer real buttons in the modal area; avoid top account/menu buttons.
                candidates.sort((a,b) => {
                    const ar = (a.el.tagName === 'BUTTON' ? 100 : 0) + (a.y > 250 ? 20 : 0) + (a.w < 220 ? 5 : 0);
                    const br = (b.el.tagName === 'BUTTON' ? 100 : 0) + (b.y > 250 ? 20 : 0) + (b.w < 220 ? 5 : 0);
                    return br - ar;
                });
                return {hasModalText, count: candidates.length, sample: candidates.slice(0,5).map(x => ({text:x.text, x:Math.round(x.x), y:Math.round(x.y), w:Math.round(x.w), h:Math.round(x.h)}))};
            """, modal_words, agree_words)
            last_state = state
            if state and state.get('hasModalText') and state.get('count', 0) > 0:
                clicked = driver.execute_script(r"""
                    const agreeWords = arguments[0].map(s => s.toLowerCase());
                    const visible = (el) => {
                        try {
                            const r = el.getBoundingClientRect();
                            const cs = getComputedStyle(el);
                            return r.width > 5 && r.height > 5 && cs.display !== 'none' && cs.visibility !== 'hidden';
                        } catch(e) { return false; }
                    };
                    const candidates = Array.from(document.querySelectorAll('button, [role="button"], span, div'))
                      .map(e => {
                        const btn = e.closest('button,[role="button"]') || e;
                        const text = [
                            e.innerText, e.textContent, e.getAttribute('aria-label'), e.getAttribute('title'),
                            btn.innerText, btn.textContent, btn.getAttribute('aria-label'), btn.getAttribute('title')
                        ].filter(Boolean).join(' ').replace(/\s+/g,' ').trim();
                        const r = btn.getBoundingClientRect();
                        return {el: btn, text, low: text.toLowerCase(), x:r.x, y:r.y, w:r.width, h:r.height, visible: visible(btn)};
                      })
                      .filter(x => x.visible && agreeWords.some(w => x.low.includes(w)));
                    candidates.sort((a,b) => {
                        const ar = (a.el.tagName === 'BUTTON' ? 100 : 0) + (a.y > 250 ? 20 : 0) + (a.w < 220 ? 5 : 0);
                        const br = (b.el.tagName === 'BUTTON' ? 100 : 0) + (b.y > 250 ? 20 : 0) + (b.w < 220 ? 5 : 0);
                        return br - ar;
                    });
                    if (!candidates.length) return null;
                    const c = candidates[0];
                    c.el.scrollIntoView({block:'center'});
                    c.el.click();
                    return {text:c.text, x:Math.round(c.x), y:Math.round(c.y), w:Math.round(c.w), h:Math.round(c.h)};
                """, agree_words)
                if clicked:
                    print(f"✅ v11.6 {relabel}: đã bấm Agree/Đồng ý popup upload: {clicked}")
                    # wait until modal disappears
                    end2 = time.time() + 8
                    while time.time() < end2:
                        try:
                            still = driver.execute_script("""
                                const t = ((document.body && document.body.innerText) || '').toLowerCase();
                                return t.includes('creating content from images and files') || t.includes('tạo nội dung từ hình ảnh và tệp') || t.includes('content from images and files');
                            """)
                            if not still:
                                break
                        except Exception:
                            break
                        time.sleep(0.3)
                    time.sleep(0.5)
                    return True
        except Exception:
            pass
        time.sleep(0.25)
    if last_state and last_state.get('hasModalText'):
        print(f"⚠ v11.6 {relabel}: thấy popup upload nhưng chưa bấm được Agree/Đồng ý. state={last_state}")
    return False


def click_consent_if_present(timeout=3):
    """Compatibility alias for older branches."""
    return click_pre_upload_consent_if_present(timeout=timeout, relabel="compat consent")


def wait_editor_ready(timeout=40):
    global driver
    selectors = [
        'div[aria-label="Enter a prompt for Gemini"]',
        "div[contenteditable='true']",
        "rich-textarea div[contenteditable='true']",
        "textarea",
    ]
    end_time = time.time() + timeout
    last_error = None
    last_signin_guard = 0
    while time.time() < end_time:
        close_possible_popups()
        try:
            now_guard = time.time()
            if now_guard - last_signin_guard >= 1.5:
                last_signin_guard = now_guard
                assert_gemini_logged_in_or_raise(driver, 'dò editor')
        except RuntimeError:
            raise
        except Exception:
            pass
        for selector in selectors:
            try:
                elems = visible_elements(selector)
                if elems:
                    return elems[0]
            except Exception as e:
                last_error = e
        time.sleep(1)
    raise TimeoutException(f"Không tìm thấy ô nhập prompt/editor: {last_error}")


def get_element_descriptor(el):
    global driver
    parts = [
        el.text or "",
        el.get_attribute("aria-label") or "",
        el.get_attribute("title") or "",
        str(el.get_attribute("class") or ""),
        el.get_attribute("data-test-id") or "",
    ]
    return " | ".join(p.strip() for p in parts if p and p.strip()).lower()


def find_attach_button(timeout=25):
    global driver
    preferred_selectors = [
        "simplified-input-menu button.menu-button",
        "button[aria-label*='Mở trình đơn trong ô nhập nội dung']",
        "button[aria-label*='chọn công cụ và loại tệp tải lên']",
        "button.upload-card-button",
        "button[aria-controls='upload-file-menu']",
        "button[aria-label*='Upload']",
        "button[aria-label*='upload']",
        "button[aria-label*='Tải']",
        "button[aria-label*='tải']",
        "button[aria-label*='Đính kèm']",
        "button[aria-label*='đính kèm']",
    ]
    end_time = time.time() + timeout
    while time.time() < end_time:
        close_possible_popups()
        for selector in preferred_selectors:
            elems = visible_elements(selector)
            if elems:
                return elems[0]
        time.sleep(float(os.environ.get("GEMINI_UPLOAD_POLL_SECONDS", "0.25") or 0.25))
    raise TimeoutException("Không tìm thấy nút mở menu upload/đính kèm")


def click_upload_menu_item(timeout=15):
    global driver
    exact_labels = {
        "tải tệp lên", "tải file lên", "tải lên tệp", "upload file", "upload files", "upload from computer", "upload from device",
    }
    # v12.34: ưu tiên click THẲNG vào chữ Upload files / aria Upload files..., tránh bấm lệch sang icon ! bên phải.
    banned_tokens = [
        "notebook", "notebooklm", "guided learning", "create image", "create music", "canvas", "deep research",
        "sổ tay", "học có hướng dẫn", "tạo hình ảnh", "tạo nhạc", "nghiên cứu chuyên sâu"
    ]
    selectors = [
        "toolbox-drawer button",
        "toolbox-drawer [role='menuitem']",
        ".toolbox-drawer-container button",
        ".toolbox-drawer-container [role='menuitem']",
        ".simplified-input-menu-container button",
        ".cdk-overlay-container .mat-mdc-list-item",
        ".cdk-overlay-container [role='menuitem']",
        ".cdk-overlay-container button",
        "[role='menuitem']",
        "button",
    ]

    def item_label(el):
        try:
            text_value = (el.text or "").strip().lower()
            aria_value = (el.get_attribute("aria-label") or "").strip().lower()
            title_value = (el.get_attribute("title") or "").strip().lower()
            data_value = (el.get_attribute("data-test-id") or "").strip().lower()
            return " ".join(x for x in [text_value, aria_value, title_value, data_value] if x).strip(), text_value, aria_value, title_value
        except Exception:
            return "", "", "", ""

    def click_upload_text_left(item, debug_label=""):
        try:
            data_id = (item.get_attribute("data-test-id") or item.get_attribute("data-testid") or "").strip().lower()
            aria_dbg = (item.get_attribute("aria-label") or "").strip().lower()
            role_dbg = (item.get_attribute("role") or "").strip().lower()
            # v12.53: item thật theo F12 là button role=menuitem data-test-id=local-images-files-upload.
            # Dùng native click vào chính button trước, tránh JS synthetic click vào span/text không mở file picker.
            if data_id in ("local-images-files-upload", "local-images-files-uploader-button") or (role_dbg == "menuitem" and aria_dbg.startswith("upload files")):
                try:
                    driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center'});", item)
                except Exception:
                    pass
                try:
                    ActionChains(driver).move_to_element(item).pause(0.03).click().perform()
                    print(f"✅ v12.53 native click button Upload files: {debug_label[:100]}")
                    return True
                except Exception:
                    pass
        except Exception:
            pass
        try:
            js_result = driver.execute_script(r"""
                const root = arguments[0];
                const wanted = [
                    'upload files', 'upload file', 'upload from computer', 'upload from device', 'tải tệp lên', 'tải file lên'
                ];
                const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
                const nodes = [root, ...root.querySelectorAll('*')];
                for (const n of nodes) {
                    const txt = norm(n.innerText || n.textContent || '');
                    if (!txt) continue;
                    if (wanted.includes(txt) || wanted.some(w => txt.startsWith(w))) {
                        try {
                            n.dispatchEvent(new MouseEvent('mouseover', {bubbles:true}));
                            n.dispatchEvent(new MouseEvent('mousedown', {bubbles:true}));
                            n.dispatchEvent(new MouseEvent('mouseup', {bubbles:true}));
                            n.click();
                            return 'text:' + txt;
                        } catch (e) {}
                    }
                }
                try {
                    root.dispatchEvent(new MouseEvent('mouseover', {bubbles:true}));
                    root.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, clientX: 24, clientY: 18}));
                    root.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, clientX: 24, clientY: 18}));
                    root.click();
                    return 'root';
                } catch (e) {}
                return '';
            """, item)
            if js_result:
                print(f"✅ v12.34 click thẳng chữ Upload files: {debug_label[:80]} • via {js_result}")
                return True
        except Exception:
            pass
        try:
            size = item.size or {}
            xoff = 24
            yoff = max(8, int((size.get('height') or 36) / 2))
            try:
                ActionChains(driver).move_to_element_with_offset(item, xoff, yoff).click().perform()
            except Exception:
                ActionChains(driver).move_to_element(item).click().perform()
            print(f"✅ v12.34 click lệch trái item Upload: {debug_label[:80]}")
            return True
        except Exception:
            pass
        try:
            safe_click(item, "menu upload left")
            print(f"✅ v12.34 fallback safe_click item Upload: {debug_label[:80]}")
            return True
        except Exception:
            return False

    try:
        assert_gemini_logged_in_or_raise(driver, 'chuẩn bị bấm Upload files')
    except RuntimeError:
        raise
    except Exception:
        pass
    end_time = time.time() + timeout
    last_candidates = []
    last_attach_reopen = time.time()
    reopen_count = 0

    def click_f12_local_images_upload_direct():
        """v12.53: theo F12 máy user: button[data-test-id='local-images-files-upload'] là mục Upload files thật."""
        direct_selectors = [
            "button[data-test-id='local-images-files-upload']",
            "[data-test-id='local-images-files-upload']",
            "button[data-test-id='local-images-files-uploader-button']",
            "[data-test-id='local-images-files-uploader-button']",
            "button[data-testid='local-images-files-uploader-button']",
            "[data-testid='local-images-files-uploader-button']",
            "button[role='menuitem'][aria-label^='Upload files']",
            "[role='menuitem'][aria-label^='Upload files']",
            "button[aria-label^='Upload files. Documents']",
            "[aria-label^='Upload files. Documents']",
            "button[aria-label*='Documents, data, code files']",
            "[aria-label*='Documents, data, code files']",
        ]
        for css in direct_selectors:
            try:
                elems = driver.find_elements(By.CSS_SELECTOR, css)
            except Exception:
                elems = []
            for el in elems:
                try:
                    if not el.is_displayed():
                        continue
                    disabled = bool(el.get_attribute("disabled")) or str(el.get_attribute("aria-disabled") or "").lower() == "true"
                    if disabled:
                        continue
                    desc = get_element_descriptor(el)[:180]
                    try:
                        driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center'});", el)
                    except Exception:
                        pass
                    # Ưu tiên Selenium native click vì Angular/Gemini có lúc không mở file picker bằng JS click.
                    clicked = False
                    try:
                        ActionChains(driver).move_to_element(el).pause(0.03).click().perform()
                        clicked = True
                    except Exception:
                        try:
                            el.click()
                            clicked = True
                        except Exception:
                            try:
                                safe_click(el, "v12.53 direct local-images-files-upload")
                                clicked = True
                            except Exception:
                                clicked = False
                    if clicked:
                        print(f"✅ v12.53 F12 direct click Upload files: {css} • {desc}")
                        return True
                except Exception:
                    pass
        return False

    while time.time() < end_time:
        # v12.53: thử selector F12 trước mỗi vòng, sau khi menu vừa bung.
        try:
            if click_f12_local_images_upload_direct():
                time.sleep(float(os.environ.get("GEMINI_AFTER_UPLOAD_ITEM_CLICK_WAIT", "0.35") or 0.35))
                return True
        except Exception:
            pass
        items = []
        seen = set()
        for selector in selectors:
            try:
                for item in driver.find_elements(By.CSS_SELECTOR, selector):
                    key = getattr(item, "id", None) or id(item)
                    if key in seen:
                        continue
                    seen.add(key)
                    items.append(item)
            except Exception:
                pass

        # v12.34: 2-pass. Pass 1 chỉ nhận exact label/text/aria upload files. Pass 2 mới nhận phrase upload.
        for pass_mode in (1, 2):
            for item in items:
                try:
                    if not item.is_displayed():
                        continue
                    disabled = bool(item.get_attribute("disabled")) or str(item.get_attribute("aria-disabled") or "").lower() == "true"
                    full_text, text_value, aria_value, title_value = item_label(item)
                    if full_text:
                        last_candidates.append(full_text[:160])
                    if disabled:
                        continue
                    if any(b in full_text for b in banned_tokens):
                        continue

                    exact_match = (
                        full_text in exact_labels or text_value in exact_labels or title_value in exact_labels or
                        any((aria_value == lbl or aria_value.startswith(lbl + ".") or aria_value.startswith(lbl + " ")) for lbl in exact_labels)
                    )
                    phrase_match = any(label in full_text for label in [
                        "upload files", "upload file", "upload from computer", "upload from device", "tải tệp lên", "tải file lên"
                    ])

                    if pass_mode == 1 and exact_match:
                        print(f"✅ v12.34 nhận diện exact Upload item: text='{text_value}' aria='{aria_value}'")
                        if click_upload_text_left(item, full_text):
                            return True
                    if pass_mode == 2 and phrase_match:
                        print(f"✅ v12.34 nhận diện phrase Upload item: text='{text_value}' aria='{aria_value}'")
                        if click_upload_text_left(item, full_text):
                            return True
                except Exception:
                    pass
        # v12.53: nếu trình duyệt đã mở input file thì coi như menu upload đã đi đúng.
        try:
            has_file_input = driver.execute_script("return !!document.querySelector('input[type=file]');")
            if has_file_input:
                print("✅ v12.53: đã thấy input[type=file] trong khi dò menu Upload files")
                return True
        except Exception:
            pass
        # v12.53: sau Agree hoặc khi menu không bung, click lại nút Upload & tools để mở lại menu.
        try:
            now_reopen = time.time()
            if now_reopen - last_attach_reopen >= float(os.environ.get("GEMINI_UPLOAD_REOPEN_ATTACH_SECONDS", "1.2") or 1.2):
                last_attach_reopen = now_reopen
                reopen_count += 1
                try:
                    btn = find_attach_button(timeout=0.25)
                    safe_click(btn, f"v12.53 reopen attach #{reopen_count}")
                    print(f"↻ v12.53 mở lại menu Upload & tools #{reopen_count}")
                    time.sleep(float(os.environ.get("GEMINI_UPLOAD_POLL_SECONDS", "0.25") or 0.25))
                except Exception:
                    pass
        except Exception:
            pass
        time.sleep(float(os.environ.get("GEMINI_UPLOAD_POLL_SECONDS", "0.25") or 0.25))
    try:
        uniq = []
        for x in last_candidates:
            if x and x not in uniq:
                uniq.append(x)
        print("⚠ v12.34 không thấy Upload files exact; menu candidates:", " | ".join(uniq[:10]))
    except Exception:
        pass
    return False



def install_file_hooks():
    global driver
    try:
        driver.execute_script(r"""
            try {
                if (!window.__seleniumUploadHookInstalled) {
                    window.__seleniumUploadHookInstalled = true;
                    window.__fileChooserOpenedCount = window.__fileChooserOpenedCount || 0;
                    window.__lastSeenFileInput = null;
                    const scanNode = (root) => {
                        try {
                            if (!root || !root.querySelectorAll) return;
                            const inputs = root.querySelectorAll('input[type="file"]');
                            if (inputs && inputs.length) window.__lastSeenFileInput = inputs[inputs.length - 1];
                            const all = root.querySelectorAll('*');
                            for (const el of all) if (el && el.shadowRoot) scanNode(el.shadowRoot);
                        } catch (e) {}
                    };
                    scanNode(document);
                    const mo = new MutationObserver(() => scanNode(document));
                    mo.observe(document.documentElement || document.body, {childList: true, subtree: true});
                    window.__seleniumUploadObserver = mo;
                    if (window.showOpenFilePicker && !window.__origShowOpenFilePicker) {
                        window.__origShowOpenFilePicker = window.showOpenFilePicker.bind(window);
                        window.showOpenFilePicker = async function() {
                            window.__fileChooserOpenedCount = (window.__fileChooserOpenedCount || 0) + 1;
                            return await window.__origShowOpenFilePicker.apply(window, arguments);
                        };
                    }
                }
                return true;
            } catch (e) {
                return String(e);
            }
        """)
    except Exception:
        pass



def install_dom_only_file_input_trap():
    """
    Gemini Pro thực ra có tạo input[type=file] ẩn, nhưng rất thoáng qua rồi tự click để mở native dialog.
    Hook này chặn input.click() cho type=file, giữ lại reference để Selenium send_keys vào chính input đó.
    """
    global driver
    try:
        driver.execute_script(r"""
            try {
                if (!window.__domOnlyFileTrapInstalled) {
                    window.__domOnlyFileTrapInstalled = true;
                    window.__lastSeenFileInput = window.__lastSeenFileInput || null;
                    window.__fileInputSeenCount = window.__fileInputSeenCount || 0;

                    const markInput = (el) => {
                        try {
                            if (!el || el.tagName !== 'INPUT' || (el.type || '').toLowerCase() !== 'file') return;
                            window.__lastSeenFileInput = el;
                            window.__fileInputSeenCount = (window.__fileInputSeenCount || 0) + 1;
                            try {
                                el.style.display = 'block';
                                el.style.visibility = 'visible';
                                el.style.opacity = '1';
                                el.removeAttribute('hidden');
                                el.removeAttribute('disabled');
                            } catch (e) {}
                        } catch (e) {}
                    };

                    const walk = (root) => {
                        try {
                            if (!root || !root.querySelectorAll) return;
                            root.querySelectorAll('input[type="file"]').forEach(markInput);
                            root.querySelectorAll('*').forEach(el => {
                                if (el && el.shadowRoot) walk(el.shadowRoot);
                            });
                        } catch (e) {}
                    };

                    walk(document);

                    const mo = new MutationObserver((mutations) => {
                        for (const m of mutations) {
                            for (const node of (m.addedNodes || [])) {
                                try {
                                    if (node && node.tagName === 'INPUT' && (node.type || '').toLowerCase() === 'file') {
                                        markInput(node);
                                    }
                                    if (node && node.querySelectorAll) {
                                        node.querySelectorAll('input[type="file"]').forEach(markInput);
                                    }
                                    if (node && node.shadowRoot) {
                                        walk(node.shadowRoot);
                                    }
                                } catch (e) {}
                            }
                        }
                        walk(document);
                    });
                    mo.observe(document.documentElement || document.body, {childList: true, subtree: true});
                    window.__domOnlyFileTrapObserver = mo;

                    if (!window.__origHTMLInputClick) {
                        window.__origHTMLInputClick = HTMLInputElement.prototype.click;
                        HTMLInputElement.prototype.click = function() {
                            try {
                                if ((this.type || '').toLowerCase() === 'file') {
                                    markInput(this);
                                    return;
                                }
                            } catch (e) {}
                            return window.__origHTMLInputClick.apply(this, arguments);
                        };
                    }

                    const origAddEventListener = EventTarget.prototype.addEventListener;
                    if (!window.__origAddEventListenerWrapped) {
                        window.__origAddEventListenerWrapped = true;
                        EventTarget.prototype.addEventListener = function(type, listener, options) {
                            if (this && this.tagName === 'INPUT') {
                                try { markInput(this); } catch (e) {}
                            }
                            return origAddEventListener.call(this, type, listener, options);
                        };
                    }
                }
                return true;
            } catch (e) {
                return String(e);
            }
        """)
    except Exception:
        pass


def get_trapped_file_input():
    global driver
    try:
        el = driver.execute_script("""
            return window.__lastSeenFileInput || null;
        """)
        return el
    except Exception:
        return None


def wait_for_trapped_or_dom_file_input(total_timeout=15, relabel="DOM trap"):
    end_time = time.time() + total_timeout
    phase = 0
    while time.time() < end_time:
        phase += 1
        install_file_hooks()
        install_dom_only_file_input_trap()

        try:
            el = get_trapped_file_input()
            if el is not None:
                try:
                    driver.execute_script("""
                        arguments[0].style.display='block';
                        arguments[0].style.visibility='visible';
                        arguments[0].style.opacity='1';
                        arguments[0].removeAttribute('hidden');
                        arguments[0].removeAttribute('disabled');
                    """, el)
                except Exception:
                    pass
                print(f"✅ {relabel}: bắt được file input trap ở pha {phase}")
                return el
        except Exception:
            pass

        try:
            el = find_file_input(timeout=1)
            if el is not None:
                print(f"✅ {relabel}: thấy input[type=file] trong DOM ở pha {phase}")
                return el
        except Exception:
            pass

        time.sleep(0.35)

    return None


def find_file_input_in_open_shadow_dom():
    global driver
    js = r"""
        const seen = new Set();
        const walk = (root) => {
            if (!root || seen.has(root)) return null;
            seen.add(root);
            try {
                if (root.querySelector) {
                    const direct = root.querySelector('input[type="file"]');
                    if (direct) return direct;
                }
            } catch (e) {}
            try {
                if (root.querySelectorAll) {
                    const all = root.querySelectorAll('*');
                    for (const el of all) {
                        if (el && el.shadowRoot) {
                            const found = walk(el.shadowRoot);
                            if (found) return found;
                        }
                    }
                }
            } catch (e) {}
            return null;
        };
        return walk(document) || window.__lastSeenFileInput || null;
    """
    try:
        return driver.execute_script(js)
    except Exception:
        return None


def find_file_input(timeout=15):
    global driver
    end_time = time.time() + timeout
    last_error = None
    while time.time() < end_time:
        install_file_hooks()
        try:
            inputs = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
            for file_input in inputs:
                try:
                    driver.execute_script("""
                        arguments[0].style.display='block';
                        arguments[0].style.visibility='visible';
                        arguments[0].style.opacity='1';
                        arguments[0].removeAttribute('hidden');
                        arguments[0].removeAttribute('disabled');
                    """, file_input)
                    return file_input
                except Exception as e:
                    last_error = e
        except Exception as e:
            last_error = e
        try:
            shadow_input = find_file_input_in_open_shadow_dom()
            if shadow_input:
                try:
                    driver.execute_script("""
                        arguments[0].style.display='block';
                        arguments[0].style.visibility='visible';
                        arguments[0].style.opacity='1';
                        arguments[0].removeAttribute('hidden');
                        arguments[0].removeAttribute('disabled');
                    """, shadow_input)
                except Exception:
                    pass
                return shadow_input
        except Exception as e:
            last_error = e
        time.sleep(float(os.environ.get("GEMINI_UPLOAD_POLL_SECONDS", "0.25") or 0.25))
    chooser_count = 0
    try:
        chooser_count = driver.execute_script("return window.__fileChooserOpenedCount || 0") or 0
    except Exception:
        pass
    raise TimeoutException(f"Không tìm thấy input[type=file] kể cả shadow DOM. fileChooserOpened={chooser_count}. last_error={last_error}")


def detect_native_file_dialog():
    """v12.2 safety: disabled. Do not inspect or control Windows native dialogs.
    This prevents the tool from touching WinRAR/Topaz/other user windows.
    """
    return None


def upload_via_native_dialog(file_path, timeout=18):
    """v12.2 safety: disabled. Upload must use Gemini DOM input only."""
    return False

def has_upload_consent_modal_visible():
    global driver
    try:
        return bool(driver.execute_script("""
            const t = ((document.body && document.body.innerText) || '').toLowerCase();
            return t.includes('creating content from images and files') ||
                   t.includes('tạo nội dung từ hình ảnh và tệp') ||
                   t.includes('content from images and files');
        """))
    except Exception:
        return False


def get_upload_state(image_path=None):
    global driver
    filename = os.path.basename(image_path or '').lower() if image_path else ''
    try:
        return driver.execute_script(r"""
            const filename = (arguments[0] || '').toLowerCase();
            const bodyText = ((document.body && document.body.innerText) || '').toLowerCase();
            const hasFilenameText = !!filename && bodyText.includes(filename);
            const previewSelectors = [
                'uploader-file-preview',
                'uploader-file-preview img',
                'uploader-file-preview-container',
                'uploader-file-preview-container img',
                '.file-preview-container',
                '.file-preview-container img',
                '[data-test-id="image-preview"]',
                '[data-test-id="image-preview"] img',
                'img[data-test-id="uploaded-img"]'
            ];
            const uniq = [];
            const seen = new Set();
            for (const sel of previewSelectors) {
                for (const el of document.querySelectorAll(sel)) {
                    if (el && !seen.has(el)) {
                        seen.add(el);
                        uniq.push(el);
                    }
                }
            }
            const items = uniq.map(el => {
                const r = el.getBoundingClientRect();
                const src = el.currentSrc || el.src || '';
                const txt = ((el.innerText || el.value || el.alt || '') + ' ' + ((el.getAttribute && el.getAttribute('aria-label')) || '')).trim();
                return {
                    tag: el.tagName,
                    text: txt,
                    src,
                    w: Math.round(r.width || 0),
                    h: Math.round(r.height || 0),
                    visible: r.width >= 20 && r.height >= 20,
                };
            }).filter(x => x.visible);
            const previewKeys = items.map(x => [x.tag, x.text, x.src, x.w, x.h].join('|'));
            const hasBlobAttachmentPreview = items.some(x => String(x.src || '').startsWith('blob:') || String(x.text || '').toLowerCase().includes('attachment'));
            return {hasFilenameText, previewCount: items.length, previewKeys, hasBlobAttachmentPreview};
        """, filename)
    except Exception:
        return {"hasFilenameText": False, "previewCount": 0, "previewKeys": [], "hasBlobAttachmentPreview": False}


def wait_after_upload(image_path, timeout=None, before_state=None, require_new=False):
    if timeout is None:
        timeout = float(os.environ.get("GEMINI_UPLOAD_PREVIEW_TIMEOUT", "12") or 12)
    before_state = before_state or {}
    before_count = int(before_state.get('previewCount', 0) or 0)
    before_keys = set(before_state.get('previewKeys', []) or [])
    end_time = time.time() + timeout
    while time.time() < end_time:
        state = get_upload_state(image_path)
        after_count = int(state.get('previewCount', 0) or 0)
        after_keys = set(state.get('previewKeys', []) or [])
        new_preview = bool(after_keys - before_keys) or (after_count > before_count)
        if state.get('hasFilenameText'):
            print('✅ Upload confirm: thấy filename trong Gemini')
            return True
        if require_new:
            if new_preview and state.get('hasBlobAttachmentPreview'):
                print(f"✅ Upload confirm: có preview mới + blob/attachment ({before_count} → {after_count})")
                return True
        else:
            if after_count > 0 and state.get('hasBlobAttachmentPreview'):
                print(f"✅ Upload confirm: preview còn tồn tại ({after_count})")
                return True
        time.sleep(float(os.environ.get('GEMINI_UPLOAD_POLL_SECONDS', '0.25') or 0.25))
    print('ℹ Không bắt được tín hiệu upload rõ ràng, không xác nhận upload')
    return False


def wait_for_upload_settle(image_path, before_state=None, timeout=None):
    """v12.21: đợi attachment upload ổn định vài nhịp trước khi viết prompt và Send."""
    if timeout is None:
        timeout = float(os.environ.get("GEMINI_UPLOAD_SETTLE_TIMEOUT", "4.0") or 4.0)
    before_state = before_state or {}
    before_count = int(before_state.get('previewCount', 0) or 0)
    before_keys = set(before_state.get('previewKeys', []) or [])
    need_rounds = int(os.environ.get("GEMINI_UPLOAD_SETTLE_ROUNDS", "6") or 6)
    poll = float(os.environ.get("GEMINI_UPLOAD_SETTLE_POLL_SECONDS", "0.25") or 0.25)
    end_time = time.time() + timeout
    stable_rounds = 0
    last_sig = None
    saw_new = False
    while time.time() < end_time:
        state = get_upload_state(image_path)
        after_count = int(state.get('previewCount', 0) or 0)
        after_keys = set(state.get('previewKeys', []) or [])
        has_ok_preview = bool(after_count > 0 and state.get('hasBlobAttachmentPreview')) or bool(state.get('hasFilenameText'))
        new_preview = bool(after_keys - before_keys) or (after_count > before_count) or bool(state.get('hasFilenameText'))
        if new_preview:
            saw_new = True
        sig = '|'.join(sorted(after_keys)) + f"|f={1 if state.get('hasFilenameText') else 0}|c={after_count}|b={1 if state.get('hasBlobAttachmentPreview') else 0}"
        if has_ok_preview and saw_new:
            if sig == last_sig:
                stable_rounds += 1
            else:
                stable_rounds = 1
                last_sig = sig
            print(f"⏳ Upload settle: round {stable_rounds}/{need_rounds} • previews={after_count} • blob={bool(state.get('hasBlobAttachmentPreview'))}")
            if stable_rounds >= need_rounds:
                print("✅ Upload settle OK: attachment đã ổn định")
                return True
        else:
            stable_rounds = 0
            last_sig = sig
        time.sleep(poll)
    print("ℹ Upload settle chưa đủ ổn định")
    return False



def dismiss_native_dialog_if_any():
    """v12.2: TUYỆT ĐỐI không đóng/ESC bất kỳ hộp thoại Windows nào.
    Trước đây hàm này có thể bắt nhầm WinRAR/Topaz/app khác rồi close/ESC,
    gây popup "User break" hoặc làm gián đoạn việc khác của người dùng.
    Upload hiện chỉ dùng DOM input/send_keys; nếu Gemini không sinh input thì trả lỗi
    để retry bằng luồng Gemini, không chạm cửa sổ ngoài Chrome/tool.
    """
    return False


def wait_for_dom_input_dom_only(total_timeout=18, relabel="DOM-only"):
    """
    Chờ input[type=file] xuất hiện trong DOM/shadow DOM.
    v12.2: không đóng/ESC native dialog để tránh chạm nhầm WinRAR/Topaz/app khác.
    """
    end_time = time.time() + total_timeout
    phase = 0
    while time.time() < end_time:
        phase += 1
        install_file_hooks()
        try:
            file_input = find_file_input(timeout=2)
            print(f"✅ {relabel}: đã thấy input[type=file] ở pha chờ {phase} → dùng send_keys")
            return file_input
        except Exception:
            pass

        closed = dismiss_native_dialog_if_any()
        if closed:
            # v12.2: không đóng native dialog/cửa sổ ngoài
            pass

        # thử bấm lại item upload một nhịp nếu menu còn đang mở
        if phase in (2, 4, 6):
            try:
                click_upload_menu_item(timeout=1)
                time.sleep(0.4)
            except Exception:
                pass

        time.sleep(0.5)

    return None



def native_upload_via_strict_open_dialog(abs_image_path, timeout=12):
    """v12.2 safety: disabled. Never paste paths into native Windows dialogs.
    Upload must use DOM input/send_keys only, so other apps such as WinRAR are never affected.
    """
    return False

def upload_file(image_path, mode, _v118_after_consent_retry=False):
    global driver, FIRST_UPLOAD_FLOW_DONE, FIRST_UPLOAD_AGREE_DONE, LAST_UPLOAD_CONFIRMED_PATH
    print("📤 Bắt đầu bước upload v12.53 F12 local-images-files-upload...")
    print("📎 Chuẩn bị upload:", os.path.basename(image_path))
    print("🧭 Quy trình cố định: bấm Tải tệp lên → nếu có Agree thì bấm Agree → mở lại upload → chờ input[type=file] → send_keys")
    LAST_UPLOAD_CONFIRMED_PATH = None
    close_possible_popups()

    abs_image_path = os.path.abspath(image_path)
    install_file_hooks()
    install_dom_only_file_input_trap()
    upload_before_state = get_upload_state(abs_image_path)
    print(f"🧭 Upload baseline trước khi bấm Tải tệp lên: previews={upload_before_state.get('previewCount', 0)}")

    attach_btn = find_attach_button(timeout=25)
    try:
        print("🧷 Nút attach:", get_element_descriptor(attach_btn)[:150])
    except Exception:
        pass
    safe_click(attach_btn, "attach")
    time.sleep(float(os.environ.get("GEMINI_UPLOAD_POLL_SECONDS", "0.25") or 0.25))
    install_file_hooks()
    install_dom_only_file_input_trap()

    if not click_upload_menu_item(timeout=float(os.environ.get("GEMINI_UPLOAD_MENU_TIMEOUT", "10") or 10)):
        raise TimeoutException("Không bấm được mục Tải tệp lên / Upload files")
    print("✅ Đã bấm mục Tải tệp lên / Upload files")

    try:
        if click_pre_upload_consent_if_present(timeout=float(os.environ.get("GEMINI_UPLOAD_CONSENT_TIMEOUT", "3") or 3), relabel="v12.21 sau khi bấm Tải tệp lên"):
            FIRST_UPLOAD_AGREE_DONE = True
            print("🔐 v12.21: đã bấm Agree cho account này")
            # v12.53: Agree thường đóng menu; chờ overlay biến mất rồi chạy lại quy trình upload từ đầu.
            time.sleep(float(os.environ.get("GEMINI_AFTER_AGREE_REOPEN_DELAY", "0.9") or 0.9))
            close_possible_popups()
            return upload_file(image_path, mode, _v118_after_consent_retry=True)
    except Exception as e:
        print(f"⚠ v12.21: kiểm tra Agree trước upload lỗi: {e}")

    if (not FIRST_UPLOAD_FLOW_DONE) and has_upload_consent_modal_visible():
        raise TimeoutException("First-Upload Agree Lock: popup Agree vẫn còn, chưa được phép chờ input/file upload")

    file_input = None
    try:
        file_input = find_file_input(timeout=float(os.environ.get("GEMINI_AFTER_MENU_INPUT_TIMEOUT", "6") or 4))
        if file_input is not None:
            print("✅ Sau khi bấm menu/mở lại upload, đã thấy input[type=file] → dùng send_keys")
    except Exception:
        file_input = None

    if file_input is None:
        # v12.53: nếu click Upload files xong nhưng chưa có input, mở lại attach/menu một vòng ngắn trước khi fallback.
        try:
            print("↻ v12.53 chưa thấy input sau Upload files → mở lại attach/menu một vòng")
            attach_btn2 = find_attach_button(timeout=1.0)
            safe_click(attach_btn2, "v12.53 attach retry before DOM input")
            time.sleep(float(os.environ.get("GEMINI_UPLOAD_POLL_SECONDS", "0.25") or 0.25))
            if click_upload_menu_item(timeout=float(os.environ.get("GEMINI_UPLOAD_MENU_RETRY_TIMEOUT", "4") or 4)):
                file_input = find_file_input(timeout=float(os.environ.get("GEMINI_AFTER_MENU_INPUT_TIMEOUT", "6") or 4))
                if file_input is not None:
                    print("✅ v12.53 retry menu: đã thấy input[type=file] → dùng send_keys")
        except Exception as e:
            print(f"⚠ v12.53 retry menu/input lỗi nhẹ: {e}")
    if file_input is None:
        if mode == "pro":
            print("🧠 Account PRO: chờ DOM input đúng quy trình cũ")
            install_dom_only_file_input_trap()
            file_input = wait_for_trapped_or_dom_file_input(total_timeout=float(os.environ.get("GEMINI_PRO_DOM_INPUT_TIMEOUT", "18") or 18), relabel="PRO v12.21 exact upload")
        else:
            file_input = wait_for_dom_input_dom_only(total_timeout=float(os.environ.get("GEMINI_REGULAR_DOM_INPUT_TIMEOUT", "12") or 12), relabel="REGULAR v12.21 exact upload")

    if file_input is None:
        raise ProDomOnlyUnavailable("Không thấy input[type=file] sau quy trình: Tải tệp lên → Agree (nếu có) → mở lại upload")

    try:
        driver.execute_script("""
            arguments[0].style.display='block';
            arguments[0].style.visibility='visible';
            arguments[0].style.opacity='1';
            arguments[0].removeAttribute('hidden');
            arguments[0].removeAttribute('disabled');
        """, file_input)
    except Exception:
        pass

    file_input.send_keys(abs_image_path)
    upload_confirmed = wait_after_upload(abs_image_path, timeout=None, before_state=upload_before_state, require_new=True)
    if not upload_confirmed:
        LAST_UPLOAD_CONFIRMED_PATH = None
        raise TimeoutException("Upload chưa được Gemini xác nhận bằng preview mới/filename, không bấm vẽ")
    if not wait_for_upload_settle(abs_image_path, before_state=upload_before_state, timeout=float(os.environ.get("GEMINI_UPLOAD_SETTLE_TIMEOUT", "4.0") or 4.0)):
        LAST_UPLOAD_CONFIRMED_PATH = None
        raise TimeoutException("Upload preview chưa ổn định đủ lâu, chưa được viết prompt/send")

    LAST_UPLOAD_CONFIRMED_PATH = abs_image_path
    FIRST_UPLOAD_FLOW_DONE = True
    print("📤 Đã upload:", os.path.basename(abs_image_path), "• confirmed=", bool(upload_confirmed), "• settled=True • firstAgreeDone=", FIRST_UPLOAD_AGREE_DONE)
    try:
        if HIDE_STYLE in ('hide', 'minimize'):
            keep_browser_in_background()
    except Exception:
        pass




def _prompt_editor_text():
    global driver
    try:
        return str(driver.execute_script(r"""
            const el = document.querySelector('div[aria-label="Enter a prompt for Gemini"]')
                || document.querySelector('rich-textarea div[contenteditable="true"]')
                || document.querySelector('div[contenteditable="true"]')
                || document.querySelector('textarea');
            if(!el) return '';
            return (el.innerText || el.textContent || el.value || '').replace(/\s+/g,' ').trim();
        """) or '').strip()
    except Exception:
        return ''


def current_model_label():
    global driver
    try:
        return str(driver.execute_script(r"""
            const b=document.querySelector('button[data-test-id="bard-mode-menu-button"]');
            if(!b) return '';
            return ((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')).replace(/\s+/g,' ').trim();
        """) or '').strip()
    except Exception:
        return ''


def _normalize_target_model(target_model=None):
    raw = str(target_model or TARGET_MODEL or 'auto').strip().lower()
    return raw if raw in ('auto', 'flash', 'pro') else 'auto'


def _model_matches_target(label, target_model=None):
    low = str(label or '').strip().lower()
    target = _normalize_target_model(target_model)
    if target == 'auto':
        return True
    if target == 'pro':
        return 'pro' in low
    if target == 'flash':
        return 'flash' in low and 'pro' not in low
    return False


def _friendly_target_model_name(target_model=None):
    target = _normalize_target_model(target_model)
    return {'auto': 'Auto', 'flash': 'Flash', 'pro': 'Pro'}.get(target, 'Auto')


def select_target_model(timeout=15, target_model=None):
    global driver
    target = _normalize_target_model(target_model)
    current = current_model_label()
    if target == 'auto':
        if current:
            print(f"🎯 Giữ model hiện tại = {current} (Auto)")
            return current
        print("🎯 Auto mode: không ép model")
        return current
    if _model_matches_target(current, target):
        print(f"🎯 Model đã là {current}")
        return current

    end = time.time() + float(timeout)
    while time.time() < end:
        try:
            opened = driver.execute_script(r"""
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>20&&r.height>16;
                }
                const btn=document.querySelector('button[data-test-id="bard-mode-menu-button"]');
                if(!btn || !visible(btn)) return false;
                btn.click();
                return true;
            """)
        except Exception:
            opened = False
        if opened:
            time.sleep(0.7)
        try:
            clicked = driver.execute_script(r"""
                const target = arguments[0] || 'pro';
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>16&&r.height>12;
                }
                const items=Array.from(document.querySelectorAll('gem-menu-item,[role="menuitemradio"],button,[role="button"]')).filter(visible);
                const scored=items.map(el=>{
                    const txt=((el.innerText||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')).replace(/\s+/g,' ').trim();
                    const low=txt.toLowerCase();
                    let score=0;
                    if(target === 'flash'){
                        if(low.includes('2.5 flash')) score=110;
                        else if(low.includes('3.1 flash')) score=105;
                        else if(low.includes('flash-lite') || low.includes('flash lite')) score=100;
                        else if(low.includes('flash')) score=90;
                        if(low.includes('pro')) score -= 70;
                    }else{
                        if(low.includes('3.1 pro')) score=110;
                        else if(low.includes('2.5 pro')) score=105;
                        else if(low.includes(' pro')) score=90;
                    }
                    if(low.includes('recommended')) score += 2;
                    if(low.includes('experimental')) score -= 2;
                    return {el, txt, low, score};
                }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
                if(!scored.length) return '';
                scored[0].el.click();
                return scored[0].txt || target;
            """, target) or ''
        except Exception:
            clicked = ''
        if clicked:
            print(f"🎯 Đã chọn model {clicked}")
        time.sleep(1.0)
        current = current_model_label()
        if _model_matches_target(current, target):
            print(f"✅ Xác nhận model hiện tại = {current}")
            return current
        time.sleep(0.35)
    raise TimeoutException(f"Không chọn được model {_friendly_target_model_name(target)}. Current={current_model_label()}")


def is_create_image_checked():
    global driver
    try:
        return bool(driver.execute_script(r"""
            function visible(el){
                if(!el) return false;
                const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                return s.display!=='none'&&s.visibility!=='hidden'&&r.width>12&&r.height>12;
            }
            const items=Array.from(document.querySelectorAll('button[role="menuitemcheckbox"],[role="menuitemcheckbox"]')).filter(visible);
            for(const item of items){
                const label=((item.innerText||'')+' '+(item.getAttribute('aria-label')||'')+' '+(item.getAttribute('title')||'')).replace(/\s+/g,' ').trim().toLowerCase();
                if(label.includes('create image') || label.includes('tạo hình ảnh') || label.includes('tạo ảnh')) {
                    return item.getAttribute('aria-checked') === 'true';
                }
            }
            return false;
        """))
    except Exception:
        return False


def ensure_create_image_mode(timeout=12):
    global driver
    if is_create_image_checked():
        print("🖼 Create image đã bật")
        return True
    end = time.time() + float(timeout)
    while time.time() < end:
        try:
            driver.execute_script(r"""
                const b=document.querySelector('button[aria-label="Upload & tools"]');
                if(b && b.getAttribute('aria-expanded')!=='true') b.click();
            """)
        except Exception:
            pass
        time.sleep(0.55)
        try:
            clicked = driver.execute_script(r"""
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>12&&r.height>12;
                }
                const items=Array.from(document.querySelectorAll('button[role="menuitemcheckbox"],[role="menuitemcheckbox"]')).filter(visible);
                for(const item of items){
                    const label=((item.innerText||'')+' '+(item.getAttribute('aria-label')||'')+' '+(item.getAttribute('title')||'')).replace(/\s+/g,' ').trim().toLowerCase();
                    if(label.includes('create image') || label.includes('tạo hình ảnh') || label.includes('tạo ảnh')) {
                        const checked = item.getAttribute('aria-checked') === 'true';
                        if(!checked) item.click();
                        return true;
                    }
                }
                return false;
            """)
        except Exception:
            clicked = False
        time.sleep(0.8)
        try:
            if not is_create_image_checked():
                driver.execute_script(r"""
                    const b=document.querySelector('button[aria-label="Upload & tools"]');
                    if(b && b.getAttribute('aria-expanded')!=='true') b.click();
                """)
                time.sleep(0.55)
        except Exception:
            pass
        if is_create_image_checked():
            print("🖼 Create image đã bật")
            try:
                ActionChains(driver).send_keys(Keys.ESCAPE).perform()
            except Exception:
                pass
            return True
        time.sleep(0.25)
    raise TimeoutException('Không bật được Create image / aria-checked=true')


def prepare_target_create_image_mode(timeout=22, target_model=None):
    target = _normalize_target_model(target_model)
    last_model = current_model_label()
    end = time.time() + float(timeout)
    while time.time() < end:
        if target != 'auto':
            last_model = select_target_model(timeout=6, target_model=target)
        else:
            last_model = current_model_label()
        ensure_create_image_mode(timeout=6)
        current = current_model_label()
        if target == 'auto':
            print(f"✅ Sẵn sàng: model {_friendly_target_model_name(target)} + Create image • model={current or 'không rõ'}")
            return current
        if _model_matches_target(current, target):
            print(f"✅ Sẵn sàng: model {_friendly_target_model_name(target)} + Create image • model={current}")
            return current
        time.sleep(0.5)
    raise TimeoutException(f"Không giữ được đồng thời model {_friendly_target_model_name(target)} và Create image • model={last_model or current_model_label()}")


def write_prompt_confirmed(prompt_text, timeout=18):
    write_prompt(prompt_text)
    marker = re.sub(r'\s+', ' ', str(prompt_text or '')).strip()[:100]
    end = time.time() + float(timeout)
    while time.time() < end:
        current = _prompt_editor_text()
        if marker and marker.lower() in re.sub(r'\s+', ' ', current).strip().lower():
            print('✅ Prompt đã hiện trong ô nhập')
            return True
        time.sleep(0.25)
    raise TimeoutException('Prompt chưa hiện đúng trong ô nhập')


def click_send_and_confirm(prompt_text, timeout=16):
    global driver
    clicked = False
    end_click = time.time() + 5.0
    while time.time() < end_click and not clicked:
        try:
            btn = driver.execute_script(r"""
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>12&&r.height>12&&!el.disabled&&el.getAttribute('aria-disabled')!=='true';
                }
                const exact=document.querySelector('button[aria-label="Send message"]');
                if(exact && visible(exact)) return exact;
                return Array.from(document.querySelectorAll('button,[role="button"]')).find(b=>{
                    const t=((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')).toLowerCase();
                    return visible(b)&&(t.includes('send')||t.includes('gửi'));
                })||null;
            """)
            if btn:
                try:
                    driver.execute_script('arguments[0].click();', btn)
                except Exception:
                    btn.click()
                clicked = True
                break
        except Exception:
            pass
        time.sleep(0.12)
    if not clicked:
        click_send()
        clicked = True
    print('📨 Đã bấm Send message')

    marker = re.sub(r'\s+', ' ', str(prompt_text or '')).strip()[:80].lower()
    end = time.time() + float(timeout)
    while time.time() < end:
        try:
            state = driver.execute_script(r"""
                const marker=arguments[0];
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>8&&r.height>8;
                }
                const editor = document.querySelector('div[aria-label="Enter a prompt for Gemini"]')
                    || document.querySelector('rich-textarea div[contenteditable="true"]')
                    || document.querySelector('div[contenteditable="true"]')
                    || document.querySelector('textarea');
                const editorText = ((editor && (editor.innerText || editor.textContent || editor.value)) || '').replace(/\s+/g,' ').trim().toLowerCase();
                const bodyText = ((document.body && document.body.innerText) || '').replace(/\s+/g,' ').trim().toLowerCase();
                const send = document.querySelector('button[aria-label="Send message"]');
                const sendVisible = !!(send && visible(send) && send.getAttribute('aria-disabled')!=='true' && !send.disabled);
                const stop = Array.from(document.querySelectorAll('button,[role="button"]')).some(el=>{
                    const t=((el.innerText||'')+' '+(el.getAttribute('aria-label')||'')).toLowerCase();
                    return visible(el) && (t.includes('stop generating') || t.includes('stop response') || t.includes('dừng'));
                });
                const creation = bodyText.includes('creating image') || bodyText.includes('image creation') || bodyText.includes('generating') || bodyText.includes('working on it') || bodyText.includes('đang tạo');
                const promptSeen = marker ? bodyText.includes(marker) : false;
                return {editorText, sendVisible, stop, creation, promptSeen};
            """, marker) or {}
        except Exception:
            state = {}
        if state.get('stop') or state.get('creation') or (state.get('promptSeen') and (not state.get('sendVisible', True))) or ((not state.get('sendVisible', True)) and marker not in (state.get('editorText') or '')):
            print('✅ Prompt đã gửi và được xác nhận')
            return True
        time.sleep(0.35)
    raise TimeoutException('Đã bấm Send nhưng chưa xác nhận prompt được gửi')


def write_prompt(prompt_text):
    prompt_box = wait_editor_ready(timeout=float(os.environ.get("GEMINI_WRITE_PROMPT_EDITOR_TIMEOUT", "25") or 25))
    safe_click(prompt_box, "prompt box")
    time.sleep(0.05)
    try:
        ActionChains(driver).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.DELETE).perform()
        time.sleep(0.05)
    except Exception:
        pass
    typed = False
    try:
        prompt_box.send_keys(prompt_text)
        typed = True
    except Exception:
        typed = False
    if not typed:
        try:
            driver.execute_script(r"""
                const txt = arguments[1];
                const el = arguments[0] || document.querySelector('div[aria-label="Enter a prompt for Gemini"]')
                    || document.querySelector('rich-textarea div[contenteditable="true"]')
                    || document.querySelector('div[contenteditable="true"]')
                    || document.querySelector('textarea');
                if(!el) return false;
                el.focus();
                try {
                    const sel = window.getSelection();
                    const range = document.createRange();
                    range.selectNodeContents(el);
                    sel.removeAllRanges();
                    sel.addRange(range);
                    document.execCommand('delete', false, null);
                } catch(e) {}
                let inserted = false;
                try { inserted = document.execCommand('insertText', false, txt); } catch(e) { inserted = false; }
                if(!inserted){
                    if(el.tagName === 'TEXTAREA'){ el.value = txt; }
                    else { el.textContent = txt; }
                }
                el.dispatchEvent(new InputEvent('input', {bubbles:true, cancelable:true, inputType:'insertText', data:txt}));
                el.dispatchEvent(new Event('change', {bubbles:true, cancelable:true}));
                return true;
            """, prompt_box, prompt_text)
        except Exception:
            try:
                driver.execute_script("""
                    const el = arguments[0], txt = arguments[1];
                    el.focus();
                    if (el.tagName === 'TEXTAREA') { el.value = txt; el.dispatchEvent(new Event('input',{bubbles:true})); }
                    else { el.textContent = txt; el.dispatchEvent(new Event('input',{bubbles:true})); }
                """, prompt_box, prompt_text)
            except Exception:
                pass
    print("✍️ Đã nhập prompt")


def click_send():
    # v11.7: bấm Send ngay sau khi nhập prompt, không chờ dài.
    candidates = [
        "button[aria-label*='Gửi']",
        "button[aria-label*='Send']",
        "button[aria-label*='Tạo']",
        "button[aria-label*='Generate']",
    ]
    send_btn = None
    end = time.time() + float(os.environ.get("GEMINI_SEND_BUTTON_TIMEOUT", "1.5") or 1.5)
    while time.time() < end and send_btn is None:
        for sel in candidates:
            try:
                els = driver.find_elements(By.CSS_SELECTOR, sel)
                for el in els:
                    try:
                        if el.is_displayed() and el.is_enabled():
                            send_btn = el
                            break
                    except Exception:
                        pass
                if send_btn:
                    break
            except Exception:
                pass
        if send_btn is None:
            time.sleep(0.08)
    if send_btn is None:
        raise TimeoutException("Không tìm thấy nút Send/Gửi")
    try:
        driver.execute_script("arguments[0].click();", send_btn)
    except Exception:
        safe_click(send_btn, "send")
    print("🚀 Đã bấm Send")


def looks_like_avatar_or_ui_url(url):
    s = (url or '').lower().strip()
    if not s:
        return True
    ui_markers = [
        'googleusercontent.com/ogw/',
        'lh3.google.com/u/0/ogw/',
        'admin.googleusercontent.com/logo-',
        'admin.googleusercontent.com/logo_scs',
        'admin.googleusercontent.com/logo-scs',
        'googleusercontent.com/a/',
        'lh3.googleusercontent.com/a/',
        'gstatic.com/images',
        'gstatic.com/lamda/images/gemini_sparkle',
        'gemini_sparkle',
        'lamda/images',
        '.svg',
        'favicon',
        'avatar',
        'profile',
        'icon',
        'logo-scs-key',
    ]
    if any(m in s for m in ui_markers):
        return True
    if re.search(r'=s(?:16|20|24|28|32|40|48|56|64|72|80|96|128)(?:-|$)', s):
        return True
    return False

def pick_best_result_url(state, old_urls=None):
    old_urls = set(old_urls or [])
    uploader_urls = set(state.get('uploaderPreviewUrls', []) or [])

    response_urls = [
        u for u in state.get('responseUrls', [])
        if u not in old_urls and u not in uploader_urls and not looks_like_avatar_or_ui_url(u)
    ]
    if response_urls:
        response_urls.sort(key=lambda u: (
            3 if str(u).startswith('data:image/') else 0,
            2 if str(u).startswith('blob:') else 0,
            len(str(u))
        ), reverse=True)
        return response_urls[0]

    return None



def collect_baseline_result_urls():
    state = collect_result_state()
    baseline = set()
    for key in ("allUrls", "responseUrls", "uploaderPreviewUrls"):
        for u in state.get(key, []) or []:
            if u:
                baseline.add(u)
    return baseline

def collect_result_state():
    return driver.execute_script(r"""
        function uniq(arr){ return [...new Set(arr.filter(Boolean))]; }

        const result = {
            allUrls: [],
            responseUrls: [],
            responseBoxes: [],
            uploaderPreviewUrls: [],
            spinners: 0,
            stopBtns: 0,
            hasGeneratingText: false,
            assistantCount: 0
        };

        const txt = (document.body && document.body.innerText || '').toLowerCase();
        result.hasGeneratingText = [
            'đang tạo',
            'đang xử lý',
            'generating',
            'creating image',
            'working on it',
            'responding',
            'thinking'
        ].some(x => txt.includes(x));

        const allProgress = Array.from(document.querySelectorAll('[role="progressbar"], mat-progress-bar, .progress-bar, .loading, .spinner'));
        result.spinners = allProgress.filter(el => {
            const testId = (el.getAttribute('data-test-id') || '').toLowerCase();
            const cls = (el.className || '').toString().toLowerCase();
            const aria = (el.getAttribute('aria-label') || '').toLowerCase();
            const inHistory = !!el.closest('.loading-history-spinner-container, conversations-list, bard-sidenav-content, mat-sidenav, .conversation-items-container');
            const inUploader = !!el.closest('uploader-file-preview, uploader-file-preview-container, .file-preview-container');
            if (testId === 'loading-history-spinner') return false;
            if (cls.includes('loading-history-spinner')) return false;
            if (aria.includes('đang tải nhật ký trò chuyện')) return false;
            if (inHistory) return false;
            if (inUploader) return false;
            return true;
        }).length;

        result.stopBtns = Array.from(document.querySelectorAll('button')).filter(b => {
            const t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).toLowerCase();
            return t.includes('stop') || t.includes('dừng') || t.includes('hủy');
        }).length;

        result.assistantCount = Array.from(document.querySelectorAll(
            'message-content, .message-content, .response-container, .model-response, article, message-bubble'
        )).filter(el => {
            const t = (el.innerText || '').trim();
            return !!t;
        }).length;

        function looksBadSrc(src){
            const s = (src || '').toLowerCase();
            if (!s) return true;
            if (s.includes('googleusercontent.com/ogw/')) return true;
            if (s.includes('lh3.google.com/u/0/ogw/')) return true;
            if (s.includes('lh3.googleusercontent.com/a/')) return true;
            if (s.includes('googleusercontent.com/a/')) return true;
            if (s.includes('admin.googleusercontent.com/')) return true;
            if (s.includes('logo-scs')) return true;
            if (s.includes('gstatic.com/lamda/images/gemini_sparkle')) return true;
            if (s.includes('gemini_sparkle')) return true;
            if (s.includes('lamda/images')) return true;
            if (s.endsWith('.svg') || s.includes('.svg?')) return true;
            if (s.includes('favicon') || s.includes('avatar') || s.includes('profile')) return true;
            if (/=s(?:16|20|24|28|32|40|48|56|64|72|80|96|128)(?:-|$)/.test(s)) return true;
            return false;
        }

        function collectImg(img){
            const src = img.currentSrc || img.src || '';
            if (!src) return;
            const r = img.getBoundingClientRect();
            const cls = (img.className || '').toString().toLowerCase();
            const testid = (img.getAttribute('data-test-id') || '').toLowerCase();
            const inUploader = !!img.closest('uploader-file-preview, uploader-file-preview-container, .file-preview-container, [data-test-id="image-preview"]')
                || testid === 'uploaded-img'
                || cls.includes('preview-image');
            const info = {
                src,
                w: Math.round(r.width || 0),
                h: Math.round(r.height || 0),
                area: Math.round((r.width || 0) * (r.height || 0)),
                inUploader,
                visible: !!(r.width >= 40 && r.height >= 40),
                cls,
                testid
            };
            result.allUrls.push(src);
            if (info.inUploader) {
                result.uploaderPreviewUrls.push(src);
            } else if (
                info.visible &&
                info.w >= 180 &&
                info.h >= 180 &&
                !cls.includes('enterprise-logo') &&
                !cls.includes('user-icon') &&
                !looksBadSrc(src)
            ) {
                result.responseUrls.push(src);
                result.responseBoxes.push(info);
            }
        }

        document.querySelectorAll('img').forEach(collectImg);

        document.querySelectorAll('canvas').forEach(c => {
            try {
                const r = c.getBoundingClientRect();
                const inUploader = !!c.closest('uploader-file-preview, uploader-file-preview-container, .file-preview-container');
                if (!inUploader && r.width >= 180 && r.height >= 180) {
                    const dataUrl = c.toDataURL('image/png');
                    result.allUrls.push(dataUrl);
                    result.responseUrls.push(dataUrl);
                    result.responseBoxes.push({
                        src: dataUrl,
                        w: Math.round(r.width || 0),
                        h: Math.round(r.height || 0),
                        area: Math.round((r.width || 0) * (r.height || 0)),
                        inUploader: false,
                        visible: true
                    });
                }
            } catch (e) {}
        });

        result.allUrls = uniq(result.allUrls);
        result.responseUrls = uniq(result.responseUrls);
        result.uploaderPreviewUrls = uniq(result.uploaderPreviewUrls);
        result.responseBoxes.sort((a,b) => (b.area || 0) - (a.area || 0));

        return result;
    """)


def _image_quota_snapshot():
    """v13.54: chụp quota theo *assistant response thật* của Gemini.

    Không dùng việc ``assistantCount`` tăng hoặc một câu quota cũ bị DOM render lại làm
    bằng chứng.  Quota chỉ hợp lệ khi sau Send xuất hiện **một response mới của Gemini**
    và chính response mới đó chứa câu giới hạn tạo ảnh.
    """
    global driver
    try:
        state = driver.execute_script(r"""
            const patterns = [
                'image generation limit reached',
                'daily image generation limit reached',
                "i can't create more images for you today",
                "i cannot create more images for you today",
                "you've reached your image generation limit",
                'you have reached your image generation limit',
                'cannot create more images today',
                "can't create more images today",
                'bạn đã đạt đến hạn mức tạo hình ảnh',
                'bạn đã đạt giới hạn tạo hình ảnh',
                'đã đạt đến giới hạn tạo hình ảnh',
                'hạn mức tạo hình ảnh của bạn',
                'hạn mức của bạn sẽ được đặt lại'
            ];
            const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
            const hitText = s => {
                const t = norm(s);
                return patterns.some(p => t.includes(p));
            };
            const visible = el => {
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const st = getComputedStyle(el);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 2 && r.height > 2;
            };

            // Chọn MỘT loại container response, ưu tiên component Gemini cụ thể nhất.
            // Không dùng message-content chung vì nó có thể đếm cả tin nhắn người dùng.
            const selectorGroups = [
                'model-response',
                '[data-message-author-role="assistant"]',
                '.model-response',
                '.response-container'
            ];
            let responses = [];
            let responseSelector = '';
            for (const sel of selectorGroups) {
                const arr = Array.from(document.querySelectorAll(sel)).filter(el => {
                    if (!visible(el)) return false;
                    const t = norm(el.innerText || el.textContent || '');
                    return !!t;
                });
                if (arr.length) {
                    responses = arr;
                    responseSelector = sel;
                    break;
                }
            }

            const responseTexts = responses.map(el => norm(el.innerText || el.textContent || '').slice(0, 4000));
            const quotaResponses = [];
            responseTexts.forEach((t, i) => {
                if (t && hitText(t)) quotaResponses.push({index: i, text: t.slice(0, 1200)});
            });

            // Chỉ để debug; alert độc lập KHÔNG tự đủ điều kiện kết luận quota.
            const alertTexts = [];
            for (const el of Array.from(document.querySelectorAll('[role="alert"], mat-snack-bar-container, .mat-mdc-snack-bar-label'))) {
                if (!visible(el)) continue;
                const t = norm(el.innerText || el.textContent || '');
                if (t && hitText(t)) alertTexts.push(t.slice(0, 1200));
            }

            return {
                hit: quotaResponses.length > 0,
                responseCount: responseTexts.length,
                responseSelector,
                responseTexts,
                quotaResponses,
                alertQuotaTexts: Array.from(new Set(alertTexts)),
                text: quotaResponses.map(x => x.text).join(' | ').slice(0, 4000)
            };
        """) or {}
        qrs = list(state.get('quotaResponses') or [])
        return {
            'hit': bool(state.get('hit')),
            'responseCount': int(state.get('responseCount') or 0),
            'assistantCount': int(state.get('responseCount') or 0),  # tương thích code cũ
            'responseSelector': str(state.get('responseSelector') or ''),
            'responseTexts': list(state.get('responseTexts') or []),
            'quotaResponses': qrs,
            'signatures': [str(x.get('text') or '') for x in qrs if isinstance(x, dict)],
            'alertQuotaTexts': list(state.get('alertQuotaTexts') or []),
            'text': str(state.get('text') or ''),
        }
    except Exception:
        return {
            'hit': False, 'responseCount': 0, 'assistantCount': 0,
            'responseSelector': '', 'responseTexts': [], 'quotaResponses': [],
            'signatures': [], 'alertQuotaTexts': [], 'text': ''
        }


def detect_image_quota_reached(baseline_signatures=None, baseline_assistant_count=None,
                               require_fresh=False, baseline_response_count=None):
    """v13.54: quota chỉ được xác nhận từ response Gemini *mới* sau Send.

    Quan trọng: một câu ``image generation limit reached`` cũ có thể bị Angular/Gemini
    render lại sau khi bấm Send. Vì vậy tuyệt đối không dùng ``assistantCount tăng`` hay
    ``signature khác`` làm đủ bằng chứng. Phải có một response container mới nằm sau
    mốc ``baseline_response_count`` và response mới đó chứa câu quota.
    """
    state = _image_quota_snapshot()
    if not state.get('hit'):
        return False, ''
    if not require_fresh:
        return True, str(state.get('text') or '')

    try:
        baseline_n = int(
            baseline_response_count
            if baseline_response_count is not None
            else (baseline_assistant_count or 0)
        )
    except Exception:
        baseline_n = 0

    current_n = int(state.get('responseCount') or 0)
    # Nếu chưa xuất hiện thêm response Gemini thì CHẮC CHẮN chưa được phép kết luận quota.
    if current_n <= baseline_n:
        return False, ''

    fresh_quota = []
    for item in (state.get('quotaResponses') or []):
        if not isinstance(item, dict):
            continue
        try:
            idx = int(item.get('index'))
        except Exception:
            continue
        if idx >= baseline_n:
            txt = str(item.get('text') or '').strip()
            if txt:
                fresh_quota.append(txt)

    if not fresh_quota:
        return False, ''
    return True, ' | '.join(fresh_quota)[:4000]

def detect_gemini_policy_refusal(baseline_response_count=None, require_fresh=False):
    """v13.54: refusal sau Send cũng phải thuộc response Gemini mới.

    Bản cũ quét toàn ``document.body`` nên một câu từ chối cũ trong lịch sử chat có
    thể làm account hiện tại bị loại dù Gemini chưa trả lời job mới.
    """
    global driver
    try:
        snap = _image_quota_snapshot()
        texts = list(snap.get('responseTexts') or [])
        try:
            base_n = int(baseline_response_count or 0)
        except Exception:
            base_n = 0
        if require_fresh:
            if len(texts) <= base_n:
                return False, ''
            texts = texts[base_n:]

        joined = '\n'.join(str(x or '') for x in texts).lower()
        patterns = [
            'image editing request denied',
            'editing request denied',
            'image request denied',
            'yêu cầu chỉnh sửa hình ảnh bị từ chối',
            'yêu cầu tạo ảnh bị từ chối',
            'i can create images of people, but not ones that depict a real person',
            'not ones that depict a real person',
            'depict a real person like that',
            'do you have another idea',
            "can\'t create that image",
            "can\'t help create an image",
            'unable to create an image of a real person',
            'cannot create an image of a real person',
            'policy refusal',
            'refused to create',
            'từ chối yêu cầu',
            'bị từ chối'
        ]
        hit = any(p in joined for p in patterns)
        if hit:
            try:
                print(f"🚫 Gemini refusal MỚI sau Send detected • freshResponses={max(0, len(list(snap.get('responseTexts') or [])) - base_n)}")
            except Exception:
                pass
            return True, joined[:6000]
        return False, ''
    except Exception:
        return False, ''

def wait_for_result_image(timeout=240, old_urls=None, quota_baseline_signatures=None,
                          quota_baseline_assistant_count=0, quota_baseline_response_count=None):
    """v13.54: chờ Gemini thật sự trả response/ảnh; không kết luận từ DOM cũ.

    - Luôn quan sát/log state trước khi kết luận quota/refusal.
    - Quota/refusal phải nằm trong response Gemini mới sau Send.
    - Nếu chưa có response mới, không thoát sớm chỉ vì spinner/busy chưa được nhận diện.
    """
    start = time.time()
    last_log = None
    idle_rounds = 0
    stable_key = None
    stable_rounds = 0
    try:
        baseline_response_n = int(
            quota_baseline_response_count
            if quota_baseline_response_count is not None
            else (quota_baseline_assistant_count or 0)
        )
    except Exception:
        baseline_response_n = 0
    min_no_response_wait = float(os.environ.get('GEMINI_MIN_NO_RESPONSE_WAIT', '45') or 45)

    while time.time() - start < timeout:
        elapsed = time.time() - start
        state = collect_result_state()
        strict_snap = _image_quota_snapshot()
        strict_response_n = int(strict_snap.get('responseCount') or 0)
        fresh_response_seen = strict_response_n > baseline_response_n

        busy = bool(state.get('hasGeneratingText')) or state.get('spinners', 0) > 0 or state.get('stopBtns', 0) > 0
        result_src = pick_best_result_url(state, old_urls=old_urls)
        has_real_response = len(state.get('responseUrls', [])) > 0 or state.get('assistantCount', 0) >= 1
        top_box = (state.get('responseBoxes') or [{}])[0] if state.get('responseBoxes') else {}
        current_key = None
        if result_src and has_real_response:
            current_key = (
                str(result_src)[:240],
                int(top_box.get('w') or 0),
                int(top_box.get('h') or 0),
                int(top_box.get('area') or 0),
                len(state.get('responseUrls', []) or []),
            )
            if current_key == stable_key:
                stable_rounds += 1
            else:
                stable_key = current_key
                stable_rounds = 1
        else:
            stable_key = None
            stable_rounds = 0

        log_key = (
            busy,
            state.get('assistantCount', 0),
            strict_response_n,
            fresh_response_seen,
            state.get('spinners', 0),
            state.get('stopBtns', 0),
            len(state.get('uploaderPreviewUrls', [])),
            len(state.get('responseUrls', [])),
            bool(result_src),
            stable_rounds,
            int(elapsed // 5),
        )
        if log_key != last_log:
            print(
                f"⏱ Gemini state: t={elapsed:.1f}s | busy={busy} | responses={strict_response_n} "
                f"(baseline={baseline_response_n}, fresh={fresh_response_seen}) | "
                f"spinners={state.get('spinners')} | stopBtns={state.get('stopBtns')} | "
                f"uploadPreviews={len(state.get('uploaderPreviewUrls', []))} | "
                f"responseImgs={len(state.get('responseUrls', []))} | freshResult={bool(result_src)} | "
                f"stable={stable_rounds}/{RESULT_STABLE_ROUNDS}"
            )
            last_log = log_key

        # Chỉ sau khi đã quan sát state mới xét quota/refusal, và phải là response mới.
        quota_hit, quota_text = detect_image_quota_reached(
            baseline_signatures=quota_baseline_signatures,
            baseline_assistant_count=quota_baseline_assistant_count,
            baseline_response_count=baseline_response_n,
            require_fresh=True,
        )
        if quota_hit:
            evidence = re.sub(r'\s+', ' ', str(quota_text or '')).strip()[:220]
            raise ImageQuotaReached(
                "Gemini trả RESPONSE MỚI xác nhận hết lượt tạo ảnh sau Send"
                + (f": {evidence}" if evidence else "")
            )

        refusal_hit, _ = detect_gemini_policy_refusal(
            baseline_response_count=baseline_response_n,
            require_fresh=True,
        )
        if refusal_hit:
            raise GeminiPolicyRefusal("Gemini trả RESPONSE MỚI từ chối ảnh trên account hiện tại")

        if result_src and has_real_response and stable_rounds >= RESULT_STABLE_ROUNDS:
            if busy and stable_rounds < RESULT_STABLE_ROUNDS + 1:
                time.sleep(1.0)
            else:
                time.sleep(RESULT_STABLE_SECONDS)
                return result_src, state

        if not busy:
            idle_rounds += 1
        else:
            idle_rounds = 0

        # Có response mới nhưng không phải quota/refusal và cũng không có ảnh: có thể Gemini
        # trả text lỗi khác. Cho vài vòng ổn định rồi trả None để job retry, KHÔNG khóa account quota.
        if fresh_response_seen and idle_rounds >= 4 and elapsed >= 8:
            if result_src and has_real_response:
                return result_src, state
            print("⚠ Gemini đã trả response mới nhưng chưa có ảnh/quota rõ ràng → coi là no-result để retry, KHÔNG đánh dấu hết quota")
            return None, state

        # Nếu chưa hề có response mới thì phải chờ đủ lâu; không thoát sau 4 vòng idle như bản cũ.
        if (not fresh_response_seen) and (not busy) and elapsed >= min_no_response_wait:
            print(f"⚠ Sau {elapsed:.0f}s Gemini vẫn chưa có response mới/ảnh → timeout no-response, KHÔNG đánh dấu hết quota")
            return None, state

        time.sleep(1.5)

    # Hết timeout tuyệt đối: chỉ xác nhận quota/refusal nếu có response mới cụ thể.
    quota_hit3, quota_text3 = detect_image_quota_reached(
        baseline_signatures=quota_baseline_signatures,
        baseline_assistant_count=quota_baseline_assistant_count,
        baseline_response_count=baseline_response_n,
        require_fresh=True,
    )
    if quota_hit3:
        evidence = re.sub(r'\s+', ' ', str(quota_text3 or '')).strip()[:220]
        raise ImageQuotaReached(
            "Gemini trả RESPONSE MỚI xác nhận hết lượt tạo ảnh sau Send"
            + (f": {evidence}" if evidence else "")
        )
    refusal_hit3, _ = detect_gemini_policy_refusal(
        baseline_response_count=baseline_response_n,
        require_fresh=True,
    )
    if refusal_hit3:
        raise GeminiPolicyRefusal("Gemini trả RESPONSE MỚI từ chối ảnh trên account hiện tại")
    return None, collect_result_state()

def _image_bytes_valid(data):
    """Kiểm tra payload thật sự là ảnh trước khi ghi đè file job."""
    if not data or len(data) < 128:
        return False
    try:
        with Image.open(BytesIO(data)) as img:
            img.verify()
        return True
    except Exception:
        return False


def _save_image_bytes(data, target_path, source_note):
    if not _image_bytes_valid(data):
        return f"{source_note}: payload không phải ảnh hợp lệ"
    with open(target_path, "wb") as f:
        f.write(data)
    return f"{source_note}: saved image bytes ({len(data)} bytes)"


def _browser_request_headers():
    try:
        ua = driver.execute_script("return navigator.userAgent || ''") or ''
    except Exception:
        ua = ''
    try:
        referer = driver.current_url or 'https://gemini.google.com/'
    except Exception:
        referer = 'https://gemini.google.com/'
    headers = {
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'Referer': referer,
    }
    if ua:
        headers['User-Agent'] = ua
    return headers


def _requests_download_with_browser_session(url, target_path):
    """Tải URL bằng cookie/UA/Referer của Chrome. Không ném exception ra ngoài capture flow."""
    global REMOTE_CDN_DIRECT_BLOCKED
    low_url = str(url or '').lower()
    is_google_cdn = 'googleusercontent.com/' in low_url or 'gg-dl/' in low_url or 'rd-gg-dl/' in low_url
    if is_google_cdn and REMOTE_CDN_DIRECT_BLOCKED:
        return "remote URL skipped: googleusercontent đã trả 403 trước đó trong worker này"
    try:
        sess = requests.Session()
        try:
            for c in driver.get_cookies() or []:
                name = c.get('name')
                value = c.get('value')
                if not name or value is None:
                    continue
                kwargs = {'path': c.get('path') or '/'}
                domain = c.get('domain')
                if domain:
                    kwargs['domain'] = domain
                try:
                    sess.cookies.set(name, value, **kwargs)
                except Exception:
                    sess.cookies.set(name, value)
        except Exception as cookie_e:
            print(f"⚠ CDN capture: không copy đủ cookie Chrome: {cookie_e}")

        r = sess.get(url, headers=_browser_request_headers(), timeout=45, allow_redirects=True)
        if int(getattr(r, 'status_code', 0) or 0) == 403:
            if is_google_cdn:
                REMOTE_CDN_DIRECT_BLOCKED = True
            return f"remote URL HTTP 403: {getattr(r, 'url', url)}"
        if not (200 <= int(getattr(r, 'status_code', 0) or 0) < 300):
            return f"remote URL HTTP {getattr(r, 'status_code', '?')}: {getattr(r, 'url', url)}"
        msg = _save_image_bytes(r.content, target_path, "saved from remote URL with Chrome session")
        if 'saved image bytes' in msg:
            return msg
        return msg
    except Exception as e:
        if '403' in str(e) and is_google_cdn:
            REMOTE_CDN_DIRECT_BLOCKED = True
        return f"remote URL exception: {type(e).__name__}: {e}"


def _browser_fetch_image_data_url(url):
    """Thử fetch ngay trong tab Gemini để dùng session thật của Chrome; CORS fail thì trả message, không throw."""
    try:
        result = driver.execute_async_script(r"""
            const url = arguments[0];
            const done = arguments[arguments.length - 1];
            fetch(url, {credentials:'include', cache:'no-store', redirect:'follow'})
              .then(async r => {
                  if (!r.ok) { done({ok:false, msg:'HTTP ' + r.status + ' ' + r.url}); return; }
                  const blob = await r.blob();
                  const reader = new FileReader();
                  reader.onloadend = () => done({ok:true, dataUrl: reader.result || '', type: blob.type || '', size: blob.size || 0});
                  reader.onerror = () => done({ok:false, msg:'FileReader error'});
                  reader.readAsDataURL(blob);
              })
              .catch(err => done({ok:false, msg:'fetch error: ' + String(err)}));
        """, url)
        if result and result.get('ok') and str(result.get('dataUrl') or '').startswith('data:image/'):
            return result.get('dataUrl'), f"browser fetch OK ({result.get('size', 0)} bytes)"
        return None, f"browser fetch failed: {(result or {}).get('msg', 'no result')}"
    except Exception as e:
        return None, f"browser fetch exception: {type(e).__name__}: {e}"


def save_result_image(url, target_path):
    """Lấy ảnh kết quả nhưng TUYỆT ĐỐI không để HTTP 403 phá vỡ fallback capture.

    Thứ tự:
    1) data/blob trực tiếp trong Chrome
    2) requests dùng cookie + UA + Referer của Chrome
    3) fetch trong browser (nếu CORS cho phép)
    Nếu vẫn thất bại, trả message để process_image chuyển sang element screenshot/DOM fallback.
    """
    if not url:
        return "remote URL missing"
    if url.startswith("data:image/"):
        try:
            header, encoded = url.split(",", 1)
            import base64
            data = base64.b64decode(encoded)
            return _save_image_bytes(data, target_path, "saved from data url")
        except Exception as e:
            return f"data url decode failed: {type(e).__name__}: {e}"
    if url.startswith("blob:"):
        js = r"""
            const blobUrl = arguments[0];
            const done = arguments[arguments.length - 1];
            fetch(blobUrl).then(r => r.blob()).then(blob => {
                const reader = new FileReader();
                reader.onloadend = () => done(reader.result || '');
                reader.readAsDataURL(blob);
            }).catch(err => done('ERROR:' + String(err)));
        """
        try:
            data_url = driver.execute_async_script(js, url)
            if isinstance(data_url, str) and data_url.startswith("data:image/"):
                return save_result_image(data_url, target_path)
            return f"blob fetch failed: {data_url}"
        except Exception as e:
            return f"blob fetch failed: {type(e).__name__}: {e}"

    # Google CDN mới có thể redirect gg-dl -> rd-gg-dl và trả 403 cho requests ngoài browser.
    # Thử một lần với session Chrome; sau 403 sẽ tự bỏ qua raw HTTP ở các job tiếp theo của worker.
    remote_msg = _requests_download_with_browser_session(url, target_path)
    if _capture_saved_message_ok(remote_msg):
        return remote_msg

    # Một số response cho phép đọc bằng fetch trong chính tab Gemini.
    data_url, fetch_msg = _browser_fetch_image_data_url(url)
    if data_url:
        saved = save_result_image(data_url, target_path)
        if _capture_saved_message_ok(saved):
            return f"{saved} • {fetch_msg}"
    return f"{remote_msg} • {fetch_msg}"


def save_result_from_rendered_element(target_path, preferred_src=None):
    """Capture trực tiếp IMG/CANVAS do Chrome đang render.

    Selenium WebElement.screenshot không bị CORS/canvas taint như drawImage().
    Đây là fallback chính cho googleusercontent 403.
    """
    try:
        candidates = []
        for el in driver.find_elements(By.CSS_SELECTOR, 'img, canvas'):
            try:
                info = driver.execute_script(r"""
                    const el = arguments[0];
                    const preferred = arguments[1] || '';
                    const r = el.getBoundingClientRect();
                    const cls = (el.className || '').toString().toLowerCase();
                    const testid = ((el.getAttribute && el.getAttribute('data-test-id')) || '').toLowerCase();
                    const src = el.tagName === 'IMG' ? (el.currentSrc || el.src || '') : 'canvas';
                    const s = (src || '').toLowerCase();
                    const inUploader = !!el.closest('uploader-file-preview, uploader-file-preview-container, .file-preview-container, [data-test-id="image-preview"]') || testid === 'uploaded-img' || cls.includes('preview-image');
                    const bad = s.includes('googleusercontent.com/ogw/') || s.includes('lh3.google.com/u/0/ogw/') || s.includes('admin.googleusercontent.com/') || s.includes('logo-scs') || s.includes('favicon') || s.includes('avatar') || s.includes('profile') || cls.includes('enterprise-logo') || cls.includes('user-icon');
                    const naturalW = el.tagName === 'IMG' ? (el.naturalWidth || 0) : (el.width || 0);
                    const naturalH = el.tagName === 'IMG' ? (el.naturalHeight || 0) : (el.height || 0);
                    let responseHint = false;
                    try {
                        responseHint = !!el.closest('model-response, message-content, .model-response-text, [data-test-id*="response"], [class*="response"]');
                    } catch(e) {}
                    return {
                        ok: !inUploader && !bad && r.width >= 180 && r.height >= 180,
                        src, x:r.left, y:r.top, w:r.width, h:r.height,
                        naturalW, naturalH,
                        preferred: !!preferred && src === preferred,
                        responseHint
                    };
                """, el, preferred_src or '')
                if not info or not info.get('ok'):
                    continue
                src = str(info.get('src') or '')
                if src and src != 'canvas' and looks_like_avatar_or_ui_url(src):
                    continue
                area = float(info.get('w') or 0) * float(info.get('h') or 0)
                natural_area = float(info.get('naturalW') or 0) * float(info.get('naturalH') or 0)
                score = area + min(natural_area, 20_000_000) * 0.05
                if info.get('responseHint'):
                    score += 100_000_000
                if info.get('preferred'):
                    score += 1_000_000_000
                candidates.append((score, el, info))
            except (StaleElementReferenceException, WebDriverException):
                continue
            except Exception:
                continue

        if not candidates:
            return 'browser element screenshot: no visible result candidate'
        candidates.sort(key=lambda x: x[0], reverse=True)

        # Thử tối đa 4 candidate lớn nhất, tránh 1 node stale làm fail toàn capture.
        last_err = None
        for _, el, info in candidates[:4]:
            try:
                driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center'});", el)
                time.sleep(0.35)
                ok = el.screenshot(target_path)
                if not ok or not os.path.isfile(target_path):
                    last_err = 'element.screenshot returned false'
                    continue
                try:
                    with Image.open(target_path) as chk:
                        w, h = chk.size
                        chk.verify()
                    if w < 180 or h < 180:
                        last_err = f'captured element quá nhỏ {w}x{h}'
                        continue
                except Exception as img_e:
                    last_err = f'captured element invalid: {img_e}'
                    continue
                return f"browser element screenshot: saved {w}x{h} src={str(info.get('src') or '')[:180]}"
            except Exception as e:
                last_err = f'{type(e).__name__}: {e}'
                continue
        return f"browser element screenshot: failed: {last_err or 'unknown'}"
    except Exception as e:
        return f"browser element screenshot error: {type(e).__name__}: {e}"


def save_result_via_browser_tab(url, target_path):
    """Fallback phụ: mở URL ảnh bằng chính Chrome/session hiện tại rồi lấy ảnh ở tab tạm."""
    if not url or str(url).startswith(('data:', 'blob:')):
        return 'browser tab capture: URL không phù hợp'
    original = None
    new_handle = None
    try:
        original = driver.current_window_handle
        before = set(driver.window_handles)
        # Click anchor trong page để giữ browser context/referrer tốt hơn driver.get() trực tiếp.
        driver.execute_script(r"""
            const a = document.createElement('a');
            a.href = arguments[0];
            a.target = '_blank';
            a.rel = 'noopener';
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            a.remove();
        """, url)
        deadline = time.time() + 6
        while time.time() < deadline:
            after = set(driver.window_handles)
            diff = list(after - before)
            if diff:
                new_handle = diff[-1]
                break
            time.sleep(0.2)
        if not new_handle:
            return 'browser tab capture: không mở được tab ảnh'
        driver.switch_to.window(new_handle)

        deadline = time.time() + 15
        img = None
        while time.time() < deadline:
            try:
                imgs = driver.find_elements(By.CSS_SELECTOR, 'img')
                for candidate in imgs:
                    dims = driver.execute_script("return [arguments[0].complete, arguments[0].naturalWidth||0, arguments[0].naturalHeight||0];", candidate)
                    if dims and dims[0] and int(dims[1] or 0) >= 180 and int(dims[2] or 0) >= 180:
                        img = candidate
                        break
                if img is not None:
                    break
            except Exception:
                pass
            time.sleep(0.4)
        if img is None:
            return f"browser tab capture: không thấy ảnh, url={str(getattr(driver, 'current_url', ''))[:180]}"

        # Khi ảnh là top-level document, canvas thường đọc được full natural resolution.
        try:
            data_url = driver.execute_script(r"""
                const img = arguments[0];
                const c = document.createElement('canvas');
                c.width = img.naturalWidth || img.width;
                c.height = img.naturalHeight || img.height;
                const ctx = c.getContext('2d');
                ctx.drawImage(img, 0, 0, c.width, c.height);
                return c.toDataURL('image/png');
            """, img)
            if isinstance(data_url, str) and data_url.startswith('data:image/'):
                msg = save_result_image(data_url, target_path)
                if _capture_saved_message_ok(msg):
                    return f"browser tab capture: saved full image • {msg}"
        except Exception as canvas_e:
            print(f"⚠ browser tab canvas không đọc được full image: {canvas_e}")

        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", img)
            time.sleep(0.25)
            if img.screenshot(target_path):
                with Image.open(target_path) as chk:
                    w, h = chk.size
                    chk.verify()
                if w >= 180 and h >= 180:
                    return f"browser tab capture: saved element {w}x{h}"
        except Exception as shot_e:
            return f"browser tab capture: element screenshot lỗi: {shot_e}"
        return 'browser tab capture: không lưu được ảnh'
    except Exception as e:
        return f"browser tab capture error: {type(e).__name__}: {e}"
    finally:
        try:
            if new_handle and new_handle in driver.window_handles:
                driver.close()
        except Exception:
            pass
        try:
            if original and original in driver.window_handles:
                driver.switch_to.window(original)
        except Exception:
            pass


def save_exact_result_from_dom(target_path, preferred_src=None, old_urls=None):
    """
    Cố lấy ảnh kết quả đúng từ DOM hiện tại mà không cần screenshot crop.
    Ưu tiên canvas / img kết quả lớn, bỏ qua uploader preview và avatar UI.
    """
    try:
        result = driver.execute_async_script(r"""
            const preferredSrc = arguments[0] || '';
            const done = arguments[arguments.length - 1];

            function looksBad(src){
                const s = (src || '').toLowerCase();
                if (!s) return false;
                if (s.includes('googleusercontent.com/ogw/')) return true;
                if (s.includes('lh3.google.com/u/0/ogw/')) return true;
                if (s.includes('/a/') && s.includes('googleusercontent.com')) return true;
                if (s.includes('admin.googleusercontent.com/')) return true;
                if (s.includes('logo-scs')) return true;
                if (/=s(?:16|20|24|28|32|40|48|64|72|96|128)(?:-|$)/.test(s)) return true;
                return false;
            }

            function isGoodImage(img){
                const r = img.getBoundingClientRect();
                const src = img.currentSrc || img.src || '';
                const cls = (img.className || '').toString().toLowerCase();
                const testid = (img.getAttribute('data-test-id') || '').toLowerCase();
                const inUploader =
                    !!img.closest('uploader-file-preview, uploader-file-preview-container, .file-preview-container, [data-test-id="image-preview"]') ||
                    testid === 'uploaded-img' ||
                    cls.includes('preview-image');
                return !inUploader && !looksBad(src) && !cls.includes('enterprise-logo') && !cls.includes('user-icon') && r.width >= 180 && r.height >= 180 && img.complete;
            }

            async function imgToDataUrl(img){
                try {
                    if (img.decode) {
                        try { await img.decode(); } catch(e) {}
                    }
                    const w = img.naturalWidth || Math.round(img.getBoundingClientRect().width) || 0;
                    const h = img.naturalHeight || Math.round(img.getBoundingClientRect().height) || 0;
                    if (!w || !h) return null;
                    const c = document.createElement('canvas');
                    c.width = w;
                    c.height = h;
                    const ctx = c.getContext('2d');
                    ctx.drawImage(img, 0, 0, w, h);
                    return c.toDataURL('image/png');
                } catch (e) {
                    return 'ERROR:' + e;
                }
            }

            try {
                const candidates = [];

                document.querySelectorAll('canvas').forEach(c => {
                    try {
                        const r = c.getBoundingClientRect();
                        const inUploader = !!c.closest('uploader-file-preview, uploader-file-preview-container, .file-preview-container, [data-test-id="image-preview"]');
                        if (!inUploader && r.width >= 180 && r.height >= 180) {
                            candidates.push({type:'canvas', area:r.width*r.height, preferred:false, node:c, src:'canvas'});
                        }
                    } catch(e) {}
                });

                document.querySelectorAll('img').forEach(img => {
                    try {
                        if (!isGoodImage(img)) return;
                        const src = img.currentSrc || img.src || '';
                        const r = img.getBoundingClientRect();
                        candidates.push({type:'img', area:r.width*r.height, preferred:(preferredSrc && src === preferredSrc), node:img, src});
                    } catch(e) {}
                });

                candidates.sort((a,b) => {
                    if (a.preferred !== b.preferred) return a.preferred ? -1 : 1;
                    return b.area - a.area;
                });

                if (!candidates.length) {
                    done({ok:false, msg:'no DOM result candidate'});
                    return;
                }

                const target = candidates[0];
                if (target.type === 'canvas') {
                    try {
                        done({ok:true, src:target.src, dataUrl:target.node.toDataURL('image/png')});
                    } catch (e) {
                        done({ok:false, msg:'canvas toDataURL error: ' + e});
                    }
                    return;
                }

                imgToDataUrl(target.node).then(dataUrl => {
                    if (typeof dataUrl === 'string' && dataUrl.startsWith('data:image/')) {
                        done({ok:true, src:target.src, dataUrl});
                    } else {
                        done({ok:false, msg:String(dataUrl || 'imgToDataUrl failed')});
                    }
                }).catch(err => done({ok:false, msg:'imgToDataUrl exception: ' + err}));
            } catch (e) {
                done({ok:false, msg:'script error: ' + e});
            }
        """, preferred_src or '')

        if not result or not result.get('ok'):
            return f"DOM exact result: {(result or {}).get('msg', 'dom extract failed')}"

        data_url = result.get('dataUrl') or ''
        if not data_url.startswith('data:image/'):
            return "DOM exact result: invalid image data"

        import base64
        _, payload = data_url.split(',', 1)
        with open(target_path, 'wb') as f:
            f.write(base64.b64decode(payload))
        return f"DOM exact result: saved exact result from DOM src={result.get('src','')}"
    except Exception as e:
        return f"DOM exact result: dom extract error: {e}"


def prepare_image_for_gemini(image_path):
    """Tạo một bản upload tạm đã được crop về 16:9 trước khi đưa lên Gemini.
    - Ảnh cao hơn 16:9: cắt trên và dưới, giữ nguyên chiều ngang.
    - Ảnh rộng hơn 16:9: cắt 2 bên để vẫn về đúng 16:9.
    Trả về: (upload_path, is_temp, note)
    """
    try:
        target_ratio = TARGET_ASPECT_W / TARGET_ASPECT_H
        with Image.open(image_path) as img:
            width, height = img.size
            if width <= 0 or height <= 0:
                return image_path, False, "Ảnh đầu vào không hợp lệ"
            current_ratio = width / height
            if abs(current_ratio - target_ratio) <= ASPECT_EPSILON:
                return image_path, False, f"Ảnh đã gần 16:9 ({width}x{height})"

            if current_ratio < target_ratio:
                new_height = max(1, int(round(width / target_ratio)))
                new_height = min(new_height, height)
                top = max(0, (height - new_height) // 2)
                bottom = min(height, top + new_height)
                left = 0
                right = width
                crop_note = f"Crop trên/dưới: {width}x{height} -> {width}x{bottom - top}"
            else:
                new_width = max(1, int(round(height * target_ratio)))
                new_width = min(new_width, width)
                left = max(0, (width - new_width) // 2)
                right = min(width, left + new_width)
                top = 0
                bottom = height
                crop_note = f"Crop hai bên: {width}x{height} -> {right - left}x{height}"

            cropped = img.crop((left, top, right, bottom))
            upload_dir = os.path.join(DEBUG_DIR, "prepared_uploads")
            os.makedirs(upload_dir, exist_ok=True)
            base_name = os.path.splitext(os.path.basename(image_path))[0]
            temp_path = os.path.join(upload_dir, f"{base_name}__upload_16x9.png")
            cropped.save(temp_path, format="PNG")
            return temp_path, True, crop_note
    except Exception as e:
        return image_path, False, f"Không crop được 16:9, dùng ảnh gốc: {e}"


def _capture_saved_message_ok(msg):
    low = str(msg or '').lower()
    return (
        'saved exact result from dom' in low
        or 'saved from data url' in low
        or 'saved from remote url' in low
        or 'saved image bytes' in low
        or ('browser element screenshot:' in low and 'saved' in low)
        or ('browser tab capture:' in low and 'saved' in low)
        or ('screenshot fallback' in low and 'saved' in low)
        or ('dom exact result:' in low and 'saved' in low)
    )


def save_result_from_visible_screenshot(target_path):
    """Fallback cuối: chụp màn hình phần kết quả nhìn thấy và crop theo box lớn nhất.
    Dùng khi blob/data/DOM đều không lấy ra được ảnh.
    """
    try:
        meta = driver.execute_script(r"""
            function looksBad(src){
                const s = (src || '').toLowerCase();
                if (!s) return false;
                return (
                    s.includes('googleusercontent.com/ogw/') ||
                    s.includes('lh3.google.com/u/0/ogw/') ||
                    s.includes('admin.googleusercontent.com/') ||
                    s.includes('logo-scs') ||
                    s.includes('favicon') ||
                    s.includes('avatar') ||
                    s.includes('profile')
                );
            }
            const items = [];
            document.querySelectorAll('img, canvas').forEach(el => {
                try {
                    const r = el.getBoundingClientRect();
                    const cls = (el.className || '').toString().toLowerCase();
                    const testid = (el.getAttribute && (el.getAttribute('data-test-id') || '').toLowerCase()) || '';
                    const inUploader = !!el.closest('uploader-file-preview, uploader-file-preview-container, .file-preview-container, [data-test-id=\'image-preview\']')
                        || testid === 'uploaded-img' || cls.includes('preview-image');
                    if (inUploader) return;
                    if (r.width < 180 || r.height < 180) return;
                    if (cls.includes('enterprise-logo') || cls.includes('user-icon')) return;
                    let src = '';
                    if (el.tagName === 'IMG') {
                        src = el.currentSrc || el.src || '';
                        if (looksBad(src)) return;
                    }
                    items.push({
                        x: Math.max(0, r.left),
                        y: Math.max(0, r.top),
                        w: Math.round(r.width),
                        h: Math.round(r.height),
                        area: Math.round(r.width * r.height),
                        dpr: window.devicePixelRatio || 1,
                        vw: window.innerWidth || 0,
                        vh: window.innerHeight || 0,
                        tag: el.tagName,
                        src: src
                    });
                } catch (e) {}
            });
            items.sort((a,b) => (b.area||0) - (a.area||0));
            return items.length ? items[0] : null;
        """)
        if not meta:
            return 'screenshot fallback: no visible result candidate'
        import base64
        from PIL import Image
        shot = Image.open(BytesIO(base64.b64decode(driver.get_screenshot_as_base64())))
        dpr = float(meta.get('dpr') or 1.0)
        left = max(0, int(round(float(meta.get('x') or 0) * dpr)))
        top = max(0, int(round(float(meta.get('y') or 0) * dpr)))
        right = min(shot.width, left + max(1, int(round(float(meta.get('w') or 0) * dpr))))
        bottom = min(shot.height, top + max(1, int(round(float(meta.get('h') or 0) * dpr))))
        if right <= left or bottom <= top:
            return f"screenshot fallback: invalid crop box {left},{top},{right},{bottom}"
        cropped = shot.crop((left, top, right, bottom))
        cropped.save(target_path)
        return f"screenshot fallback: saved visible result {cropped.width}x{cropped.height}"
    except Exception as e:
        return f"screenshot fallback error: {e}"


def add_logo(image_path):
    try:
        if not logo_path:
            print("🖼 Bỏ qua chèn logo: không cấu hình logo")
            return
        base = Image.open(image_path).convert("RGBA")
        logo = Image.open(logo_path).convert("RGBA")
        base_width, base_height = base.size
        new_logo_width = max(36, int(base_width * 0.085))
        ratio = new_logo_width / max(1, logo.width)
        new_logo_height = max(1, int(logo.height * ratio))
        logo = logo.resize((new_logo_width, new_logo_height), Image.LANCZOS)
        pos_x = max(0, base_width - logo.width - LOGO_RIGHT_MARGIN)
        pos_y = max(0, base_height - logo.height - LOGO_BOTTOM_MARGIN)
        base.alpha_composite(logo, (pos_x, pos_y))
        base.convert("RGB").save(image_path)
        print("🖼 Đã chèn logo")
    except Exception as e:
        print("⚠ Không chèn được logo:", e)


def _read_png_chunks(png_bytes):
    """Đọc chunk PNG để chèn padding hợp lệ trước IEND."""
    if not png_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
        return None
    chunks = []
    pos = 8
    total = len(png_bytes)
    while pos + 8 <= total:
        length = int.from_bytes(png_bytes[pos:pos + 4], 'big')
        ctype = png_bytes[pos + 4:pos + 8]
        data_start = pos + 8
        data_end = data_start + length
        crc_end = data_end + 4
        if crc_end > total:
            return None
        chunks.append((ctype, png_bytes[pos:crc_end]))
        pos = crc_end
        if ctype == b'IEND':
            break
    return chunks


def _add_png_pad_chunk(png_bytes, extra_payload_len):
    """Chèn ancillary chunk npAD trước IEND để tăng dung lượng nhưng vẫn là PNG hợp lệ."""
    if extra_payload_len <= 0:
        return png_bytes
    chunks = _read_png_chunks(png_bytes)
    if not chunks:
        return png_bytes + (b' ' * extra_payload_len)
    out = bytearray(b'\x89PNG\r\n\x1a\n')
    inserted = False
    pad_type = b'npAD'  # chữ thường đầu tiên => ancillary chunk, decoder PNG sẽ bỏ qua an toàn
    pad_data = b'P' * int(extra_payload_len)
    pad_chunk = bytearray()
    pad_chunk.extend(len(pad_data).to_bytes(4, 'big'))
    pad_chunk.extend(pad_type)
    pad_chunk.extend(pad_data)
    crc = zlib.crc32(pad_type)
    crc = zlib.crc32(pad_data, crc) & 0xffffffff
    pad_chunk.extend(crc.to_bytes(4, 'big'))
    for ctype, raw_chunk in chunks:
        if ctype == b'IEND' and not inserted:
            out.extend(pad_chunk)
            inserted = True
        out.extend(raw_chunk)
    if not inserted:
        out.extend(pad_chunk)
    return bytes(out)


def ensure_png_over_min_size(image_path, min_mb=None, margin_kb=80):
    """v45: đảm bảo ảnh cuối cùng là PNG hợp lệ và lớn hơn min_mb.

    Khác bản cũ: không ép đúng 2.00MB nữa, mà ép LỚN HƠN 2MB.
    Mặc định min_mb lấy từ FINAL_MIN_IMAGE_MB = 2.05 để an toàn vượt ngưỡng 2MB.
    """
    try:
        min_mb = FINAL_MIN_IMAGE_MB if min_mb is None else float(min_mb)
        min_bytes = int(min_mb * 1024 * 1024)
        target_bytes = min_bytes + int(max(0, margin_kb) * 1024)

        with Image.open(image_path) as src_img:
            img = src_img.convert('RGB')
            bio = BytesIO()
            # compress_level thấp giúp ảnh thường lớn hơn và tiết kiệm CPU hơn optimize cao.
            img.save(bio, format='PNG', compress_level=1, optimize=False)
            data = bio.getvalue()

        if len(data) <= min_bytes:
            # Cộng thêm 12 byte header chunk, nên payload phải dư thêm một chút.
            extra_payload = max(1, target_bytes - len(data) - 12)
            data = _add_png_pad_chunk(data, extra_payload)

        with open(image_path, 'wb') as f:
            f.write(data)

        # Verify lại để chắc chắn padding không làm hỏng ảnh.
        try:
            with Image.open(image_path) as verify_img:
                verify_img.verify()
        except Exception as verify_error:
            raise RuntimeError(f'PNG sau khi ép dung lượng không hợp lệ: {verify_error}')

        final_size = os.path.getsize(image_path)
        final_mb = final_size / (1024 * 1024)
        if final_size <= 2 * 1024 * 1024:
            raise RuntimeError(f'Ảnh cuối vẫn chưa >2MB: {final_mb:.3f}MB')
        print(f'📦 Đã đảm bảo ảnh cuối >2MB: {final_mb:.2f}MB (min yêu cầu {min_mb:.2f}MB)')
        return True
    except Exception as e:
        print('⚠ Không ép được ảnh cuối >2MB:', e)
        return False


# Giữ tên hàm cũ để dashboard/worker cũ nếu gọi vẫn không lỗi.
def force_png_to_exact_size(image_path, target_mb=2.0):
    min_mb = max(float(target_mb or 2.0) + 0.05, FINAL_MIN_IMAGE_MB)
    return ensure_png_over_min_size(image_path, min_mb=min_mb)

    try:
        import io
        target_bytes = int(target_mb * 1024 * 1024)
        img = Image.open(image_path)
        if img.mode not in ('RGB', 'RGBA', 'L'):
            img = img.convert('RGB')

        def encode_candidate(compress_level=6, quant_colors=None, scale=1.0):
            working = img
            if scale != 1.0:
                new_w = max(1, int(img.width * scale))
                new_h = max(1, int(img.height * scale))
                working = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
            if quant_colors is not None:
                try:
                    working = working.convert('RGB').quantize(colors=quant_colors, method=Image.Quantize.MEDIANCUT)
                except Exception:
                    working = working.convert('P', palette=Image.Palette.ADAPTIVE, colors=quant_colors)
            bio = io.BytesIO()
            working.save(bio, format='PNG', compress_level=compress_level, optimize=False)
            return bio.getvalue()

        def add_png_pad_chunk(png_bytes, extra_payload_len):
            if not png_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
                return png_bytes
            sig = png_bytes[:8]
            data = png_bytes[8:]
            out = bytearray(sig)
            i = 0
            inserted = False
            while i + 8 <= len(data):
                length = int.from_bytes(data[i:i+4], 'big')
                ctype = data[i+4:i+8]
                chunk_total = 12 + length
                chunk = data[i:i+chunk_total]
                if ctype == b'IEND' and not inserted:
                    pad_data = b'P' * max(0, extra_payload_len)
                    pad_type = b'npAD'
                    out.extend(len(pad_data).to_bytes(4, 'big'))
                    out.extend(pad_type)
                    out.extend(pad_data)
                    crc = zlib.crc32(pad_type)
                    crc = zlib.crc32(pad_data, crc) & 0xffffffff
                    out.extend(crc.to_bytes(4, 'big'))
                    inserted = True
                out.extend(chunk)
                i += chunk_total
            return bytes(out)

        candidates = []
        for scale in (1.0, 0.98, 0.96, 0.94, 0.92, 0.90, 0.88, 0.86, 0.84):
            for quant in (None, 256, 192, 160, 128, 96, 64):
                for level in range(0, 10):
                    try:
                        data = encode_candidate(compress_level=level, quant_colors=quant, scale=scale)
                        candidates.append((len(data), data))
                    except Exception:
                        pass

        if not candidates:
            print('⚠ Không ép được ảnh lên 2MB: không tạo được candidate PNG')
            return

        under = [(size, data) for size, data in candidates if size <= target_bytes - 12]
        if under:
            size, data = max(under, key=lambda x: x[0])
            padded = add_png_pad_chunk(data, target_bytes - size - 12)
        else:
            under2 = [(size, data) for size, data in candidates if size <= target_bytes]
            if under2:
                size, data = max(under2, key=lambda x: x[0])
                padded = data + (b' ' * (target_bytes - size))
            else:
                size, data = min(candidates, key=lambda x: x[0])
                padded = data

        with open(image_path, 'wb') as f:
            f.write(padded)
        final_size = os.path.getsize(image_path)
        print(f'📦 Đã ép dung lượng ảnh: {final_size / (1024 * 1024):.2f}MB')
    except Exception as e:
        print('⚠ Không ép được ảnh lên 2MB:', e)


def open_new_chat():
    global driver
    print("🌐 Mở chat mới Gemini...")
    driver.get("https://gemini.google.com/app/new")
    wait_for_page_ready(driver)
    click_google_cookie_consent_if_present(timeout=6, relabel='open_new_chat cookie')
    close_possible_popups()
    assert_gemini_logged_in_or_raise(driver, 'mở chat mới')
    print("✅ Trang đã mở, đang dò editor...")
    wait_editor_ready(timeout=45)
    print("✅ Editor sẵn sàng")
    try:
        print(f"🎛 Model mục tiêu: {_friendly_target_model_name(TARGET_MODEL)}")
    except Exception:
        pass
    try:
        prepare_target_create_image_mode(timeout=float(os.environ.get('GEMINI_PREPARE_PRO_IMAGE_TIMEOUT', '24') or 24), target_model=TARGET_MODEL)
    except Exception as e:
        print(f"⚠ Không chuẩn bị được model + Create image: {e}")
        raise


def classify_process_exception(exc):
    """Phân loại lỗi để retry đúng cách và không khóa nhầm account.

    Trả về: (error_type, retryable, account_exhaust)
    - account_exhaust=True chỉ dành cho lỗi có khả năng do account/session/quota.
    - capture/validate/upload lỗi nhẹ sẽ retry job và không loại account.
    """
    name = type(exc).__name__
    msg = str(exc or '')
    low = (name + ' ' + msg).lower()
    if any(x in low for x in ('geminipolicyrefusal', 'image editing request denied', 'editing request denied', 'request denied', 'real person', 'depict a real person', 'từ chối', 'policy refusal', 'bị từ chối')):
        return 'gemini_refusal', False, True
    if 'quota' in low or 'hết lượt' in low or 'limit reached' in low:
        return 'quota', False, True
    if any(x in low for x in ('accounts.google.com', 'chưa đăng nhập', 'login', 'sign in', 'xác minh', 'verify it')):
        return 'session_fail', False, True
    if any(x in low for x in ('không tìm thấy input[type=file]', 'file input', 'upload', 'tải tệp', 'dom-only', 'prodromonlyunavailable')):
        return 'upload_fail', True, False
    if any(x in low for x in ('không lấy được ảnh', 'blob fetch failed', 'dom exact result', 'screenshot fallback', 'browser element screenshot', 'browser tab capture', 'remote url http 403', '403 client error', 'googleusercontent', 'capture', 'candidate', 'result image')):
        return 'capture_fail', True, False
    if any(x in low for x in ('ảnh cuối', '16:9', 'quá nhỏ', 'validate', '2mb', '>2mb', 'png sau khi ép')):
        return 'validate_fail', True, False
    if any(x in low for x in ('timeout', 'timed out', 'staleelement', 'elementclick', 'not interactable', 'chrome not reachable')):
        return 'transient_ui_fail', True, False
    return name or 'generic_fail', True, False


def process_image(image_path, attempt=1, max_attempts=None):
    global fail_streak, success_count, fail_count, failed_files, last_error_reason
    max_attempts = max_attempts or (MAX_JOB_RETRIES + 1)
    print(f"\n🔄 Đang xử lý: {image_path} | attempt {attempt}/{max_attempts}")
    emit_event("job_start", path=image_path, account=current_account + 1, mode=account_modes[current_account] if current_account < len(account_modes) else "", attempt=attempt, max_attempts=max_attempts)
    update_job_manifest(image_path, "running", account=current_account + 1, started_at=_manifest_now(), attempt=attempt, max_attempts=max_attempts)
    last_error_reason = None
    upload_path = image_path
    is_temp_upload = False
    try:
        print(f"🫥 HEADLESS STEP 1/6 • mở Gemini ẩn • A{current_account + 1}")
        dismiss_unexpected_dialogs('trước open_new_chat')
        open_new_chat()
        dismiss_unexpected_dialogs('sau open_new_chat')
        upload_path, is_temp_upload, prep_note = prepare_image_for_gemini(image_path)
        print(f"🪄 Chuẩn hóa ảnh trước upload: {prep_note}")
        print(f"🫥 HEADLESS STEP 2/6 • upload ảnh • {os.path.basename(upload_path)}")
        with upload_serial_lock(os.path.basename(upload_path)):
            dismiss_unexpected_dialogs('trước upload')
            upload_file(upload_path, account_modes[current_account])
            dismiss_unexpected_dialogs('sau upload')
            if LAST_UPLOAD_CONFIRMED_PATH != os.path.abspath(upload_path):
                raise TimeoutException("Refusal Account Skip + Upload Menu Fix: chưa xác nhận đúng file upload, không được bấm vẽ")
            if not wait_after_upload(upload_path, timeout=float(os.environ.get("GEMINI_PRE_SEND_UPLOAD_CONFIRM_TIMEOUT", "8") or 8), require_new=False):
                raise TimeoutException("Upload preview không còn tồn tại trước khi bấm Send, hủy job để retry")
            if not wait_for_upload_settle(upload_path, timeout=float(os.environ.get("GEMINI_PRE_SEND_UPLOAD_SETTLE_TIMEOUT", "2.5") or 2.5)):
                raise TimeoutException("Upload attachment chưa ổn định ngay trước khi bấm Send")
        print("🫥 HEADLESS STEP 3/6 • nhập prompt")
        print("✍️ Bắt đầu nhập prompt...")
        dismiss_unexpected_dialogs('trước nhập prompt')
        _job_prompt = _myinggo_job_prompt(image_path)
        write_prompt_confirmed(_job_prompt)
        dismiss_unexpected_dialogs('sau nhập prompt')
        if not wait_after_upload(upload_path, timeout=float(os.environ.get("GEMINI_PRE_SEND_UPLOAD_CONFIRM_TIMEOUT", "8") or 8), require_new=False):
            raise TimeoutException("Upload preview biến mất sau khi nhập prompt, hủy job để retry")
        if not wait_for_upload_settle(upload_path, timeout=float(os.environ.get("GEMINI_PRE_SEND_UPLOAD_SETTLE_TIMEOUT", "2.5") or 2.5)):
            raise TimeoutException("Upload attachment chưa ổn định sau khi nhập prompt")
        baseline_urls = collect_baseline_result_urls()
        quota_before_send = _image_quota_snapshot()
        baseline_response_count = int(quota_before_send.get('responseCount') or 0)
        baseline_assistant_count = baseline_response_count  # tương thích tham số cũ
        quota_before_signatures = list(quota_before_send.get('signatures') or [])
        print(f"🧭 Baseline trước Send: {len(baseline_urls)} URL/preview/UI • {baseline_response_count} response Gemini cũ")
        if quota_before_signatures:
            print(f"🧪 Phát hiện {len(quota_before_signatures)} dấu quota CŨ trước Send → sẽ bỏ qua, không được kết luận hết quota")
        print("📨 v13.54: quota chỉ hợp lệ nếu xuất hiện RESPONSE GEMINI MỚI sau Send; quota cũ/render lại sẽ bị bỏ qua")
        print("🫥 HEADLESS STEP 4/6 • gửi prompt")
        dismiss_unexpected_dialogs('trước send')
        click_send_and_confirm(_job_prompt, timeout=16)
        dismiss_unexpected_dialogs('sau send')
        print("🚀 Đã gửi prompt THẬT • bắt đầu chờ Gemini trả ảnh/quota")
        print("🫥 HEADLESS STEP 5/6 • chờ ảnh Gemini mới / Fresh Response Gate")
        print("⏳ Đợi Gemini render...")
        result_url, state = wait_for_result_image(
            timeout=240,
            old_urls=baseline_urls,
            quota_baseline_signatures=quota_before_signatures,
            quota_baseline_assistant_count=baseline_assistant_count,
            quota_baseline_response_count=baseline_response_count,
        )
        print(f"🖼 Số candidate image URLs: {len(state.get('allUrls', []))}")
        debug_urls = [u for u in (state.get("allUrls", []) or []) if not looks_like_avatar_or_ui_url(u)]
        if not debug_urls:
            debug_urls = (state.get("allUrls", []) or [])[:8]
        for u in debug_urls[:8]:
            print("   -", u)
        print("📥 URL ảnh chọn được:", result_url)
        save_msg = None
        capture_ok = False
        if result_url:
            try:
                save_msg = save_result_image(result_url, image_path)
            except Exception as direct_e:
                # CDN 403/HTTP lỗi không được phép nhảy ra ngoài và làm job vẽ lại trước khi thử Chrome capture.
                save_msg = f"remote URL capture exception: {type(direct_e).__name__}: {direct_e}"
            print("🧩 Kết quả tải ảnh:", save_msg)
            capture_ok = _capture_saved_message_ok(save_msg)
        if (not capture_ok) or (result_url is None) or looks_like_avatar_or_ui_url(result_url) or str(save_msg).startswith("blob fetch failed"):
            print(f"⚠ URL ảnh không tải trực tiếp được; dùng {REMOTE_CAPTURE_FIX_VERSION} để capture ngay từ Chrome...")
            last_capture_msg = save_msg

            # FIX 403 QUAN TRỌNG: chụp đúng IMG/CANVAS đang render trong Chrome trước.
            element_msg = save_result_from_rendered_element(image_path, preferred_src=result_url)
            print("🧩 Browser element:", element_msg)
            last_capture_msg = element_msg
            capture_ok = _capture_saved_message_ok(element_msg)

            for capture_attempt in range(1, CAPTURE_RETRY_LIMIT + 1):
                if capture_ok:
                    break
                refreshed_url = None
                if capture_attempt > 1:
                    time.sleep(1.5)
                    try:
                        refreshed_state = collect_result_state()
                        refreshed_url = pick_best_result_url(refreshed_state, old_urls=baseline_urls)
                    except Exception:
                        refreshed_url = None
                    if refreshed_url and refreshed_url != result_url:
                        retry_msg = save_result_image(refreshed_url, image_path)
                        print(f"🧩 Retry URL attempt {capture_attempt}: {retry_msg}")
                        last_capture_msg = retry_msg
                        if _capture_saved_message_ok(retry_msg):
                            capture_ok = True
                            break

                # Element screenshot không bị CORS; thử lại sau khi DOM ổn định thêm.
                element_msg = save_result_from_rendered_element(image_path, preferred_src=refreshed_url or result_url)
                print(f"🧩 Browser element attempt {capture_attempt}: {element_msg}")
                last_capture_msg = element_msg
                if _capture_saved_message_ok(element_msg):
                    capture_ok = True
                    break

                # DOM canvas vẫn giữ làm phương án phụ cho blob/canvas same-origin.
                dom_msg = save_exact_result_from_dom(image_path, preferred_src=refreshed_url or result_url)
                print(f"🧩 DOM attempt {capture_attempt}: {dom_msg}")
                last_capture_msg = dom_msg
                if _capture_saved_message_ok(dom_msg):
                    capture_ok = True
                    break

            # Nếu img đang render nhưng element screenshot không lấy được, mở URL bằng chính Chrome/session.
            if not capture_ok and result_url:
                tab_msg = save_result_via_browser_tab(result_url, image_path)
                print("🧩 Browser tab:", tab_msg)
                last_capture_msg = tab_msg
                capture_ok = _capture_saved_message_ok(tab_msg)

            if not capture_ok:
                shot_msg = save_result_from_visible_screenshot(image_path)
                print("🧩", shot_msg)
                last_capture_msg = shot_msg
                capture_ok = _capture_saved_message_ok(shot_msg)
            if not capture_ok and EXTRA_CAPTURE_WAIT_SECONDS > 0:
                print(f"🔁 Capture chưa thấy ảnh thật, chờ thêm {EXTRA_CAPTURE_WAIT_SECONDS} giây rồi thử lấy lại một lần...")
                try:
                    extra_url, extra_state = wait_for_result_image(
                        timeout=EXTRA_CAPTURE_WAIT_SECONDS,
                        old_urls=baseline_urls,
                        quota_baseline_signatures=quota_before_signatures,
                        quota_baseline_assistant_count=baseline_assistant_count,
                        quota_baseline_response_count=baseline_response_count,
                    )
                    if extra_url:
                        extra_msg = save_result_image(extra_url, image_path)
                        print("🧩 Extra capture URL:", extra_msg)
                        capture_ok = _capture_saved_message_ok(extra_msg)
                        last_capture_msg = extra_msg
                    if not capture_ok:
                        extra_element_msg = save_result_from_rendered_element(image_path, preferred_src=extra_url if 'extra_url' in locals() else result_url)
                        print("🧩 Extra Browser element:", extra_element_msg)
                        capture_ok = _capture_saved_message_ok(extra_element_msg)
                        last_capture_msg = extra_element_msg
                    if not capture_ok:
                        extra_dom_msg = save_exact_result_from_dom(image_path, preferred_src=extra_url if 'extra_url' in locals() else result_url)
                        print("🧩 Extra DOM:", extra_dom_msg)
                        capture_ok = _capture_saved_message_ok(extra_dom_msg)
                        last_capture_msg = extra_dom_msg
                except Exception as extra_e:
                    print(f"⚠ Extra capture lỗi: {extra_e}")
            elif not capture_ok:
                print("⚡ Fast mode: capture Chrome vẫn không thấy ảnh thật; chỉ lúc này mới retry job")
            if not capture_ok:
                raise Exception(last_capture_msg or 'Không lấy được ảnh kết quả sau nhiều lần thử')
        print("🫥 HEADLESS STEP 6/6 • chuẩn hóa + logo + validate")
        normalize_final_image_geometry(image_path)
        add_logo(image_path)
        if not ensure_png_over_min_size(image_path, min_mb=FINAL_MIN_IMAGE_MB):
            raise Exception('Không đảm bảo được ảnh cuối cùng >2MB')
        final_info = validate_final_image_file(image_path)
        print(f"✅ FINAL VALIDATE OK: {final_info.get('width')}x{final_info.get('height')} • {final_info.get('size_mb')}MB • sha256={str(final_info.get('sha256',''))[:12]}")
        emit_event("job_done", path=image_path, account=current_account + 1, final=final_info)
        update_job_manifest(image_path, "done", account=current_account + 1, final=final_info, finished_at=_manifest_now())
        print("✅ Đã ghi đè ảnh + chèn logo thành công • FINAL OK >2MB")
        success_count += 1
        fail_streak = 0
        last_error_reason = None
        return True
    except ImageQuotaReached as e:
        print(f"⚠ {e} → chuyển account")
        emit_event("quota", path=image_path, account=current_account + 1, message=str(e))
        update_job_manifest(image_path, "queued", account=current_account + 1, last_error="quota", message=str(e))
        last_error_reason = "quota"
        fail_streak = (PRO_SWITCH_AFTER_ERRORS if account_modes[current_account] == "pro" else REGULAR_SWITCH_AFTER_ERRORS)
        return False
    except ProDomOnlyUnavailable as e:
        print(f"⚠ {e}")
        emit_event("job_error", path=image_path, account=current_account + 1, error_type="pro_dom_unavailable", message=str(e))
        update_job_manifest(image_path, "queued", account=current_account + 1, last_error="pro_dom_unavailable", message=str(e))
        last_error_reason = "pro_dom_unavailable"
        return False
    except Exception as e:
        err_type, retryable, account_exhaust = classify_process_exception(e)
        print(f"💥 HEADLESS-GEMINI ERROR • {type(e).__name__}: {e} | type={err_type} | retryable={retryable} | account_exhaust={account_exhaust}")
        try:
            save_debug_artifacts(f"process_image_{err_type}")
        except Exception:
            pass
        if retryable and int(attempt) < int(max_attempts):
            emit_event("job_retry", path=image_path, account=current_account + 1, error_type=err_type, message=str(e), attempt=attempt, max_attempts=max_attempts, account_exhaust=False)
            update_job_manifest(image_path, "queued", account=current_account + 1, last_error=err_type, message=str(e), retry_attempt=attempt, max_attempts=max_attempts)
            last_error_reason = "retry"
            print(f"🔁 Retry job do lỗi nhẹ: {err_type} ({attempt}/{max_attempts})")
            return False
        emit_event("job_error", path=image_path, account=current_account + 1, error_type=err_type, message=str(e), attempt=attempt, max_attempts=max_attempts, account_exhaust=bool(account_exhaust), retryable=False)
        update_job_manifest(image_path, "error", account=current_account + 1, last_error=err_type, message=str(e), account_exhaust=bool(account_exhaust))
        if account_exhaust:
            if err_type == "gemini_refusal":
                fail_streak = (PRO_SWITCH_AFTER_ERRORS if account_modes[current_account] == "pro" else REGULAR_SWITCH_AFTER_ERRORS)
                print("🚫 Gemini từ chối trên account này → bỏ qua account này, thử account khác")
            else:
                fail_streak += 1
            last_error_reason = "account_error"
        else:
            # Lỗi capture/validate/upload của một ảnh không được tính là lỗi account liên tiếp.
            fail_streak = 0
            last_error_reason = "job_error"
        fail_count += 1
        failed_files.append(image_path)
        print(f"⚠ Lỗi liên tiếp account: {fail_streak}")
        return False


def relaunch_current_account_non_headless():
    global driver, wait, current_runtime_headless
    profile_path = profiles[current_account]
    print("🔁 Nhánh PRO DOM-only không khả dụng trên account này → mở lại cùng account ở chế độ classic")
    try:
        driver.quit()
    except Exception:
        pass
    driver, wait = ensure_logged_in(profile_path, current_account + 1, headless=False)
    current_runtime_headless = False


def switch_account():
    global driver, wait, current_account, fail_streak
    print("\n⚠ Quá nhiều lỗi → đổi tài khoản")
    try:
        driver.quit()
    except Exception:
        pass
    current_account += 1
    if current_account >= len(profiles):
        print("❌ Hết account cục bộ trong worker hiện tại")
        raise SystemExit(1)
    print("🔄 Chuyển sang account", current_account + 1)
    emit_event("account_switch", account=current_account + 1, mode=account_modes[current_account])
    print("🧠 Loại account:", "PRO" if account_modes[current_account] == "pro" else "THƯỜNG")
    headless = HEADLESS_FOR_PRO if account_modes[current_account] == "pro" else HEADLESS_FOR_REGULAR
    profile_path = profiles[current_account]
    globals()["driver"], globals()["wait"] = ensure_logged_in(profile_path, current_account + 1, headless=headless)
    globals()["current_runtime_headless"] = headless
    fail_streak = 0


def iter_candidate_images(root):
    thumb_re = re.compile(r"^thumbnail-original-(\d+)-final\.png$", re.IGNORECASE)
    for dirpath, _, filenames in os.walk(root):
        for filename in filenames:
            if thumb_re.match(filename):
                yield os.path.join(dirpath, filename)


ensure_browser_files()

print("\n🔐 KIỂM TRA GOOGLE ACCOUNT\n")
for i, profile in enumerate(profiles):
    if profile_has_local_data(profile):
        print(f"✅ Profile account {i+1} đã có dữ liệu Chrome")
    else:
        launch_normal_chrome_for_login(profile, i + 1)

print("\n🧠 PHÂN LOẠI ACCOUNT\n")
for i, profile in enumerate(profiles):
    if i < len(PROVIDED_ACCOUNT_MODES) and PROVIDED_ACCOUNT_MODES[i] in ("regular", "pro"):
        mode = PROVIDED_ACCOUNT_MODES[i]
        print(f"⚡ Account {i+1}: dùng mode từ dashboard/CLI = {mode.upper()} (bỏ detect để tăng tốc)")
        write_mode_cache(profile, mode)
    else:
        mode = detect_account_mode(profile, i + 1)
    account_modes.append(mode)

print("\n✅ Tất cả profile đã được chuẩn bị\n")
emit_event("worker_ready", root=root_folder, logo=logo_path, accounts=len(profiles), manifest=JOB_MANIFEST_PATH, final_min_mb=FINAL_MIN_IMAGE_MB, account_modes=account_modes)

current_account = 0
profile_path = profiles[current_account]
print("🔑 Đang dùng account:", current_account + 1)
print("Profile:", profile_path)
print("🧠 Loại account:", "PRO" if account_modes[current_account] == "pro" else "THƯỜNG")
headless = HEADLESS_FOR_PRO if account_modes[current_account] == "pro" else HEADLESS_FOR_REGULAR
_ready_fast_start = str(os.environ.get("GEMINI_READY_PROFILE_FAST_START", "0")).strip().lower() in ("1", "true", "yes", "on")
if _ready_fast_start:
    # V23 Web READY pool: this profile was already verified in Kho tài khoản. The first job's
    # open_new_chat() still performs assert_gemini_logged_in_or_raise, so stale sessions are
    # rejected safely without paying for TWO Gemini navigations before the first thumbnail.
    _proxy_value = _proxy_for_local_account_index(current_account)
    print("⚡ V23 READY FAST START • bỏ lượt mở Gemini kiểm tra trùng • xác thực ngay ở STEP 1 của job đầu")
    driver, wait = start_selenium(profile_path, headless=headless, proxy_value=_proxy_value)
else:
    driver, wait = ensure_logged_in(profile_path, current_account + 1, headless=headless)
current_runtime_headless = headless

seen = set()
for image_path in iter_candidate_images(root_folder):
    norm = os.path.normpath(image_path)
    if norm in seen:
        continue
    seen.add(norm)

    if manifest_status(image_path) == "done":
        print(f"⏭ Resume manifest: bỏ qua ảnh đã DONE: {image_path}")
        emit_event("job_resume_skip", path=image_path, reason="manifest_done")
        skipped_count += 1
        continue

    size_mb = os.path.getsize(image_path) / (1024 * 1024)
    if size_mb > INPUT_SKIP_OVER_MB:
        print(f"⏭ Bỏ qua (>{INPUT_SKIP_OVER_MB:.1f}MB): {image_path}")
        emit_event("job_skipped", path=image_path, reason="input_size", size_mb=round(size_mb, 4), limit_mb=INPUT_SKIP_OVER_MB)
        update_job_manifest(image_path, "skipped", reason="input_size", size_mb=round(size_mb, 4), limit_mb=INPUT_SKIP_OVER_MB)
        skipped_count += 1
        continue

    print(f"🎨 Cần vẽ (<={INPUT_SKIP_OVER_MB:.1f}MB): {image_path}")

    attempt = 1
    max_attempts = MAX_JOB_RETRIES + 1
    while True:
        ok = process_image(image_path, attempt=attempt, max_attempts=max_attempts)
        threshold = PRO_SWITCH_AFTER_ERRORS if account_modes[current_account] == "pro" else REGULAR_SWITCH_AFTER_ERRORS
        if ok:
            break

        if last_error_reason == "retry" and attempt < max_attempts:
            attempt += 1
            print(f"🔁 Thử lại cùng job/cùng account lần {attempt}/{max_attempts}...")
            continue

        if last_error_reason == "pro_dom_unavailable" and account_modes[current_account] == "pro" and current_runtime_headless:
            relaunch_current_account_non_headless()
            print("🔁 Thử lại ảnh với cùng account PRO ở chế độ classic...")
            continue

        if fail_streak >= threshold:
            prev_reason = last_error_reason
            switch_account()
            if prev_reason in ("quota", "account_error"):
                print("🔁 Thử lại ảnh với account mới...")
                attempt = 1
                continue
        break

print("\n==============================")
print("🎉 HOÀN TẤT TOÀN BỘ")
print(f"✅ Thành công: {success_count}")
print(f"❌ Thất bại: {fail_count}")
print(f"⏭ Bỏ qua: {skipped_count}")
if failed_files:
    print("\n📂 Danh sách lỗi:")
    for path in failed_files:
        print(path)
print("==============================")
emit_event("worker_summary", success=success_count, failed=fail_count, skipped=skipped_count, failed_files=failed_files)
save_job_manifest()
if has_interactive_stdin():
    try:
        input("\n👉 Nhấn Enter để đóng tool...")
    except EOFError:
        pass
