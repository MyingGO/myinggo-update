"""MyingGo • Xoá watermark "ngôi sao" Gemini ở góc dưới bên phải ảnh tạo từ tài khoản web.

Đo trên ảnh thật 1281x721: ngôi sao nằm cách mép phải/dưới ~112px (tâm), bán kính mũi nhọn ~23px,
trắng mờ (alpha ~0.3-0.6) với 4 mũi nhọn, cạnh lõm. Vị trí/kích thước phụ thuộc cách chụp nên bộ dò tìm
tự do trong vùng góc (không đụng giữa ảnh), dùng matched-filter hình ngôi sao.

Xoá: (1) ước lượng nền bằng inpaint, (2) ước lượng độ trong suốt alpha của ngôi sao từ chính ảnh,
(3) đảo phép pha trộn  gốc = (ảnh - alpha*255) / (1 - alpha)  => khôi phục hoạ tiết nền thật bên dưới,
(4) inpaint nhẹ viền ngôi sao để xoá quầng. Không đủ chắc chắn là watermark => giữ nguyên ảnh.
"""
import os

try:
    import cv2
    import numpy as np
except Exception:  # thiếu thư viện => bỏ qua, không làm hỏng job
    cv2 = None
    np = None

STAR_P = 0.78                                   # độ "béo" của ngôi sao (astroid mở rộng)
OFF_MIN_PX, OFF_MAX_FRAC = 36, 0.30             # tâm cách mép: từ 36px đến 30% chiều cao
R_MIN_FRAC, R_MAX_FRAC = 0.013, 0.044           # bán kính mũi nhọn / chiều cao ảnh (thật: 0.015 ảnh gốc, 0.031 ảnh 1281x721)
OFF_PER_R = (3.8, 6.2)                          # tâm cách mép = ~4.9 x bán kính (96px hộp, lề 64px, mũi ~23px)
MIN_CONTRAST = 8.0
MIN_CHANNEL_RATIO = 0.35
MIN_STAR_RATIO = 0.55
MIN_SHAPE_CORR = 0.84
MIN_SHARPNESS = 0.16                            # độ sắc của viền / contrast (thật: 0.25-0.31, ảnh mờ: 0.10)
ALPHA_MIN, ALPHA_MAX = 0.14, 0.60               # alpha thật đo được ~0.29-0.31


def _star(h, w, cx, cy, radius, p=STAR_P):
    ys, xs = np.ogrid[:h, :w]
    dx = np.abs(xs - cx) / max(1e-6, radius)
    dy = np.abs(ys - cy) / max(1e-6, radius)
    return (dx ** p + dy ** p) <= 1.0


def _kernel(R, kind):
    n = int(R * 1.7) | 1
    c = n // 2
    if kind == "in":
        m = _star(n, n, c, c, R * 0.85)
    else:
        m = _star(n, n, c, c, R * 1.55) & ~_star(n, n, c, c, R * 1.2)
    k = m.astype(np.float32)
    return k / max(1.0, k.sum())


def _find(gray, h, w):
    """Matched-filter trong vùng góc dưới-phải. Trả về danh sách ứng viên (contrast, cx, cy, R)."""
    off_max = int(OFF_MAX_FRAC * h)
    x0, y0 = max(0, w - off_max - 40), max(0, h - off_max - 40)
    crop = gray[y0:, x0:]
    cands = []
    r_lo, r_hi = max(8, int(R_MIN_FRAC * h)), max(10, int(R_MAX_FRAC * h))
    for R in range(r_lo, r_hi + 1, 2):
        cmap = cv2.filter2D(crop, -1, _kernel(R, "in"), borderType=cv2.BORDER_REPLICATE) \
            - cv2.filter2D(crop, -1, _kernel(R, "ring"), borderType=cv2.BORDER_REPLICATE)
        # chỉ cho phép tâm nằm trong cửa sổ offset hợp lệ
        ys, xs = np.mgrid[:crop.shape[0], :crop.shape[1]]
        ox = w - (xs + x0)
        oy = h - (ys + y0)
        valid = (ox >= OFF_PER_R[0] * R) & (oy >= OFF_PER_R[0] * R) & (ox <= OFF_PER_R[1] * R) & (oy <= OFF_PER_R[1] * R) & (ox >= OFF_MIN_PX * 0.5) & (oy >= OFF_MIN_PX * 0.5)
        cmap = np.where(valid, cmap, -1e9)
        idx = int(np.argmax(cmap))
        yy, xx = divmod(idx, cmap.shape[1])
        cands.append((float(cmap[yy, xx]), float(xx + x0), float(yy + y0), float(R)))
    cands.sort(reverse=True)
    return cands[:6]


def _validate(bgr, gray, cx, cy, R):
    """Kiểm tra hình ngôi sao thật sự (sáng đều 3 kênh, đúng dạng 4 mũi nhọn, khớp mẫu alpha)."""
    h, w = gray.shape
    pad = int(R * 1.9)
    x0, x1 = int(max(0, cx - pad)), int(min(w, cx + pad + 1))
    y0, y1 = int(max(0, cy - pad)), int(min(h, cy + pad + 1))
    g = gray[y0:y1, x0:x1]
    c = bgr[y0:y1, x0:x1].astype(np.float32)
    hh, ww = g.shape
    lcx, lcy = cx - x0, cy - y0
    inner = _star(hh, ww, lcx, lcy, R * 0.85)
    ring = _star(hh, ww, lcx, lcy, R * 1.55) & ~_star(hh, ww, lcx, lcy, R * 1.2)
    box = (np.abs(np.arange(ww)[None, :] - lcx) <= R) & (np.abs(np.arange(hh)[:, None] - lcy) <= R)
    corners = box & ~_star(hh, ww, lcx, lcy, R * 1.15)
    if inner.sum() < 12 or ring.sum() < 12 or corners.sum() < 12:
        return None
    contrast = float(g[inner].mean() - g[ring].mean())
    lifts = [float(c[..., ch][inner].mean() - c[..., ch][ring].mean()) for ch in range(3)]
    ch_ratio = min(lifts) / max(1e-6, float(np.mean(lifts)))
    gap = float(g[inner].mean() - g[corners].mean())
    star_ratio = contrast / gap if gap > 1e-6 else 0.0
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.sqrt(gx * gx + gy * gy) / 8.0
    band = _star(hh, ww, lcx, lcy, R * 1.12) & ~_star(hh, ww, lcx, lcy, R * 0.88)
    sharp = float(mag[band].mean() / max(1e-6, contrast)) if band.sum() > 12 else 0.0
    return contrast, ch_ratio, star_ratio, sharp


def _estimate(bgr, cx, cy, R):
    """Ước lượng nền (inpaint) + alpha. Trả về (bg, alpha0, shape_corr)."""
    h, w = bgr.shape[:2]
    big = _star(h, w, cx, cy, R * 1.3).astype(np.uint8) * 255
    big = cv2.dilate(big, np.ones((3, 3), np.uint8), iterations=2)
    bg = cv2.inpaint(bgr, big, max(3, int(round(R * 0.15))), cv2.INPAINT_TELEA)
    den = 255.0 - bg.astype(np.float32)
    lift = bgr.astype(np.float32) - bg.astype(np.float32)
    core = _star(h, w, cx, cy, R * 0.55) & (den.min(axis=2) > 35)
    if core.sum() < 10:
        return bg, None, 0.0
    alpha_px = (lift / np.maximum(den, 1.0)).mean(axis=2)
    alpha0 = float(np.median(alpha_px[core]))
    if not (ALPHA_MIN <= alpha0 <= ALPHA_MAX):
        return bg, None, 0.0
    # độ khớp giữa phần "sáng thêm" và hình ngôi sao
    pad = int(R * 1.5)
    y0, y1, x0, x1 = int(max(0, cy - pad)), int(min(h, cy + pad + 1)), int(max(0, cx - pad)), int(min(w, cx + pad + 1))
    obs = lift.mean(axis=2)[y0:y1, x0:x1].ravel()
    shp = _star(h, w, cx, cy, R)[y0:y1, x0:x1].astype(np.float32).ravel()
    corr = float(np.corrcoef(obs, shp)[0, 1]) if obs.std() > 1e-6 and shp.std() > 1e-6 else 0.0
    return bg, alpha0, corr


def _reverse_blend(bgr, bg, cx, cy, R, rim=True):
    """Tìm tham số hình/độ mờ/alpha khớp nhất rồi đảo phép pha trộn. Trả về (ảnh, độ lệch, (p, rs, sg, alpha))."""
    h, w = bgr.shape[:2]
    pad = int(R * 2.4)
    y0, y1, x0, x1 = int(max(0, cy - pad)), int(min(h, cy + pad + 1)), int(max(0, cx - pad)), int(min(w, cx + pad + 1))
    crop = bgr[y0:y1, x0:x1].astype(np.float32)
    bgc = bg[y0:y1, x0:x1].astype(np.float32)
    hh, ww = crop.shape[:2]
    lcx, lcy = cx - x0, cy - y0
    den = 255.0 - bgc
    lift = crop - bgc
    near = _star(hh, ww, lcx, lcy, R * 1.5)
    best = None
    for p_ in (0.62, 0.70, 0.78):
        for rs in (1.0, 1.06, 1.12):
            shape = _star(hh, ww, lcx, lcy, R * rs, p=p_).astype(np.float32)
            band = _star(hh, ww, lcx, lcy, R * (rs + 0.12), p=p_) & ~_star(hh, ww, lcx, lcy, R * (rs - 0.12), p=p_)
            for sg in (0.4, 0.9):
                soft = cv2.GaussianBlur(shape, (0, 0), max(0.6, sg * R * 0.05))[..., None]
                a_lsq = float((soft * den * lift).sum() / max(1e-6, ((soft * den) ** 2).sum()))
                for mult in (1.0,):
                    a0 = float(np.clip(a_lsq * mult, ALPHA_MIN, ALPHA_MAX))
                    al = soft * a0
                    rev = np.clip((crop - al * 255.0) / np.maximum(1.0 - al, 0.05), 0, 255)
                    rg = cv2.cvtColor(rev.astype(np.uint8), cv2.COLOR_BGR2GRAY).astype(np.float32)
                    gx = cv2.Sobel(rg, cv2.CV_32F, 1, 0, ksize=3)
                    gy = cv2.Sobel(rg, cv2.CV_32F, 0, 1, ksize=3)
                    edge = float((np.sqrt(gx * gx + gy * gy) / 8.0)[band].mean())
                    fill = float(np.abs(rev - bgc)[near].mean())
                    cost = fill
                    if best is None or cost < best[0]:
                        best = (cost, p_, rs, sg, a0, rev)
    _, p_, rs, sg, a0, rev = best
    out_crop = rev
    if rim:
        inner = _star(hh, ww, lcx, lcy, R * (rs - 0.20), p=p_).astype(np.uint8)
        outer = _star(hh, ww, lcx, lcy, R * (rs + 0.14), p=p_).astype(np.uint8)
        rim_mask = (outer - inner).astype(np.uint8) * 255
        out_crop = cv2.inpaint(np.clip(rev, 0, 255).astype(np.uint8), rim_mask, 2, cv2.INPAINT_TELEA).astype(np.float32)
    # chỉ thay trong vùng quanh ngôi sao (mép mềm), ngoài vùng giữ nguyên tuyệt đối
    wmask = cv2.GaussianBlur(_star(hh, ww, lcx, lcy, R * (rs + 0.25), p=p_).astype(np.float32), (0, 0), 1.0)
    wmask = np.where(_star(hh, ww, lcx, lcy, R * (rs + 0.6), p=p_), wmask, 0.0)[..., None]
    blended = crop * (1.0 - wmask) + out_crop * wmask
    out = bgr.copy()
    out[y0:y1, x0:x1] = np.clip(blended + 0.5, 0, 255).astype(np.uint8)
    dev = float(np.abs(out_crop - bgc)[_star(hh, ww, lcx, lcy, R)].mean())
    return out, dev, (p_, rs, sg, a0)


_TPL_B64 = (
    "eNrtmG1IFEEYx+9zZWJ2haaVCRJEUtgLaEpBiZWFUKJJJEoKRiK+gZYVERQkWFnYh8Ivai8WQSlSokamcFB0+VZhZmillt3pebd3"
    "t7sz+zR7Hpd2X29nIZ4fHPttf/efeeaZ2TEYEARBEARBEARBEARBEO0J0k+9VMfYoQnxEcv0UW+7Vr0nVB917oC5OEoX84Yrdql+"
    "ix7m5clNEphS9FBHFvUoMJGvhzq27juAcD1GB/XudgAgpqIQ7ubVBZ8AXIrQFs+9jx3vsAMRFBgv4R17UxMFBxEJzD1K5ahlzTO6"
    "chjASYgC5GvNep6Zg/NfCwAyIVRWJNPpcI7q/Y+dIFIiq3Lq6Cvnt4kl3B0HcMtEkgklIkDv0WBO5p21P4ASSZIpZQ9RAWtrzgoe"
    "4ois+hEAycVGW1XLMgVwdJdt9Raglq2ksGsWFIW4JarCJhtURm8laZ15X7XJxmpbppIMCnuo68vD5MPcKN/a0yLykacziiRJrLpU"
    "tWe2vWqgvcXRWh3YYg4W13ZZgYUl6sbBAvsiz7uHGiqOJa0JuDckLvP8g/4ZAFFNqoo8aljM2PMbp1IiA2tOrXnxbnjSwd4us9gK"
    "C6swMVX+UYN9zPymLjqg6pPt055Xu9mGwdRqbNlb2z6U+T9COuMC20XK7/dZPcPsqyq/yJ7Rtwy0lAb2gBy0ce+Jc42DkhpO/dHF"
    "FeZF6ms8k7ErUoMS3362R/QG9Bttz0B0lMRp1U+iDl3u/M0yu9yyv9jSfTFRy2ZmzLr3WVAn2i/xyJ0DWn/iJZa9Uk0LK1utr8Gq"
    "ddrvXOGF731RFe8it5mqwnjsmsb0ZvuCxUxAmWjOWMLprJDW6vyrpiC2p3E7IK3MfOntIGyiZcfHCo7HQmPpB+9suxyCuSKMo9oQ"
    "e+mLGlkUZqdHa4INXIlvZoUtWa3U9iSZ981VXrcDnFNWmCzif2uW/Vae/TlnexbL//s6rMFisdl6C/S4Vrgw8Ev8dlWXK6Tstilq"
    "Ttfl8mrH7XGhZbMuakOlRbi5Sh/14aH+XH3MBmNezloDgiAIgiAIgiAIgiAIgvyP/AHxgsJi"
)
_TPL_SHAPE = (123, 123)
_TPL = None
_TPL_C = 61
_TPL_HALF = 22.0


def _template():
    """Hình ngôi sao THẬT (đo từ ảnh Gemini) chuẩn hoá 0..1; None nếu thiếu file."""
    global _TPL
    if _TPL is None:
        try:
            import base64
            import zlib
            q = np.frombuffer(zlib.decompress(base64.b64decode("".join(_TPL_B64))), dtype=np.uint8)
            _TPL = (q.reshape(_TPL_SHAPE).astype(np.float32) / 255.0)
        except Exception:
            _TPL = False
    return _TPL if _TPL is not False else None


def _warp_tpl(tpl, s, tx, ty, ww, hh):
    M = np.float32([[s, 0, tx - _TPL_C * s], [0, s, ty - _TPL_C * s]])
    return cv2.warpAffine(tpl, M, (ww, hh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)


def _reverse_blend_tpl(bgr, bg, cx, cy, R):
    """Đảo phép pha trộn bằng mẫu ngôi sao thật: tự khớp tỉ lệ + vị trí dưới-pixel + alpha. None nếu không có mẫu."""
    tpl = _template()
    if tpl is None:
        return None
    h, w = bgr.shape[:2]
    pad = int(R * 2.6)
    y0, y1, x0, x1 = int(max(0, cy - pad)), int(min(h, cy + pad + 1)), int(max(0, cx - pad)), int(min(w, cx + pad + 1))
    crop = bgr[y0:y1, x0:x1].astype(np.float32)
    bgc = bg[y0:y1, x0:x1].astype(np.float32)
    hh, ww = crop.shape[:2]
    lcx, lcy = cx - x0, cy - y0
    den = 255.0 - bgc
    lift = crop - bgc

    def fit(s, dx, dy):
        sh = _warp_tpl(tpl, s, lcx + dx, lcy + dy, ww, hh)
        s3 = sh[..., None]
        sd = s3 * den
        a = float((sd * lift).sum() / max(1e-6, (sd * sd).sum()))
        a = float(np.clip(a, ALPHA_MIN, ALPHA_MAX))
        res = float(((lift - a * sd) ** 2).sum())
        return res, a, sh

    s0 = R / _TPL_HALF
    best = None
    for s in np.arange(s0 * 0.78, s0 * 1.36, 0.04 * max(0.5, s0)):
        for dy in (-3, -2, -1, 0, 1, 2, 3):
            for dx in (-3, -2, -1, 0, 1, 2, 3):
                r_, a_, _ = fit(s, dx, dy)
                if best is None or r_ < best[0]:
                    best = (r_, s, dx, dy)
    _, s, dx, dy = best
    for ds in (-0.03, -0.015, 0, 0.015, 0.03):
        for ddy in (-0.5, -0.25, 0, 0.25, 0.5):
            for ddx in (-0.5, -0.25, 0, 0.25, 0.5):
                r_, a_, _ = fit(s + ds * max(0.5, s0), dx + ddx, dy + ddy)
                if r_ < best[0]:
                    best = (r_, s + ds * max(0.5, s0), dx + ddx, dy + ddy)
    _, s, dx, dy = best
    _, a0, sh = fit(s, dx, dy)
    al = (sh * a0)[..., None]
    rev = np.clip((crop - al * 255.0) / np.maximum(1.0 - al, 0.05), 0, 255)
    # vùng thay: đúng hình ngôi sao nở ra 2px, mép mềm 1px; ngoài vùng giữ nguyên tuyệt đối
    cover = cv2.dilate((sh > 0.004).astype(np.uint8), np.ones((5, 5), np.uint8), iterations=1).astype(np.float32)
    cover = cv2.GaussianBlur(cover, (0, 0), 1.0)[..., None]
    out_crop = crop * (1.0 - cover) + rev * cover
    out = bgr.copy()
    out[y0:y1, x0:x1] = np.clip(out_crop + 0.5, 0, 255).astype(np.uint8)
    dev = float(np.abs(out_crop - bgc)[sh > 0.5].mean())
    return out, dev, ("tpl", round(s, 3), round(dx, 2), round(dy, 2), a0)


PRIOR_OFF = 112.5     # tâm ngôi sao cách mép phải/dưới (px) - đo trên 282 ảnh thật: luôn 112.5px ở ảnh cao 721
PRIOR_H = 721.0
PRIOR_MIN_NCC = 0.08  # độ khớp hình tối thiểu tại đúng vị trí cố định
PRIOR_ALPHA_LO, PRIOR_ALPHA_HI = 0.17, 0.45   # có ngôi sao: alpha lõi ~0.25-0.31; không có: ~0.00
PRIOR_MAX_ENERGY = 1.15  # chặn trường hợp xoá xong viền còn rõ hơn hẳn
PRIOR_GHOST_NCC = 0.30   # chỉ còn đường viền mờ (lõi sạch) nhưng hình khớp rõ
PRIOR_LOCK_NCC = 0.35
PRIOR_ALPHA_DEFAULT = 0.28


LAST_DIAG = {}


def _hp(x, sg):
    return x - cv2.GaussianBlur(x, (0, 0), sg)


def _ncc(a, b, m):
    a = a[m]; b = b[m]
    a = a - a.mean(); b = b - b.mean()
    d = float(np.sqrt((a * a).sum() * (b * b).sum()))
    return float((a * b).sum() / d) if d > 1e-6 else 0.0


def _edge_energy(img3, mask):
    g = cv2.cvtColor(np.clip(img3, 0, 255).astype(np.uint8), cv2.COLOR_BGR2GRAY).astype(np.float32)
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    return float(np.sqrt(gx * gx + gy * gy)[mask].mean())


def _prior_remove(bgr):
    """Ngôi sao Gemini (ảnh chụp từ web) LUÔN nằm ở vị trí cố định cách góc dưới-phải 112.5px (theo tỉ lệ chiều cao).
    Khớp mẫu ngôi sao thật tại đúng chỗ đó (tinh chỉnh dưới-pixel), ước lượng alpha bằng cách tìm giá trị làm
    viền ngôi sao biến mất (năng lượng cạnh nhỏ nhất), rồi đảo phép pha trộn. Không cần đoán nền => chạy được cả
    trên nền nhiều hoạ tiết/chữ. Trả về (ảnh, mô tả) hoặc None nếu không có ngôi sao."""
    tpl = _template()
    if tpl is None:
        return None
    h, w = bgr.shape[:2]
    k = h / PRIOR_H
    if w < 300 or h < 300:
        return None
    cx0, cy0 = w - PRIOR_OFF * k, h - PRIOR_OFF * k
    pad = int(48 * k) + 4
    x0, x1 = int(cx0 - pad), int(cx0 + pad + 1)
    y0, y1 = int(cy0 - pad), int(cy0 + pad + 1)
    if x0 < 0 or y0 < 0 or x1 > w or y1 > h:
        return None
    crop = bgr[y0:y1, x0:x1].astype(np.float32)
    hh, ww = crop.shape[:2]
    g = cv2.cvtColor(bgr[y0:y1, x0:x1], cv2.COLOR_BGR2GRAY).astype(np.float32)
    ghp = _hp(g, 5 * k)
    lcx, lcy = cx0 - x0, cy0 - y0
    zone = _star(hh, ww, lcx, lcy, 40 * k, p=1.0)   # vùng quanh ngôi sao để so khớp

    best = None
    for s in (k * 0.97, k, k * 1.03):
        for dy in (-1.5, -1, -0.5, 0, 0.5, 1, 1.5):
            for dx in (-1.5, -1, -0.5, 0, 0.5, 1, 1.5):
                sh = _warp_tpl(tpl, s, lcx + dx, lcy + dy, ww, hh)
                v = _ncc(ghp, _hp(sh, 5 * k), zone)
                if best is None or v > best[0]:
                    best = (v, s, dx, dy, sh)
    ncc, s, dx, dy, sh = best
    if ncc < PRIOR_LOCK_NCC:
        # khớp yếu (nền nhiều chữ/hoạ tiết kéo lệch) => khoá về đúng vị trí/tỉ lệ chuẩn đã đo (rất ổn định)
        s, dx, dy = k, 0.0, 0.0
        sh = _warp_tpl(tpl, s, lcx, lcy, ww, hh)
        ncc = _ncc(ghp, _hp(sh, 5 * k), zone)
    LAST_DIAG.clear(); LAST_DIAG.update(ncc=round(ncc, 3))
    if ncc < PRIOR_MIN_NCC:
        return None

    mask = cv2.dilate((sh > 0.02).astype(np.uint8), np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    s3 = sh[..., None]

    def rev_of(a):
        al = s3 * a
        return (crop - al * 255.0) / np.maximum(1.0 - al, 0.05)

    # alpha thật đo trên ảnh: lõi ngôi sao ~0.25-0.31 (cố định theo thiết kế của Gemini). Ước lượng bằng trung vị
    # (bền với nền nhiều chữ/hoạ tiết): nền lấy bằng inpaint vùng ngôi sao nở rộng.
    big = cv2.dilate((sh > 0.02).astype(np.uint8) * 255, np.ones((3, 3), np.uint8), iterations=3)
    bg = cv2.inpaint(bgr[y0:y1, x0:x1], big, max(3, int(5 * k)), cv2.INPAINT_TELEA).astype(np.float32)
    den = 255.0 - bg
    core = (sh > 0.8) & (den.min(axis=2) > 25)
    a_med = float(np.median(((crop - bg) / np.maximum(den, 1.0)).mean(axis=2)[core])) if core.sum() >= 40 else 0.0
    LAST_DIAG.update(a_med=round(a_med, 3))

    # dải viền ngôi sao (nơi hay còn sót "bóng ma" sau khi xoá)
    edge = ((sh > 0.03) & (sh < 0.75)).astype(np.uint8) * 255
    edge = cv2.dilate(edge, np.ones((3, 3), np.uint8), iterations=1)
    cover = cv2.GaussianBlur(mask.astype(np.float32), (0, 0), 1.0)[..., None]

    has_star = (a_med >= PRIOR_ALPHA_LO and ncc >= PRIOR_MIN_NCC) or (a_med >= 0.07 and ncc >= 0.18)
    ghost = (not has_star) and a_med < 0.07 and ncc >= PRIOR_GHOST_NCC
    if not has_star and not ghost:
        return None

    if ghost:
        # lõi đã sạch nhưng còn "bóng" hình ngôi sao (do lần xoá trước) => vá lại toàn bộ hình ngôi sao
        whole = cv2.dilate((sh > 0.03).astype(np.uint8) * 255, np.ones((3, 3), np.uint8), iterations=2)
        fixed = cv2.inpaint(bgr[y0:y1, x0:x1], whole, max(3, int(4 * k)), cv2.INPAINT_TELEA).astype(np.float32)
        cover = cv2.GaussianBlur((whole > 0).astype(np.float32), (0, 0), 1.0)[..., None]
        out_crop = crop * (1.0 - cover) + fixed * cover
        out = bgr.copy()
        out[y0:y1, x0:x1] = np.clip(out_crop + 0.5, 0, 255).astype(np.uint8)
        return out, f"đã xoá viền mờ watermark Gemini còn sót ở góc (vị trí cố định • khớp={ncc:.2f})"

    # alpha: nếu đo được hợp lý thì dùng, không thì dùng giá trị thiết kế ~0.28; tinh chỉnh bằng năng lượng viền
    a_ref = a_med if 0.20 <= a_med <= 0.36 else PRIOR_ALPHA_DEFAULT
    lo, hi = max(0.18, a_ref - 0.04), min(0.40, a_ref + 0.04)
    e0 = _edge_energy(crop, mask)
    a_best, e_best = a_ref, _edge_energy(rev_of(a_ref), mask)
    for a in np.arange(lo, hi + 1e-6, 0.01):
        e = _edge_energy(rev_of(a), mask)
        if e < e_best:
            a_best, e_best = float(a), e
    a_best = 0.5 * (a_best + a_ref)
    e_best = _edge_energy(rev_of(a_best), mask)
    ratio = e_best / max(1e-6, e0)
    LAST_DIAG.update(ratio=round(ratio, 3))
    if ratio > PRIOR_MAX_ENERGY:
        return None

    rev = np.clip(rev_of(a_best), 0, 255)
    # viền mảnh còn sót do lệch dưới-pixel / nén ảnh => inpaint nhẹ đúng dải mép ngôi sao
    fixed = cv2.inpaint(rev.astype(np.uint8), edge, 2, cv2.INPAINT_TELEA).astype(np.float32)
    soft_edge = cv2.GaussianBlur(edge.astype(np.float32) / 255.0, (0, 0), 0.8)[..., None] * 0.7
    rev = rev * (1.0 - soft_edge) + fixed * soft_edge
    out_crop = crop * (1.0 - cover) + rev * cover
    out = bgr.copy()
    out[y0:y1, x0:x1] = np.clip(out_crop + 0.5, 0, 255).astype(np.uint8)
    return out, (f"đã xoá watermark Gemini ở góc (vị trí cố định • tâm {cx0 + dx:.0f},{cy0 + dy:.0f} • "
                 f"tỉ lệ={s:.3f} • alpha={a_best:.2f} • khớp={ncc:.2f} • viền còn {ratio * 100:.0f}%)")


def process_bgr(bgr, min_contrast=MIN_CONTRAST):
    """Xử lý ảnh trong bộ nhớ. Trả về (ảnh_ra, mô_tả). Không chắc chắn thì trả lại ảnh gốc."""
    h, w = bgr.shape[:2]
    pr = _prior_remove(bgr)
    if pr is not None:
        return pr
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    best = None
    for _, cx, cy, R in _find(gray, h, w):
        v = _validate(bgr, gray, cx, cy, R)
        if not v:
            continue
        contrast, ch_ratio, star_ratio, sharp = v
        if contrast < min_contrast or ch_ratio < MIN_CHANNEL_RATIO or star_ratio < MIN_STAR_RATIO or sharp < MIN_SHARPNESS:
            continue
        bg, alpha0, corr = _estimate(bgr, cx, cy, R)
        if alpha0 is None or corr < MIN_SHAPE_CORR:
            continue
        score = contrast * corr
        if best is None or score > best[0]:
            best = (score, cx, cy, R, contrast, corr, bg, alpha0)
    if best is None:
        return bgr, "không thấy watermark Gemini ở góc ảnh → giữ nguyên"
    _, cx, cy, R, contrast, corr, bg, alpha0 = best

    res = _reverse_blend_tpl(bgr, bg, cx, cy, R)
    if res is None:
        res = _reverse_blend(bgr, bg, cx, cy, R)
    out, dev, fit = res
    if dev > 28.0:
        out = bg
    return out, (f"đã xoá watermark Gemini ở góc (tâm {cx:.0f},{cy:.0f} • R={R:.0f}px • "
                 f"alpha={fit[-1]:.2f} • mẫu={fit[0]} • contrast={contrast:.0f} • khớp={corr:.2f}{' • dùng nền ước lượng' if dev > 28.0 else ''})")


def remove_gemini_watermark(path, min_contrast=MIN_CONTRAST):
    """Trả về chuỗi mô tả kết quả. Không bao giờ ném lỗi ra ngoài; không chắc chắn thì giữ nguyên ảnh."""
    if cv2 is None:
        return "bỏ qua xoá watermark Gemini: thiếu opencv/numpy"
    try:
        data = np.fromfile(path, dtype=np.uint8)
        bgr = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if bgr is None:
            return "bỏ qua xoá watermark Gemini: không đọc được ảnh"
        out, msg = process_bgr(bgr, min_contrast)
        if out is bgr:
            return msg
        ext = os.path.splitext(path)[1].lower() or ".png"
        params = [cv2.IMWRITE_PNG_COMPRESSION, 1] if ext == ".png" else ([cv2.IMWRITE_JPEG_QUALITY, 95] if ext in (".jpg", ".jpeg") else [])
        ok, buf = cv2.imencode(ext, out, params)
        if not ok:
            return "bỏ qua xoá watermark Gemini: không ghi được ảnh"
        tmp = path + ".wm_tmp"
        buf.tofile(tmp)
        os.replace(tmp, path)
        return msg
    except Exception as e:  # noqa
        return f"bỏ qua xoá watermark Gemini: {e}"
