# -*- coding: utf-8 -*-
"""
Flow Fast Parallel Dashboard Clean - v13.48.2 PySide6/Qt + Detect-language Google Translate

Mục tiêu bản này:
- Chuyển giao diện từ Tkinter sang PySide6/Qt để mượt hơn và ít bị Windows "Not Responding".
- Giữ backend/worker cũ: Selenium Flow, multi-worker, clone profile, copyback atomic, backup ảnh cũ.
- Chạy cạnh file backend gemini_auto_router_by_account_mode_fixed_v*.py và có thể import lại helper từ bản dashboard v50/v49 nếu có.

Cài PySide6 nếu máy chưa có:
    pip install PySide6
"""

import os
import sys
import re
import json
import time
import queue
import shutil
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess
import importlib.util
import ctypes
import ctypes.wintypes
import atexit
import base64
import random
import hashlib
from pathlib import Path
from datetime import datetime
from io import BytesIO

# V50: export the authenticated Gemini browser session into Thumbnail Studio's
# persistent session cache. Description Studio consumes this cache directly over
# HTTP, so rewriting descriptions never drives a browser.
try:
    from session_engine import create_engine as _create_thumbnail_session_engine
except Exception:
    _create_thumbnail_session_engine = None

def _qt_export_gemini_session_bundle(driver, profile_dir, proxy_value="", log_fn=None):
    if driver is None or _create_thumbnail_session_engine is None:
        return False
    try:
        root = Path(profile_dir)
        engine = _create_thumbnail_session_engine(
            root, "gemini", "https://gemini.google.com/app",
            proxy_value=str(proxy_value or ""), account_label=root.name,
        )
        payload = engine.export_from_driver(
            driver, referer="https://gemini.google.com/app",
            proxy_value=str(proxy_value or ""),
            extra={"source": "thumbnail-studio-account-check", "captured_at": int(time.time())},
        )
        ok = bool(engine.has_usable_cache())
        if log_fn:
            try:
                log_fn(f"[session-cache] Gemini {'READY' if ok else 'EMPTY'} • {root.name} • cookies={len(payload.get('cookies') or [])}")
            except Exception:
                pass
        return ok
    except Exception as exc:
        if log_fn:
            try:
                log_fn(f"[session-cache] export Gemini lỗi • {Path(profile_dir).name} • {exc}")
            except Exception:
                pass
        return False


# v8.6: Crash/runtime logger - ghi file lỗi kể cả khi tool bị out bất ngờ.
_CRASH_LOG_FILES = []
def _setup_crash_runtime_logger():
    try:
        import traceback, faulthandler
        base = Path(__file__).resolve().parent
        log_dir = base / "_crash_logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        runtime_path = log_dir / f"runtime_{stamp}.log"
        fatal_path = log_dir / f"fatal_native_{stamp}.log"

        class _Tee:
            def __init__(self, *streams):
                self.streams = streams
            def write(self, data):
                for st in list(self.streams):
                    try:
                        st.write(data)
                        st.flush()
                    except Exception:
                        pass
            def flush(self):
                for st in list(self.streams):
                    try:
                        st.flush()
                    except Exception:
                        pass
            @property
            def encoding(self):
                return "utf-8"

        runtime_f = open(runtime_path, "a", encoding="utf-8", buffering=1)
        fatal_f = open(fatal_path, "a", encoding="utf-8", buffering=1)
        _CRASH_LOG_FILES.extend([runtime_f, fatal_f])
        runtime_f.write(f"===== Gemini Tool runtime start {datetime.now().isoformat()} =====\n")
        runtime_f.write(f"cwd={os.getcwd()}\npython={sys.version}\nexe={sys.executable}\nfile={__file__}\n")
        runtime_f.flush()

        sys.stdout = _Tee(getattr(sys, "__stdout__", None) or sys.stdout, runtime_f)
        sys.stderr = _Tee(getattr(sys, "__stderr__", None) or sys.stderr, runtime_f)

        try:
            faulthandler.enable(file=fatal_f, all_threads=True)
        except Exception:
            pass

        def _write_uncaught(kind, exc_type, exc, tb):
            try:
                crash_path = log_dir / f"fatal_{kind}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                text = "".join(traceback.format_exception(exc_type, exc, tb))
                crash_path.write_text(text, encoding="utf-8", errors="replace")
                print(f"[fatal] saved {crash_path}")
            except Exception:
                pass

        old_hook = sys.excepthook
        def _sys_hook(exc_type, exc, tb):
            _write_uncaught("sys", exc_type, exc, tb)
            try:
                old_hook(exc_type, exc, tb)
            except Exception:
                pass
        sys.excepthook = _sys_hook

        if hasattr(threading, "excepthook"):
            old_thread_hook = threading.excepthook
            def _thread_hook(args):
                _write_uncaught("thread", args.exc_type, args.exc_value, args.exc_traceback)
                try:
                    old_thread_hook(args)
                except Exception:
                    pass
            threading.excepthook = _thread_hook

        def _on_exit():
            try:
                print(f"===== Gemini Tool runtime exit {datetime.now().isoformat()} =====")
                for f in _CRASH_LOG_FILES:
                    try:
                        f.flush()
                    except Exception:
                        pass
            except Exception:
                pass
        atexit.register(_on_exit)

        os.environ["GEMINI_TOOL_RUNTIME_LOG"] = str(runtime_path)
        os.environ["GEMINI_TOOL_FATAL_LOG"] = str(fatal_path)
        print(f"[crash-log] runtime: {runtime_path}")
        print(f"[crash-log] fatal native: {fatal_path}")
        return runtime_path
    except Exception as e:
        try:
            print("[crash-log] setup failed:", e)
        except Exception:
            pass
        return None

_SETUP_RUNTIME_LOG_PATH = _setup_crash_runtime_logger()


# v9.5: Upload Fallback - ghi rõ ai/luồng nào khiến Qt app thoát.
_EXIT_TRACE_LOCK = threading.RLock()
_EXIT_TRACE_PATH = None
_EXIT_TRACE_SEQ = 0

def _get_exit_trace_path():
    global _EXIT_TRACE_PATH
    if _EXIT_TRACE_PATH is not None:
        return _EXIT_TRACE_PATH
    try:
        base = Path(__file__).resolve().parent
        log_dir = base / "_crash_logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        _EXIT_TRACE_PATH = log_dir / f"exit_trace_{stamp}_pid{os.getpid()}.log"
        try:
            _EXIT_TRACE_PATH.write_text(
                f"===== Exit Trace start {datetime.now().isoformat()} pid={os.getpid()} =====\n"
                f"cwd={os.getcwd()}\npython={sys.version}\nexe={sys.executable}\nfile={__file__}\n",
                encoding="utf-8",
                errors="replace",
            )
        except Exception:
            pass
        return _EXIT_TRACE_PATH
    except Exception:
        return None

def _exit_trace(message, *, stack=False, win=None, extra=None):
    """Append high-signal shutdown/close breadcrumbs to _crash_logs/exit_trace_*.log."""
    global _EXIT_TRACE_SEQ
    try:
        path = _get_exit_trace_path()
        if not path:
            return
        with _EXIT_TRACE_LOCK:
            _EXIT_TRACE_SEQ += 1
            now = datetime.now().isoformat(timespec="milliseconds")
            th = threading.current_thread()
            lines = [f"\n[{_EXIT_TRACE_SEQ:05d}] {now} pid={os.getpid()} thread={th.name}/{th.ident} :: {message}"]
            try:
                lines.append(f"    argv={sys.argv!r}")
            except Exception:
                pass
            if win is not None:
                try:
                    lines.append(
                        "    win_state="
                        f"visible={win.isVisible()} minimized={win.isMinimized()} active={win.isActiveWindow()} "
                        f"closing={getattr(win, '_closing_now', None)} stop_requested={getattr(win, 'stop_requested', None)} "
                        f"workers={len(getattr(win, 'worker_procs', []) or [])} queue={getattr(getattr(win, 'ui_queue', None), 'qsize', lambda: '?')()}"
                    )
                except Exception as e:
                    lines.append(f"    win_state_error={e!r}")
            if extra is not None:
                try:
                    lines.append("    extra=" + repr(extra))
                except Exception:
                    pass
            if stack:
                try:
                    import traceback
                    lines.append("    stack:\n" + "".join(traceback.format_stack(limit=35)))
                except Exception as e:
                    lines.append(f"    stack_error={e!r}")
            with open(path, "a", encoding="utf-8", errors="replace") as f:
                f.write("\n".join(lines) + "\n")
                f.flush()
        try:
            print(f"[exit-trace] {message}")
        except Exception:
            pass
    except Exception:
        pass

def _install_process_exit_tracers():
    try:
        _exit_trace("install process exit tracers", stack=False)
        def _atexit_exit_trace():
            _exit_trace("python atexit reached", stack=True)
        atexit.register(_atexit_exit_trace)
    except Exception:
        pass
    try:
        import signal
        for sig_name in ("SIGTERM", "SIGINT", "SIGBREAK"):
            sig = getattr(signal, sig_name, None)
            if sig is None:
                continue
            try:
                old_handler = signal.getsignal(sig)
                def _handler(signum, frame, _old=old_handler, _name=sig_name):
                    _exit_trace(f"signal received: {_name}/{signum}", stack=True)
                    if callable(_old):
                        return _old(signum, frame)
                    if _old in (signal.SIG_DFL, None):
                        try:
                            sys.exit(128 + int(signum))
                        except SystemExit:
                            raise
                signal.signal(sig, _handler)
            except Exception:
                pass
    except Exception:
        pass

_install_process_exit_tracers()

try:
    import psutil
except Exception:
    psutil = None

try:
    from PIL import Image, ImageDraw, ImageChops
except Exception:
    Image = None

# v113: ẩn sớm cửa sổ cmd nếu tool được mở bằng .bat/python.exe.
# Nếu muốn debug console, chạy với biến môi trường FLOW_SHOW_CONSOLE=1.
def _early_hide_console_window():
    if os.name != "nt" or os.environ.get("FLOW_SHOW_CONSOLE", "0") == "1":
        return False
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)
            return True
    except Exception:
        pass
    return False

_early_hide_console_window()

try:
    from PySide6.QtCore import Qt, QTimer, QSize, Signal, QObject
    from PySide6.QtGui import QPixmap, QIcon, QAction, QFont
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
        QLabel, QPushButton, QLineEdit, QFileDialog, QMessageBox, QFrame,
        QScrollArea, QSplitter, QListWidget, QListWidgetItem, QTreeWidget,
        QTreeWidgetItem, QPlainTextEdit, QSpinBox, QGroupBox, QMenu, QToolButton,
        QSizePolicy, QHeaderView, QInputDialog, QComboBox, QProgressBar, QProgressDialog, QDialog, QStackedWidget,
        QListView, QTreeView, QAbstractItemView, QCheckBox
    )
except Exception as _qt_import_error:
    print("\n❌ Thiếu PySide6/Qt.")
    print("Cài bằng lệnh: pip install PySide6")
    print("Chi tiết lỗi:", _qt_import_error)
    input("\nNhấn Enter để thoát...")
    raise SystemExit(1)

def _load_app_version():
    try:
        data = json.loads((Path(__file__).resolve().parent / "app_version.json").read_text(encoding="utf-8-sig"))
        value = str(data.get("version", "12.96")).strip()
        return value or "12.96"
    except Exception:
        return "12.96"

APP_VERSION = _load_app_version()
APP_TITLE = f"Gemini Studio v{APP_VERSION} • Thumb + Desc Clean Any Brand"

try:
    import online_updater as _online_updater
except Exception as _online_updater_import_error:
    _online_updater = None


class _UpdateSignals(QObject):
    update_found = Signal(object)
    no_update = Signal(str)
    check_failed = Signal(str)
    download_progress = Signal(int)
    download_finished = Signal(str, object)
    download_failed = Signal(str)

GEMINI_WEB_URL_GUI = "https://gemini.google.com/app"
FLOW_WEB_URL_GUI = GEMINI_WEB_URL_GUI  # v6.7: Flow removed; keep alias only for legacy helper compatibility
GOOGLE_LOGIN_FORCE_URL_GUI = "https://accounts.google.com/signin/v2/identifier?hl=vi"
SIZE_LIMIT_MB = 1.5
RUN_HISTORY_KEEP = 1
PROFILE_HISTORY_KEEP = int(os.environ.get("GEMINI_PROFILE_KEEP", "20") or 20)
MACHINE_ACCOUNT_POOL_LIMIT = int(os.environ.get("GEMINI_MACHINE_POOL_LIMIT", "20") or 20)
PROFILE_NEVER_PRUNE_MACHINE_POOL = str(os.environ.get("GEMINI_PROFILE_NEVER_PRUNE_MACHINE_POOL", "1")).strip().lower() not in ("0", "false", "no", "off")
PROFILE_SYNC_BACK_ALWAYS = str(os.environ.get("GEMINI_PROFILE_SYNC_BACK_ALWAYS", "1")).strip().lower() not in ("0", "false", "no", "off")
MACHINE_ACCOUNT_POOL_JSON = "machine_account_pool.json"
MACHINE_ACCOUNT_POOL_TXT = "machine_accounts.txt"
# v13.54: FULL VAULT RUN + FRESH RESPONSE GATE. Mỗi lần bấm Chạy queue mở toàn bộ kho mail; ưu tiên account tốt trước.
# Account chỉ bị coi hết quota khi chính job vừa Send nhận phản hồi quota MỚI từ Gemini.
# MACHINE_ACCOUNT_POOL_LIMIT chỉ còn dùng cho bootstrap nền/housekeeping, KHÔNG giới hạn kho account được scheduler sử dụng.
# Có thể đặt GEMINI_DAILY_QUOTA_HOLD_FILE tới một đường dẫn dùng chung (LAN/NAS)
# file dùng chung vẫn lưu quota để nhiều máy tránh retry vòng lặp; manual run dùng override cục bộ.
ACCOUNT_DAILY_QUOTA_HOLD_JSON = "account_quota_hold_today.json"
ACCOUNT_DAILY_QUOTA_HOLD_ENV = "GEMINI_DAILY_QUOTA_HOLD_FILE"
ACCOUNT_SELECTION_HISTORY_JSON = "account_selection_history.json"
ACCOUNT_DAILY_LOCK_STALE_SECONDS = int(os.environ.get("GEMINI_DAILY_QUOTA_LOCK_STALE_SECONDS", "120") or 120)
# v12.64: Fast Reuse Mode - ưu tiên dùng lại 20 profile cố định, bỏ hidden-check dài khi profile đã có dữ liệu.
PROFILE_LOGIN_OK_MARKER = ".gemini_login_ok.json"
PROFILE_FORCE_LOGIN_MARKER = ".gemini_force_login.json"
PROFILE_REUSE_DAYS = int(os.environ.get("GEMINI_PROFILE_REUSE_DAYS", "60") or 60)
LOGIN_USE_PROXY = str(os.environ.get("GEMINI_LOGIN_USE_PROXY", "0")).strip().lower() in ("1", "true", "yes", "on")
PROXY_SAFE_CHECK = str(os.environ.get("GEMINI_PROXY_SAFE_CHECK", "1")).strip().lower() not in ("0", "false", "no", "off")
FAST_REUSE_MODE = str(os.environ.get("GEMINI_FAST_REUSE_MODE", "1")).strip().lower() not in ("0", "false", "no", "off")
FAST_REUSE_ASSUME_PROFILE_OK = str(os.environ.get("GEMINI_PROFILE_FAST_ASSUME_OK", "1")).strip().lower() not in ("0", "false", "no", "off")
FAST_PROXY_CHECK_TIMEOUT = float(os.environ.get("GEMINI_PROXY_CHECK_TIMEOUT", "2.5") or 2.5)
FAST_REUSE_READY_ONLY = str(os.environ.get("GEMINI_FAST_READY_ONLY", "1")).strip().lower() not in ("0", "false", "no", "off")
FAST_REUSE_BOOTSTRAP_IF_NONE_READY = str(os.environ.get("GEMINI_FAST_BOOTSTRAP_IF_NONE_READY", "1")).strip().lower() not in ("0", "false", "no", "off")
FAST_REUSE_MAX_WORKERS = int(os.environ.get("GEMINI_FAST_REUSE_MAX_WORKERS", "8") or 8)
ACCOUNT_ROTATE_AFTER_DRAW_ERRORS = int(os.environ.get("GEMINI_ACCOUNT_ROTATE_AFTER_DRAW_ERRORS", "3") or 3)
RESTORE_MAX_BYTES = int(0.6 * 1024 * 1024)

# UI tuning for Qt: drain queue in tiny batches; QListWidget handles previews better than Tk custom grid.
UI_DRAIN_MAX_EVENTS = 120
UI_DRAIN_MAX_SECONDS = 0.035
UI_DRAIN_FAST_MS = 16
UI_DRAIN_NORMAL_MS = 110
PREVIEW_REFRESH_DELAY_MS = 900  # v12.0: giảm tải UI khi chạy 5-8 luồng
PREVIEW_MAX_CARDS_RUNNING = 16  # v12.0: ít refresh card hơn để nhường CPU cho Chrome
PREVIEW_MAX_CARDS_IDLE = 999999  # v2.5: sau Quét file hiển thị đầy đủ job để kiểm tra
LOG_MAX_LINES = 1200
LOG_BATCH_MAX_LINES_PER_TICK = 80
NOISY_LOG_THROTTLE_SECONDS = 8.0
GENERIC_LOG_THROTTLE_SECONDS = 3.0

COPYBACK_VERIFY_MIN_BYTES = 1024
COPYBACK_BACKUP_ORIGINAL = True
COPYBACK_BACKUP_DIRNAME = "_gemini_before_overwrite"
COPYBACK_ATOMIC = True
EVENT_MARKER = "__GEMINI_EVENT__"
FINAL_MIN_MB = 2.05
COMPACT_UI = True  # v1.8: chỉ đổi giao diện sidebar, giữ nguyên engine v1.7.
# v134.8: giữ chia job ban đầu như cũ; chỉ khi tài khoản xong sớm mới nhận bớt job CHƯA CHẠY của tài khoản còn bận.
FLOW_POLICY_FAILOVER_ERROR_TYPES = {"FlowGenerationFailed"}
# v135.6: tránh retry/chuyển tài khoản vô hạn khi lỗi nằm ở ảnh/prompt/job.
POLICY_MAX_ACCOUNTS_PER_JOB = int(os.environ.get("FLOW_POLICY_MAX_ACCOUNTS_PER_JOB", "8") or 8)
QUEUE_SPILLOVER_THRESHOLD = int(os.environ.get("GEMINI_QUEUE_SPILLOVER_THRESHOLD", "2") or 2)
POLICY_FOLDER_FAST_SKIP_THRESHOLD = int(os.environ.get("FLOW_POLICY_FOLDER_FAST_SKIP_THRESHOLD", "3") or 3)
WORK_STEAL_MIN_RESERVED = int(os.environ.get("FLOW_WORK_STEAL_MIN_RESERVED", "2") or 2)
ACCOUNT_ERROR_COOLDOWN_SECONDS = int(os.environ.get("FLOW_ACCOUNT_ERROR_COOLDOWN_SECONDS", "90") or 90)
ACCOUNT_POLICY_FAIL_COOLDOWN_THRESHOLD = int(os.environ.get("FLOW_ACCOUNT_POLICY_FAIL_COOLDOWN_THRESHOLD", "999999") or 999999)
ACCOUNT_GENERIC_FAIL_COOLDOWN_THRESHOLD = int(os.environ.get("FLOW_ACCOUNT_GENERIC_FAIL_COOLDOWN_THRESHOLD", "3") or 3)
ACCOUNT_COOLDOWN_MIN_SECONDS = int(os.environ.get("FLOW_ACCOUNT_COOLDOWN_MIN_SECONDS", "30") or 30)
ACCOUNT_COOLDOWN_MAX_SECONDS = int(os.environ.get("FLOW_ACCOUNT_COOLDOWN_MAX_SECONDS", "180") or 180)
WORK_STEAL_TARGET_BATCH = int(os.environ.get("FLOW_WORK_STEAL_TARGET_BATCH", "8") or 8)

# v8.0: Account pool auto-rotate for Gemini-only throughput.
ACCOUNT_ROTATE_MIN_IMAGES = int(os.environ.get("GEMINI_ROTATE_IMAGES_MIN", "4") or 4)
ACCOUNT_ROTATE_MAX_IMAGES = int(os.environ.get("GEMINI_ROTATE_IMAGES_MAX", "5") or 5)
ACCOUNT_ROTATE_POOL_PER_WORKER = int(os.environ.get("GEMINI_ROTATE_POOL_PER_WORKER", "1") or 1)
# v8.2: chống crash/thoát tool khi đăng nhập ngầm quá nhiều Chrome cùng lúc.
ACCOUNT_POOL_LOGIN_PARALLEL = int(os.environ.get("GEMINI_POOL_LOGIN_PARALLEL", "3") or 3)  # v12.61: chỉ login 1 account/lượt; ưu tiên dùng lại profile đã đăng nhập
ACCOUNT_POOL_LOGIN_STAGGER_SECONDS = float(os.environ.get("GEMINI_POOL_LOGIN_STAGGER_SECONDS", "0.10") or 0.10)  # v12.1: login đã chia theo wave, chỉ lệch rất nhẹ
FIRST_RUN_BOOTSTRAP_WORKERS = int(os.environ.get("GEMINI_FIRST_RUN_BOOTSTRAP_WORKERS", "8") or 8)
# v12.91: không chờ đủ toàn bộ worker login xong mới vẽ. Account nào login/profile OK trước thì chạy trước,
# các account còn lại vẫn login/check nền song song để tối ưu thời gian.
FIRST_RUN_START_AS_SOON_AS_READY = str(os.environ.get("GEMINI_START_AS_SOON_AS_READY", "1")).strip().lower() not in ("0", "false", "no", "off")
FIRST_RUN_LOGIN_BARRIER_TIMEOUT = float(os.environ.get("GEMINI_FIRST_RUN_LOGIN_BARRIER_TIMEOUT", "1200") or 1200)
BACKGROUND_BOOTSTRAP_20_ENABLED = str(os.environ.get("GEMINI_BACKGROUND_BOOTSTRAP_20", "0")).strip().lower() not in ("0", "false", "no", "off")
BACKGROUND_BOOTSTRAP_DELAY_SECONDS = float(os.environ.get("GEMINI_BACKGROUND_BOOTSTRAP_DELAY_SECONDS", "0") or 0)
RUN_READY_ONLY_NO_LOGIN = str(os.environ.get("GEMINI_RUN_READY_ONLY_NO_LOGIN", "0")).strip().lower() in ("1", "true", "yes", "on")

START_WAVE_SIZE = int(os.environ.get("GEMINI_START_WAVE_SIZE", "8") or 8)  # v12.1: ví dụ 8 luồng thì 5 luồng đầu chạy ngay
START_WAVE_DELAY_SECONDS = float(os.environ.get("GEMINI_START_WAVE_DELAY_SECONDS", "0.8") or 0.8)  # v12.1: luồng 6+ chạy sau 2-3s
START_WAVE_INNER_STAGGER_SECONDS = float(os.environ.get("GEMINI_START_WAVE_INNER_STAGGER_SECONDS", "0.05") or 0.05)

# Colors - v53: compact high-contrast professional slate theme, easier to read.
BG = "#111827"
PANEL = "#1f2937"
CARD = "#243244"
CARD_2 = "#172033"
BORDER = "#42526b"
FG = "#f8fafc"
SUB = "#d9e6f7"
MUTED = "#a8b7cc"
BLUE = "#3b82f6"
GREEN = "#22c55e"
RED = "#ef4444"
YELLOW = "#facc15"
ORANGE = "#fb923c"


def now_ts():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def normalize_path(p):
    return os.path.normpath(os.path.expandvars(os.path.expanduser(str(p).strip().strip('"'))))


def safe_mkdir(path):
    Path(path).mkdir(parents=True, exist_ok=True)
    return Path(path)


def _app_storage_dir():
    try:
        if getattr(sys, "frozen", False):
            return Path(sys.executable).resolve().parent
        return Path(__file__).resolve().parent
    except Exception:
        return Path.cwd()


def _hide_own_console_window():
    """Ẩn cửa sổ cmd của chính tool nếu chạy bằng .bat/python.exe.
    GUI vẫn chạy bình thường; chỉ tránh cửa sổ đen nhảy lên màn hình.
    """
    if os.environ.get("FLOW_SHOW_CONSOLE", "0") == "1":
        return False
    if os.name != "nt":
        return False
    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        hwnd = kernel32.GetConsoleWindow()
        if hwnd:
            SW_HIDE = 0
            user32.ShowWindow(hwnd, SW_HIDE)
            return True
    except Exception:
        pass
    return False


def _make_no_window_startupinfo():
    """StartupInfo dùng cho subprocess trên Windows để không bật cmd con."""
    if os.name != "nt":
        return None
    try:
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        return si
    except Exception:
        return None


def _no_window_creationflags():
    if os.name != "nt":
        return 0
    try:
        return int(getattr(subprocess, "CREATE_NO_WINDOW", 0) or 0)
    except Exception:
        return 0


def _storage_dir_candidates():
    items = []
    try:
        items.append(_app_storage_dir())
    except Exception:
        pass
    try:
        items.append(Path.cwd())
    except Exception:
        pass
    try:
        local = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        if local:
            items.append(Path(local) / "FlowFastParallelDashboardClean")
    except Exception:
        pass
    try:
        items.append(Path.home() / ".gemini_fast_parallel_dashboard_clean")
    except Exception:
        pass
    unique, seen = [], set()
    for item in items:
        try:
            r = str(Path(item).resolve())
        except Exception:
            r = str(item)
        if r not in seen:
            seen.add(r)
            unique.append(Path(r))
    return unique


def _is_dir_writable(folder: Path):
    try:
        folder.mkdir(parents=True, exist_ok=True)
        probe = folder / ".__state_write_test__.tmp"
        with open(probe, "w", encoding="utf-8") as f:
            f.write("ok")
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        try:
            probe.unlink()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _primary_persist_path():
    name = "gemini_fast_parallel_dashboard_clean_state.json"
    for folder in _storage_dir_candidates():
        if _is_dir_writable(folder):
            return folder / name
    return Path.cwd() / name


def _secondary_persist_paths(primary_path: Path):
    name = primary_path.name
    out = []
    for folder in _storage_dir_candidates():
        cand = folder / name
        try:
            if cand.resolve() == primary_path.resolve():
                continue
        except Exception:
            if str(cand) == str(primary_path):
                continue
        out.append(cand)
    return out


def _legacy_persist_candidates():
    candidates = []
    try:
        candidates.append(Path(__file__).resolve().with_suffix(".json"))
    except Exception:
        pass
    for base in _storage_dir_candidates():
        try:
            candidates.extend(sorted(base.glob("gemini_fast_parallel_dashboard_clean*.json"), key=lambda x: x.stat().st_mtime, reverse=True))
        except Exception:
            pass
    unique, seen = [], set()
    for c in candidates:
        try:
            r = str(c.resolve())
        except Exception:
            r = str(c)
        if r not in seen:
            seen.add(r)
            unique.append(Path(r))
    return unique


def _load_legacy_helpers():
    """Load helper functions from the newest non-Qt Tk dashboard file if present."""
    here = Path(__file__).resolve().parent
    candidates = []
    for p in here.glob("gemini_fast_parallel_dashboard_clean_fixed_v*.py"):
        name = p.name.lower()
        if "pyside" in name or "qt" in name or p.resolve() == Path(__file__).resolve():
            continue
        m = re.search(r"fixed_v(\d+)", p.name, re.I)
        ver = int(m.group(1)) if m else -1
        candidates.append((ver, p))
    candidates.sort(reverse=True, key=lambda x: x[0])
    for _ver, path in candidates:
        try:
            spec = importlib.util.spec_from_file_location("_gemini_legacy_dashboard_helpers", str(path))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)  # type: ignore[union-attr]
            return mod, path
        except Exception:
            continue
    return None, None


LEGACY, LEGACY_PATH = _load_legacy_helpers()


def _legacy_func(name, default=None):
    if LEGACY is not None and hasattr(LEGACY, name):
        return getattr(LEGACY, name)
    return default


# Prefer battle-tested helpers from v50/v49. Fallbacks keep this file usable enough even without v50.
scan_jobs = _legacy_func("scan_jobs")
find_thumbnail_jpg_files = _legacy_func("find_thumbnail_jpg_files")
restore_original_thumbnail_set = _legacy_func("restore_original_thumbnail_set")
copy_job_for_worker = _legacy_func("copy_job_for_worker")
clone_profile_fast = _legacy_func("clone_profile_fast")
sync_profile_fast = _legacy_func("sync_profile_fast")
check_gemini_logged_in = _legacy_func("check_gemini_logged_in")
auto_login_gemini = _legacy_func("auto_login_gemini")


if scan_jobs is None:
    def _find_nearest_logo_folder_for_job(job_file: Path, root: Path):
        """Tìm thư mục cha gần nhất có logo2.png/logo.png khi người dùng chọn thư mục tổng."""
        logo_names = ("logo2.png", "logo.png")
        try:
            root = root.resolve()
            cur = job_file.parent.resolve()
        except Exception:
            cur = job_file.parent
        while True:
            for name in logo_names:
                cand = cur / name
                if cand.exists() and cand.is_file():
                    return cur, cand
            try:
                if cur == root or root not in cur.parents:
                    break
            except Exception:
                if str(cur) == str(root):
                    break
            parent = cur.parent
            if parent == cur:
                break
            cur = parent
        return root, None

    def _direct_child_parent(root: Path, path: Path):
        """Trả về thư mục con cấp 1 của root chứa path; dùng để log số thư mục cha khi quét thư mục tổng."""
        try:
            rel = path.resolve().relative_to(root.resolve())
            if len(rel.parts) >= 2:
                return str(root / rel.parts[0])
        except Exception:
            pass
        return str(root)

    def scan_jobs(root_folder, size_limit_mb=SIZE_LIMIT_MB, logo_path=None):
        """Quét nhanh đệ quy thumbnail-original-*-final.
        V55: dùng os.walk có prune thư mục + cache logo theo folder thay cho Path.rglob('*').
        Điều này tránh stat/is_file trên mọi entry không liên quan và giảm mạnh I/O với cây thư mục lớn.
        """
        root = Path(normalize_path(root_folder))
        jobs, skipped = [], 0
        if not root.exists():
            return jobs, skipped
        thumb_re = re.compile(r"^thumbnail-original-(\d+)-final\.(png|jpg|jpeg|webp)$", re.I)
        ignore_names = {"_debug", "_v11_dashboard_runs", "_simple_parallel_runs", "outputs", "__pycache__"}
        explicit_logo = Path(normalize_path(logo_path)) if logo_path else None
        explicit_logo_ok = bool(explicit_logo and explicit_logo.exists())
        logo_names = ("logo.png", "logo.jpg", "logo.jpeg", "logo.webp")
        logo_cache = {}
        root_resolved = root.resolve()

        def nearest_logo_for_dir(folder: Path):
            key = str(folder)
            cached = logo_cache.get(key, None)
            if key in logo_cache:
                return cached
            cur = folder
            found_parent, found_logo = root, None
            while True:
                ckey = str(cur)
                if ckey in logo_cache:
                    found_parent, found_logo = logo_cache[ckey]
                    break
                for name in logo_names:
                    cand = cur / name
                    if cand.is_file():
                        found_parent, found_logo = cur, cand
                        break
                if found_logo is not None:
                    break
                try:
                    if cur.resolve() == root_resolved or root_resolved not in cur.resolve().parents:
                        break
                except Exception:
                    if str(cur) == str(root):
                        break
                parent = cur.parent
                if parent == cur:
                    break
                cur = parent
            logo_cache[key] = (found_parent, found_logo)
            return found_parent, found_logo

        for dirpath, dirnames, filenames in os.walk(root):
            # prune ngay từ os.walk để không duyệt cây output/debug nặng
            dirnames[:] = [d for d in dirnames if d.lower() not in ignore_names]
            folder = Path(dirpath)
            matches = [name for name in filenames if thumb_re.match(name)]
            if not matches:
                continue
            parent_root, auto_logo = nearest_logo_for_dir(folder)
            if auto_logo is not None:
                logo_for_job = str(auto_logo)
            elif explicit_logo_ok:
                logo_for_job = str(explicit_logo)
            else:
                logo_for_job = ""
            direct_parent = _direct_child_parent(root, folder / matches[0])
            for name in matches:
                path = folder / name
                try:
                    size_mb = path.stat().st_size / (1024 * 1024)
                except Exception:
                    continue
                job = {
                    "image_path": str(path),
                    "filename": path.name,
                    "size_mb": size_mb,
                    "status": "queued",
                    "note": "",
                    "worker": "",
                    "scan_root": str(root),
                    "parent_root": str(parent_root),
                    "direct_parent_root": direct_parent,
                    "logo_path": logo_for_job,
                }
                if size_mb > size_limit_mb:
                    job["status"] = "skipped"
                    job["note"] = f"Bỏ qua do > {size_limit_mb:.1f}MB"
                    skipped += 1
                jobs.append(job)
        jobs.sort(key=lambda x: (str(x.get("direct_parent_root") or "").lower(), str(x.get("image_path") or "").lower()))
        return jobs, skipped


if find_thumbnail_jpg_files is None:
    def find_thumbnail_jpg_files(root_folder: Path):
        results = []
        for dirpath, _, filenames in os.walk(root_folder):
            for name in filenames:
                if name.lower() == "thumbnail.jpg":
                    results.append(Path(dirpath) / name)
        return results


if restore_original_thumbnail_set is None:
    def _png_bytes_of_image(img):
        buf = BytesIO()
        img.save(buf, format="PNG", optimize=True, compress_level=9)
        return buf.getvalue()

    def _make_png_under_limit(src_img, max_bytes):
        src_img = src_img.convert("RGB")
        best_data, best_size = None, None
        for scale in [1.00, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70, 0.65, 0.60]:
            working = src_img if scale == 1.0 else src_img.resize((max(1, int(src_img.width * scale)), max(1, int(src_img.height * scale))), Image.Resampling.LANCZOS)
            data = _png_bytes_of_image(working)
            size = len(data)
            if best_size is None or size < best_size:
                best_data, best_size = data, size
            if size <= max_bytes:
                return data
            for colors in [256, 192, 128, 96, 64, 48, 32, 24, 16, 8]:
                pal = working.quantize(colors=colors, method=Image.Quantize.MEDIANCUT)
                data = _png_bytes_of_image(pal)
                size = len(data)
                if best_size is None or size < best_size:
                    best_data, best_size = data, size
                if size <= max_bytes:
                    return data
        return best_data

    def restore_original_thumbnail_set(thumbnail_path: Path):
        out_dir = thumbnail_path.parent
        with Image.open(thumbnail_path) as img:
            png_data = _make_png_under_limit(img, RESTORE_MAX_BYTES)
        thumb_re = re.compile(r"^thumbnail-original-(\d+)-final\.(png|jpg|jpeg|webp)$", re.I)
        existing = [c for c in out_dir.iterdir() if c.is_file() and thumb_re.match(c.name)]
        if not existing:
            raise FileNotFoundError(f"Không tìm thấy file thumbnail-original-*-final trong {out_dir}")
        existing.sort(key=lambda p: int(thumb_re.match(p.name).group(1)) if thumb_re.match(p.name) else 999999)
        for out_path in existing:
            with open(out_path, "wb") as f:
                f.write(png_data)
        return len(png_data) / 1024.0, existing


if copy_job_for_worker is None:
    def copy_job_for_worker(worker_jobs_root, original_path, source_root):
        original = Path(original_path)
        source_root = Path(normalize_path(source_root))
        try:
            rel = original.relative_to(source_root)
        except Exception:
            rel = Path(original.name)
        target = Path(worker_jobs_root) / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, target)
        return str(target)


if clone_profile_fast is None:
    def clone_profile_fast(src_profile, dst_profile):
        src_profile = Path(src_profile)
        dst_profile = Path(dst_profile)
        if dst_profile.exists():
            shutil.rmtree(dst_profile, ignore_errors=True)
        skip_names = {"Cache", "Code Cache", "GPUCache", "ShaderCache", "GrShaderCache", "DawnCache", "Crashpad", "CrashpadMetrics", "blob_storage"}
        def ignore(_dirpath, names):
            out = []
            for name in names:
                if name in skip_names or name.lower().endswith((".tmp", ".log")):
                    out.append(name)
            return out
        shutil.copytree(src_profile, dst_profile, ignore=ignore)


if sync_profile_fast is None:
    def sync_profile_fast(src_profile, dst_profile):
        src_profile, dst_profile = Path(src_profile), Path(dst_profile)
        if not src_profile.exists():
            return 0
        skip_names = {"Cache", "Code Cache", "GPUCache", "ShaderCache", "GrShaderCache", "DawnCache", "Crashpad", "CrashpadMetrics", "blob_storage"}
        copied = 0
        for root, dirs, files in os.walk(src_profile):
            rel = Path(root).relative_to(src_profile)
            dirs[:] = [d for d in dirs if d not in skip_names]
            target_dir = dst_profile / rel
            target_dir.mkdir(parents=True, exist_ok=True)
            for name in files:
                if name in skip_names or name.lower().endswith((".tmp", ".log")):
                    continue
                try:
                    shutil.copy2(Path(root) / name, target_dir / name)
                    copied += 1
                except Exception:
                    pass
        return copied


# ---------- v54: hidden account check + stable login helpers ----------
CHECK_HEADLESS_FIRST = True
CHECK_USE_PROFILE_CLONE = True       # Không đụng trực tiếp profile gốc khi kiểm tra, giảm hỏng session/cookies.
CHECK_SEQUENTIAL_ALL = False         # v57: Kiểm tra tất cả chạy song song.
CHECK_ALL_PARALLEL_LIMIT = 12         # chạy cùng lúc tối đa 12 account để tránh quá tải máy.
CHECK_NONHEADLESS_FALLBACK = False    # v57: tắt fallback Chrome thường để KHÔNG còn cửa sổ đen nhảy lên màn hình khi kiểm tra.
CHECK_CLONE_ROOT_NAME = "_qt_check_profiles"


def _profile_has_login_data(profile_dir):
    p = Path(profile_dir)
    return any((p / x).exists() for x in ("Default", "Local State", "First Run"))


def _qt_check_clone(profile_dir):
    """Clone profile sang thư mục tạm để check không khóa/không làm bẩn profile gốc."""
    src = Path(profile_dir)
    root = _app_storage_dir() / CHECK_CLONE_ROOT_NAME
    root.mkdir(parents=True, exist_ok=True)
    dst = root / f"check_{src.name}_{now_ts()}_{os.getpid()}_{threading.get_ident()}"
    clone_profile_fast(src, dst)
    return dst


def _qt_cleanup_tree(path):
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


def _qt_descendant_pids(root_pid):
    if not root_pid:
        return set()
    out = {int(root_pid)}
    if psutil is None:
        return out
    try:
        proc = psutil.Process(int(root_pid))
        for ch in proc.children(recursive=True):
            try:
                out.add(int(ch.pid))
            except Exception:
                pass
    except Exception:
        pass
    return out


def _qt_enum_visible_windows_for_pids(pids):
    if os.name != "nt" or not pids:
        return []
    try:
        user32 = ctypes.windll.user32
    except Exception:
        return []
    wins = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def _cb(hwnd, _lparam):
        try:
            if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
                return True
            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if int(pid.value) not in pids:
                return True
            wins.append(hwnd)
        except Exception:
            pass
        return True

    user32.EnumWindows(EnumWindowsProc(_cb), 0)
    return wins


def _qt_hide_process_windows(root_pid, seconds=4.0):
    """Đẩy cửa sổ Chrome automation xuống taskbar nếu phải fallback non-headless."""
    if os.name != "nt" or not root_pid:
        return
    end = time.time() + float(seconds)
    while time.time() < end:
        try:
            pids = _qt_descendant_pids(root_pid)
            for hwnd in _qt_enum_visible_windows_for_pids(pids):
                _qt_minimize_hwnd_no_activate(hwnd)
        except Exception:
            pass
        time.sleep(0.07)


def _qt_minimize_hwnd_no_activate(hwnd):
    """Minimize cửa sổ mà không kéo nó lên foreground. Giữ nó ở taskbar, không SW_HIDE."""
    if os.name != "nt" or not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        SW_SHOWMINNOACTIVE = 7
        SW_MINIMIZE = 6
        HWND_BOTTOM = 1
        SWP_NOSIZE = 0x0001
        SWP_NOMOVE = 0x0002
        SWP_NOACTIVATE = 0x0010
        user32.ShowWindow(hwnd, SW_SHOWMINNOACTIVE)
        user32.SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
        user32.ShowWindow(hwnd, SW_MINIMIZE)
        return True
    except Exception:
        return False



def _qt_move_hwnd_offscreen_no_activate(hwnd):
    """Đưa Chrome portable ra ngoài màn hình, không activate và không minimize.
    v112: nếu Chrome khởi động minimized để chống nháy, restore nó ở ngoài màn hình
    để Flow vẫn render upload preview/menu.
    """
    if os.name != "nt" or not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        HWND_BOTTOM = 1
        SW_SHOWNOACTIVATE = 4
        SWP_NOSIZE = 0x0001
        SWP_NOACTIVATE = 0x0010
        SWP_NOOWNERZORDER = 0x0200
        SWP_SHOWWINDOW = 0x0040
        user32.SetWindowPos(hwnd, HWND_BOTTOM, -32000, -32000, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_SHOWWINDOW)
        user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
        user32.SetWindowPos(hwnd, HWND_BOTTOM, -32000, -32000, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_SHOWWINDOW)
        return True
    except Exception:
        return False


def _qt_keep_portable_chrome_offscreen_once(chrome_binary):
    count = 0
    for hwnd in _qt_enum_visible_portable_chrome_windows(chrome_binary):
        if _qt_move_hwnd_offscreen_no_activate(hwnd):
            count += 1
    return count


def _qt_get_hwnd_pid(hwnd):
    if os.name != "nt" or not hwnd:
        return None
    try:
        user32 = ctypes.windll.user32
        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)
    except Exception:
        return None

def _qt_is_portable_chrome_hwnd(hwnd, chrome_binary):
    if os.name != "nt" or not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
            return False
        pid = _qt_get_hwnd_pid(hwnd)
        if not pid:
            return False
        if psutil is not None:
            try:
                chrome_bin = str(Path(chrome_binary).resolve()).lower()
                p = psutil.Process(pid)
                exe = str(p.exe() or "").lower()
                name = str(p.name() or "").lower()
                return exe == chrome_bin or (name == "chrome.exe" and "chrome-win64" in exe and Path(exe).name == "chrome.exe")
            except Exception:
                return False
    except Exception:
        return False
    return False


def _qt_enum_visible_portable_chrome_windows(chrome_binary):
    """Tìm mọi cửa sổ Chrome portable do tool mở để ép xuống taskbar.
    Không động tới Chrome cá nhân nếu exe path khác chrome_binary.
    """
    if os.name != "nt":
        return []
    try:
        chrome_bin = str(Path(chrome_binary).resolve()).lower()
        user32 = ctypes.windll.user32
    except Exception:
        return []
    wins = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def _cb(hwnd, _lparam):
        try:
            if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
                return True
            if _qt_is_portable_chrome_hwnd(hwnd, chrome_binary):
                wins.append(hwnd)
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(EnumWindowsProc(_cb), 0)
    except Exception:
        pass
    return wins


def _qt_minimize_portable_chrome_windows(chrome_binary):
    count = 0
    for hwnd in _qt_enum_visible_portable_chrome_windows(chrome_binary):
        if _qt_minimize_hwnd_no_activate(hwnd):
            count += 1
    return count


FAKE_EMAIL_EXACT = {
    "googlers@google.com",
    "google@google.com",
    "noreply@google.com",
}
FAKE_EMAIL_PARTS = (
    "gstatic", "googleusercontent", "schema.org", "example.com", "wixpress",
    "noreply", "no-reply", "donotreply", "@chromium.org", "@developer.gserviceaccount.com",
    "@2x.png", "@1x.png", "@media", "@font",
)


def _qt_clean_email(mail):
    mail = str(mail or "").strip().strip("'\"<>;:,()[]{}").lower()
    if not re.fullmatch(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", mail or ""):
        return ""
    if mail in FAKE_EMAIL_EXACT:
        return ""
    if any(part in mail for part in FAKE_EMAIL_PARTS):
        return ""
    return mail


def _qt_collect_emails_from_obj(obj, out, depth=0):
    if depth > 10:
        return
    try:
        if isinstance(obj, dict):
            for k, v in obj.items():
                lk = str(k).lower()
                if lk in ("email", "emailaddress", "email_address", "user_email", "account_email", "last_email", "username", "user_name", "gaia_email"):
                    em = _qt_clean_email(v)
                    if em and em not in out:
                        out.append(em)
                _qt_collect_emails_from_obj(v, out, depth + 1)
        elif isinstance(obj, list):
            for v in obj:
                _qt_collect_emails_from_obj(v, out, depth + 1)
        elif isinstance(obj, str):
            for m in re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", obj, flags=re.I):
                em = _qt_clean_email(m)
                if em and em not in out:
                    out.append(em)
    except Exception:
        pass


def _qt_profile_email_candidates(profile_dir):
    out = []
    base = Path(profile_dir)
    candidates = [
        base / "Local State",
        base / "Default" / "Preferences",
        base / "Default" / "Secure Preferences",
        base / "Profile 1" / "Preferences",
        base / "Profile 1" / "Secure Preferences",
    ]
    for p in candidates:
        try:
            if not p.is_file() or p.stat().st_size > 20 * 1024 * 1024:
                continue
            data = json.load(open(p, "r", encoding="utf-8", errors="ignore"))
            _qt_collect_emails_from_obj(data, out)
        except Exception:
            try:
                raw = p.read_text(encoding="utf-8", errors="ignore")
                _qt_collect_emails_from_obj(raw, out)
            except Exception:
                pass
    # Ưu tiên mail người dùng phổ biến, bỏ các mail kỹ thuật còn sót.
    return out


def _qt_best_profile_email(profile_dir):
    emails = _qt_profile_email_candidates(profile_dir)
    return emails[0] if emails else ""


def _qt_extract_email_from_driver(drv):
    # Chỉ lấy email từ text/thuộc tính hiển thị, không tin page_source thô vì hay chứa mail mẫu googlers@google.com.
    sources = []
    for getter in (
        lambda: drv.execute_script("return document.body ? document.body.innerText : '';"),
        lambda: drv.title,
        lambda: drv.current_url,
    ):
        try:
            sources.append(str(getter() or ""))
        except Exception:
            pass
    try:
        attrs = drv.execute_script(r"""
            const out = [];
            document.querySelectorAll('[aria-label],[title],[data-email],[data-identifier]').forEach(el => {
                ['aria-label','title','data-email','data-identifier'].forEach(a => {
                    const v = el.getAttribute(a);
                    if (v && v.includes('@')) out.push(v);
                });
            });
            return out.join('\n');
        """)
        sources.append(str(attrs or ""))
    except Exception:
        pass
    found = []
    text = "\n".join(sources)
    for m in re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text, flags=re.I):
        mail = _qt_clean_email(m)
        if mail and mail not in found:
            found.append(mail)
    return (found or [""])[0]


def _qt_body_text(drv):
    try:
        return (drv.find_element("tag name", "body").text or "").lower()
    except Exception:
        return ""


def _qt_has_visible_any(drv, selectors):
    for css in selectors:
        try:
            for el in drv.find_elements("css selector", css):
                try:
                    if el.is_displayed():
                        return True
                except Exception:
                    pass
        except Exception:
            pass
    return False


def _qt_gemini_ready(drv, body):
    """v109: checker xanh cho Flow, không còn dùng marker Gemini nữa.
    Flow có thể đang ở trang thư viện/project list chứ chưa có prompt box,
    nên chỉ cần thấy UI Flow đã đăng nhập: Dự án mới, thư viện, sidebar, chip model, nút add_2, v.v.
    """
    body = body or ""
    ready_markers = [
        "dự án mới", "du an moi",
        "tất cả nội dung nghe nhìn", "tat ca noi dung nghe nhin",
        "hình ảnh", "hinh anh",
        "nhân vật", "nhan vat",
        "cảnh", "canh",
        "tệp tải lên", "tep tai len",
        "bạn muốn tạo gì", "ban muon tao gi",
        "tác nhân", "tac nhan",
        "nano banana",
        "flow tv",
    ]
    if any(x in body for x in ready_markers):
        return True

    try:
        url = (drv.current_url or "").lower()
    except Exception:
        url = ""
    if "/fx/" in url and "labs.google" in url:
        try:
            ok = drv.execute_script(r"""
                function visible(el){
                    const r=el.getBoundingClientRect();
                    const st=getComputedStyle(el);
                    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
                }
                const text = (document.body && document.body.innerText || '').toLowerCase();
                if (text.includes('dự án mới') || text.includes('tất cả nội dung nghe nhìn') ||
                    text.includes('bạn muốn tạo gì') || text.includes('nano banana')) return true;

                const els=[...document.querySelectorAll('button,[role="button"],input[type="file"],textarea,div[role="textbox"],[contenteditable="true"],a')].filter(visible);
                return els.some(el=>{
                    const t=((el.innerText||el.textContent||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.outerHTML||'')).toLowerCase();
                    return t.includes('add_2') || t.includes('dự án mới') || t.includes('tạo') ||
                           t.includes('nano banana') || t.includes('upload') || t.includes('tải lên') ||
                           t.includes('arrow_forward') || t.includes('hình ảnh') || t.includes('nhân vật') ||
                           t.includes('tất cả nội dung');
                });
            """)
            if ok:
                return True
        except Exception:
            pass

    return _qt_has_visible_any(drv, [
        "input[type='file']",
        "textarea[aria-label]",
        "div[role='textbox']",
        "div[contenteditable='true']",
        "button[aria-haspopup='menu']",
        "button[aria-label*='Tải']",
        "button[aria-label*='tải']",
    ])



def _qt_is_google_password_step(url, body):
    """Trang nhập mật khẩu Google cũng nằm dưới /challenge/pwd. Đây là bước login bình thường, không phải checkpoint."""
    hay = (str(url or "") + "\n" + str(body or "")).lower()
    if "challenge/pwd" in hay:
        return True
    password_markers = (
        "enter your password", "show password", "forgot password",
        "nhập mật khẩu", "hiện mật khẩu", "quên mật khẩu", "mật khẩu"
    )
    return ("accounts.google.com" in hay) and any(k in hay for k in password_markers)


def _qt_is_google_account_verify_required(url, body):
    """Google checkpoint/verify account: không cố đăng nhập trong batch, chuyển account khác.
    Lưu ý: /challenge/pwd là trang nhập mật khẩu bình thường, không được đánh nhầm là verify.
    """
    hay = (str(url or "") + "\n" + str(body or "")).lower()
    # v12.93: trang accounts.google.com/signin/rejected / "Không thể đăng nhập cho bạn" là account bị Google từ chối sau khi verify recovery email.
    # Phải bỏ account này và chuyển account khác, không tiếp tục chờ/login.
    if ("signin/rejected" in hay) or ("/rejected" in hay) or ("không thể đăng nhập cho bạn" in hay) or ("google không thể xác minh" in hay) or ("couldn't sign you in" in hay) or ("could not sign you in" in hay):
        return True
    if _qt_is_google_password_step(url, body):
        return False
    # /challenge/kpe là bước nhập email khôi phục hợp lệ, không phải checkpoint cần bỏ account.
    try:
        if _qt_is_recovery_email_challenge_page(url, body):
            return False
    except Exception:
        pass
    # /challenge/selection vẫn có thể là bước hợp lệ nếu có lựa chọn
    # "Xác nhận email khôi phục của bạn" (data-challengetype=12). Không bỏ account trước khi thử chọn mục này.
    if ("challenge/selection" in hay) and (("xác nhận email khôi phục" in hay) or ("xac nhan email khoi phuc" in hay) or ("data-challengetype=\"12\"" in hay) or ("data-challengetype='12'" in hay)):
        return False
    keys = (
        "verify it", "verify it\'s you", "verify it’s you", "verify your identity",
        "signin/rejected", "/rejected?", "không thể đăng nhập cho bạn", "khong the dang nhap cho ban",
        "google không thể xác minh rằng tài khoản này là của bạn",
        "google khong the xac minh rang tai khoan nay la cua ban",
        "couldn't sign you in", "couldn’t sign you in", "could not sign you in",
        "google couldn't verify that this account belongs to you",
        "google could not verify that this account belongs to you",

        "confirm it's you", "confirm it’s you", "check if it's really you", "check if it’s really you",
        "this helps show that this account really belongs to you",
        "choose how you want to sign in", "try another way",
        "xác minh danh tính", "xác minh đó là bạn", "xác minh bạn",
        "để giữ an toàn cho tài khoản", "chọn cách bạn muốn đăng nhập", "thử cách khác",
        "xác minh thiết bị", "xác minh robot", "rô-bốt", "recaptcha", "unusual traffic"
    )
    if any(k in hay for k in keys):
        return True
    # Chỉ coi URL challenge là checkpoint khi KHÔNG phải trang password và có dấu hiệu challenge thật.
    challenge_url_keys = ("signin/rejected", "/rejected", "challenge/selection", "challenge/recaptcha", "challenge/ipp", "challenge/dp", "challenge/ootp", "challenge/phone")
    return any(k in hay for k in challenge_url_keys)

def _qt_is_account_verify_message(msg):
    low = str(msg or "").lower()
    return any(k in low for k in (
        "account_verify_required", "xác minh danh tính", "google yêu cầu xác minh",
        "verify identity", "verify your identity", "verify it", "challenge", "signin/rejected", "không thể đăng nhập", "google không thể xác minh",
        "xác minh robot", "xác minh thiết bị", "robot/thiết bị", "recaptcha"
    ))

def _qt_not_ready_reason(url, body):
    if _qt_is_google_account_verify_required(url, body):
        return "Google yêu cầu xác minh danh tính tài khoản"
    if "accounts.google.com" in (url or ""):
        return "Chưa đăng nhập Google/Flow"
    checks = [
        ("signin/rejected", "Google từ chối đăng nhập account này"),
        ("không thể đăng nhập", "Google từ chối đăng nhập account này"),
        ("google không thể xác minh", "Google từ chối đăng nhập account này"),
        ("verify it", "Google yêu cầu xác minh lại"),
        ("xác minh", "Google yêu cầu xác minh lại"),
        ("access denied", "Truy cập bị từ chối"),
        ("truy cập bị từ chối", "Truy cập bị từ chối"),
        ("service unavailable", "Flow tạm không khả dụng"),
        ("dịch vụ này không khả dụng", "Flow tạm không khả dụng"),
        ("something went wrong", "Flow báo lỗi tạm thời"),
        ("đã xảy ra lỗi", "Flow báo lỗi tạm thời"),
        ("sign in", "Chưa đăng nhập Google/Flow"),
        ("hãy đăng nhập", "Chưa đăng nhập Google/Flow"),
    ]
    for key, msg in checks:
        if key in body:
            return msg
    return ""


def _qt_gemini_app_ready(drv, body):
    """v6.8: chỉ tích xanh khi đã vào đúng giao diện Gemini có ô prompt/editor.
    Landing page / popup Điều khoản / Chào mừng chưa được coi là OK.
    """
    try:
        url = (drv.current_url or "").lower()
    except Exception:
        url = ""
    if "accounts.google.com" in url:
        return False
    try:
        if _gemini_prompt_editor_ready_driver(drv):
            return True
    except Exception:
        pass
    return False


def _qt_not_ready_reason_gemini(url, body):
    if _qt_is_google_account_verify_required(url, body):
        return "Google yêu cầu xác minh danh tính tài khoản"
    if "accounts.google.com" in (url or ""):
        return "Chưa đăng nhập Google/Gemini"
    checks = [
        ("signin/rejected", "Google từ chối đăng nhập account này"),
        ("không thể đăng nhập", "Google từ chối đăng nhập account này"),
        ("google không thể xác minh", "Google từ chối đăng nhập account này"),
        ("verify it", "Google yêu cầu xác minh lại"),
        ("xác minh", "Google yêu cầu xác minh lại"),
        ("access denied", "Truy cập bị từ chối"),
        ("truy cập bị từ chối", "Truy cập bị từ chối"),
        ("service unavailable", "Gemini tạm không khả dụng"),
        ("dịch vụ này không khả dụng", "Gemini tạm không khả dụng"),
        ("something went wrong", "Gemini báo lỗi tạm thời"),
        ("đã xảy ra lỗi", "Gemini báo lỗi tạm thời"),
        ("sign in", "Chưa đăng nhập Google/Gemini"),
        ("hãy đăng nhập", "Chưa đăng nhập Google/Gemini"),
        ("đăng nhập", "Chưa đăng nhập Google/Gemini"),
    ]
    for key, msg in checks:
        if key in body:
            return msg
    return ""


def _qt_build_check_options(chrome_binary, profile_dir, headless=True, safe=True):
    from selenium import webdriver
    options = webdriver.ChromeOptions()
    options.binary_location = normalize_path(chrome_binary)
    options.add_argument(f"--user-data-dir={normalize_path(profile_dir)}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-component-extensions-with-background-pages")
    options.add_argument("--disable-default-apps")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--remote-debugging-port=0")
    options.add_argument("--password-store=basic")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option('excludeSwitches', ['enable-automation'])
    options.add_experimental_option('useAutomationExtension', False)
    # Offscreen là lớp an toàn nếu headless bị Google/Flow chặn.
    options.add_argument("--start-minimized")
    options.add_argument("--window-position=-32000,-32000")
    options.add_argument("--window-size=1380,1000")
    options.add_argument("--disable-backgrounding-occluded-windows")
    options.add_argument("--disable-renderer-backgrounding")
    if headless:
        options.add_argument("--headless=new")
        options.add_argument("--hide-scrollbars")
        options.add_argument("--disable-gpu")
    else:
        options.add_argument("--start-minimized")
    if safe:
        options.add_argument("--disable-background-networking")
        options.add_argument("--disable-component-update")
        options.add_argument("--disable-features=MediaRouter,OptimizationHints,Translate,ChromeWhatsNewUI,ChromeSigninIntercept,SigninInterceptBubble")
    return options


def _qt_hidden_check_once(chrome_binary, driver_binary, profile_dir, headless=True, use_clone=True, safe=True, stop_event=None):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.by import By

    drv = None
    clone_dir = None
    target_profile = Path(profile_dir)
    try:
        if use_clone:
            clone_dir = _qt_check_clone(profile_dir)
            target_profile = clone_dir
        if stop_event is not None and stop_event.is_set():
            return False, "Đã dừng kiểm tra", ""
        options = _qt_build_check_options(chrome_binary, target_profile, headless=headless, safe=safe)
        _drv_path = Path(driver_binary) if driver_binary else None
        service = None
        if _drv_path is not None and _drv_path.is_file():
            service = Service(normalize_path(_drv_path))
            # v113: ChromeDriver cũng được chạy không console để khi bấm Kiểm tra tất cả không bật cửa sổ đen.
            try:
                service.creation_flags = _no_window_creationflags()
            except Exception:
                pass
            try:
                service.startupinfo = _make_no_window_startupinfo()
            except Exception:
                pass
            drv = webdriver.Chrome(service=service, options=options)
        else:
            drv = webdriver.Chrome(options=options)
        try:
            root_pid = int(drv.service.process.pid)
        except Exception:
            root_pid = None
        if not headless and root_pid:
            threading.Thread(target=_qt_hide_process_windows, args=(root_pid, 5.0), daemon=True).start()
        try:
            drv.set_window_position(-32000, -32000)
            drv.set_window_size(1380, 1000)
        except Exception:
            pass
        drv.get(FLOW_WEB_URL_GUI)
        WebDriverWait(drv, 35).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        last_url = ""
        last_body = ""
        # v67: chỉ dùng email đọc trực tiếp từ trang Flow/Google đang mở để xác nhận xanh.
        # Không lấy email trong file Preferences/Local State làm bằng chứng đăng nhập vì cookie có thể hết hạn
        # hoặc Flow chưa được đăng nhập dù profile vẫn còn lưu mail cũ.
        verified_email = ""
        for _ in range(24):
            if stop_event is not None and stop_event.is_set():
                return False, "Đã dừng kiểm tra", verified_email or ""
            time.sleep(0.85)
            try:
                last_url = (drv.current_url or "").lower()
            except Exception:
                last_url = ""
            last_body = _qt_body_text(drv)
            page_email = _qt_extract_email_from_driver(drv)
            if page_email:
                verified_email = page_email
            reason = _qt_not_ready_reason(last_url, last_body)
            if reason and reason not in ("Flow báo lỗi tạm thời", "Flow tạm không khả dụng"):
                return False, reason, ""
            if _qt_gemini_ready(drv, last_body):
                if verified_email:
                    return True, "Đã đăng nhập Flow • mail thật OK", verified_email
                # Flow không phải lúc nào cũng hiện email trong DOM. Nếu UI Flow đã sẵn sàng thì cho xanh.
                return True, "Đã đăng nhập Flow • OK", ""
        if "accounts.google.com" in last_url:
            return False, "Chưa đăng nhập Google/Flow", ""
        reason = _qt_not_ready_reason(last_url, last_body)
        if ("/fx/" in (last_url or "") and "labs.google" in (last_url or "") and
            not reason and "accounts.google.com" not in (last_url or "")):
            # v109: tránh false yellow khi Flow đã load nhưng DOM chưa hiện marker đủ nhanh.
            return True, "Đã đăng nhập Flow • OK", verified_email or ""
        return False, reason or "Có session Google nhưng Flow chưa sẵn sàng", ""
    finally:
        try:
            if drv:
                drv.quit()
        except Exception:
            pass
        if clone_dir is not None:
            _qt_cleanup_tree(clone_dir)


def _qt_hidden_check_gemini_app_once(chrome_binary, driver_binary, profile_dir, headless=True, use_clone=True, safe=True, stop_event=None):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.by import By
    drv = None
    clone_dir = None
    target_profile = Path(profile_dir)
    try:
        if use_clone:
            clone_dir = _qt_check_clone(profile_dir)
            target_profile = clone_dir
        if stop_event is not None and stop_event.is_set():
            return False, "Đã dừng kiểm tra", ""
        options = _qt_build_check_options(chrome_binary, target_profile, headless=headless, safe=safe)
        _drv_path = Path(driver_binary) if driver_binary else None
        service = None
        if _drv_path is not None and _drv_path.is_file():
            service = Service(normalize_path(_drv_path))
            try: service.creation_flags = _no_window_creationflags()
            except Exception: pass
            try: service.startupinfo = _make_no_window_startupinfo()
            except Exception: pass
            drv = webdriver.Chrome(service=service, options=options)
        else:
            drv = webdriver.Chrome(options=options)
        try:
            drv.set_window_position(-32000, -32000); drv.set_window_size(1380, 1000)
        except Exception: pass
        drv.get(GEMINI_WEB_URL_GUI)
        WebDriverWait(drv, 35).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        last_url = ""; last_body = ""; verified_email = ""
        for _ in range(24):
            if stop_event is not None and stop_event.is_set():
                return False, "Đã dừng kiểm tra", verified_email or ""
            time.sleep(0.85)
            try: last_url = (drv.current_url or "").lower()
            except Exception: last_url = ""
            last_body = _qt_body_text(drv)
            page_email = _qt_extract_email_from_driver(drv)
            if page_email: verified_email = page_email
            reason = _qt_not_ready_reason_gemini(last_url, last_body)
            if reason and reason not in ("Gemini báo lỗi tạm thời", "Gemini tạm không khả dụng"):
                return False, reason, ""
            if _qt_gemini_app_ready(drv, last_body):
                _qt_export_gemini_session_bundle(drv, profile_dir)
                return True, "Đã đăng nhập Gemini • OK", verified_email or ""
        if "accounts.google.com" in last_url:
            return False, "Chưa đăng nhập Google/Gemini", ""
        reason = _qt_not_ready_reason_gemini(last_url, last_body)
        if "gemini.google.com" in (last_url or "") and not reason:
            _qt_export_gemini_session_bundle(drv, profile_dir)
            return True, "Đã đăng nhập Gemini • OK", verified_email or ""
        return False, reason or "Có session Google nhưng Gemini chưa sẵn sàng", ""
    finally:
        try:
            if drv: drv.quit()
        except Exception: pass
        if clone_dir is not None:
            _qt_cleanup_tree(clone_dir)


def qt_hidden_check_flow_logged_in(chrome_binary, driver_binary, profile_dir, stop_event=None):
    profile_dir = Path(profile_dir)
    if not profile_dir.exists() or not _profile_has_login_data(profile_dir):
        return False, "Profile chưa có dữ liệu đăng nhập", ""
    attempts = [
        {"headless": True,  "use_clone": CHECK_USE_PROFILE_CLONE, "safe": True},
        {"headless": True,  "use_clone": CHECK_USE_PROFILE_CLONE, "safe": False},
    ]
    if CHECK_NONHEADLESS_FALLBACK:
        attempts.append({"headless": False, "use_clone": CHECK_USE_PROFILE_CLONE, "safe": True})
    last_error = None
    for cfg in attempts:
        try:
            return _qt_hidden_check_once(chrome_binary, driver_binary, profile_dir, stop_event=stop_event, **cfg)
        except Exception as e:
            last_error = e
            msg = str(e).lower()
            retryable = any(x in msg for x in ("devtoolsactiveport", "chrome failed to start", "session not created", "chrome not reachable", "loader has changed", "timeout", "timed out"))
            if not retryable: break
            time.sleep(0.45)
    return False, f"Lỗi kiểm tra Flow headless: {last_error}", ""


def _qt_try_profile_email_for_display(profile_dir):
    try: return _qt_best_profile_email(profile_dir) or ""
    except Exception: return ""


def qt_hidden_check_gemini_logged_in(chrome_binary, driver_binary, profile_dir, stop_event=None):
    # v6.6 Pure Gemini: chỉ kiểm tra Gemini, không kiểm tra/mở Flow nữa.
    profile_dir = Path(profile_dir)
    if not profile_dir.exists() or not _profile_has_login_data(profile_dir):
        return False, "Profile chưa có dữ liệu đăng nhập", ""
    email_hint = _qt_try_profile_email_for_display(profile_dir)
    try:
        gem_ok, gem_msg, gem_email = _qt_hidden_check_gemini_app_once(
            chrome_binary, driver_binary, profile_dir,
            headless=True, use_clone=CHECK_USE_PROFILE_CLONE, safe=True, stop_event=stop_event
        )
    except Exception as e:
        gem_ok, gem_msg, gem_email = False, f"Lỗi kiểm tra Gemini headless: {e}", ""
    if not gem_ok:
        try:
            gem_ok, gem_msg, gem_email = _qt_hidden_check_gemini_app_once(
                chrome_binary, driver_binary, profile_dir,
                headless=True, use_clone=CHECK_USE_PROFILE_CLONE, safe=False, stop_event=stop_event
            )
        except Exception as e:
            gem_msg = f"Lỗi kiểm tra Gemini headless: {e}"
    email = gem_email or email_hint
    if gem_ok:
        return True, "Gemini OK", email
    return False, f"Gemini chưa OK: {gem_msg}", email


check_gemini_logged_in = qt_hidden_check_gemini_logged_in



# ---------- v3.8 dashboard proxy config ----------
def _dash_proxy_config_path(app_dir):
    try: return Path(app_dir) / "proxy_accounts.txt"
    except Exception: return Path("proxy_accounts.txt")


def _dash_load_proxy_map(app_dir):
    path = _dash_proxy_config_path(app_dir); out = {}
    try:
        if not path.is_file(): return out
        seq = 1
        for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith(";"): continue
            if "=" in line:
                k, v = line.split("=", 1)
                if k.strip() and v.strip(): out[k.strip().lower()] = v.strip()
            else:
                out[f"google_{seq}"] = line; seq += 1
    except Exception:
        pass
    return out


def _dash_load_proxy_entries(app_dir):
    """v5.2: đọc TOÀN BỘ proxy trong proxy_accounts.txt, không chỉ proxy khớp account đang bật.
    Trả về list {key, acc, proxy}; acc chỉ để hiển thị nếu key dạng google_N.
    """
    import re
    mp = _dash_load_proxy_map(app_dir)
    entries = []
    for k, v in (mp or {}).items():
        key = str(k or "").strip().lower()
        m = re.search(r"(\d+)$", key)
        acc = int(m.group(1)) if m else None
        entries.append({"key": key, "acc": acc, "proxy": str(v or "").strip()})
    def _sort(e):
        return (0, int(e["acc"])) if e.get("acc") is not None else (1, str(e.get("key") or ""))
    entries.sort(key=_sort)
    return entries


def _dash_proxy_for_account(app_dir, account_no):
    try:
        mp = _dash_load_proxy_map(app_dir); key = f"google_{int(account_no)}"
        return mp.get(key.lower()) or mp.get(str(int(account_no))) or ""
    except Exception:
        return ""

def _dash_parse_proxy_value(value):
    """Parse proxy dạng ip:port:user:pass hoặc scheme://user:pass@host:port."""
    import re
    from urllib.parse import urlparse
    raw = str(value or "").strip()
    if not raw:
        return None
    scheme = "http"
    host = port = username = password = ""
    try:
        if "://" in raw:
            u = urlparse(raw)
            scheme = (u.scheme or "http").lower()
            host = u.hostname or ""
            port = str(u.port or "")
            username = u.username or ""
            password = u.password or ""
        else:
            parts = raw.split(":")
            if len(parts) >= 4:
                host, port, username = parts[0].strip(), parts[1].strip(), parts[2].strip()
                password = ":".join(parts[3:]).strip()
            elif len(parts) >= 2:
                host, port = parts[0].strip(), parts[1].strip()
        if not host or not port:
            return None
        port_i = int(str(port))
        return {"scheme": scheme, "host": host, "port": port_i, "username": username, "password": password, "raw": raw}
    except Exception:
        return None


def _dash_mask_proxy_value(value):
    px = _dash_parse_proxy_value(value)
    if not px:
        return "-"
    return f"{px.get('host')}:{px.get('port')}"


def _dash_check_proxy_value(value, timeout=8):
    """Kiểm tra proxy bằng TCP + HTTPS Google generate_204 + thử đọc IP ngoài."""
    import socket
    import urllib.request
    import urllib.parse
    px = _dash_parse_proxy_value(value)
    if not px:
        return False, "Sai định dạng proxy", ""
    host = str(px.get("host") or "")
    port = int(px.get("port") or 0)
    try:
        with socket.create_connection((host, port), timeout=min(5, float(timeout))):
            pass
    except Exception as e:
        return False, f"Không mở được TCP {host}:{port} • {type(e).__name__}", ""
    try:
        scheme = px.get("scheme") or "http"
        user = urllib.parse.quote(str(px.get("username") or ""), safe="")
        pwd = urllib.parse.quote(str(px.get("password") or ""), safe="")
        auth = f"{user}:{pwd}@" if user or pwd else ""
        proxy_url = f"{scheme}://{auth}{host}:{port}"
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url}))
        req = urllib.request.Request("https://www.gstatic.com/generate_204", headers={"User-Agent":"Mozilla/5.0"})
        with opener.open(req, timeout=float(timeout)) as resp:
            code = int(getattr(resp, "status", 0) or resp.getcode() or 0)
        if code not in (200, 204):
            return False, f"Google check HTTP {code}", ""
        ip = ""
        try:
            req2 = urllib.request.Request("https://api.ipify.org", headers={"User-Agent":"Mozilla/5.0"})
            with opener.open(req2, timeout=float(timeout)) as resp2:
                ip = (resp2.read(80) or b"").decode("utf-8", "ignore").strip()
        except Exception:
            ip = ""
        return True, "Proxy OK • vào Google được", ip
    except Exception as e:
        msg = str(e)
        if "407" in msg or "Proxy Authentication" in msg:
            return False, "Sai user/pass proxy hoặc proxy yêu cầu auth", ""
        if "timed out" in msg.lower() or "timeout" in msg.lower():
            return False, "Proxy timeout khi vào Google", ""
        return False, f"Proxy không vào được Google • {type(e).__name__}", ""

def _dash_proxy_enabled_default():
    return str(os.environ.get("GEMINI_PROXY_ENABLED", "0")).strip().lower() in ("1", "true", "yes", "on")


def _dash_proxy_raw_list(app_dir):
    """Trả về danh sách proxy hợp lệ từ proxy_accounts.txt theo thứ tự."""
    entries = _dash_load_proxy_entries(app_dir)
    out = []
    for e in entries:
        raw = str(e.get("proxy") or "").strip()
        if raw and _dash_parse_proxy_value(raw):
            out.append(raw)
    return out


def build_persistent_login_args(chrome, profile_dir):
    """Mở Chrome thật để đăng nhập 1 lần, giữ nguyên profile/cookies lâu nhất có thể."""
    return [
        str(chrome),
        f"--user-data-dir={profile_dir}",
        "--profile-directory=Default",
        "--start-maximized",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-notifications",
        "--disable-popup-blocking",
        "--password-store=basic",
        "--disable-session-crashed-bubble",
        "--disable-features=ChromeSigninIntercept,SigninInterceptBubble,AutofillServerCommunication",
        # v7.2 Pure Gemini: chỉ mở Gemini, không mở Flow nữa.
        GEMINI_WEB_URL_GUI,
    ]


# ---------- v6.1: secure Gmail login assist ----------
def _dpapi_protect_text(text):
    """Encrypt text with Windows DPAPI for current Windows user. Fallback uses base64 only if DPAPI unavailable."""
    if os.name != "nt":
        return {"kind": "plain-local-dev", "data": base64.b64encode((text or "").encode("utf-8")).decode("ascii")}
    try:
        import ctypes
        import ctypes.wintypes
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]
        raw = (text or "").encode("utf-8")
        in_buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(len(raw), ctypes.cast(in_buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)):
            raise ctypes.WinError()
        try:
            protected = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
        return {"kind": "dpapi", "data": base64.b64encode(protected).decode("ascii")}
    except Exception as e:
        return {"kind": "plain-fallback", "data": base64.b64encode((text or "").encode("utf-8")).decode("ascii"), "warning": str(e)[:120]}


def _dpapi_unprotect_text(obj):
    if not obj:
        return ""
    kind = obj.get("kind") if isinstance(obj, dict) else ""
    data = obj.get("data") if isinstance(obj, dict) else ""
    if not data:
        return ""
    if kind in ("plain-local-dev", "plain-fallback") or os.name != "nt":
        try:
            return base64.b64decode(data.encode("ascii")).decode("utf-8", "ignore")
        except Exception:
            return ""
    try:
        import ctypes
        import ctypes.wintypes
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]
        protected = base64.b64decode(data.encode("ascii"))
        in_buf = ctypes.create_string_buffer(protected)
        in_blob = DATA_BLOB(len(protected), ctypes.cast(in_buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)):
            raise ctypes.WinError()
        try:
            raw = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)
        return raw.decode("utf-8", "ignore")
    except Exception:
        return ""


def _login_vault_path(app_dir):
    try:
        return Path(app_dir) / "login_vault.json"
    except Exception:
        return Path("login_vault.json")


def _parse_login_import_text(text, start_google=1):
    """Parse login lines.
    Supported formats:
      email<TAB>password
      email<TAB>password<TAB>recovery_email
      google_3<TAB>email<TAB>password
      google_3<TAB>email<TAB>password<TAB>recovery_email
      google_3=email<TAB>password<TAB>recovery_email
      email|password|recovery_email
    Lines without google_N are assigned from the first account row in order.
    """
    out = []
    seq = int(start_google or 1)

    def _add(acc, email, secret_parts):
        email = str(email or "").strip()
        parts = [str(x or "").strip() for x in (secret_parts or [])]
        password = parts[0] if len(parts) >= 1 else ""
        recovery_email = parts[1] if len(parts) >= 2 else ""
        if email and password:
            out.append((int(acc), email, password, recovery_email))

    for raw in (text or "").splitlines():
        line = raw.strip().strip("\ufeff")
        if not line or line.startswith("#"):
            continue
        line = line.replace("\t", "|")
        if "=" in line and line.lower().split("=", 1)[0].strip().startswith("google_"):
            left, rest = line.split("=", 1)
            acc_s = left.strip().lower().replace("google_", "")
            parts = [x.strip() for x in rest.split("|")]
            if len(parts) >= 2 and acc_s.isdigit():
                _add(int(acc_s), parts[0], parts[1:])
            continue
        parts = [x.strip() for x in line.split("|")]
        if len(parts) >= 3 and parts[0].lower().startswith("google_"):
            acc_s = parts[0].lower().replace("google_", "")
            if acc_s.isdigit():
                _add(int(acc_s), parts[1], parts[2:])
            continue
        if len(parts) >= 3 and parts[0].isdigit():
            _add(int(parts[0]), parts[1], parts[2:])
            continue
        if len(parts) >= 2:
            _add(seq, parts[0], parts[1:])
            seq += 1
            continue
        parts = [x.strip() for x in line.split(":")]
        if len(parts) >= 2 and "@" in parts[0]:
            _add(seq, parts[0], [":".join(parts[1:])])
            seq += 1
    return out

def _find_visible_by_selectors(drv, selectors):
    for sel in selectors:
        try:
            for el in drv.find_elements("css selector", sel):
                try:
                    if el.is_displayed() and el.is_enabled():
                        return el
                except Exception:
                    pass
        except Exception:
            pass
    return None


def _safe_click_js(drv, el):
    try:
        drv.execute_script("arguments[0].click();", el); return True
    except Exception:
        try:
            el.click(); return True
        except Exception:
            return False




def _qt_is_recovery_email_challenge_page(url="", body=""):
    hay = (str(url or "") + "\n" + str(body or "")).lower()
    return (
        "challenge/kpe" in hay
        or "knowledgepreregisteredemailresponse" in hay
        or "email khôi phục" in hay
        or "email khoi phuc" in hay
        or "nhập địa chỉ email khôi phục" in hay
        or "nhap dia chi email khoi phuc" in hay
        or "xác nhận địa chỉ email khôi phục" in hay
        or "xac nhan dia chi email khoi phuc" in hay
        or "confirm your recovery email" in hay
        or "confirm the recovery email" in hay
        or "recovery email" in hay
    )



def _qt_select_recovery_email_method_if_present(drv, log_fn=None):
    """Trang Google /challenge/selection: ưu tiên chọn đúng mục
    'Xác nhận email khôi phục của bạn' để sang bước nhập recovery email.
    Không chọn mục 'Nhận mã xác minh tại ...' vì mục đó yêu cầu lấy code trong mailbox.
    """
    def log(msg):
        try:
            (log_fn or print)(msg)
        except Exception:
            try: print(msg)
            except Exception: pass
    try:
        from selenium.webdriver.common.by import By
    except Exception:
        By = None
    try:
        url_l = (drv.current_url or '').lower()
    except Exception:
        url_l = ''
    if 'accounts.google.com' not in url_l:
        return False
    # v12.98: On /challenge/selection, JS synthetic click may only focus the row
    # and not trigger Google's navigation. Use real Selenium click/ENTER first and
    # verify that the page actually moved to the recovery-email input step.
    def _qt_has_recovery_input_step():
        try:
            u = (drv.current_url or '').lower()
            if '/challenge/kpe' in u or 'challenge/kpe' in u:
                return True
        except Exception:
            pass
        try:
            return bool(drv.execute_script(r"""
                function vis(el){
                    if(!el) return false;
                    const st=getComputedStyle(el);
                    const r=el.getBoundingClientRect();
                    return st.display!=='none' && st.visibility!=='hidden' && r.width>2 && r.height>2 && !el.disabled;
                }
                const inputs = Array.from(document.querySelectorAll('input,textarea,[contenteditable="true"]'));
                return inputs.some(el => {
                    const typ=(el.type||'').toLowerCase();
                    const nm=(el.name||'').toLowerCase();
                    const id=(el.id||'').toLowerCase();
                    const aria=(el.getAttribute('aria-label')||'').toLowerCase();
                    if(['hidden','password','submit','button','checkbox','radio'].includes(typ)) return false;
                    if(!vis(el)) return false;
                    return nm.includes('knowledgepreregisteredemailresponse') || id.includes('knowledge') || aria.includes('khôi') || aria.includes('khoi') || aria.includes('recovery') || typ==='email' || typ==='text' || typ==='';
                });
            """))
        except Exception:
            return False

    if By is not None:
        try:
            from selenium.webdriver.common.action_chains import ActionChains
            from selenium.webdriver.common.keys import Keys
        except Exception:
            ActionChains = None
            Keys = None
        try:
            elems = drv.find_elements(By.CSS_SELECTOR, "[data-action='selectchallenge'][data-challengetype='12'], .VV3oRb[data-challengetype='12'], [role='link'][data-challengetype='12'], [data-challengetype='12']")
        except Exception:
            elems = []
        for el in elems:
            try:
                if not (el.is_displayed() and el.is_enabled()):
                    continue
                txt = (el.text or el.get_attribute('innerText') or el.get_attribute('textContent') or el.get_attribute('aria-label') or '').strip()
                low = txt.lower()
                if ('nhận mã xác minh' in low) or ('nhan ma xac minh' in low) or ('verification code' in low):
                    continue
                before_url = ''
                try:
                    before_url = drv.current_url or ''
                except Exception:
                    pass
                click_methods = []
                # v12.99: Google /challenge/selection often ignores JS-only clicks.
                # Try CDP mouse coordinates as a real browser click before falling back.
                if ActionChains is not None:
                    click_methods.append('action')
                click_methods.extend(['cdp', 'native', 'enter', 'js'])
                last_err = ''
                for method in click_methods:
                    try:
                        drv.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center'}); arguments[0].focus();", el)
                    except Exception:
                        pass
                    try:
                        if method == 'action' and ActionChains is not None:
                            ActionChains(drv).move_to_element(el).pause(0.08).click(el).perform()
                        elif method == 'cdp':
                            # Chrome DevTools Protocol click at the row center. This behaves
                            # closer to a real user click than dispatching JS events.
                            rect = drv.execute_script("""
                                const r = arguments[0].getBoundingClientRect();
                                return {x: Math.floor(r.left + r.width/2), y: Math.floor(r.top + r.height/2)};
                            """, el)
                            x = int(rect.get('x', 0)); y = int(rect.get('y', 0))
                            drv.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mouseMoved','x':x,'y':y,'button':'none'})
                            drv.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mousePressed','x':x,'y':y,'button':'left','clickCount':1})
                            drv.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mouseReleased','x':x,'y':y,'button':'left','clickCount':1})
                        elif method == 'native':
                            el.click()
                        elif method == 'enter' and Keys is not None:
                            el.send_keys(Keys.ENTER)
                        else:
                            drv.execute_script("""
                                const el=arguments[0];
                                el.scrollIntoView({block:'center', inline:'center'});
                                try{el.focus();}catch(e){}
                                for(const ev of ['pointerdown','mousedown','mouseup','pointerup','click']){
                                    try{ el.dispatchEvent(new MouseEvent(ev,{bubbles:true,cancelable:true,view:window})); }catch(e){}
                                }
                                try{el.click();}catch(e){}
                            """, el)
                    except Exception as e:
                        last_err = f"{method}:{type(e).__name__}"
                    # Wait until Google really opens the recovery-email input step.
                    for _ in range(18):
                        if _qt_has_recovery_input_step():
                            log(f"[login-assist] đã chọn 'Xác nhận email khôi phục của bạn' bằng click thật: {method} • {txt[:80] or 'data-challengetype=12'}")
                            time.sleep(0.6)
                            return True
                        try:
                            now_url = drv.current_url or ''
                            if before_url and now_url != before_url and 'challenge/selection' not in now_url.lower():
                                log(f"[login-assist] đã chọn 'Xác nhận email khôi phục của bạn' bằng click thật: {method} • chuyển trang")
                                time.sleep(0.9)
                                return True
                        except Exception:
                            pass
                        time.sleep(0.25)
                if last_err:
                    log(f"[login-assist] click type12 chưa sang ô nhập: {last_err}")
            except Exception:
                pass
    try:
        clicked = drv.execute_script(r"""
            const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
            function visible(el){
                if(!el) return false;
                const st = getComputedStyle(el);
                const r = el.getBoundingClientRect();
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 20 && r.height > 15;
            }
            const preferred = [
                'xác nhận email khôi phục', 'xac nhan email khoi phuc',
                'confirm your recovery email', 'confirm recovery email',
                'confirm the recovery email'
            ];
            const bad = [
                'nhận mã xác minh', 'nhan ma xac minh', 'get a verification code',
                'receive a verification code', 'verification code at', 'mã xác minh tại',
                'ma xac minh tai', 'thử cách khác', 'thu cach khac', 'try another way',
                'điện thoại', 'dien thoai', 'phone', 'máy tính khác', 'may tinh khac'
            ];
            // v12.96: Google có 2 mục email icon:
            //   data-challengetype=30 = Nhận mã xác minh tại ... (cần OTP, KHÔNG chọn)
            //   data-challengetype=12 = Xác nhận email khôi phục của bạn (chọn mục này rồi điền cột recovery_email)
            // Ưu tiên tuyệt đối data-challengetype=12 để không click nhầm mục nhận mã.
            const type12 = Array.from(document.querySelectorAll('[data-action="selectchallenge"][data-challengetype="12"], .VV3oRb[data-challengetype="12"], [role="link"][data-challengetype="12"], [data-challengetype="12"]'));
            for(const el of type12){
                const t = norm(el.innerText || el.textContent || el.getAttribute('aria-label') || '');
                if(!visible(el)) continue;
                // v12.97: data-challengetype=12 chính là "Xác nhận email khôi phục của bạn".
                // Click luôn theo type=12, không phụ thuộc text vì Google có thể dịch/ẩn text khác nhau.
                el.scrollIntoView({block:'center', inline:'center'});
                try { el.focus(); } catch(e) {}
                el.dispatchEvent(new PointerEvent('pointerdown', {bubbles:true, cancelable:true, pointerId:1, pointerType:'mouse', isPrimary:true}));
                el.dispatchEvent(new MouseEvent('mouseover', {bubbles:true, cancelable:true, view:window}));
                el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, view:window}));
                el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true, view:window}));
                el.dispatchEvent(new PointerEvent('pointerup', {bubbles:true, cancelable:true, pointerId:1, pointerType:'mouse', isPrimary:true}));
                el.click();
                return 'type12:' + (t || 'data-challengetype=12');
            }
            const candidates = Array.from(document.querySelectorAll('[data-action="selectchallenge"], [role="link"], [role="button"], div.VV3oRb, button'));
            for(const el of candidates){
                const t = norm(el.innerText || el.textContent || el.getAttribute('aria-label') || '');
                if(!t || !visible(el)) continue;
                // Tuyệt đối bỏ mục nhận mã OTP, thường là data-challengetype=30.
                const ct = String(el.getAttribute('data-challengetype') || '').trim();
                if(ct === '30') continue;
                if(bad.some(x => t.includes(x))) continue;
                if(preferred.some(x => t.includes(x))){
                    el.scrollIntoView({block:'center', inline:'center'});
                    el.dispatchEvent(new MouseEvent('mouseover', {bubbles:true, cancelable:true, view:window}));
                    el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, view:window}));
                    el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true, view:window}));
                    el.click();
                    return t;
                }
            }
            return '';
        """)
        if clicked:
            # Do not claim success until the selection page actually changes.
            # Older builds logged selected but stayed on the same screen, then kept
            # searching for the input too early.
            for _ in range(24):
                if _qt_has_recovery_input_step():
                    log(f"[login-assist] đã chọn 'Xác nhận email khôi phục của bạn': {clicked}")
                    time.sleep(0.6)
                    return True
                try:
                    u = (drv.current_url or '').lower()
                    if 'challenge/selection' not in u:
                        log(f"[login-assist] đã chọn 'Xác nhận email khôi phục của bạn': {clicked} • đã chuyển trang")
                        time.sleep(0.9)
                        return True
                except Exception:
                    pass
                time.sleep(0.25)
            log(f"[login-assist] click type12 chưa chuyển sang ô nhập, sẽ thử XPath/CDP tiếp: {clicked}")
    except Exception:
        pass
    # Fallback XPath chính xác, tránh click parent chứa toàn bộ trang.
    if By is not None:
        xps = [
            "//*[@data-action='selectchallenge' and @data-challengetype='12']",
            "//*[@data-challengetype='12' and contains(normalize-space(.), 'Xác nhận email khôi phục')]",
            "//*[@data-action='selectchallenge' and .//*[contains(normalize-space(.), 'Xác nhận email khôi phục')]]",
            "//*[@data-action='selectchallenge' and contains(normalize-space(.), 'Xác nhận email khôi phục')]",
            "//*[@role='link' and .//*[contains(normalize-space(.), 'Xác nhận email khôi phục')]]",
            "//*[@role='link' and contains(normalize-space(.), 'Xác nhận email khôi phục')]",
            "//*[(@role='link' or @role='button') and (contains(normalize-space(.), 'Confirm your recovery email') or contains(normalize-space(.), 'Confirm recovery email'))]",
        ]
        for xp in xps:
            try:
                for el in drv.find_elements(By.XPATH, xp):
                    try:
                        txt = (el.text or '').strip()
                        low = txt.lower()
                        ct = (el.get_attribute('data-challengetype') or '').strip()
                        if ct == '30':
                            continue
                        if ('nhận mã xác minh' in low) or ('get a verification code' in low) or ('try another way' in low) or ('thử cách khác' in low):
                            continue
                        if el.is_displayed() and el.is_enabled():
                            _safe_click_js(drv, el)
                            log(f"[login-assist] đã chọn 'Xác nhận email khôi phục của bạn' bằng XPath: {txt[:80]}")
                            time.sleep(1.2)
                            return True
                    except Exception:
                        pass
            except Exception:
                pass
    return False

def _qt_try_fill_recovery_email_challenge(drv, recovery_email, log_fn=None):
    """Nếu Google hỏi email khôi phục (challenge/kpe), tự điền email khôi phục đã import.
    Return:
      True  = đã xử lý/đã bấm Next
      None  = đúng trang email khôi phục nhưng chưa thấy ô nhập, cần chờ tiếp, KHÔNG được coi là verify
      False = không phải trang email khôi phục hoặc không có recovery_email
    """
    try:
        from selenium.webdriver.common.by import By
    except Exception:
        pass
    recovery_email = str(recovery_email or "").strip()
    def log(msg):
        try:
            (log_fn or print)(msg)
        except Exception:
            try: print(msg)
            except Exception: pass
    try:
        url_l = (drv.current_url or "").lower()
    except Exception:
        url_l = ""
    body_l = ""
    try:
        body_l = (drv.find_element(By.TAG_NAME, "body").text or "").lower()
    except Exception:
        pass
    if "accounts.google.com" not in url_l:
        return False
    if not _qt_is_recovery_email_challenge_page(url_l, body_l):
        return False

    # v12.97: /challenge/selection cũng có chữ "email khôi phục" nhưng CHƯA phải ô nhập.
    # Phải chọn mục data-challengetype=12 trước, rồi trang mới chuyển sang /challenge/kpe để nhập cột recovery_email.
    # Không kiểm tra vault thiếu recovery_email trước bước chọn này, nếu không sẽ đứng ở selection và bỏ account sớm.
    if "challenge/selection" in url_l:
        try:
            if _qt_select_recovery_email_method_if_present(drv, log_fn=log_fn):
                time.sleep(1.5)
                return None
        except Exception as e:
            log(f"[login-assist] chưa chọn được mục Xác nhận email khôi phục: {type(e).__name__}")
            return None

    if not recovery_email or "@" not in recovery_email:
        log("[login-assist] đang ở bước nhập email khôi phục nhưng vault chưa có recovery_email")
        return None

    deadline = time.time() + 18
    chosen_method_once = False
    inp = None
    while time.time() < deadline and inp is None:
        try:
            # Nếu đang ở trang chọn phương thức, chọn mục email khôi phục trước.
            visible_inputs = drv.execute_script("""
                function vis(el){
                    if(!el) return false;
                    const st = getComputedStyle(el);
                    const r = el.getBoundingClientRect();
                    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 2 && r.height > 2 && !el.disabled;
                }
                return Array.from(document.querySelectorAll('input,textarea,[contenteditable="true"]'))
                    .filter(el => vis(el) && !['hidden','password','submit','button','checkbox','radio'].includes((el.type||'').toLowerCase()))
                    .length;
            """)
            if not visible_inputs and not chosen_method_once:
                # Trang /challenge/selection có nhiều lựa chọn. Chỉ chọn đúng
                # "Xác nhận email khôi phục của bạn" để sang bước nhập recovery email.
                # Không chọn "Nhận mã xác minh tại ..." vì mục đó cần OTP trong mailbox.
                try:
                    chosen_method_once = bool(_qt_select_recovery_email_method_if_present(drv, log_fn=log_fn))
                except Exception:
                    chosen_method_once = False
        except Exception:
            pass

        # Ưu tiên selector chính xác của Google challenge/kpe, sau đó fallback bằng JS quét input hiển thị.
        selectors = [
            "input[name='knowledgePreregisteredEmailResponse']",
            "input#knowledge-preregistered-email-response",
            "input[aria-label*='khôi phục']",
            "input[aria-label*='khoi phuc']",
            "input[aria-label*='recovery']",
            "input[type='email']",
            "input[type='text']",
            "input:not([type])",
            "textarea",
            "[contenteditable='true']",
        ]
        for sel in selectors:
            try:
                for el in drv.find_elements(By.CSS_SELECTOR, sel):
                    try:
                        typ = (el.get_attribute("type") or "").lower()
                        name = (el.get_attribute("name") or "").lower()
                        if typ in ("password", "hidden", "submit", "button", "checkbox", "radio"):
                            continue
                        if "password" in name:
                            continue
                        if el.is_displayed() and el.is_enabled():
                            inp = el
                            break
                    except Exception:
                        pass
                if inp is not None:
                    break
            except Exception:
                pass
        if inp is None:
            try:
                inp = drv.execute_script("""
                    function vis(el){
                        if(!el) return false;
                        const st = getComputedStyle(el);
                        const r = el.getBoundingClientRect();
                        return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 2 && r.height > 2 && !el.disabled;
                    }
                    const all = Array.from(document.querySelectorAll('input,textarea,[contenteditable="true"]'));
                    return all.find(el => {
                        const typ=(el.type||'').toLowerCase();
                        const nm=(el.name||'').toLowerCase();
                        const aria=(el.getAttribute('aria-label')||'').toLowerCase();
                        const id=(el.id||'').toLowerCase();
                        if(['hidden','password','submit','button','checkbox','radio'].includes(typ)) return false;
                        if(nm.includes('password')) return false;
                        if(!vis(el)) return false;
                        if(nm.includes('knowledgepreregisteredemailresponse') || id.includes('knowledge') || aria.includes('khôi') || aria.includes('khoi') || aria.includes('recovery')) return true;
                        return typ === 'email' || typ === 'text' || typ === '' || el.tagName.toLowerCase()==='textarea' || el.isContentEditable;
                    }) || null;
                """)
            except Exception:
                inp = None
        if inp is None:
            time.sleep(0.7)

    if inp is None:
        log("[login-assist] thấy bước email khôi phục nhưng chưa tìm được ô nhập, giữ cửa sổ chờ thêm")
        return None

    try:
        drv.execute_script("arguments[0].scrollIntoView({block:'center'}); arguments[0].focus();", inp)
    except Exception:
        pass
    try:
        inp.clear()
    except Exception:
        pass
    try:
        # Set qua JS + dispatch event trước, rồi send_keys để tương thích Material input của Google.
        try:
            drv.execute_script("""
                const el=arguments[0], val=arguments[1];
                el.focus();
                if(el.isContentEditable){ el.textContent = val; }
                else { el.value = val; }
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
            """, inp, recovery_email)
        except Exception:
            pass
        try:
            inp.clear()
        except Exception:
            pass
        inp.send_keys(recovery_email)
        log("[login-assist] đã điền email khôi phục")
    except Exception as e:
        log(f"[login-assist] lỗi điền email khôi phục: {type(e).__name__}: {str(e)[:120]}")
        return None

    # v12.92: Sau khi điền email khôi phục phải bấm Tiếp theo thật chắc.
    # Bản trước điền được nhưng đôi lúc không click được nút vì Google đổi DOM/Material button,
    # làm vòng login đứng tại /challenge/kpe hoặc bị retry rồi đóng Chrome.
    try:
        from selenium.webdriver.common.keys import Keys as _SeleniumKeys
    except Exception:
        _SeleniumKeys = None

    clicked = False
    click_deadline = time.time() + 12
    last_click_err = ""
    while time.time() < click_deadline and not clicked:
        # Cách chính: JS quét đúng button/role=button có text Tiếp theo/Next, tránh nút Thử cách khác.
        try:
            clicked_text = drv.execute_script(r'''
                const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
                function visible(el){
                    if(!el) return false;
                    const st = getComputedStyle(el);
                    const r = el.getBoundingClientRect();
                    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 20 && r.height > 15 && !el.disabled;
                }
                const good = ['tiếp theo','tiep theo','next'];
                const bad = ['thử cách khác','thu cach khac','try another way','forgot','quên'];
                const nodes = Array.from(document.querySelectorAll('button, [role="button"], div[role="button"], span[role="button"], a'));
                for(const el of nodes){
                    const t = norm(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '');
                    if(!t || !visible(el)) continue;
                    if(bad.some(x => t.includes(x))) continue;
                    if(good.some(x => t === x || t.includes(x))){
                        el.scrollIntoView({block:'center', inline:'center'});
                        el.dispatchEvent(new MouseEvent('mouseover', {bubbles:true, cancelable:true, view:window}));
                        el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true, view:window}));
                        el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true, view:window}));
                        el.click();
                        return t;
                    }
                }
                return '';
            ''')
            if clicked_text:
                clicked = True
                log(f"[login-assist] đã bấm Tiếp theo sau email khôi phục: {clicked_text}")
                break
        except Exception as e:
            last_click_err = f"JS {type(e).__name__}: {str(e)[:80]}"

        # Cách phụ: XPath nếu JS không thấy.
        for xp in [
            "//button[.//*[contains(normalize-space(.), 'Tiếp theo')] or contains(normalize-space(.), 'Tiếp theo')]",
            "//button[.//*[contains(normalize-space(.), 'Next')] or contains(normalize-space(.), 'Next')]",
            "//*[@role='button'][.//*[contains(normalize-space(.), 'Tiếp theo')] or contains(normalize-space(.), 'Tiếp theo')]",
            "//*[@role='button'][.//*[contains(normalize-space(.), 'Next')] or contains(normalize-space(.), 'Next')]",
        ]:
            try:
                for btn in drv.find_elements(By.XPATH, xp):
                    try:
                        txt = (btn.text or '').strip()
                        txt_l = txt.lower()
                        if ('thử cách khác' in txt_l) or ('try another way' in txt_l):
                            continue
                        if btn.is_displayed() and btn.is_enabled():
                            _safe_click_js(drv, btn)
                            clicked = True
                            log(f"[login-assist] đã bấm Tiếp theo sau email khôi phục bằng XPath: {txt or xp[:50]}")
                            break
                    except Exception:
                        pass
                if clicked:
                    break
            except Exception as e:
                last_click_err = f"XPath {type(e).__name__}: {str(e)[:80]}"
        if clicked:
            break
        time.sleep(0.5)

    if not clicked:
        # Fallback cuối: Enter ngay trong ô đang focus. Không coi là verify, chỉ chờ tiếp.
        try:
            if _SeleniumKeys is not None:
                inp.send_keys(_SeleniumKeys.ENTER)
            else:
                inp.send_keys('\n')
            log("[login-assist] chưa tìm thấy nút Tiếp theo, đã nhấn Enter sau email khôi phục")
            clicked = True
        except Exception as e:
            log(f"[login-assist] chưa bấm được Tiếp theo sau email khôi phục: {last_click_err or type(e).__name__}")
            return None

    # Đợi trang rời khỏi /challenge/kpe hoặc ô khôi phục biến mất. Nếu chưa rời, không đánh verify sai.
    moved = False
    wait_deadline = time.time() + 18
    while time.time() < wait_deadline:
        try:
            url_now = (drv.current_url or '').lower()
        except Exception:
            url_now = ''
        body_now = ''
        try:
            body_now = (drv.find_element(By.TAG_NAME, 'body').text or '').lower()
        except Exception:
            pass
        if not _qt_is_recovery_email_challenge_page(url_now, body_now):
            moved = True
            break
        # Nếu Google đang xử lý/đổi trang, tiếp tục đợi nhẹ.
        time.sleep(0.8)
    if moved:
        log("[login-assist] email khôi phục đã qua bước Tiếp theo")
        return True
    log("[login-assist] đã nhập email khôi phục nhưng trang chưa chuyển, giữ cửa sổ chờ tiếp")
    return None


def _gemini_prompt_editor_ready_driver(drv):
    """v6.9: Gemini chỉ được coi là sẵn sàng khi đã vào đúng giao diện chat/vẽ có ô prompt."""
    try:
        return bool(drv.execute_script(r"""
            function visible(el){
                const r = el.getBoundingClientRect();
                const st = getComputedStyle(el);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 30 && r.height > 20;
            }
            const sels = [
                'rich-textarea',
                'textarea',
                'div[role="textbox"]',
                'div[contenteditable="true"]',
                'div[aria-label*="Nhập câu lệnh"]',
                'div[aria-label*="Hỏi Gemini"]',
                '[aria-label*="Nhập câu lệnh cho Gemini"]',
                '[placeholder*="Hỏi Gemini"]',
                '[placeholder*="Ask Gemini"]'
            ];
            const els = sels.flatMap(s => Array.from(document.querySelectorAll(s))).filter(visible);
            return els.some(el => {
                const t = ((el.innerText||el.textContent||el.value||'') + ' ' +
                          (el.getAttribute('aria-label')||'') + ' ' +
                          (el.getAttribute('placeholder')||'') + ' ' +
                          (el.getAttribute('role')||'')).toLowerCase();
                return t.includes('gemini') || t.includes('nhập') || t.includes('hỏi') || t.includes('ask') || t.includes('message') || el.tagName.toLowerCase()==='rich-textarea';
            });
        """))
    except Exception:
        return False


def _gemini_click_first_text_driver(drv, texts):
    """v7.2: Click nút onboarding Gemini theo button thật, không click DIV nền.
    Fix lỗi v7.2: khi popup Use Gemini hiện, selector bắt nhầm DIV/nền làm click sang For developers/Chat nền.
    - Chỉ chấp nhận target là button/a/[role=button]/mat button thật.
    - Span/touch-target phải click ngược lên button cha.
    - Nếu modal đang mở thì chỉ click nút bên trong modal.
    - Ưu tiên exact text nhỏ như Use Gemini, I understand, Chat with Gemini.
    """
    import time as _time
    try:
        res = drv.execute_script(r"""
            const wanted = arguments[0].map(x => String(x).toLowerCase().replace(/\s+/g,' ').trim()).filter(Boolean);
            function visible(el){
                if (!el) return false;
                const r = el.getBoundingClientRect();
                const st = getComputedStyle(el);
                return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 12 && r.height > 12 && r.bottom > 0 && r.right > 0 && r.left < innerWidth && r.top < innerHeight;
            }
            function norm(s){ return String(s||'').replace(/\s+/g,' ').trim().toLowerCase(); }
            function isActionable(el){
                if (!el || !el.matches) return false;
                return el.matches('button, a, [role="button"], .mat-mdc-button, .mat-mdc-raised-button, .mat-mdc-unelevated-button, .mdc-button');
            }
            function targetFor(el){
                if (!el) return null;
                if (isActionable(el)) return el;
                return (el.closest && el.closest('button, a, [role="button"], .mat-mdc-button, .mat-mdc-raised-button, .mat-mdc-unelevated-button, .mdc-button')) || null;
            }
            function isInsideModal(el){
                return !!(el && el.closest && el.closest('[role="dialog"], mat-dialog-container, .mat-mdc-dialog-container, .cdk-overlay-pane, .cdk-overlay-container'));
            }
            const modalOpen = !!document.querySelector('[role="dialog"], mat-dialog-container, .mat-mdc-dialog-container, .cdk-overlay-pane, .cdk-overlay-container');
            function targetText(t, child){
                return norm([
                    t.innerText, t.textContent, t.getAttribute('aria-label'), t.getAttribute('title'),
                    child ? child.innerText : '', child ? child.textContent : '', child ? child.getAttribute('aria-label') : ''
                ].join(' '));
            }
            function score(child){
                const t = targetFor(child);
                if (!t || !visible(t)) return null;
                // Khi modal mở, tuyệt đối không click nút nền như Chat with Gemini / For developers.
                if (modalOpen && !(isInsideModal(t) || isInsideModal(child))) return null;
                const txt = targetText(t, child);
                if (!txt) return null;
                let best = 0;
                for (const w of wanted) {
                    if (!w) continue;
                    if (txt === w) best = Math.max(best, 5000);
                    else if (txt.startsWith(w)) best = Math.max(best, 4200 + w.length);
                    else if (txt.includes(w)) best = Math.max(best, 3000 + w.length);
                }
                if (!best) return null;
                // Không bao giờ chọn No thanks / Không cảm ơn.
                if (/\bno thanks\b|không,? cảm ơn|không cảm ơn/.test(txt)) return null;
                const tag = t.tagName;
                if (tag === 'BUTTON') best += 800;
                if (t.getAttribute('role') === 'button') best += 300;
                if ((t.className||'').toString().includes('mat-mdc')) best += 200;
                if (isInsideModal(t) || isInsideModal(child)) best += 1000;
                // Nút thật thường nhỏ; phạt target quá to để tránh container.
                const r = t.getBoundingClientRect();
                const area = r.width * r.height;
                if (area > 90000) best -= 2000;
                return {el: child, target: t, sc: best, txt, area};
            }
            const nodes = Array.from(document.querySelectorAll('button, a, [role="button"], .mat-mdc-button, .mat-mdc-raised-button, .mat-mdc-unelevated-button, .mdc-button, .mat-mdc-button-touch-target, span'));
            const seen = new Set();
            const cand = [];
            for (const n of nodes) {
                if (!visible(n)) continue;
                const x = score(n);
                if (!x) continue;
                if (seen.has(x.target)) continue;
                seen.add(x.target);
                cand.push(x);
            }
            cand.sort((a,b) => (b.sc - a.sc) || (a.area - b.area));
            if (!cand.length) return {ok:false, reason:'NO_BUTTON_FOUND', modalOpen};
            const pick = cand[0];
            const target = pick.target;
            try { target.scrollIntoView({block:'center', inline:'center'}); } catch(e) {}
            const r = target.getBoundingClientRect();
            const cx = Math.max(2, Math.min(window.innerWidth-3, r.left + r.width/2));
            const cy = Math.max(2, Math.min(window.innerHeight-3, r.top + r.height/2));
            target.setAttribute('data-gemini-onboarding-picked','1');
            try { target.focus && target.focus(); } catch(e) {}
            return {
                ok:true,
                text:pick.txt,
                tag:target.tagName,
                role:target.getAttribute('role'),
                x:Math.round(cx),
                y:Math.round(cy),
                modalOpen,
                html:(target.outerHTML||'').slice(0,800)
            };
        """, list(texts))
        if not (isinstance(res, dict) and res.get('ok')):
            return False
        try:
            x = int(res.get('x') or 1); y = int(res.get('y') or 1)
            drv.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mouseMoved', 'x':x, 'y':y, 'button':'none'})
            drv.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mousePressed', 'x':x, 'y':y, 'button':'left', 'clickCount':1})
            _time.sleep(0.10)
            drv.execute_cdp_cmd('Input.dispatchMouseEvent', {'type':'mouseReleased', 'x':x, 'y':y, 'button':'left', 'clickCount':1})
        except Exception:
            pass
        # JS click dự phòng SAU CDP, nhưng chỉ trên đúng target đã đánh dấu.
        try:
            drv.execute_script("""
                const t = document.querySelector('[data-gemini-onboarding-picked="1"]');
                if (t) { try { t.click(); } catch(e) {} t.removeAttribute('data-gemini-onboarding-picked'); }
            """)
        except Exception:
            pass
        _time.sleep(0.8)
        return True
    except Exception:
        return False




def _google_workspace_terms_accept_driver(drv, log_fn=None, max_seconds=18):
    """v13.02: Tự xử lý trang chào mừng/điều khoản của tài khoản Google Workspace mới.

    Sau khi nhập mật khẩu, một số tài khoản Education/Workspace chuyển tới
    accounts.google.com/.../speedbump/workspacetermsofservice và bắt buộc cuộn
    xuống rồi bấm "Tôi hiểu" / "I understand". Chỉ thao tác khi nhận đúng trang
    này; tài khoản bình thường được bỏ qua ngay.
    """
    def log(msg):
        try:
            if log_fn:
                log_fn(msg)
        except Exception:
            pass

    import time as _time
    start = _time.time()
    saw_page = False

    while _time.time() - start < max_seconds:
        try:
            url_l = (drv.current_url or '').lower()
        except Exception:
            url_l = ''
        try:
            body_l = (drv.find_element(By.TAG_NAME, 'body').text or '').lower()
        except Exception:
            body_l = ''

        url_marker = (
            'workspacetermsofservice' in url_l
            or ('accounts.google.com' in url_l and '/signin/speedbump/' in url_l)
        )
        body_marker = any(k in body_l for k in (
            'chào mừng bạn đến với tài khoản mới',
            'chao mung ban den voi tai khoan moi',
            'welcome to your new account',
            'google workspace for education',
            'tôi hiểu',
            'toi hieu',
            'i understand',
        ))

        if not (url_marker or (('accounts.google.com' in url_l) and body_marker)):
            return False
        saw_page = True

        # Nút nằm cuối một trang rất dài nên phải cuộn xuống trước khi tìm.
        try:
            drv.execute_script(r"""
                try {
                    window.scrollTo({top: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight), behavior: 'instant'});
                    document.documentElement.scrollTop = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
                    document.body.scrollTop = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
                } catch(e) {}
            """)
        except Exception:
            pass
        _time.sleep(0.7)

        clicked = _gemini_click_first_text_driver(drv, [
            'Tôi hiểu', 'I understand', 'I Understand',
            'Tôi đồng ý', 'I agree', 'Agree',
            'Accept', 'Continue',
        ])
        if clicked:
            log('[login-assist] đã bấm Tôi hiểu trên trang chào mừng Google Workspace')
            # Đợi URL rời trang terms; nếu chuyển thẳng sang Gemini thì vòng login
            # phía ngoài sẽ tiếp tục bấm Chat with Gemini và Use Gemini như cũ.
            old_url = url_l
            for _ in range(20):
                _time.sleep(0.5)
                try:
                    new_url = (drv.current_url or '').lower()
                except Exception:
                    new_url = ''
                if new_url and new_url != old_url and 'workspacetermsofservice' not in new_url:
                    break
            return True

        # Dự phòng: Google có thể dùng lớp ripple VfPpkd-RLmnJb bên trong button.
        # Không click trực tiếp lớp ripple; tìm button cha có đúng nhãn.
        try:
            clicked_js = bool(drv.execute_script(r"""
                const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
                const wanted = ['tôi hiểu','toi hieu','i understand','tôi đồng ý','i agree'];
                const visible = el => {
                    if (!el) return false;
                    const r = el.getBoundingClientRect();
                    const st = getComputedStyle(el);
                    return r.width > 10 && r.height > 10 && st.display !== 'none' && st.visibility !== 'hidden';
                };
                const nodes = Array.from(document.querySelectorAll('button, [role="button"], span, div.VfPpkd-RLmnJb'));
                for (const n of nodes) {
                    const btn = n.matches && n.matches('button,[role="button"]') ? n : (n.closest && n.closest('button,[role="button"]'));
                    if (!btn || !visible(btn)) continue;
                    const tx = norm([btn.innerText, btn.textContent, btn.getAttribute('aria-label')].filter(Boolean).join(' '));
                    if (!wanted.some(w => tx === w || tx.includes(w))) continue;
                    try { btn.scrollIntoView({block:'center', inline:'center'}); } catch(e) {}
                    try { btn.click(); return true; } catch(e) {}
                }
                return false;
            """))
        except Exception:
            clicked_js = False
        if clicked_js:
            log('[login-assist] đã bấm Tôi hiểu Google Workspace bằng DOM dự phòng')
            _time.sleep(2.0)
            return True

        _time.sleep(0.6)

    if saw_page:
        log('[login-assist] thấy trang Google Workspace nhưng chưa bấm được Tôi hiểu')
    return False



def _google_workspace_unknown_error_continue_driver(drv, log_fn=None, max_seconds=10):
    """v13.03: Xử lý trang lỗi trung gian sau khi bấm điều khoản Workspace.

    Một số tài khoản Google Workspace/Education sau khi bấm "Tôi hiểu" chuyển tới
    accounts.google.com/.../signin/unknownerror với nội dung "Đã xảy ra lỗi" và
    nút "Tiếp theo". Đây là bước trung gian có thể tiếp tục bình thường; tool chỉ
    bấm nút khi xác định đúng trang lỗi này, tránh bấm nhầm nút Next ở màn khác.
    """
    def log(msg):
        try:
            if log_fn:
                log_fn(msg)
        except Exception:
            pass

    import time as _time
    start = _time.time()
    saw_page = False

    while _time.time() - start < max_seconds:
        try:
            url_l = (drv.current_url or '').lower()
        except Exception:
            url_l = ''
        try:
            body_l = (drv.find_element(By.TAG_NAME, 'body').text or '').lower()
        except Exception:
            body_l = ''

        url_marker = (
            'accounts.google.com' in url_l
            and ('/signin/unknownerror' in url_l or 'unknownerror' in url_l)
        )
        body_marker = (
            'accounts.google.com' in url_l
            and (
                ('đã xảy ra lỗi' in body_l and 'vui lòng thử lại' in body_l)
                or ('rất tiếc' in body_l and 'đã xảy ra sự cố' in body_l)
                or ('something went wrong' in body_l and 'try again' in body_l)
                or ('sorry' in body_l and 'something went wrong' in body_l)
            )
        )

        if not (url_marker or body_marker):
            return False
        saw_page = True

        # Ưu tiên đúng nút hành động thật theo nhãn Tiếp theo/Next.
        if _gemini_click_first_text_driver(drv, ['Tiếp theo', 'Next', 'Continue']):
            log('[login-assist] đã bấm Tiếp theo trên trang lỗi trung gian Google Workspace')
            old_url = url_l
            for _ in range(24):
                _time.sleep(0.5)
                try:
                    new_url = (drv.current_url or '').lower()
                except Exception:
                    new_url = ''
                try:
                    new_body = (drv.find_element(By.TAG_NAME, 'body').text or '').lower()
                except Exception:
                    new_body = ''
                if new_url and new_url != old_url:
                    break
                if 'đã xảy ra lỗi' not in new_body and 'something went wrong' not in new_body:
                    break
            return True

        # DOM dự phòng: chỉ click button/[role=button] có text khớp chính xác.
        try:
            clicked_js = bool(drv.execute_script(r"""
                const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
                const wanted = new Set(['tiếp theo', 'tiep theo', 'next', 'continue']);
                const visible = el => {
                    if (!el) return false;
                    const r = el.getBoundingClientRect();
                    const st = getComputedStyle(el);
                    return r.width > 20 && r.height > 15 && st.display !== 'none' && st.visibility !== 'hidden';
                };
                const nodes = Array.from(document.querySelectorAll('button, [role="button"]'));
                for (const btn of nodes) {
                    if (!visible(btn)) continue;
                    const tx = norm([btn.innerText, btn.textContent, btn.getAttribute('aria-label')].filter(Boolean).join(' '));
                    if (!wanted.has(tx)) continue;
                    try { btn.scrollIntoView({block:'center', inline:'center'}); } catch(e) {}
                    try { btn.focus(); } catch(e) {}
                    try { btn.click(); return true; } catch(e) {}
                }
                return false;
            """))
        except Exception:
            clicked_js = False

        if clicked_js:
            log('[login-assist] đã bấm Tiếp theo trang lỗi Workspace bằng DOM dự phòng')
            _time.sleep(1.5)
            return True

        _time.sleep(0.5)

    if saw_page:
        log('[login-assist] thấy trang lỗi trung gian Workspace nhưng chưa bấm được Tiếp theo')
    return False

def _google_cookie_accept_all_driver(drv, log_fn=None, max_seconds=12):
    """Bấm bảng cookie Google/Gemini: Read more -> Accept all."""
    def log(msg):
        try:
            if log_fn:
                log_fn(msg)
        except Exception:
            pass
    import time as _time
    start = _time.time()
    last_state = None
    while _time.time() - start < max_seconds:
        try:
            state = drv.execute_script(r"""
                const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
                const visible = (el) => {
                    if (!el) return false;
                    try {
                        const r = el.getBoundingClientRect();
                        const cs = getComputedStyle(el);
                        return r.width > 8 && r.height > 8 && cs.display !== 'none' && cs.visibility !== 'hidden' && r.bottom > 0 && r.right > 0 && r.left < innerWidth && r.top < innerHeight;
                    } catch(e) { return false; }
                };
                const body = norm((document.body && document.body.innerText) || '');
                const hasCookie = ['before you continue to google','we use cookies and data','if you choose “accept all”','if you choose "accept all"','chúng tôi sử dụng cookie','cookie và dữ liệu','trước khi tiếp tục sử dụng google'].some(k => body.includes(k));
                if (!hasCookie) return {hasCookie:false};
                const nodes = Array.from(document.querySelectorAll('button, [role="button"], a, span, div'));
                const actionable = (el) => {
                    if (!el) return null;
                    if (el.matches && el.matches('button, [role="button"], a, .mat-mdc-button, .mdc-button')) return el;
                    return (el.closest && el.closest('button, [role="button"], a, .mat-mdc-button, .mdc-button')) || null;
                };
                const textOf = (el, child) => norm([el && el.innerText, el && el.textContent, el && el.getAttribute && el.getAttribute('aria-label'), el && el.getAttribute && el.getAttribute('title'), el && el.getAttribute && el.getAttribute('data-test-id'), child && child.innerText, child && child.textContent, child && child.getAttribute && child.getAttribute('aria-label'), child && child.getAttribute && child.getAttribute('title'), child && child.getAttribute && child.getAttribute('data-test-id')].filter(Boolean).join(' '));
                function candidatesFor(words, rejectWords) {
                    const seen = new Set(); const out = [];
                    for (const child of nodes) {
                        const t = actionable(child);
                        if (!t || seen.has(t) || !visible(t)) continue;
                        const tx = textOf(t, child);
                        if (!tx) continue;
                        if (rejectWords && rejectWords.some(w => tx.includes(w))) continue;
                        if (words.some(w => tx.includes(w))) {
                            const r = t.getBoundingClientRect(); seen.add(t);
                            out.push({el:t, text:tx, x:r.x, y:r.y, w:r.width, h:r.height, isButton:(t.tagName === 'BUTTON')});
                        }
                    }
                    out.sort((a,b) => ((b.isButton?1000:0)+b.y) - ((a.isButton?1000:0)+a.y));
                    return out;
                }
                function clickPick(c){
                    const el=c.el; try{el.scrollIntoView({block:'center', inline:'center'});}catch(e){}
                    try{el.dispatchEvent(new MouseEvent('mouseover',{bubbles:true}));}catch(e){}
                    try{el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));}catch(e){}
                    try{el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));}catch(e){}
                    try{el.click();}catch(e){}
                    return {text:c.text, x:Math.round(c.x), y:Math.round(c.y), w:Math.round(c.w), h:Math.round(c.h)};
                }
                const accept = candidatesFor(['accept all','i agree','agree to all','chấp nhận tất cả','chap nhan tat ca','đồng ý tất cả','dong y tat ca'], ['reject all','từ chối tất cả','tu choi tat ca']);
                if (accept.length) return {hasCookie:true, clickedAccept:clickPick(accept[0])};
                const read = candidatesFor(['read more','đọc thêm','doc them','xem thêm','xem them','more options','thêm tùy chọn','them tuy chon','read-more-button'], []);
                if (read.length) return {hasCookie:true, clickedReadMore:clickPick(read[0])};
                return {hasCookie:true, acceptCount:0, readCount:0};
            """)
            last_state = state
            if not (state and state.get('hasCookie')):
                return False
            if state.get('clickedReadMore'):
                log('[google-cookie] đã bấm Read more')
                _time.sleep(0.8)
                continue
            if state.get('clickedAccept'):
                log('[google-cookie] đã bấm Accept all')
                _time.sleep(1.0)
                return True
        except Exception as e:
            last_state = {'error': str(e)[:120]}
        _time.sleep(0.35)
    if last_state and last_state.get('hasCookie'):
        log('[google-cookie] thấy popup cookie nhưng chưa bấm xong')
    return False

def _gemini_finish_onboarding_driver(drv, log_fn=None, stop_event=None, max_seconds=90):
    """v7.2: sau khi login, tự bấm các màn Gemini đầu tiên để vào đúng giao diện vẽ/chat; ưu tiên modal Use Gemini trước nền Chat; không mở Flow."""
    def log(msg):
        try:
            if log_fn: log_fn(msg)
        except Exception:
            pass
    import time as _time
    start = _time.time()
    last_action = ''
    try:
        drv.get(GEMINI_WEB_URL_GUI)
        _time.sleep(2.5)
        _google_cookie_accept_all_driver(drv, log_fn=log_fn, max_seconds=10)
    except Exception:
        pass
    while _time.time() - start < max_seconds:
        if stop_event is not None and stop_event.is_set():
            return False, "Đã dừng"
        try:
            url_l = (drv.current_url or '').lower()
        except Exception:
            url_l = ''
        body_l = ''
        try:
            body_l = (drv.find_element(By.TAG_NAME, 'body').text or '').lower()
        except Exception:
            pass
        if 'accounts.google.com' in url_l:
            # v13.02: account Workspace mới có thể còn trang Chào mừng/Tôi hiểu.
            # Xử lý xong rồi tiếp tục quy trình Chat with Gemini -> Use Gemini bên dưới.
            if _google_workspace_terms_accept_driver(drv, log_fn=log_fn, max_seconds=8):
                _time.sleep(2.0)
                continue
            return False, "Vẫn ở trang Google Login"
        _google_cookie_accept_all_driver(drv, log_fn=log_fn, max_seconds=2)
        if _gemini_prompt_editor_ready_driver(drv):
            return True, "Gemini đã vào giao diện vẽ/chat"
        # v7.2: Ưu tiên popup/modal trước. Nếu Terms popup đang hiện mà bấm Chat nền trước thì sẽ lặp mãi.
        # Terms/privacy popup: bấm Sử dụng Gemini / Use Gemini trước khi tìm nút Chat nền.
        if _gemini_click_first_text_driver(drv, ['Sử dụng Gemini', 'Use Gemini', 'I agree', 'Agree', 'Start using Gemini', 'Accept']):
            if last_action != 'use':
                log('[gemini-onboarding] bấm Sử dụng Gemini/Use Gemini')
                last_action = 'use'
            _time.sleep(3)
            continue
        # Intro modal: Tôi hiểu / Got it / I understand.
        if _gemini_click_first_text_driver(drv, ['Tôi hiểu', 'Got it', 'I understand', 'Understand', 'Done', 'I got it']):
            if last_action != 'understand':
                log('[gemini-onboarding] bấm Tôi hiểu/Got it')
                last_action = 'understand'
            _time.sleep(3)
            continue
        # Landing page: chỉ bấm Chat khi không còn modal Use/I understand phía trên.
        if _gemini_click_first_text_driver(drv, ['Trò chuyện với Gemini', 'Chat with Gemini', 'Try Gemini', 'Start chatting', 'Start chat', 'Open Gemini']):
            if last_action != 'chat':
                log('[gemini-onboarding] bấm Trò chuyện với Gemini/Chat with Gemini')
                last_action = 'chat'
            _time.sleep(3)
            continue
        # Nếu ở /app nhưng chưa hiện editor, đợi thêm.
        _time.sleep(1.5)
    return False, "Chưa vào được giao diện Gemini sau onboarding"




def _purge_external_extensions_from_profile(profile_dir, log_fn=None):
    """v13.30: dọn extension ngoài (McAfee/WebAdvisor...) khỏi profile Chrome Testing của tool.
    Chỉ tác động profile riêng của tool, không đụng Chrome cá nhân.
    Proxy auth extension của tool nằm ở _proxy_auth_ext* ngoài các thư mục này nên vẫn được giữ.
    """
    def _log(msg):
        try:
            if log_fn:
                log_fn(msg)
        except Exception:
            pass
    removed = 0
    try:
        prof = Path(normalize_path(profile_dir))
        default_dir = prof / "Default"
        targets = [
            default_dir / "Extensions",
            default_dir / "Extension State",
            default_dir / "Extension Rules",
            default_dir / "Extension Scripts",
            default_dir / "Local Extension Settings",
            default_dir / "Sync Extension Settings",
            default_dir / "Managed Extension Settings",
            default_dir / "Extension Cookies",
            default_dir / "Extension Activity",
        ]
        for target in targets:
            try:
                if target.exists():
                    if target.is_dir():
                        shutil.rmtree(target, ignore_errors=True)
                    else:
                        target.unlink(missing_ok=True)
                    removed += 1
            except Exception:
                pass
        # Xóa marker extension pending/externally installed nếu tồn tại ở Secure Preferences.
        for pref_path in (default_dir / "Preferences", default_dir / "Secure Preferences"):
            try:
                if not pref_path.exists() or pref_path.stat().st_size <= 0:
                    continue
                data = json.loads(pref_path.read_text(encoding="utf-8", errors="ignore"))
                if not isinstance(data, dict):
                    continue
                ext = data.get("extensions")
                if isinstance(ext, dict):
                    ext["alerts"] = {"initialized": True}
                    ui = ext.get("ui") if isinstance(ext.get("ui"), dict) else {}
                    ui["developer_mode"] = False
                    ext["ui"] = ui
                    # Bỏ record extension đã inject; extension proxy của tool được load qua command line.
                    if isinstance(ext.get("settings"), dict):
                        ext["settings"] = {}
                    data["extensions"] = ext
                pref_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
        if removed:
            _log(f"[extension-guard] đã dọn {removed} dữ liệu extension ngoài khỏi profile tool")
        return removed
    except Exception as e:
        _log(f"[extension-guard] dọn extension lỗi nhẹ: {e}")
        return removed

def _prepare_chromium_no_browser_signin_profile(profile_dir, log_fn=None):
    """v12.36: tắt browser-level Chromium sign-in/sync prompt trong profile trước khi mở Chrome.
    Không ảnh hưởng web login Google/Gemini; chỉ tránh popup 'Bạn muốn đăng nhập vào Chromium?'.
    """
    def _log(msg):
        try:
            if log_fn:
                log_fn(msg)
        except Exception:
            pass
    try:
        prof = Path(normalize_path(profile_dir))
        default_dir = prof / "Default"
        default_dir.mkdir(parents=True, exist_ok=True)
        try:
            _purge_external_extensions_from_profile(prof, log_fn=log_fn)
        except Exception:
            pass

        def patch_json(path, updates):
            data = {}
            try:
                if path.exists() and path.stat().st_size > 0:
                    data = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
                    if not isinstance(data, dict):
                        data = {}
            except Exception:
                data = {}
            def deep_set(obj, parts, value):
                cur = obj
                for k in parts[:-1]:
                    if not isinstance(cur.get(k), dict):
                        cur[k] = {}
                    cur = cur[k]
                cur[parts[-1]] = value
            for key, value in updates.items():
                deep_set(data, key.split("."), value)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

        common_updates = {
            "signin.allowed": False,
            "signin.allowed_on_next_startup": False,
            "sync.suppress_start": True,
            "sync.keep_everything_synced": False,
            "sync_promo.show_on_first_run_allowed": False,
            "sync_promo.user_skipped": True,
            "browser.has_seen_welcome_page": True,
            "profile.exit_type": "Normal",
            "profile.exited_cleanly": True,
            "credentials_enable_service": False,
            "profile.password_manager_enabled": False,
            "extensions.alerts.initialized": True,
            "extensions.ui.developer_mode": False,
        }
        patch_json(prof / "Local State", common_updates)
        patch_json(default_dir / "Preferences", common_updates)
        _log("[login-assist] v13.30 đã chuẩn bị profile: tắt sign-in/sync + chặn extension ngoài")
    except Exception as e:
        _log(f"[login-assist] chuẩn bị profile no-browser-signin lỗi: {e}")


def _dismiss_chromium_profile_signin_prompt(drv, log_fn=None, max_rounds=8):
    """v12.36: xử lý popup Chromium profile sync: 'Bạn muốn đăng nhập vào Chromium?'.
    Ưu tiên tắt bằng prefs/flags; nếu vẫn hiện thì click nút bỏ qua, cuối cùng dùng Tab+Enter/Escape fallback.
    """
    def _log(msg):
        try:
            if log_fn:
                log_fn(msg)
        except Exception:
            pass
    try:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        from selenium.webdriver.common.action_chains import ActionChains
    except Exception:
        return False
    clicked_any = False
    for round_i in range(max_rounds):
        body_l = ''
        try:
            body_l = (drv.find_element(By.TAG_NAME, 'body').text or '').lower()
        except Exception:
            pass
        has_prompt_text = any(x in body_l for x in [
            'bạn muốn đăng nhập vào chromium',
            'đăng nhập vào chromium',
            'dang nhap vao chromium',
            'sign in to chromium',
            'dùng chromium mà không cần tài khoản',
            'dung chromium ma khong can tai khoan',
            'use chromium without an account',
            'continue without an account',
            'tiếp tục bằng tài khoản',
            'continue as',
        ])
        # Luôn thử DOM click một vài vòng vì prompt có thể nằm trong DOM nhưng body text chưa ổn định.
        js_clicked = False
        try:
            js_clicked = bool(drv.execute_script(r"""
                const norm = s => String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
                const wanted = [
                  'dùng chromium mà không cần tài khoản',
                  'dung chromium ma khong can tai khoan',
                  'use chromium without an account',
                  'continue without an account',
                  'continue without account',
                  'not now',
                  'không phải bây giờ'
                ];
                const bad = ['tiếp tục bằng tài khoản', 'continue as', 'continue with'];
                const nodes = Array.from(document.querySelectorAll('button, [role="button"], a, div, span'));
                function visible(el){ const r=el.getBoundingClientRect(); return r.width>5 && r.height>5; }
                // Ưu tiên button rõ ràng, đặc biệt nút phải có text Dùng Chromium mà không cần tài khoản.
                for (const el of nodes) {
                    const t = norm(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '');
                    if (!t || !visible(el)) continue;
                    if (bad.some(b => t.includes(b))) continue;
                    if (wanted.some(w => t.includes(w))) {
                        el.scrollIntoView({block:'center', inline:'center'});
                        el.dispatchEvent(new MouseEvent('mouseover', {bubbles:true}));
                        el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true}));
                        el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true}));
                        el.click();
                        return true;
                    }
                }
                return false;
            """))
        except Exception:
            js_clicked = False
        if js_clicked:
            clicked_any = True
            _log('[login-assist] đã bấm Dùng Chromium mà không cần tài khoản bằng DOM')
            time.sleep(1.2)
            continue
        try:
            xp = "//*[self::button or @role='button' or self::a][contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZÀÁẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬĐÈÉẺẼẸÊẾỀỂỄỆÌÍỈĨỊÒÓỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÙÚỦŨỤƯỨỪỬỮỰỲÝỶỸỴ', 'abcdefghijklmnopqrstuvwxyzàáảãạăắằẳẵặâấầẩẫậđèéẻẽẹêếềểễệìíỉĩịòóỏõọôốồổỗộơớờởỡợùúủũụưứừửữựỳýỷỹỵ'), 'dùng chromium mà không cần tài khoản') or contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'use chromium without an account') or contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'continue without')]"
            for btn in drv.find_elements(By.XPATH, xp):
                try:
                    if btn.is_displayed():
                        _safe_click_js(drv, btn)
                        clicked_any = True
                        _log('[login-assist] đã bỏ qua popup đăng nhập Chromium/sync bằng XPath')
                        time.sleep(1.2)
                        break
                except Exception:
                    pass
        except Exception:
            pass
        if clicked_any:
            continue
        if has_prompt_text:
            # Nếu đây là Chrome UI overlay không thấy DOM button, dùng phím: Tab sang nút phải rồi Enter.
            if str(os.environ.get('GEMINI_CHROMIUM_SYNC_TAB_ENTER_FALLBACK', '1')).strip().lower() in ('1','true','yes','on'):
                try:
                    ActionChains(drv).send_keys(Keys.TAB).pause(0.15).send_keys(Keys.ENTER).perform()
                    _log('[login-assist] popup Chromium sync: đã thử Tab+Enter chọn nút bỏ qua')
                    time.sleep(1.5)
                    clicked_any = True
                    continue
                except Exception as e:
                    _log(f'[login-assist] Tab+Enter fallback lỗi: {e}')
            try:
                ActionChains(drv).send_keys(Keys.ESCAPE).perform()
                _log('[login-assist] popup Chromium sync: đã thử ESC để đóng')
                time.sleep(1.0)
            except Exception:
                pass
        else:
            if clicked_any:
                return True
            if round_i >= 1:
                return False
            time.sleep(0.5)
    return clicked_any

def _auto_google_login_once(chrome_binary, driver_binary, profile_dir, email, password, recovery_email="", log_fn=None, stop_event=None, hidden=False, proxy_value=None):
    """Auto-fill normal Google login. Does not bypass 2FA/captcha/security prompts."""
    def log(msg):
        try:
            if log_fn: log_fn(msg)
        except Exception:
            pass
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.common.by import By
    _prepare_chromium_no_browser_signin_profile(profile_dir, log_fn=log_fn)
    opts = webdriver.ChromeOptions()
    opts.binary_location = str(chrome_binary)
    proxy_extension_loaded = False
    opts.add_argument(f"--user-data-dir={normalize_path(profile_dir)}")
    try:
        px = _dash_parse_proxy_value(proxy_value or "")
        if px:
            opts.add_argument(f"--proxy-server={px.get('scheme') or 'http'}://{px.get('host')}:{int(px.get('port'))}")
            opts.add_argument("--proxy-bypass-list=<-loopback>")
            if px.get("username") or px.get("password"):
                try:
                    ext_dir = Path(profile_dir) / "_proxy_auth_ext_login_mv3"
                    ext_dir.mkdir(parents=True, exist_ok=True)
                    user = str(px.get("username") or "").replace('"', '\\"')
                    pwd = str(px.get("password") or "").replace('"', '\\"')
                    manifest = {
                        "version": "1.0",
                        "manifest_version": 3,
                        "name": "Gemini Login Proxy Auth MV3",
                        "permissions": ["proxy", "storage", "webRequest", "webRequestAuthProvider"],
                        "host_permissions": ["<all_urls>"],
                        "background": {"service_worker": "background.js"},
                        "minimum_chrome_version": "88.0.0",
                    }
                    bg = f"""
const config = {{
  mode: "fixed_servers",
  rules: {{
    singleProxy: {{scheme: "{px.get('scheme') or 'http'}", host: "{px.get('host')}", port: {int(px.get('port'))}}},
    bypassList: ["localhost", "127.0.0.1", "<local>"]
  }}
}};
chrome.proxy.settings.set({{value: config, scope: "regular"}}, function() {{}});
chrome.webRequest.onAuthRequired.addListener(
  function(details, callback) {{ callback({{authCredentials: {{username: "{user}", password: "{pwd}"}}}}); }},
  {{urls: ["<all_urls>"]}},
  ["asyncBlocking"]
);
"""
                    (ext_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
                    (ext_dir / "background.js").write_text(bg, encoding="utf-8")
                    opts.add_argument(f"--load-extension={ext_dir}")
                    opts.add_argument(f"--disable-extensions-except={ext_dir}")
                    proxy_extension_loaded = True
                except Exception as _proxy_ext_e:
                    log(f"[login-assist] tạo proxy auth MV3 lỗi nhẹ: {_proxy_ext_e}")
            log(f"[login-assist] Proxy ON cho login: {px.get('host')}:{px.get('port')}")
    except Exception as e:
        log(f"[login-assist] Proxy setup login lỗi nhẹ: {e}")
    opts.add_argument("--profile-directory=Default")
    normal_then_minimize = str(os.environ.get("GEMINI_NORMAL_THEN_MINIMIZE", "0")).strip().lower() in ("1", "true", "yes", "on")
    npt_exact_9999 = str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on")
    stable_offscreen = hidden and str(os.environ.get("GEMINI_LOGIN_STABLE_OFFSCREEN", "0")).strip().lower() in ("1", "true", "yes", "on")
    if npt_exact_9999 or stable_offscreen:
        # V18 Web login: keep the real browser fully rendered but permanently outside the desktop.
        # Do NOT minimize/restore it: those Win32 transitions were stealing focus and making the Web modal blink.
        opts.add_argument("--window-position=12000,12000")
        opts.add_argument("--window-size=1280,900")
        if stable_offscreen:
            log("[login-ui] V18 stable offscreen • no minimize • no global window hook")
    elif hidden and not normal_then_minimize:
        opts.add_argument("--window-position=-32000,-32000")
        opts.add_argument("--window-size=1280,900")
        opts.add_argument("--start-minimized")
        opts.add_argument("--disable-backgrounding-occluded-windows")
        opts.add_argument("--disable-renderer-backgrounding")
        opts.add_argument("--disable-background-timer-throttling")
    else:
        opts.add_argument("--window-position=60,40")
        opts.add_argument("--window-size=1280,900")
        opts.add_argument("--start-maximized")
    opts.add_argument("--no-first-run")
    opts.add_argument("--no-default-browser-check")
    if not proxy_extension_loaded:
        opts.add_argument("--disable-extensions")
    opts.add_argument("--disable-component-extensions-with-background-pages")
    opts.add_argument("--disable-default-apps")
    opts.add_argument("--disable-notifications")
    opts.add_argument("--disable-popup-blocking")
    opts.add_argument("--disable-sync")
    opts.add_argument("--disable-session-crashed-bubble")
    opts.add_argument("--hide-crash-restore-bubble")
    opts.add_argument("--disable-signin-scoped-device-id")
    opts.add_argument("--disable-features=ChromeSigninIntercept,SigninInterceptBubble,AccountConsistency,SigninProfileCreation,PasswordManagerOnboarding,UnoDesktop,DiceWebSigninInterception,SigninInterception,SyncPromoAfterSigninIntercept,ExplicitBrowserSigninUIOnDesktop,ChromeSignIn")
    opts.add_argument("--password-store=basic")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    try:
        opts.add_experimental_option("prefs", {
            "session.restore_on_startup": 0,
            "profile.exit_type": "Normal",
            "profile.exited_cleanly": True,
            "signin.allowed": False,
            "sync_promo.show_on_first_run_allowed": False,
            "sync_promo.user_skipped": True,
            "credentials_enable_service": False,
            "profile.password_manager_enabled": False,
        })
    except Exception:
        pass
    drv = None
    try:
        _drv_path = Path(driver_binary) if driver_binary else None
        if _drv_path is not None and _drv_path.is_file():
            _svc = Service(str(_drv_path))
        else:
            log(f"[login-assist] chromedriver local không có → dùng Selenium Manager cho Chrome {chrome_binary}")
            _svc = Service()
        # V16: suppress ChromeDriver console/window creation. Together with the dashboard
        # WinEvent background guard this removes the short taskbar/window flashes between accounts.
        try:
            _svc.creation_flags = _no_window_creationflags()
        except Exception:
            pass
        try:
            _svc.startupinfo = _make_no_window_startupinfo()
        except Exception:
            pass
        drv = webdriver.Chrome(service=_svc, options=opts)
        try:
            if hidden and not stable_offscreen:
                _root_pid = int(drv.service.process.pid)
                threading.Thread(target=_qt_hide_process_windows, args=(_root_pid, 8.0), daemon=True).start()
        except Exception:
            pass
        try:
            normal_then_minimize = str(os.environ.get("GEMINI_NORMAL_THEN_MINIMIZE", "0")).strip().lower() in ("1", "true", "yes", "on")
            npt_exact_9999 = str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on")
            stable_offscreen = hidden and str(os.environ.get("GEMINI_LOGIN_STABLE_OFFSCREEN", "0")).strip().lower() in ("1", "true", "yes", "on")
            if npt_exact_9999 or stable_offscreen:
                drv.set_window_rect(12000, 12000, 1280, 900)
            elif hidden and not normal_then_minimize:
                drv.set_window_rect(-32000, -32000, 1280, 900)
                drv.minimize_window()
            else:
                drv.set_window_rect(60, 40, 1280, 900)
                if hidden or normal_then_minimize:
                    time.sleep(0.8)
                    try: drv.minimize_window()
                    except Exception: pass
        except Exception:
            pass
        drv.set_page_load_timeout(60)
        # v7.2: profile cũ có thể restore tab Flow; đóng hết tab thừa trước khi login Gemini.
        try:
            handles = list(drv.window_handles)
            for h in handles[1:]:
                try:
                    drv.switch_to.window(h); drv.close()
                except Exception:
                    pass
            if handles:
                drv.switch_to.window(handles[0])
        except Exception:
            pass
        log("[login-assist] mở Chromium login/debug visible")
        try:
            if str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on"):
                drv.set_window_rect(9999, 9999, 1280, 900)
        except Exception:
            pass
        # v6.5: dùng URL login Google đơn giản + Gemini onboarding, không gắn continue về Flow để tránh Error 400 Bad Request.
        drv.get(GOOGLE_LOGIN_FORCE_URL_GUI)
        time.sleep(1.2)
        _dismiss_chromium_profile_signin_prompt(drv, log_fn=log_fn, max_rounds=12)
        _google_cookie_accept_all_driver(drv, log_fn=log_fn, max_seconds=4)
        time.sleep(1.0)
        saw_login = False
        password_submitted = False
        for _ in range(100):
            if stop_event is not None and stop_event.is_set():
                return False, "Đã dừng"
            try:
                url_l = (drv.current_url or "").lower()
            except Exception:
                url_l = ""
            body_txt = ""
            try:
                body_txt = drv.find_element(By.TAG_NAME, "body").text[:2000]
            except Exception:
                pass
            body_l = body_txt.lower()
            # Đừng kiểm tra verify trước khi xử lý ô mật khẩu: trang nhập mật khẩu Google có URL /challenge/pwd.
            try:
                _pwd_probe = _find_visible_by_selectors(drv, ['input[type="password"]', 'input[name="Passwd"]'])
            except Exception:
                _pwd_probe = None
            # v13.02: một số tài khoản Workspace/Education mới hiện trang Chào mừng rất dài
            # và bắt buộc bấm "Tôi hiểu" sau mật khẩu. Phải xử lý trước kiểm tra verify,
            # sau đó quy trình onboarding vẫn bấm Chat with Gemini và Use Gemini như cũ.
            if _pwd_probe is None and _google_workspace_terms_accept_driver(drv, log_fn=log_fn, max_seconds=8):
                # v13.03: một số account sau "Tôi hiểu" đi qua trang unknownerror
                # và cần bấm thêm "Tiếp theo" mới hoàn tất đăng nhập.
                time.sleep(0.8)
                _google_workspace_unknown_error_continue_driver(drv, log_fn=log_fn, max_seconds=12)
                time.sleep(1.2)
                continue
            # Có thể trang lỗi trung gian xuất hiện chậm hơn vòng xử lý terms ở trên.
            # Kiểm tra độc lập trước khi coi đây là checkpoint/xác minh tài khoản.
            if _pwd_probe is None and _google_workspace_unknown_error_continue_driver(drv, log_fn=log_fn, max_seconds=3):
                time.sleep(1.2)
                continue
            # Một số account sau mật khẩu sẽ hỏi "Nhập địa chỉ email khôi phục" (/challenge/kpe).
            # Nếu TXT/vault có cột recovery_email thì điền trước, không đánh nhầm là checkpoint cần bỏ account.
            if _pwd_probe is None:
                _rec_res = _qt_try_fill_recovery_email_challenge(drv, recovery_email, log_fn=log_fn)
                if _rec_res is True or _rec_res is None:
                    continue
            if _pwd_probe is None and _qt_is_google_account_verify_required(url_l, body_l):
                msg = "ACCOUNT_VERIFY_REQUIRED: Google yêu cầu xác minh danh tính tài khoản; bỏ account này và chuyển tài khoản khác"
                log("[login-assist] " + msg)
                return False, msg
            # v12.36: bỏ qua popup sync Chromium nếu xuất hiện ở bất kỳ bước nào.
            if _dismiss_chromium_profile_signin_prompt(drv, log_fn=log_fn, max_rounds=3):
                try:
                    drv.get("https://gemini.google.com/app/new")
                    time.sleep(1.5)
                except Exception:
                    pass
                continue
            if "bad request" in body_l or "that's an error" in body_l or "error 400" in body_l:
                # URL cũ hoặc redirect hỏng: quay về trang login Google đơn giản + Gemini onboarding.
                try:
                    log("[login-assist] gặp Google 400, đổi sang login đơn giản")
                    drv.get("https://accounts.google.com/signin/v2/identifier?hl=vi")
                    time.sleep(2.5)
                    continue
                except Exception:
                    pass
            if "accounts.google.com" not in url_l and ("myaccount.google" in url_l or "gemini.google" in url_l or "google.com" in url_l or "gemini" in body_l):
                _dismiss_chromium_profile_signin_prompt(drv, log_fn=log_fn, max_rounds=5)
                # v6.8: Đăng nhập xong phải hoàn tất onboarding Gemini để vào đúng giao diện vẽ/chat.
                ok_onboard, msg_onboard = _gemini_finish_onboarding_driver(drv, log_fn=log_fn, stop_event=stop_event, max_seconds=90)
                if ok_onboard:
                    _qt_export_gemini_session_bundle(drv, profile_dir, proxy_value=proxy_value or "", log_fn=log)
                    log("[login-assist] Gemini onboarding OK")
                    return True, "Gemini OK • đã vào giao diện vẽ/chat"
                log("[login-assist] Gemini onboarding chưa xong: " + str(msg_onboard))
                return False, msg_onboard
            if "accounts.google.com" in url_l:
                saw_login = True
                try:
                    for m in drv.find_elements(By.XPATH, f"//*[contains(normalize-space(.), '{email}')]"):
                        if m.is_displayed():
                            _safe_click_js(drv, m)
                            log("[login-assist] đã chọn email trong account chooser")
                            time.sleep(2.5)
                            break
                except Exception:
                    pass
                email_box = _find_visible_by_selectors(drv, ['input[type="email"]', 'input#identifierId'])
                if email_box is not None:
                    try:
                        email_box.clear(); email_box.send_keys(email); email_box.send_keys(Keys.ENTER)
                        log("[login-assist] đã điền email")
                        time.sleep(3)
                        continue
                    except Exception:
                        pass
                pwd_box = _find_visible_by_selectors(drv, ['input[type="password"]', 'input[name="Passwd"]'])
                if pwd_box is not None:
                    try:
                        pwd_box.clear(); pwd_box.send_keys(password); pwd_box.send_keys(Keys.ENTER)
                        password_submitted = True
                        log("[login-assist] đã điền mật khẩu")
                        time.sleep(7)
                        continue
                    except Exception:
                        pass
                try:
                    for o in drv.find_elements(By.XPATH, "//*[contains(text(),'Sử dụng một tài khoản khác') or contains(text(),'Use another account')]"):
                        if o.is_displayed():
                            _safe_click_js(drv, o); time.sleep(2); break
                except Exception:
                    pass
            time.sleep(1.5)
        return (False, "Cần thao tác thủ công hoặc bảo mật Google") if saw_login else (False, "Không xác định được trạng thái đăng nhập")
    except Exception as e:
        return False, f"Lỗi auto-login: {type(e).__name__}: {str(e)[:160]}"
    finally:
        try:
            if drv is not None: drv.quit()
        except Exception:
            pass



def _auto_detect_npt_chromium_binary():
    """v12.36: ưu tiên Chromium portable của NPT nếu có, nhưng vẫn cho override bằng env."""
    try:
        env_bin = os.environ.get("GEMINI_CHROMIUM_BINARY") or os.environ.get("GEMINI_CHROME_BINARY")
        if env_bin and Path(env_bin).exists():
            return Path(env_bin)
    except Exception:
        pass
    try:
        local = os.environ.get("LOCALAPPDATA") or ""
        base = Path(__file__).resolve().parent
        # v12.36: ưu tiên Chromium đã copy vào thư mục tool để tool độc lập, sau đó mới fallback sang NPT.
        candidates = [
            base / "chromium" / "chrome.exe",
            base / "chromium" / "chromium.exe",
        ]
        if local:
            candidates.append(Path(local) / "Programs" / "NPT Veo Auto" / "resources" / "chromium" / "chrome.exe")
        candidates += [
            base / "chrome-win64" / "chrome.exe",
        ]
        # Web integration may not bundle Chromium. Fall back to an installed Google Chrome
        # while keeping the isolated google_N user-data-dir used by the original tool.
        pf = os.environ.get("PROGRAMFILES") or ""
        pfx86 = os.environ.get("PROGRAMFILES(X86)") or ""
        if local:
            candidates.append(Path(local) / "Google" / "Chrome" / "Application" / "chrome.exe")
        if pf:
            candidates.append(Path(pf) / "Google" / "Chrome" / "Application" / "chrome.exe")
        if pfx86:
            candidates.append(Path(pfx86) / "Google" / "Chrome" / "Application" / "chrome.exe")
        for c in candidates:
            if c.exists():
                return c
    except Exception:
        pass
    return Path(__file__).resolve().parent / "chrome-win64" / "chrome.exe"


def _auto_detect_driver_binary(default_dir):
    try:
        env_drv = os.environ.get("GEMINI_CHROMEDRIVER_BINARY") or os.environ.get("GEMINI_DRIVER_BINARY")
        if env_drv and Path(env_drv).exists():
            return Path(env_drv)
    except Exception:
        pass
    base = Path(default_dir)
    candidates = [base / "chromedriver-win64" / "chromedriver.exe", base / "chromedriver.exe"]
    try:
        import shutil as _shutil
        found = _shutil.which("chromedriver.exe") or _shutil.which("chromedriver")
        if found:
            candidates.append(Path(found))
    except Exception:
        pass
    try:
        local = os.environ.get("LOCALAPPDATA") or ""
        if local:
            npt = Path(local) / "Programs" / "NPT Veo Auto" / "resources"
            candidates += [npt / "chromedriver-win64" / "chromedriver.exe", npt / "chromedriver.exe"]
    except Exception:
        pass
    for c in candidates:
        try:
            if c.is_file():
                return c
        except Exception:
            pass
    # Missing local driver is OK in v9: Selenium Manager will resolve a compatible driver.
    return base / "chromedriver-win64" / "chromedriver.exe"

class WorkerState:
    def __init__(self, wid, acc, jobs):
        self.worker_id = wid
        self.account_no = acc
        self.jobs = jobs
        self.total = len(jobs)
        self.ok = 0
        self.err = 0
        self.skip = 0
        self.phase = "Chuẩn bị"
        self.state = "🚀 Khởi động"
        self.current = "-"
        self.last_error = "-"
        self.proc = None
        self.path_pairs = []
        self.current_worker_path = None
        self.current_original_path = None
        self.switch_count = 0
        self.tried_accounts = [acc]
        self.quota_exhausted = False
        self.failover_requested = False
        self.failover_reason = ""
        self.failover_exhaust_current = False
        self.failover_handled = False
        self.terminate_requested = False
        self.finished = False
        self.account_map = [acc]
        self.last_ui_log_ts = 0.0
        self.copyback_done = set()
        self.json_mode = False
        self.started_at = 0.0
        self.current_job_started_at = 0.0
        self.completed_events = 0
        self.last_job_duration = 0.0
        # v12.59: Dispatch Core Fix. Phân biệt worker đang launch/login với worker đã chết,
        # tránh scheduler tưởng còn slot rồi sinh W30/W40 ở cuối batch.
        self.last_output_ts = 0.0
        self.last_schedule_ts = 0.0
        self.dispatch_token = ""
        self.lease_ids = {}


class StatCard(QFrame):
    def __init__(self, title, color, parent=None):
        super().__init__(parent)
        self.setObjectName("StatCard")
        # v12.81: tăng nhẹ chiều cao để số Live Stats không bị cắt chân khi dùng font lớn.
        self.setMinimumHeight(68 if COMPACT_UI else 88)
        self.setMaximumHeight(84 if COMPACT_UI else 104)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8 if COMPACT_UI else 14, 6 if COMPACT_UI else 10, 8 if COMPACT_UI else 14, 7 if COMPACT_UI else 11)
        bar = QFrame()
        bar.setFixedHeight(3 if COMPACT_UI else 4)
        bar.setStyleSheet(f"background:{color}; border-radius:2px;")
        self.title = QLabel(title)
        self.title.setObjectName("CardTitle")
        self.value = QLabel("0")
        self.value.setObjectName("CardValue")
        self.value.setMinimumHeight(28 if COMPACT_UI else 34)
        self.value.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        lay.addWidget(bar)
        lay.addSpacing(1)
        lay.addWidget(self.title)
        lay.addWidget(self.value)
        lay.addStretch(1)

    def set_value(self, value):
        self.value.setText(str(value))


class AccountRow(QFrame):
    def __init__(self, app, row_no=1, account_no=None, login_email="", login_password="", display_email=""):
        super().__init__()
        self.app = app
        self.row_id = id(self)
        self.ok = False
        self.setObjectName("AccountRow")
        self.setMinimumHeight(56)
        self.setMaximumHeight(64)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)
        lay.setSpacing(7)

        self.title = QLabel()
        self.title.setObjectName("AccountTitle")
        self.title.setMinimumWidth(92)
        self.title.setMaximumWidth(118)

        self.up_btn = QPushButton("↑")
        self.down_btn = QPushButton("↓")
        for _b in (self.up_btn, self.down_btn):
            _b.setObjectName("MoveButton")
            _b.setFixedSize(30, 30)
            _b.setToolTip("Di chuyển thứ tự tài khoản")

        # v79.2: Ẩn ô số profile "Account 3/5/5" khỏi giao diện vì đã có nhãn Tài khoản 1/2/3.
        # Vẫn giữ self.account_edit ở nền để tool biết profile thật là google_3/google_4/...
        acc_chip = QLabel("Account")
        acc_chip.setObjectName("TinyChip")
        acc_chip.setVisible(False)
        self.account_edit = QLineEdit(str(account_no or row_no))
        self.account_edit.setFixedWidth(0)
        self.account_edit.setVisible(False)
        self.account_edit.setPlaceholderText("A")

        self.email_edit = QLineEdit(login_email)
        self.email_edit.setPlaceholderText("Email auto-login (tuỳ chọn)")
        self.email_edit.setVisible(False)
        self.pass_edit = QLineEdit(login_password)
        self.pass_edit.setPlaceholderText("Mật khẩu (tuỳ chọn)")
        self.pass_edit.setEchoMode(QLineEdit.Password)
        self.pass_edit.setVisible(False)

        self.status = QLabel("Chưa kiểm tra")
        self.status.setObjectName("AccountStatus")
        self.status.setMinimumWidth(190)
        self.status.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.display_email = QLabel(display_email or "Mail đang đăng nhập: -")
        self.display_email.setObjectName("AccountEmail")
        self.display_email.setMinimumWidth(240)
        self.display_email.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self.check_btn = QPushButton("Kiểm tra")
        self.check_btn.setObjectName("CheckButton")
        self.login_btn = QPushButton("Đăng nhập")
        self.login_btn.setObjectName("LoginButton")
        self.remove_btn = QPushButton("Xóa")
        self.remove_btn.setObjectName("DangerButton")
        self.login_btn.setFixedWidth(106)
        self.check_btn.setFixedWidth(74)
        self.remove_btn.setFixedWidth(56)

        lay.addWidget(self.title)
        lay.addWidget(self.up_btn)
        lay.addWidget(self.down_btn)
        # v79.2: không add acc_chip/account_edit vào layout để giao diện gọn hơn.
        lay.addWidget(self.status, 2)
        lay.addWidget(self.display_email, 3)
        lay.addStretch(1)
        lay.addWidget(self.login_btn)
        lay.addWidget(self.check_btn)
        lay.addWidget(self.remove_btn)

        self.up_btn.clicked.connect(lambda: self.app.move_account_row(self, -1))
        self.down_btn.clicked.connect(lambda: self.app.move_account_row(self, 1))
        self.account_edit.textChanged.connect(self.app.schedule_save_state)
        self.email_edit.textChanged.connect(self.app.schedule_save_state)
        self.pass_edit.textChanged.connect(self.app.schedule_save_state)
        self.check_btn.clicked.connect(self.check)
        self.login_btn.clicked.connect(self.login_manual)
        self.remove_btn.clicked.connect(self.remove)
        self.update_title(row_no)

        # Context menu for optional credential fields.
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._menu)

    def _menu(self, pos):
        m = QMenu(self)
        a1 = QAction("Hiện/ẩn ô email & mật khẩu auto-login", self)
        a1.triggered.connect(self._toggle_credentials_dialog)
        m.addAction(a1)
        m.exec(self.mapToGlobal(pos))

    def _toggle_credentials_dialog(self):
        dlg = QMessageBox(self)
        dlg.setWindowTitle("Auto-login tùy chọn")
        dlg.setText("Bản Qt vẫn giữ ô email/mật khẩu trong state, nhưng mặc định ẩn để giao diện gọn. Dùng đăng nhập thủ công thường an toàn hơn.")
        dlg.setInformativeText(f"Email đang lưu: {self.email_edit.text().strip() or '-'}")
        dlg.exec()

    def update_title(self, row_no):
        self.title.setText(f"Tài khoản {row_no}")

    def set_move_enabled(self, can_up, can_down):
        try:
            self.up_btn.setEnabled(bool(can_up))
            self.down_btn.setEnabled(bool(can_down))
        except Exception:
            pass

    def account_no(self):
        return int(str(self.account_edit.text()).strip())

    def profile_path(self):
        return self.app.backend_dir / "profiles" / f"google_{self.account_no()}"

    def set_status(self, ok, msg, email=""):
        self.ok = bool(ok)
        if ok:
            try:
                self.app._clear_account_force_login(self.account_no())
            except Exception:
                pass
            self.status.setText(f"✅ {msg}")
            self.status.setStyleSheet(f"color:#ecfdf5; font-weight:900; background:#11351f; border:1px solid {GREEN}; border-radius:8px; padding:7px 9px;")
        else:
            self.status.setText(f"⚠ {msg}")
            self.status.setStyleSheet(f"color:#fff7cc; font-weight:900; background:#3a2f12; border:1px solid {YELLOW}; border-radius:8px; padding:7px 9px;")
        if email:
            self.display_email.setText(f"Mail đang đăng nhập: {email}")
        elif not ok:
            self.display_email.setText("Mail đang đăng nhập: -")
        self.app.schedule_save_state()

    def check(self):
        self.app.check_account_row_hidden(self)

    def login_manual(self):
        try:
            if self.app.start_login_assist_for_row(self):
                return
            prof = self.profile_path()
            prof.mkdir(parents=True, exist_ok=True)
            chrome = self.app.chrome_binary
            if not chrome.exists():
                QMessageBox.warning(self, APP_TITLE, f"Không thấy Chrome portable:\n{chrome}")
                return
            args = build_persistent_login_args(chrome, prof)
            subprocess.Popen(args)
            self.app.append_log(f"[login] mở Chrome thật để đăng nhập/refresh session A{self.account_no()} • profile giữ cố định: {prof}")
            self.app.append_log("[login] đăng nhập xong hãy vào được Gemini, rồi đóng Chrome đó trước khi chạy worker để tránh khóa profile")
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def remove(self):
        self.app.remove_account_row(self)

    def as_state(self):
        try:
            acc = self.account_no()
        except Exception:
            acc = None
        return {
            "account_no": acc,
            "login_email": self.email_edit.text().strip(),
            "login_password": "",  # v6.1: không lưu mật khẩu thô trong state; dùng login_vault.json mã hóa
            "display_email": self.display_email.text().replace("Mail đang đăng nhập:", "").strip().strip("-"),
        }


class _ChannelBrandSignals(QObject):
    names_ready = Signal(object)
    logo_ready = Signal(object)
    logo_progress = Signal(int, str)
    failed = Signal(str)
    status = Signal(str)


class ChannelBrandDialog(QWidget):
    """v13.44: tối ưu luồng sửa mô tả, cứu lỗi 60 giây, log ngôn ngữ và tự chọn file lỗi."""
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.setObjectName("BrandWorkspace")
        self.setMinimumSize(760, 620)
        self._busy = False
        self._last_logo_path = ""
        self._all_logo_paths = []
        self._selected_name = ""
        self._selected_logo_idx = -1
        self._selected_logo_name = ""
        self._selected_logo_channel_name = ""
        self._name_buttons = []
        self._name_copy_buttons = []
        self._logo_buttons = []
        self._logo_cards = []
        self._logo_slot_labels = []
        self._logo_meta_labels = []
        self._logo_download_buttons = []
        self._logo_swap_buttons = []
        self._logo_preview_map = []
        self._name_count = 10
        self._logo_count = 4
        self._logo_parallel_count = 6
        self._can_more_names = False
        self._name_request_mode = "initial"

        self.signals = _ChannelBrandSignals(self)
        self.signals.names_ready.connect(self._on_names_ready)
        self.signals.logo_ready.connect(self._on_logo_ready)
        self.signals.logo_progress.connect(self._on_logo_progress)
        self.signals.failed.connect(self._on_failed)
        self.signals.status.connect(self._set_status)

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 16)
        root.setSpacing(12)

        header = QFrame()
        header.setObjectName("WorkspaceHeader")
        header_lay = QVBoxLayout(header)
        header_lay.setContentsMargins(16, 12, 16, 12)
        header_lay.setSpacing(2)
        title = QLabel("Tạo Tên Kênh & Logo")
        title.setObjectName("WorkspaceTitle")
        subtitle = QLabel("Tạo tên kênh và chọn logo.")
        subtitle.setObjectName("WorkspaceSubtitle")
        header_lay.addWidget(title)
        header_lay.addWidget(subtitle)
        root.addWidget(header, 0)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(12)
        root.addLayout(body, 1)

        left = QVBoxLayout()
        left.setContentsMargins(0, 0, 0, 0)
        left.setSpacing(10)
        body.addLayout(left, 3)

        key_box = QGroupBox("01  Thông tin kênh")
        key_lay = QVBoxLayout(key_box)
        key_lay.setContentsMargins(12, 18, 12, 12)
        key_lay.setSpacing(6)

        key_label = QLabel("KEY / chủ đề chính")
        key_label.setObjectName("FieldLabel")
        self.key_edit = QLineEdit()
        self.key_edit.setPlaceholderText("Ví dụ: Italian Disco, Slow Jams R&B, Japanese Nostalgia...")
        self.key_edit.setMinimumHeight(34)
        key_lay.addWidget(key_label)
        key_lay.addWidget(self.key_edit)

        note_label = QLabel("Ghi chú / điều kiện về tên kênh")
        note_label.setObjectName("FieldLabel")
        self.notes_edit = QPlainTextEdit()
        self.notes_edit.setPlaceholderText(
            "Ví dụ: tên ngắn, dễ nhớ, có chữ Hits ở cuối, không dùng số, phong cách cổ điển..."
        )
        self.notes_edit.setMaximumHeight(86)
        key_lay.addWidget(note_label)
        key_lay.addWidget(self.notes_edit)

        name_actions = QHBoxLayout()
        name_actions.setSpacing(7)
        self.btn_names = QPushButton("✦  Tạo 10 tên kênh")
        self.btn_names.setObjectName("PrimaryAction")
        self.btn_names.setMinimumHeight(36)
        self.btn_names.clicked.connect(self._start_generate_names)
        self.btn_more_names = QPushButton("Đổi 10 tên khác")
        self.btn_more_names.setObjectName("SecondaryAction")
        self.btn_more_names.setMinimumHeight(36)
        self.btn_more_names.setEnabled(False)
        self.btn_more_names.clicked.connect(self._start_generate_more_names)
        name_actions.addWidget(self.btn_names, 1)
        name_actions.addWidget(self.btn_more_names, 1)
        key_lay.addLayout(name_actions)
        left.addWidget(key_box, 0)

        names_box = QGroupBox("02  Chọn tên kênh (10 ô)")
        names_lay = QVBoxLayout(names_box)
        names_lay.setContentsMargins(12, 18, 12, 12)
        names_lay.setSpacing(8)

        self.name_hint = QLabel("Bấm tên để chọn • bấm ⧉ để sao chép.")
        self.name_hint.setObjectName("WorkspaceSubtitle")
        self.name_hint.setWordWrap(True)
        names_lay.addWidget(self.name_hint, 0)

        self.names_scroll = QScrollArea()
        self.names_scroll.setWidgetResizable(True)
        self.names_scroll.setFrameShape(QFrame.NoFrame)
        self.names_wrap = QWidget()
        self.names_grid = QGridLayout(self.names_wrap)
        self.names_grid.setContentsMargins(0, 0, 0, 0)
        self.names_grid.setHorizontalSpacing(8)
        self.names_grid.setVerticalSpacing(8)
        self.names_scroll.setWidget(self.names_wrap)
        names_lay.addWidget(self.names_scroll, 1)

        actions = QHBoxLayout()
        actions.setSpacing(7)
        self.btn_logo = QPushButton("Tạo logo (4 ô chọn)")
        self.btn_logo.setObjectName("PrimaryAction")
        self.btn_logo.setEnabled(False)
        self.btn_logo.setMinimumHeight(36)
        self.btn_logo.clicked.connect(self._start_generate_logo)
        self.btn_open = QPushButton("Mở thư mục")
        self.btn_open.setObjectName("SecondaryAction")
        self.btn_open.setEnabled(False)
        self.btn_open.setMinimumHeight(36)
        self.btn_open.clicked.connect(self._open_output_folder)
        actions.addWidget(self.btn_logo, 2)
        actions.addWidget(self.btn_open, 1)
        names_lay.addLayout(actions)
        left.addWidget(names_box, 1)

        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(10)
        body.addLayout(right, 2)

        preview_box = QGroupBox("03  Chọn logo (4 ô)")
        preview_lay = QVBoxLayout(preview_box)
        preview_lay.setContentsMargins(12, 18, 12, 12)
        preview_lay.setSpacing(8)
        self.logo_hint = QLabel("Chọn logo phù hợp nhất.")
        self.logo_hint.setObjectName("WorkspaceSubtitle")
        self.logo_hint.setWordWrap(True)
        preview_lay.addWidget(self.logo_hint, 0)

        selected_bar = QFrame()
        selected_bar.setObjectName("BrandSelectedBar")
        selected_lay = QHBoxLayout(selected_bar)
        selected_lay.setContentsMargins(10, 7, 8, 7)
        selected_lay.setSpacing(8)
        selected_caption = QLabel("TÊN ĐANG CHỌN")
        selected_caption.setObjectName("BrandSelectedCaption")
        self.preview_name_label = QLabel("Chưa chọn tên kênh")
        self.preview_name_label.setObjectName("BrandSelectedName")
        self.preview_name_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.preview_name_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.btn_copy_selected_name = QPushButton("⧉  Sao chép")
        self.btn_copy_selected_name.setObjectName("NameCopyButton")
        self.btn_copy_selected_name.setEnabled(False)
        self.btn_copy_selected_name.setToolTip("Sao chép tên kênh đang chọn")
        self.btn_copy_selected_name.clicked.connect(self._copy_selected_name)
        selected_lay.addWidget(selected_caption, 0)
        selected_lay.addWidget(self.preview_name_label, 1)
        selected_lay.addWidget(self.btn_copy_selected_name, 0)
        preview_lay.addWidget(selected_bar, 0)

        grid_wrap = QWidget()
        grid_wrap.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.logo_grid = QGridLayout(grid_wrap)
        self.logo_grid.setContentsMargins(0, 4, 0, 2)
        self.logo_grid.setHorizontalSpacing(12)
        self.logo_grid.setVerticalSpacing(10)
        self.logo_grid.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        self.logo_grid.setColumnStretch(0, 1)
        self.logo_grid.setColumnStretch(1, 1)
        for idx in range(self._logo_count):
            card = QFrame()
            card.setObjectName("BrandPreviewCard")
            card.setProperty("selected", False)
            card.setProperty("ready", False)
            card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            card_lay = QVBoxLayout(card)
            card_lay.setContentsMargins(10, 10, 10, 10)
            card_lay.setSpacing(8)

            top_row = QHBoxLayout()
            top_row.setContentsMargins(0, 0, 0, 0)
            top_row.setSpacing(6)
            slot_label = QLabel(f"Logo {idx + 1}")
            slot_label.setObjectName("BrandPreviewBadge")
            top_row.addWidget(slot_label, 0)
            top_row.addStretch(1)

            download_btn = QToolButton()
            download_btn.setObjectName("LogoCornerAction")
            download_btn.setText("↓")
            download_btn.setToolTip(f"Tải Logo {idx + 1}")
            download_btn.setAutoRaise(False)
            download_btn.setFixedSize(28, 28)
            download_btn.setEnabled(False)
            download_btn.clicked.connect(lambda checked=False, i=idx: self._download_logo_slot(i))
            top_row.addWidget(download_btn, 0)
            self._logo_download_buttons.append(download_btn)

            swap_btn = QToolButton()
            swap_btn.setObjectName("LogoCornerAction")
            swap_btn.setText("↻")
            swap_btn.setToolTip(f"Đổi logo ở ô {idx + 1}")
            swap_btn.setAutoRaise(False)
            swap_btn.setFixedSize(28, 28)
            swap_btn.setEnabled(False)
            swap_btn.clicked.connect(lambda checked=False, i=idx: self._swap_logo_preview(i))
            top_row.addWidget(swap_btn, 0)
            self._logo_swap_buttons.append(swap_btn)
            card_lay.addLayout(top_row)

            btn = QToolButton()
            btn.setCheckable(True)
            btn.setToolButtonStyle(Qt.ToolButtonIconOnly)
            btn.setIconSize(QSize(134, 134))
            btn.setMinimumSize(164, 164)
            btn.setMaximumHeight(176)
            btn.setText("")
            btn.setToolTip(f"Chọn Logo {idx + 1}")
            btn.clicked.connect(lambda checked=False, i=idx: self._select_logo(i))
            card_lay.addWidget(btn, 1)
            self._logo_buttons.append(btn)

            meta = QLabel("Chưa tạo")
            meta.setObjectName("BrandPreviewMeta")
            meta.setAlignment(Qt.AlignCenter)
            meta.setMinimumHeight(18)
            meta.setWordWrap(False)
            card_lay.addWidget(meta, 0)
            self._logo_meta_labels.append(meta)

            self._logo_cards.append(card)
            self._logo_slot_labels.append(slot_label)
            self.logo_grid.addWidget(card, idx // 2, idx % 2)
        preview_lay.addWidget(grid_wrap, 0)

        self.logo_pool_label = QLabel("4 logo để chọn")
        self.logo_pool_label.setObjectName("LogoPoolChip")
        self.logo_pool_label.setAlignment(Qt.AlignCenter)
        self.logo_pool_label.setMinimumHeight(30)
        preview_lay.addWidget(self.logo_pool_label, 0)

        preview_actions = QHBoxLayout()
        preview_actions.setSpacing(7)
        self.btn_download_selected = QPushButton("Tải logo chọn")
        self.btn_download_selected.setObjectName("SecondaryAction")
        self.btn_download_selected.setEnabled(False)
        self.btn_download_selected.setMinimumHeight(34)
        self.btn_download_selected.setVisible(False)
        self.btn_download_selected.clicked.connect(self._download_selected_logo)
        self.btn_download_all = QPushButton("Tải tất cả 4 logo")
        self.btn_download_all.setObjectName("SecondaryAction")
        self.btn_download_all.setEnabled(False)
        self.btn_download_all.setMinimumHeight(34)
        self.btn_download_all.clicked.connect(self._download_all_logos)
        preview_actions.addWidget(self.btn_download_all, 1)
        preview_lay.addLayout(preview_actions)
        preview_box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
        right.addWidget(preview_box, 0)

        self.status = QLabel("Sẵn sàng")
        self.status.setObjectName("StatusPill")
        self.status.setWordWrap(True)
        self.status.setMinimumHeight(38)
        right.addWidget(self.status, 0)
        right.addStretch(1)

        self._reset_name_grid()
        self._reset_logo_grid()

    def _style_name_button(self, btn, selected=False):
        if selected:
            btn.setStyleSheet(
                "QPushButton{background:#2f66f2;color:white;border:2px solid #74a3ff;border-radius:10px;"
                "padding:10px 8px;font-weight:700;text-align:left;}"
            )
        else:
            btn.setStyleSheet(
                "QPushButton{background:#0c1d39;color:#eaf2ff;border:1px solid #35568f;border-radius:10px;"
                "padding:10px 8px;font-weight:600;text-align:left;}"
                "QPushButton:hover{border:1px solid #5e8ef9;background:#10274c;}"
            )

    def _style_logo_button(self, btn, selected=False):
        border = '#60a5fa' if selected else '#d1deeb'
        width = '2px' if selected else '1px'
        bg = '#eef5ff' if selected else '#ffffff'
        btn.setStyleSheet(
            f"QToolButton{{background:{bg};color:#eaf2ff;border:{width} solid {border};border-radius:14px;padding:6px;}}"
            "QToolButton:hover{border:2px solid #60a5fa;background:#f8fbff;}"
        )

    def _style_logo_card(self, card, selected=False, ready=False):
        bg = '#ffffff' if ready else '#f8fbff'
        border = '#60a5fa' if selected else ('#d7e3ef' if ready else '#e1e9f2')
        width = '2px' if selected else '1px'
        card.setStyleSheet(
            f"QFrame{{background:{bg};border:{width} solid {border};border-radius:14px;}}"
            f"QFrame:hover{{border:1px solid #93c5fd; background:#fbfdff;}}"
        )
        card.setProperty('selected', bool(selected))
        card.setProperty('ready', bool(ready))

    def _clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            child = item.layout()
            if w is not None:
                w.deleteLater()
            elif child is not None:
                self._clear_layout(child)

    def _reset_name_grid(self):
        self._selected_name = ""
        self._name_buttons = []
        self._name_copy_buttons = []
        self._clear_layout(self.names_grid)
        try:
            self.preview_name_label.setText("Chưa chọn tên kênh")
            self.btn_copy_selected_name.setEnabled(False)
        except Exception:
            pass
        for idx in range(self._name_count):
            card = QFrame()
            card.setObjectName("BrandNameCard")
            card_lay = QHBoxLayout(card)
            card_lay.setContentsMargins(0, 0, 0, 0)
            card_lay.setSpacing(6)

            btn = QPushButton(f"Ô tên kênh {idx + 1}")
            btn.setEnabled(False)
            btn.setCheckable(True)
            btn.setMinimumHeight(54)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn.clicked.connect(lambda checked=False, i=idx: self._select_name(i))
            self._style_name_button(btn, False)
            card_lay.addWidget(btn, 1)
            self._name_buttons.append(btn)

            copy_btn = QPushButton("⧉")
            copy_btn.setObjectName("NameCopyButton")
            copy_btn.setToolTip("Sao chép tên kênh")
            copy_btn.setFixedSize(42, 54)
            copy_btn.setEnabled(False)
            copy_btn.clicked.connect(lambda checked=False, i=idx: self._copy_name(i))
            card_lay.addWidget(copy_btn, 0)
            self._name_copy_buttons.append(copy_btn)

            self.names_grid.addWidget(card, idx // 2, idx % 2)

    def _copy_name(self, idx):
        if idx < 0 or idx >= len(self._name_buttons):
            return
        name = str(self._name_buttons[idx].property('brand_name') or '').strip()
        if not name:
            return
        QApplication.clipboard().setText(name)
        self._set_status(f"Đã sao chép tên kênh: {name}")

    def _copy_selected_name(self):
        name = str(self._selected_name or '').strip()
        if not name:
            return
        QApplication.clipboard().setText(name)
        self._set_status(f"Đã sao chép tên kênh: {name}")

    def _reset_logo_grid(self):
        self._all_logo_paths = []
        self._logo_preview_map = list(range(self._logo_count))
        self._selected_logo_idx = -1
        self._last_logo_path = ''
        self._selected_logo_name = ""
        self._selected_logo_channel_name = ""
        self.btn_download_selected.setEnabled(False)
        self.btn_download_all.setEnabled(False)
        try:
            self.logo_pool_label.setText("4 logo để chọn")
        except Exception:
            pass
        for idx, btn in enumerate(self._logo_buttons):
            btn.setProperty('logo_path', '')
            btn.setProperty('source_index', -1)
            btn.blockSignals(True)
            btn.setChecked(False)
            btn.blockSignals(False)
            btn.setIcon(QIcon())
            btn.setText('')
            btn.setEnabled(False)
            self._style_logo_button(btn, False)
            if idx < len(self._logo_cards):
                self._style_logo_card(self._logo_cards[idx], False, False)
            if idx < len(self._logo_slot_labels):
                self._logo_slot_labels[idx].setText(f"Logo {idx + 1}")
            if idx < len(self._logo_meta_labels):
                self._logo_meta_labels[idx].setText("Chưa tạo")
            if idx < len(self._logo_download_buttons):
                self._logo_download_buttons[idx].setEnabled(False)
        for btn in self._logo_swap_buttons:
            btn.setEnabled(False)

    def _refresh_logo_preview_buttons(self):
        valid_positions = [i for i, x in enumerate(self._all_logo_paths or []) if str(x or '').strip() and Path(str(x)).is_file()]
        if not self._logo_preview_map:
            self._logo_preview_map = list(range(self._logo_count))
        used = set()
        for idx in range(self._logo_count):
            current = self._logo_preview_map[idx] if idx < len(self._logo_preview_map) else idx
            if current in valid_positions and current not in used:
                used.add(current)
                continue
            replacement = next((pos for pos in valid_positions if pos not in used), -1)
            if idx < len(self._logo_preview_map):
                self._logo_preview_map[idx] = replacement
            else:
                self._logo_preview_map.append(replacement)
            if replacement >= 0:
                used.add(replacement)
        displayed = {x for x in self._logo_preview_map if isinstance(x, int) and x >= 0}
        hidden_alternatives = [pos for pos in valid_positions if pos not in displayed]
        for idx, btn in enumerate(self._logo_buttons):
            src_idx = self._logo_preview_map[idx] if idx < len(self._logo_preview_map) else -1
            path = ''
            if src_idx >= 0 and src_idx < len(self._all_logo_paths):
                path = str(self._all_logo_paths[src_idx] or '').strip()
            btn.setProperty('logo_path', path)
            btn.setProperty('source_index', src_idx)
            ready = bool(path and Path(path).is_file())
            if ready:
                pix = QPixmap(path)
                if not pix.isNull():
                    btn.setIcon(QIcon(pix))
                else:
                    btn.setIcon(QIcon())
                    ready = False
            else:
                btn.setIcon(QIcon())
            btn.setText('')
            btn.blockSignals(True)
            if not path:
                btn.setChecked(False)
            btn.blockSignals(False)
            btn.setEnabled(bool(path))
            self._style_logo_button(btn, self._selected_logo_idx == idx and bool(path))
            if idx < len(self._logo_cards):
                self._style_logo_card(self._logo_cards[idx], self._selected_logo_idx == idx and bool(path), ready)
            if idx < len(self._logo_slot_labels):
                if self._selected_logo_idx == idx and path:
                    self._logo_slot_labels[idx].setText(f"Logo {idx + 1} • Đang chọn")
                else:
                    self._logo_slot_labels[idx].setText(f"Logo {idx + 1}")
            if idx < len(self._logo_meta_labels):
                if ready:
                    meta = Path(path).name
                    if len(meta) > 26:
                        meta = meta[:23] + '...'
                    self._logo_meta_labels[idx].setText(meta)
                else:
                    self._logo_meta_labels[idx].setText("Chưa tạo")
            if idx < len(self._logo_download_buttons):
                self._logo_download_buttons[idx].setEnabled(bool(path))
            if idx < len(self._logo_swap_buttons):
                local_current = src_idx if ready else -1
                local_hidden = [pos for pos in valid_positions if pos != local_current and pos not in (displayed - ({src_idx} if src_idx >= 0 else set()))]
                self._logo_swap_buttons[idx].setEnabled(bool(ready and local_hidden))
        self.btn_open.setEnabled(any(bool(self._all_logo_paths[i]) for i in valid_positions))
        self.btn_download_all.setEnabled(any(bool(self._all_logo_paths[i]) for i in valid_positions))
        if self._selected_logo_idx >= 0:
            current = str(self._logo_buttons[self._selected_logo_idx].property('logo_path') or '')
            if not current:
                self._selected_logo_idx = -1
                self._last_logo_path = ''
                self.btn_download_selected.setEnabled(False)

    def _swap_logo_preview(self, idx):
        if idx < 0 or idx >= self._logo_count:
            return
        valid_positions = [i for i, x in enumerate(self._all_logo_paths or []) if str(x or '').strip() and Path(str(x)).is_file()]
        if not valid_positions:
            return
        if not self._logo_preview_map:
            self._logo_preview_map = list(range(self._logo_count))
        current = self._logo_preview_map[idx] if idx < len(self._logo_preview_map) else -1
        if current not in valid_positions:
            current = -1
        displayed_other = {x for i, x in enumerate(self._logo_preview_map) if i != idx and isinstance(x, int) and x >= 0}
        hidden_alternatives = [pos for pos in valid_positions if pos != current and pos not in displayed_other]
        if not hidden_alternatives:
            self._set_status("Chưa có logo ẩn khác để đổi. Tool vẫn đang tiếp tục tạo/lưu các logo còn lại.")
            return
        next_pos = hidden_alternatives[0]
        if current in valid_positions:
            ordered = [pos for pos in valid_positions if pos not in displayed_other]
            try:
                cur_idx = ordered.index(current)
                next_pos = ordered[(cur_idx + 1) % len(ordered)]
            except Exception:
                next_pos = hidden_alternatives[0]
        if idx < len(self._logo_preview_map):
            self._logo_preview_map[idx] = next_pos
        else:
            self._logo_preview_map.append(next_pos)
        self._refresh_logo_preview_buttons()
        if self._selected_logo_idx == idx:
            self._select_logo(idx)
        else:
            self._set_status(f"Đã đổi ô Logo {idx + 1} sang {Path(str(self._all_logo_paths[next_pos])).name}")

    def _set_busy(self, busy):
        self._busy = bool(busy)
        self.btn_names.setEnabled(not busy)
        self.btn_more_names.setEnabled((not busy) and self._can_more_names)
        self._update_logo_button()
        if busy:
            self.btn_logo.setEnabled(False)
        for btn in self._name_buttons:
            btn.setEnabled((not busy) and bool(btn.property('brand_name')))
        for btn in self._name_copy_buttons:
            btn.setEnabled(bool(btn.property('brand_name')))
        try:
            self.btn_copy_selected_name.setEnabled(bool(self._selected_name))
        except Exception:
            pass
        # Không disable card logo khi các worker còn chạy: Qt sẽ tự biến QIcon thành grayscale.
        # Logo nào đã có vẫn phải xem/chọn/tải ngay trong lúc các Chrome khác tiếp tục tạo.
        for btn in self._logo_buttons:
            btn.setEnabled(bool(btn.property('logo_path')))
        try:
            self._refresh_logo_preview_buttons()
        except Exception:
            pass

    def _set_status(self, text):
        self.status.setText(str(text or ""))

    def _select_name(self, idx):
        if idx < 0 or idx >= len(self._name_buttons):
            return
        chosen = ""
        for i, btn in enumerate(self._name_buttons):
            is_sel = (i == idx)
            btn.blockSignals(True)
            btn.setChecked(is_sel)
            btn.blockSignals(False)
            self._style_name_button(btn, is_sel)
            if is_sel:
                chosen = str(btn.property('brand_name') or btn.text() or '').strip()
        self._selected_name = chosen
        self._selected_logo_channel_name = chosen
        self._update_logo_button()
        try:
            self.preview_name_label.setText(chosen or "Chưa chọn tên kênh")
            self.btn_copy_selected_name.setEnabled(bool(chosen))
        except Exception:
            pass
        if chosen:
            self._set_status(f"Đã chọn tên kênh: {chosen}")

    def _select_logo(self, idx):
        if idx < 0 or idx >= len(self._logo_buttons):
            return
        self._selected_logo_idx = idx
        self._last_logo_path = ""
        for i, btn in enumerate(self._logo_buttons):
            is_sel = (i == idx)
            btn.blockSignals(True)
            btn.setChecked(is_sel)
            btn.blockSignals(False)
            if is_sel:
                self._last_logo_path = str(btn.property('logo_path') or '')
        self._refresh_logo_preview_buttons()
        self.btn_open.setEnabled(bool(self._last_logo_path or self._all_logo_paths))
        self.btn_download_selected.setEnabled(bool(self._last_logo_path))
        self.btn_download_all.setEnabled(any(bool(x) for x in self._all_logo_paths))
        if self._last_logo_path:
            self._selected_logo_name = Path(self._last_logo_path).name
            self._set_status(f"Đã chọn logo: {Path(self._last_logo_path).name}")

    def _update_logo_button(self):
        self.btn_logo.setEnabled((not self._busy) and bool(self._selected_name))

    def _start_generate_names(self):
        key = self.key_edit.text().strip()
        notes = self.notes_edit.toPlainText().strip()
        if not key:
            QMessageBox.information(self, APP_TITLE, "Hãy nhập KEY / chủ đề chính trước.")
            return
        if self._busy:
            return
        self._name_request_mode = "initial"
        self._can_more_names = False
        self._set_busy(True)
        self._reset_name_grid()
        self._reset_logo_grid()
        self._set_status("Đang tạo 10 tên kênh…")

        def work():
            try:
                names = self.app._channel_brand_generate_names(key, notes, None, reuse_conversation=False)
                self.signals.names_ready.emit(names)
            except Exception as e:
                self.signals.failed.emit(str(e))
        threading.Thread(target=work, name="ChannelBrandNames", daemon=True).start()

    def _start_generate_more_names(self):
        if self._busy or not self._can_more_names:
            return
        key = str(getattr(self.app, '_channel_brand_name_key', '') or self.key_edit.text()).strip()
        notes = str(getattr(self.app, '_channel_brand_name_notes', '') or self.notes_edit.toPlainText()).strip()
        if key:
            self.key_edit.setText(key)
        self.notes_edit.setPlainText(notes)
        self._name_request_mode = "more"
        self._set_busy(True)
        self._reset_logo_grid()
        self._set_status("Đang đổi 10 tên khác…")

        def work():
            try:
                names = self.app._channel_brand_generate_names(key, notes, None, reuse_conversation=True)
                self.signals.names_ready.emit(names)
            except Exception as e:
                self.signals.failed.emit(str(e))
        threading.Thread(target=work, name="ChannelBrandMoreNames", daemon=True).start()

    def _on_names_ready(self, names):
        self._reset_name_grid()
        names = list(names or [])[: self._name_count]
        for idx, name in enumerate(names):
            btn = self._name_buttons[idx]
            btn.setText(str(name))
            btn.setProperty('brand_name', str(name))
            btn.setEnabled(True)
            self._style_name_button(btn, False)
            if idx < len(self._name_copy_buttons):
                copy_btn = self._name_copy_buttons[idx]
                copy_btn.setProperty('brand_name', str(name))
                copy_btn.setEnabled(True)
                copy_btn.setToolTip(f"Sao chép: {name}")
        self.name_hint.setText("Bấm tên để chọn • bấm ⧉ để sao chép.")
        if names:
            self._select_name(0)
            self._can_more_names = True
        self._set_busy(False)
        self._set_status("Sẵn sàng")

    def _start_generate_logo(self):
        name = str(self._selected_name or '').strip()
        if not name:
            QMessageBox.information(self, APP_TITLE, "Hãy chọn một tên kênh trước.")
            return
        if self._busy:
            return
        key = self.key_edit.text().strip()
        notes = self.notes_edit.toPlainText().strip()
        self._set_busy(True)
        self._reset_logo_grid()
        self._selected_logo_channel_name = name
        self.logo_hint.setText("Chọn logo phù hợp nhất.")
        self._set_status(f"Đang tạo logo cho: {name}")

        def work():
            try:
                logo_paths = self.app._channel_brand_generate_logos(name, key, notes, self._logo_parallel_count, None, self.signals.logo_progress.emit)
                self.signals.logo_ready.emit([str(x) for x in (logo_paths or [])])
            except Exception as e:
                self.signals.failed.emit(str(e))
        threading.Thread(target=work, name="ChannelBrandLogo", daemon=True).start()

    def _on_logo_progress(self, slot_no, path):
        try:
            idx = int(slot_no) - 1
        except Exception:
            return
        path = str(path or '').strip()
        if not path:
            return
        while len(self._all_logo_paths) < self._logo_parallel_count:
            self._all_logo_paths.append('')
        if idx < 0 or idx >= len(self._all_logo_paths):
            return
        self._all_logo_paths[idx] = path
        self._refresh_logo_preview_buttons()
        self.logo_pool_label.setText("4 logo để chọn")
        self.logo_hint.setText("Chọn logo phù hợp nhất.")
        if self._selected_logo_idx < 0:
            for i, btn in enumerate(self._logo_buttons):
                if str(btn.property('logo_path') or '').strip():
                    self._select_logo(i)
                    break

    def _on_logo_ready(self, paths):
        incoming = [str(x or '').strip() for x in (paths or [])]
        if len(incoming) < self._logo_parallel_count:
            incoming.extend([''] * (self._logo_parallel_count - len(incoming)))
        self._all_logo_paths = incoming[:self._logo_parallel_count]
        self._refresh_logo_preview_buttons()
        valid_count = sum(1 for x in self._all_logo_paths if x)
        shown_count = min(valid_count, self._logo_count)
        self.logo_pool_label.setText("4 logo để chọn")
        if shown_count:
            try:
                first_idx = next(i for i, btn in enumerate(self._logo_buttons) if str(btn.property('logo_path') or '').strip())
                self._select_logo(first_idx)
            except Exception:
                pass
        self.logo_hint.setText("Chọn logo phù hợp nhất.")
        self.btn_open.setEnabled(any(bool(x) for x in self._all_logo_paths))
        self.btn_download_all.setEnabled(any(bool(x) for x in self._all_logo_paths))
        self._set_busy(False)
        self._set_status("Hoàn tất")

    def _on_failed(self, message):
        self._set_busy(False)
        self._set_status("Lỗi: " + str(message))
        self.logo_hint.setText("Chọn logo phù hợp nhất.")
        QMessageBox.warning(self, "Tạo tên kênh & Logo", str(message))

    def _safe_logo_slug(self, text):
        txt = re.sub(r'[^A-Za-z0-9._-]+', '_', str(text or '').strip())
        txt = txt.strip('._-')
        return txt or 'logo'

    def _download_logo_slot(self, idx):
        if idx < 0 or idx >= len(self._logo_buttons):
            return
        src = str(self._logo_buttons[idx].property('logo_path') or '').strip()
        if not src or not Path(src).is_file():
            return
        self._selected_logo_idx = idx
        self._last_logo_path = src
        self._selected_logo_name = Path(src).name
        self._refresh_logo_preview_buttons()
        self._download_selected_logo()

    def _download_selected_logo(self):
        try:
            src = str(self._last_logo_path or '').strip()
            if not src or not Path(src).is_file():
                QMessageBox.information(self, APP_TITLE, 'Hãy chọn một logo trước.')
                return
            channel = self._selected_logo_channel_name or self._selected_name or 'channel_logo'
            base_name = self._safe_logo_slug(channel) + '_' + Path(src).name
            dest, _ = QFileDialog.getSaveFileName(self, 'Tải logo đã chọn', str(Path.home() / 'Downloads' / base_name), 'PNG files (*.png)')
            if not dest:
                return
            dest_path = Path(dest)
            if dest_path.suffix.lower() != '.png':
                dest_path = dest_path.with_suffix('.png')
            shutil.copy2(src, dest_path)
            self._set_status(f'Đã tải logo: {dest_path.name}')
        except Exception as e:
            QMessageBox.warning(self, APP_TITLE, str(e))

    def _download_all_logos(self):
        try:
            valid = [str(x) for x in self._all_logo_paths if str(x or '').strip() and Path(str(x)).is_file()]
            if not valid:
                QMessageBox.information(self, APP_TITLE, 'Chưa có logo nào để tải xuống.')
                return
            channel = self._selected_logo_channel_name or self._selected_name or 'channel_logo'
            folder = QFileDialog.getExistingDirectory(self, 'Chọn thư mục để tải tất cả logo', str(Path.home() / 'Downloads'))
            if not folder:
                return
            root = Path(folder)
            root.mkdir(parents=True, exist_ok=True)
            slug = self._safe_logo_slug(channel)
            count = 0
            for i, src in enumerate(self._all_logo_paths, start=1):
                src = str(src or '').strip()
                if not src or not Path(src).is_file():
                    continue
                dest = root / f'{slug}_logo_{i}.png'
                shutil.copy2(src, dest)
                count += 1
            self._set_status(f'Đã tải {count} logo vào: {root}')
            QMessageBox.information(self, APP_TITLE, f'Đã tải {count} logo vào\n{root}')
        except Exception as e:
            QMessageBox.warning(self, APP_TITLE, str(e))

    def _open_output_folder(self):
        try:
            if self._last_logo_path:
                target = Path(self._last_logo_path).parent
            elif self._all_logo_paths:
                target = Path(self._all_logo_paths[0]).parent
            else:
                target = self.app._channel_brand_output_root()
            target.mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                os.startfile(str(target))
            else:
                subprocess.Popen(["xdg-open", str(target)])
        except Exception as e:
            QMessageBox.warning(self, APP_TITLE, str(e))


class QtDashboard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(1820, 940)
        self.setMinimumSize(1500, 760)

        self.ui_queue = queue.Queue()
        self.rows = []
        self.jobs = []
        self.workers = []
        self.running = False
        self.run_dir = None
        self.current_root_folder = None
        self.current_logo_path = None
        self.current_workers_root = None
        self.active_accounts = set()
        self.exhausted_accounts = set()
        self.next_runtime_worker_id = 1
        self.run_lock = threading.RLock()  # v12.77: fix deadlock khi scheduler gọi steal_work lồng run_lock
        self.schedule_lock = threading.Lock()
        self._manifest_save_lock = threading.Lock()  # v13.44: chỉ một luồng manager ghi manifest
        self._account_rr_lock = threading.Lock()
        self._account_rr = []
        self._account_rr_index = 0
        # v55 fix: v54 thiếu 3 biến này nên nút Kiểm tra/Kiểm tra tất cả có thể không chạy.
        self._checking_lock = threading.Lock()
        self._checking_account_nos = set()
        self._checking_all = False
        self._chrome_guard_lock = threading.Lock()
        self._chrome_guard_stop = threading.Event()
        self._chrome_guard_thread = None
        self._chrome_guard_refs = 0
        self._thumb_cache = {}
        self._selected_thumbnail_paths = set()
        self._last_visible_thumbnail_paths = []
        self._last_preview_refresh_ts = 0.0
        self._preview_refresh_pending = False
        self._save_state_pending = False
        self._suspend_state_save = True
        self._log_lines = []
        self._last_log_line = None
        self._worker_items = {}
        self._worker_cards = {}
        self._last_worker_values = {}
        self._theme_mode = "dark"
        self._sidebar_visible = True
        self._channel_brand_dialog = None
        self._channel_brand_lock = threading.Lock()
        self._channel_brand_busy = False
        self._channel_brand_stop_event = threading.Event()
        # v13.40: giữ một Chromium/Gemini conversation và đọc ngay phản hồi tên mới.
        self._channel_brand_name_drv = None
        self._channel_brand_name_acc = None
        self._channel_brand_name_run_root = None
        self._channel_brand_name_key = ""
        self._channel_brand_name_notes = ""
        self._channel_brand_name_history = []
        # v58: modern job cards + lightweight animated spinner for running jobs.
        self._spin_index = 0
        self._spin_chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        self._running_spinner_labels = []
        self.run_started_at = None
        self.run_finished_at = None
        self.run_done_baseline = 0
        self.run_manifest_path = None
        self._finish_show_all_done = False
        self.error_stats = {}
        self.account_perf = {}
        # v13.48.2: giữ quota theo ngày + lịch sử chọn account qua lần mở tool mới.
        self._daily_quota_lock = threading.RLock()
        self._daily_quota_accounts = set()
        self._daily_quota_date = ""
        self._daily_quota_loaded = False
        self._daily_quota_file_mtime_ns = 0
        self._daily_quota_log_date = ""
        # v13.51: khi người dùng chủ động bấm Chạy queue lại, cho các account
        # đã chạm quota được thử lại 1 lần trong lượt chạy mới. File quota dùng chung
        # vẫn được giữ nguyên để không phá trạng thái của máy/tool khác.
        self._manual_quota_recheck_accounts = set()
        self._account_issue_once = set()
        self._account_history_lock = threading.RLock()
        self._account_history = {}
        self._account_history_loaded = False
        self._account_history_dirty = False
        self._last_account_history_save_ts = 0.0
        self._cooldown_schedule_pending = False
        self._last_manifest_save_ts = 0.0
        # v79.5: tự động chạy lại toàn bộ job lỗi cho đến khi hết lỗi.
        self.auto_rerun_failed_enabled = True
        self.auto_rerun_round = 0
        self.auto_rerun_max_rounds = 999999
        self._inside_auto_rerun = False
        # v113: Dừng/Tắt tool phải chặn mọi failover/auto-rerun và dọn sạch tiến trình phụ.
        self.stop_requested = False
        self._closing_now = False
        # v11.9: bỏ No Quit Guard/Thoát an toàn theo yêu cầu; closeEvent trở lại mặc định.
        self._allow_real_close = True
        self._external_close_blocked = 0
        self._check_stop_event = threading.Event()
        self._proxy_check_in_progress = False
        self._proxy_approved_accounts = None
        self._proxy_last_results = []
        self._proxy_has_config_for_run = False
        # v12.54: hàng chờ nhiều thư mục, mỗi thư mục dùng một logo riêng.
        self.project_queue = []
        self.queue_running = False
        self.current_queue_index = -1
        self._queue_advance_pending = False
        self._queue_autostarting = False
        # v12.54: hàng chờ thông minh - chạy chung các queue, worker rảnh được lấy queue sau.
        self.queue_smart_parallel = False
        # v12.78: nhánh Sửa mô tả độc lập, không dùng self.jobs để Danh sách job chỉ dành cho thumbnail.
        self.desc_jobs = []
        self.desc_running = False
        self.desc_stop_event = threading.Event()
        self.desc_lock = threading.RLock()
        self.desc_stats = {"total": 0, "done": 0, "error": 0, "running": 0, "queued": 0, "skipped": 0}
        self.desc_last_message = "Chưa quét mô tả"
        # v13.10: Sửa mô tả có thể lấy tự động nguồn từ Queue Thumbnail và thêm nhiều thư mục Crawl riêng.
        self.desc_custom_roots = []
        # v13.11: nguồn Crawl nhập trực tiếp từng dòng + dịch nhanh nhiều mô tả theo batch.
        self._desc_source_editor_syncing = False
        self.desc_translate_language = "English"
        self.desc_operation = "idle"
        # v8.2: login ngầm account pool dùng semaphore toàn cục, tránh mở 10-20 Chrome cùng lúc làm app tự tắt/Windows kill.
        try:
            self._pool_login_semaphore = threading.Semaphore(max(1, int(ACCOUNT_POOL_LOGIN_PARALLEL)))
        except Exception:
            self._pool_login_semaphore = threading.Semaphore(2)

        # v12.96: hệ thống cập nhật online mức 1.
        self._update_check_busy = False
        self._update_check_manual = False
        self._update_download_busy = False
        self._update_cancel_event = None
        self._update_progress_dialog = None
        self._update_signals = None

        self.backend_dir = Path(__file__).resolve().parent
        self.backend_file = self._detect_backend_file()
        self.chrome_binary = _auto_detect_npt_chromium_binary()
        self.driver_binary = _auto_detect_driver_binary(self.backend_dir)
        # v12.99: nhánh sửa mô tả có runtime Chrome/Driver riêng. Nếu tool chạy từ LAN,
        # runtime sẽ được cache về ổ máy để Chrome không chạy exe/profile trực tiếp trên UNC.
        self._desc_chrome_binary = self.chrome_binary
        self._desc_driver_binary = self.driver_binary
        self._desc_current_run_root = None
        self._desc_clone_semaphore = threading.Semaphore(1)
        self.persist_path = _primary_persist_path()
        try:
            self.append_log(f"[chromium] binary={self.chrome_binary}")
            self.append_log(f"[chromium] driver={self.driver_binary}")
        except Exception:
            pass

        self._build_ui()
        self._apply_style()
        self._update_theme_button()
        try:
            self._refresh_daily_quota_holds(log=True)
            self._load_account_selection_history()
        except Exception as _account_state_e:
            self.append_log(f"[account-state] đọc trạng thái account lỗi nhẹ: {_account_state_e}")
        self._set_state_info(f"save path {self.persist_path}")
        if LEGACY_PATH:
            self.append_log(f"[qt] dùng helper từ: {LEGACY_PATH.name}")
        else:
            self.append_log("[qt] không thấy v50/v49 để import helper; dùng fallback cơ bản")
        self.prune_old_run_dirs_async(keep=RUN_HISTORY_KEEP, reason="startup")
        self.prune_old_profile_dirs(keep=PROFILE_HISTORY_KEEP)
        self._update_proxy_toggle_text()
        self.load_state()
        self._ensure_project_queue_slots()
        self._refresh_project_queue_ui()
        if not self.rows:
            self.add_account_row()
        self._suspend_state_save = False
        self.save_state()

        self.drain_timer = QTimer(self)
        self.drain_timer.timeout.connect(self._drain)
        self.drain_timer.start(UI_DRAIN_NORMAL_MS)

        self.spinner_timer = QTimer(self)
        self.spinner_timer.timeout.connect(self._animate_spinners)
        self.spinner_timer.start(170)

        # v12.59: dispatch watchdog chạy nền. Chỉ gọi scheduler khi thật sự thiếu active worker,
        # không tính sai worker đang launch/login là đã chết.
        self.tail_rescue_timer = QTimer(self)
        self.tail_rescue_timer.timeout.connect(self._tail_rescue_tick)
        self.tail_rescue_timer.start(5000)

        # v12.96: kiểm tra update chạy nền, không làm chậm lúc mở giao diện.
        self._setup_online_update()

    def _setup_online_update(self):
        try:
            if _online_updater is None:
                self.append_log(f"[update] Không nạp được module updater: {_online_updater_import_error}")
                if hasattr(self, "update_btn"):
                    self.update_btn.setEnabled(False)
                    self.update_btn.setToolTip("Thiếu online_updater.py")
                return
            self._update_signals = _UpdateSignals(self)
            self._update_signals.update_found.connect(self._on_update_found)
            self._update_signals.no_update.connect(self._on_update_no_update)
            self._update_signals.check_failed.connect(self._on_update_check_failed)
            self._update_signals.download_progress.connect(self._on_update_download_progress)
            self._update_signals.download_finished.connect(self._on_update_download_finished)
            self._update_signals.download_failed.connect(self._on_update_download_failed)
            QTimer.singleShot(900, self._show_last_update_result)
            try:
                cfg = _online_updater.load_config(self.backend_dir)
                auto = bool(cfg.get("check_on_startup", True))
            except Exception:
                auto = True
            if auto:
                QTimer.singleShot(2600, lambda: self.check_for_updates(manual=False))
        except Exception as e:
            try:
                self.append_log(f"[update] Lỗi khởi tạo: {e}")
            except Exception:
                pass

    def _show_last_update_result(self):
        if _online_updater is None:
            return
        try:
            result = _online_updater.consume_last_result(self.backend_dir)
        except Exception:
            result = None
        if not result:
            return
        ok = bool(result.get("ok"))
        version = str(result.get("version") or APP_VERSION)
        message = str(result.get("message") or ("Cập nhật thành công" if ok else "Cập nhật thất bại"))
        log_path = str(result.get("log") or "")
        if ok:
            QMessageBox.information(
                self,
                "Cập nhật hoàn tất",
                f"Tool đã được cập nhật thành công lên phiên bản v{version}."
            )
        else:
            extra = f"\n\nLog: {log_path}" if log_path else ""
            QMessageBox.critical(self, "Cập nhật thất bại", message + extra)

    def check_for_updates(self, manual=True):
        if _online_updater is None:
            if manual:
                QMessageBox.warning(self, "Cập nhật", "Thiếu online_updater.py nên chưa thể kiểm tra cập nhật.")
            return
        if self._update_check_busy or self._update_download_busy:
            if manual:
                QMessageBox.information(self, "Cập nhật", "Tool đang kiểm tra hoặc tải bản cập nhật.")
            return
        self._update_check_busy = True
        self._update_check_manual = bool(manual)
        if hasattr(self, "update_btn"):
            self.update_btn.setEnabled(False)
            self.update_btn.setToolTip("Đang kiểm tra cập nhật online…")

        def worker():
            try:
                info = _online_updater.check_for_update(self.backend_dir)
                if bool(info.get("available")):
                    self._update_signals.update_found.emit(info)
                else:
                    self._update_signals.no_update.emit(
                        f"Bạn đang dùng phiên bản mới nhất v{info.get('current_version', APP_VERSION)}."
                    )
            except Exception as e:
                self._update_signals.check_failed.emit(str(e))

        threading.Thread(target=worker, name="online-update-check", daemon=True).start()

    def _reset_update_check_ui(self):
        self._update_check_busy = False
        if hasattr(self, "update_btn"):
            self.update_btn.setEnabled(True)
            self.update_btn.setToolTip(
                f"Kiểm tra và cài bản cập nhật online\nPhiên bản hiện tại: v{APP_VERSION}"
            )

    def _on_update_no_update(self, message):
        manual = self._update_check_manual
        self._reset_update_check_ui()
        if manual:
            QMessageBox.information(self, "Kiểm tra cập nhật", str(message))
        else:
            try:
                self.append_log("[update] " + str(message))
            except Exception:
                pass

    def _on_update_check_failed(self, message):
        manual = self._update_check_manual
        self._reset_update_check_ui()
        msg = str(message)
        if manual:
            QMessageBox.warning(self, "Không kiểm tra được cập nhật", msg)
        else:
            try:
                self.append_log("[update] " + msg)
            except Exception:
                pass

    def _on_update_found(self, info):
        self._reset_update_check_ui()
        try:
            new_version = str(info.get("version", "mới"))
            current_version = str(info.get("current_version", APP_VERSION))
            notes = str(info.get("notes") or "Có bản cập nhật mới.").strip()
            if len(notes) > 2500:
                notes = notes[:2500] + "…"
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Information)
            box.setWindowTitle("Có bản cập nhật mới")
            box.setText(f"Đã có Gemini Studio v{new_version}")
            box.setInformativeText(f"Phiên bản đang dùng: v{current_version}\n\n{notes}")
            update_now = box.addButton("Cập nhật ngay", QMessageBox.AcceptRole)
            box.addButton("Để sau", QMessageBox.RejectRole)
            box.setDefaultButton(update_now)
            box.exec()
            if box.clickedButton() is update_now:
                self._begin_update_download(info)
        except Exception as e:
            QMessageBox.warning(self, "Cập nhật", f"Không mở được thông báo cập nhật: {e}")

    def _begin_update_download(self, info):
        if self.running or self.desc_running or self.queue_running:
            QMessageBox.warning(
                self,
                "Chưa thể cập nhật",
                "Tool đang chạy job. Hãy bấm Dừng và chờ các luồng dừng hẳn rồi cập nhật lại."
            )
            return
        if self._update_download_busy:
            return
        self._update_download_busy = True
        self._update_cancel_event = threading.Event()
        dlg = QProgressDialog("Đang tải bản cập nhật…", "Hủy", 0, 100, self)
        dlg.setWindowTitle(f"Tải Gemini Studio v{info.get('version', '')}")
        dlg.setWindowModality(Qt.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setValue(0)
        dlg.canceled.connect(self._cancel_update_download)
        self._update_progress_dialog = dlg
        dlg.show()

        def progress(value):
            try:
                self._update_signals.download_progress.emit(int(value))
            except Exception:
                pass

        def worker():
            try:
                path = _online_updater.download_update(
                    self.backend_dir, info, progress_callback=progress, cancel_event=self._update_cancel_event
                )
                self._update_signals.download_finished.emit(str(path), info)
            except Exception as e:
                self._update_signals.download_failed.emit(str(e))

        threading.Thread(target=worker, name="online-update-download", daemon=True).start()

    def _cancel_update_download(self):
        try:
            if self._update_cancel_event is not None:
                self._update_cancel_event.set()
        except Exception:
            pass

    def _on_update_download_progress(self, value):
        dlg = self._update_progress_dialog
        if dlg is not None:
            dlg.setValue(max(0, min(100, int(value))))
            dlg.setLabelText(f"Đang tải bản cập nhật… {int(value)}%")

    def _close_update_progress(self):
        dlg = self._update_progress_dialog
        self._update_progress_dialog = None
        if dlg is not None:
            try:
                dlg.close()
                dlg.deleteLater()
            except Exception:
                pass

    def _on_update_download_failed(self, message):
        self._update_download_busy = False
        self._close_update_progress()
        QMessageBox.warning(self, "Tải cập nhật thất bại", str(message))

    def _on_update_download_finished(self, zip_path, info):
        self._close_update_progress()
        try:
            self.save_state()
        except Exception:
            pass
        try:
            _online_updater.launch_updater(
                self.backend_dir, Path(zip_path), info, restart_file="RUN.bat"
            )
        except Exception as e:
            self._update_download_busy = False
            QMessageBox.critical(self, "Không thể cài cập nhật", str(e))
            return
        QMessageBox.information(
            self,
            "Sẵn sàng cập nhật",
            "Đã tải xong. Tool sẽ đóng, tự sao lưu bản cũ, cài bản mới rồi mở lại.\n\nKhông tắt máy trong lúc này."
        )
        self._closing_now = True
        QTimer.singleShot(200, self.close)

    def _detect_backend_file(self):
        # v79: ưu tiên tuyệt đối backend speed/stability để không chọn nhầm bản cũ.
        preferred = [
            self.backend_dir / "hybrid_auto_router_flow_gemini.py",
            self.backend_dir / "flow_auto_router_project_x4_complete.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v47_speed_stability.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v47.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v46_full_upgrade.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v46.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v45_2mb_plus.py",
        ]
        for p in preferred:
            if p.exists():
                return p
        ver_re = re.compile(r"gemini_auto_router_by_account_mode_fixed_v(\d+)(?:[_\w]*)?\.py$", re.I)
        priority_candidates = [self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py", self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v52_auto_rerun.py", self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v51_turbo.py", self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v50_fast_scan_capture.py", self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v49_clean_error_fix.py", self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v48_speed_fix.py"]
        fixed_candidates = sorted(
            self.backend_dir.glob("gemini_auto_router_by_account_mode_fixed_v*.py"),
            key=lambda p: int(ver_re.match(p.name).group(1)) if ver_re.match(p.name) else -1,
            reverse=True,
        )
        legacy_candidates = [
            self.backend_dir / "gemini_auto_router_by_account_mode_fixed.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fast_worker_ui_safe_v2.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fast_worker_ui_safe.py",
            self.backend_dir / "gemini_auto_router_by_account_mode_fast_worker_fixed.py",
            self.backend_dir / "gemini_auto_router_by_account_mode.py",
        ]
        candidates = [p for p in priority_candidates if p.exists()] + fixed_candidates + [p for p in legacy_candidates if p not in fixed_candidates]
        return next((p for p in candidates if p.exists()), self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py")

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main = QHBoxLayout(root)
        main.setContentsMargins(6, 6, 6, 6)
        main.setSpacing(8)

        # ===== LEFT CONTROL SIDEBAR =====
        sidebar = QFrame(); sidebar.setObjectName("SideBar")
        sidebar.setFixedWidth(196)
        self.sidebar = sidebar
        side = QVBoxLayout(sidebar); side.setContentsMargins(9, 8, 9, 9); side.setSpacing(7)
        main.addWidget(sidebar, 0)

        # v13.06: Sidebar là menu điều hướng thật, luôn hiển thị như ứng dụng quản trị.
        brand_head = QFrame(); brand_head.setObjectName("AppBrand")
        brand_head_lay = QHBoxLayout(brand_head); brand_head_lay.setContentsMargins(8, 8, 8, 8); brand_head_lay.setSpacing(9)
        app_mark = QLabel("GS"); app_mark.setObjectName("AppMark"); app_mark.setAlignment(Qt.AlignCenter); app_mark.setFixedSize(36, 36)
        app_text = QVBoxLayout(); app_text.setContentsMargins(0, 0, 0, 0); app_text.setSpacing(0)
        app_name = QLabel("Gemini Studio"); app_name.setObjectName("AppName")
        app_ver = QLabel(f"Workspace  •  v{APP_VERSION}"); app_ver.setObjectName("AppVersion")
        app_text.addWidget(app_name); app_text.addWidget(app_ver)
        brand_head_lay.addWidget(app_mark, 0); brand_head_lay.addLayout(app_text, 1)
        side.addWidget(brand_head, 0)

        # v13.09: Tài khoản nằm trên nhóm Công cụ để đúng luồng thao tác.
        account_nav_label = QLabel("TÀI KHOẢN")
        account_nav_label.setObjectName("NavSection")
        side.addWidget(account_nav_label, 0)
        self.import_txt_btn = QPushButton("⇧   Nhập TXT TK")
        self.import_txt_btn.setObjectName("NavActionButton")
        self.import_txt_btn.setMinimumHeight(36)
        self.import_txt_btn.setToolTip("Nhập danh sách tài khoản từ file TXT")
        self.import_txt_btn.clicked.connect(self.import_login_txt)
        side.addWidget(self.import_txt_btn, 0)

        nav_label = QLabel("CÔNG CỤ")
        nav_label.setObjectName("NavSection")
        side.addWidget(nav_label, 0)

        self.nav_thumb_btn = QPushButton("▦   Tạo Thumbnail")
        self.nav_thumb_btn.setObjectName("NavButton")
        self.nav_thumb_btn.setCheckable(True)
        self.nav_thumb_btn.setChecked(True)
        self.nav_thumb_btn.setMinimumHeight(38)
        self.nav_thumb_btn.clicked.connect(lambda: self._switch_workspace(0))
        self.nav_brand_btn = QPushButton("✦   Tên kênh & Logo")
        self.nav_brand_btn.setObjectName("NavButton")
        self.nav_brand_btn.setCheckable(True)
        self.nav_brand_btn.setMinimumHeight(38)
        self.nav_brand_btn.clicked.connect(lambda: self._switch_workspace(1))
        self.nav_desc_btn = QPushButton("✎   Sửa mô tả")
        self.nav_desc_btn.setObjectName("NavButton")
        self.nav_desc_btn.setCheckable(True)
        self.nav_desc_btn.setMinimumHeight(38)
        self.nav_desc_btn.clicked.connect(lambda: self._switch_workspace(2))
        side.addWidget(self.nav_thumb_btn, 0)
        side.addWidget(self.nav_brand_btn, 0)
        side.addWidget(self.nav_desc_btn, 0)

        # v13.16: Log tổng chuyển sang sidebar trái để xem log của mọi công cụ.
        self.log_toggle = QPushButton("▶ Hiện Log tổng")
        self.log_toggle.setObjectName("LogToggle")
        self.log_toggle.setMinimumHeight(34)
        self.log_toggle.clicked.connect(self._toggle_log_visible)
        side.addWidget(self.log_toggle, 0)

        self.log_group = QGroupBox("Log tổng tất cả công cụ")
        self.log_group.setObjectName("SidebarLogGroup")
        self.log_group.setVisible(False)
        self.log_group.setMaximumHeight(220)
        log_lay = QVBoxLayout(self.log_group)
        log_lay.setContentsMargins(8, 14, 8, 8)
        log_lay.setSpacing(5)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(LOG_MAX_LINES)
        self.log.setFont(QFont("Consolas", 8))
        self.log.setPlaceholderText("Log tổng của Thumbnail, Tên kênh & Logo, Sửa mô tả sẽ hiện ở đây...")
        log_lay.addWidget(self.log, 1)
        side.addWidget(self.log_group, 0)
        side.addStretch(1)

        self.thumb_side_panel = QFrame()
        self.thumb_side_panel.setObjectName("ThumbSidePanel")
        self.thumb_side_panel.setFixedWidth(220)
        thumb_side = QVBoxLayout(self.thumb_side_panel)
        thumb_side.setContentsMargins(7, 7, 7, 7)
        thumb_side.setSpacing(6)

        # v13.08: Nút Nhập TXT đã chuyển sang thanh công cụ chính bên trái.
        # Giữ các widget trạng thái tài khoản ở chế độ ẩn để tương thích engine cũ.
        self.account_pool_label = QLabel("")
        self.account_pool_label.setObjectName("SmallMuted")
        self.account_pool_label.setVisible(False)
        self.accounts_scroll = QScrollArea()
        self.accounts_scroll.setWidgetResizable(True)
        self.accounts_scroll.setMinimumHeight(1)
        self.accounts_scroll.setMaximumHeight(1)
        self.accounts_scroll.setVisible(False)
        self.accounts_body = QWidget()
        self.accounts_layout = QVBoxLayout(self.accounts_body)
        self.accounts_layout.setContentsMargins(0, 0, 0, 0)
        self.accounts_layout.setSpacing(5)
        self.accounts_layout.addStretch(1)
        self.accounts_scroll.setWidget(self.accounts_body)
        self.account_queue_hint = QLabel("")
        self.account_queue_hint.setObjectName("SmallMuted")
        self.account_queue_hint.setVisible(False)

        cfg = QGroupBox("Cấu hình")
        cfg_lay = QVBoxLayout(cfg); cfg_lay.setContentsMargins(8, 16, 8, 8); cfg_lay.setSpacing(6)

        def field_block(label_text, line_edit, button=None):
            wrap = QFrame(); wrap.setObjectName("FieldBlock")
            lay = QVBoxLayout(wrap); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(4)
            lb = QLabel(label_text); lb.setObjectName("FieldLabel")
            row = QHBoxLayout(); row.setContentsMargins(0, 0, 0, 0); row.setSpacing(5)
            row.addWidget(line_edit, 1)
            if button is not None:
                button.setFixedWidth(54)
                row.addWidget(button)
            lay.addWidget(lb)
            lay.addLayout(row)
            return wrap

        self.root_edit = QLineEdit(); self.root_edit.setPlaceholderText("Thư mục quét: có thể là thư mục cha hoặc thư mục tổng")
        self.logo_edit = QLineEdit(); self.logo_edit.setPlaceholderText("Logo PNG (tuỳ chọn, để trống = không chèn logo)")
        btn_root = QPushButton("Chọn")
        btn_logo = QPushButton("Chọn")
        btn_root.clicked.connect(self.pick_root)
        btn_logo.clicked.connect(self.pick_logo)
        self.root_edit.textChanged.connect(self.schedule_save_state)
        self.logo_edit.textChanged.connect(self.schedule_save_state)
        # v12.78: 4 ô queue thumbnail + 1 ô Sửa mô tả riêng bên phải.
        # Vẫn giữ root_edit/logo_edit ẩn để các hàm scan/run cũ dùng chung state.
        self.root_edit.setVisible(False)
        self.logo_edit.setVisible(False)
        btn_root.setVisible(False)
        btn_logo.setVisible(False)

        workers_box = QFrame(); workers_box.setObjectName("FieldBlock")
        workers_lay = QVBoxLayout(workers_box); workers_lay.setContentsMargins(0, 0, 0, 0); workers_lay.setSpacing(4)
        workers_label = QLabel("Số luồng")
        workers_label.setObjectName("FieldLabel")
        self.worker_spin = QSpinBox(); self.worker_spin.setRange(1, 50); self.worker_spin.setValue(8); self.worker_spin.setFixedWidth(72)
        self.worker_spin.valueChanged.connect(self.schedule_save_state)
        workers_hint = QLabel("Khuyên dùng 8 luồng")
        workers_hint.setObjectName("SmallMuted")
        workers_lay.addWidget(workers_label)
        workers_lay.addWidget(self.worker_spin, 0, Qt.AlignLeft)
        workers_lay.addWidget(workers_hint)
        cfg_lay.addWidget(workers_box)

        model_box = QFrame(); model_box.setObjectName("FieldBlock")
        model_lay = QVBoxLayout(model_box); model_lay.setContentsMargins(0, 0, 0, 0); model_lay.setSpacing(4)
        model_label = QLabel("Model vẽ")
        model_label.setObjectName("FieldLabel")
        self.thumb_model_combo = QComboBox()
        self.thumb_model_combo.addItem("Auto", "auto")
        self.thumb_model_combo.addItem("Flash", "flash")
        self.thumb_model_combo.addItem("Pro", "pro")
        self.thumb_model_combo.setCurrentIndex(0)
        self.thumb_model_combo.setFixedWidth(110)
        self.thumb_model_combo.setToolTip("Chọn model dùng để vẽ thumbnail. Auto = không ép model, Flash = ưu tiên nhanh, Pro = ưu tiên chất lượng.")
        self.thumb_model_combo.currentIndexChanged.connect(self.schedule_save_state)
        model_hint = QLabel("Auto/Flash nhanh hơn Pro")
        model_hint.setObjectName("SmallMuted")
        model_lay.addWidget(model_label)
        model_lay.addWidget(self.thumb_model_combo, 0, Qt.AlignLeft)
        model_lay.addWidget(model_hint)
        cfg_lay.addWidget(model_box)
        thumb_side.addWidget(cfg, 0)

        controls_group = QGroupBox("Điều khiển")
        controls_lay = QVBoxLayout(controls_group); controls_lay.setContentsMargins(8, 16, 8, 9); controls_lay.setSpacing(7)
        # v12.81: giao diện Điều khiển chỉ còn 3 nút chính, bỏ dòng hướng dẫn để gọn hơn.

        self.btn_scan = self._btn("⌕  Quét file", self.scan_only, "SecondaryAction")
        self.btn_start = self._btn("▶  Chạy queue", self.start_project_queue, "PrimaryAction")
        self.btn_stop = self._btn("■  Dừng", self.stop_all, "DangerButton")

        # v12.80: bỏ khỏi giao diện các nút không cần thiết: Chạy lại lỗi, Bỏ qua, Ảnh <0.5.
        # Vẫn giữ object/hàm trong nền để các luồng cũ hoặc phím tắt/debug không bị lỗi.
        self.btn_make_thumbs = self._btn("Tạo thumb", self.create_thumbs_from_originals, "AccentButton")
        self.btn_rerun_fail = self._btn("Chạy lại lỗi", self.rerun_failed_thumbnails)
        self.btn_rerun_skip = self._btn("Bỏ qua", self.rerun_skipped_thumbnails)
        self.btn_under = self._btn("Ảnh <0.5", self.select_under_half_mb)
        self.btn_restore = self._btn("Phục hồi", self.restore_original_thumbnails, "WarnButton")
        for _hidden_btn in (self.btn_make_thumbs, self.btn_rerun_fail, self.btn_rerun_skip, self.btn_under, self.btn_restore):
            _hidden_btn.setVisible(False)

        self.btn_scan.setMinimumHeight(32)
        self.btn_scan.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_scan.setStyleSheet("")
        controls_lay.addWidget(self.btn_scan)

        run_row = QHBoxLayout(); run_row.setContentsMargins(0, 0, 0, 0); run_row.setSpacing(7)
        for b in (self.btn_start, self.btn_stop):
            b.setMinimumHeight(33)
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            b.setStyleSheet("")
            run_row.addWidget(b, 1)
        controls_lay.addLayout(run_row)

        thumb_side.addWidget(controls_group, 0)

        sys_group = QGroupBox("Tình trạng hệ thống")
        sys_lay = QVBoxLayout(sys_group); sys_lay.setContentsMargins(8, 16, 8, 8); sys_lay.setSpacing(5)
        self.status_label = QLabel("Sẵn sàng")
        self.status_label.setObjectName("StatusPill")
        self.status_label.setWordWrap(True)
        self.status_label.setMinimumHeight(30)
        sys_lay.addWidget(self.status_label)
        thumb_side.addWidget(sys_group, 0)

        live_group = QGroupBox("Live Stats")
        live_lay = QGridLayout(live_group); live_lay.setContentsMargins(8, 16, 8, 10); live_lay.setHorizontalSpacing(6); live_lay.setVerticalSpacing(7)
        self.stat_cards = {
            "total": StatCard("Tổng file", BLUE),
            "queue": StatCard("Chờ", YELLOW),
            "running": StatCard("Đang chạy", BLUE),
            "done": StatCard("Hoàn tất", GREEN),
            "error": StatCard("Lỗi", RED),
            "skip": StatCard("Bỏ qua", ORANGE),
        }
        for idx, c in enumerate(self.stat_cards.values()):
            live_lay.addWidget(c, idx // 2, idx % 2)
        thumb_side.addWidget(live_group, 0)

        runtime_group = QGroupBox("Thời gian chạy")
        runtime_lay = QVBoxLayout(runtime_group); runtime_lay.setContentsMargins(8, 16, 8, 8); runtime_lay.setSpacing(4)
        self.runtime_value = QLabel("00:00:00")
        self.runtime_value.setObjectName("RuntimeValue")
        self.runtime_note = QLabel("Từ lúc Bắt đầu đến khi xong")
        self.runtime_note.setObjectName("SmallMuted")
        runtime_lay.addWidget(self.runtime_value)
        runtime_lay.addWidget(self.runtime_note)
        thumb_side.addWidget(runtime_group, 0)

        # v12.54: Proxy thành ô riêng dưới thời gian chạy, giao diện switch giống Auto IP.
        proxy_group = QGroupBox("Proxy")
        proxy_group.setObjectName("ProxyBox")
        proxy_lay = QVBoxLayout(proxy_group); proxy_lay.setContentsMargins(8, 16, 8, 8); proxy_lay.setSpacing(4)
        proxy_row = QHBoxLayout(); proxy_row.setContentsMargins(0, 0, 0, 0); proxy_row.setSpacing(7)
        self.proxy_toggle_btn = QPushButton("●")
        self.proxy_toggle_btn.setObjectName("ProxySwitch")
        self.proxy_toggle_btn.setCheckable(True)
        self.proxy_toggle_btn.setFixedSize(38, 22)
        self.proxy_toggle_btn.setToolTip("Bật/tắt dùng proxy trong proxy_accounts.txt cho login + worker Gemini")
        self.proxy_toggle_btn.clicked.connect(self._toggle_proxy_enabled)
        self.proxy_title_label = QLabel("Auto IP 🌐")
        self.proxy_title_label.setObjectName("ProxyTitle")
        proxy_row.addWidget(self.proxy_toggle_btn, 0)
        proxy_row.addWidget(self.proxy_title_label, 1)
        proxy_lay.addLayout(proxy_row)
        self.proxy_status_label = QLabel("TẮT (IP Gốc)")
        self.proxy_status_label.setObjectName("ProxyState")
        self.proxy_status_label.setToolTip("Chưa bật proxy")
        proxy_lay.addWidget(self.proxy_status_label)
        thumb_side.addWidget(proxy_group, 0)

        thumb_side.addStretch(1)

        bottom_side = QHBoxLayout(); bottom_side.setContentsMargins(0, 0, 0, 0); bottom_side.setSpacing(5)
        # v12.96 UI: hai nút cuối sidebar có kích thước bằng nhau; update dùng icon gọn, cân giữa.
        self.update_btn = QPushButton("")
        self.update_btn.setObjectName("SideFooter")
        self.update_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.update_btn.setFixedHeight(40)
        update_icon_path = self.backend_dir / "assets" / "update_icon.png"
        if update_icon_path.exists():
            self.update_btn.setIcon(QIcon(str(update_icon_path)))
            self.update_btn.setIconSize(QSize(24, 24))
        else:
            self.update_btn.setText("↻")
        self.update_btn.setToolTip(
            f"Kiểm tra và cài bản cập nhật online\nPhiên bản hiện tại: v{APP_VERSION}"
        )
        self.update_btn.setAccessibleName("Kiểm tra cập nhật online")
        self.update_btn.clicked.connect(lambda: self.check_for_updates(manual=True))

        self.theme_btn = QPushButton("🌙 Tối")
        self.theme_btn.setObjectName("SideFooter")
        self.theme_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.theme_btn.setFixedHeight(40)
        self.theme_btn.clicked.connect(self._toggle_theme)

        # Stretch 1:1 để hai nút luôn rộng bằng nhau ở mọi độ rộng sidebar.
        bottom_side.addWidget(self.update_btn, 1)
        bottom_side.addWidget(self.theme_btn, 1)
        side.addLayout(bottom_side)

        # ===== MAIN WORKSPACE =====
        self.workspace_stack = QStackedWidget()
        self.workspace_stack.setObjectName("WorkspaceStack")
        main.addWidget(self.workspace_stack, 1)

        self.thumbnail_page = QWidget()
        self.thumbnail_page.setObjectName("ThumbnailWorkspace")
        thumbnail_shell = QHBoxLayout(self.thumbnail_page)
        thumbnail_shell.setContentsMargins(0, 0, 0, 0)
        thumbnail_shell.setSpacing(8)
        thumbnail_shell.addWidget(self.thumb_side_panel, 0)

        self.thumbnail_content_host = QWidget()
        self.thumbnail_content_host.setObjectName("ThumbnailContentHost")
        content = QVBoxLayout(self.thumbnail_content_host)
        content.setContentsMargins(0, 0, 0, 0)
        content.setSpacing(7)
        thumbnail_shell.addWidget(self.thumbnail_content_host, 1)
        self.workspace_stack.addWidget(self.thumbnail_page)

        thumb_header = QFrame()
        thumb_header.setObjectName("WorkspaceHeader")
        thumb_header.setFixedHeight(58)
        thumb_header_lay = QHBoxLayout(thumb_header)
        thumb_header_lay.setContentsMargins(14, 8, 14, 8)
        thumb_header_lay.setSpacing(8)
        thumb_header_text = QVBoxLayout()
        thumb_header_text.setContentsMargins(0, 0, 0, 0)
        thumb_header_text.setSpacing(1)
        thumb_title = QLabel("Tạo Thumbnail")
        thumb_title.setObjectName("WorkspaceTitle")
        thumb_subtitle = QLabel("Quản lý queue tạo ảnh và chèn logo theo từng dự án")
        thumb_subtitle.setObjectName("WorkspaceSubtitle")
        thumb_header_text.addWidget(thumb_title)
        thumb_header_text.addWidget(thumb_subtitle)
        thumb_header_lay.addLayout(thumb_header_text, 1)
        content.addWidget(thumb_header, 0)

        # Tương thích code cũ; menu giờ là các mục bên sidebar, không còn nút ẩn/hiện.
        self.menu_btn = self.nav_thumb_btn
        self.brand_tool_btn = self.nav_brand_btn

        top_row = QHBoxLayout(); top_row.setContentsMargins(0, 0, 0, 0); top_row.setSpacing(7)
        content.addLayout(top_row, 0)

        queue_group = QGroupBox("4 Queue thumbnail / logo")
        # v12.54: queue chiếm trọn chiều ngang vùng nội dung, ngang bằng khung Danh sách job.
        queue_group.setMinimumHeight(184)
        queue_group.setMaximumHeight(200)
        queue_group.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        # v12.55: tăng chiều cao + đẩy nội dung xuống nhẹ để không bị mất chữ/nút ở mép trên-dưới.
        queue_lay = QVBoxLayout(queue_group); queue_lay.setContentsMargins(10, 24, 10, 12); queue_lay.setSpacing(2)

        # v12.54: giao diện queue sạch: bỏ thanh hướng dẫn/nút phụ phía trên, chỉ còn 5 ô cố định.
        # Hidden list giữ compatibility cho remove/move/currentRow; phần hiển thị thật là hàng card ngang.
        self.project_queue_list = QListWidget()
        self.project_queue_list.setVisible(False)
        self.selected_queue_index = -1

        self.project_queue_cards_body = QWidget()
        self.project_queue_cards_body.setObjectName("QueueCardsBody")
        self.project_queue_cards_layout = QHBoxLayout(self.project_queue_cards_body)
        self.project_queue_cards_layout.setContentsMargins(0, 0, 0, 0)
        self.project_queue_cards_layout.setSpacing(14)
        queue_lay.addWidget(self.project_queue_cards_body, 0)
        top_row.addWidget(queue_group, 1)

        track_group = QGroupBox("Worker Stream")
        track_group.setMaximumHeight(250)
        track_group.setMinimumWidth(330)
        track_group.setMaximumWidth(380)
        track_lay = QVBoxLayout(track_group); track_lay.setContentsMargins(8, 15, 8, 8); track_lay.setSpacing(5)
        stream_hint = QLabel("Luồng dạng ô • nhìn nhanh realtime")
        stream_hint.setObjectName("SmallMuted")
        track_lay.addWidget(stream_hint)
        track_header = QFrame(); track_header.setObjectName("TrackHero")
        track_header_lay = QVBoxLayout(track_header); track_header_lay.setContentsMargins(7, 4, 7, 4); track_header_lay.setSpacing(3)
        self.track_top = QLabel("Sẵn sàng")
        self.track_top.setObjectName("StatusPillMini")
        self.track_top.setFixedHeight(24)
        track_header_lay.addWidget(self.track_top)
        chips = QHBoxLayout(); chips.setContentsMargins(0, 0, 0, 0); chips.setSpacing(5)
        self.track_chip_workers = QLabel("Worker: 0")
        self.track_chip_running = QLabel("Đang chạy: 0")
        self.track_chip_done = QLabel("Xong: 0")
        self.track_chip_error = QLabel("Lỗi: 0")
        for lb in (self.track_chip_workers, self.track_chip_running, self.track_chip_done, self.track_chip_error):
            lb.setObjectName("TrackChip")
            chips.addWidget(lb)
        chips.addStretch(1)
        track_header_lay.addLayout(chips)
        track_lay.addWidget(track_header, 0)

        self.worker_cards_scroll = QScrollArea()
        self.worker_cards_scroll.setWidgetResizable(True)
        self.worker_cards_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.worker_cards_scroll.setObjectName("WorkerCardsScroll")
        self.worker_cards_body = QWidget()
        self.worker_cards_layout = QVBoxLayout(self.worker_cards_body)
        self.worker_cards_layout.setContentsMargins(4, 4, 4, 4)
        self.worker_cards_layout.setSpacing(6)
        self.worker_cards_layout.addStretch(1)
        self.worker_cards_scroll.setWidget(self.worker_cards_body)
        track_lay.addWidget(self.worker_cards_scroll, 1)

        # Giữ tên cũ để các đoạn reset không lỗi; worker stream mới dùng card, không dùng bảng.
        self.worker_tree = None
        # v12.54: ẩn Worker Stream khỏi hàng trên để 5 queue rộng ngang bằng Danh sách job.
        # Các label/card vẫn tồn tại nên logic cập nhật worker không lỗi.
        track_group.setVisible(False)
        top_row.addWidget(track_group, 0)

        # ===== JOB LIST =====
        preview_group = QGroupBox("Danh sách job")
        preview_lay = QVBoxLayout(preview_group); preview_lay.setContentsMargins(10, 16, 10, 10); preview_lay.setSpacing(6)
        filter_row = QHBoxLayout(); filter_row.setContentsMargins(0, 0, 0, 0); filter_row.setSpacing(6)
        self.job_filter_combo = QComboBox()
        self.job_filter_combo.addItems(["Tất cả", "Chờ", "Đang chạy", "Xong", "Lỗi", "Bỏ qua"])
        self.job_filter_combo.currentTextChanged.connect(lambda *_: self.request_preview_refresh(force=True))
        self.job_search_edit = QLineEdit(); self.job_search_edit.setPlaceholderText("Tìm theo tên file/thư mục/note...")
        self.job_search_edit.textChanged.connect(lambda *_: self.request_preview_refresh(force=False))
        self.eta_label = QLabel("ETA: -"); self.eta_label.setObjectName("TrackChip")
        self.error_summary_label = QLabel("Lỗi: -"); self.error_summary_label.setObjectName("TrackChip")
        self.account_perf_label = QLabel("TK: -"); self.account_perf_label.setObjectName("TrackChip")
        self.eta_label.setVisible(False); self.error_summary_label.setVisible(False); self.account_perf_label.setVisible(False)
        filter_row.addWidget(QLabel("Lọc:"), 0)
        filter_row.addWidget(self.job_filter_combo, 0)
        filter_row.addWidget(self.job_search_edit, 1)
        self.thumb_selected_label = QLabel("Đã chọn: 0")
        self.thumb_selected_label.setObjectName("TrackChip")
        self.thumb_select_all_btn = QPushButton("Chọn tất cả")
        self.thumb_select_all_btn.setObjectName("SecondaryAction")
        self.thumb_select_all_btn.setMinimumHeight(28)
        self.thumb_select_all_btn.clicked.connect(self._select_all_visible_thumbnails)
        self.thumb_clear_select_btn = QPushButton("Bỏ chọn")
        self.thumb_clear_select_btn.setObjectName("SecondaryAction")
        self.thumb_clear_select_btn.setMinimumHeight(28)
        self.thumb_clear_select_btn.clicked.connect(self._clear_selected_thumbnails)
        self.thumb_restore_selected_btn = QPushButton("Phục hồi thumb đã chọn")
        self.thumb_restore_selected_btn.setObjectName("WarnButton")
        self.thumb_restore_selected_btn.setMinimumHeight(28)
        self.thumb_restore_selected_btn.clicked.connect(self.restore_selected_thumbnails)
        filter_row.addWidget(self.thumb_selected_label, 0)
        filter_row.addWidget(self.thumb_select_all_btn, 0)
        filter_row.addWidget(self.thumb_clear_select_btn, 0)
        filter_row.addWidget(self.thumb_restore_selected_btn, 0)
        filter_row.addWidget(self.eta_label, 0)
        filter_row.addWidget(self.error_summary_label, 0)
        filter_row.addWidget(self.account_perf_label, 0)
        preview_lay.addLayout(filter_row)
        self.preview = QListWidget()
        self.preview.setViewMode(QListWidget.IconMode)
        self.preview.setResizeMode(QListWidget.Adjust)
        self.preview.setMovement(QListWidget.Static)
        self.preview.setWrapping(True)
        try:
            self.preview.setFlow(QListWidget.LeftToRight)
        except Exception:
            pass
        self.preview.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.preview.setSpacing(8)
        self.preview.setIconSize(QSize(218, 123))
        self.preview.setGridSize(QSize(248, 218))
        self.preview.setUniformItemSizes(True)
        self.preview.itemDoubleClicked.connect(self._preview_double_clicked)
        preview_lay.addWidget(self.preview, 1)
        content.addWidget(preview_group, 1)

        # v13.16: log tổng đã chuyển hẳn sang sidebar trái, luôn dùng chung cho mọi workspace.

        # Giữ thuộc tính splitter để các hàm cũ không lỗi; layout mới không phụ thuộc splitter.
        self.main_splitter = preview_group

        self.brand_page = QWidget()
        self.brand_page.setObjectName("BrandPage")
        brand_page_lay = QVBoxLayout(self.brand_page)
        brand_page_lay.setContentsMargins(0, 0, 0, 0)
        brand_page_lay.setSpacing(0)
        self._channel_brand_dialog = ChannelBrandDialog(self)
        self._channel_brand_dialog.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        brand_page_lay.addWidget(self._channel_brand_dialog, 1)
        self.workspace_stack.addWidget(self.brand_page)

        # v13.09: Sửa mô tả là một công cụ độc lập với danh sách và khung xem nội dung.
        self._build_description_workspace()
        self._switch_workspace(0, save=False)

    def _build_description_workspace(self):
        self.description_page = QWidget()
        self.description_page.setObjectName("DescriptionPage")
        page = QVBoxLayout(self.description_page)
        page.setContentsMargins(0, 0, 0, 0)
        page.setSpacing(7)

        header = QFrame()
        header.setObjectName("WorkspaceHeader")
        header.setFixedHeight(62)
        header_lay = QHBoxLayout(header)
        header_lay.setContentsMargins(14, 8, 14, 8)
        title_box = QVBoxLayout(); title_box.setContentsMargins(0, 0, 0, 0); title_box.setSpacing(1)
        title = QLabel("Sửa mô tả")
        title.setObjectName("WorkspaceTitle")
        subtitle = QLabel("Quét, xem trước, viết lại và kiểm tra description.txt từ Queue Thumbnail hoặc các thư mục Crawl đã chọn")
        subtitle.setObjectName("WorkspaceSubtitle")
        title_box.addWidget(title); title_box.addWidget(subtitle)
        header_lay.addLayout(title_box, 1)
        page.addWidget(header, 0)

        # v13.11: nguồn mô tả là ô nhập nhiều dòng. Mỗi thư mục Crawl nằm trên một dòng.
        source_group = QGroupBox("Nguồn thư mục Crawl")
        source_lay = QVBoxLayout(source_group)
        source_lay.setContentsMargins(10, 16, 10, 9)
        source_lay.setSpacing(6)

        source_top = QHBoxLayout(); source_top.setContentsMargins(0, 0, 0, 0); source_top.setSpacing(7)
        self.desc_source_summary = QLabel("Đang đọc nguồn từ Tạo Thumbnail")
        self.desc_source_summary.setObjectName("DescStatusText")
        self.desc_source_summary.setToolTip("Mỗi dòng là một thư mục Crawl. Nguồn đang cấu hình ở Tạo Thumbnail luôn được tự động cộng vào.")
        source_top.addWidget(self.desc_source_summary, 1)

        self.desc_add_roots_btn = QPushButton("＋ Chọn thư mục Crawl")
        self.desc_add_roots_btn.setObjectName("PrimaryAction")
        self.desc_add_roots_btn.setToolTip("Có thể Ctrl/Shift để chọn nhiều thư mục. Đường dẫn sẽ được thêm vào ô bên dưới, mỗi thư mục một dòng.")
        self.desc_add_roots_btn.clicked.connect(self._description_pick_custom_roots)
        self.desc_apply_roots_btn = QPushButton("✓ Áp dụng đường dẫn")
        self.desc_apply_roots_btn.setObjectName("SecondaryAction")
        self.desc_apply_roots_btn.setToolTip("Đọc các đường dẫn trong ô bên dưới và lưu làm nguồn quét mô tả.")
        self.desc_apply_roots_btn.clicked.connect(lambda: self._description_apply_roots_editor(show_message=True))
        self.desc_clear_roots_btn = QPushButton("Xóa thư mục thêm")
        self.desc_clear_roots_btn.setObjectName("SecondaryAction")
        self.desc_clear_roots_btn.setToolTip("Chỉ xóa các dòng nhập thêm; nguồn từ Tạo Thumbnail vẫn được tự động giữ lại.")
        self.desc_clear_roots_btn.clicked.connect(self._description_clear_custom_roots)
        for _b in (self.desc_add_roots_btn, self.desc_apply_roots_btn, self.desc_clear_roots_btn):
            _b.setMinimumHeight(30)
        source_top.addWidget(self.desc_add_roots_btn, 0)
        source_top.addWidget(self.desc_apply_roots_btn, 0)
        source_top.addWidget(self.desc_clear_roots_btn, 0)
        source_lay.addLayout(source_top)

        self.desc_source_editor = QPlainTextEdit()
        self.desc_source_editor.setObjectName("DescSourceEditor")
        self.desc_source_editor.setPlaceholderText(
            "Mỗi thư mục Crawl nằm trên một dòng, ví dụ:\n"
            r"E:\3T Media\Kênh 1\Crawl" "\n"
            r"D:\Kênh\Kênh 2\Crawl"
        )
        self.desc_source_editor.setMinimumHeight(72)
        self.desc_source_editor.setMaximumHeight(118)
        self.desc_source_editor.setToolTip("Có thể gõ hoặc dán nhiều đường dẫn, mỗi đường dẫn một dòng. Bấm Áp dụng đường dẫn trước khi quét.")
        self.desc_source_editor.textChanged.connect(self._description_source_editor_changed)
        source_lay.addWidget(self.desc_source_editor, 1)
        page.addWidget(source_group, 0)

        control = QFrame()
        control.setObjectName("DescToolbar")
        control_lay = QVBoxLayout(control)
        control_lay.setContentsMargins(10, 9, 10, 9)
        control_lay.setSpacing(7)

        action_row = QHBoxLayout(); action_row.setContentsMargins(0, 0, 0, 0); action_row.setSpacing(7)
        self.desc_scan_btn = QPushButton("⌕  Quét mô tả")
        self.desc_scan_btn.setObjectName("SecondaryAction")
        self.desc_scan_btn.clicked.connect(self.scan_description_jobs_only)
        self.desc_run_btn = QPushButton("▶  Sửa chưa xử lý")
        self.desc_run_btn.setObjectName("PrimaryAction")
        self.desc_run_btn.clicked.connect(self.start_description_rewrite)
        self.desc_stop_btn = QPushButton("■  Dừng")
        self.desc_stop_btn.setObjectName("DangerButton")
        self.desc_stop_btn.clicked.connect(self.stop_description_only)
        self.desc_restore_all_btn = QPushButton("↶  Khôi phục tất cả")
        self.desc_restore_all_btn.setObjectName("WarnButton")
        self.desc_restore_all_btn.clicked.connect(self.restore_original_descriptions)
        for b in (self.desc_scan_btn, self.desc_run_btn, self.desc_stop_btn, self.desc_restore_all_btn):
            b.setMinimumHeight(32)
        action_row.addWidget(self.desc_scan_btn, 0)
        action_row.addWidget(self.desc_run_btn, 0)
        action_row.addWidget(self.desc_stop_btn, 0)
        action_row.addWidget(self.desc_restore_all_btn, 0)

        self.desc_language_combo = QComboBox()
        self.desc_language_combo.setObjectName("DescLanguageCombo")
        self.desc_language_combo.setMinimumWidth(138)
        # Các ngôn ngữ chủ đạo được đưa lên đầu để chọn nhanh.
        self.desc_language_combo.addItems([
            "English", "日本語", "Español", "Tiếng Việt",
            "Português", "Italiano", "Deutsch", "Français",
            "한국어", "Русский", "العربية", "हिन्दी",
            "Bahasa Indonesia", "ภาษาไทย", "Tùy chỉnh..."
        ])
        self.desc_language_combo.setMaxVisibleItems(15)
        try:
            idx_lang = self.desc_language_combo.findText(str(getattr(self, "desc_translate_language", "English") or "English"))
            if idx_lang >= 0:
                self.desc_language_combo.setCurrentIndex(idx_lang)
        except Exception:
            pass
        self.desc_language_combo.currentTextChanged.connect(self._description_language_changed)
        self.desc_translate_selected_btn = QPushButton("Dịch mục hiện tại")
        self.desc_translate_selected_btn.setObjectName("SecondaryAction")
        self.desc_translate_selected_btn.setToolTip("Dịch miễn phí bằng translate.google.com cho mô tả đang xem.")
        self.desc_translate_selected_btn.clicked.connect(lambda: self.start_description_translation(selected_only=True))
        self.desc_translate_all_btn = QPushButton("⚡ Dịch mô tả đã chọn")
        self.desc_translate_all_btn.setObjectName("PrimaryAction")
        self.desc_translate_all_btn.setToolTip("Tích các mô tả sai ngôn ngữ rồi dịch miễn phí bằng translate.google.com.")
        self.desc_translate_all_btn.clicked.connect(lambda: self.start_description_translation(selected_only="multi"))
        for _b in (self.desc_translate_selected_btn, self.desc_translate_all_btn):
            _b.setMinimumHeight(32)
        action_row.addStretch(1)

        self.desc_total_chip = QLabel("Tổng 0")
        self.desc_done_chip = QLabel("Đã sửa 0")
        self.desc_wait_chip = QLabel("Chờ 0")
        self.desc_error_chip = QLabel("Lỗi 0")
        self.desc_skip_chip = QLabel("Bỏ qua 0")
        for lb in (self.desc_total_chip, self.desc_done_chip, self.desc_wait_chip, self.desc_error_chip, self.desc_skip_chip):
            lb.setObjectName("DescStatChip")
            action_row.addWidget(lb, 0)
        control_lay.addLayout(action_row)

        translate_row = QHBoxLayout(); translate_row.setContentsMargins(0, 0, 0, 0); translate_row.setSpacing(7)
        translate_row.addWidget(QLabel("Phát hiện ngôn ngữ →"), 0)
        translate_row.addWidget(self.desc_language_combo, 0)
        translate_row.addWidget(self.desc_translate_selected_btn, 0)
        translate_row.addWidget(self.desc_translate_all_btn, 0)
        self.desc_translate_hint = QLabel("Nguồn tự nhận diện • chỉ dịch các mô tả đã tích")
        self.desc_translate_hint.setObjectName("DescStatusText")
        translate_row.addWidget(self.desc_translate_hint, 0)
        translate_row.addStretch(1)
        control_lay.addLayout(translate_row)

        progress_row = QHBoxLayout(); progress_row.setContentsMargins(0, 0, 0, 0); progress_row.setSpacing(8)
        self.desc_page_progress = QProgressBar()
        self.desc_page_progress.setRange(0, 1)
        self.desc_page_progress.setValue(0)
        self.desc_page_progress.setFormat("0%")
        self.desc_page_progress.setFixedHeight(17)
        self.desc_page_status = QLabel("Chưa quét mô tả")
        self.desc_page_status.setObjectName("DescStatusText")
        progress_row.addWidget(self.desc_page_progress, 1)
        progress_row.addWidget(self.desc_page_status, 0)
        control_lay.addLayout(progress_row)
        page.addWidget(control, 0)

        body = QSplitter(Qt.Horizontal)
        body.setObjectName("DescSplitter")

        list_group = QGroupBox("Danh sách mô tả")
        list_lay = QVBoxLayout(list_group); list_lay.setContentsMargins(9, 16, 9, 9); list_lay.setSpacing(6)
        filter_row = QHBoxLayout(); filter_row.setContentsMargins(0, 0, 0, 0); filter_row.setSpacing(6)
        self.desc_filter_combo = QComboBox()
        self.desc_filter_combo.addItems(["Tất cả", "Chờ sửa", "Đã sửa", "Đang sửa", "Lỗi", "Bỏ qua"])
        self.desc_filter_combo.currentTextChanged.connect(lambda *_: self._refresh_description_workspace())
        self.desc_search_edit = QLineEdit()
        self.desc_search_edit.setPlaceholderText("Tìm thư mục, đường dẫn hoặc nội dung mô tả...")
        self.desc_search_edit.textChanged.connect(lambda *_: self._refresh_description_workspace())
        filter_row.addWidget(self.desc_filter_combo, 0)
        filter_row.addWidget(self.desc_search_edit, 1)
        self.desc_check_all_btn = QPushButton("✓ Chọn tất cả")
        self.desc_check_all_btn.setObjectName("SecondaryAction")
        self.desc_check_all_btn.setToolTip("Tích chọn toàn bộ mô tả đang hiển thị theo bộ lọc hiện tại.")
        self.desc_check_all_btn.clicked.connect(self._description_check_all_visible)
        self.desc_check_vietnamese_btn = QPushButton("Chọn mô tả tiếng Việt")
        self.desc_check_vietnamese_btn.setObjectName("SecondaryAction")
        self.desc_check_vietnamese_btn.setToolTip("Tự động tích các description.txt hiện đang được nhận diện là tiếng Việt để dịch hàng loạt.")
        self.desc_check_vietnamese_btn.clicked.connect(self._description_check_vietnamese)
        self.desc_uncheck_all_btn = QPushButton("Bỏ chọn")
        self.desc_uncheck_all_btn.setObjectName("SecondaryAction")
        self.desc_uncheck_all_btn.setToolTip("Bỏ toàn bộ dấu chọn dịch.")
        self.desc_uncheck_all_btn.clicked.connect(self._description_uncheck_all)
        filter_row.addWidget(self.desc_check_all_btn, 0)
        filter_row.addWidget(self.desc_check_vietnamese_btn, 0)
        filter_row.addWidget(self.desc_uncheck_all_btn, 0)
        list_lay.addLayout(filter_row)

        self.desc_checked_paths = set()
        self.desc_tree = QTreeWidget()
        self.desc_tree.setObjectName("DescTree")
        self.desc_tree.setColumnCount(5)
        self.desc_tree.setHeaderLabels(["Chọn", "Trạng thái", "Thư mục", "Mô tả hiện tại", "Ghi chú"])
        self.desc_tree.setRootIsDecorated(False)
        self.desc_tree.setAlternatingRowColors(True)
        self.desc_tree.setUniformRowHeights(True)
        self.desc_tree.setSelectionMode(QTreeWidget.SingleSelection)
        self.desc_tree.itemSelectionChanged.connect(self._description_selection_changed)
        self.desc_tree.itemChanged.connect(self._description_checkbox_changed)
        header_view = self.desc_tree.header()
        header_view.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header_view.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header_view.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header_view.setSectionResizeMode(3, QHeaderView.Stretch)
        header_view.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        list_lay.addWidget(self.desc_tree, 1)
        body.addWidget(list_group)

        detail_group = QGroupBox("Nội dung mô tả")
        detail_group.setMinimumWidth(430)
        detail_lay = QVBoxLayout(detail_group); detail_lay.setContentsMargins(9, 16, 9, 9); detail_lay.setSpacing(6)
        self.desc_selected_path_label = QLabel("Chọn một mô tả trong danh sách")
        self.desc_selected_path_label.setObjectName("DescPathLabel")
        self.desc_selected_path_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        detail_lay.addWidget(self.desc_selected_path_label, 0)

        editors = QSplitter(Qt.Vertical)
        original_box = QGroupBox("Mô tả gốc")
        original_lay = QVBoxLayout(original_box); original_lay.setContentsMargins(7, 15, 7, 7)
        self.desc_original_editor = QPlainTextEdit()
        self.desc_original_editor.setReadOnly(True)
        self.desc_original_editor.setPlaceholderText("Chưa có bản gốc hoặc chưa chọn mô tả")
        original_lay.addWidget(self.desc_original_editor)
        editors.addWidget(original_box)

        current_box = QGroupBox("Mô tả hiện tại")
        current_lay = QVBoxLayout(current_box); current_lay.setContentsMargins(7, 15, 7, 7)
        self.desc_current_editor = QPlainTextEdit()
        self.desc_current_editor.setReadOnly(False)
        self.desc_current_editor.setPlaceholderText("Nội dung description.txt hiện tại")
        current_lay.addWidget(self.desc_current_editor)
        editors.addWidget(current_box)
        editors.setStretchFactor(0, 1)
        editors.setStretchFactor(1, 1)
        detail_lay.addWidget(editors, 1)

        detail_actions = QHBoxLayout(); detail_actions.setContentsMargins(0, 0, 0, 0); detail_actions.setSpacing(6)
        self.desc_open_folder_btn = QPushButton("Mở thư mục")
        self.desc_open_folder_btn.setObjectName("SecondaryAction")
        self.desc_open_folder_btn.clicked.connect(self._description_open_selected_folder)
        self.desc_reload_btn = QPushButton("Tải lại")
        self.desc_reload_btn.clicked.connect(self._description_selection_changed)
        self.desc_undo_translate_btn = QPushButton("Hoàn tác dịch")
        self.desc_undo_translate_btn.setObjectName("SecondaryAction")
        self.desc_undo_translate_btn.setToolTip("Khôi phục bản ngay trước lần dịch gần nhất của mục đang chọn.")
        self.desc_undo_translate_btn.clicked.connect(self._description_undo_translation_selected)
        self.desc_restore_selected_btn = QPushButton("Khôi phục mục chọn")
        self.desc_restore_selected_btn.setObjectName("WarnButton")
        self.desc_restore_selected_btn.clicked.connect(self._description_restore_selected)
        self.desc_save_btn = QPushButton("Lưu mô tả")
        self.desc_save_btn.setObjectName("PrimaryAction")
        self.desc_save_btn.clicked.connect(self._description_save_selected)
        for _desc_detail_btn in (self.desc_open_folder_btn, self.desc_reload_btn, self.desc_undo_translate_btn, self.desc_restore_selected_btn, self.desc_save_btn):
            _desc_detail_btn.setEnabled(False)
        detail_actions.addWidget(self.desc_open_folder_btn)
        detail_actions.addWidget(self.desc_reload_btn)
        detail_actions.addStretch(1)
        detail_actions.addWidget(self.desc_undo_translate_btn)
        detail_actions.addWidget(self.desc_restore_selected_btn)
        detail_actions.addWidget(self.desc_save_btn)
        detail_lay.addLayout(detail_actions)
        body.addWidget(detail_group)
        body.setStretchFactor(0, 3)
        body.setStretchFactor(1, 2)
        page.addWidget(body, 1)

        self.workspace_stack.addWidget(self.description_page)
        self._refresh_description_sources_ui()
        self._refresh_description_workspace()

    def _description_selected_path(self):
        try:
            item = self.desc_tree.currentItem()
            if item is None:
                return None
            value = item.data(0, Qt.UserRole)
            return Path(str(value)) if value else None
        except Exception:
            return None

    def _description_selected_paths(self):
        """Trả về dòng đang được mở xem trong bảng."""
        path = self._description_selected_path()
        return [path] if path else []

    def _description_checked_paths(self):
        """Trả về đúng các description.txt đã tích ô Chọn."""
        result = []
        seen = set()
        checked = set(getattr(self, "desc_checked_paths", set()) or set())
        for value in checked:
            try:
                path = Path(str(value))
                key = str(path).lower()
                if path.is_file() and key not in seen:
                    seen.add(key)
                    result.append(path)
            except Exception:
                continue
        result.sort(key=lambda x: str(x).lower())
        return result

    def _description_update_checked_ui(self):
        count = len(self._description_checked_paths())
        busy = bool(getattr(self, "desc_running", False))
        thumb_busy = bool(getattr(self, "running", False))
        try:
            self.desc_translate_all_btn.setEnabled(count > 0 and not busy and not thumb_busy)
        except Exception:
            pass
        try:
            if count > 0:
                self.desc_translate_hint.setText(f"Đã tích {count} mô tả • dịch miễn phí bằng Google Translate")
            else:
                self.desc_translate_hint.setText("Nguồn tự nhận diện • chỉ dịch các mô tả đã tích")
        except Exception:
            pass

    def _description_checkbox_changed(self, item, column):
        if column != 0 or item is None:
            return
        try:
            value = item.data(0, Qt.UserRole)
            if not value:
                return
            key = str(Path(str(value))).lower()
            checked = set(getattr(self, "desc_checked_paths", set()) or set())
            if item.checkState(0) == Qt.Checked:
                checked.add(key)
            else:
                checked.discard(key)
            self.desc_checked_paths = checked
            self._description_update_checked_ui()
        except Exception:
            pass

    @staticmethod
    def _description_is_vietnamese_text(text):
        """Nhận diện tiếng Việt đủ chặt để chặn output sai và chọn nhanh mục cần dịch."""
        raw = str(text or "").strip().lower()
        if not raw:
            return False
        # Chỉ dùng ký tự đặc trưng của tiếng Việt; không coi á/é/í/ó/ú đơn thuần là tiếng Việt
        # vì các ký tự đó cũng xuất hiện rất nhiều trong tiếng Tây Ban Nha/Bồ Đào Nha.
        vietnamese_exclusive = set("ăđơưảạắằẳẵặấầẩẫậẻẽẹếềểễệỉĩịỏọốồổỗộớờởỡợủũụứừửữựỳỷỹỵ")
        if any(ch in vietnamese_exclusive for ch in raw):
            return True
        normalized = re.sub(r"[^a-z0-9#@]+", " ", raw)
        padded = " " + re.sub(r"\s+", " ", normalized).strip() + " "
        strong_phrases = (
            " tieng viet ", " mo ta ", " chao mung ", " thuong thuc ",
            " dang ky kenh ", " bai hat ", " am nhac ", " hanh trinh ",
            " buoc vao ", " chung toi ", " khong gian ",
        )
        if any(x in padded for x in strong_phrases):
            return True
        common_words = (
            " va ", " cua ", " voi ", " trong ", " nhung ", " mot ", " khong ",
            " duoc ", " hay ", " ban ", " kenh ", " noi dung ", " video nay ",
            " cac ", " cho ", " tu ", " den ", " ve ", " cung ",
        )
        score = sum(1 for x in common_words if x in padded)
        return score >= 4

    @staticmethod
    def _description_detect_language_label(text):
        """Nhận diện nhẹ để ghi log. Không dùng để dịch và không ép đổi ngôn ngữ."""
        raw = str(text or "").strip().lower()
        if not raw:
            return "Trống"
        if QtDashboard._description_is_vietnamese_text(raw):
            return "Vietnamese"
        cleaned = " " + re.sub(r"[^a-zà-ÿ0-9]+", " ", raw, flags=re.I).strip() + " "
        dictionaries = {
            "English": (" the ", " and ", " with ", " this ", " music ", " songs ", " enjoy ", " subscribe ", " from ", " for "),
            "Spanish": (" el ", " la ", " los ", " las ", " y ", " con ", " música ", " canciones ", " disfruta ", " suscríbete ", " para ", " una "),
            "Portuguese": (" o ", " a ", " os ", " as ", " e ", " com ", " música ", " canções ", " aproveite ", " inscreva ", " para ", " uma "),
            "French": (" le ", " la ", " les ", " et ", " avec ", " musique ", " chansons ", " profitez ", " abonnez ", " pour ", " une "),
            "German": (" der ", " die ", " das ", " und ", " mit ", " musik ", " lieder ", " genieße ", " abonnieren ", " für "),
            "Italian": (" il ", " lo ", " la ", " gli ", " le ", " e ", " con ", " musica ", " canzoni ", " ascolta ", " iscriviti ", " per "),
            "Indonesian": (" dan ", " dengan ", " musik ", " lagu ", " untuk ", " nikmati ", " berlangganan ", " ini "),
        }
        scores = {name: sum(1 for token in tokens if token in cleaned) for name, tokens in dictionaries.items()}
        best = max(scores, key=scores.get)
        best_score = scores[best]
        ordered = sorted(scores.values(), reverse=True)
        second = ordered[1] if len(ordered) > 1 else 0
        if best_score >= 3 and best_score >= second + 1:
            return best
        # Nhận diện theo bảng chữ viết cho các ngôn ngữ không Latin.
        if re.search(r"[ぁ-んァ-ン一-龯]", raw): return "Japanese"
        if re.search(r"[가-힣]", raw): return "Korean"
        if re.search(r"[А-Яа-яЁё]", raw): return "Russian"
        if re.search(r"[ء-ي]", raw): return "Arabic"
        if re.search(r"[ก-๙]", raw): return "Thai"
        if re.search(r"[ऀ-ॿ]", raw): return "Hindi"
        return "Không xác định"

    def _description_language_mismatch(self, original_text, result_text):
        original_vi = self._description_is_vietnamese_text(original_text)
        result_vi = self._description_is_vietnamese_text(result_text)
        if (not original_vi) and result_vi:
            return True, "bản gốc không phải tiếng Việt nhưng Gemini trả tiếng Việt"
        return False, ""

    def _description_check_vietnamese(self):
        """Tích toàn bộ mô tả hiện tại được nhận diện là tiếng Việt."""
        if not hasattr(self, "desc_tree"):
            return
        checked = set(getattr(self, "desc_checked_paths", set()) or set())
        found = 0
        self.desc_tree.blockSignals(True)
        try:
            for i in range(self.desc_tree.topLevelItemCount()):
                item = self.desc_tree.topLevelItem(i)
                value = item.data(0, Qt.UserRole)
                if not value:
                    continue
                path = Path(str(value))
                try:
                    current = path.read_text(encoding="utf-8-sig", errors="ignore") if path.is_file() else ""
                except Exception:
                    current = ""
                if self._description_is_vietnamese_text(current):
                    key = str(path).lower()
                    checked.add(key)
                    item.setCheckState(0, Qt.Checked)
                    found += 1
        finally:
            self.desc_tree.blockSignals(False)
        self.desc_checked_paths = checked
        self._description_update_checked_ui()
        self.desc_last_message = f"Đã chọn {found} mô tả tiếng Việt để dịch"
        try:
            self.desc_page_status.setText(self.desc_last_message)
        except Exception:
            pass
        try:
            self.statusBar().showMessage(self.desc_last_message, 3500)
        except Exception:
            pass
        if found == 0:
            QMessageBox.information(self, APP_TITLE, "Không tìm thấy mô tả tiếng Việt trong danh sách đang hiển thị.")

    def _description_check_error_jobs(self, focus_first=True):
        """Tự tích các description.txt còn lỗi sau khi kết thúc để người dùng thấy và chạy lại ngay."""
        error_paths = []
        for job in list(getattr(self, "desc_jobs", []) or []):
            if str(job.get("status") or "").lower() != "error":
                continue
            value = job.get("description_path") or job.get("path")
            if value:
                error_paths.append(str(Path(str(value))))
        if not error_paths:
            return 0
        checked = set(getattr(self, "desc_checked_paths", set()) or set())
        checked.update(x.lower() for x in error_paths)
        self.desc_checked_paths = checked
        try:
            self._refresh_description_workspace(preserve_path=Path(error_paths[0]) if focus_first else None)
        except Exception:
            self._refresh_description_workspace()
        self._description_update_checked_ui()
        try:
            self.desc_last_message = f"Còn {len(error_paths)} mô tả lỗi • đã tự chọn để chạy lại"
            self.desc_page_status.setText(self.desc_last_message)
        except Exception:
            pass
        return len(error_paths)

    def _description_check_all_visible(self):
        if not hasattr(self, "desc_tree"):
            return
        checked = set(getattr(self, "desc_checked_paths", set()) or set())
        self.desc_tree.blockSignals(True)
        try:
            for i in range(self.desc_tree.topLevelItemCount()):
                item = self.desc_tree.topLevelItem(i)
                value = item.data(0, Qt.UserRole)
                if value:
                    checked.add(str(Path(str(value))).lower())
                    item.setCheckState(0, Qt.Checked)
        finally:
            self.desc_tree.blockSignals(False)
        self.desc_checked_paths = checked
        self._description_update_checked_ui()

    def _description_uncheck_all(self):
        self.desc_checked_paths = set()
        if hasattr(self, "desc_tree"):
            self.desc_tree.blockSignals(True)
            try:
                for i in range(self.desc_tree.topLevelItemCount()):
                    self.desc_tree.topLevelItem(i).setCheckState(0, Qt.Unchecked)
            finally:
                self.desc_tree.blockSignals(False)
        self._description_update_checked_ui()

    def _description_status_label(self, status):
        translating = str(getattr(self, "desc_operation", "") or "") == "translate"
        return {
            "queued": "CHỜ DỊCH" if translating else "CHỜ SỬA",
            "running": "ĐANG DỊCH" if translating else "ĐANG SỬA",
            "done": "ĐÃ DỊCH" if translating else "ĐÃ SỬA",
            "error": "LỖI",
            "skipped": "BỎ QUA",
        }.get(str(status or "").lower(), str(status or "-").upper())

    def _description_filter_accepts(self, job, current_text):
        status = str((job or {}).get("status") or "queued").lower()
        selected = self.desc_filter_combo.currentText() if hasattr(self, "desc_filter_combo") else "Tất cả"
        wanted = {
            "Chờ sửa": "queued", "Đã sửa": "done", "Đang sửa": "running",
            "Lỗi": "error", "Bỏ qua": "skipped",
        }.get(selected)
        if wanted and status != wanted:
            return False
        query = self.desc_search_edit.text().strip().lower() if hasattr(self, "desc_search_edit") else ""
        if not query:
            return True
        hay = "\n".join([
            str((job or {}).get("description_path") or ""),
            str((job or {}).get("folder") or ""),
            str((job or {}).get("note") or ""),
            str(current_text or ""),
        ]).lower()
        return query in hay

    def _refresh_description_workspace(self, preserve_path=None):
        if not hasattr(self, "desc_tree"):
            return
        try:
            selected_path = str(preserve_path or self._description_selected_path() or "")
            stats = dict(getattr(self, "desc_stats", {}) or self._desc_compute_stats())
            total = int(stats.get("total") or 0)
            done = int(stats.get("done") or 0)
            running = int(stats.get("running") or 0)
            queued = int(stats.get("queued") or 0)
            error = int(stats.get("error") or 0)
            skipped = int(stats.get("skipped") or 0)
            translating = str(getattr(self, "desc_operation", "") or "") == "translate"
            self.desc_total_chip.setText(f"Tổng {total}")
            self.desc_done_chip.setText(f"Đã dịch {done}" if translating else f"Đã sửa {done}")
            self.desc_wait_chip.setText(f"Chờ dịch {queued}" if translating else f"Chờ {queued}")
            self.desc_error_chip.setText(f"Lỗi {error}")
            self.desc_skip_chip.setText(f"Bỏ qua {skipped}")
            self.desc_page_progress.setRange(0, max(1, total))
            self.desc_page_progress.setValue(min(max(0, done + skipped), max(1, total)))
            pct = int(((done + skipped) / total) * 100) if total else 0
            self.desc_page_progress.setFormat(f"{pct}%")
            self.desc_page_status.setText(str(getattr(self, "desc_last_message", "") or "Chưa quét mô tả"))

            busy = bool(getattr(self, "desc_running", False))
            thumb_busy = bool(getattr(self, "running", False))
            self.desc_scan_btn.setEnabled(not busy and not thumb_busy)
            self.desc_run_btn.setEnabled(not busy and not thumb_busy and (queued > 0 or bool(self._description_queue_roots())))
            self.desc_stop_btn.setEnabled(busy)
            self.desc_restore_all_btn.setEnabled(not busy and not thumb_busy and bool(self._description_queue_roots()))
            if hasattr(self, "desc_language_combo"):
                self.desc_language_combo.setEnabled(not busy and not thumb_busy)
            if hasattr(self, "desc_translate_all_btn"):
                self.desc_translate_all_btn.setEnabled(not busy and not thumb_busy and bool(self._description_checked_paths()))
            if hasattr(self, "desc_check_all_btn"):
                self.desc_check_all_btn.setEnabled(not busy and not thumb_busy and total > 0)
            if hasattr(self, "desc_check_vietnamese_btn"):
                self.desc_check_vietnamese_btn.setEnabled(not busy and not thumb_busy and total > 0)
            if hasattr(self, "desc_uncheck_all_btn"):
                self.desc_uncheck_all_btn.setEnabled(not busy and not thumb_busy and bool(getattr(self, "desc_checked_paths", set())))
            if hasattr(self, "desc_translate_selected_btn"):
                self.desc_translate_selected_btn.setEnabled(not busy and not thumb_busy and bool(self._description_selected_path()))

            self.desc_tree.blockSignals(True)
            self.desc_tree.clear()
            matched_item = None
            first_item = None
            for job in list(getattr(self, "desc_jobs", []) or []):
                desc_path = Path(str(job.get("description_path") or ""))
                try:
                    current = desc_path.read_text(encoding="utf-8-sig", errors="ignore") if desc_path.is_file() else ""
                except Exception:
                    current = ""
                if not self._description_filter_accepts(job, current):
                    continue
                compact = re.sub(r"\s+", " ", current).strip()
                excerpt = compact[:180] + ("…" if len(compact) > 180 else "")
                folder = desc_path.parent.name or str(job.get("folder") or "")
                item = QTreeWidgetItem([
                    "",
                    self._description_status_label(job.get("status")),
                    folder,
                    excerpt or "(trống)",
                    str(job.get("note") or ""),
                ])
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                path_key = str(desc_path).lower()
                item.setCheckState(0, Qt.Checked if path_key in set(getattr(self, "desc_checked_paths", set()) or set()) else Qt.Unchecked)
                item.setData(0, Qt.UserRole, str(desc_path))
                item.setToolTip(0, "Tích để đưa mô tả này vào danh sách dịch")
                item.setToolTip(1, str(desc_path))
                item.setToolTip(2, str(desc_path.parent))
                item.setToolTip(3, current)
                item.setToolTip(4, str(job.get("note") or ""))
                self.desc_tree.addTopLevelItem(item)
                if first_item is None:
                    first_item = item
                if selected_path and str(desc_path) == selected_path:
                    matched_item = item
            self.desc_tree.blockSignals(False)
            target = matched_item or first_item
            if target is not None:
                self.desc_tree.setCurrentItem(target)
                self._description_selection_changed()
                self._description_update_checked_ui()
            elif self.desc_tree.topLevelItemCount() == 0:
                self.desc_selected_path_label.setText("Không có mô tả phù hợp bộ lọc")
                self.desc_original_editor.clear()
                self.desc_current_editor.clear()
                self.desc_current_editor.setReadOnly(True)
                for btn_name in ("desc_open_folder_btn", "desc_reload_btn", "desc_undo_translate_btn", "desc_restore_selected_btn", "desc_save_btn", "desc_translate_selected_btn"):
                    try:
                        getattr(self, btn_name).setEnabled(False)
                    except Exception:
                        pass
        except Exception as e:
            try:
                self.append_log(f"[desc-ui] refresh lỗi nhẹ: {e}")
            except Exception:
                pass

    def _description_selection_changed(self):
        if not hasattr(self, "desc_current_editor"):
            return
        path = self._description_selected_path()
        checked_paths = [p for p in self._description_checked_paths() if p and p.is_file()]
        enabled = bool(path and path.is_file()) and not bool(getattr(self, "desc_running", False))
        for btn_name in ("desc_open_folder_btn", "desc_reload_btn", "desc_undo_translate_btn", "desc_restore_selected_btn", "desc_save_btn", "desc_translate_selected_btn"):
            try:
                getattr(self, btn_name).setEnabled(enabled)
            except Exception:
                pass
        self._description_update_checked_ui()
        self.desc_current_editor.setReadOnly(not enabled)
        if not path or not path.is_file():
            self.desc_selected_path_label.setText("Chọn một mô tả trong danh sách")
            self.desc_original_editor.clear(); self.desc_current_editor.clear()
            return
        try:
            current = path.read_text(encoding="utf-8-sig", errors="ignore")
        except Exception as e:
            current = f"Không đọc được file: {e}"
        original = ""
        try:
            first = self._description_first_backup_path(path, create_from_text=None)
            if first and Path(first).is_file():
                original = Path(first).read_text(encoding="utf-8-sig", errors="ignore")
        except Exception:
            original = ""
        self.desc_selected_path_label.setText(str(path))
        self.desc_selected_path_label.setToolTip(str(path))
        self.desc_original_editor.setPlainText(original or "Chưa có backup mô tả gốc. Backup sẽ được tạo trước lần sửa đầu tiên.")
        self.desc_current_editor.setPlainText(current)

    def _description_language_changed(self, value):
        value = str(value or "").strip()
        if value == "Tùy chỉnh...":
            custom, ok = QInputDialog.getText(self, APP_TITLE, "Nhập ngôn ngữ đích", text=str(getattr(self, "desc_translate_language", "English") or "English"))
            if ok and str(custom or "").strip():
                value = str(custom).strip()
                if self.desc_language_combo.findText(value) < 0:
                    self.desc_language_combo.insertItem(max(0, self.desc_language_combo.count() - 1), value)
                self.desc_language_combo.setCurrentText(value)
            else:
                old = str(getattr(self, "desc_translate_language", "English") or "English")
                idx = self.desc_language_combo.findText(old)
                if idx >= 0:
                    self.desc_language_combo.blockSignals(True)
                    self.desc_language_combo.setCurrentIndex(idx)
                    self.desc_language_combo.blockSignals(False)
                return
        self.desc_translate_language = value or "English"
        self.schedule_save_state()

    def _description_translation_backup_dir(self, desc_path):
        return Path(desc_path).parent / "_description_before_translation"

    def _description_latest_translation_backup(self, desc_path):
        backup_dir = self._description_translation_backup_dir(desc_path)
        if not backup_dir.is_dir():
            return None
        items = [p for p in backup_dir.glob("description_BEFORE_TRANSLATE_*.txt") if p.is_file()]
        items.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        return items[0] if items else None

    def _description_backup_before_translation(self, desc_path, text, wid=""):
        backup_dir = self._description_translation_backup_dir(desc_path)
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        suffix = f"_{wid}" if wid else ""
        backup = backup_dir / f"description_BEFORE_TRANSLATE_{stamp}{suffix}.txt"
        backup.write_text(str(text or "").rstrip("\n") + "\n", encoding="utf-8", errors="replace")
        return backup

    def _description_undo_translation_selected(self):
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang xử lý mô tả, chưa thể hoàn tác dịch.")
            return
        path = self._description_selected_path()
        if not path or not path.is_file():
            return
        backup = self._description_latest_translation_backup(path)
        if not backup:
            QMessageBox.information(self, APP_TITLE, "Mục này chưa có bản sao trước khi dịch.")
            return
        if QMessageBox.question(self, APP_TITLE, f"Khôi phục bản ngay trước lần dịch gần nhất?\n{backup.name}") != QMessageBox.Yes:
            return
        try:
            text = backup.read_text(encoding="utf-8-sig", errors="ignore")
            path.write_text(text.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
            with self.desc_lock:
                for job in self.desc_jobs:
                    if str(job.get("description_path") or "") == str(path):
                        status, note = self._description_persisted_status(path, text)
                        job["status"] = status
                        job["note"] = f"Đã hoàn tác dịch • {backup.name}"
                        break
                self.desc_stats = self._desc_compute_stats()
            self.desc_last_message = f"Đã hoàn tác dịch: {path.parent.name}"
            self.append_log(f"[desc-translate] hoàn tác OK • {path} • {backup.name}")
            self._refresh_description_workspace(preserve_path=path)
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không hoàn tác được bản dịch:\n{e}")

    def _description_open_selected_folder(self):
        path = self._description_selected_path()
        try:
            if path and path.parent.exists():
                if os.name == "nt":
                    os.startfile(str(path.parent))
                else:
                    subprocess.Popen(["xdg-open", str(path.parent)])
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không mở được thư mục:\n{e}")

    def _description_save_selected(self):
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả tự động, chưa thể lưu thủ công.")
            return
        path = self._description_selected_path()
        if not path or not path.is_file():
            return
        new_text = self.desc_current_editor.toPlainText().strip()
        if not new_text:
            QMessageBox.warning(self, APP_TITLE, "Mô tả không được để trống.")
            return
        try:
            old_text = path.read_text(encoding="utf-8-sig", errors="ignore")
            self._description_first_backup_path(path, create_from_text=old_text)
            path.write_text(new_text.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
            with self.desc_lock:
                for job in self.desc_jobs:
                    if str(job.get("description_path") or "") == str(path):
                        status, note = self._description_persisted_status(path, new_text)
                        job["status"] = status
                        job["note"] = "Đã lưu thủ công" if status == "done" else note
                        job["size"] = len(new_text)
                        break
                self.desc_stats = self._desc_compute_stats()
            self.desc_last_message = f"Đã lưu: {path.parent.name}"
            self.append_log(f"[desc-manual] lưu OK • {path}")
            self._refresh_description_workspace(preserve_path=path)
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không lưu được mô tả:\n{e}")

    def _description_restore_selected(self):
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, chưa thể khôi phục.")
            return
        path = self._description_selected_path()
        if not path or not path.is_file():
            return
        try:
            first = self._description_first_backup_path(path, create_from_text=None)
            if not first or not Path(first).is_file():
                QMessageBox.information(self, APP_TITLE, "Mục này chưa có backup mô tả gốc.")
                return
            if QMessageBox.question(self, APP_TITLE, f"Khôi phục mô tả gốc cho:\n{path.parent.name}?") != QMessageBox.Yes:
                return
            original = Path(first).read_text(encoding="utf-8-sig", errors="ignore")
            path.write_text(original.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
            with self.desc_lock:
                for job in self.desc_jobs:
                    if str(job.get("description_path") or "") == str(path):
                        job["status"] = "queued"
                        job["note"] = "Đã khôi phục mô tả gốc"
                        job["size"] = len(original)
                        break
                self.desc_stats = self._desc_compute_stats()
            self.desc_last_message = f"Đã khôi phục: {path.parent.name}"
            self.append_log(f"[desc-restore-one] OK • {path}")
            self._refresh_description_workspace(preserve_path=path)
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không khôi phục được mô tả:\n{e}")

    def stop_description_only(self):
        if not getattr(self, "desc_running", False):
            self.statusBar().showMessage("Sửa mô tả hiện không chạy", 1800)
            return
        self.desc_stop_event.set()
        self.desc_last_message = "Đã yêu cầu dừng sửa mô tả"
        self.append_log("[desc] người dùng yêu cầu dừng")
        self._refresh_description_workspace()

    def _btn(self, text, callback, object_name=None):
        b = QPushButton(text)
        if object_name:
            b.setObjectName(object_name)
        b.clicked.connect(callback)
        return b

    def _switch_workspace(self, index, save=True):
        """v13.09: chuyển giữa Thumbnail, Tên kênh & Logo và Sửa mô tả."""
        try:
            idx = int(index)
            if idx not in (0, 1, 2):
                idx = 0
            self.workspace_stack.setCurrentIndex(idx)
            self.nav_thumb_btn.setChecked(idx == 0)
            self.nav_brand_btn.setChecked(idx == 1)
            self.nav_desc_btn.setChecked(idx == 2)
            self._active_workspace = idx
            if idx == 0:
                self.statusBar().showMessage("Tạo Thumbnail", 1800)
            elif idx == 1:
                self.statusBar().showMessage("Tạo Tên Kênh & Logo", 1800)
            else:
                self.statusBar().showMessage("Sửa mô tả", 1800)
                self._refresh_description_sources_ui()
                self._refresh_description_workspace()
            if save:
                self.schedule_save_state()
        except Exception:
            pass

    def _toggle_sidebar(self):
        # Giữ tương thích phím/nút cũ: sidebar giờ luôn là menu chính.
        self._switch_workspace(0)

    def _apply_sidebar_visibility(self):
        try:
            self._sidebar_visible = True
            self.sidebar.setVisible(True)
        except Exception:
            pass

    def _open_channel_brand_dialog(self):
        self._switch_workspace(1)

    def _channel_brand_output_root(self):
        return self.backend_dir / "Channel_Brand_Output"

    def _channel_brand_sanitize_name(self, value):
        txt = re.sub(r'[<>:"/\\|?*]+', '_', str(value or '').strip())
        txt = re.sub(r'\s+', ' ', txt).strip(' ._')
        return (txt or 'channel_logo')[:120]

    def _channel_brand_pick_account(self, status_cb=None):
        """Chọn 1 profile cho tạo tên kênh.

        v13.28: nếu chưa có profile hợp lệ thì tự đăng nhập/bù profile giống luồng
        Tạo Thumbnail, thay vì dừng ngay bằng hộp thoại lỗi.
        """
        cb = status_cb or (lambda _x: None)
        candidates = list(self._configured_accounts() or [])
        if not candidates:
            candidates = [r.account_no() for r in self.rows if getattr(r, 'account_edit', None)]
        checked = []
        for acc in candidates:
            try:
                acc = int(acc)
                ok, profile, reason = self._description_profile_is_usable(acc)
                checked.append(f"A{acc}:{reason}")
                if ok:
                    self.ui_queue.put(("log", f"[brand-profile] dùng profile sẵn có A{acc} • {reason}"))
                    return acc, Path(profile)
            except Exception as e:
                checked.append(f"A{acc}:{type(e).__name__}")

        # Không còn profile sẵn: dùng đúng cơ chế auto-login của pool Thumbnail.
        details = ', '.join(checked[:10]) or 'chưa có profile nào'
        msg = "Chưa có profile Gemini sẵn sàng • đang tự đăng nhập tài khoản giống Tạo Thumbnail…"
        cb(msg)
        self.ui_queue.put(("log", f"[brand-profile] {msg} • {details}"))
        try:
            prepared = self._channel_brand_pick_accounts(count=1, status_cb=cb)
        except Exception as e:
            raise RuntimeError(
                "Không chuẩn bị được profile Gemini cho Tên kênh & Logo sau khi đã tự đăng nhập giống Tạo Thumbnail. "
                f"Chi tiết: {e}"
            ) from e
        if prepared:
            acc, profile = prepared[0]
            self.ui_queue.put(("log", f"[brand-profile] auto-login xong • dùng A{acc}"))
            return int(acc), Path(profile)
        raise RuntimeError("Không chuẩn bị được profile Gemini sau auto-login.")

    def _channel_brand_pick_accounts(self, count=6, status_cb=None):
        """Chọn đủ account từ pool Thumbnail; thiếu profile thì tự auto-login giống Tạo Thumbnail."""
        requested = max(1, int(count or 1))
        cb = status_cb or (lambda _x: None)

        def _candidate_accounts():
            vals = []
            try:
                vals.extend(list(self._configured_accounts() or []))
            except Exception:
                pass
            if not vals:
                try:
                    vals.extend([r.account_no() for r in self.rows if getattr(r, 'account_edit', None)])
                except Exception:
                    pass
            out = []
            for raw in vals:
                try:
                    acc = int(raw)
                    if acc > 0 and acc not in out:
                        out.append(acc)
                except Exception:
                    pass
            return out

        def _collect_usable(candidates):
            usable = []
            checked = []
            exhausted = set(getattr(self, 'exhausted_accounts', set()) or set())
            for raw_acc in candidates:
                try:
                    acc = int(raw_acc)
                    if acc in exhausted:
                        checked.append(f"A{acc}:đã hết lượt")
                        continue
                    if self._account_cooldown_remaining(acc) > 0:
                        checked.append(f"A{acc}:cooldown")
                        continue
                    ok, profile, reason = self._description_profile_is_usable(acc)
                    checked.append(f"A{acc}:{reason}")
                    if ok and all(int(x[0]) != acc for x in usable):
                        usable.append((acc, Path(profile)))
                        if len(usable) >= requested:
                            break
                except Exception as e:
                    checked.append(f"A{raw_acc}:{type(e).__name__}")
            return usable, checked

        candidates = _candidate_accounts()
        usable, checked = _collect_usable(candidates)
        if len(usable) >= requested:
            return usable[:requested]

        need = requested - len(usable)
        msg = f"Hiện có {len(usable)}/{requested} tài khoản sẵn sàng • tự đăng nhập thêm {need} tài khoản giống Tạo Thumbnail…"
        cb(msg)
        self.ui_queue.put(("log", f"[brand-login] {msg}"))

        attempted = set()
        max_parallel = max(1, int(globals().get('ACCOUNT_POOL_LOGIN_PARALLEL', 3) or 3))
        # Tối đa vài vòng để sau khi account bị Verify và pool tự thay thế, có thể lấy account mới ngay.
        for round_no in range(1, 5):
            candidates = _candidate_accounts()
            usable, checked = _collect_usable(candidates)
            if len(usable) >= requested:
                self.ui_queue.put(("log", f"[brand-login] đã đủ {len(usable)}/{requested} tài khoản sau auto-login"))
                cb(f"Đã chuẩn bị đủ {requested}/{requested} tài khoản. Đang mở 6 worker tạo logo…")
                return usable[:requested]

            exhausted = set(getattr(self, 'exhausted_accounts', set()) or set())
            pending = []
            for acc in candidates:
                try:
                    acc = int(acc)
                except Exception:
                    continue
                if acc in attempted or acc in exhausted:
                    continue
                if self._account_cooldown_remaining(acc) > 0:
                    continue
                if any(int(x[0]) == acc for x in usable):
                    continue
                # Chỉ login account có credential; account thiếu mật khẩu sẽ được bỏ qua như Thumbnail.
                try:
                    email, password, _recovery = self._get_login_credential(acc)
                except Exception:
                    email = password = ''
                if not email or not password:
                    self.ui_queue.put(("log", f"[brand-login] A{acc}: thiếu email/mật khẩu trong vault, bỏ qua"))
                    attempted.add(acc)
                    continue
                pending.append(acc)

            if not pending:
                break

            remaining_need = max(1, requested - len(usable))
            wave_size = min(len(pending), max(max_parallel, remaining_need))
            wave = pending[:wave_size]
            attempted.update(wave)
            cb(f"Đang tự đăng nhập {len(wave)} tài khoản bổ sung • vòng {round_no}…")
            self.ui_queue.put(("log", f"[brand-login] vòng {round_no} • login thêm: " + ','.join(f'A{x}' for x in wave)))

            with ThreadPoolExecutor(max_workers=min(max_parallel, len(wave)), thread_name_prefix='BrandLogin') as pool:
                futures = {
                    pool.submit(self._login_account_profile_if_needed, acc, '[brand-login]'): acc
                    for acc in wave
                }
                completed = 0
                for fut in as_completed(futures):
                    acc = futures[fut]
                    completed += 1
                    try:
                        ok = bool(fut.result())
                    except Exception as e:
                        ok = False
                        self.ui_queue.put(("log", f"[brand-login] A{acc}: lỗi {type(e).__name__}: {str(e)[:140]}"))
                    cb(f"Đã kiểm tra/login {completed}/{len(wave)} tài khoản bổ sung")
                    self.ui_queue.put(("log", f"[brand-login] A{acc}: {'OK' if ok else 'CHƯA SẴN SÀNG'}"))

            # Reload pool vì nhánh Thumbnail có thể vừa thay account bị Verify bằng account mới.
            time.sleep(0.3)

        candidates = _candidate_accounts()
        usable, checked = _collect_usable(candidates)
        if len(usable) < requested:
            details = ', '.join(checked[:12])
            raise RuntimeError(
                f"Tool đã tự đăng nhập thêm giống Tạo Thumbnail nhưng mới chuẩn bị được {len(usable)}/{requested} tài khoản. "
                f"Hãy kiểm tra các tài khoản còn lại trong Nhập TXT TK. Chi tiết: {details}"
            )
        return usable[:requested]

    def _channel_brand_parse_names(self, raw_text, limit=10):
        """Rút đúng danh sách tên, bỏ nhãn giao diện/markdown của Gemini."""
        text = str(raw_text or '').replace('\r\n', '\n').replace('\r', '\n')
        lines = []
        ignored_exact = {
            'copy', 'copy code', 'copied', 'show drafts', 'regenerate', 'share',
            'export', 'more', 'sources', 'google gemini', 'gemini', 'text',
            'plaintext', 'markdown', 'code', 'thumbs up', 'thumbs down',
        }
        for raw in text.split('\n'):
            line = raw.strip()
            if not line or line.startswith('```'):
                continue
            line = re.sub(r'^\s*(?:[-•*]+|\d+[\).:-]?|[A-Za-z][\).:-])\s*', '', line).strip()
            line = line.strip('"“”\'` ')
            if not line:
                continue
            low = re.sub(r'\s+', ' ', line).strip().lower()
            if low in ignored_exact:
                continue
            if low.startswith(('here are', 'dưới đây', 'tên kênh', 'channel names', 'gợi ý', 'suggested names')):
                continue
            if low.startswith(('gemini said', 'gemini says', 'gemini đã nói', 'gemini trả lời')):
                line = re.sub(r'^gemini\s+(?:said|says|đã\s+nói|trả\s+lời)\s*[:：-]?\s*', '', line, flags=re.I).strip()
                low = line.lower()
            if not line or len(line) > 90:
                continue
            # Loại câu giải thích rõ ràng; tên kênh vẫn được phép có dấu & hoặc dấu gạch ngang.
            if line.endswith(':') or (len(line.split()) > 11 and any(x in low for x in (' because ', ' these ', ' names ', ' channel '))):
                continue
            if line not in lines:
                lines.append(line)
            if len(lines) >= int(limit):
                break
        if len(lines) < 3:
            # Gemini đôi khi trả một dòng ngăn bằng dấu phẩy/semicolon.
            for raw in re.split(r'[,;|]+', text):
                line = re.sub(r'^\s*\d+[\).:-]?\s*', '', raw).strip().strip('"“”\'` ')
                low = line.lower()
                if low in ignored_exact or line.startswith('```'):
                    continue
                if 2 <= len(line) <= 90 and line not in lines:
                    lines.append(line)
                if len(lines) >= int(limit):
                    break
        return lines[:int(limit)]

    def _channel_brand_collect_name_response_state(self, drv):
        """Chỉ đọc các câu trả lời MODEL theo thứ tự DOM; không lấy prompt của người dùng.

        Bộ đọc chung cho description từng dựa vào trạng thái busy toàn trang. Gemini có thể
        giữ spinner/nút Stop giả sau khi text đã xong, khiến phần tên phải đợi tới timeout.
        """
        try:
            return drv.execute_script(r"""
                function visible(el){
                    if(!el || !el.getBoundingClientRect) return false;
                    const r=el.getBoundingClientRect(), st=getComputedStyle(el);
                    return st.display!=='none' && st.visibility!=='hidden' && Number(st.opacity||1)>0.01 &&
                           r.width>8 && r.height>8 && r.bottom>0 && r.right>0;
                }
                function textOf(el){
                    try { return String(el.innerText||el.textContent||'').replace(/\n{3,}/g,'\n\n').trim(); }
                    catch(e){ return ''; }
                }
                function attrs(el){
                    try {
                        return [el.tagName,el.className,el.id,el.getAttribute('role'),
                            el.getAttribute('data-testid'),el.getAttribute('data-test-id'),
                            el.getAttribute('data-message-author-role'),el.getAttribute('aria-label')]
                            .join(' ').toLowerCase();
                    } catch(e){ return ''; }
                }
                function inEditor(el){
                    try { return !!el.closest("textarea,input,[contenteditable='true'],div[role='textbox'],rich-textarea"); }
                    catch(e){ return false; }
                }
                function isUserTurn(el){
                    let n=el, guard=0;
                    while(n && guard++<10){
                        const a=attrs(n);
                        if((n.getAttribute && n.getAttribute('data-message-author-role')==='user') ||
                           a.includes('user-query') || a.includes('user-message') ||
                           a.includes('query-content') || a.includes('prompt-container')) return true;
                        if((n.getAttribute && n.getAttribute('data-message-author-role')==='model') ||
                           a.includes('model-response')) return false;
                        n=n.parentElement;
                    }
                    return false;
                }
                function hasNearSameChild(el,t){
                    try {
                        for(const c of Array.from(el.children||[])){
                            const ct=textOf(c);
                            if(ct && ct.length>=Math.max(8,t.length*0.82)) return true;
                        }
                    } catch(e){}
                    return false;
                }

                const selectors=[
                    "[data-message-author-role='model'] message-content",
                    "model-response message-content",
                    "[class*='model-response'] message-content",
                    "message-content",
                    "[data-message-author-role='model']",
                    "model-response",
                    "[class*='model-response']",
                    "[class*='response-container']"
                ];
                const nodeSet=new Set();
                for(const sel of selectors){
                    try { for(const el of document.querySelectorAll(sel)) nodeSet.add(el); } catch(e){}
                }
                const nodes=Array.from(nodeSet);
                nodes.sort((a,b)=>{
                    if(a===b) return 0;
                    const pos=a.compareDocumentPosition(b);
                    if(pos & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
                    if(pos & Node.DOCUMENT_POSITION_PRECEDING) return 1;
                    return 0;
                });
                const texts=[];
                for(const el of nodes){
                    if(!visible(el) || inEditor(el) || isUserTurn(el)) continue;
                    let t=textOf(el);
                    if(!t || t.length<3) continue;
                    const a=attrs(el);
                    // Ưu tiên message-content lá; bỏ container cha lặp nguyên nội dung con.
                    if(String(el.tagName||'').toLowerCase()!=='message-content' && hasNearSameChild(el,t)) continue;
                    const low=t.toLowerCase();
                    if(low.startsWith('you said') || low.startsWith('bạn đã nói')) continue;
                    texts.push(t);
                }

                const stopBusy=Array.from(document.querySelectorAll('button,[role="button"]')).some(b=>{
                    if(!visible(b)) return false;
                    const t=((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')).toLowerCase();
                    return t.includes('stop response') || t.includes('stop generating') ||
                           t.includes('dừng phản hồi') || t.includes('dừng tạo');
                });
                const progressBusy=Array.from(document.querySelectorAll('main [role="progressbar"], model-response [role="progressbar"]')).some(visible);
                return {texts:texts, busy:!!(stopBusy||progressBusy), url:location.href};
            """) or {'texts': [], 'busy': False}
        except Exception:
            return {'texts': [], 'busy': False}

    def _channel_brand_send_prompt_get_names(self, drv, prompt, stop_event, status_cb=None, limit=10):
        """Gửi prompt và lấy ngay phản hồi MỚI khi đã nhìn thấy đủ `limit` tên.

        Không chờ cờ busy của Gemini tắt. Baseline trước khi gửi giúp nút "Đổi 10 tên khác"
        không đọc nhầm bộ 10 tên của lượt trước trong cùng conversation.
        """
        cb = status_cb or (lambda _x: None)
        if not self._description_wait_editor_ready(
            drv, timeout=float(os.environ.get('GEMINI_BRAND_NAME_READY_TIMEOUT', '20') or 20)
        ):
            raise RuntimeError('Gemini chưa sẵn sàng ô nhập để tạo tên kênh')

        before = self._channel_brand_collect_name_response_state(drv)
        baseline = [str(x or '').strip() for x in (before.get('texts') or []) if str(x or '').strip()]
        baseline_count = len(baseline)
        baseline_sigs = {re.sub(r'\s+', ' ', x).strip().lower() for x in baseline}

        self._description_write_prompt(drv, prompt)
        self._description_click_send(
            drv, timeout=float(os.environ.get('GEMINI_BRAND_NAME_SEND_TIMEOUT', '6') or 6)
        )
        cb('Đang nhận tên từ Gemini…')

        end = time.time() + float(os.environ.get('GEMINI_BRAND_NAME_TIMEOUT', '45') or 45)
        last_text = ''
        stable_since = 0.0
        saw_new = False
        while time.time() < end and not stop_event.is_set():
            state = self._channel_brand_collect_name_response_state(drv)
            texts = [str(x or '').strip() for x in (state.get('texts') or []) if str(x or '').strip()]
            pool = []

            # Bình thường Gemini chỉ nối thêm một model turn mới ở cuối DOM.
            if len(texts) > baseline_count:
                pool.extend(texts[baseline_count:])
            else:
                # Fallback khi Gemini virtualize DOM hoặc thay node cũ trong lúc streaming.
                for t in texts:
                    sig = re.sub(r'\s+', ' ', t).strip().lower()
                    if sig not in baseline_sigs:
                        pool.append(t)
                if not pool and texts and baseline:
                    if re.sub(r'\s+', ' ', texts[-1]).strip().lower() != re.sub(r'\s+', ' ', baseline[-1]).strip().lower():
                        pool.append(texts[-1])

            if pool:
                saw_new = True
                # Chọn candidate mới có nhiều tên hợp lệ nhất; nếu bằng nhau chọn turn cuối.
                scored = []
                for idx, t in enumerate(pool):
                    parsed = self._channel_brand_parse_names(t, limit)
                    scored.append((len(parsed), idx, len(t), t))
                candidate = max(scored, key=lambda x: (x[0], x[1], x[2]))[3]
                if candidate != last_text:
                    last_text = candidate
                    stable_since = time.time()
                names_now = self._channel_brand_parse_names(candidate, limit)
                if len(names_now) >= int(limit) and (time.time() - stable_since) >= 0.22:
                    self.ui_queue.put(('log', f'[brand-name] lấy ngay {len(names_now)}/{limit} tên khi phản hồi mới đã đủ'))
                    return candidate
                # Trường hợp Gemini kết thúc sớm với ít hơn 10 tên: trả nhanh để lớp trên gửi bổ sung.
                if names_now and not bool(state.get('busy')) and (time.time() - stable_since) >= 0.65:
                    return candidate
            time.sleep(0.16)

        if stop_event.is_set():
            raise RuntimeError('Đã dừng trước khi Gemini trả tên kênh')
        if saw_new and last_text:
            return last_text
        raise RuntimeError('Gemini không trả phản hồi tên kênh mới trong thời gian chờ')

    def _channel_brand_session(self, status_cb=None):
        if self.running or self.desc_running or self.queue_running:
            raise RuntimeError("Tool đang chạy Queue hoặc Sửa mô tả. Hãy đợi hoàn tất rồi dùng Tên kênh & Logo.")
        cb = status_cb or (lambda _x: None)
        self._channel_brand_stop_event.clear()
        self.desc_stop_event.clear()
        drv = None
        run_root = None
        try:
            cb("Đang chuẩn bị Chromium local…")
            self._description_prepare_local_browser_runtime()
            acc, _src_profile = self._channel_brand_pick_account(status_cb=cb)
            local_base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or str(self.backend_dir))
            run_root = local_base / "ToolThumbnail" / "brand_runs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            session_profile = run_root / f"profile_A{acc}"
            run_root.mkdir(parents=True, exist_ok=True)
            cb(f"Đang clone profile A{acc}…")
            self._description_prepare_profile_clone(acc, session_profile, wid="BRAND")
            cb(f"Đang mở Gemini bằng A{acc}…")
            drv = self._description_open_driver(acc, session_profile)
            return drv, acc, run_root
        except Exception:
            self._channel_brand_finish_session(drv, run_root)
            raise

    def _channel_brand_finish_session(self, drv, run_root):
        try:
            self._description_close_driver_fast(drv, reason="Tên kênh & Logo kết thúc", timeout=0.3)
        except Exception:
            try:
                if drv is not None:
                    drv.quit()
            except Exception:
                pass
        try:
            shutil.rmtree(run_root, ignore_errors=True)
        except Exception:
            pass
        try:
            self._desc_profile_prune_guard = False
        except Exception:
            pass

    def _channel_brand_close_name_session(self):
        """Đóng conversation đặt tên đang giữ, dùng khi tạo bộ KEY mới hoặc thoát tool."""
        drv = getattr(self, '_channel_brand_name_drv', None)
        run_root = getattr(self, '_channel_brand_name_run_root', None)
        self._channel_brand_name_drv = None
        self._channel_brand_name_acc = None
        self._channel_brand_name_run_root = None
        self._channel_brand_name_key = ""
        self._channel_brand_name_notes = ""
        self._channel_brand_name_history = []
        if drv is not None or run_root is not None:
            self._channel_brand_finish_session(drv, run_root)

    def _channel_brand_name_session_is_alive(self):
        drv = getattr(self, '_channel_brand_name_drv', None)
        if drv is None:
            return False
        try:
            return bool(drv.execute_script("return document.readyState === 'complete' || document.readyState === 'interactive';"))
        except Exception:
            return False

    def _channel_brand_generate_names(self, key, notes, status_cb=None, reuse_conversation=False):
        """Tạo 10 tên; khi reuse_conversation=True phải gửi tiếp trong đúng Gemini conversation hiện tại."""
        with self._channel_brand_lock:
            cb = status_cb or (lambda _x: None)
            drv = None
            acc = None
            created_new_session = False

            if reuse_conversation:
                if not self._channel_brand_name_session_is_alive():
                    raise RuntimeError("Cuộc trò chuyện đặt tên hiện tại đã đóng. Hãy bấm 'Tạo 10 tên kênh' để bắt đầu lại.")
                drv = self._channel_brand_name_drv
                acc = self._channel_brand_name_acc
                # Giữ đúng KEY + ghi chú của lượt đầu, kể cả người dùng vô tình sửa ô nhập sau đó.
                key = self._channel_brand_name_key
                notes = self._channel_brand_name_notes
                previous = [str(x).strip() for x in (self._channel_brand_name_history or []) if str(x).strip()]
                previous_text = "\n".join(previous[-80:])
                prompt = (
                    "Generate exactly 10 MORE unique YouTube channel names for the SAME KEY, conditions and context in this conversation.\n"
                    "Do not repeat any name already suggested earlier.\n"
                    + (f"Names already used:\n{previous_text}\n\n" if previous_text else "")
                    + "Return ONLY the 10 new names, one name per line, without numbering, bullets, quotes, headings or commentary."
                )
                cb("Đang đổi 10 tên khác…")
            else:
                self._channel_brand_close_name_session()
                drv, acc, run_root = self._channel_brand_session(cb)
                self._channel_brand_name_drv = drv
                self._channel_brand_name_acc = acc
                self._channel_brand_name_run_root = run_root
                self._channel_brand_name_key = str(key).strip()
                self._channel_brand_name_notes = str(notes).strip()
                self._channel_brand_name_history = []
                created_new_session = True
                try:
                    drv.get("https://gemini.google.com/app/new")
                    if not self._description_wait_editor_ready(drv, timeout=24):
                        raise RuntimeError("Gemini chưa sẵn sàng ô nhập để tạo tên kênh")
                except Exception:
                    self._channel_brand_close_name_session()
                    raise
                prompt = (
                    "You are a professional YouTube channel naming expert.\n"
                    f"Main music KEY/topic: {self._channel_brand_name_key}\n"
                    f"Additional naming conditions: {self._channel_brand_name_notes or 'No extra conditions.'}\n\n"
                    "Generate exactly 10 unique, memorable and brandable YouTube channel names that fit the KEY and all conditions. "
                    "Avoid duplicates, awkward spelling, trademark-like names, numbers, and explanations. "
                    "Return ONLY the 10 names, one name per line, without numbering, bullets, quotes, headings or commentary."
                )
                cb("Đang tạo 10 tên kênh…")

            try:
                raw = self._channel_brand_send_prompt_get_names(
                    drv, prompt, self._channel_brand_stop_event, status_cb=cb, limit=10
                )
                names = self._channel_brand_parse_names(raw, 10)
                if len(names) < 10:
                    retry_prompt = (
                        "Return EXACTLY 10 unique names for the same request. "
                        "Do not repeat earlier names. One name per line only. "
                        "No numbering, bullets, heading or explanation."
                    )
                    raw_retry = self._channel_brand_send_prompt_get_names(
                        drv, retry_prompt, self._channel_brand_stop_event, status_cb=cb, limit=10
                    )
                    names = self._channel_brand_parse_names(raw_retry, 10)
                if len(names) < 10:
                    raise RuntimeError(f"Gemini chưa trả đủ 10 tên hợp lệ: {str(raw)[:260]}")

                history_lower = {str(x).strip().lower() for x in self._channel_brand_name_history}
                unique_names = []
                for name in names:
                    clean = str(name).strip()
                    if clean and clean.lower() not in history_lower:
                        unique_names.append(clean)
                        history_lower.add(clean.lower())
                if len(unique_names) < 10 and reuse_conversation:
                    missing = 10 - len(unique_names)
                    retry_more = (
                        f"Give {missing} additional NEW names now. Do not repeat any earlier name. "
                        "One name per line only, with no numbering or explanation."
                    )
                    raw_more = self._channel_brand_send_prompt_get_names(
                        drv, retry_more, self._channel_brand_stop_event, status_cb=cb, limit=missing
                    )
                    for name in self._channel_brand_parse_names(raw_more, missing):
                        clean = str(name).strip()
                        if clean and clean.lower() not in history_lower:
                            unique_names.append(clean)
                            history_lower.add(clean.lower())
                        if len(unique_names) >= 10:
                            break
                names = unique_names[:10]
                if len(names) < 10:
                    raise RuntimeError("Gemini chưa tạo đủ 10 tên mới không trùng trong cuộc trò chuyện hiện tại.")

                self._channel_brand_name_history.extend(names)
                try:
                    out_root = self._channel_brand_output_root()
                    out_root.mkdir(parents=True, exist_ok=True)
                    (out_root / "channel_names_latest.txt").write_text("\n".join(names) + "\n", encoding="utf-8")
                    (out_root / "channel_names_history.txt").write_text("\n".join(self._channel_brand_name_history) + "\n", encoding="utf-8")
                except Exception:
                    pass
                self.ui_queue.put(("log", f"[brand] A{acc} tạo {len(names)} tên kênh • same_conversation={bool(reuse_conversation)} • KEY={self._channel_brand_name_key}"))
                return names
            except Exception:
                # Nếu lượt đầu không thành công thì không giữ một session dở dang.
                if created_new_session:
                    self._channel_brand_close_name_session()
                raise

    def _channel_brand_current_model(self, drv):
        try:
            return str(drv.execute_script(r"""
                const b=document.querySelector('button[data-test-id="bard-mode-menu-button"]');
                if(!b) return '';
                return ((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')).trim();
            """) or '').strip()
        except Exception:
            return ''

    def _channel_brand_select_pro_model(self, drv, worker_no=0, account_no=0, timeout=12):
        prefix = f"[brand-W{worker_no}] A{account_no}" if worker_no else "[brand]"
        current = self._channel_brand_current_model(drv)
        if 'pro' in current.lower():
            self.ui_queue.put(("log", f"{prefix} model đã là {current}"))
            return current

        end = time.time() + float(timeout)
        opened = False
        while time.time() < end and not self._channel_brand_stop_event.is_set():
            try:
                result = drv.execute_script(r"""
                    function visible(el){
                        if(!el) return false;
                        const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                        return s.display!=='none'&&s.visibility!=='hidden'&&r.width>20&&r.height>16;
                    }
                    const btn=document.querySelector('button[data-test-id="bard-mode-menu-button"]');
                    if(!btn) return {ok:false,why:'no-model-button'};
                    if(btn.getAttribute('aria-expanded')!=='true'){
                        btn.click();
                        return {ok:false,why:'opened'};
                    }
                    let item=document.querySelector('gem-menu-item[data-test-id="bard-mode-option-9d8ca3786ebdfbea"]');
                    if(!item || !visible(item)){
                        item=Array.from(document.querySelectorAll('gem-menu-item[role="menuitem"]')).find(x=>{
                            const t=(x.innerText||x.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
                            return visible(x) && /(^|\s)pro(\s|$)/.test(t);
                        })||null;
                    }
                    if(!item) return {ok:false,why:'no-pro-item'};
                    const label=(item.innerText||item.textContent||'').replace(/\s+/g,' ').trim();
                    item.click();
                    return {ok:true,label:label};
                """) or {}
                if result.get('why') == 'opened':
                    opened = True
                if result.get('ok'):
                    break
            except Exception:
                pass
            time.sleep(0.35)
        else:
            raise RuntimeError("Không tìm thấy hoặc không bấm được model Pro")

        end_verify = time.time() + 8.0
        while time.time() < end_verify and not self._channel_brand_stop_event.is_set():
            current = self._channel_brand_current_model(drv)
            if 'pro' in current.lower():
                self.ui_queue.put(("log", f"{prefix} đã chọn model {current}"))
                return current
            time.sleep(0.3)
        raise RuntimeError(f"Đã bấm Pro nhưng Gemini chưa xác nhận model Pro; hiện tại={current or 'không rõ'}")

    def _channel_brand_image_tool_checked(self, drv):
        try:
            return bool(drv.execute_script(r"""
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>20&&r.height>16;
                }
                const items=Array.from(document.querySelectorAll('button[role="menuitemcheckbox"]'));
                const item=items.find(x=>{
                    const t=(x.innerText||x.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
                    const icon=x.querySelector('[data-mat-icon-name="image_create"],mat-icon[fonticon="image_create"]');
                    return visible(x) && (t.startsWith('create image') || t.includes('tạo hình ảnh') || !!icon);
                });
                return !!item && item.getAttribute('aria-checked')==='true';
            """))
        except Exception:
            return False

    def _channel_brand_enable_create_image(self, drv, worker_no=0, account_no=0, timeout=12):
        from selenium.webdriver.common.keys import Keys
        from selenium.webdriver.common.action_chains import ActionChains
        prefix = f"[brand-W{worker_no}] A{account_no}" if worker_no else "[brand]"
        end = time.time() + float(timeout)
        clicked = False
        while time.time() < end and not self._channel_brand_stop_event.is_set():
            try:
                result = drv.execute_script(r"""
                    function visible(el){
                        if(!el) return false;
                        const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                        return s.display!=='none'&&s.visibility!=='hidden'&&r.width>20&&r.height>16;
                    }
                    const tools=document.querySelector('button[aria-label="Upload & tools"]');
                    if(!tools) return {ok:false,why:'no-tools-button'};
                    if(tools.getAttribute('aria-expanded')!=='true'){
                        tools.click();
                        return {ok:false,why:'opened'};
                    }
                    const items=Array.from(document.querySelectorAll('button[role="menuitemcheckbox"]'));
                    const item=items.find(x=>{
                        const t=(x.innerText||x.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
                        const icon=x.querySelector('[data-mat-icon-name="image_create"],mat-icon[fonticon="image_create"]');
                        return visible(x) && (t.startsWith('create image') || t.includes('tạo hình ảnh') || !!icon);
                    })||null;
                    if(!item) return {ok:false,why:'no-create-image'};
                    const checked=item.getAttribute('aria-checked')==='true';
                    const label=(item.innerText||item.textContent||'').replace(/\s+/g,' ').trim();
                    if(!checked) item.click();
                    return {ok:true,already:checked,label:label};
                """) or {}
                if result.get('ok'):
                    clicked = not bool(result.get('already'))
                    break
            except Exception:
                pass
            time.sleep(0.35)
        else:
            raise RuntimeError("Không tìm thấy mục Create image trong Upload & tools")

        time.sleep(0.65)
        verified = False
        for _ in range(2):
            try:
                # Reopen menu when it closed so aria-checked can be verified.
                drv.execute_script(r"""
                    const b=document.querySelector('button[aria-label="Upload & tools"]');
                    if(b && b.getAttribute('aria-expanded')!=='true') b.click();
                """)
            except Exception:
                pass
            time.sleep(0.45)
            if self._channel_brand_image_tool_checked(drv):
                verified = True
                break
        try:
            ActionChains(drv).send_keys(Keys.ESCAPE).perform()
        except Exception:
            try:
                drv.execute_script("document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',bubbles:true}));")
            except Exception:
                pass
        if not verified:
            raise RuntimeError("Đã bấm Create image nhưng Gemini chưa xác nhận aria-checked=true")
        self.ui_queue.put(("log", f"{prefix} Create image đã bật"))
        return True

    def _channel_brand_prepare_pro_image_mode(self, drv, worker_no=0, account_no=0):
        prefix = f"[brand-W{worker_no}] A{account_no}" if worker_no else "[brand]"
        last_model = self._channel_brand_current_model(drv)
        tool_ok = False
        warnings = []
        for _ in range(2):
            try:
                last_model = self._channel_brand_select_pro_model(drv, worker_no, account_no)
            except Exception as e:
                warnings.append(str(e))
                try:
                    last_model = self._channel_brand_current_model(drv)
                except Exception:
                    pass
                self.ui_queue.put(("log", f"{prefix} cảnh báo model Pro • {e} • sẽ tiếp tục thử Create image"))
            try:
                self._channel_brand_enable_create_image(drv, worker_no, account_no)
                tool_ok = True
            except Exception as e:
                warnings.append(str(e))
                self.ui_queue.put(("log", f"{prefix} cảnh báo Create image • {e}"))
                time.sleep(0.35)
                continue
            time.sleep(0.35)
            model_now = self._channel_brand_current_model(drv)
            tool_verify = False
            try:
                drv.execute_script(r"""
                    const b=document.querySelector('button[aria-label="Upload & tools"]');
                    if(b && b.getAttribute('aria-expanded')!=='true') b.click();
                """)
                time.sleep(0.35)
                tool_verify = self._channel_brand_image_tool_checked(drv)
            finally:
                try:
                    from selenium.webdriver.common.keys import Keys
                    from selenium.webdriver.common.action_chains import ActionChains
                    ActionChains(drv).send_keys(Keys.ESCAPE).perform()
                except Exception:
                    pass
            if tool_verify and 'pro' in str(model_now or '').lower():
                self.ui_queue.put(("log", f"{prefix} sẵn sàng • model Pro + Create image"))
                return True
            if tool_verify:
                self.ui_queue.put(("log", f"{prefix} sẵn sàng kiểu mềm • Create image OK, model hiện '{model_now or last_model or 'không rõ'}'. Tiếp tục tạo để tránh lỡ tab tạo ảnh."))
                return True
        if tool_ok:
            self.ui_queue.put(("log", f"{prefix} cảnh báo • chỉ xác nhận được Create image, chưa xác nhận chắc nhãn Pro. Vẫn tiếp tục chạy tạo ảnh."))
            return True
        raise RuntimeError("Không bật được chế độ tạo ảnh. " + (" | ".join(warnings[:3]) if warnings else f"model={last_model or 'không rõ'}"))

    def _channel_brand_editor_text(self, drv):
        try:
            return str(drv.execute_script(r"""
                const el=document.querySelector('div[aria-label="Enter a prompt for Gemini"],div[role="textbox"][contenteditable="true"],rich-textarea div[contenteditable="true"]');
                return el ? (el.innerText||el.textContent||el.value||'') : '';
            """) or '')
        except Exception:
            return ''

    def _channel_brand_send_prompt_confirm(self, drv, prompt, channel_name, worker_no=0, account_no=0, timeout=18):
        prefix = f"[brand-W{worker_no}] A{account_no}" if worker_no else "[brand]"
        prompt = str(prompt or '')
        channel_name = str(channel_name or '').strip()
        self._description_write_prompt(drv, prompt)
        time.sleep(0.25)
        editor_text = self._channel_brand_editor_text(drv)
        expected = re.sub(r'\s+', ' ', prompt).strip()
        actual = re.sub(r'\s+', ' ', editor_text).strip()
        if not actual or expected[:60] not in actual:
            raise RuntimeError("Prompt chưa được ghi đầy đủ vào ô nhập Gemini")
        self.ui_queue.put(("log", f"{prefix} đã ghi prompt vào ô nhập ({len(actual)} ký tự)"))

        before_url = ''
        try:
            before_url = str(drv.current_url or '')
        except Exception:
            pass

        # Use the exact selector found by F12; keep generic fallback for future UI changes.
        clicked = False
        try:
            btn = drv.execute_script(r"""
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>12&&r.height>12&&!el.disabled&&el.getAttribute('aria-disabled')!=='true';
                }
                const exact=document.querySelector('button[aria-label="Send message"]');
                if(exact && visible(exact)) return exact;
                return Array.from(document.querySelectorAll('button,[role="button"]')).find(b=>{
                    const t=((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')).toLowerCase();
                    return visible(b)&&(t.includes('send')||t.includes('gửi'));
                })||null;
            """)
            if btn:
                try:
                    drv.execute_script("arguments[0].click();", btn)
                except Exception:
                    btn.click()
                clicked = True
        except Exception:
            clicked = False
        if not clicked:
            self._description_click_send(drv, timeout=8)

        marker_a = re.sub(r'\s+', ' ', prompt[:80]).strip()
        marker_b = channel_name
        end = time.time() + float(timeout)
        second_click_done = False
        last_state = {}
        while time.time() < end and not self._channel_brand_stop_event.is_set():
            try:
                state = drv.execute_script(r"""
                    const markerA=arguments[0], markerB=arguments[1], beforeUrl=arguments[2];
                    const editor=document.querySelector('div[aria-label="Enter a prompt for Gemini"],div[role="textbox"][contenteditable="true"],rich-textarea div[contenteditable="true"]');
                    const editorText=editor?(editor.innerText||editor.textContent||editor.value||'').replace(/\s+/g,' ').trim():'';
                    const history=document.querySelector('infinite-scroller[data-test-id="chat-history-container"],main');
                    const historyText=history?(history.innerText||history.textContent||'').replace(/\s+/g,' ').trim():'';
                    const body=(document.body&&document.body.innerText||'').replace(/\s+/g,' ').trim();
                    const url=location.href;
                    const stop=Array.from(document.querySelectorAll('button,[role="button"]')).some(b=>{
                        const t=((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')).toLowerCase();
                        const r=b.getBoundingClientRect(),s=getComputedStyle(b);
                        return s.display!=='none'&&s.visibility!=='hidden'&&r.width>10&&r.height>10&&(t.includes('stop')||t.includes('dừng'));
                    });
                    const creation=['image creation','creating image','creating your image','generating image','đang tạo hình ảnh'].some(x=>body.toLowerCase().includes(x));
                    const historyHas=(markerA&&historyText.includes(markerA))||(markerB&&historyText.includes(markerB));
                    return {editorText:editorText,historyHas:historyHas,url:url,urlChanged:!!beforeUrl&&url!==beforeUrl,stop:stop,creation:creation};
                """, marker_a, marker_b, before_url) or {}
                last_state = state
                cleared = len(str(state.get('editorText') or '').strip()) < 4
                confirmed = cleared and (bool(state.get('historyHas')) or bool(state.get('urlChanged')) or bool(state.get('stop')) or bool(state.get('creation')))
                if confirmed:
                    self.ui_queue.put(("log", f"{prefix} prompt đã gửi và được xác nhận"))
                    return state
                # Retry only when text is still in the editor; this cannot duplicate an already-cleared prompt.
                if not second_click_done and (time.time() + 8.0) >= end and not cleared:
                    second_click_done = True
                    try:
                        self._description_click_send(drv, timeout=5)
                        self.ui_queue.put(("log", f"{prefix} bấm gửi lần 2 vì prompt vẫn còn trong ô nhập"))
                    except Exception:
                        pass
            except Exception:
                pass
            time.sleep(0.35)
        raise RuntimeError(f"Không xác nhận được prompt đã gửi; trạng thái={str(last_state)[:280]}")

    def _channel_brand_image_state(self, drv):
        """v13.31: dò ảnh sâu xuyên Shadow DOM và cả CSS background/role=img.

        Gemini đôi khi hiển thị ảnh thật trong custom element hoặc shadowRoot nên
        document.querySelectorAll('img') của bản cũ không nhìn thấy dù người dùng
        đã thấy ảnh trên Chrome.
        """
        try:
            return drv.execute_script(r"""
                function visible(el){
                    if(!el || !el.getBoundingClientRect) return false;
                    const r=el.getBoundingClientRect(), s=getComputedStyle(el);
                    return s.display!=='none' && s.visibility!=='hidden' && Number(s.opacity||1)>0.01 &&
                           r.width>=90 && r.height>=90 && r.bottom>0 && r.right>0 &&
                           r.top<window.innerHeight && r.left<window.innerWidth;
                }
                function bad(src){
                    const s=String(src||'').toLowerCase();
                    return !s || s.includes('googleusercontent.com/ogw/') || s.includes('/a/') ||
                        s.includes('avatar') || s.includes('profile') || s.includes('favicon') ||
                        s.includes('gemini_sparkle') || s.includes('lamda/images') || s.includes('logo-scs') ||
                        s.includes('googlelogo') || s.includes('product-logo') ||
                        s.endsWith('.svg') || s.includes('.svg?');
                }
                function rootChain(el){
                    const arr=[]; let n=el, guard=0;
                    while(n && guard++<40){
                        arr.push(n);
                        if(n.parentElement) n=n.parentElement;
                        else {
                            const root=n.getRootNode ? n.getRootNode() : null;
                            n=(root && root.host) ? root.host : null;
                        }
                    }
                    return arr;
                }
                function responseLike(el){
                    for(const n of rootChain(el)){
                        const tag=String(n.tagName||'').toLowerCase();
                        const cls=String(n.className||'').toLowerCase();
                        const test=String((n.getAttribute&&(
                            n.getAttribute('data-test-id')||n.getAttribute('data-testid')||
                            n.getAttribute('data-message-author-role')||n.getAttribute('role')||''))||'').toLowerCase();
                        if(tag.includes('model-response') || tag.includes('message-content') || tag.includes('generated-image') ||
                           cls.includes('model-response') || cls.includes('response-container') || cls.includes('generated-image') ||
                           cls.includes('image-card') || test==='model' || test.includes('model-response')) return true;
                    }
                    return false;
                }
                function allDeep(){
                    const out=[], roots=[document], seenRoots=new Set(), seenEls=new Set();
                    while(roots.length){
                        const root=roots.shift();
                        if(!root || seenRoots.has(root)) continue;
                        seenRoots.add(root);
                        let els=[];
                        try{ els=Array.from(root.querySelectorAll('*')); }catch(e){}
                        for(const el of els){
                            if(!seenEls.has(el)){ seenEls.add(el); out.push(el); }
                            try{ if(el.shadowRoot && !seenRoots.has(el.shadowRoot)) roots.push(el.shadowRoot); }catch(e){}
                        }
                    }
                    return out;
                }
                function bgUrl(el){
                    try{
                        const bg=getComputedStyle(el).backgroundImage||'';
                        if(!bg || bg==='none') return '';
                        const m=bg.match(/url\(["']?(.*?)["']?\)/i);
                        return m ? m[1] : '';
                    }catch(e){ return ''; }
                }
                const deep=allDeep(), out=[], seen=new Set();
                function add(kind,src,el,extra){
                    try{
                        if(!visible(el)) return;
                        const r=el.getBoundingClientRect();
                        const x=Math.max(0,r.left), y=Math.max(0,r.top);
                        const w=Math.min(r.right,window.innerWidth)-x, h=Math.min(r.bottom,window.innerHeight)-y;
                        if(w<80 || h<80) return;
                        const naturalW=Number((extra&&extra.naturalW)||0), naturalH=Number((extra&&extra.naturalH)||0);
                        if(kind!=='element' && bad(src)) return;
                        const alt=String((el.getAttribute&&(
                            el.getAttribute('alt')||el.getAttribute('aria-label')||el.getAttribute('title')||''))||'');
                        const tag=String(el.tagName||'').toLowerCase();
                        const cls=String(el.className||'').slice(0,250);
                        const response=responseLike(el);
                        const key=[kind,src,Math.round(x),Math.round(y),Math.round(w),Math.round(h)].join('|');
                        if(seen.has(key)) return; seen.add(key);
                        const imageHint=(tag+' '+cls+' '+alt).toLowerCase();
                        const hinted=imageHint.includes('generated')||imageHint.includes('image')||imageHint.includes('photo')||imageHint.includes('media');
                        const quality=(response?100000000:0)+(hinted?50000000:0)+(naturalW*naturalH)+(w*h);
                        out.push({kind:kind,src:String(src||''),signature:key,area:w*h,response:response,hinted:hinted,
                            x:x,y:y,w:w,h:h,naturalW:naturalW,naturalH:naturalH,tag:tag,alt:alt,cls:cls,quality:quality});
                    }catch(e){}
                }
                for(const el of deep){
                    const tag=String(el.tagName||'').toLowerCase();
                    if(tag==='img'){
                        const src=el.currentSrc||el.src||el.getAttribute('src')||el.getAttribute('data-src')||'';
                        add('img',src,el,{naturalW:el.naturalWidth||0,naturalH:el.naturalHeight||0});
                    } else if(tag==='canvas'){
                        const r=el.getBoundingClientRect();
                        const src='canvas:'+Math.round(r.left)+':'+Math.round(r.top)+':'+Math.round(r.width)+':'+Math.round(r.height);
                        add('canvas',src,el,{naturalW:el.width||0,naturalH:el.height||0});
                    } else {
                        const bg=bgUrl(el);
                        if(bg) add('bg',bg,el,{});
                        const role=String((el.getAttribute&&el.getAttribute('role'))||'').toLowerCase();
                        const tagHint=tag.includes('generated-image')||tag.includes('image-card')||tag.includes('image-container');
                        const cls=String(el.className||'').toLowerCase();
                        const clsHint=cls.includes('generated-image')||cls.includes('image-card')||cls.includes('result-image');
                        if((role==='img'||tagHint||clsHint) && !bg){
                            const r=el.getBoundingClientRect();
                            add('element','element:'+Math.round(r.left)+':'+Math.round(r.top)+':'+Math.round(r.width)+':'+Math.round(r.height),el,{});
                        }
                    }
                }
                // Một số nút download nằm cạnh ảnh nhưng ảnh không có class rõ ràng.
                // Lấy phần tử hình lớn gần nút download làm candidate bổ sung.
                for(const el of deep){
                    try{
                        const label=((el.innerText||'')+' '+(el.getAttribute&&el.getAttribute('aria-label')||'')+' '+(el.getAttribute&&el.getAttribute('title')||'')).toLowerCase();
                        if(!label.includes('download') && !label.includes('tải xuống') && !label.includes('save image')) continue;
                        for(const n of rootChain(el).slice(0,8)){
                            if(!n || !n.querySelectorAll) continue;
                            for(const img of Array.from(n.querySelectorAll('img,canvas,[role="img"]'))){
                                const tag=String(img.tagName||'').toLowerCase();
                                if(tag==='img') add('img',img.currentSrc||img.src||'',img,{naturalW:img.naturalWidth||0,naturalH:img.naturalHeight||0});
                                else if(tag==='canvas'){
                                    const r=img.getBoundingClientRect(); add('canvas','canvas:'+Math.round(r.left)+':'+Math.round(r.top)+':'+Math.round(r.width)+':'+Math.round(r.height),img,{naturalW:img.width||0,naturalH:img.height||0});
                                } else { const r=img.getBoundingClientRect(); add('element','element:'+Math.round(r.left)+':'+Math.round(r.top)+':'+Math.round(r.width)+':'+Math.round(r.height),img,{}); }
                            }
                        }
                    }catch(e){}
                }
                out.sort((a,b)=>(b.quality-a.quality));
                const body=(document.body&&document.body.innerText||'').toLowerCase();
                const title=(document.title||'').toLowerCase();
                const btns=deep.filter(x=>{const t=String(x.tagName||'').toLowerCase();return t==='button'||String((x.getAttribute&&x.getAttribute('role'))||'').toLowerCase()==='button';});
                const stopBtns=btns.filter(b=>{
                    const t=((b.innerText||'')+' '+(b.getAttribute&&b.getAttribute('aria-label')||'')).toLowerCase();
                    return t.includes('stop')||t.includes('dừng')||t.includes('hủy');
                }).length;
                const spinners=deep.filter(el=>{
                    try{
                        const role=String((el.getAttribute&&el.getAttribute('role'))||'').toLowerCase();
                        const cls=String(el.className||'').toLowerCase();
                        if(role!=='progressbar'&&!cls.includes('spinner')&&!cls.includes('loading')) return false;
                        const r=el.getBoundingClientRect(),s=getComputedStyle(el);
                        return s.display!=='none'&&s.visibility!=='hidden'&&r.width>8&&r.height>8;
                    }catch(e){return false;}
                }).length;
                const generatingText=['generating','creating image','creating your image','image is being created','đang tạo','đang xử lý','đang tạo hình ảnh','thinking','responding','working on it'].some(x=>body.includes(x));
                const creationLabel=['image creation','creating image','creating your image','generating image','image is being created','đang tạo hình ảnh'].some(x=>body.includes(x)||title.includes(x));
                const failurePatterns=[
                    'image generation limit reached','cannot create more images','can\'t create more images',
                    'generation failed','try another prompt','something went wrong','couldn\'t generate',
                    'could not generate','image creation is not available','image creation unavailable',
                    'bạn đã đạt đến hạn mức tạo hình ảnh','không thể tạo thêm hình ảnh','tạo hình ảnh không thành công',
                    'request denied','image editing request denied','yêu cầu tạo ảnh bị từ chối'
                ];
                const failure=failurePatterns.find(x=>body.includes(x)||title.includes(x))||'';
                const hardBusy=stopBtns>0||spinners>0||generatingText;
                return {items:out.slice(0,40),busy:hardBusy,hardBusy:hardBusy,creationLabel:creationLabel,
                    failure:failure,title:title,stopBtns:stopBtns,spinners:spinners,deepCount:deep.length};
            """) or {"items": [], "busy": False, "hardBusy": False, "creationLabel": False, "failure": ""}
        except Exception as e:
            try:
                self.ui_queue.put(("log", f"[brand-detect] lỗi quét ảnh sâu: {type(e).__name__}: {str(e)[:160]}"))
            except Exception:
                pass
            return {"items": [], "busy": False, "hardBusy": False, "creationLabel": False, "failure": ""}

    def _channel_brand_build_logo_prompt(self, channel_name, key, notes, worker_no=1, total=1, style_hint=""):
        channel_name = str(channel_name or '').strip()
        key = str(key or '').strip()
        notes = str(notes or '').strip()
        style_hint = str(style_hint or '').strip()
        return (
            "Create one finished image now.\n\n"
            f"Design a premium circular YouTube music logo for: {channel_name}\n"
            f"Music genre/topic: {key}\n"
            f"Extra conditions: {notes or 'None'}\n"
            f"Variation {worker_no}/{total}: {style_hint or 'distinct genre-accurate premium design'}\n\n"
            "Requirements:\n"
            "- Use the exact channel name only.\n"
            "- Rich, layered, detailed and professional; not plain, minimal or generic.\n"
            "- Strong genre-accurate typography, depth, highlights and relevant music symbolism.\n"
            "- Perfect round badge centered in a square 1:1 image; readable at small avatar size.\n"
            "- Outside the round badge use one completely flat solid pure magenta background #FF00FF only.\n"
            "- No transparent/checkerboard/gradient/scene outside background.\n"
            "- No extra words, artist names, people, hands, mockups, posters or watermarks.\n"
            "- Make this version clearly different from the other five.\n\n"
            "Return only the final image, no explanation."
        )

    def _channel_brand_try_make_magenta_transparent_png(self, target_path):
        try:
            target_path = Path(target_path)
            with Image.open(target_path) as im:
                im = im.convert('RGBA')
                w, h = im.size
                px = im.load()
                key = (255, 0, 255)

                def near_magenta(rgb):
                    r, g, b = [int(x) for x in rgb[:3]]
                    return abs(r - key[0]) <= 84 and abs(g - key[1]) <= 84 and abs(b - key[2]) <= 84

                from collections import deque
                q = deque()
                seen = set()
                for x in range(w):
                    q.append((x, 0)); q.append((x, h - 1))
                for y in range(h):
                    q.append((0, y)); q.append((w - 1, y))
                changed = 0
                while q:
                    x, y = q.popleft()
                    if (x, y) in seen or x < 0 or y < 0 or x >= w or y >= h:
                        continue
                    seen.add((x, y))
                    r, g, b, a = px[x, y]
                    if a == 0:
                        continue
                    if near_magenta((r, g, b)):
                        px[x, y] = (r, g, b, 0)
                        changed += 1
                        q.append((x + 1, y)); q.append((x - 1, y)); q.append((x, y + 1)); q.append((x, y - 1))
                if changed <= 0:
                    return False

                alpha = im.getchannel('A')
                bbox = alpha.getbbox()
                if bbox:
                    left, top, right, bottom = bbox
                    bw = max(1, right - left)
                    bh = max(1, bottom - top)
                    pad = max(16, int(max(bw, bh) * 0.07))
                    left = max(0, left - pad)
                    top = max(0, top - pad)
                    right = min(w, right + pad)
                    bottom = min(h, bottom + pad)
                    im = im.crop((left, top, right, bottom))
                    cw, ch = im.size
                    side = max(cw, ch)
                    canvas = Image.new('RGBA', (side, side), (0, 0, 0, 0))
                    ox = (side - cw) // 2
                    oy = (side - ch) // 2
                    canvas.alpha_composite(im, (ox, oy))
                    im = canvas
                if im.width > 1024:
                    im = im.resize((1024, 1024), Image.LANCZOS)
                elif im.width < 512:
                    im = im.resize((512, 512), Image.LANCZOS)
                im.save(target_path, 'PNG')
                return True
        except Exception:
            return False

    def _channel_brand_try_make_transparent_png(self, target_path):
        try:
            target_path = Path(target_path)
            with Image.open(target_path) as im:
                im = im.convert('RGBA')
                w, h = im.size
                px = im.load()
                # Sample edge pixels and estimate whether the edge background is mostly one flat color.
                edge = []
                for x in range(w):
                    edge.append(px[x, 0][:3]); edge.append(px[x, h - 1][:3])
                for y in range(h):
                    edge.append(px[0, y][:3]); edge.append(px[w - 1, y][:3])
                if not edge:
                    return False
                avg = tuple(int(sum(c[i] for c in edge) / len(edge)) for i in range(3))
                def dist(a, b):
                    return abs(int(a[0]) - int(b[0])) + abs(int(a[1]) - int(b[1])) + abs(int(a[2]) - int(b[2]))
                similar = sum(1 for c in edge if dist(c, avg) <= 42)
                if similar / max(1, len(edge)) < 0.68:
                    return False
                from collections import deque
                q = deque()
                seen = set()
                for x in range(w):
                    q.append((x, 0)); q.append((x, h - 1))
                for y in range(h):
                    q.append((0, y)); q.append((w - 1, y))
                while q:
                    x, y = q.popleft()
                    if (x, y) in seen or x < 0 or y < 0 or x >= w or y >= h:
                        continue
                    seen.add((x, y))
                    r, g, b, a = px[x, y]
                    if a == 0:
                        continue
                    if dist((r, g, b), avg) <= 48:
                        px[x, y] = (r, g, b, 0)
                        q.append((x + 1, y)); q.append((x - 1, y)); q.append((x, y + 1)); q.append((x, y - 1))
                im.save(target_path, 'PNG')
                return True
        except Exception:
            return False

    def _channel_brand_force_round_png(self, target_path):
        try:
            target_path = Path(target_path)
            with Image.open(target_path) as im:
                im = im.convert('RGBA')
                w, h = im.size
                side = min(w, h)
                left = max(0, (w - side) // 2)
                top = max(0, (h - side) // 2)
                im = im.crop((left, top, left + side, top + side))
                alpha = Image.new('L', (side, side), 0)
                draw = ImageDraw.Draw(alpha)
                inset = max(2, side // 64)
                draw.ellipse((inset, inset, side - inset - 1, side - inset - 1), fill=255)
                current_alpha = im.getchannel('A')
                try:
                    merged_alpha = ImageChops.multiply(current_alpha, alpha)
                except Exception:
                    merged_alpha = alpha
                im.putalpha(merged_alpha)
                im.save(target_path, 'PNG')
                return True
        except Exception:
            return False

    def _channel_brand_extract_image(self, drv, candidate, target_path):
        """v13.36: lấy file ảnh cuối trực tiếp ngay khi Gemini vẽ xong. Screenshot chỉ là fallback khẩn cấp nếu nguồn ảnh không thể đọc."""
        target_path = Path(target_path)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        candidate = dict(candidate or {})
        kind = str(candidate.get('kind') or '')
        src = str(candidate.get('src') or '')
        result = ''
        try:
            result = drv.execute_async_script(r"""
                const kind=arguments[0], src=arguments[1], done=arguments[arguments.length-1];
                function roots(){
                    const out=[document], q=[document], seen=new Set();
                    while(q.length){
                        const root=q.shift(); if(!root||seen.has(root)) continue; seen.add(root);
                        let els=[]; try{els=Array.from(root.querySelectorAll('*'));}catch(e){}
                        for(const el of els){try{if(el.shadowRoot&&!seen.has(el.shadowRoot)){out.push(el.shadowRoot);q.push(el.shadowRoot);}}catch(e){}}
                    }
                    return out;
                }
                function all(sel){const out=[];for(const r of roots()){try{out.push(...Array.from(r.querySelectorAll(sel)));}catch(e){}}return out;}
                function toData(blob){
                    const r=new FileReader(); r.onloadend=()=>done(String(r.result||'')); r.onerror=()=>done('ERROR:reader'); r.readAsDataURL(blob);
                }
                try{
                    if(kind==='canvas'){
                        const parts=src.split(':').slice(1).map(Number);
                        const cvs=all('canvas').filter(c=>{
                            const r=c.getBoundingClientRect();
                            return Math.abs(r.left-parts[0])<8 && Math.abs(r.top-parts[1])<8 && Math.abs(r.width-parts[2])<12 && Math.abs(r.height-parts[3])<12;
                        });
                        if(cvs.length){
                            try{const d=cvs[0].toDataURL('image/png');if(d&&d.startsWith('data:image/')){done(d);return;}}catch(e){}
                        }
                        done('ERROR:canvas-not-readable'); return;
                    }
                    if(kind==='img'){
                        const imgs=all('img').filter(i=>(i.currentSrc||i.src||i.getAttribute('src')||i.getAttribute('data-src')||'')===src);
                        const img=imgs[0];
                        if(img){
                            try{
                                const w=img.naturalWidth||Math.round(img.getBoundingClientRect().width), h=img.naturalHeight||Math.round(img.getBoundingClientRect().height);
                                const c=document.createElement('canvas'); c.width=Math.max(1,w); c.height=Math.max(1,h);
                                c.getContext('2d').drawImage(img,0,0,c.width,c.height);
                                const d=c.toDataURL('image/png'); if(d&&d.startsWith('data:image/')){done(d);return;}
                            }catch(e){}
                        }
                    }
                    if((kind==='img'||kind==='bg') && src){
                        const ctrl=new AbortController();
                        const timer=setTimeout(()=>{try{ctrl.abort();}catch(e){}},4500);
                        fetch(src,{credentials:'include',signal:ctrl.signal})
                            .then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.blob();})
                            .then(blob=>{clearTimeout(timer);toData(blob);})
                            .catch(e=>{clearTimeout(timer);done('ERROR:'+String(e));});
                        return;
                    }
                    done('ERROR:no-direct-extractor');
                }catch(e){done('ERROR:'+String(e));}
            """, kind, src)
        except Exception as e:
            result = 'ERROR:' + str(e)

        wrote = False
        if isinstance(result, str) and result.startswith('data:image/'):
            try:
                payload = result.split(',', 1)[1]
                target_path.write_bytes(base64.b64decode(payload))
                wrote = True
            except Exception:
                wrote = False

        if not wrote:
            # Screenshot crop là fallback quan trọng cho ảnh trong Shadow DOM/CSS background.
            try:
                shot = drv.get_screenshot_as_png()
                with Image.open(BytesIO(shot)) as screen:
                    screen = screen.convert('RGBA')
                    vw = float(drv.execute_script('return Math.max(1, window.innerWidth||document.documentElement.clientWidth||1);') or 1)
                    vh = float(drv.execute_script('return Math.max(1, window.innerHeight||document.documentElement.clientHeight||1);') or 1)
                    sx = float(screen.width) / vw
                    sy = float(screen.height) / vh
                    x = max(0.0, float(candidate.get('x') or 0.0))
                    y = max(0.0, float(candidate.get('y') or 0.0))
                    w = max(1.0, float(candidate.get('w') or 0.0))
                    h = max(1.0, float(candidate.get('h') or 0.0))
                    left = max(0, min(screen.width - 1, int(round(x * sx))))
                    top = max(0, min(screen.height - 1, int(round(y * sy))))
                    right = max(left + 1, min(screen.width, int(round((x + w) * sx))))
                    bottom = max(top + 1, min(screen.height, int(round((y + h) * sy))))
                    crop = screen.crop((left, top, right, bottom))
                    if crop.width < 80 or crop.height < 80:
                        raise RuntimeError(f'crop screenshot quá nhỏ: {crop.width}x{crop.height}')
                    crop.save(target_path, 'PNG')
                    wrote = True
                    self.ui_queue.put(("log", f"[brand-capture] dùng screenshot crop cho {kind} • {crop.width}x{crop.height}"))
            except Exception as e:
                raise RuntimeError(f"Không lấy được dữ liệu ảnh Gemini: direct={str(result)[:120]} • screenshot={e}")

        # Chuẩn hóa logo về PNG vuông, ưu tiên tách nền magenta rồi mask tròn.
        try:
            raw_path = target_path.with_name(target_path.stem + '_raw.png')
            try:
                shutil.copy2(target_path, raw_path)
            except Exception:
                pass
            with Image.open(target_path) as im:
                im = im.convert('RGBA')
                w, h = im.size
                side = min(w, h)
                left = max(0, (w - side) // 2); top = max(0, (h - side) // 2)
                im = im.crop((left, top, left + side, top + side))
                if side > 1280:
                    im = im.resize((1280, 1280), Image.LANCZOS)
                elif side < 640:
                    im = im.resize((640, 640), Image.LANCZOS)
                im.save(target_path, 'PNG')
            removed = False
            try:
                removed = bool(self._channel_brand_try_make_magenta_transparent_png(target_path))
            except Exception:
                removed = False
            if not removed:
                try:
                    self._channel_brand_try_make_transparent_png(target_path)
                except Exception:
                    pass
            try:
                self._channel_brand_force_round_png(target_path)
            except Exception:
                pass
            self._channel_brand_enforce_logo_under_1mb(target_path)
            with Image.open(target_path) as verify:
                verify.verify()
            if target_path.stat().st_size >= 1024 * 1024:
                raise RuntimeError(f"Logo sau nén vẫn vượt 1 MB: {target_path.stat().st_size / (1024*1024):.2f} MB")
            self.ui_queue.put(("log", f"[brand-logo] PNG đã chuẩn hóa dưới 1 MB • {target_path.stat().st_size / 1024:.0f} KB • {target_path.name}"))
        except Exception as e:
            raise RuntimeError(f"Ảnh logo tải về không hợp lệ: {e}")
        return target_path

    def _channel_brand_enforce_logo_under_1mb(self, target_path, max_bytes=950 * 1024):
        """Giữ logo PNG dưới 1 MB, ưu tiên chất lượng và độ trong suốt."""
        target_path = Path(target_path)
        if not target_path.is_file():
            return target_path
        try:
            if target_path.stat().st_size <= int(max_bytes):
                return target_path
        except Exception:
            pass
        temp_path = target_path.with_name(target_path.stem + "_compressed_tmp.png")
        best_path = None
        best_size = None
        try:
            with Image.open(target_path) as src:
                base = src.convert("RGBA")
                max_side_steps = (1024, 896, 768, 640, 512)
                color_steps = (256, 192, 160, 128, 96, 64)
                quantize_enum = getattr(Image, "Quantize", None)
                method = getattr(quantize_enum, "FASTOCTREE", 2) if quantize_enum is not None else 2
                dither_enum = getattr(Image, "Dither", None)
                dither_none = getattr(dither_enum, "NONE", 0) if dither_enum is not None else 0
                for max_side in max_side_steps:
                    work = base.copy()
                    if max(work.size) > max_side:
                        ratio = float(max_side) / float(max(work.size))
                        new_size = (max(1, int(round(work.width * ratio))), max(1, int(round(work.height * ratio))))
                        work = work.resize(new_size, Image.LANCZOS)
                    # Thử PNG RGBA tối ưu trước để giữ đủ màu.
                    work.save(temp_path, "PNG", optimize=True, compress_level=9)
                    size = temp_path.stat().st_size
                    if best_size is None or size < best_size:
                        best_size = size
                        best_path = temp_path.read_bytes()
                    if size <= int(max_bytes):
                        os.replace(temp_path, target_path)
                        return target_path
                    for colors in color_steps:
                        quantized = work.quantize(colors=colors, method=method, dither=dither_none)
                        quantized.save(temp_path, "PNG", optimize=True, compress_level=9)
                        size = temp_path.stat().st_size
                        if best_size is None or size < best_size:
                            best_size = size
                            best_path = temp_path.read_bytes()
                        if size <= int(max_bytes):
                            os.replace(temp_path, target_path)
                            return target_path
            if best_path:
                target_path.write_bytes(best_path)
            if target_path.stat().st_size > int(max_bytes):
                # Fallback cuối: 512px/48 màu vẫn đủ rõ cho avatar và chắc chắn rất nhẹ.
                with Image.open(target_path) as src:
                    work = src.convert("RGBA")
                    if max(work.size) > 512:
                        ratio = 512.0 / float(max(work.size))
                        work = work.resize((max(1, int(work.width * ratio)), max(1, int(work.height * ratio))), Image.LANCZOS)
                    quantized = work.quantize(colors=48, method=method, dither=dither_none)
                    quantized.save(target_path, "PNG", optimize=True, compress_level=9)
            return target_path
        finally:
            try:
                temp_path.unlink(missing_ok=True)
            except Exception:
                pass

    def _channel_brand_generate_logo(self, channel_name, key, notes, status_cb=None):
        with self._channel_brand_lock:
            drv = None; run_root = None
            try:
                cb = status_cb or (lambda _x: None)
                drv, acc, run_root = self._channel_brand_session(cb)
                cb("Đang mở cuộc trò chuyện tạo logo…")
                try:
                    drv.get("https://gemini.google.com/app")
                    time.sleep(0.8)
                except Exception:
                    pass
                if not self._description_wait_editor_ready(drv, timeout=28):
                    raise RuntimeError("Gemini chưa sẵn sàng ô nhập để tạo logo")
                self._channel_brand_prepare_pro_image_mode(drv, 0, acc)
                baseline = {str(x.get('signature') or x.get('src') or '') for x in (self._channel_brand_image_state(drv).get('items') or [])}
                prompt = self._channel_brand_build_logo_prompt(
                    channel_name=channel_name,
                    key=key,
                    notes=notes,
                    worker_no=1,
                    total=1,
                    style_hint="a strong genre-accurate avatar treatment that matches the channel topic and mood",
                )
                cb("Đang gửi yêu cầu tạo logo bằng Pro + Create image…")
                self._channel_brand_send_prompt_confirm(drv, prompt, channel_name, 0, acc)
                cb("Gemini đã nhận prompt và đang tạo logo…")
                end = time.time() + float(os.environ.get("GEMINI_BRAND_LOGO_TIMEOUT", "180") or 180)
                selected = None; stable_since = 0.0; last_src = ''
                while time.time() < end and not self._channel_brand_stop_event.is_set():
                    state = self._channel_brand_image_state(drv)
                    candidates = [x for x in (state.get('items') or []) if str(x.get('signature') or x.get('src') or '') not in baseline or (str(x.get('kind') or '') == 'element' and bool(x.get('response')))]
                    candidates.sort(key=lambda x: (1 if x.get('response') else 0, float(x.get('area') or 0)), reverse=True)
                    cand = candidates[0] if candidates else None
                    if cand:
                        src = str(cand.get('signature') or cand.get('src') or '')
                        if src != last_src:
                            last_src = src; stable_since = time.time(); selected = cand
                        elif not state.get('busy') and (time.time() - stable_since) >= 2.0:
                            selected = cand
                            break
                    time.sleep(0.55)
                if not selected:
                    raise RuntimeError("Gemini chưa trả về ảnh logo trong thời gian chờ")
                safe_name = self._channel_brand_sanitize_name(channel_name)
                out_dir = self._channel_brand_output_root() / safe_name
                out_path = out_dir / "logo.png"
                cb("Đang tải và lưu logo…")
                self._channel_brand_extract_image(drv, selected, out_path)
                meta = {
                    "version": APP_VERSION,
                    "channel_name": channel_name,
                    "key": key,
                    "notes": notes,
                    "account": acc,
                    "created_at": datetime.now().isoformat(),
                    "logo": str(out_path),
                }
                (out_dir / "logo_info.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
                self.ui_queue.put(("log", f"[brand] A{acc} tạo logo xong • {out_path}"))
                return out_path
            finally:
                if run_root is not None:
                    self._channel_brand_finish_session(drv, run_root)

    def _channel_brand_generate_logos(self, channel_name, key, notes, count=6, status_cb=None, progress_cb=None):
        """Chạy 6 luồng tạo logo song song; giao diện hiển thị 4 logo để chọn."""
        with self._channel_brand_lock:
            if self.running or self.desc_running or self.queue_running:
                raise RuntimeError("Tool đang chạy Queue hoặc Sửa mô tả. Hãy đợi hoàn tất rồi tạo logo.")
            cb = status_cb or (lambda _x: None)
            pc = progress_cb or (lambda _slot, _path: None)
            requested = max(1, int(count or 6))
            target_success = min(4, requested)
            self._channel_brand_stop_event.clear()
            self.desc_stop_event.clear()
            self._description_prepare_local_browser_runtime()
            reserve_count = min(10, requested + 2)
            account_pairs = self._channel_brand_pick_accounts(reserve_count, status_cb=cb)
            account_numbers = [int(x[0]) for x in account_pairs]
            self.ui_queue.put(("log", "[brand-pool] dùng pool Thumbnail + account dự phòng • " + ",".join(f"A{x}" for x in account_numbers)))

            local_base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or str(self.backend_dir))
            run_root = local_base / "ToolThumbnail" / "brand_runs" / ("parallel_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            run_root.mkdir(parents=True, exist_ok=True)
            safe_name = self._channel_brand_sanitize_name(channel_name)
            out_dir = self._channel_brand_output_root() / safe_name
            out_dir.mkdir(parents=True, exist_ok=True)
            style_hints = [
                "premium layered badge with dense detail, bold typography, and a powerful music-first identity that accurately reflects the genre/topic",
                "modern high-end music avatar with richer composition, more visual depth, and strong readable lettering matched to the channel mood",
                "dynamic high-contrast emblem with polished texture, genre-accurate iconography, and a more luxurious finished look",
                "clean but premium circular logo with stronger decorative depth, refined typography hierarchy, and richer material treatment",
                "eye-catching avatar with layered visual detail, deeper styling, stronger centerpiece icon, and a distinct music identity",
                "decorative retro or vintage-inspired emblem with richer ornament, thicker structure, and premium detail while staying on-theme",
            ]

            def _one_logo(worker_no, account_no):
                drv = None
                session_profile = run_root / f"worker_{worker_no}_A{account_no}"
                try:
                    self.ui_queue.put(("log", f"[brand-W{worker_no}] A{account_no} bắt đầu logo {worker_no}/{requested}"))
                    self._description_prepare_profile_clone(account_no, session_profile, wid=f"BRAND{worker_no}")
                    drv = self._description_open_driver(account_no, session_profile)
                    try:
                        drv.get("https://gemini.google.com/app")
                        time.sleep(0.8)
                    except Exception:
                        pass
                    if not self._description_wait_editor_ready(drv, timeout=28):
                        raise RuntimeError("Gemini chưa sẵn sàng ô nhập để tạo logo")
                    self._channel_brand_prepare_pro_image_mode(drv, worker_no, account_no)
                    baseline = {str(x.get('signature') or x.get('src') or '') for x in (self._channel_brand_image_state(drv).get('items') or [])}
                    prompt = self._channel_brand_build_logo_prompt(
                        channel_name=channel_name,
                        key=key,
                        notes=notes,
                        worker_no=worker_no,
                        total=requested,
                        style_hint=style_hints[(worker_no - 1) % len(style_hints)],
                    )
                    try:
                        (out_dir / f"logo_{worker_no}_prompt.txt").write_text(prompt, encoding='utf-8')
                    except Exception:
                        pass
                    self._channel_brand_send_prompt_confirm(drv, prompt, channel_name, worker_no, account_no)
                    attempt_timeout = float(os.environ.get("GEMINI_BRAND_LOGO_TIMEOUT", "135") or 135)
                    end_time = time.time() + attempt_timeout
                    selected = None
                    stable_since = 0.0
                    last_src = ""
                    started_wait = time.time()
                    static_creation_since = 0.0
                    last_state_log = 0.0
                    while time.time() < end_time and not self._channel_brand_stop_event.is_set():
                        state = self._channel_brand_image_state(drv)
                        failure = str(state.get('failure') or '').strip()
                        if failure:
                            raise RuntimeError(f"Gemini báo lỗi tạo ảnh: {failure}")
                        candidates = [x for x in (state.get('items') or []) if str(x.get('signature') or x.get('src') or '') not in baseline or (str(x.get('kind') or '') == 'element' and bool(x.get('response')))]
                        candidates.sort(key=lambda x: (1 if x.get('response') else 0, float(x.get('area') or 0)), reverse=True)
                        cand = candidates[0] if candidates else None
                        if cand:
                            static_creation_since = 0.0
                            src = str(cand.get('signature') or cand.get('src') or '')
                            if src != last_src:
                                last_src = src
                                stable_since = time.time()
                                selected = cand
                            natural_ok = int(cand.get('naturalW') or 0) >= 512 and int(cand.get('naturalH') or 0) >= 512
                            area_ok = float(cand.get('area') or 0) >= 100000
                            direct_kind = str(cand.get('kind') or '') in ('img', 'bg', 'canvas')
                            stable_for = time.time() - stable_since
                            # Không tạo preview screenshot. Khi ảnh nguồn thật đã sẵn sàng, lấy file ngay.
                            # Worker này tải/lưu độc lập; các Chrome khác vẫn tiếp tục tạo song song.
                            if direct_kind and (natural_ok or area_ok) and stable_for >= 0.18:
                                selected = cand
                                break
                            if (not state.get('hardBusy')) and stable_for >= 0.30:
                                selected = cand
                                break
                        else:
                            if state.get('creationLabel') and not state.get('hardBusy'):
                                if static_creation_since <= 0:
                                    static_creation_since = time.time()
                                elif (time.time() - static_creation_since) >= 38.0:
                                    raise RuntimeError("Gemini bị kẹt ở màn Image creation, chuyển account cứu hộ")
                            else:
                                static_creation_since = 0.0
                        if time.time() - last_state_log >= 20.0:
                            last_state_log = time.time()
                            elapsed = int(time.time() - started_wait)
                            
                            kinds = ','.join(sorted({str(x.get('kind') or '?') for x in (state.get('items') or [])})) or '-'
                            self.ui_queue.put(("log", f"[brand-W{worker_no}] A{account_no} đang chờ ảnh • {elapsed}s • deep={int(state.get('deepCount') or 0)} • candidates={len(state.get('items') or [])} ({kinds}) • ImageCreation={bool(state.get('creationLabel'))} • busy={bool(state.get('hardBusy'))}"))
                        time.sleep(0.55)
                    if not selected:
                        raise RuntimeError(f"Gemini chưa trả về ảnh logo sau {int(attempt_timeout)} giây")
                    out_path = out_dir / f"logo_{worker_no}.png"
                    extract_started = time.time()
                    self.ui_queue.put(("log", f"[brand-W{worker_no}] A{account_no} ảnh đã vẽ xong • đang lấy file gốc ngay"))
                    self._channel_brand_extract_image(drv, selected, out_path)
                    elapsed_extract = time.time() - extract_started
                    try:
                        pc(int(worker_no), str(out_path))
                    except Exception:
                        pass
                    self.ui_queue.put(("log", f"[brand-W{worker_no}] A{account_no} OK + đã tải file cuối và hiện ngay lên tool • {elapsed_extract:.1f}s • {out_path}"))
                    return worker_no, account_no, out_path, ""
                except Exception as e:
                    msg = str(e)
                    low = msg.lower()
                    if ('không bật được chế độ tạo ảnh' in low or 'model pro' in low or 'create image' in low or 'flash-lite' in low):
                        msg = 'MODE_UNSUPPORTED • ' + msg
                    elif 'something went wrong' in low:
                        msg = 'GEMINI_TRANSIENT • ' + msg
                    self.ui_queue.put(("log", f"[brand-W{worker_no}] A{account_no} ERROR • {type(e).__name__}: {msg}"))
                    return worker_no, account_no, None, msg
                finally:
                    try:
                        self._description_close_driver_fast(drv, reason=f"Brand W{worker_no}/A{account_no} kết thúc", timeout=0.35)
                    except Exception:
                        pass
                    try:
                        shutil.rmtree(session_profile, ignore_errors=True)
                    except Exception:
                        pass

            cb("Đang chạy 6 luồng song song. Logo nào xong trước sẽ hiện ngay lên tool, đồng thời tool vẫn tiếp tục lưu đủ 6 logo…")
            results_by_index = {}
            failures = []
            bad_mode_accounts = set()
            slot_account_history = {i: set() for i in range(1, requested + 1)}
            max_rounds = 3
            try:
                round_no = 1
                while round_no <= max_rounds and len(results_by_index) < requested and not self._channel_brand_stop_event.is_set():
                    missing_slots = [i for i in range(1, requested + 1) if i not in results_by_index]
                    if not missing_slots:
                        break
                    if round_no == 1:
                        self.ui_queue.put(("log", f"[brand] chạy vòng chính để tạo {len(missing_slots)} logo"))
                    else:
                        self.ui_queue.put(("log", f"[brand] chạy vòng cứu hộ {round_no - 1} cho {len(missing_slots)} logo còn thiếu • bỏ account không có Pro/Create image"))
                    cb(f"Vòng {round_no}/{max_rounds}: đang tạo {len(missing_slots)} logo còn thiếu…")
                    with ThreadPoolExecutor(max_workers=min(requested, len(missing_slots)), thread_name_prefix=f"BrandLogoR{round_no}") as pool:
                        futures = []
                        used_this_round = set()
                        for pos, worker_no in enumerate(missing_slots):
                            eligible = [a for a in account_numbers if a not in bad_mode_accounts and a not in slot_account_history.get(worker_no, set()) and a not in used_this_round]
                            if not eligible:
                                eligible = [a for a in account_numbers if a not in bad_mode_accounts and a not in used_this_round]
                            if not eligible:
                                eligible = [a for a in account_numbers if a not in used_this_round] or list(account_numbers)
                            account_no = eligible[(worker_no + round_no + pos - 2) % len(eligible)]
                            used_this_round.add(account_no)
                            slot_account_history.setdefault(worker_no, set()).add(account_no)
                            futures.append(pool.submit(_one_logo, worker_no, account_no))
                        completed = 0
                        for fut in as_completed(futures):
                            worker_no, account_no, out_path, error = fut.result()
                            completed += 1
                            if out_path is not None:
                                results_by_index[int(worker_no)] = Path(out_path)
                            elif error:
                                failures.append(f"Vòng {round_no} • Logo {worker_no}/A{account_no}: {error}")
                                if str(error).startswith('MODE_UNSUPPORTED'):
                                    bad_mode_accounts.add(int(account_no))
                                    self.ui_queue.put(("log", f"[brand-pool] loại A{account_no} khỏi các vòng sau vì không xác nhận được Pro/Create image"))
                            cb(f"Vòng {round_no}: xong {completed}/{len(missing_slots)} • đã lưu {len(results_by_index)}/{requested} logo")
                    if len(results_by_index) >= requested:
                        break
                    round_no += 1
            finally:
                try:
                    shutil.rmtree(run_root, ignore_errors=True)
                except Exception:
                    pass
                try:
                    self._desc_profile_prune_guard = False
                except Exception:
                    pass

            results = [str(results_by_index.get(i) or "") for i in range(1, requested + 1)]
            if not any(results):
                raise RuntimeError("Không tạo được logo nào. " + (" | ".join(failures[:3]) if failures else "") + " • Gợi ý: kiểm tra tài khoản Gemini, model Create image/Pro, hoặc chạy lại để dùng account khác.")
            meta = {
                "version": APP_VERSION,
                "channel_name": channel_name,
                "key": key,
                "notes": notes,
                "accounts": account_numbers,
                "parallel_workers": requested,
                "preview_display_count": 4,
                "race_target_success": target_success,
                "all_workers_continue_after_preview": True,
                "created_at": datetime.now().isoformat(),
                "logos": [str(x) for x in results],
                "failures": failures,
                "bad_mode_accounts": sorted(bad_mode_accounts),
            }
            (out_dir / "logo_info.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
            success_count = sum(1 for x in results if x)
            self.ui_queue.put(("log", f"[brand] tạo song song xong {success_count}/{requested} logo • {out_dir}"))
            return results

    def _update_theme_button(self):
        try:
            if hasattr(self, "theme_btn"):
                self.theme_btn.setText("☀️ Sáng" if getattr(self, "_theme_mode", "dark") == "dark" else "🌙 Tối")
        except Exception:
            pass

    def _toggle_theme(self):
        self._theme_mode = "light" if getattr(self, "_theme_mode", "dark") == "dark" else "dark"
        self._apply_style()
        self._update_theme_button()
        self.schedule_save_state()

    def _apply_style(self):
        if getattr(self, "_theme_mode", "dark") == "light":
            self.setStyleSheet("""
            QMainWindow, QWidget { background:#f3f7fc; color:#172033; font-family:'Segoe UI'; font-size:8.6pt; }
            QGroupBox { background:#ffffff; border:1px solid #a9b9cc; border-radius:10px; margin-top:11px; font-weight:800; color:#0f172a; }
            QGroupBox::title { subcontrol-origin: margin; left:14px; padding:0 7px; color:#0f172a; }
            #SideBar { background:#f8fbff; border:1px solid #d5e1ef; border-radius:12px; }
            #AppBrand { background:transparent; border:0; }
            #AppMark { background:#2563eb; color:#ffffff; border-radius:11px; font-size:10pt; font-weight:900; }
            #AppName { color:#1d4ed8; font-size:10pt; font-weight:900; }
            #AppVersion { color:#6b7f96; font-size:7.5pt; font-weight:700; }
            #NavSection { color:#7b8ea5; font-size:7.5pt; font-weight:900; padding:8px 8px 2px 8px; letter-spacing:1px; }
            QPushButton#NavButton { background:transparent; color:#52667e; border:0; border-radius:8px; padding:8px 11px; text-align:left; font-size:8.7pt; font-weight:700; }
            QPushButton#NavButton:hover { background:#eaf2ff; color:#1d4ed8; }
            QPushButton#NavButton:checked { background:#dbeafe; color:#1d4ed8; border-left:3px solid #2563eb; padding-left:8px; font-weight:900; }
            QPushButton#NavActionButton { background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; border-radius:8px; padding:8px 11px; text-align:left; font-size:8.5pt; font-weight:900; }
            QPushButton#NavActionButton:hover { background:#dbeafe; border-color:#60a5fa; }
            QPushButton#NavActionButton:pressed { background:#bfdbfe; }
            #ThumbSidePanel { background:#ffffff; border:1px solid #d7e3f1; border-radius:12px; }
            #ThumbSidePanel QGroupBox { background:#f8fbff; border:1px solid #dce7f3; border-radius:9px; margin-top:10px; font-size:7.7pt; color:#52667e; }
            #ThumbSidePanel QGroupBox::title { subcontrol-origin:margin; left:9px; padding:0 5px; color:#6b7f96; font-size:7.7pt; font-weight:900; }
            #ThumbSidePanel QLabel { font-size:8pt; }
            #ThumbSidePanel QLineEdit, #ThumbSidePanel QSpinBox, #ThumbSidePanel QComboBox { background:#ffffff; color:#172033; border:1px solid #cbd9e8; border-radius:7px; padding:5px 7px; font-size:8pt; }
            #ThumbSidePanel QPushButton { border-radius:7px; padding:5px 7px; font-size:8pt; min-height:20px; }
            #ThumbSidePanel #StatusPill { background:#eef6ff; color:#263a52; border:1px solid #cbd9e8; border-radius:8px; padding:5px 7px; }
            #ThumbSidePanel #StatCard { background:#ffffff; border:1px solid #d4e0ed; border-radius:9px; }
            #ThumbSidePanel #CardTitle { color:#6b7f96; font-size:7.2pt; }
            #ThumbSidePanel #CardValue { color:#1e3a5f; font-size:12pt; }
            #ThumbSidePanel #RuntimeValue { color:#1e3a5f; background:#ffffff; border:1px solid #cbd9e8; border-radius:8px; font-size:14pt; padding:5px 7px; }
            #ThumbSidePanel #ProxyBox { background:#f8fbff; border:1px solid #dce7f3; border-radius:9px; }
            #ThumbnailContentHost { background:transparent; border:0; }
            #WorkspaceStack, #ThumbnailWorkspace, #BrandPage, #BrandWorkspace, #DescriptionPage { background:transparent; border:0; }
            #WorkspaceHeader { background:#ffffff; border:1px solid #d7e3f1; border-radius:10px; }
            #WorkspaceTitle { color:#17365d; font-size:13pt; font-weight:900; }
            #WorkspaceSubtitle { color:#71849a; font-size:8.3pt; }
            #DescToolbar { background:#ffffff; border:1px solid #d7e3f1; border-radius:10px; }
            #DescStatChip { background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; border-radius:8px; padding:5px 8px; font-size:8pt; font-weight:900; }
            #DescStatusText { color:#64748b; font-size:8pt; font-weight:800; }
            #DescPathLabel { background:#f8fbff; color:#334155; border:1px solid #d4e0ed; border-radius:7px; padding:6px 8px; font-size:8pt; }
            #DescTree { background:#ffffff; alternate-background-color:#f6f9fd; border:1px solid #d4e0ed; border-radius:9px; }
            #DescTree::item { min-height:28px; padding:3px 4px; }
            #DescTree::item:selected { background:#dbeafe; color:#1d4ed8; }
            QPushButton#PrimaryAction { background:#2563eb; color:#ffffff; border:1px solid #1d4ed8; border-radius:8px; padding:7px 12px; font-weight:900; }
            QPushButton#PrimaryAction:hover { background:#3b82f6; }
            QPushButton#SecondaryAction { background:#ffffff; color:#1d4ed8; border:1px solid #93c5fd; border-radius:8px; padding:7px 12px; font-weight:800; }
            QPushButton#NameCopyButton { background:#eff6ff; color:#1d4ed8; border:1px solid #93c5fd; border-radius:8px; padding:6px 9px; font-weight:900; }
            QPushButton#NameCopyButton:hover { background:#dbeafe; border-color:#60a5fa; }
            QPushButton#NameCopyButton:disabled { background:#f3f6fa; color:#a1afc0; border-color:#d7e1ec; }
            #BrandNameCard { background:transparent; border:0; }
            #BrandPreviewCard { background:#f8fbff; border:1px solid #cfdded; border-radius:12px; }
            #BrandSelectedBar { background:#eef6ff; border:1px solid #bfdbfe; border-radius:9px; }
            #BrandSelectedCaption { color:#6b7f96; font-size:7.3pt; font-weight:900; }
            #BrandSelectedName { color:#17365d; font-size:9.2pt; font-weight:900; }
            #BrandPreviewBadge { background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; border-radius:9px; padding:4px 8px; font-size:7.6pt; font-weight:900; }
            #BrandPreviewMeta { color:#5f738a; font-size:7.6pt; font-weight:700; padding-top:1px; }
            QToolButton#LogoCornerAction { background:#ffffff; color:#1d4ed8; border:1px solid #bfdbfe; border-radius:14px; font-size:9pt; font-weight:900; padding:0; }
            QToolButton#LogoCornerAction:hover { background:#dbeafe; border-color:#60a5fa; }
            QToolButton#LogoCornerAction:disabled { background:#f4f7fb; color:#b4c1d0; border-color:#d8e1eb; }
            #LogoPoolChip { background:#f3f7fc; color:#52667e; border:1px solid #d4e0ed; border-radius:8px; padding:5px 8px; font-weight:800; }
            #BrandNamesList { background:#ffffff; border:1px solid #d4e0ed; border-radius:9px; padding:4px; }
            #BrandNamesList::item { padding:8px 9px; margin:2px; border-radius:6px; }
            #BrandNamesList::item:selected { background:#dbeafe; color:#1d4ed8; }
            #TopTools { background:#e4edf8; border:1px solid #9fb2c9; border-radius:11px; }
            #MenuButton { background:#ffffff; border:1px solid #7f97b2; min-width:92px; }
            #BrandTitle { font-size:15pt; font-weight:900; color:#0f172a; padding:5px; }
            #BrandPreview { background:#f8fafc; border:1px dashed #93a9c1; border-radius:14px; color:#475569; }
            #SideTitle { font-size:11pt; font-weight:900; color:#0f172a; padding-left:4px; }
            #ControlHint { background:#eef6ff; color:#0f172a; border:1px solid #bfdbfe; border-radius:9px; padding:5px 6px; font-size:8pt; font-weight:900; }
            #ControlNote { color:#475569; font-size:8pt; font-weight:700; padding-top:1px; }
            #SavePill { background:#e11d48; color:white; border:1px solid #fb7185; border-radius:11px; font-weight:900; font-size:8pt; padding:0; }
            #SideFooter { background:#ffffff; border:1px solid #93a9c1; border-radius:10px; color:#0f172a; font-weight:900; min-height:24px; }
            #ProxyBox { background:#ffffff; border:1px solid #a9b9cc; border-radius:14px; }
            #ProxyTitle { color:#64748b; font-weight:800; font-size:9pt; }
            #ProxyState { color:#64748b; font-weight:800; font-size:8.8pt; padding-left:4px; }
            #ProxyState[active="true"] { color:#15803d; }
            QPushButton#ProxySwitch { background:#cbd5e1; border:0; border-radius:11px; color:#ffffff; font-size:11pt; font-weight:900; padding-right:15px; }
            QPushButton#ProxySwitch[active="true"] { background:#86efac; color:#ffffff; padding-left:15px; padding-right:0px; }
            #LogToggle { background:#0f8f83; border:1px solid #35d0c4; border-radius:12px; color:white; font-weight:900; min-height:26px; font-size:8.5pt; padding:3px 7px; }
            #RuntimeValue { color:#0f172a; font-size:17pt; font-weight:900; background:#ffffff; border:1px solid #9fb2c9; border-radius:10px; padding:7px 8px; }
            #SmallMuted, .QLabel#SmallMuted { color:#475569; font-size:9pt; }
            #StatusPill { color:#0f172a; font-weight:900; background:#ffffff; border:1px solid #9fb2c9; border-radius:10px; padding:7px 10px; }
            #StatusPillMini { color:#0f172a; font-weight:900; background:#edf6ff; border:1px solid #9bb7d4; border-radius:8px; padding:5px 8px; }
            #TrackHero { background:#f4f8fd; border:1px solid #a7b9cd; border-radius:12px; }
            #TrackChip { color:#0f172a; background:#ffffff; border:1px solid #9fb2c9; border-radius:10px; padding:5px 8px; font-weight:900; font-size:8.8pt; }
            #WorkerCard { background:#ffffff; border:1px solid #9fb2c9; border-radius:13px; }
            #WorkerCardTitle { color:#0f172a; font-weight:900; font-size:10pt; }
            #WorkerCardSub { color:#334155; font-weight:800; font-size:8.5pt; }
            #WorkerStatusBadge { background:#dbeafe; color:#0f172a; border:1px solid #93c5fd; border-radius:8px; padding:3px 7px; font-weight:900; font-size:8.5pt; }
            #FieldBlock { background:transparent; border:0; }
            #FieldLabel { color:#334155; font-weight:800; font-size:9.5pt; }
            #StatCard { background:#ffffff; border:1px solid #a9b9cc; border-radius:14px; }
            #CardTitle { color:#334155; font-weight:800; font-size:8pt; }
            #CardValue { color:#0f172a; font-size:16pt; font-weight:900; }
            #AccountRow { background:#f8fafc; border:1px solid #a9b9cc; border-radius:12px; }
            #AccountTitle { color:#0f172a; font-weight:900; }
            #AccountStatus, #AccountEmail { color:#0f172a; background:#ffffff; border:1px solid #a9b9cc; border-radius:8px; padding:6px 8px; }
            QLineEdit, QSpinBox, QComboBox { background:#ffffff; color:#0f172a; border:1px solid #9fb2c9; border-radius:8px; padding:6px 8px; selection-background-color:#60a5fa; }\n            QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border:1px solid #2563eb; background:#f8fbff; }
            QPushButton { background:#e2ebf7; color:#0f172a; border:1px solid #9fb2c9; border-radius:8px; padding:6px 10px; font-weight:900; }
            QPushButton:hover { background:#d6e4f3; border-color:#60a5fa; }
            QPushButton#AccentButton { background:#60a5fa; color:#07111f; border-color:#2563eb; }
            QPushButton#LoginButton { background:#16a34a; border-color:#15803d; color:#ffffff; }
            QPushButton#CheckButton { background:#2563eb; border-color:#1d4ed8; color:#ffffff; }
            QPushButton#DangerButton { background:#dc2626; border-color:#b91c1c; color:#fff; }
            QPushButton#WarnButton { background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #f59e0b, stop:1 #d97706); border:1px solid #b45309; color:#fff; border-radius:12px; padding:7px 12px; }\n            QFrame#JobCard QPushButton#WarnButton { font-size:9pt; min-height:28px; padding:5px 10px; }
            QPushButton#MoveButton { background:#ffffff; color:#0f172a; border:1px solid #9fb2c9; border-radius:8px; padding:3px; font-size:12pt; font-weight:900; }
            QScrollArea, QListWidget, QPlainTextEdit, #WorkerCardsScroll, #QueueCardsScroll { background:#f8fafc; border:1px solid #a9b9cc; border-radius:11px; color:#0f172a; }
            #QueueCard { background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #ffffff, stop:1 #f3f8ff); border:1px solid #9fb3cc; border-radius:18px; }
            QFrame#QueueCard[empty="true"] { background:#f8fafc; border:1px dashed #94a3b8; }
            #QueueAddButton { background:#e2ebf7; color:#2563eb; border:1px dashed #60a5fa; border-radius:16px; font-size:22pt; font-weight:900; padding:2px 8px; }
            #QueueDeleteButton { background:#fee2e2; color:#991b1b; border:1px solid #fca5a5; border-radius:9px; padding:1px; font-size:10pt; font-weight:900; }
            QFrame#QueueCard[selected="true"] { border:2px solid #2563eb; background:#eff6ff; }
            QFrame#QueueCard[active="true"] { border:2px solid #22c55e; background:#ecfdf5; }
            #QueueCardTitle { color:#0f172a; font-weight:900; font-size:10pt; }
            #QueueBadge { background:#dbeafe; color:#0f172a; border:1px solid #93c5fd; border-radius:8px; padding:2px 6px; font-weight:900; font-size:8pt; }
            #QueueMiniLabel { color:#334155; font-weight:900; font-size:8.5pt; }
            #QueueMiniEdit { padding:5px 7px; font-size:8.5pt; border-radius:8px; }
            #QueueMiniButton { padding:3px 5px; font-size:8.5pt; border-radius:8px; }
            #QueueStats { color:#334155; font-weight:900; font-size:8.5pt; }
            QListWidget { padding:8px 4px; }
            QListWidget::item { background:transparent; border:0; padding:0; margin:4px; }
            QFrame#JobCard { background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #ffffff, stop:1 #f4f8ff); border:1px solid #9fb3cc; border-radius:20px; }
            QFrame#JobCard[status="running"] { background:#eff6ff; border:2px solid #60a5fa; }
            QFrame#JobCard[status="done"] { background:#ecfdf5; border:1px solid #22c55e; }
            QFrame#JobCard[status="error"] { background:#fff1f2; border:1px solid #ef4444; }
            QFrame#JobCard[status="skipped"] { background:#fff7ed; border:1px solid #fb923c; }
            QFrame#JobCard[status="reserved"] { background:#fefce8; border:1px solid #facc15; }
            QFrame#JobCard[selected="true"] { border:2px solid #2563eb; background:#eaf2ff; }
            QCheckBox#JobSelectCheck { color:#1d4ed8; font-weight:900; font-size:8pt; padding:0; }
            QLabel#JobThumb { background:#eef4fb; border:1px solid #b7c7da; border-radius:15px; }
            QLabel#JobTitle { color:#0f172a; font-weight:900; font-size:9.5pt; }
            QLabel#JobSub { color:#334155; font-weight:700; font-size:8.5pt; }
            QLabel#JobChip { color:#0f172a; background:#e2ebf7; border:1px solid #9fb2c9; border-radius:10px; padding:4px 8px; font-weight:900; font-size:8.5pt; }
            QProgressBar { background:#e2e8f0; border:1px solid #94a3b8; border-radius:7px; height:9px; text-align:center; color:#0f172a; font-size:7pt; }
            QProgressBar::chunk { background:#60a5fa; border-radius:6px; }
            QScrollBar:vertical { background:#e2e8f0; width:14px; margin:0; }
            QScrollBar::handle:vertical { background:#94a3b8; min-height:28px; border-radius:7px; }
            QScrollBar:horizontal { background:#e2e8f0; height:14px; margin:0; }
            QScrollBar::handle:horizontal { background:#94a3b8; min-width:28px; border-radius:7px; }
            """)
            return
        self.setStyleSheet(f"""
            QMainWindow, QWidget {{ background:{BG}; color:{FG}; font-family:'Segoe UI'; font-size:8.6pt; }}
            QGroupBox {{
                background:{PANEL}; border:1px solid {BORDER}; border-radius:10px;
                margin-top:11px; font-weight:800; color:{FG};
            }}
            QGroupBox::title {{ subcontrol-origin: margin; left:14px; padding:0 7px; color:{FG}; }}
            #Hero {{ background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #263a5a, stop:.55 #18263d, stop:1 #111827); border:1px solid #52647d; border-radius:18px; }}

            #SideBar {{ background:#0b1220; border:1px solid #27344a; border-radius:12px; }}
            #AppBrand {{ background:transparent; border:0; }}
            #AppMark {{ background:#2563eb; color:#ffffff; border-radius:11px; font-size:10pt; font-weight:900; }}
            #AppName {{ color:#dbeafe; font-size:10pt; font-weight:900; }}
            #AppVersion {{ color:#7f93aa; font-size:7.5pt; font-weight:700; }}
            #NavSection {{ color:#6f839d; font-size:7.5pt; font-weight:900; padding:8px 8px 2px 8px; letter-spacing:1px; }}
            QPushButton#NavButton {{ background:transparent; color:#a9bad0; border:0; border-radius:8px; padding:8px 11px; text-align:left; font-size:8.7pt; font-weight:700; }}
            QPushButton#NavButton:hover {{ background:#13233b; color:#dbeafe; }}
            QPushButton#NavButton:checked {{ background:#163052; color:#dbeafe; border-left:3px solid #3b82f6; padding-left:8px; font-weight:900; }}
            QPushButton#NavActionButton {{ background:#102540; color:#bfdbfe; border:1px solid #315f91; border-radius:8px; padding:8px 11px; text-align:left; font-size:8.5pt; font-weight:900; }}
            QPushButton#NavActionButton:hover {{ background:#16365d; border-color:#60a5fa; color:#ffffff; }}
            QPushButton#NavActionButton:pressed {{ background:#1e4b80; }}
            #ThumbSidePanel {{ background:#0d1524; border:1px solid #27344a; border-radius:12px; }}
            #ThumbSidePanel QGroupBox {{ background:#111c2d; border:1px solid #2d3b52; border-radius:9px; margin-top:10px; font-size:7.7pt; color:#cbd8e8; }}
            #ThumbSidePanel QGroupBox::title {{ subcontrol-origin:margin; left:9px; padding:0 5px; color:#8fa4bc; font-size:7.7pt; font-weight:900; }}
            #ThumbSidePanel QLabel {{ font-size:8pt; }}
            #ThumbSidePanel QLineEdit, #ThumbSidePanel QSpinBox, #ThumbSidePanel QComboBox {{ background:#0d1626; color:#edf5ff; border:1px solid #384760; border-radius:7px; padding:5px 7px; font-size:8pt; }}
            #ThumbSidePanel QPushButton {{ border-radius:7px; padding:5px 7px; font-size:8pt; min-height:20px; }}
            #ThumbSidePanel #StatusPill {{ background:#17263d; color:#e7f1ff; border:1px solid #3b506c; border-radius:8px; padding:5px 7px; }}
            #ThumbSidePanel #StatCard {{ background:#151f31; border:1px solid #344159; border-radius:9px; }}
            #ThumbSidePanel #CardTitle {{ color:#8fa4bc; font-size:7.2pt; }}
            #ThumbSidePanel #CardValue {{ color:#edf5ff; font-size:12pt; }}
            #ThumbSidePanel #RuntimeValue {{ color:#edf5ff; background:#0d1626; border:1px solid #384760; border-radius:8px; font-size:14pt; padding:5px 7px; }}
            #ThumbSidePanel #ProxyBox {{ background:#111c2d; border:1px solid #2d3b52; border-radius:9px; }}
            #ThumbnailContentHost {{ background:transparent; border:0; }}
            #WorkspaceStack, #ThumbnailWorkspace, #BrandPage, #BrandWorkspace, #DescriptionPage {{ background:transparent; border:0; }}
            #WorkspaceHeader {{ background:#111827; border:1px solid #303b50; border-radius:10px; }}
            #WorkspaceTitle {{ color:#eaf3ff; font-size:13pt; font-weight:900; }}
            #WorkspaceSubtitle {{ color:#8fa4bc; font-size:8.3pt; }}
            #DescToolbar {{ background:#111827; border:1px solid #303b50; border-radius:10px; }}
            #DescStatChip {{ background:#102540; color:#bfdbfe; border:1px solid #315f91; border-radius:8px; padding:5px 8px; font-size:8pt; font-weight:900; }}
            #DescStatusText {{ color:#8fa4bc; font-size:8pt; font-weight:800; }}
            #DescPathLabel {{ background:#0d1626; color:#cbd8e8; border:1px solid #384760; border-radius:7px; padding:6px 8px; font-size:8pt; }}
            #DescTree {{ background:#101a2a; alternate-background-color:#142136; border:1px solid #37445b; border-radius:9px; }}
            #DescTree::item {{ min-height:28px; padding:3px 4px; }}
            #DescTree::item:selected {{ background:#163052; color:#dbeafe; }}
            QPushButton#PrimaryAction {{ background:#2563eb; color:#ffffff; border:1px solid #60a5fa; border-radius:8px; padding:7px 12px; font-weight:900; }}
            QPushButton#PrimaryAction:hover {{ background:#3b82f6; }}
            QPushButton#SecondaryAction {{ background:#121f33; color:#bfdbfe; border:1px solid #365f8c; border-radius:8px; padding:7px 12px; font-weight:800; }}
            QPushButton#NameCopyButton {{ background:#152943; color:#bfdbfe; border:1px solid #365f8c; border-radius:8px; padding:6px 9px; font-weight:900; }}
            QPushButton#NameCopyButton:hover {{ background:#1d3b61; border-color:#60a5fa; color:#ffffff; }}
            QPushButton#NameCopyButton:disabled {{ background:#111827; color:#526176; border-color:#2a3547; }}
            #BrandNameCard {{ background:transparent; border:0; }}
            #BrandPreviewCard {{ background:#0d192b; border:1px solid #31445f; border-radius:12px; }}
            #BrandSelectedBar {{ background:#102540; border:1px solid #315f91; border-radius:9px; }}
            #BrandSelectedCaption {{ color:#8fa4bc; font-size:7.3pt; font-weight:900; }}
            #BrandSelectedName {{ color:#eaf3ff; font-size:9.2pt; font-weight:900; }}
            #BrandPreviewBadge {{ background:#132742; color:#dbeafe; border:1px solid #315f91; border-radius:9px; padding:4px 8px; font-size:7.6pt; font-weight:900; }}
            #BrandPreviewMeta {{ color:#9fb3ca; font-size:7.6pt; font-weight:700; padding-top:1px; }}
            QToolButton#LogoCornerAction {{ background:#13223a; color:#dbeafe; border:1px solid #315f91; border-radius:14px; font-size:9pt; font-weight:900; padding:0; }}
            QToolButton#LogoCornerAction:hover {{ background:#1b365a; border-color:#60a5fa; }}
            QToolButton#LogoCornerAction:disabled {{ background:#101827; color:#526176; border-color:#2a3547; }}
            #LogoPoolChip {{ background:#111c2d; color:#9fb3ca; border:1px solid #344159; border-radius:8px; padding:5px 8px; font-weight:800; }}
            #BrandNamesList {{ background:#0f1724; border:1px solid #37445b; border-radius:9px; padding:4px; }}
            #BrandNamesList::item {{ padding:8px 9px; margin:2px; border-radius:6px; }}
            #BrandNamesList::item:selected {{ background:#163052; color:#dbeafe; }}
            #TopTools {{ background:#07101e; border:1px solid #233754; border-radius:11px; }}
            #MenuButton {{ background:#24364f; border:1px solid #6f829c; min-width:92px; }}
            #BrandTitle {{ font-size:15pt; font-weight:900; color:#ffffff; padding:5px; }}
            #BrandPreview {{ background:#0d1522; border:1px dashed #52647d; border-radius:14px; color:{SUB}; }}
            #SideTitle {{ font-size:11pt; font-weight:900; color:#ffffff; padding-left:4px; }}
            #ControlHint {{ background:#162236; color:#eaf2ff; border:1px solid #42617f; border-radius:9px; padding:5px 6px; font-size:8pt; font-weight:900; }}
            #ControlNote {{ color:#9fb3ca; font-size:8pt; font-weight:700; padding-top:1px; }}
            #SavePill {{ background:#e11d48; color:white; border:1px solid #fb7185; border-radius:11px; font-weight:900; font-size:8pt; padding:0; }}
            #SideFooter {{ background:#111e31; border:1px solid #34506e; border-radius:10px; color:#dbeafe; font-weight:900; min-height:24px; }}
            #ProxyBox {{ background:#0d1726; border:1px solid #34506e; border-radius:14px; }}
            #ProxyTitle {{ color:#cbd5e1; font-weight:800; font-size:9pt; }}
            #ProxyState {{ color:#94a3b8; font-weight:800; font-size:8.8pt; padding-left:4px; }}
            #ProxyState[active="true"] {{ color:#86efac; }}
            QPushButton#ProxySwitch {{ background:#374151; border:0; border-radius:11px; color:#f8fafc; font-size:11pt; font-weight:900; padding-right:15px; }}
            QPushButton#ProxySwitch[active="true"] {{ background:#22c55e; color:#ffffff; padding-left:15px; padding-right:0px; }}
            #LogToggle {{ background:#0f8f83; border:1px solid #35d0c4; border-radius:12px; color:white; font-weight:900; min-height:26px; font-size:8.5pt; padding:3px 7px; }}
            #RuntimeValue {{ color:#ffffff; font-size:17pt; font-weight:900; background:#0f172a; border:1px solid #34445e; border-radius:10px; padding:7px 8px; }}
            #HeroTitle {{ font-size:22pt; font-weight:900; color:#ffffff; letter-spacing:.2px; }}
            #SmallMuted, .QLabel#SmallMuted {{ color:{SUB}; font-size:9pt; }}
            #StatusLabel {{ color:{SUB}; font-weight:800; }}
            #StatusPill {{ color:#eaf2ff; font-weight:900; background:#162236; border:1px solid #4f617a; border-radius:10px; padding:7px 10px; }}
            #StatusPillMini {{ color:#eaf2ff; font-weight:900; background:#1e2d43; border:1px solid #5e7692; border-radius:8px; padding:5px 8px; }}
            #TrackHero {{ background:#1a273a; border:1px solid #43566f; border-radius:12px; }}
            #TrackChip {{ color:#eaf2ff; background:#24364f; border:1px solid #5b6f88; border-radius:10px; padding:5px 8px; font-weight:900; font-size:8.8pt; }}
            #WorkerCard {{ background:#162236; border:1px solid #41536d; border-radius:13px; }}
            #WorkerCard:hover {{ background:#1b2b43; border-color:#60a5fa; }}
            #WorkerCardTitle {{ color:#ffffff; font-weight:900; font-size:10pt; }}
            #WorkerCardSub {{ color:#d9e6f7; font-weight:800; font-size:8.5pt; }}
            #WorkerStatusBadge {{ background:#24364f; color:#eaf2ff; border:1px solid #5b6f88; border-radius:8px; padding:3px 7px; font-weight:900; font-size:8.5pt; }}
            #WorkerCardsScroll, #QueueCardsScroll {{ background:#111b2b; border:1px solid #42526b; border-radius:11px; }}
            #QueueCard {{ background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #1d2c42, stop:1 #121d2f); border:1px solid #526781; border-radius:18px; }}
            QFrame#QueueCard[empty="true"] {{ background:#111827; border:1px dashed #64748b; }}
            #QueueAddButton {{ background:#1e2d43; color:#60a5fa; border:1px dashed #60a5fa; border-radius:16px; font-size:22pt; font-weight:900; padding:2px 8px; }}
            #QueueDeleteButton {{ background:#4a1f25; color:#fecaca; border:1px solid #ef4444; border-radius:9px; padding:1px; font-size:10pt; font-weight:900; }}
            QFrame#QueueCard[selected="true"] {{ border:2px solid #60a5fa; background:#1b2b43; }}
            QFrame#QueueCard[active="true"] {{ border:2px solid #22c55e; background:#123323; }}
            #QueueCardTitle {{ color:#ffffff; font-weight:900; font-size:9.5pt; }}
            #QueueBadge {{ background:#24364f; color:#eaf2ff; border:1px solid #5b6f88; border-radius:8px; padding:2px 6px; font-weight:900; font-size:8pt; }}
            #QueueMiniLabel {{ color:{SUB}; font-weight:800; font-size:8pt; }}
            #QueueMiniEdit {{ padding:4px 6px; font-size:8pt; border-radius:7px; }}
            #QueueMiniButton {{ padding:2px 4px; font-size:8pt; border-radius:7px; }}
            #QueueStats {{ color:{SUB}; font-weight:800; font-size:8pt; }}
            #QueueList {{ background:#101827; border:1px solid #43566f; border-radius:12px; padding:5px; }}
            QProgressBar {{ background:#0f172a; border:1px solid #50647f; border-radius:7px; height:9px; text-align:center; color:#eaf2ff; font-size:7pt; }}
            QProgressBar::chunk {{ background:#60a5fa; border-radius:6px; }}
            #FieldBlock {{ background:transparent; border:0; }}
            #FieldLabel {{ color:{SUB}; font-weight:800; font-size:9.5pt; }}
            #TinyChip {{ background:#2d3b50; color:{SUB}; border:1px solid #52647d; border-radius:8px; padding:5px 8px; font-weight:800; }}
            #StatCard {{ background:{CARD}; border:1px solid {BORDER}; border-radius:14px; }}
            #CardTitle {{ color:{SUB}; font-weight:800; font-size:8pt; }}
            #CardValue {{ color:#ffffff; font-size:16pt; font-weight:900; }}
            #AccountRow {{ background:#202b3d; border:1px solid #4a5b73; border-radius:12px; }}
            #AccountRow:hover {{ background:#263448; border-color:#64748b; }}
            #AccountTitle {{ color:#ffffff; font-weight:900; }}
            #AccountStatus {{ color:{SUB}; font-weight:800; background:#142033; border:1px solid #34445e; border-radius:8px; padding:6px 8px; }}
            #AccountEmail {{ color:#e5eefc; background:#142033; border:1px solid #34445e; border-radius:8px; padding:6px 8px; }}
            QPushButton#MoveButton {{ background:#25364d; color:#ffffff; border:1px solid #52647d; border-radius:8px; padding:3px; font-size:12pt; font-weight:900; }}
            QPushButton#MoveButton:hover {{ background:#34506f; border-color:{BLUE}; }}
            QPushButton#MoveButton:disabled {{ background:#172033; color:#607089; border-color:#2b3a50; }}
            QLineEdit, QSpinBox, QComboBox {{
                background:#111a2a; color:#ffffff; border:1px solid #5a6b84;
                border-radius:9px; padding:8px 10px; selection-background-color:{BLUE};
            }}
            QLineEdit:focus, QSpinBox:focus, QComboBox:focus {{ border:1px solid {BLUE}; background:#132039; }}
            QPushButton {{
                background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #3a516d, stop:1 #26384f);
                color:#ffffff; border:1px solid #6f829c;
                border-radius:8px; padding:6px 10px; font-weight:900;
            }}
            QPushButton:hover {{ background:#465f7d; border-color:#9bb0c8; }}
            QPushButton:pressed {{ background:#203149; }}
            QPushButton#AccentButton {{ background:#2563eb; color:#ffffff; border-color:#60a5fa; }}
            QPushButton#LoginButton {{ background:#0f6b46; border-color:#34d399; color:#ffffff; }}
            QPushButton#LoginButton:hover {{ background:#138257; border-color:#6ee7b7; }}
            QPushButton#CheckButton {{ background:#1d4ed8; border-color:#60a5fa; color:#ffffff; }}
            QPushButton#CheckButton:hover {{ background:#2563eb; border-color:#93c5fd; }}
            QPushButton#DangerButton {{ background:#b91c1c; border-color:#ef4444; color:#fff; }}
            QPushButton#WarnButton {{ background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #e0a03a, stop:1 #9a6417); border:1px solid #f0b24b; color:#fff; border-radius:12px; padding:7px 12px; }}
            QFrame#JobCard QPushButton#WarnButton {{ padding:5px 10px; font-size:9pt; min-height:28px; border-radius:11px; }}
            QScrollArea, QListWidget, QTreeWidget, QPlainTextEdit {{
                background:#121d2e; border:1px solid {BORDER}; border-radius:11px; color:{FG};
            }}
            QListWidget {{ padding:8px 4px; }}
            QTreeWidget {{ background:#111b2b; alternate-background-color:#152238; }}
            QTreeWidget::item {{ height:29px; border-bottom:1px solid #22344e; font-size:8.7pt; }}
            QTreeWidget::item:hover {{ background:#1b2b42; }}
            QHeaderView::section {{ background:#263750; color:#eff6ff; padding:5px 5px; border:0; border-right:1px solid #41536b; font-weight:900; font-size:8.7pt; }}
            QListWidget::item {{ background:transparent; border:0; padding:0; margin:4px; }}
            QListWidget::item:selected {{ background:transparent; border:0; }}
            QFrame#JobCard {{ background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #253a56, stop:.55 #1b2a40, stop:1 #121d2f); border:1px solid #5b708c; border-radius:20px; }}
            QFrame#JobCard[status="running"] {{ background:#1e3550; border:2px solid {BLUE}; }}
            QFrame#JobCard[status="done"] {{ background:#183324; border:1px solid {GREEN}; }}
            QFrame#JobCard[status="error"] {{ background:#3a1d22; border:1px solid {RED}; }}
            QFrame#JobCard[status="skipped"] {{ background:#342b16; border:1px solid {ORANGE}; }}
            QFrame#JobCard[status="reserved"] {{ background:#252f45; border:1px solid {YELLOW}; }}
            QFrame#JobCard[selected="true"] {{ border:2px solid #93c5fd; background:#223a57; }}
            QCheckBox#JobSelectCheck {{ color:#dbeafe; font-weight:900; font-size:8pt; padding:0; }}
            QLabel#JobThumb {{ background:#0d1522; border:1px solid #41516a; border-radius:14px; }}
            QLabel#JobTitle {{ color:#ffffff; font-weight:900; font-size:9.5pt; }}
            QLabel#JobSub {{ color:{SUB}; font-weight:700; font-size:8.5pt; }}
            QLabel#JobChip {{ color:#dbeafe; background:#21334d; border:1px solid #50647f; border-radius:10px; padding:4px 8px; font-weight:900; font-size:8.5pt; }}
            QLabel#JobChip[status="running"] {{ color:#06111f; background:{BLUE}; border-color:#b9ddff; }}
            QLabel#JobChip[status="done"] {{ color:#04160c; background:{GREEN}; border-color:#a7f3d0; }}
            QLabel#JobChip[status="error"] {{ color:#fff1f2; background:#b91c1c; border-color:#fb7185; }}
            QLabel#JobChip[status="skipped"] {{ color:#1f1300; background:{ORANGE}; border-color:#fdba74; }}
            QLabel#JobChip[status="reserved"] {{ color:#1a1300; background:{YELLOW}; border-color:#fde68a; }}
            QTreeWidget {{ alternate-background-color:#172337; }}
            QTreeWidget::item {{ padding:3px 3px; }}
            QTreeWidget::item:selected {{ background:#1d4b7a; color:#ffffff; }}
            QHeaderView::section {{ background:#2a3a51; color:#ffffff; padding:5px 5px; border:0; border-right:1px solid #40526b; font-weight:900; font-size:8.7pt; }}
            QSplitter::handle {{ background:#0f172a; }}
            QScrollBar:vertical {{ background:#101827; width:14px; margin:0; }}
            QScrollBar::handle:vertical {{ background:#52647d; min-height:28px; border-radius:7px; }}
            QScrollBar::handle:vertical:hover {{ background:#708198; }}
            QScrollBar:horizontal {{ background:#101827; height:14px; margin:0; }}
            QScrollBar::handle:horizontal {{ background:#52647d; min-width:28px; border-radius:7px; }}
            QScrollBar::handle:horizontal:hover {{ background:#708198; }}
        """)


    # ---------- state/accounts ----------
    def add_account_row(self, account_no=None, login_email="", login_password="", display_email=""):
        row = AccountRow(self, len(self.rows) + 1, account_no, login_email, login_password, display_email)
        self.rows.append(row)
        self.accounts_layout.insertWidget(max(0, self.accounts_layout.count() - 1), row)
        self.reindex_rows(save=False)
        if not self._suspend_state_save:
            self.schedule_save_state()
        return row

    # ---------- v6.1 Login vault / TXT import ----------
    def _vault_path(self):
        return _login_vault_path(self.backend_dir)

    def _load_login_vault(self):
        try:
            p = self._vault_path()
            if p.exists():
                data = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
        except Exception as e:
            self.append_log(f"[login-vault] đọc vault lỗi: {e}")
        return {"version": 1, "accounts": {}}

    def _save_login_vault(self, vault):
        try:
            p = self._vault_path()
            tmp = p.with_suffix(".tmp")
            tmp.write_text(json.dumps(vault, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(p)
            return True
        except Exception as e:
            self.append_log(f"[login-vault] lưu vault lỗi: {e}")
            return False

    def _get_login_credential(self, account_no):
        vault = self._load_login_vault()
        rec = (vault.get("accounts") or {}).get(f"google_{int(account_no)}") or {}
        email = rec.get("email", "")
        password = _dpapi_unprotect_text(rec.get("password"))
        recovery_email = rec.get("recovery_email", "") or rec.get("recovery", "") or rec.get("backup_email", "")
        return email, password, recovery_email

    def import_login_txt(self):
        try:
            default = self.backend_dir / "account_import.txt"
            file_path, _ = QFileDialog.getOpenFileName(self, "Chọn account_import.txt", str(default), "Text files (*.txt);;All files (*.*)")
            if not file_path:
                return
            text = Path(file_path).read_text(encoding="utf-8", errors="ignore")
            start_google = 1
            try:
                if self.rows:
                    start_google = min(r.account_no() for r in self.rows)
            except Exception:
                pass
            items = _parse_login_import_text(text, start_google=start_google)
            if not items:
                QMessageBox.warning(self, APP_TITLE, "Không đọc được tài khoản nào.\nDạng đúng khuyên dùng:\nemail@gmail.com<TAB>matkhau<TAB>email_khoi_phuc\nhoặc:\ngoogle_3<TAB>email@gmail.com<TAB>matkhau<TAB>email_khoi_phuc")
                return
            vault = self._load_login_vault()
            vault.setdefault("version", 1)
            vault.setdefault("accounts", {})
            imported = 0
            for acc, email, password, recovery_email in items:
                vault["accounts"][f"google_{int(acc)}"] = {
                    "email": email,
                    "password": _dpapi_protect_text(password),
                    "recovery_email": recovery_email,
                    "imported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                row = None
                for r in self.rows:
                    try:
                        if r.account_no() == int(acc):
                            row = r; break
                    except Exception:
                        pass
                if row is None:
                    row = self.add_account_row(account_no=int(acc), display_email=email)
                row.email_edit.setText(email)
                row.pass_edit.setText("")
                row.display_email.setText(f"Mail đang đăng nhập: {email}")
                imported += 1
            if self._save_login_vault(vault):
                try:
                    Path(file_path).rename(str(file_path) + ".imported_delete_me")
                    self.append_log(f"[login-vault] đã đổi tên file TXT tạm để tránh lộ mật khẩu: {Path(file_path).name}.imported_delete_me")
                except Exception:
                    self.append_log("[login-vault] chưa tự đổi tên/xóa được file TXT, bạn nên xóa file import sau khi nhập")
                QMessageBox.information(self, APP_TITLE, f"Đã import {imported} tài khoản vào login_vault.json.\nMật khẩu được mã hóa bằng Windows DPAPI trên máy này.\nNếu TXT có cột 3, tool sẽ lưu email khôi phục để điền khi Google hỏi.\nFile TXT tạm nên xóa sau khi import.")
                self.append_log(f"[login-vault] import OK {imported} tài khoản")
                self.schedule_save_state()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def start_login_assist_for_row(self, row):
        try:
            acc = row.account_no()
            email, password, recovery_email = self._get_login_credential(acc)
            if not email or not password:
                return False
            if not self.chrome_binary.exists():
                QMessageBox.warning(self, APP_TITLE, f"Không thấy Chrome/Chromium để auto-login: {self.chrome_binary}")
                return False
            row.set_status(False, "Đang tự đăng nhập...", email)
            self.append_log(f"[login-assist] bắt đầu auto-login A{acc} • {email}")
            def work():
                ok, msg = _auto_google_login_once(self.chrome_binary, self.driver_binary, row.profile_path(), email, password, recovery_email, log_fn=self.append_log, proxy_value=self._proxy_value_for_account(acc))
                def finish():
                    if ok:
                        row.set_status(True, "Login assist OK • hãy Kiểm tra lại", email)
                    else:
                        row.set_status(False, msg or "Cần đăng nhập thủ công", email)
                    self.append_log(f"[login-assist] A{acc}: {'OK' if ok else 'FAIL'} • {msg}")
                QTimer.singleShot(0, finish)
            threading.Thread(target=work, daemon=True).start()
            return True
        except Exception as e:
            self.append_log(f"[login-assist] lỗi: {e}")
            return False

    # ---------- v6.3 Auto Login All ----------
    def _row_needs_login_assist(self, row):
        try:
            # Bỏ qua account đang xanh OK rõ ràng để không mở Chrome thừa.
            txt = ""
            try:
                txt = (row.status_label.text() or "").lower()
            except Exception:
                txt = ""
            if ("gemini ok" in txt) or ("login assist ok" in txt):
                return False
            email, password, _recovery_email = self._get_login_credential(row.account_no())
            return bool(email and password)
        except Exception:
            return False

    def login_all_accounts(self):
        """Tự đăng nhập hàng loạt bằng login_vault.json. v6.8 chạy lần lượt từng account và tự hoàn tất onboarding Gemini."""
        try:
            if not self.chrome_binary.exists():
                QMessageBox.warning(self, APP_TITLE, f"Không thấy Chrome/Chromium để auto-login: {self.chrome_binary}")
                return
            targets = []
            for row in list(self.rows):
                try:
                    acc = row.account_no()
                    email, password, recovery_email = self._get_login_credential(acc)
                    if not email or not password:
                        continue
                    if not self._row_needs_login_assist(row):
                        self.append_log(f"[login-all] bỏ qua A{acc}: đã OK hoặc không cần đăng nhập")
                        continue
                    targets.append((row, acc, email, password, recovery_email))
                except Exception:
                    pass
            if not targets:
                QMessageBox.information(self, APP_TITLE, "Không có tài khoản nào cần auto-login hoặc chưa import TXT login.")
                return

            # v6.4: chạy lần lượt từng tài khoản để test ổn định, dễ nhìn lỗi và tránh Google nghi ngờ.
            max_parallel = 1
            self.append_log(f"[login-all] bắt đầu tự đăng nhập {len(targets)} tài khoản • lần lượt từng tài khoản • login Google đơn giản + Gemini onboarding")
            for row, acc, email, _password, _recovery_email in targets:
                try:
                    row.set_status(False, "Chờ auto-login...", email)
                except Exception:
                    pass

            stop_flag = threading.Event()
            self._login_all_stop_event = stop_flag

            def ui_set(row, ok, msg, email):
                try:
                    if ok:
                        row.set_status(True, "Login assist OK • hãy Kiểm tra lại", email)
                    else:
                        row.set_status(False, msg or "Cần đăng nhập thủ công", email)
                except Exception:
                    pass

            def worker(item):
                row, acc, email, password, recovery_email = item
                try:
                    QTimer.singleShot(0, lambda r=row, e=email: r.set_status(False, "Đang tự đăng nhập...", e))
                    self.append_log(f"[login-all] A{acc}: bắt đầu • {email}")
                    ok, msg = _auto_google_login_once(self.chrome_binary, self.driver_binary, row.profile_path(), email, password, recovery_email, log_fn=self.append_log, stop_event=stop_flag, proxy_value=self._proxy_value_for_account(acc))
                    self.append_log(f"[login-all] A{acc}: {'OK' if ok else 'FAIL'} • {msg}")
                    QTimer.singleShot(0, lambda r=row, o=ok, m=msg, e=email: ui_set(r, o, m, e))
                except Exception as e:
                    self.append_log(f"[login-all] A{acc}: lỗi {type(e).__name__}: {str(e)[:160]}")
                    QTimer.singleShot(0, lambda r=row, e=email, m=str(e)[:120]: ui_set(r, False, "Lỗi auto-login: " + m, e))

            def orchestrator():
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=max_parallel) as ex:
                    futs = [ex.submit(worker, item) for item in targets]
                    for _ in concurrent.futures.as_completed(futs):
                        pass
                def done_ui():
                    self.append_log("[login-all] hoàn tất auto-login hàng loạt • tự chạy Kiểm tra tất cả")
                    try:
                        self.check_all()
                    except Exception as e:
                        self.append_log(f"[login-all] không tự kiểm tra được: {e}")
                QTimer.singleShot(0, done_ui)

            threading.Thread(target=orchestrator, daemon=True).start()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def remove_account_row(self, row):
        if row in self.rows:
            self.rows.remove(row)
            row.setParent(None)
            row.deleteLater()
            self.reindex_rows()

    def move_account_row(self, row, delta):
        if row not in self.rows:
            return
        old = self.rows.index(row)
        new = max(0, min(len(self.rows) - 1, old + int(delta)))
        if new == old:
            return
        self.rows.pop(old)
        self.rows.insert(new, row)
        try:
            self.accounts_layout.removeWidget(row)
            self.accounts_layout.insertWidget(new, row)
        except Exception:
            pass
        self.reindex_rows()
        try:
            self.append_log(f"[account] đã đổi thứ tự: A{row.account_no()} -> vị trí {new + 1}")
        except Exception:
            pass

    def reindex_rows(self, save=True):
        total = len(self.rows)
        for i, row in enumerate(self.rows, start=1):
            row.update_title(i)
            try:
                row.set_move_enabled(i > 1, i < total)
            except Exception:
                pass
        if save and not self._suspend_state_save:
            self.schedule_save_state()

    def _mark_account_checking(self, acc):
        with self._checking_lock:
            if acc in self._checking_account_nos:
                return False
            self._checking_account_nos.add(acc)
            return True

    def _unmark_account_checking(self, acc):
        with self._checking_lock:
            self._checking_account_nos.discard(acc)

    def _acquire_chrome_background_guard(self, reason=""):
        """Background guard for legacy desktop mode only.

        V17 Web integration: NEVER install the global WinEvent hook. 3T's web shell can
        run in the same Chrome executable used for Gemini login; matching by chrome_binary at
        system-window level can therefore hide/move the user's MAIN 3T window. All Web
        workers/checks are headless and login windows are hidden per ChromeDriver PID, so the
        global guard is both unnecessary and harmful.
        """
        web_mode = str(os.environ.get("THUMBNAIL_WEB_MODE", "0")).strip().lower() in ("1", "true", "yes", "on")
        if web_mode:
            try:
                if not getattr(self, "_v17_web_guard_off_logged", False):
                    self._v17_web_guard_off_logged = True
                    self.append_log(f"[chrome-bg] V17 GLOBAL GUARD OFF in Web mode • {reason or 'no-reason'} • 3T window protected")
            except Exception:
                pass
            return
        visible_debug = str(os.environ.get("GEMINI_VISIBLE_DEBUG", "0")).strip().lower() in ("1", "true", "yes", "on")
        disable_guard = str(os.environ.get("GEMINI_DISABLE_CHROME_BG_GUARD", "0")).strip().lower() in ("1", "true", "yes", "on")
        if visible_debug or disable_guard:
            try:
                self.append_log(f"[chrome-bg] DISABLED for visible debug • {reason}")
            except Exception:
                pass
            return
        if os.name != "nt":
            return
        try:
            with self._chrome_guard_lock:
                self._chrome_guard_refs += 1
                if self._chrome_guard_thread is None or not self._chrome_guard_thread.is_alive():
                    self._chrome_guard_stop.clear()

                    def _loop():
                        tick = 0
                        hooks = []
                        callback_ref = None
                        try:
                            user32 = ctypes.windll.user32
                            EVENT_SYSTEM_FOREGROUND = 0x0003
                            EVENT_OBJECT_SHOW = 0x8002
                            WINEVENT_OUTOFCONTEXT = 0x0000
                            WINEVENT_SKIPOWNPROCESS = 0x0002
                            OBJID_WINDOW = 0
                            WinEventProc = ctypes.WINFUNCTYPE(None, ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_long, ctypes.c_long, ctypes.c_uint, ctypes.c_uint)
                            try:
                                user32.SetWinEventHook.restype = ctypes.c_void_p
                                user32.UnhookWinEvent.argtypes = [ctypes.c_void_p]
                            except Exception:
                                pass

                            def _event_cb(_hook, _event, hwnd, id_object, _id_child, _thread, _time_ms):
                                try:
                                    hwnd = int(hwnd or 0)
                                    if id_object not in (OBJID_WINDOW, 0):
                                        return
                                    if _qt_is_portable_chrome_hwnd(hwnd, self.chrome_binary):
                                        _qt_move_hwnd_offscreen_no_activate(hwnd)
                                except Exception:
                                    pass

                            callback_ref = WinEventProc(_event_cb)
                            for ev in (EVENT_OBJECT_SHOW, EVENT_SYSTEM_FOREGROUND):
                                h = user32.SetWinEventHook(ev, ev, 0, callback_ref, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS)
                                if h:
                                    hooks.append(h)
                        except Exception:
                            hooks = []
                            callback_ref = None

                        try:
                            while not self._chrome_guard_stop.is_set():
                                try:
                                    _qt_keep_portable_chrome_offscreen_once(self.chrome_binary)
                                except Exception:
                                    pass
                                tick += 1
                                try:
                                    msg = ctypes.wintypes.MSG()
                                    PM_REMOVE = 0x0001
                                    user32 = ctypes.windll.user32
                                    while user32.PeekMessageW(ctypes.byref(msg), 0, 0, 0, PM_REMOVE):
                                        user32.TranslateMessage(ctypes.byref(msg))
                                        user32.DispatchMessageW(ctypes.byref(msg))
                                except Exception:
                                    pass
                                time.sleep(0.006 if tick < 260 else 0.08)
                        finally:
                            try:
                                user32 = ctypes.windll.user32
                                for h in hooks:
                                    try:
                                        user32.UnhookWinEvent(h)
                                    except Exception:
                                        pass
                            except Exception:
                                pass
                            _ = callback_ref

                    self._chrome_guard_thread = threading.Thread(target=_loop, daemon=True)
                    self._chrome_guard_thread.start()
            if reason:
                self.append_log(f"[chrome-bg] v134 giữ Chrome/cmd ngoài màn hình + dọn process trước chạy • {reason}")
        except Exception as e:
            try:
                self.append_log(f"[chrome-bg] guard lỗi: {e}")
            except Exception:
                pass

    def _release_chrome_background_guard(self, grace=2.0):
        if os.name != "nt":
            return
        def _release_later():
            time.sleep(max(0.0, float(grace)))
            with self._chrome_guard_lock:
                self._chrome_guard_refs = max(0, self._chrome_guard_refs - 1)
                if self._chrome_guard_refs <= 0:
                    self._chrome_guard_stop.set()
        threading.Thread(target=_release_later, daemon=True).start()


    def check_account_row_hidden(self, row):
        if check_gemini_logged_in is None:
            QMessageBox.warning(self, APP_TITLE, "Không có hàm kiểm tra tài khoản.")
            return
        try:
            acc = row.account_no()
        except Exception:
            QMessageBox.warning(self, APP_TITLE, "Số account không hợp lệ")
            return
        if not self._mark_account_checking(acc):
            self.append_log(f"[check] A{acc} đang được kiểm tra, bỏ qua lệnh trùng")
            return
        row.set_status(False, "Đang kiểm tra headless...", "")
        self._check_stop_event.clear()
        self._acquire_chrome_background_guard("kiểm tra tài khoản headless")

        def run():
            try:
                ok, msg, email = check_gemini_logged_in(str(self.chrome_binary), str(self.driver_binary), str(row.profile_path()), stop_event=self._check_stop_event)
            except Exception as e:
                ok, msg, email = False, str(e), ""
            finally:
                self._unmark_account_checking(acc)
                self._release_chrome_background_guard(grace=1.5)
            try:
                if ok:
                    self._mark_account_login_ok(acc, msg)
                if not hasattr(self, "_web_check_results") or not isinstance(self._web_check_results, dict):
                    self._web_check_results = {}
                self._web_check_results[int(acc)] = "ok" if ok else "fail"
                row.ok = bool(ok)
            except Exception:
                pass
            self.ui_queue.put(("account_status", row.row_id, ok, msg, email))
        threading.Thread(target=run, daemon=True).start()

    def autofill_rows(self):
        profiles_root = self.backend_dir / "profiles"
        nums = []
        if profiles_root.exists():
            for p in sorted(profiles_root.glob("google_*")):
                m = re.search(r"google_(\d+)$", p.name)
                if m:
                    nums.append(int(m.group(1)))
        if not nums:
            QMessageBox.warning(self, APP_TITLE, "Không thấy profiles/google_*")
            return
        for r in list(self.rows):
            self.remove_account_row(r)
        for n in nums:
            self.add_account_row(n)
        self.append_log(f"[account] tự đọc {len(nums)} profile")

    def check_all(self):
        if self._checking_all:
            self.append_log("[check] đang kiểm tra tất cả, vui lòng đợi xong")
            return
        rows = list(self.rows)
        if not rows:
            return
        self._checking_all = True
        self._check_stop_event.clear()
        self._web_check_total = len(rows)
        self._web_check_done = 0
        self._web_check_ok = 0
        self._web_check_fail = 0
        self._web_check_results = {int(r.account_no()): None for r in rows if str(r.account_no()).isdigit()}
        self.status_label.setText("Đang kiểm tra tất cả song song...")
        for r in rows:
            r.set_status(False, "Chờ kiểm tra headless...", "")

        # Bật guard trước khi ChromeDriver kịp mở Chrome, tránh cửa sổ nhảy lên màn hình nếu có fallback/debug.
        self._acquire_chrome_background_guard("kiểm tra tất cả song song")

        def run_parallel():
            from concurrent.futures import ThreadPoolExecutor, as_completed
            web_mode = str(os.environ.get("THUMBNAIL_WEB_MODE", "0")).strip().lower() in ("1","true","yes","on")
            safe_limit = min(int(CHECK_ALL_PARALLEL_LIMIT), 8) if web_mode else int(CHECK_ALL_PARALLEL_LIMIT)
            max_workers = max(1, min(len(rows), safe_limit))
            started = 0

            def _one(r):
                try:
                    acc = r.account_no()
                except Exception:
                    return r.row_id, 0, False, "Số account không hợp lệ", ""
                if not self._mark_account_checking(acc):
                    return r.row_id, int(acc), False, "Đang được kiểm tra bởi lệnh khác", ""
                self.ui_queue.put(("account_status", r.row_id, False, "Đang kiểm tra headless...", ""))
                try:
                    if self._check_stop_event.is_set():
                        return r.row_id, int(acc), False, "Đã dừng kiểm tra", ""
                    ok, msg, email = check_gemini_logged_in(str(self.chrome_binary), str(self.driver_binary), str(r.profile_path()), stop_event=self._check_stop_event)
                    return r.row_id, int(acc), ok, msg, email
                except Exception as e:
                    return r.row_id, int(acc), False, str(e), ""
                finally:
                    self._unmark_account_checking(acc)

            try:
                self.ui_queue.put(("log", f"[check] V24 kiểm tra song song {len(rows)} tài khoản • tối đa {max_workers} luồng • WEB_SAFE={web_mode} • progress realtime • headless"))
                with ThreadPoolExecutor(max_workers=max_workers) as ex:
                    futs = []
                    for r in rows:
                        futs.append(ex.submit(_one, r))
                        started += 1
                    done = 0
                    for fut in as_completed(futs):
                        done += 1
                        try:
                            row_id, acc, ok, msg, email = fut.result()
                        except Exception as e:
                            row_id, acc, ok, msg, email = None, 0, False, str(e), ""
                        if row_id is not None:
                            for _r in rows:
                                if _r.row_id == row_id:
                                    _r.ok = bool(ok)
                                    break
                            self.ui_queue.put(("account_status", row_id, ok, msg, email))
                        self._web_check_done = done
                        if ok:
                            if acc:
                                try:
                                    self._mark_account_login_ok(int(acc), msg)
                                except Exception:
                                    pass
                            self._web_check_ok = int(getattr(self, "_web_check_ok", 0) or 0) + 1
                        else:
                            self._web_check_fail = int(getattr(self, "_web_check_fail", 0) or 0) + 1
                        if acc:
                            self._web_check_results[int(acc)] = "ok" if ok else "fail"
                        pct = int(round(done * 100 / max(1, started)))
                        self.ui_queue.put(("status", f"Kiểm tra tất cả: {done}/{started} • {pct}% • OK {self._web_check_ok} • lỗi {self._web_check_fail}"))
            finally:
                self._checking_all = False
                self._release_chrome_background_guard(grace=2.0)
                self.ui_queue.put(("status", "Kiểm tra tất cả xong"))
                self.ui_queue.put(("log", "[check] kiểm tra tất cả song song xong"))

        threading.Thread(target=run_parallel, daemon=True).start()

    # ---------- v13.48.2 Daily quota hold + account history ----------
    def _account_state_write_json_atomic(self, path, data):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
        raw = json.dumps(data, ensure_ascii=False, indent=2)
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(raw)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
            os.replace(tmp, path)
        finally:
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass

    def _daily_quota_hold_path(self):
        raw = str(os.environ.get(ACCOUNT_DAILY_QUOTA_HOLD_ENV, "") or "").strip().strip('"')
        if raw:
            return Path(normalize_path(raw))
        return self.backend_dir / ACCOUNT_DAILY_QUOTA_HOLD_JSON

    def _daily_quota_file_lock_acquire(self, path, timeout=4.0):
        """Khóa bằng thư mục để dùng được cả Windows và đường dẫn LAN/NAS."""
        lock_dir = Path(str(path) + ".lock")
        deadline = time.time() + max(0.2, float(timeout or 0.2))
        while time.time() < deadline:
            try:
                lock_dir.parent.mkdir(parents=True, exist_ok=True)
                lock_dir.mkdir()
                try:
                    (lock_dir / "owner.json").write_text(
                        json.dumps({"pid": os.getpid(), "time": time.time()}, ensure_ascii=False),
                        encoding="utf-8",
                    )
                except Exception:
                    pass
                return lock_dir
            except FileExistsError:
                try:
                    age = max(0.0, time.time() - lock_dir.stat().st_mtime)
                    if age > max(30, int(ACCOUNT_DAILY_LOCK_STALE_SECONDS or 120)):
                        try:
                            owner = lock_dir / "owner.json"
                            if owner.exists():
                                owner.unlink()
                        except Exception:
                            pass
                        try:
                            lock_dir.rmdir()
                            continue
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.05)
            except Exception:
                break
        return None

    def _daily_quota_file_lock_release(self, lock_dir):
        if not lock_dir:
            return
        try:
            owner = Path(lock_dir) / "owner.json"
            if owner.exists():
                owner.unlink()
        except Exception:
            pass
        try:
            Path(lock_dir).rmdir()
        except Exception:
            pass

    def _read_daily_quota_payload(self, path):
        try:
            if not Path(path).is_file():
                return {}
            data = json.loads(Path(path).read_text(encoding="utf-8-sig", errors="ignore") or "{}")
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _new_daily_quota_payload(self, today=None):
        return {
            "version": "13.48.2",
            "date": str(today or datetime.now().date().isoformat()),
            "accounts": [],
            "details": {},
            "note": "Account hết quota tạo ảnh trong lượt hiện tại. Giữ nguyên profile; bấm Chạy queue lại sẽ cho thử lại một lần.",
        }

    def _refresh_daily_quota_holds(self, log=False):
        """Đọc hold theo ngày; file ngày cũ được tự làm mới, không xóa profile."""
        today = datetime.now().date().isoformat()
        path = self._daily_quota_hold_path()
        with self._daily_quota_lock:
            data = self._read_daily_quota_payload(path)
            if str(data.get("date") or "") != today:
                lock_dir = self._daily_quota_file_lock_acquire(path)
                if lock_dir:
                    try:
                        latest = self._read_daily_quota_payload(path)
                        if str(latest.get("date") or "") == today:
                            data = latest
                        else:
                            data = self._new_daily_quota_payload(today)
                            self._account_state_write_json_atomic(path, data)
                    finally:
                        self._daily_quota_file_lock_release(lock_dir)
                else:
                    data = self._new_daily_quota_payload(today)
            held = set()
            for raw_acc in data.get("accounts") or []:
                try:
                    held.add(int(raw_acc))
                except Exception:
                    pass
            previous = set(getattr(self, "_daily_quota_accounts", set()) or set())
            self._daily_quota_accounts = held
            # v13.51: quota hold trên đĩa là trạng thái gốc. Khi người dùng bấm
            # Chạy queue lại, các account nằm trong override được tạm mở để thử lại.
            manual_retry = set(getattr(self, "_manual_quota_recheck_accounts", set()) or set())
            effective_held = held.difference(manual_retry)
            self._daily_quota_date = today
            self._daily_quota_loaded = True
            try:
                self._daily_quota_file_mtime_ns = int(path.stat().st_mtime_ns)
            except Exception:
                self._daily_quota_file_mtime_ns = 0
            try:
                self.exhausted_accounts.difference_update(previous | manual_retry)
                self.exhausted_accounts.update(effective_held)
            except Exception:
                pass
            signature = today + "|" + ",".join(str(x) for x in sorted(held))
            if log and signature != getattr(self, "_daily_quota_log_date", ""):
                self._daily_quota_log_date = signature
                if effective_held:
                    self.append_log(
                        f"[daily-quota] đang giữ {len(effective_held)} account vẫn hết quota trong lượt này: "
                        + ",".join(f"A{x}" for x in sorted(effective_held))
                    )
                elif held and manual_retry:
                    self.append_log(f"[daily-quota-recheck] đang mở lại {len(held)} account quota để thử lại theo nút Chạy queue")
                else:
                    self.append_log("[daily-quota] hiện chưa có account nào bị giữ quota")
            return set(held)

    def _daily_quota_held_accounts(self):
        today = datetime.now().date().isoformat()
        changed_on_disk = False
        try:
            path = self._daily_quota_hold_path()
            current_mtime = int(path.stat().st_mtime_ns) if path.is_file() else 0
            changed_on_disk = current_mtime != int(getattr(self, "_daily_quota_file_mtime_ns", 0) or 0)
        except Exception:
            changed_on_disk = False
        if (not getattr(self, "_daily_quota_loaded", False)) or getattr(self, "_daily_quota_date", "") != today or changed_on_disk:
            raw_held = self._refresh_daily_quota_holds(log=False)
        else:
            raw_held = set(getattr(self, "_daily_quota_accounts", set()) or set())
        manual_retry = set(getattr(self, "_manual_quota_recheck_accounts", set()) or set())
        return set(raw_held).difference(manual_retry)

    def _enable_manual_quota_recheck(self):
        """v13.51: mỗi lần người dùng bấm Chạy queue mới, cho quota account thử lại 1 lần.

        Không xóa file hold dùng chung. Chỉ tạo override cục bộ cho lượt chạy hiện tại.
        Nếu account vẫn báo quota, _mark_daily_quota_hold() sẽ gỡ override của chính
        account đó ngay lập tức, vì vậy account không bị retry vòng lặp trong cùng batch.
        """
        try:
            raw_held = set(self._refresh_daily_quota_holds(log=False) or set())
        except Exception:
            raw_held = set(getattr(self, "_daily_quota_accounts", set()) or set())
        self._manual_quota_recheck_accounts = set(raw_held)
        if not raw_held:
            return set()
        try:
            self.exhausted_accounts.difference_update(raw_held)
        except Exception:
            pass
        # Quota hit chỉ là trạng thái tạm thời. Xóa penalty runtime để account thực sự
        # có cơ hội được scheduler chọn lại ngay trong lượt chạy mới.
        for acc in raw_held:
            try:
                perf = self._get_account_perf(acc)
                perf["quota_hits"] = 0
                perf["cooldown_until"] = 0.0
            except Exception:
                pass
        try:
            self.append_log(
                f"[daily-quota-recheck] Bấm Chạy queue → MỞ LẠI toàn bộ {len(raw_held)} account từng bị gắn quota, cho vẽ thử thật: "
                + ",".join(f"A{x}" for x in sorted(raw_held))
            )
            self.append_log("[daily-quota-recheck] chỉ account nào đã Send job thật và Gemini trả quota mới bị khóa trong lượt này; lần bấm Chạy queue sau lại thử toàn bộ")
        except Exception:
            pass
        return set(raw_held)

    def _clear_daily_quota_hold_after_success(self, account_no):
        """Nếu account quota được manual recheck và tạo ảnh thành công, bỏ hold ngay."""
        try:
            acc = int(account_no)
        except Exception:
            return False
        manual_retry = set(getattr(self, "_manual_quota_recheck_accounts", set()) or set())
        if acc not in manual_retry:
            return False
        today = datetime.now().date().isoformat()
        path = self._daily_quota_hold_path()
        removed = False
        with self._daily_quota_lock:
            lock_dir = self._daily_quota_file_lock_acquire(path)
            if lock_dir:
                try:
                    data = self._read_daily_quota_payload(path)
                    if str(data.get("date") or "") == today:
                        accounts = []
                        for raw_acc in data.get("accounts") or []:
                            try:
                                value = int(raw_acc)
                            except Exception:
                                continue
                            if value == acc:
                                removed = True
                                continue
                            if value not in accounts:
                                accounts.append(value)
                        data["accounts"] = sorted(accounts)
                        details = data.get("details") if isinstance(data.get("details"), dict) else {}
                        details.pop(str(acc), None)
                        data["details"] = details
                        data["note"] = "Quota hold được rà lại khi bấm Chạy queue; account tạo ảnh thành công sẽ được mở lại ngay."
                        self._account_state_write_json_atomic(path, data)
                        self._daily_quota_accounts = set(accounts)
                finally:
                    self._daily_quota_file_lock_release(lock_dir)
            self._manual_quota_recheck_accounts.discard(acc)
            try:
                self.exhausted_accounts.discard(acc)
            except Exception:
                pass
            try:
                self._daily_quota_file_mtime_ns = int(path.stat().st_mtime_ns) if path.is_file() else 0
            except Exception:
                pass
        if removed:
            try:
                self.ui_queue.put(("log", f"[daily-quota-recheck] A{acc} tạo ảnh thành công → quota đã hồi, bỏ hold và cho dùng bình thường"))
            except Exception:
                pass
        return removed

    def _mark_daily_quota_hold(self, account_no, message=""):
        try:
            acc = int(account_no)
        except Exception:
            return False
        today = datetime.now().date().isoformat()
        path = self._daily_quota_hold_path()
        # Nếu account đang được thử lại do người dùng bấm Chạy queue mà vẫn báo quota,
        # khóa riêng account đó lại ngay trong lượt hiện tại.
        try:
            self._manual_quota_recheck_accounts.discard(acc)
        except Exception:
            pass
        added = False
        write_failed = ""
        merged_accounts = None
        with self._daily_quota_lock:
            lock_dir = self._daily_quota_file_lock_acquire(path)
            if lock_dir:
                try:
                    data = self._read_daily_quota_payload(path)
                    if str(data.get("date") or "") != today:
                        data = self._new_daily_quota_payload(today)
                    accounts = []
                    for raw_acc in data.get("accounts") or []:
                        try:
                            value = int(raw_acc)
                            if value not in accounts:
                                accounts.append(value)
                        except Exception:
                            pass
                    if acc not in accounts:
                        accounts.append(acc)
                        added = True
                    accounts.sort()
                    data["version"] = "13.48.2"
                    data["date"] = today
                    data["accounts"] = accounts
                    merged_accounts = set(accounts)
                    details = data.get("details") if isinstance(data.get("details"), dict) else {}
                    details[str(acc)] = {
                        "reason": "quota",
                        "held_at": datetime.now().isoformat(timespec="seconds"),
                        "message": str(message or "Gemini image generation limit reached")[:500],
                    }
                    data["details"] = details
                    data["note"] = "Account hết quota tạo ảnh trong lượt hiện tại. Giữ nguyên profile; bấm Chạy queue lại sẽ cho thử lại một lần."
                    self._account_state_write_json_atomic(path, data)
                except Exception as e:
                    write_failed = str(e)
                finally:
                    self._daily_quota_file_lock_release(lock_dir)
            else:
                write_failed = "không lấy được khóa file quota dùng chung"
            if merged_accounts is not None:
                self._daily_quota_accounts = set(merged_accounts)
            else:
                self._daily_quota_accounts.add(acc)
            self._daily_quota_date = today
            self._daily_quota_loaded = True
            try:
                self._daily_quota_file_mtime_ns = int(path.stat().st_mtime_ns)
            except Exception:
                pass
            try:
                self.exhausted_accounts.add(acc)
                self.active_accounts.discard(acc)
            except Exception:
                pass
        if added:
            try:
                self.ui_queue.put(("log", f"[daily-quota] giữ A{acc} trong lượt này • bấm Chạy queue lại sẽ thử lại • không xóa profile"))
            except Exception:
                pass
        if write_failed:
            try:
                self.ui_queue.put(("log", f"[daily-quota] WARN A{acc} mới chỉ giữ trong bộ nhớ, chưa ghi được file: {write_failed}"))
            except Exception:
                pass
        return added

    def _account_selection_history_path(self):
        return self.backend_dir / ACCOUNT_SELECTION_HISTORY_JSON

    def _load_account_selection_history(self):
        with self._account_history_lock:
            if getattr(self, "_account_history_loaded", False):
                return self._account_history
            path = self._account_selection_history_path()
            data = {}
            try:
                if path.is_file():
                    raw = json.loads(path.read_text(encoding="utf-8-sig", errors="ignore") or "{}")
                    data = raw.get("accounts") if isinstance(raw, dict) else {}
            except Exception:
                data = {}
            self._account_history = data if isinstance(data, dict) else {}
            self._account_history_loaded = True
            return self._account_history

    def _account_history_entry(self, account_no):
        try:
            key = str(int(account_no))
        except Exception:
            key = str(account_no)
        with self._account_history_lock:
            history = self._load_account_selection_history()
            entry = history.get(key)
            if not isinstance(entry, dict):
                entry = {}
                history[key] = entry
            return entry

    def _save_account_selection_history(self, force=False):
        with self._account_history_lock:
            if not getattr(self, "_account_history_dirty", False):
                return
            now = time.time()
            if (not force) and now - float(getattr(self, "_last_account_history_save_ts", 0.0) or 0.0) < 5.0:
                return
            payload = {
                "version": "13.48.2",
                "updated_at": datetime.now().isoformat(timespec="seconds"),
                "accounts": self._load_account_selection_history(),
                "note": "Chỉ lưu thống kê chọn account; không chứa email hoặc mật khẩu.",
            }
            try:
                self._account_state_write_json_atomic(self._account_selection_history_path(), payload)
                self._account_history_dirty = False
                self._last_account_history_save_ts = now
            except Exception as e:
                try:
                    self.ui_queue.put(("log", f"[account-score] lưu lịch sử lỗi nhẹ: {e}"))
                except Exception:
                    pass

    def _mark_accounts_selected(self, accounts):
        now = time.time()
        changed = False
        for raw_acc in accounts or []:
            try:
                acc = int(raw_acc)
            except Exception:
                continue
            entry = self._account_history_entry(acc)
            entry["selections"] = int(entry.get("selections", 0) or 0) + 1
            entry["last_selected_at"] = now
            changed = True
        if changed:
            self._account_history_dirty = True
            self._save_account_selection_history(force=True)

    def _vault_account_numbers(self):
        """v8.0: account pool lấy từ login_vault.json, không phụ thuộc hàng đăng nhập trên UI."""
        nums = []
        try:
            vault = self._load_login_vault()
            for k, rec in (vault.get("accounts") or {}).items():
                m = re.search(r"google_(\d+)", str(k))
                if not m:
                    continue
                email = str((rec or {}).get("email") or "").strip()
                if not email:
                    continue
                n = int(m.group(1))
                if n not in nums:
                    nums.append(n)
        except Exception as e:
            self.append_log(f"[account-pool] đọc kho tài khoản lỗi: {e}")
        nums.sort()
        return nums

    def _machine_pool_identity(self):
        """v12.60: tạo khóa ổn định cho từng máy để mỗi máy dùng 1 nhóm mail cố định."""
        try:
            parts = [
                os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "",
                os.environ.get("USERNAME") or os.environ.get("USER") or "",
            ]
            raw = "|".join(str(x or "").strip() for x in parts)
            if not raw.strip("|"):
                raw = str(Path.home()).lower()
            h = hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:16]
            return raw, h
        except Exception:
            return "unknown", "unknown"

    def _manual_machine_account_pool(self, all_accounts):
        """Đọc machine_accounts.txt nếu muốn tự chỉ định 20 mail cho riêng máy này.
        Chấp nhận: 12, google_12, hoặc email@gmail.com ở đầu dòng.
        """
        try:
            path = self.backend_dir / MACHINE_ACCOUNT_POOL_TXT
            if not path.exists():
                return []
            all_set = set(int(x) for x in (all_accounts or []))
            vault = self._load_login_vault()
            email_to_no = {}
            for k, rec in (vault.get("accounts") or {}).items():
                m = re.search(r"google_(\d+)", str(k))
                email = str((rec or {}).get("email") or "").strip().lower()
                if m and email:
                    email_to_no[email] = int(m.group(1))
            out, seen = [], set()
            for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                token = re.split(r"[\s,;=]+", line, maxsplit=1)[0].strip()
                acc = None
                m = re.search(r"google_(\d+)", token, re.I) or re.fullmatch(r"(\d+)", token)
                if m:
                    acc = int(m.group(1))
                elif "@" in token:
                    acc = email_to_no.get(token.lower())
                if acc and acc in all_set and acc not in seen:
                    seen.add(acc); out.append(acc)
            return out[:max(1, int(MACHINE_ACCOUNT_POOL_LIMIT or 20))]
        except Exception as e:
            try: self.append_log(f"[machine-pool] đọc {MACHINE_ACCOUNT_POOL_TXT} lỗi nhẹ: {e}")
            except Exception: pass
            return []

    def _machine_account_pool(self, all_accounts=None):
        """v13.54 FULL VAULT: không còn khóa máy vào 20 mail cố định.

        Trả về TOÀN BỘ account trong vault. Thứ tự thực tế khi cấp worker sẽ do
        _sorted_candidate_accounts() quyết định: profile/marker tốt + lịch sử thành công
        được ưu tiên trước, account lỗi/quota được đẩy xuống sau hoặc loại trong lượt.

        machine_accounts.txt / machine_account_pool.json cũ không còn giới hạn scheduler.
        Giữ hàm này để tương thích các nhánh cache/prune cũ.
        """
        try:
            all_accounts = list(dict.fromkeys(int(a) for a in (all_accounts or self._vault_account_numbers() or [])))
            all_accounts.sort()
            if not all_accounts:
                return []
            ordered = self._sorted_candidate_accounts(all_accounts)
            if not getattr(self, "_machine_pool_logged", False):
                self._machine_pool_logged = True
                try:
                    self.append_log(
                        f"[account-pool] v13.54 FULL VAULT • dùng toàn bộ {len(ordered)} mail trong kho; "
                        "không còn giới hạn pool 20 • ưu tiên mail/profile tốt trước"
                    )
                except Exception:
                    pass
            return ordered
        except Exception as e:
            try:
                self.append_log(f"[account-pool] FULL VAULT lỗi nhẹ, fallback toàn bộ kho: {e}")
            except Exception:
                pass
            try:
                return list(dict.fromkeys(int(a) for a in (all_accounts or [])))
            except Exception:
                return list(all_accounts or [])

    def _strict_ready_account_numbers(self):
        """V21 Web: account dùng khi Chạy phải đã READY trong Kho tài khoản. Không tự đăng nhập ở runtime."""
        ready = []
        allow = getattr(self, "_web_strict_ready_accounts", None)
        allow = set(int(a) for a in (allow or []) if str(a).strip().lstrip("-").isdigit())
        for r in list(getattr(self, "rows", []) or []):
            try:
                acc = int(r.account_no())
                if allow and acc not in allow:
                    continue
                if not bool(getattr(r, "ok", False)):
                    continue
                if not r.profile_path().exists():
                    continue
                try:
                    self._clear_account_force_login(acc)
                except Exception:
                    pass
                if acc not in ready:
                    ready.append(acc)
            except Exception:
                pass
        return self._sorted_candidate_accounts(ready)

    def _replace_account_in_machine_pool(self, old_account, reason=""):
        """v13.54: tương thích tên hàm cũ; chọn mail thay thế từ TOÀN BỘ vault.

        Không ghi/chỉnh machine_account_pool.json nữa vì scheduler không còn pool 20.
        """
        try:
            old_acc = int(old_account)
        except Exception:
            return None
        try:
            all_accounts = (self._strict_ready_account_numbers() if RUN_READY_ONLY_NO_LOGIN else self._sorted_candidate_accounts(self._vault_account_numbers() or []))
            held_now = set(self._daily_quota_held_accounts() or set())
            busy = set(getattr(self, 'active_accounts', set()) or set()) | self._active_worker_accounts()
            exhausted = set(getattr(self, 'exhausted_accounts', set()) or set())
            for acc in all_accounts:
                try:
                    acc = int(acc)
                except Exception:
                    continue
                if acc == old_acc or acc in held_now or acc in busy or acc in exhausted:
                    continue
                if self._account_cooldown_remaining(acc) > 0:
                    continue
                try:
                    self.append_log(f"[account-pool] FULL VAULT thay A{old_acc} -> A{acc} • {reason or 'rotate account'}")
                except Exception:
                    pass
                return acc
            return None
        except Exception as e:
            try:
                self.append_log(f"[account-pool] tìm mail thay thế FULL VAULT lỗi nhẹ: {e}")
            except Exception:
                pass
            return None

    def _should_rotate_account_after_error(self, account_no, err_type=""):
        try:
            et = str(err_type or '').lower()
            if et in ('session_fail', 'login_fail', 'logged_out', 'quota', 'account_verify_required', 'robot_check'):
                return True, 'mất phiên/hết lượt/xác minh Google'
            # v12.95: "Image Editing Request Denied" là account bị Gemini từ chối vẽ ảnh hiện tại.
            # Không giữ account đến cuối batch vì sẽ kéo chậm; đổi mail ngay.
            if et in ('gemini_refusal', 'image_editing_request_denied'):
                return True, 'Gemini Image Editing Request Denied → đổi account ngay'
            perf = self._get_account_perf(account_no)
            draw_like = {'upload_fail', 'capture_fail', 'validate_fail', 'transient_ui_fail', 'generic_fail'}
            if et in draw_like:
                errors = int(perf.get('job_errors', 0) or 0)
                if errors >= max(2, int(ACCOUNT_ROTATE_AFTER_DRAW_ERRORS or 3)):
                    return True, f'lỗi vẽ {errors} lần'
            return False, ''
        except Exception:
            return False, ''

    def _configured_accounts(self):
        """v13.54: scheduler nhìn thấy TOÀN BỘ mail trong vault ở mỗi lần Chạy queue.

        - Chỉ loại account đã được Gemini xác nhận quota SAU Send trong chính lượt hiện tại.
        - Manual bấm Chạy queue mới sẽ mở lại quota-hold để thử thật lần nữa.
        - Thứ tự luôn qua health score để mail/profile tốt chạy trước.
        """
        pool = self._vault_account_numbers()
        if pool:
            held_now = set(self._daily_quota_held_accounts() or set())
            if RUN_READY_ONLY_NO_LOGIN:
                ready_pool = self._strict_ready_account_numbers()
                available = [int(a) for a in ready_pool if int(a) not in held_now]
                ordered = self._sorted_candidate_accounts(available)
                try:
                    self.append_log(f"[V21-READY-POOL] scheduler chỉ thấy {len(ordered)} account READY trong Kho • AUTO-LOGIN=OFF")
                except Exception:
                    pass
            else:
                available = [int(a) for a in pool if int(a) not in held_now]
                ordered = self._sorted_candidate_accounts(available)
            sig = (len(pool), len(held_now))
            if sig != getattr(self, '_full_vault_log_signature', None):
                self._full_vault_log_signature = sig
                try:
                    self.append_log(
                        f"[account-pool] FULL VAULT sẵn sàng {len(ordered)}/{len(pool)} mail • "
                        f"đã xác nhận quota trong lượt này={len(held_now)} • ưu tiên mail tốt trước"
                    )
                except Exception:
                    pass
            return ordered

        # Fallback khi chưa có vault: dùng toàn bộ profile/UI khả dụng, không cắt 20 mail.
        ready, fallback = [], []
        for r in self.rows:
            try:
                acc = r.account_no()
                if not r.profile_path().exists():
                    continue
                if getattr(r, "ok", False):
                    if acc not in ready:
                        ready.append(acc)
                elif acc not in fallback:
                    fallback.append(acc)
            except Exception:
                pass
        ordered, seen = [], set()
        for acc in ready + fallback:
            if acc not in seen:
                seen.add(acc)
                ordered.append(acc)
        return self._sorted_candidate_accounts(ordered)

    def _profile_ready_for_fast_draw(self, account_no):
        """v12.94: Start straight from cached profile.
        Nếu profile trong FULL VAULT đã có dữ liệu Chrome/marker thì cho worker chạy ngay.
        Chỉ account có force marker mất phiên mới bị loại và đổi mail khác.
        Nếu session thật sự chết, worker sẽ báo SESSION_FAIL rồi manager tự rotate sang mail dự phòng.
        """
        try:
            acc = int(account_no)
            prof = self._profile_dir_for_account(acc)
            if not prof.exists():
                return False, "profile chưa có thư mục"
            if self._force_login_marker_path_for_account(acc).is_file():
                return False, "profile bị đánh dấu mất phiên"
            if not _profile_has_login_data(prof):
                return False, "profile chưa có dữ liệu Chrome"
            ok_marker, marker_msg = self._account_login_marker_valid(acc)
            if not ok_marker:
                if FAST_REUSE_MODE and FAST_REUSE_ASSUME_PROFILE_OK:
                    return True, "profile có dữ liệu Chrome, chạy thẳng; lỗi thì worker tự báo SESSION_FAIL để đổi mail"
                return False, "profile có dữ liệu nhưng chưa có marker login/live-check OK"
            try:
                verify_marker = str(os.environ.get("GEMINI_VERIFY_MARKER_LOGIN", "0")).strip().lower() not in ("0", "false", "no", "off")
                if verify_marker:
                    ok, msg = qt_hidden_check_gemini_logged_in(self.chrome_binary, self.driver_binary, prof, stop_event=self._check_stop_event)
                    if ok:
                        self._mark_account_login_ok(acc, msg)
                        return True, f"{marker_msg} + hidden-check Gemini OK"
                    if FAST_REUSE_MODE and FAST_REUSE_ASSUME_PROFILE_OK:
                        return True, f"{marker_msg} nhưng hidden-check chưa login; vẫn chạy thẳng, lỗi thì đổi mail"
                    return False, f"{marker_msg} nhưng Gemini chưa login: {str(msg)[:100]}"
            except Exception as e:
                if FAST_REUSE_MODE and FAST_REUSE_ASSUME_PROFILE_OK:
                    return True, f"{marker_msg} nhưng hidden-check lỗi nhẹ; chạy thẳng profile cache: {type(e).__name__}"
                return False, f"{marker_msg} nhưng hidden-check lỗi, cần login lại: {type(e).__name__}"
            return True, marker_msg
        except Exception as e:
            return False, f"check profile lỗi: {str(e)[:80]}"

    def _build_account_maps_for_workers(self, accounts, workers_count):
        """Chia account trong pool cố định của máy thành nhóm không trùng nhau cho từng worker.
        v12.66: khi Fast Reuse bật, chỉ đưa profile đã sẵn sàng vào worker vẽ.
        Account chưa có profile hoặc bị mất phiên không bị login hàng loạt trong lúc chạy batch.
        """
        held_today = self._daily_quota_held_accounts()
        if RUN_READY_ONLY_NO_LOGIN:
            strict_ready = set(self._strict_ready_account_numbers())
            accounts = [int(a) for a in accounts if int(a) in strict_ready]
            accounts = [int(a) for a in accounts if int(a) not in held_today and self._account_cooldown_remaining(int(a)) <= 0]
            accounts = self._sorted_candidate_accounts(accounts)
            requested = max(1, int(workers_count or 1))
            if not accounts:
                try:
                    self.append_log(f"[V21-RUN-GATE] BLOCK core • READY usable=0 < workers={requested} • không login bù")
                except Exception:
                    pass
                return []
            if len(accounts) < requested:
                requested = len(accounts)
            selected = accounts[:requested]
            self._mark_accounts_selected(selected)
            try:
                self.append_log("[V21-RUN-GATE] READY selected: " + ",".join(f"A{x}" for x in selected) + " • AUTO-LOGIN=OFF")
            except Exception:
                pass
            return [[a] for a in selected]
        accounts = [
            int(a) for a in list(dict.fromkeys(int(a) for a in accounts))
            if int(a) not in held_today and self._account_cooldown_remaining(int(a)) <= 0
        ]
        accounts = self._sorted_candidate_accounts(accounts)
        if not accounts:
            return []

        if FAST_REUSE_MODE and FAST_REUSE_READY_ONLY:
            ready, not_ready = [], []
            for acc in accounts:
                ok, why = self._profile_ready_for_fast_draw(acc)
                if ok:
                    ready.append(acc)
                else:
                    not_ready.append((acc, why))

            max_fast = max(1, int(FAST_REUSE_MAX_WORKERS or 8))
            requested = max(1, min(int(workers_count or 1), max_fast, len(accounts)))
            first_run_target = max(1, min(int(FIRST_RUN_BOOTSTRAP_WORKERS or 8), requested, len(accounts)))

            if ready:
                # v12.77: nếu máy mới chỉ có một vài profile sẵn, không giảm xuống 1-2 luồng nữa.
                # Lấy thêm account chưa sẵn sàng để worker tự login trước khi vẽ, đủ số luồng người dùng chọn.
                need_more = max(0, requested - len(ready))
                fillers = [a for a, _w in not_ready[:need_more]]
                if fillers:
                    try:
                        sample = ", ".join(f"A{a}" for a in fillers[:8])
                        self.append_log(f"[first-run-login] có {len(ready)} profile sẵn • thêm {len(fillers)} account cần login để đủ {requested} luồng: {sample}")
                    except Exception:
                        pass
                accounts = (ready + fillers)[:requested]
                workers_count = max(1, min(requested, len(accounts)))
                if not_ready and not fillers:
                    try:
                        sample = ", ".join(f"A{a}({w})" for a, w in not_ready[:8])
                        more = f" ... +{len(not_ready)-8}" if len(not_ready) > 8 else ""
                        self.append_log(f"[fast-ready] còn {len(not_ready)} account chưa sẵn sàng, sẽ bootstrap nền sau: {sample}{more}")
                    except Exception:
                        pass
            else:
                if FAST_REUSE_BOOTSTRAP_IF_NONE_READY and accounts:
                    # v12.77: máy mới/lần đầu chạy phải tự chuẩn bị đủ số luồng đã chọn, không chỉ 1 account.
                    accounts = accounts[:first_run_target]
                    workers_count = first_run_target
                    try:
                        self.append_log(f"[first-run-login] máy mới/chưa có profile sẵn • khởi động {workers_count} worker, login song song tối đa {ACCOUNT_POOL_LOGIN_PARALLEL} TK/lượt trước khi vẽ")
                    except Exception:
                        pass
                else:
                    try:
                        self.append_log("[fast-ready] chưa có profile sẵn sàng và bootstrap bị tắt; không có worker để chạy")
                    except Exception:
                        pass
                    return []

        # v13.48.2: bỏ random.shuffle. Ưu tiên profile tốt, lịch sử thành công,
        # ít lỗi và account lâu chưa được chọn để tránh thử lại account xấu.
        accounts = self._sorted_candidate_accounts(accounts)
        workers_count = max(1, min(int(workers_count), len(accounts)))
        per_worker = max(1, int(ACCOUNT_ROTATE_POOL_PER_WORKER or 1))
        limit = min(len(accounts), workers_count * per_worker)
        selected = accounts[:limit]
        self._mark_accounts_selected(selected)
        groups = [[] for _ in range(workers_count)]
        for i in range(workers_count):
            groups[i].append(selected[i])
        for idx, acc in enumerate(selected[workers_count:]):
            groups[idx % workers_count].append(acc)
        return groups

    def _ensure_accounts_logged_in_hidden(self, account_numbers):
        """Đăng nhập/ngầm hoàn tất onboarding Gemini cho account được chọn trước khi clone profile vào worker."""
        account_numbers = list(dict.fromkeys(int(a) for a in account_numbers))
        if not account_numbers:
            return
        self.append_log(f"[account-pool] chuẩn bị đăng nhập ngầm {len(account_numbers)} tài khoản được chọn")
        for acc in account_numbers:
            email, password, recovery_email = self._get_login_credential(acc)
            if not email or not password:
                self.append_log(f"[account-pool] A{acc}: thiếu email/mật khẩu trong vault, vẫn thử dùng profile sẵn có")
                continue
            try:
                ok, msg = _auto_google_login_once(self.chrome_binary, self.driver_binary, self.backend_dir / "profiles" / f"google_{acc}", email, password, recovery_email, log_fn=self.append_log, stop_event=self._check_stop_event, hidden=True, proxy_value=self._proxy_value_for_account(acc))
                self.append_log(f"[account-pool] A{acc}: {'OK' if ok else 'WARN'} • {msg}")
            except Exception as e:
                self.append_log(f"[account-pool] A{acc}: login ngầm lỗi nhẹ: {e}")

    def _thread_log(self, msg):
        try:
            self.ui_queue.put(("log", str(msg)))
        except Exception:
            try:
                self.append_log(str(msg))
            except Exception:
                pass

    def _login_account_profile_if_needed(self, account_no, prefix="[bootstrap-login]"):
        """v12.77: đăng nhập 1 profile nếu thiếu/mất phiên. Dùng được trong thread nền."""
        if RUN_READY_ONLY_NO_LOGIN:
            self._thread_log(f"[V21-NO-LOGIN] A{account_no}: từ chối auto-login runtime • hãy xử lý trong Kho tài khoản")
            return False
        try:
            acc = int(account_no)
        except Exception:
            return False
        try:
            need_login, why = self._account_needs_auto_login(acc)
        except Exception as e:
            need_login, why = True, f"check lỗi: {type(e).__name__}: {str(e)[:120]}"
        if not need_login:
            self._thread_log(f"{prefix} A{acc}: đã sẵn sàng • {why}")
            return True
        email, password, recovery_email = self._get_login_credential(acc)
        if not email or not password:
            self._thread_log(f"{prefix} A{acc}: cần login nhưng thiếu email/mật khẩu • {why}")
            return False
        try:
            sem = getattr(self, "_pool_login_semaphore", None)
            if sem is None:
                sem = threading.Semaphore(max(1, int(ACCOUNT_POOL_LOGIN_PARALLEL)))
                self._pool_login_semaphore = sem
            with sem:
                if getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
                    return False
                visible_debug = str(os.environ.get("GEMINI_VISIBLE_DEBUG", "0")).strip().lower() in ("1", "true", "yes", "on")
                login_proxy = self._proxy_value_for_account(acc) if LOGIN_USE_PROXY else ""
                self._thread_log(f"{prefix} A{acc}: login vì {why} • login song song tối đa {ACCOUNT_POOL_LOGIN_PARALLEL}")
                ok, msg = _auto_google_login_once(
                    self.chrome_binary,
                    self.driver_binary,
                    self.backend_dir / "profiles" / f"google_{acc}",
                    email,
                    password,
                    recovery_email,
                    log_fn=lambda m: self._thread_log(m),
                    stop_event=self._check_stop_event,
                    hidden=(not visible_debug),
                    proxy_value=login_proxy,
                )
                if ok:
                    self._mark_account_login_ok(acc, msg)
                elif _qt_is_account_verify_message(msg):
                    try:
                        self._mark_account_force_login(acc, msg)
                        self._mark_account_exhausted(acc, reason_type="verify", message=msg)
                        self._replace_account_in_machine_pool(acc, "Google verify required")
                    except Exception:
                        pass
                    self._thread_log(f"{prefix} A{acc}: BỎ QUA • Google yêu cầu xác minh danh tính, chuyển tài khoản khác")
                self._thread_log(f"{prefix} A{acc}: {'OK' if ok else 'WARN'} • {msg}")
                return bool(ok)
        except Exception as e:
            self._thread_log(f"{prefix} A{acc}: login lỗi nhẹ: {type(e).__name__}: {str(e)[:160]}")
            return False

    def _setup_initial_login_barrier(self, selected_accounts):
        """v12.91: mặc định KHÔNG chờ đủ worker. Account nào login/profile OK trước thì vẽ trước."""
        try:
            if FIRST_RUN_START_AS_SOON_AS_READY:
                self._initial_login_barrier_accounts = set()
                self._initial_login_barrier_done = set()
                self._initial_login_barrier_cond = None
                try:
                    if RUN_READY_ONLY_NO_LOGIN:
                        self.append_log("[V22-READY-START] profile READY nào được chọn thì mở Gemini headless ngay • không có login nền")
                    else:
                        self.append_log("[start-now] bật tối ưu thời gian: TK nào đăng nhập/profile OK trước thì chạy vẽ ngay; TK khác vẫn login nền")
                except Exception:
                    pass
                return
            selected = []
            for a in selected_accounts or []:
                try:
                    ia = int(a)
                    if ia not in selected:
                        selected.append(ia)
                except Exception:
                    pass
            need_any = False
            for a in selected:
                try:
                    need, _why = self._account_needs_auto_login(a)
                    if need:
                        need_any = True
                        break
                except Exception:
                    need_any = True
                    break
            if len(selected) <= 1 or not need_any:
                self._initial_login_barrier_accounts = set()
                self._initial_login_barrier_done = set()
                self._initial_login_barrier_cond = None
                return
            self._initial_login_barrier_accounts = set(selected)
            self._initial_login_barrier_done = set()
            self._initial_login_barrier_cond = threading.Condition()
            self._initial_login_barrier_deadline = time.monotonic() + max(60.0, float(FIRST_RUN_LOGIN_BARRIER_TIMEOUT or 1200))
            self.append_log(f"[first-run-login] sẽ đợi {len(selected)} TK worker đăng nhập/check xong rồi mới bắt đầu vẽ: " + ",".join(f"A{x}" for x in selected))
        except Exception as e:
            try:
                self.append_log(f"[first-run-login] setup barrier lỗi nhẹ: {e}")
            except Exception:
                pass
            self._initial_login_barrier_accounts = set()
            self._initial_login_barrier_done = set()
            self._initial_login_barrier_cond = None

    def _initial_login_barrier_arrive_and_wait(self, state):
        try:
            accounts = set(getattr(self, "_initial_login_barrier_accounts", set()) or set())
            if not accounts:
                return
            acc = int(getattr(state, "account_no", 0) or 0)
            if acc not in accounts:
                return
            cond = getattr(self, "_initial_login_barrier_cond", None)
            if cond is None:
                return
            with cond:
                self._initial_login_barrier_done.add(acc)
                done = len(self._initial_login_barrier_done)
                total = len(accounts)
                self.ui_queue.put(("log", f"[first-run-login] W{state.worker_id}/A{acc}: profile đã check/login xong • {done}/{total}"))
                cond.notify_all()
                while len(self._initial_login_barrier_done) < len(accounts):
                    if getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
                        return
                    if time.monotonic() > float(getattr(self, "_initial_login_barrier_deadline", 0) or 0):
                        self.ui_queue.put(("log", f"[first-run-login] hết thời gian chờ đủ {total} TK • tiếp tục chạy với TK đã sẵn sàng"))
                        cond.notify_all()
                        return
                    cond.wait(timeout=1.0)
                self.ui_queue.put(("log", f"[first-run-login] đủ {total}/{total} TK worker • bắt đầu vẽ đồng loạt"))
        except Exception as e:
            try:
                self.ui_queue.put(("log", f"[first-run-login] barrier lỗi nhẹ: {e}"))
            except Exception:
                pass

    def _start_background_bootstrap_remaining_profiles(self, all_accounts, selected_accounts=None):
        """v13.54: bootstrap nền chỉ chuẩn bị một nhóm nhỏ để tránh login storm; KHÔNG giới hạn scheduler FULL VAULT."""
        try:
            if RUN_READY_ONLY_NO_LOGIN:
                self.ui_queue.put(("log", "[V21-NO-LOGIN] background bootstrap=OFF • đăng nhập chỉ thực hiện trong Kho tài khoản"))
                return
            if not BACKGROUND_BOOTSTRAP_20_ENABLED:
                self.ui_queue.put(("log", "[bg-login-20] v13.30: đã tắt chuẩn bị nền các tài khoản còn lại để tránh mở nhiều cửa sổ Chrome login"))
                return
            if getattr(self, "_background_bootstrap_running", False):
                return
            selected = {int(a) for a in (selected_accounts or []) if str(a).strip().lstrip("-").isdigit()}
            pool = []
            for a in list(all_accounts or [])[:max(1, int(MACHINE_ACCOUNT_POOL_LIMIT or 20))]:
                try:
                    ia = int(a)
                    if ia not in pool:
                        pool.append(ia)
                except Exception:
                    pass
            todo = [a for a in pool if a not in selected]
            if not todo:
                return
            self._background_bootstrap_running = True
            self.ui_queue.put(("log", f"[bg-login-20] bootstrap nền tối đa {len(todo)} TK (scheduler vẫn dùng FULL VAULT)" + (f" sau {BACKGROUND_BOOTSTRAP_DELAY_SECONDS:.0f}s" if float(BACKGROUND_BOOTSTRAP_DELAY_SECONDS or 0) > 0 else " ngay bây giờ")))

            def _work():
                try:
                    time.sleep(max(0.0, float(BACKGROUND_BOOTSTRAP_DELAY_SECONDS or 0)))
                    for acc in todo:
                        if getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
                            break
                        if not getattr(self, "running", False):
                            break
                        try:
                            if acc in set(getattr(self, "active_accounts", set()) or set()):
                                continue
                        except Exception:
                            pass
                        self._login_account_profile_if_needed(acc, prefix="[bg-login-20]")
                    self._thread_log("[bg-login-20] hoàn tất bootstrap nền; scheduler FULL VAULT không bị giới hạn")
                finally:
                    try:
                        self._background_bootstrap_running = False
                    except Exception:
                        pass

            threading.Thread(target=_work, name="BackgroundBootstrap20", daemon=True).start()
        except Exception as e:
            try:
                self.ui_queue.put(("log", f"[bg-login-20] lỗi nhẹ: {e}"))
            except Exception:
                pass


    # ---------- v12.61: reuse profile trước, chỉ login lại khi thật sự mất phiên ----------
    def _profile_dir_for_account(self, account_no):
        return self.backend_dir / "profiles" / f"google_{int(account_no)}"

    def _login_marker_path_for_account(self, account_no):
        return self._profile_dir_for_account(account_no) / PROFILE_LOGIN_OK_MARKER

    def _force_login_marker_path_for_account(self, account_no):
        return self._profile_dir_for_account(account_no) / PROFILE_FORCE_LOGIN_MARKER

    def _mark_account_force_login(self, account_no, reason=""):
        """v12.64: worker báo session_fail thì lần sau login lại đúng profile đó."""
        try:
            prof = self._profile_dir_for_account(account_no)
            prof.mkdir(parents=True, exist_ok=True)
            data = {"version": "12.68", "account": int(account_no), "time": time.time(), "reason": str(reason or "")[:240]}
            self._force_login_marker_path_for_account(account_no).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            try:
                self._login_marker_path_for_account(account_no).unlink(missing_ok=True)
            except Exception:
                pass
        except Exception:
            pass

    def _clear_account_force_login(self, account_no):
        try:
            self._force_login_marker_path_for_account(account_no).unlink(missing_ok=True)
        except Exception:
            pass

    def _mark_account_login_ok(self, account_no, message=""):
        try:
            prof = self._profile_dir_for_account(account_no)
            prof.mkdir(parents=True, exist_ok=True)
            data = {
                "version": "12.68",
                "account": int(account_no),
                "time": time.time(),
                "message": str(message or "")[:200],
                "note": "Profile đã vào được Gemini. Lần sau ưu tiên dùng lại, không login lại nếu marker còn hạn.",
            }
            self._login_marker_path_for_account(account_no).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            self._clear_account_force_login(account_no)
        except Exception:
            pass

    def _account_login_marker_valid(self, account_no):
        try:
            path = self._login_marker_path_for_account(account_no)
            if not path.is_file():
                return False, "chưa có marker"
            data = json.loads(path.read_text(encoding="utf-8", errors="ignore") or "{}")
            ts = float(data.get("time") or 0)
            max_age = max(1, int(PROFILE_REUSE_DAYS or 21)) * 86400
            if ts > 0 and (time.time() - ts) <= max_age:
                return True, f"marker OK {int((time.time()-ts)/3600)}h"
            return False, "marker cũ/hết hạn"
        except Exception as e:
            return False, f"marker lỗi: {str(e)[:80]}"

    def _account_needs_auto_login(self, account_no):
        """Trả về (need_login, reason). Ưu tiên dùng lại profile; chỉ login khi thiếu/mất phiên."""
        try:
            acc = int(account_no)
            prof = self._profile_dir_for_account(acc)
            # v12.64: nếu profile chưa tồn tại thì tạo ngay, tránh worker crash WinError 3 trước khi login lần đầu.
            if not prof.exists():
                try:
                    prof.mkdir(parents=True, exist_ok=True)
                    try:
                        _prepare_chromium_no_browser_signin_profile(prof, log_fn=None)
                    except Exception:
                        pass
                except Exception:
                    pass
                return True, "profile mới tạo, cần login lần đầu"
            force_marker = self._force_login_marker_path_for_account(acc)
            if force_marker.is_file():
                return True, "worker báo mất phiên/đăng xuất ở lần trước"
            if not _profile_has_login_data(prof):
                return True, "profile chưa có dữ liệu Chrome"
            ok_marker, marker_msg = self._account_login_marker_valid(acc)
            if ok_marker:
                # FIX v12.88: marker OK chỉ chứng minh lần trước đã login, không chứng minh phiên Google/Gemini còn sống.
                # Nếu session hết hạn mà vẫn tin marker, worker sẽ vào Gemini, thấy Sign in rồi SESSION_FAIL hàng loạt.
                verify_marker = str(os.environ.get("GEMINI_VERIFY_MARKER_LOGIN", "1")).strip().lower() not in ("0", "false", "no", "off")
                if verify_marker:
                    try:
                        ok, msg = qt_hidden_check_gemini_logged_in(self.chrome_binary, self.driver_binary, prof, stop_event=self._check_stop_event)
                        if ok:
                            self._mark_account_login_ok(acc, msg)
                            return False, f"{marker_msg} + hidden-check Gemini OK"
                        return True, f"{marker_msg} nhưng hidden-check chưa login: {str(msg)[:120]}"
                    except Exception as e:
                        if not FAST_REUSE_ASSUME_PROFILE_OK:
                            return True, f"{marker_msg} nhưng hidden-check lỗi, cần login lại: {type(e).__name__}: {str(e)[:100]}"
                        return False, f"{marker_msg} • hidden-check lỗi nhẹ, tạm dùng lại profile: {type(e).__name__}"
                return False, marker_msg
            # v12.64 Fast Reuse: nếu profile đã có dữ liệu Chrome thì chạy luôn, không mở hidden-check dài.
            # Nếu thật sự bị đăng xuất, worker sẽ báo lỗi đăng nhập và lần sau mới login lại profile đó.
            if FAST_REUSE_MODE and FAST_REUSE_ASSUME_PROFILE_OK:
                return False, "Fast Reuse: profile có dữ liệu Chrome, bỏ hidden-check để vào việc nhanh"
            # Fallback safe mode: check nhanh Gemini bằng clone để không làm bẩn profile gốc.
            # Không dùng proxy ở bước check/login để tránh Google checkpoint do đổi IP.
            try:
                ok, msg = qt_hidden_check_gemini_logged_in(self.chrome_binary, self.driver_binary, prof, stop_event=self._check_stop_event)
                if ok:
                    self._mark_account_login_ok(acc, msg)
                    return False, "hidden-check Gemini OK"
                return True, f"hidden-check chưa login: {str(msg)[:120]}"
            except Exception as e:
                # v12.89: check lỗi thì KHÔNG được cho worker vẽ ngay, vì Gemini có thể đang hiện Sign in.
                return True, f"hidden-check lỗi, cần login lại trước khi vẽ: {type(e).__name__}: {str(e)[:80]}"
        except Exception as e:
            return True, f"kiểm tra profile lỗi: {str(e)[:120]}"

    def _filter_live_proxy_pool_for_run(self, proxy_pool):
        """v12.61: lọc proxy chết trước khi gắn worker; proxy lỗi thì tự fallback IP gốc."""
        raw = [str(x or "").strip() for x in (proxy_pool or []) if str(x or "").strip()]
        raw = [x for x in raw if _dash_parse_proxy_value(x)]
        if not raw or not PROXY_SAFE_CHECK:
            return raw
        try:
            import concurrent.futures
            good = []
            bad = []
            def one(pv):
                ok, msg, ip = _dash_check_proxy_value(pv, timeout=FAST_PROXY_CHECK_TIMEOUT)
                return pv, ok, msg, ip
            with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, min(8, len(raw)))) as ex:
                futs = [ex.submit(one, pv) for pv in raw]
                for fut in concurrent.futures.as_completed(futs):
                    try:
                        pv, ok, msg, ip = fut.result()
                    except Exception as e:
                        pv, ok, msg, ip = "", False, str(e), ""
                    if ok:
                        good.append(pv)
                    else:
                        bad.append((_dash_mask_proxy_value(pv), msg))
            if bad:
                self.append_log("[proxy-safe] bỏ proxy lỗi: " + "; ".join(f"{m} • {str(msg)[:60]}" for m, msg in bad[:6]))
            if good:
                self.append_log(f"[proxy-safe] dùng {len(good)}/{len(raw)} proxy live cho worker; login/check vẫn dùng IP gốc")
                return good
            self.append_log("[proxy-safe] không có proxy live → tự chạy IP gốc để tránh treo/lỗi Gemini")
            return []
        except Exception as e:
            self.append_log(f"[proxy-safe] check proxy lỗi nhẹ, fallback IP gốc: {e}")
            return []


    def _is_proxy_enabled(self):
        try:
            if hasattr(self, "proxy_toggle_btn"):
                return bool(self.proxy_toggle_btn.isChecked())
        except Exception:
            pass
        return bool(getattr(self, "proxy_enabled", False))

    def _set_proxy_compact_text(self, text):
        try:
            raw = str(text or "")
            enabled = self._is_proxy_enabled()
            count = len(_dash_proxy_raw_list(self.backend_dir))
            label = (f"BẬT ({count} proxy)" if count else "BẬT (chưa có proxy)") if enabled else "TẮT (IP Gốc)"
            tip = raw if raw and raw not in ("Proxy ON", "Proxy OFF") else label
            if hasattr(self, "proxy_status_label"):
                self.proxy_status_label.setText(label)
                self.proxy_status_label.setToolTip(tip)
                self.proxy_status_label.setProperty("active", "true" if enabled else "false")
                self.proxy_status_label.style().unpolish(self.proxy_status_label); self.proxy_status_label.style().polish(self.proxy_status_label)
        except Exception:
            pass

    def _update_proxy_toggle_text(self):
        try:
            enabled = self._is_proxy_enabled()
            count = len(_dash_proxy_raw_list(self.backend_dir))
            if hasattr(self, "proxy_toggle_btn"):
                self.proxy_toggle_btn.setText("●")
                self.proxy_toggle_btn.setProperty("active", "true" if enabled else "false")
                self.proxy_toggle_btn.style().unpolish(self.proxy_toggle_btn); self.proxy_toggle_btn.style().polish(self.proxy_toggle_btn)
            if hasattr(self, "proxy_title_label"):
                self.proxy_title_label.setText("Auto IP 🌐")
            self._set_proxy_compact_text(("Proxy ON" if enabled else "Proxy OFF") + f" • {count}")
        except Exception:
            pass

    def _toggle_proxy_enabled(self):
        try:
            self.proxy_enabled = self._is_proxy_enabled()
            self._update_proxy_toggle_text()
            self.append_log(f"[proxy] {'BẬT' if self.proxy_enabled else 'TẮT'} proxy cho lần chạy tiếp theo")
            self.schedule_save_state()
        except Exception:
            pass

    def _proxy_value_for_account(self, account_no):
        if not self._is_proxy_enabled():
            return ""
        try:
            run_pool = list(getattr(self, "_run_live_proxy_pool", []) or [])
            # Nếu đang trong một lần chạy và Safe Check đã lọc xong, chỉ dùng proxy trong pool live.
            if run_pool:
                direct = _dash_proxy_for_account(self.backend_dir, int(account_no))
                if direct and direct in run_pool and _dash_parse_proxy_value(direct):
                    return direct
                return run_pool[(int(account_no) - 1) % len(run_pool)]
            # Khi chưa start run, vẫn cho manual login đọc direct/raw nếu người dùng bật proxy thủ công.
            direct = _dash_proxy_for_account(self.backend_dir, int(account_no))
            if direct and _dash_parse_proxy_value(direct):
                return direct
            pool = _dash_proxy_raw_list(self.backend_dir)
            if not pool:
                return ""
            return pool[(int(account_no) - 1) % len(pool)]
        except Exception:
            return ""

    def _proxy_list_for_account_map(self, account_map):
        out = []
        for acc in list(account_map or []):
            out.append(self._proxy_value_for_account(acc) or "")
        return out

    def _selected_thumbnail_model(self):
        try:
            combo = getattr(self, "thumb_model_combo", None)
            if combo is not None:
                raw = str(combo.currentData() or combo.currentText() or "auto").strip().lower()
                if raw in ("auto", "flash", "pro"):
                    return raw
        except Exception:
            pass
        return "auto"

    def schedule_save_state(self):
        if self._suspend_state_save or self._save_state_pending:
            return
        self._save_state_pending = True
        QTimer.singleShot(300, self.save_state)

    def load_state(self):
        paths = [self.persist_path] + [p for p in _secondary_persist_paths(self.persist_path)] + [p for p in _legacy_persist_candidates() if p != self.persist_path]
        source = None
        for p in paths:
            try:
                if p.exists() and p.stat().st_size > 0:
                    source = p
                    break
            except Exception:
                pass
        if source is None:
            self._set_state_info(f"chưa thấy file state • sẽ lưu tại {self.persist_path}")
            return False
        try:
            data = json.loads(source.read_text(encoding="utf-8"))
            self.root_edit.setText(data.get("root_folder", ""))
            self.logo_edit.setText(data.get("logo_path", ""))
            try:
                self.project_queue = list(data.get("project_queue", []) or [])[:self.QUEUE_SLOT_MAX]
                self._ensure_project_queue_slots()
                self._refresh_project_queue_ui()
            except Exception:
                self.project_queue = []
            try:
                raw_desc_roots = list(data.get("desc_custom_roots", []) or [])
                clean_desc_roots, seen_desc_roots = [], set()
                for raw_root in raw_desc_roots:
                    root_value = str(raw_root or "").strip()
                    root_key = self._description_root_key(root_value)
                    if root_value and root_key and root_key not in seen_desc_roots:
                        clean_desc_roots.append(root_value); seen_desc_roots.add(root_key)
                self.desc_custom_roots = clean_desc_roots
                self.desc_translate_language = str(data.get("desc_translate_language", "English") or "English")
                if hasattr(self, "desc_language_combo"):
                    idx_lang = self.desc_language_combo.findText(self.desc_translate_language)
                    if idx_lang >= 0:
                        self.desc_language_combo.setCurrentIndex(idx_lang)
                self._refresh_description_sources_ui(force=True)
            except Exception:
                self.desc_custom_roots = []
            try:
                self.worker_spin.setValue(max(1, int(data.get("worker_count", 3))))
            except Exception:
                pass
            try:
                raw_model = str(data.get("thumb_model", "auto") or "auto").strip().lower()
                if raw_model not in ("auto", "flash", "pro"):
                    raw_model = "auto"
                if hasattr(self, "thumb_model_combo"):
                    idx_model = self.thumb_model_combo.findData(raw_model)
                    if idx_model >= 0:
                        self.thumb_model_combo.setCurrentIndex(idx_model)
            except Exception:
                pass
            try:
                self._sidebar_visible = True
                self._apply_sidebar_visibility()
                self._active_workspace = int(data.get("active_workspace", 0) or 0)
            except Exception:
                pass
            try:
                self._theme_mode = str(data.get("theme_mode", "dark") or "dark").lower()
                if self._theme_mode not in ("dark", "light"):
                    self._theme_mode = "dark"
                self._apply_style(); self._update_theme_button()
            except Exception:
                pass
            try:
                self.proxy_enabled = bool(data.get("proxy_enabled", _dash_proxy_enabled_default()))
                if hasattr(self, "proxy_toggle_btn"):
                    self.proxy_toggle_btn.setChecked(self.proxy_enabled)
                self._update_proxy_toggle_text()
                QTimer.singleShot(0, lambda idx=getattr(self, "_active_workspace", 0): self._switch_workspace(idx, save=False))
            except Exception:
                pass
            for r in list(self.rows):
                self.remove_account_row(r)
            accounts = data.get("accounts", [])
            for acc in accounts:
                if isinstance(acc, dict):
                    self.add_account_row(acc.get("account_no") or acc.get("account") or acc.get("no"), acc.get("login_email", ""), acc.get("login_password", ""), acc.get("display_email", ""))
                else:
                    self.add_account_row(acc)
            self._set_state_info(f"load OK từ {source} • save path {self.persist_path}")
            return True
        except Exception as e:
            self._set_state_info(f"load state lỗi từ {source}: {e}", is_error=True)
            return False

    def save_state(self):
        self._save_state_pending = False
        if self._suspend_state_save:
            return False
        data = {
            "root_folder": self.root_edit.text().strip(),
            "logo_path": self.logo_edit.text().strip(),
            "project_queue": list(getattr(self, "project_queue", []) or []),
            "desc_custom_roots": list(getattr(self, "desc_custom_roots", []) or []),
            "desc_translate_language": str(getattr(self, "desc_translate_language", "English") or "English"),
            "worker_count": str(self.worker_spin.value()),
            "thumb_model": str(self._selected_thumbnail_model()),
            "theme_mode": getattr(self, "_theme_mode", "dark"),
            "sidebar_visible": True,
            "active_workspace": int(getattr(self, "_active_workspace", 0)),
            "proxy_enabled": bool(self._is_proxy_enabled()),
            "accounts": [r.as_state() for r in self.rows if r.account_edit.text().strip()],
        }
        raw = json.dumps(data, ensure_ascii=False, indent=2)
        errors, ok_any = [], False
        targets = [self.persist_path] + _secondary_persist_paths(self.persist_path)[:2]
        for target in targets:
            try:
                safe_mkdir(target.parent)
                tmp = target.with_suffix(target.suffix + ".tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(raw)
                    f.flush()
                    try:
                        os.fsync(f.fileno())
                    except Exception:
                        pass
                os.replace(tmp, target)
                ok_any = True
            except Exception as e:
                errors.append(f"{target}: {e}")
        if ok_any:
            return True
        self._set_state_info("save state lỗi • " + " | ".join(errors), is_error=True)
        return False

    def _set_state_info(self, message, is_error=False):
        self.append_log(f"[state] {'ERROR' if is_error else 'INFO'} • {message}")

    # ---------- file/path actions ----------
    def pick_root(self):
        d = QFileDialog.getExistingDirectory(self, "Chọn thư mục cha hoặc thư mục tổng chứa nhiều thư mục cha")
        if d:
            self.root_edit.setText(d)

    def pick_logo(self):
        f, _ = QFileDialog.getOpenFileName(self, "Chọn logo PNG", "", "PNG files (*.png)")
        if f:
            self.logo_edit.setText(f)

    def validate(self):
        root = normalize_path(self.root_edit.text())
        logo = normalize_path(self.logo_edit.text())
        if not Path(root).exists():
            raise ValueError("Thư mục quét không tồn tại.")
        # v12.77: Logo là tuỳ chọn thật sự.
        # Nếu logo trống hoặc đường dẫn logo cũ bị mất => chạy không logo, không chặn quét/chạy.
        if logo:
            if (not Path(logo).exists()) or (not str(logo).lower().endswith(".png")):
                try:
                    self.append_log(f"[logo-optional] bỏ qua logo không hợp lệ/mất file: {logo}")
                    self.logo_edit.blockSignals(True)
                    self.logo_edit.setText("")
                    self.logo_edit.blockSignals(False)
                except Exception:
                    pass
                logo = ""
        if not self.backend_file.exists():
            raise ValueError(f"Không thấy backend worker: {self.backend_file.name}")
        accounts = self._configured_accounts()
        if not accounts:
            held = self._daily_quota_held_accounts()
            if held and self._vault_account_numbers():
                raise ValueError(
                    f"Không còn tài khoản dùng được trong lượt này: {len(held)} tài khoản vẫn đang hết quota. "
                    "Bấm Chạy queue lại để rà soát lại quota các mail này; tool không xóa profile."
                )
            raise ValueError("Chưa có tài khoản trong kho. Hãy bấm Nhập TXT tài khoản trước.")
        workers = max(1, int(self.worker_spin.value()))
        return root, logo, workers, accounts

    def _job_tried_accounts(self, job):
        vals = job.get("tried_accounts") or []
        if not isinstance(vals, list):
            vals = []
        out = []
        for v in vals:
            try:
                iv = int(v)
                if iv not in out:
                    out.append(iv)
            except Exception:
                pass
        return out

    def _remember_job_tried_account(self, job, account_no):
        try:
            acc = int(account_no)
        except Exception:
            return
        tried = self._job_tried_accounts(job)
        if acc not in tried:
            tried.append(acc)
        job["tried_accounts"] = tried

    def _job_can_run_on_account(self, job, account_no):
        try:
            acc = int(account_no)
        except Exception:
            return True
        return acc not in self._job_tried_accounts(job)

    def _job_policy_fail_count(self, job):
        try:
            return int(job.get("policy_fail_count", 0) or 0)
        except Exception:
            return 0

    def _remember_job_policy_fail(self, job, account_no):
        self._remember_job_tried_account(job, account_no)
        job["policy_fail_count"] = self._job_policy_fail_count(job) + 1
        job["last_policy_fail_account"] = account_no

    def _mark_policy_folder_fast_skip_if_needed(self, folder_path, note):
        """Nếu nhiều ảnh cùng folder đều policy, đánh dấu nhanh các ảnh còn chờ của folder đó.
        Tránh chuyển vòng qua nhiều tài khoản rồi vẫn lỗi.
        """
        try:
            folder = self._normalize_cmp_path(folder_path)
            if not folder:
                return 0
            related = [j for j in self.jobs if self._normalize_cmp_path(Path(str(j.get("image_path") or "")).parent) == folder]
            policy_errors = [j for j in related if str(j.get("error_type") or "") in FLOW_POLICY_FAILOVER_ERROR_TYPES or self._job_policy_fail_count(j) > 0]
            if len(policy_errors) < max(1, int(POLICY_FOLDER_FAST_SKIP_THRESHOLD or 3)):
                return 0
            changed = 0
            for j in related:
                if j.get("status") in ("queued", "reserved") and self._job_policy_fail_count(j) > 0:
                    j["status"] = "error"
                    j["worker"] = ""
                    j["error_type"] = "FlowGenerationFailed"
                    j["note"] = note
                    changed += 1
            if changed:
                self.ui_queue.put(("log", f"[policy-guard] folder lỗi policy hàng loạt • khóa nhanh {changed} job còn chờ: {folder_path}"))
                self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            return changed
        except Exception as e:
            self.ui_queue.put(("log", f"[policy-guard] kiểm tra folder lỗi nhẹ: {e}"))
            return 0

    def _job_owned_by_state(self, state, job):
        marker = f"W{getattr(state, 'worker_id', '')}/"
        worker = str(job.get("worker") or "")
        if not worker:
            return True
        return worker.startswith(marker)

    def _worker_home_for_state(self, workers_root, state):
        try:
            return Path(workers_root) / f"worker_{int(state.worker_id)}_independent"
        except Exception:
            return Path(workers_root) / f"worker_{state.worker_id}_independent"

    def _append_worker_skiplist(self, donor_state, stolen_jobs, workers_root):
        """Báo cho worker đang chạy bỏ qua các file đã bị tài khoản rảnh lấy bớt.
        Backend đọc worker_skiplist.json trước mỗi folder, nên không cần kill worker đang chạy.
        """
        try:
            stolen_norm = {self._normalize_cmp_path(j.get("image_path")) for j in (stolen_jobs or [])}
            copied_paths = []
            for original, copied in getattr(donor_state, "path_pairs", []) or []:
                if self._normalize_cmp_path(original) in stolen_norm:
                    copied_paths.append(os.path.abspath(str(copied)))
            if not copied_paths:
                return 0
            skip_path = self._worker_home_for_state(workers_root, donor_state) / "worker_skiplist.json"
            existing = []
            try:
                if skip_path.is_file():
                    data = json.loads(skip_path.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        existing = list(data.get("skip") or [])
                    elif isinstance(data, list):
                        existing = list(data)
            except Exception:
                existing = []
            seen = {self._normalize_cmp_path(x) for x in existing}
            for x in copied_paths:
                k = self._normalize_cmp_path(x)
                if k not in seen:
                    existing.append(x); seen.add(k)
            skip_path.write_text(json.dumps({"skip": existing, "updated_at": time.time()}, ensure_ascii=False, indent=2), encoding="utf-8")
            return len(copied_paths)
        except Exception as e:
            self.ui_queue.put(("log", f"[manager] ghi skiplist cho W{getattr(donor_state,'worker_id','?')} lỗi nhẹ: {e}"))
            return 0

    def _reserved_jobs_for_steal(self, donor_state):
        cur = self._normalize_cmp_path(getattr(donor_state, "current_original_path", None))
        out = []
        for j in getattr(donor_state, "jobs", []) or []:
            if j.get("status") != "reserved":
                continue
            if cur and self._normalize_cmp_path(j.get("image_path")) == cur:
                continue
            out.append(j)
        return out

    def _pick_jobs_to_steal(self, reserved_jobs):
        reserved_jobs = list(reserved_jobs or [])
        if len(reserved_jobs) < max(1, int(WORK_STEAL_MIN_RESERVED or 2)):
            return []
        buckets = self._bucket_jobs_by_parent_folder(reserved_jobs, 2)
        preferred = buckets[1] if len(buckets) > 1 and buckets[1] else reserved_jobs[max(1, len(reserved_jobs)//2):]
        steal = list(preferred)
        if len(steal) > max(1, int(WORK_STEAL_TARGET_BATCH or 8)):
            steal = steal[:max(1, int(WORK_STEAL_TARGET_BATCH or 8))]
        return list(steal)

    def _steal_work_for_available_accounts(self, available_accounts):
        """Khi một tài khoản xong sớm: lấy bớt job CHƯA CHẠY (reserved) từ worker còn bận.
        Không chia nhỏ ngay từ đầu; chỉ cân bằng lại khi đã có account rảnh.
        """
        if not available_accounts:
            return False
        launch = []
        acquired = self.run_lock.acquire(timeout=0.5)
        if not acquired:
            try: self.ui_queue.put(("log", "[lock-fix] steal-work bỏ qua một tick vì run_lock bận"))
            except Exception: pass
            return False
        try:
            self.next_runtime_worker_id = max(self.next_runtime_worker_id, max([w.worker_id for w in self.workers] + [0]) + 1)
            for acc in list(available_accounts):
                donors = []
                for w in self.workers:
                    try:
                        if not (w.proc and w.proc.poll() is None):
                            continue
                        if getattr(w, "account_no", None) == acc:
                            continue
                        reserved = self._reserved_jobs_for_steal(w)
                        if len(reserved) >= max(1, int(WORK_STEAL_MIN_RESERVED or 2)):
                            donors.append((len(reserved), w, reserved))
                    except Exception:
                        pass
                if not donors:
                    continue
                donors.sort(key=lambda x: x[0], reverse=True)
                _count, donor, reserved = donors[0]
                jobs = self._pick_jobs_to_steal(reserved)
                if not jobs:
                    continue
                self._append_worker_skiplist(donor, jobs, self.current_workers_root)
                stolen_norm = {self._normalize_cmp_path(j.get("image_path")) for j in jobs}
                donor.jobs = [j for j in donor.jobs if self._normalize_cmp_path(j.get("image_path")) not in stolen_norm]
                donor.path_pairs = [(o, c) for (o, c) in (getattr(donor, "path_pairs", []) or []) if self._normalize_cmp_path(o) not in stolen_norm]
                donor.total = len(donor.jobs)
                self._recompute_state_counts(donor)

                wid = self.next_runtime_worker_id; self.next_runtime_worker_id += 1
                new_state = WorkerState(wid, acc, jobs)
                new_state.account_map = [acc]; new_state.account_no = acc
                new_state.queue_index = getattr(donor, "queue_index", None)
                new_state.worker_root = getattr(donor, "worker_root", self.current_root_folder)
                new_state.worker_logo = getattr(donor, "worker_logo", self.current_logo_path)
                self.workers.append(new_state); self.active_accounts.add(acc)
                for job in jobs:
                    job["status"] = "reserved"
                    job["worker"] = self._display_worker_label(wid, acc)
                    job["note"] = f"{self._display_tk_label(acc)} rảnh • nhận bớt từ W{donor.worker_id}/{self._display_tk_label(donor.account_no)}"
                launch.append((new_state, jobs, donor))
        finally:
            try: self.run_lock.release()
            except Exception: pass
        if launch:
            self._mark_accounts_selected([new_state.account_no for new_state, _jobs, _donor in launch])
        for new_state, jobs, donor in launch:
            self.ui_queue.put(("log", f"[manager] A{new_state.account_no} đã rảnh • nhận bớt {len(jobs)} job chưa chạy từ W{donor.worker_id}/A{donor.account_no}"))
            self.ui_queue.put(("worker_row", donor.worker_id, donor.account_no, "▶ Đang chạy", "Đã chia bớt job", f"{donor.ok+donor.err+donor.skip}/{donor.total}", donor.current, donor.last_error))
            self.ui_queue.put(("worker_row", new_state.worker_id, new_state.account_no, "🚀 Khởi động", f"Nhận bớt {len(jobs)} job", f"0/{len(jobs)}", "-", "-"))
            threading.Thread(target=self._launch_worker, args=(new_state, getattr(new_state, "worker_root", self.current_root_folder), getattr(new_state, "worker_logo", self.current_logo_path), self.current_workers_root), daemon=True).start()
        if launch:
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            return True
        return False

    def _bucket_jobs_by_parent_folder(self, jobs, slots):
        """Flow Project X4: giữ mọi thumbnail-original trong cùng một thư mục ở cùng một worker.
        Như vậy 1 thư mục = 1 project, cần 3 ảnh thì worker tạo x4 lấy 3; cần 5 ảnh thì tạo 2 round.
        """
        slots = max(1, int(slots or 1))
        buckets = [[] for _ in range(slots)]
        loads = [0 for _ in range(slots)]
        groups = {}
        for job in list(jobs or []):
            try:
                key = os.path.normcase(os.path.normpath(str(Path(job.get("image_path") or "").parent)))
            except Exception:
                key = str(job.get("image_path") or "")
            groups.setdefault(key, []).append(job)
        def _group_order_key(g):
            try:
                qidx = min(int(x.get("queue_index", 9999) if str(x.get("queue_index", "")).lstrip("-").isdigit() else 9999) for x in g)
            except Exception:
                qidx = 9999
            # v12.54: ưu tiên queue trước, nhưng vẫn chia cho worker rảnh ở queue sau khi queue trước ít job.
            return (qidx, str(g[0].get("image_path") if g else "").lower(), -len(g))
        ordered = sorted(groups.values(), key=_group_order_key)
        for group in ordered:
            idx = min(range(slots), key=lambda i: loads[i])
            buckets[idx].extend(group)
            loads[idx] += len(group)
        return buckets

    def _queue_context_for_jobs(self, jobs, root_fallback="", logo_fallback=""):
        jobs = [j for j in (jobs or []) if isinstance(j, dict)]
        qidx = None
        try:
            qvals = [self._job_queue_index(j, 9999) for j in jobs]
            qvals = [q for q in qvals if q < 9999]
            qidx = min(qvals) if qvals else None
        except Exception:
            qidx = None

        root = normalize_path(root_fallback or "")
        logo = normalize_path(logo_fallback or "")
        item = None
        try:
            if qidx is not None and 0 <= int(qidx) < len(getattr(self, "project_queue", []) or []):
                item = (self.project_queue or [])[int(qidx)]
        except Exception:
            item = None
        if not isinstance(item, dict):
            item = {}

        if jobs:
            root = normalize_path(item.get("root") or root or jobs[0].get("queue_root") or jobs[0].get("scan_root") or self.current_root_folder or "")
            logo = normalize_path(item.get("logo") or logo or jobs[0].get("queue_logo") or jobs[0].get("logo_path") or self.current_logo_path or "")
        # v12.77: logo trống/mất file = không chèn logo, không làm Queue lỗi.
        try:
            if logo and ((not Path(logo).exists()) or (not str(logo).lower().endswith(".png"))):
                logo = ""
        except Exception:
            logo = ""
        return qidx, root, logo

    def _bucket_jobs_for_queue_workers(self, jobs, slots):
        """v12.77: chia job theo queue nhưng giữ đủ slot.
        Mỗi bucket/worker vẫn chỉ nhận đúng 1 queue để logo không lẫn.
        Khác bản cũ: không giới hạn theo số parent-folder nữa, vì như vậy Q1 còn 5 job trong 2 folder sẽ tụt 8 -> 2 worker.
        """
        slots = max(1, int(slots or 1))
        queue_map = {}
        for job in list(jobs or []):
            qidx = self._job_queue_index(job, 9999)
            queue_map.setdefault(qidx, []).append(job)

        ordered = [(qidx, qjobs) for qidx, qjobs in sorted(queue_map.items(), key=lambda x: x[0]) if qjobs]
        if not ordered:
            return []

        out = []
        remaining_slots = min(slots, sum(len(qjobs) for _qidx, qjobs in ordered))

        def _split_even(qjobs, n):
            n = max(1, min(int(n or 1), len(qjobs)))
            buckets = [[] for _ in range(n)]
            # Giữ thứ tự file nhưng rải đều để mỗi worker có việc.
            for i, job in enumerate(list(qjobs or [])):
                buckets[i % n].append(job)
            return [b for b in buckets if b]

        # Ưu tiên queue trước lấy slot trước. Nếu Q1 còn 5 job và chọn 8 luồng:
        # Q1 lấy 5 slot, Q2 lấy 3 slot còn lại.
        for qidx, qjobs in ordered:
            if remaining_slots <= 0:
                break
            take = min(len(qjobs), remaining_slots)
            _qidx, qroot, qlogo = self._queue_context_for_jobs(qjobs)
            for bucket in _split_even(qjobs, take):
                out.append({
                    "queue_index": qidx,
                    "root": qroot,
                    "logo": qlogo,
                    "jobs": bucket,
                })
            remaining_slots -= take
        return out


    def scan_only(self):
        """v12.78: bấm Quét file sẽ quét toàn bộ 4 Queue thumb nếu có queue hợp lệ."""
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, hãy đợi xong hoặc bấm Dừng trước khi quét thumb.")
            return
        try:
            self._ensure_project_queue_slots()
            if self._valid_project_queue_indices():
                return self.scan_project_queue_only()
        except Exception:
            pass
        if getattr(self, "_scan_running", False):
            self.append_log("[scan] đang quét, vui lòng đợi xong")
            return
        try:
            root, _logo, _workers, _accounts = self.validate()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e)); return

        # v2.4: không gọi stop_all đồng bộ khi Quét file, vì gần cuối run còn nhiều Chrome/preview
        # sẽ làm Qt Not Responding. Chỉ đặt cờ dừng, kill worker ở thread nền rồi scan.
        try:
            self.stop_requested = True
            self.running = False
            self._check_stop_event.set()
            for w in list(getattr(self, "workers", []) or []):
                try:
                    w.terminate_requested = True
                except Exception:
                    pass
        except Exception:
            pass
        purged = self._purge_pending_ui_events()
        self._reset_runtime_view(keep_jobs=False)
        try:
            self.preview.setUpdatesEnabled(False)
            self.preview.clear()
            self.preview.setUpdatesEnabled(True)
        except Exception:
            pass
        self._scan_running = True
        try:
            self.btn_scan.setEnabled(False)
        except Exception:
            pass
        self.status_label.setText("Đang quét nền + xoá run cũ...")
        self.append_log(f"[scan] bắt đầu quét nền: {root}" + (f" • dọn {purged} event cũ" if purged else "") + " • sẽ xoá toàn bộ run cũ • sau quét hiện đủ file")

        def _run_scan():
            try:
                # v2.4: dừng/kill worker cũ trong thread nền để UI không đơ khi scan lại gần cuối.
                try:
                    for w in list(getattr(self, "workers", []) or []):
                        try:
                            if w.proc and w.proc.poll() is None:
                                self._kill_process_tree(w.proc.pid, timeout=0.45)
                        except Exception:
                            pass
                except Exception:
                    pass
                # v1.7: bấm Quét file là reset run sạch hoàn toàn. Lần Bắt đầu sau sẽ tạo run mới.
                try:
                    self._cleanup_leftover_worker_processes(timeout=0.25)
                except Exception:
                    pass
                deleted, errors = self._delete_run_dirs_quiet(also_reset_current=True)
                self.ui_queue.put(("log", f"[scan] đã xoá {deleted} thư mục run cũ trước khi quét"))
                if errors:
                    self.ui_queue.put(("log", f"[scan] một số run chưa xoá được: {len(errors)} mục"))
                jobs, skipped = scan_jobs(root, logo_path=_logo)
                parent_count = len({str(j.get("direct_parent_root") or j.get("parent_root") or "") for j in jobs if j.get("image_path")})
                self.ui_queue.put(("scan_done", jobs, skipped, parent_count))
            except Exception as e:
                self.ui_queue.put(("scan_error", str(e)))

        threading.Thread(target=_run_scan, daemon=True).start()

    def select_under_half_mb(self):
        try:
            root, _logo, _workers, _accounts = self.validate()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e)); return
        if not self.jobs:
            logo_for_scan = normalize_path(getattr(self, "current_logo_path", None) or self.logo_edit.text())
            self.jobs, skipped = scan_jobs(root, logo_path=logo_for_scan)
            self.stat_cards["total"].set_value(len(self.jobs))
        selected = filtered = 0
        for job in self.jobs:
            current_mb = self._current_file_size_mb(job.get("image_path"))
            size_mb = current_mb if current_mb is not None else float(job.get("size_mb") or 0.0)
            job["size_mb"] = size_mb
            if size_mb < 0.5:
                if job.get("status") not in ("done", "running"):
                    job["status"] = "queued"; job["worker"] = ""; job["note"] = "Đã chọn theo bộ lọc <0.5MB"
                selected += 1
            else:
                if job.get("status") not in ("done", "running"):
                    job["status"] = "skipped"; job["worker"] = ""; job["note"] = "Bỏ qua bởi bộ lọc >=0.5MB"
                filtered += 1
        self.refresh_stats(); self.request_preview_refresh(force=True)
        self.status_label.setText(f"Đã chọn ảnh <0,5MB • {selected} ảnh • bỏ qua {filtered} ảnh")

    def _png_data_from_thumb_source(self, thumb_path):
        if Image is None:
            raise RuntimeError("Thiếu Pillow (PIL)")
        with Image.open(thumb_path) as img:
            img = img.convert("RGB")
            helper = globals().get("_make_png_under_limit")
            if callable(helper):
                return helper(img, RESTORE_MAX_BYTES)
            buf = BytesIO()
            try:
                img.save(buf, format="PNG", optimize=True, compress_level=9)
                data = buf.getvalue()
            finally:
                try:
                    buf.close()
                except Exception:
                    pass
            return data

    def create_thumbs_from_originals(self):
        """Tạo nhiều file thumbnail-original-*-final.png từ thumbnail.jpg để đưa vào hàng job."""
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, hãy đợi xong hoặc bấm Dừng trước khi tạo thumb.")
            return
        if self.running:
            QMessageBox.information(self, APP_TITLE, "Hãy dừng tool trước khi tạo thumb từ gốc.")
            return
        root = normalize_path(self.root_edit.text())
        if not root or not Path(root).exists():
            QMessageBox.warning(self, APP_TITLE, "Hãy chọn Thư mục cha hợp lệ trước.")
            return
        if Image is None:
            QMessageBox.critical(self, APP_TITLE, "Thiếu Pillow (PIL), không thể tạo thumbnail.")
            return

        count, ok = QInputDialog.getInt(
            self,
            APP_TITLE,
            "Nhập số thumb cần tạo cho MỖI thư mục có file thumbnail.jpg:\n"
            "Ví dụ nhập 4 sẽ tạo:\n"
            "thumbnail-original-0-final.png đến thumbnail-original-3-final.png",
            4, 1, 200, 1
        )
        if not ok:
            return

        thumbs = find_thumbnail_jpg_files(Path(root))
        if not thumbs:
            QMessageBox.information(self, APP_TITLE, "Không tìm thấy file thumbnail.jpg nào trong thư mục cha.")
            return

        total_files = len(thumbs) * int(count)
        msg = (
            f"Tạo / ghi đè {total_files} file thumb từ thumb gốc?\n\n"
            f"Số thư mục có thumbnail.jpg: {len(thumbs)}\n"
            f"Số thumb mỗi thư mục: {int(count)}\n"
            "Tên file tạo ra: thumbnail-original-0-final.png, thumbnail-original-1-final.png, ...\n\n"
            "Lưu ý: file trùng tên trong khoảng này sẽ bị ghi đè bằng thumb gốc."
        )
        if QMessageBox.question(self, APP_TITLE, msg) != QMessageBox.Yes:
            return

        success_dirs = failed_dirs = written = 0
        for thumb in thumbs:
            try:
                png_data = self._png_data_from_thumb_source(thumb)
                for idx in range(int(count)):
                    out_path = Path(thumb).parent / f"thumbnail-original-{idx}-final.png"
                    with open(out_path, "wb") as f:
                        f.write(png_data)
                    written += 1
                success_dirs += 1
                self.append_log(f"[thumb-factory] OK • {thumb.parent} • tạo {int(count)} thumb • ~{len(png_data)/1024.0:.1f} KB/file")
            except Exception as e:
                failed_dirs += 1
                self.append_log(f"[thumb-factory] ERROR • {thumb} • {e}")

        try:
            self.jobs, skipped = scan_jobs(root, logo_path=_logo)
            self.stat_cards["total"].set_value(len(self.jobs))
            self.stat_cards["skip"].set_value(skipped)
            self.refresh_stats()
            self.request_preview_refresh(force=True)
        except Exception as e:
            self.append_log(f"[thumb-factory] scan lại lỗi: {e}")

        self.status_label.setText(f"Tạo thumb xong • {written} file • OK {success_dirs} thư mục • Lỗi {failed_dirs}")
        QMessageBox.information(
            self,
            APP_TITLE,
            f"Tạo thumb xong.\nFile đã ghi: {written}\nThư mục thành công: {success_dirs}\nThư mục lỗi: {failed_dirs}"
        )

    def restore_original_thumbnails(self):
        if self.running:
            QMessageBox.information(self, APP_TITLE, "Hãy dừng tool trước khi phục hồi Thumbnail gốc."); return
        root = normalize_path(self.root_edit.text())
        if not root or not Path(root).exists():
            QMessageBox.warning(self, APP_TITLE, "Hãy chọn Thư mục cha hợp lệ trước."); return
        if Image is None:
            QMessageBox.critical(self, APP_TITLE, "Thiếu Pillow (PIL), không thể phục hồi thumbnail."); return
        thumbs = find_thumbnail_jpg_files(Path(root))
        if not thumbs:
            QMessageBox.information(self, APP_TITLE, "Không tìm thấy file thumbnail.jpg nào để phục hồi."); return
        if QMessageBox.question(self, APP_TITLE, f"Phục hồi {len(thumbs)} bộ Thumbnail gốc từ file thumbnail.jpg?\nCác file thumbnail-original-*-final sẽ bị ghi đè.") != QMessageBox.Yes:
            return
        success = failed = 0
        for thumb in thumbs:
            try:
                size_kb, _ = restore_original_thumbnail_set(thumb)
                success += 1
                self.append_log(f"[restore] OK • {thumb} -> ~{size_kb:.1f} KB mỗi file")
            except Exception as e:
                failed += 1
                self.append_log(f"[restore] ERROR • {thumb} • {e}")
        self.status_label.setText(f"Phục hồi xong • OK {success} • Lỗi {failed}")
        try:
            self.jobs, _skipped = scan_jobs(root)
            self.refresh_stats(); self.request_preview_refresh(force=True)
        except Exception:
            pass
        QMessageBox.information(self, APP_TITLE, f"Phục hồi xong.\nThành công: {success}\nLỗi: {failed}")

    def _run_queue_scoped_action(self, idx, callback, refresh_all=True):
        self._ensure_project_queue_slots()
        try:
            idx = int(idx)
        except Exception:
            idx = -1
        if idx < 0 or idx >= len(getattr(self, "project_queue", []) or []):
            QMessageBox.warning(self, APP_TITLE, "Queue không hợp lệ.")
            return False

        item = self.project_queue[idx] or {}
        root = normalize_path(item.get("root") or "")
        logo = normalize_path(item.get("logo") or "")
        if not root or not Path(root).exists():
            QMessageBox.warning(self, APP_TITLE, f"Queue #{idx+1} chưa có thư mục hợp lệ.")
            return False

        old_root = normalize_path(self.root_edit.text())
        old_logo = normalize_path(self.logo_edit.text())
        old_selected = int(getattr(self, "selected_queue_index", -1) or -1)

        try:
            self.selected_queue_index = idx
            self.root_edit.setText(root)
            self.logo_edit.setText(logo)
            callback()
        finally:
            try:
                self.root_edit.setText(old_root)
                self.logo_edit.setText(old_logo)
            except Exception:
                pass
            try:
                self.selected_queue_index = old_selected
            except Exception:
                pass
            try:
                self._refresh_project_queue_ui()
            except Exception:
                pass

        if refresh_all and not self.running:
            try:
                self.scan_project_queue_only()
            except Exception as e:
                try:
                    self.append_log(f"[queue] scan lại sau thao tác Queue #{idx+1} lỗi: {e}")
                except Exception:
                    pass
        return True

    def create_thumbs_for_queue(self, idx):
        return self._run_queue_scoped_action(idx, self.create_thumbs_from_originals, refresh_all=True)

    def restore_thumbs_for_queue(self, idx):
        return self._run_queue_scoped_action(idx, self.restore_original_thumbnails, refresh_all=True)

    def rerun_failed_thumbnails(self):
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, hãy đợi xong hoặc bấm Dừng trước khi chạy lại thumb lỗi."); return
        if self.running:
            QMessageBox.information(self, APP_TITLE, "Đang chạy rồi."); return
        failed = [j for j in self.jobs if j.get("status") == "error"]
        if not failed:
            QMessageBox.information(self, APP_TITLE, "Không có thumbnail lỗi để chạy lại."); return
        for j in failed:
            j["status"] = "queued"; j["note"] = "Chờ chạy lại"; j["worker"] = ""
        self.refresh_stats(); self.request_preview_refresh(force=False)
        self.status_label.setText(f"Chuẩn bị chạy lại {len(failed)} thumbnail lỗi")
        self.start_run()

    def rerun_skipped_thumbnails(self):
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, hãy đợi xong hoặc bấm Dừng trước khi chạy lại thumb bỏ qua."); return
        if self.running:
            QMessageBox.information(self, APP_TITLE, "Đang chạy rồi."); return
        skipped = [j for j in self.jobs if j.get("status") == "skipped"]
        if not skipped:
            QMessageBox.information(self, APP_TITLE, "Không có thumbnail bị bỏ qua để vẽ lại."); return
        for j in skipped:
            j["status"] = "queued"; j["note"] = "Ép chạy lại từ nhóm bị bỏ qua"; j["worker"] = ""
        self.refresh_stats(); self.request_preview_refresh(force=False)
        self.status_label.setText(f"Chuẩn bị vẽ lại {len(skipped)} thumbnail bị bỏ qua")
        self.start_run()

    def _auto_rerun_failed_now(self, round_no=None):
        failed = [j for j in self.jobs if j.get("status") == "error"]
        if not failed:
            self._show_all_jobs_after_finish("auto-rerun-no-failed")
            return False
        if round_no is None:
            round_no = int(getattr(self, 'auto_rerun_round', 0) or 0) + 1
        self.auto_rerun_round = int(round_no)
        for j in failed:
            j["status"] = "queued"
            j["note"] = f"Tự chạy lại vòng {self.auto_rerun_round}"
            j["worker"] = ""
        self.refresh_stats(); self.request_preview_refresh(force=False)
        self.status_label.setText(f"Tự chạy lại {len(failed)} thumbnail lỗi • vòng {self.auto_rerun_round} • đến khi xong")
        self.append_log(f"[auto-rerun] vòng {self.auto_rerun_round}: đưa {len(failed)} job lỗi về hàng chờ và chia lại cho worker")
        self._inside_auto_rerun = True
        try:
            self.start_run()
        finally:
            self._inside_auto_rerun = False
        return True

    # ---------- v78 manifest/resume + filters ----------
    def _save_run_manifest(self, force=False):
        if not self.run_manifest_path:
            return
        now = time.monotonic()
        if not force and now - float(getattr(self, "_last_manifest_save_ts", 0.0) or 0.0) < 1.25:
            return
        lock = getattr(self, '_manifest_save_lock', None)
        acquired = False
        tmp = None
        try:
            if lock is not None:
                acquired = lock.acquire(timeout=1.5 if force else 0.05)
                if not acquired:
                    return
            self._last_manifest_save_ts = now
            data = {
                "version": 2,
                "app": APP_TITLE,
                "root_folder": self.current_root_folder or normalize_path(self.root_edit.text()),
                "logo_path": self.current_logo_path or normalize_path(self.logo_edit.text()),
                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "jobs": {},
            }
            for j in self.jobs:
                path = str(j.get("image_path") or "")
                if not path:
                    continue
                data["jobs"][os.path.normcase(os.path.normpath(path))] = {
                    "path": path,
                    "filename": j.get("filename", ""),
                    "status": j.get("status", ""),
                    "worker": j.get("worker", ""),
                    "note": j.get("note", ""),
                    "size_mb": j.get("size_mb", 0),
                    "error_type": j.get("error_type", ""),
                }
            target = Path(self.run_manifest_path)
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_name(f"{target.name}.{os.getpid()}.{threading.get_ident()}.tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
            last_error = None
            for attempt in range(6):
                try:
                    os.replace(tmp, target)
                    tmp = None
                    last_error = None
                    break
                except PermissionError as e:
                    last_error = e
                    time.sleep(0.08 * (attempt + 1))
            if last_error is not None:
                raise last_error
        except Exception as e:
            try:
                self.append_log(f"[manifest] lưu lỗi: {e}")
            except Exception:
                pass
        finally:
            if tmp is not None:
                try:
                    Path(tmp).unlink(missing_ok=True)
                except Exception:
                    pass
            if acquired and lock is not None:
                try:
                    lock.release()
                except Exception:
                    pass

    def _latest_manifest_for_root(self, root):
        try:
            runs_root = self.backend_dir / "_simple_parallel_runs"
            if not runs_root.exists():
                return None
            root_norm = os.path.normcase(os.path.normpath(str(root)))
            candidates = sorted(runs_root.glob("run_*/job_manifest.json"), key=lambda x: x.stat().st_mtime, reverse=True)
            for mf in candidates[:12]:
                try:
                    data = json.loads(mf.read_text(encoding="utf-8"))
                    mf_root = os.path.normcase(os.path.normpath(str(data.get("root_folder") or "")))
                    if mf_root == root_norm and isinstance(data.get("jobs"), dict):
                        return mf, data
                except Exception:
                    continue
        except Exception:
            pass
        return None

    def _apply_latest_manifest(self, root):
        found = self._latest_manifest_for_root(root)
        if not found:
            return 0
        mf, data = found
        states = data.get("jobs", {}) or {}
        applied = 0
        for job in self.jobs:
            key = os.path.normcase(os.path.normpath(str(job.get("image_path") or "")))
            item = states.get(key) or {}
            st = str(item.get("status") or "")
            if not st:
                continue
            if st == "done":
                job["status"] = "done"; job["note"] = "Resume manifest: đã hoàn tất từ run trước"; applied += 1
            elif st == "skipped":
                job["status"] = "skipped"; job["note"] = item.get("note", "Resume manifest: đã bỏ qua từ run trước"); applied += 1
            elif st in ("running", "reserved", "queued", "error"):
                job["status"] = "queued"; job["note"] = "Resume manifest: job chưa xong, đưa lại vào hàng chờ"; applied += 1
        if applied:
            self.append_log(f"[manifest] resume từ {mf} • áp dụng {applied} job")
        return applied

    def _status_matches_filter(self, status, filter_text):
        ft = str(filter_text or "Tất cả")
        status = str(status or "")
        # v2.9: Khi đang chạy và bộ lọc là "Chờ", vẫn phải hiện:
        # - job đang chờ
        # - job đang chạy
        # - thumb đã hoàn tất
        # để trong lúc vẽ người dùng vẫn nhìn thấy thành quả đang sinh ra.
        wait_set = {"queued", "reserved", "running", "done"} if getattr(self, "running", False) else {"queued", "reserved"}
        mapping = {
            "Tất cả": None,
            "Chờ": wait_set,
            "Đang chạy": {"running"},
            "Xong": {"done"},
            "Lỗi": {"error"},
            "Bỏ qua": {"skipped"},
        }
        allowed = mapping.get(ft)
        return True if allowed is None else status in allowed

    def _filtered_preview_jobs(self):
        filter_text = self.job_filter_combo.currentText() if hasattr(self, "job_filter_combo") else "Tất cả"
        q = (self.job_search_edit.text() if hasattr(self, "job_search_edit") else "").strip().lower()
        out = []
        for job in self.jobs:
            if not self._status_matches_filter(job.get("status"), filter_text):
                continue
            if q:
                hay = " ".join(str(job.get(k, "")) for k in ("filename", "image_path", "note", "worker")).lower()
                if q not in hay:
                    continue
            out.append(job)
        return out

    def _format_eta(self, seconds):
        try:
            seconds = int(max(0, seconds))
            h, rem = divmod(seconds, 3600)
            m, sec = divmod(rem, 60)
            if h:
                return f"{h}h {m}m"
            if m:
                return f"{m}m {sec}s"
            return f"{sec}s"
        except Exception:
            return "-"

    def _format_hms(self, seconds):
        try:
            seconds = int(max(0, seconds))
            h, rem = divmod(seconds, 3600)
            m, sec = divmod(rem, 60)
            return f"{h:02d}:{m:02d}:{sec:02d}"
        except Exception:
            return "00:00:00"

    def _toggle_log_visible(self):
        try:
            show = not self.log_group.isVisible()
            self.log_group.setVisible(show)
            self.log_toggle.setText("▼ Ẩn Log tổng" if show else "▶ Hiện Log tổng")
        except Exception:
            pass

    def _jobs_all_terminal_success(self):
        """True khi mọi job đã DONE/SKIPPED; không còn Chờ/Đang chạy/Lỗi."""
        try:
            return bool(self.jobs) and all(str(j.get("status") or "") in ("done", "skipped") for j in self.jobs)
        except Exception:
            return False

    def _show_all_jobs_after_finish(self, reason="finish"):
        """V22: chỉ chuyển UI sang idle sau khi worker process thật sự đóng.

        V21 cho UI báo xong sớm trong khi worker cũ vẫn sống, khiến người dùng có thể Phục hồi
        đúng lúc worker đó còn ghi/capture. V22 giữ trạng thái running thêm vài giây nếu cần.
        """
        try:
            if self._has_live_worker_process():
                self.status_label.setText("Đã xong ảnh • đang đóng worker nền…")
                if not getattr(self, "_v22_finish_wait_logged", False):
                    self._v22_finish_wait_logged = True
                    self.append_log("[V22-FINISH-GATE] mọi job đã terminal • chờ worker process đóng hẳn trước khi cho Phục hồi/Chạy lại")
                QTimer.singleShot(700, lambda: self._show_all_jobs_after_finish(reason))
                return
            self._v22_finish_wait_logged = False
        except Exception:
            pass
        try:
            self._finish_show_all_done = True
        except Exception:
            pass
        try:
            self.running = False
            # Nếu worker process còn sống thêm vài giây sau summary, vẫn gỡ khỏi danh sách active để stats không giữ Đang chạy:1
            try:
                for w in list(getattr(self, "workers", []) or []):
                    if getattr(w, "finished", False):
                        continue
                    # Không kill process; chỉ UI đã terminal thì không coi là đang chạy nữa.
                self.active_accounts = set()
            except Exception:
                pass
            if self.run_started_at and self.run_finished_at is None:
                self.run_finished_at = time.monotonic()
            if hasattr(self, "job_filter_combo"):
                self.job_filter_combo.blockSignals(True)
                self.job_filter_combo.setCurrentText("Tất cả")
                self.job_filter_combo.blockSignals(False)
            self.status_label.setText("Hoàn tất toàn bộ • đã hiện tất cả thumbnail")
            self.append_log(f"[ui] hoàn tất toàn bộ • ép chuyển bộ lọc về Tất cả • hiện đầy đủ thumbnail ({reason})")
        except Exception:
            pass
        try:
            self.refresh_stats()
            self.request_preview_refresh(force=True)
            self._update_runtime_label()
        except Exception:
            pass

    def _update_runtime_label(self):
        try:
            if not hasattr(self, "runtime_value"):
                return
            if not self.run_started_at:
                self.runtime_value.setText("00:00:00")
                self.runtime_note.setText("Từ lúc Bắt đầu đến khi xong")
                return
            total = len(self.jobs)
            done = sum(1 for j in self.jobs if j.get("status") in ("done", "skipped"))
            # Chỉ chốt thời gian khi toàn bộ job đã hoàn tất/bỏ qua và không còn đang chạy/chờ.
            active_left = any(j.get("status") in ("queued", "reserved", "running", "error") for j in self.jobs)
            if total and done >= total and not active_left:
                if self.run_finished_at is None:
                    self.run_finished_at = time.monotonic()
                end = self.run_finished_at
                self.runtime_note.setText("Đã hoàn thành")
            else:
                if (not self.running) and self.run_finished_at is not None:
                    end = self.run_finished_at
                    self.runtime_note.setText("Tạm dừng")
                else:
                    end = time.monotonic()
                    self.runtime_note.setText("Đang chạy" if self.running else "Tạm dừng")
            self.runtime_value.setText(self._format_hms(max(0, end - self.run_started_at)))
        except Exception:
            pass

    # ---------- preview/stats/log ----------
    def _thumb_job_key(self, job_or_path):
        try:
            if isinstance(job_or_path, dict):
                raw = str(job_or_path.get("image_path") or "").strip()
            else:
                raw = str(job_or_path or "").strip()
            if not raw:
                return ""
            return str(Path(raw).resolve())
        except Exception:
            return str(job_or_path or "").strip()

    def _is_thumbnail_selected(self, job_or_path):
        return self._thumb_job_key(job_or_path) in getattr(self, "_selected_thumbnail_paths", set())

    def _set_thumbnail_selected(self, job_or_path, selected=True):
        key = self._thumb_job_key(job_or_path)
        if not key:
            return
        if not hasattr(self, "_selected_thumbnail_paths"):
            self._selected_thumbnail_paths = set()
        if selected:
            self._selected_thumbnail_paths.add(key)
        else:
            self._selected_thumbnail_paths.discard(key)
        self._sync_thumbnail_selection_controls()

    def _selected_thumbnail_jobs(self):
        chosen = []
        selected = set(getattr(self, "_selected_thumbnail_paths", set()) or set())
        if not selected:
            return chosen
        for job in (self.jobs or []):
            key = self._thumb_job_key(job)
            if key and key in selected:
                chosen.append(job)
        # dọn key mồ côi nếu có
        alive = {self._thumb_job_key(j) for j in chosen if self._thumb_job_key(j)}
        if alive != selected:
            self._selected_thumbnail_paths = alive
        return chosen

    def _selected_restorable_thumbnail_jobs(self):
        jobs = []
        for job in self._selected_thumbnail_jobs():
            try:
                target = Path(str(job.get("image_path") or "")).resolve()
            except Exception:
                target = None
            if target and target.exists() and self._job_thumb_jpg_from_job(job) is not None:
                jobs.append(job)
        return jobs

    def _sync_thumbnail_selection_controls(self):
        try:
            selected_jobs = self._selected_thumbnail_jobs()
            restorable = self._selected_restorable_thumbnail_jobs()
            count = len(selected_jobs)
            self.thumb_selected_label.setText(f"Đã chọn: {count}")
            has_visible = bool(getattr(self, "_last_visible_thumbnail_paths", []) or [])
            self.thumb_select_all_btn.setEnabled(has_visible)
            self.thumb_clear_select_btn.setEnabled(count > 0)
            self.thumb_restore_selected_btn.setEnabled((count > 0) and bool(restorable) and (not getattr(self, "running", False)) and (not getattr(self, "desc_running", False)))
            if restorable and count:
                self.thumb_restore_selected_btn.setText(f"Phục hồi thumb đã chọn ({len(restorable)})")
            else:
                self.thumb_restore_selected_btn.setText("Phục hồi thumb đã chọn")
        except Exception:
            pass

    def _select_all_visible_thumbnails(self):
        visible = list(getattr(self, "_last_visible_thumbnail_paths", []) or [])
        if not visible:
            return
        if not hasattr(self, "_selected_thumbnail_paths"):
            self._selected_thumbnail_paths = set()
        for p in visible:
            key = self._thumb_job_key(p)
            if key:
                self._selected_thumbnail_paths.add(key)
        self.request_preview_refresh(force=True)

    def _clear_selected_thumbnails(self):
        self._selected_thumbnail_paths = set()
        self.request_preview_refresh(force=True)

    def _apply_job_card_selected_state(self, frame, selected=False):
        try:
            frame.setProperty("selected", bool(selected))
            frame.style().unpolish(frame)
            frame.style().polish(frame)
            frame.update()
        except Exception:
            pass

    def _on_thumbnail_checkbox_toggled(self, job, frame, checked):
        """v13.48: đồng bộ checkbox card -> tập thumb đã chọn + bộ đếm."""
        try:
            self._set_thumbnail_selected(job, bool(checked))
            self._apply_job_card_selected_state(frame, bool(checked))
        except Exception as e:
            try:
                self.append_log(f"[thumb-select] ERROR • {job.get('image_path','')} • {type(e).__name__}: {e}")
            except Exception:
                pass

    def _current_file_size_mb(self, path):
        try:
            return Path(path).stat().st_size / (1024 * 1024)
        except Exception:
            return None

    def _thumb_fingerprint(self, path):
        try:
            st = Path(path).stat()
            return (int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1_000_000_000))), int(st.st_size))
        except Exception:
            return (0, 0)

    def _job_icon(self, path, size=(250, 150)):
        key = (str(path), self._thumb_fingerprint(path), size)
        cached = self._thumb_cache.get(key)
        if cached is not None:
            return cached
        if len(self._thumb_cache) > 240:
            self._thumb_cache.clear()
        pix = QPixmap()
        try:
            pix.load(str(path))
            if pix.isNull() and Image is not None:
                with Image.open(path) as img:
                    img.thumbnail(size)
                    buf = BytesIO(); img.save(buf, format="PNG")
                    pix.loadFromData(buf.getvalue(), "PNG")
            if not pix.isNull():
                pix = pix.scaled(size[0], size[1], Qt.KeepAspectRatio, Qt.FastTransformation)
        except Exception:
            pix = QPixmap()
        icon = QIcon(pix) if not pix.isNull() else QIcon()
        self._thumb_cache[key] = icon
        return icon

    def _preview_card_metrics(self):
        try:
            viewport_w = int(self.preview.viewport().width() or self.preview.width() or 1000)
        except Exception:
            viewport_w = 1000

        spacing = int(self.preview.spacing() or 8)

        # v79.6 Grid Fix:
        # QListWidget/IconMode còn cộng thêm spacing + padding riêng, nên bản cũ tính card hơi rộng
        # và bị wrap thành 3 ô / hàng. Công thức mới tính grid cell nhỏ hơn để chắc chắn vừa 5 ô.
        if viewport_w >= 980:
            cols = 4
        elif viewport_w >= 720:
            cols = 3
        elif viewport_w >= 480:
            cols = 2
        else:
            cols = 1

        usable = max(260, viewport_w - 52)
        item_w = int((usable - spacing * max(0, cols - 1)) / cols)
        item_w = max(150, item_w)

        card_w = max(146, item_w - 10)
        img_w = max(132, card_w - 18)
        img_h = max(74, int(round(img_w * 9 / 16)))
        card_h = img_h + 132  # v12.77: nới card để nút Phục hồi gốc không bị cắt chữ

        return {
            "viewport_w": viewport_w,
            "cols": cols,
            "card_w": card_w,
            "img_w": img_w,
            "img_h": img_h,
            "card_h": card_h,
            "item_w": item_w,
            "item_h": card_h + 12,
        }

    def _job_thumb_jpg_from_job(self, job):
        try:
            p = Path(str(job.get("image_path") or "")).resolve()
        except Exception:
            return None
        cand = p.parent / "thumbnail.jpg"
        return cand if cand.exists() else None

    def _can_show_restore_for_job(self, job):
        try:
            size_mb = float(job.get("size_mb") or 0)
        except Exception:
            size_mb = 0.0
        # Chỉ hiện nút phục hồi riêng cho thumbnail lớn hơn 1.9MB.
        return size_mb > 1.9 and self._job_thumb_jpg_from_job(job) is not None

    def _restore_job_original_now(self, job):
        if Image is None:
            raise RuntimeError("Thiếu Pillow (PIL), không thể phục hồi thumbnail.")
        thumb_jpg = self._job_thumb_jpg_from_job(job)
        if not thumb_jpg:
            raise FileNotFoundError("Không tìm thấy file thumbnail.jpg cho job này.")
        target_path = Path(str(job.get("image_path") or "")).resolve()
        with Image.open(thumb_jpg) as img:
            img = img.convert("RGB")
            buf = BytesIO()
            try:
                helper = globals().get("_make_png_under_limit")
                if callable(helper):
                    png_data = helper(img, RESTORE_MAX_BYTES)
                else:
                    img.save(buf, format="PNG", optimize=True, compress_level=9)
                    png_data = buf.getvalue()
            finally:
                try:
                    buf.close()
                except Exception:
                    pass
        with open(target_path, "wb") as f:
            f.write(png_data)
        job["status"] = "queued"
        job["worker"] = ""
        job["note"] = "Đã phục hồi về thumb gốc • sẵn sàng vẽ lại"
        job["size_mb"] = len(png_data) / (1024 * 1024)
        return thumb_jpg, target_path, png_data

    def restore_selected_thumbnails(self):
        if self.running:
            QMessageBox.information(self, APP_TITLE, "Hãy dừng tool trước khi phục hồi thumb đã chọn.")
            return
        jobs = self._selected_restorable_thumbnail_jobs()
        if not jobs:
            QMessageBox.information(self, APP_TITLE, "Chưa có thumb hợp lệ nào được chọn để phục hồi.")
            return
        names = [Path(str(j.get("image_path") or "")).resolve().parent.name for j in jobs[:6]]
        more = "" if len(jobs) <= 6 else f"\n... và {len(jobs) - 6} mục khác"
        msg = (
            f"Phục hồi {len(jobs)} thumbnail đã chọn về thumb gốc?\n"
            f"Các file được chọn sẽ bị ghi đè.\n\n"
            + "\n".join(names)
            + more
        )
        if QMessageBox.question(self, APP_TITLE, msg) != QMessageBox.Yes:
            return
        ok = 0
        err = 0
        for job in jobs:
            try:
                thumb_jpg, target_path, png_data = self._restore_job_original_now(job)
                ok += 1
                self.append_log(f"[restore-selected] OK • {thumb_jpg} -> {target_path.name} • ~{len(png_data)/1024.0:.1f} KB")
            except Exception as e:
                err += 1
                try:
                    fail_path = Path(str(job.get('image_path') or '')).resolve()
                except Exception:
                    fail_path = Path(str(job.get('image_path') or 'unknown'))
                self.append_log(f"[restore-selected] ERROR • {fail_path} • {e}")
        self._selected_thumbnail_paths = set()
        self.refresh_stats()
        self.request_preview_refresh(force=True)
        self.status_label.setText(f"Đã phục hồi thumb đã chọn • OK {ok} • lỗi {err}")
        if err:
            QMessageBox.warning(self, APP_TITLE, f"Đã phục hồi {ok} thumbnail.\nCòn {err} lỗi, xem log để biết chi tiết.")

    def _restore_single_job_original(self, job):
        if self.running:
            QMessageBox.information(self, APP_TITLE, "Hãy dừng tool trước khi phục hồi thumbnail gốc của từng job.")
            return
        if Image is None:
            QMessageBox.critical(self, APP_TITLE, "Thiếu Pillow (PIL), không thể phục hồi thumbnail.")
            return
        thumb_jpg = self._job_thumb_jpg_from_job(job)
        if not thumb_jpg:
            QMessageBox.warning(self, APP_TITLE, "Không tìm thấy file thumbnail.jpg cho job này.")
            return
        try:
            target_path = Path(str(job.get("image_path") or "")).resolve()
        except Exception:
            QMessageBox.warning(self, APP_TITLE, "Không xác định được file thumbnail cần phục hồi.")
            return
        folder_name = target_path.parent.name
        msg = f"Phục hồi đúng 1 thumbnail này về thumb gốc?\nThư mục: {folder_name}\nFile: {target_path.name}\nChỉ file này sẽ bị ghi đè."
        if QMessageBox.question(self, APP_TITLE, msg) != QMessageBox.Yes:
            return
        try:
            thumb_jpg, target_path, png_data = self._restore_job_original_now(job)
            self._selected_thumbnail_paths.discard(self._thumb_job_key(job))
            self.append_log(f"[restore-one] OK • {thumb_jpg} -> {target_path.name} • ~{len(png_data)/1024.0:.1f} KB")
            self.status_label.setText(f"Đã phục hồi 1 thumbnail gốc • {target_path.name}")
            self.refresh_stats()
            self.request_preview_refresh(force=True)
        except Exception as e:
            self.append_log(f"[restore-one] ERROR • {thumb_jpg} • {e}")
            QMessageBox.critical(self, APP_TITLE, f"Phục hồi thất bại:\n{e}")

    def _make_job_card(self, job, metrics=None):
        st = str(job.get("status") or "queued")
        m = metrics or self._preview_card_metrics()
        card_w = int(m["card_w"])
        img_w = int(m["img_w"])
        img_h = int(m["img_h"])
        card_h = int(m["card_h"])

        frame = QFrame()
        frame.setObjectName("JobCard")
        frame.setProperty("status", st)
        frame.setFixedSize(card_w, card_h)

        lay = QVBoxLayout(frame)
        lay.setContentsMargins(9, 9, 9, 8)
        lay.setSpacing(6)

        select_row = QHBoxLayout()
        select_row.setContentsMargins(0, 0, 0, 0)
        select_row.setSpacing(4)
        select_row.addStretch(1)
        chk_select = QCheckBox("Chọn")
        chk_select.setObjectName("JobSelectCheck")
        chk_select.setCursor(Qt.PointingHandCursor)
        chk_select.setChecked(self._is_thumbnail_selected(job))
        select_row.addWidget(chk_select, 0)
        lay.addLayout(select_row)

        img = QLabel()
        img.setObjectName("JobThumb")
        img.setFixedSize(img_w, img_h)
        img.setAlignment(Qt.AlignCenter)
        # v2.3: lúc đang chạy/chạy lại, queued/reserved không cần load ảnh ngay.
        # Việc load 100+ thumbnail trong UI thread là nguyên nhân chính gây Not Responding.
        light_preview = bool(getattr(self, "running", False) and st in ("queued", "reserved"))
        if light_preview:
            img.setText("CHỜ LUỒNG")
        else:
            icon = self._job_icon(job.get("image_path"), size=(img_w, img_h))
            pix = icon.pixmap(QSize(img_w, img_h))
            if not pix.isNull():
                img.setPixmap(pix)
            else:
                img.setText("NO PREVIEW")
                img.setObjectName("JobThumb")
        lay.addWidget(img)

        title = QLabel(str(job.get("filename") or ""))
        title.setObjectName("JobTitle")
        title.setToolTip(str(job.get("image_path") or ""))
        title.setTextInteractionFlags(Qt.TextSelectableByMouse)
        title.setMaximumHeight(26)
        lay.addWidget(title)

        meta_row = QHBoxLayout()
        meta_row.setContentsMargins(0, 0, 0, 0)
        meta_row.setSpacing(6)

        labels = {
            "running": "ĐANG TẠO",
            "done": "XONG",
            "error": "LỖI",
            "skipped": "BỎ QUA",
            "reserved": "CHỜ WORKER",
            "queued": "CHỜ",
        }
        chip = QLabel(labels.get(st, st.upper()))
        chip.setObjectName("JobChip")
        chip.setProperty("status", st)
        chip.setAlignment(Qt.AlignCenter)
        chip.setMinimumHeight(24)
        worker = str(job.get("worker") or "-")
        if st == "running":
            base = f"ĐANG TẠO • {worker}"
            chip.setProperty("baseText", base)
            chip.setText(f"{self._spin_chars[self._spin_index % len(self._spin_chars)]} {base}")
            self._running_spinner_labels.append(chip)
        elif worker and worker != "-":
            chip.setText(f"{labels.get(st, st.upper())} • {worker}")
        meta_row.addWidget(chip, 0)

        size = QLabel(f"{float(job.get('size_mb') or 0):.2f} MB")
        size.setObjectName("JobSub")
        size.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        meta_row.addWidget(size, 1)
        lay.addLayout(meta_row)

        if self._can_show_restore_for_job(job):
            action_row = QHBoxLayout()
            action_row.setContentsMargins(0, 0, 0, 0)
            action_row.setSpacing(6)
            btn_restore_one = QPushButton("↩ Phục hồi gốc")
            btn_restore_one.setObjectName("WarnButton")
            btn_restore_one.setCursor(Qt.PointingHandCursor)
            btn_restore_one.setFixedHeight(30)
            btn_restore_one.setEnabled(not self.running)
            btn_restore_one.clicked.connect(lambda _=False, j=job: self._restore_single_job_original(j))
            action_row.addWidget(btn_restore_one, 1)
            lay.addLayout(action_row)

        note_txt = str(job.get("note") or "")
        if len(note_txt) > 64:
            note_txt = note_txt[:61] + "..."
        note = QLabel(note_txt)
        note.setObjectName("JobSub")
        note.setToolTip(str(job.get("note") or ""))
        note.setMaximumHeight(20)
        lay.addWidget(note)

        # v13.48: checkbox phải cập nhật selection thật, không chỉ đổi dấu tick trên UI.
        self._apply_job_card_selected_state(frame, self._is_thumbnail_selected(job))
        chk_select.toggled.connect(lambda checked, j=job, f=frame: self._on_thumbnail_checkbox_toggled(j, f, checked))

        frame.setToolTip(f"{job.get('filename','')}\n{job.get('image_path','')}\n{job.get('note','')}")
        return frame

    def _animate_spinners(self):
        self._update_runtime_label()
        if not getattr(self, "_running_spinner_labels", None):
            return
        self._spin_index = (self._spin_index + 1) % len(self._spin_chars)
        ch = self._spin_chars[self._spin_index]
        alive = []
        for lb in list(self._running_spinner_labels):
            try:
                base = lb.property("baseText") or "ĐANG TẠO"
                lb.setText(f"{ch} {base}")
                alive.append(lb)
            except RuntimeError:
                pass
            except Exception:
                pass
        self._running_spinner_labels = alive

    def _display_order(self, job):
        status = str(job.get("status") or "")
        rank = {"running": 0, "done": 1, "error": 2, "reserved": 3, "queued": 4, "skipped": 5}.get(status, 6)
        return (rank, str(job.get("worker") or ""), str(job.get("image_path") or "").lower())

    def request_preview_refresh(self, force=False):
        # v2.3: KHÔNG refresh preview đồng bộ trong lúc bấm Bắt đầu/Chạy lại.
        # Tạo 100+ card + load ảnh ngay trong event click dễ làm Qt hiện Not Responding.
        # Force chỉ có nghĩa là chạy ở tick kế tiếp, không chặn UI thread ngay lập tức.
        if self._preview_refresh_pending:
            return
        self._preview_refresh_pending = True
        if force:
            QTimer.singleShot(0, self._preview_refresh_tick)
            return
        now = time.monotonic()
        delay = max(0, PREVIEW_REFRESH_DELAY_MS - int((now - self._last_preview_refresh_ts) * 1000))
        QTimer.singleShot(delay, self._preview_refresh_tick)

    def _preview_refresh_tick(self):
        self._preview_refresh_pending = False
        self.refresh_previews()

    def refresh_previews(self):
        self._last_preview_refresh_ts = time.monotonic()
        self._running_spinner_labels = []
        # v2.8: nếu mọi job đã DONE/SKIPPED thì ép thoát chế độ đang chạy và hiện Tất cả ngay.
        # Không chờ worker process kết thúc hẳn, vì có lúc summary đã xong nhưng process còn treo vài giây làm UI vẫn giữ lọc Chờ.
        try:
            if self._jobs_all_terminal_success():
                _live_finish = self._has_live_worker_process()
                if _live_finish:
                    # V22: chưa cho UI thành idle/restore khi process worker vẫn còn sống.
                    self.running = True
                    self.status_label.setText("Đã xong ảnh • đang đóng worker nền…")
                    QTimer.singleShot(700, lambda: self.request_preview_refresh(force=True))
                else:
                    self.running = False
                    if self.run_started_at and self.run_finished_at is None:
                        self.run_finished_at = time.monotonic()
                    if not getattr(self, "_finish_show_all_done", False):
                        self._finish_show_all_done = True
                        self.status_label.setText("Hoàn tất toàn bộ • đã hiện tất cả thumbnail")
                        self.append_log("[ui] phát hiện toàn bộ job đã DONE/SKIPPED và worker đã đóng • tự hiện Tất cả")
                    if hasattr(self, "job_filter_combo") and self.job_filter_combo.currentText() != "Tất cả":
                        self.job_filter_combo.blockSignals(True)
                        self.job_filter_combo.setCurrentText("Tất cả")
                        self.job_filter_combo.blockSignals(False)
                    try:
                        self._maybe_advance_project_queue()
                    except Exception as _queue_e:
                        self.append_log(f"[queue] auto next lỗi nhẹ: {_queue_e}")
        except Exception:
            pass
        metrics = self._preview_card_metrics()
        layout_key = (metrics["viewport_w"], metrics["card_w"], metrics["card_h"], metrics["cols"], bool(self.running), len(self.jobs))
        self._last_preview_layout_key = layout_key
        self._last_preview_viewport_width = metrics["viewport_w"]
        self.preview.setSpacing(6 if metrics.get("cols") == 4 else 8)
        self.preview.setGridSize(QSize(metrics["item_w"], metrics["item_h"]))
        self.preview.setIconSize(QSize(metrics["img_w"], metrics["img_h"]))
        self.preview.setUpdatesEnabled(False)
        try:
            self.preview.clear()
            self._last_visible_thumbnail_paths = []
            display_all = sorted(self._filtered_preview_jobs(), key=self._display_order)
            cap = PREVIEW_MAX_CARDS_RUNNING if self.running else PREVIEW_MAX_CARDS_IDLE
            # v2.5: sau Quét file/đang dừng hiển thị đầy đủ để kiểm tra; khi chạy mới giới hạn card.
            display_jobs = display_all[:cap]
            self._last_visible_thumbnail_paths = [self._thumb_job_key(j) for j in display_jobs if self._thumb_job_key(j)]
            has_running = any(str(j.get("status") or "") == "running" for j in display_jobs)
            for job in display_jobs:
                item = QListWidgetItem()
                item.setData(Qt.UserRole, job.get("image_path"))
                item.setSizeHint(QSize(metrics["item_w"], metrics["item_h"]))
                self.preview.addItem(item)
                try:
                    card = self._make_job_card(job, metrics=metrics)
                    self.preview.setItemWidget(item, card)
                except Exception as card_e:
                    # v13.47: một card lỗi không được phép làm trắng toàn bộ Danh sách job.
                    item.setText(str(job.get("filename") or Path(str(job.get("image_path") or "")).name or "Thumbnail"))
                    item.setToolTip(f"Không dựng được card: {card_e}")
                    try:
                        self.append_log(f"[preview-card] ERROR • {job.get('image_path','')} • {type(card_e).__name__}: {card_e}")
                    except Exception:
                        pass
            hidden = max(0, len(display_all) - len(display_jobs))
            if hidden:
                msg = f"Đang chạy nên ẩn tạm {hidden} ảnh phía sau để giữ UI mượt. File đang chạy và thumb đã hoàn tất vẫn luôn được ưu tiên hiện."
                item = QListWidgetItem(msg)
                item.setForeground(Qt.lightGray)
                item.setSizeHint(QSize(metrics["item_w"], 44))
                self.preview.addItem(item)
        finally:
            self.preview.setUpdatesEnabled(True)
        self._sync_thumbnail_selection_controls()
        if self.running and 'has_running' in locals() and has_running:
            QTimer.singleShot(0, self.preview.scrollToTop)

    def _preview_double_clicked(self, item):
        p = item.data(Qt.UserRole)
        if not p:
            return
        try:
            if os.name == "nt":
                os.startfile(str(Path(p).resolve().parent))
            else:
                subprocess.Popen(["xdg-open", str(Path(p).resolve().parent)])
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không mở được thư mục:\n{e}")

    def refresh_stats(self):
        try:
            if getattr(self, "queue_running", False) or any("queue_index" in j for j in (self.jobs or [])):
                self._sync_project_queue_stats_from_jobs()
        except Exception:
            pass
        self.stat_cards["total"].set_value(len(self.jobs))
        q = sum(1 for j in self.jobs if j.get("status") in ("queued", "reserved"))
        active = 0
        if not self._jobs_all_terminal_success():
            for w in self.workers:
                try:
                    if w.proc and w.proc.poll() is None:
                        active += 1
                except Exception:
                    pass
        d = sum(1 for j in self.jobs if j.get("status") == "done")
        e = sum(1 for j in self.jobs if j.get("status") == "error")
        s = sum(1 for j in self.jobs if j.get("status") == "skipped")
        self.stat_cards["queue"].set_value(q)
        self.stat_cards["running"].set_value(active)
        self.stat_cards["done"].set_value(d)
        self.stat_cards["error"].set_value(e)
        self.stat_cards["skip"].set_value(s)
        try:
            total_workers = len(self.workers)
            self.track_chip_workers.setText(f"Worker: {total_workers}")
            self.track_chip_running.setText(f"Đang chạy: {active}")
            self.track_chip_done.setText(f"Xong: {d}")
            self.track_chip_error.setText(f"Lỗi: {e}")
            if hasattr(self, "eta_label"):
                done_delta = max(0, d - int(getattr(self, "run_done_baseline", 0) or 0))
                remaining = sum(1 for j in self.jobs if j.get("status") in ("queued", "reserved", "running"))
                if self.running and self.run_started_at and done_delta > 0:
                    rate = (time.monotonic() - self.run_started_at) / max(1, done_delta)
                    self.eta_label.setText(f"ETA: {self._format_eta(rate * remaining)}")
                elif self.running:
                    self.eta_label.setText("ETA: đang đo...")
                else:
                    self.eta_label.setText("ETA: -")
            if hasattr(self, "error_summary_label"):
                pairs = sorted(self.error_stats.items(), key=lambda kv: kv[1], reverse=True)[:3]
                if pairs:
                    self.error_summary_label.setText("Lỗi: " + ", ".join(f"{k}:{v}" for k, v in pairs))
                else:
                    self.error_summary_label.setText("Lỗi: -")
            if hasattr(self, "account_perf_label"):
                ranked = []
                for acc in sorted(self.account_perf.keys()):
                    avg = self._account_avg_job_seconds(acc)
                    if avg is None:
                        continue
                    perf = self._get_account_perf(acc)
                    ranked.append((avg, acc, perf))
                if ranked:
                    ranked.sort(key=lambda x: x[0])
                    chunks = []
                    for avg, acc, perf in ranked[:2]:
                        chunks.append(f"{self._display_tk_label(acc)}:{int(avg)}s/j • ok {int(perf.get('jobs_done', 0) or 0)}")
                    self.account_perf_label.setText("TK nhanh: " + " | ".join(chunks))
                else:
                    cooling = []
                    for acc in sorted(self.account_perf.keys()):
                        rem = self._account_cooldown_remaining(acc)
                        if rem > 0:
                            cooling.append(f"{self._display_tk_label(acc)}:{int(rem)}s")
                    self.account_perf_label.setText("TK: " + ("cooldown " + ", ".join(cooling[:2]) if cooling else "-") )
        except Exception:
            pass
        self._update_runtime_label()
        self._sync_thumbnail_selection_controls()
        self._save_run_manifest(force=False)

    def append_log(self, line):
        self.append_logs([line])

    def append_logs(self, lines):
        """v13.15 HOTFIX_NO_QT_THREAD_CRASH: chỉ update QTextEdit trên main thread Qt.

        Lỗi crash native/access violation xảy ra khi worker thread gọi append_log(),
        rồi append_logs() chạm trực tiếp self.log.appendPlainText(). Qt widget không
        thread-safe, nên mọi log từ thread phụ phải được đẩy qua self.ui_queue để
        hàm _drain() xử lý trên main thread.
        """
        # Worker/background thread: tuyệt đối không đụng self.log/QTextEdit.
        try:
            import threading as _threading
            if _threading.current_thread() is not _threading.main_thread():
                q = getattr(self, "ui_queue", None)
                if q is not None:
                    try:
                        for x in (lines or []):
                            s = str(x).rstrip()
                            if s.strip():
                                q.put(("log", s))
                    except Exception:
                        pass
                return
        except Exception:
            # Nếu không xác định được thread thì vẫn cố chạy nhánh main-thread cũ,
            # nhưng không để lỗi log làm sập tool.
            pass

        clean = []
        last = getattr(self, "_last_log_line", "")
        for x in (lines or []):
            s = str(x).rstrip()
            if not s.strip() or s == last:
                continue
            clean.append(s)
            last = s
        try:
            self._last_log_line = last
        except Exception:
            pass
        if not clean:
            return

        # V16 Web: keep a real in-memory ring buffer + a plain text file so the Web Log drawer
        # can always show useful diagnostics.  The old Qt log only wrote to QTextEdit, while
        # web_engine_bridge was reading a non-existent _log_lines attribute, hence "Chưa có log".
        try:
            ring = list(getattr(self, "_web_log_lines", []) or [])
            stamp = datetime.now().strftime("%H:%M:%S")
            ring.extend([f"{stamp} {x}" for x in clean])
            if len(ring) > 4000:
                ring = ring[-4000:]
            self._web_log_lines = ring
            try:
                dbg = Path(getattr(self, "backend_dir", Path(__file__).resolve().parent)) / "_debug"
                dbg.mkdir(parents=True, exist_ok=True)
                live_log = dbg / "thumbnail_studio_live.log"
                with live_log.open("a", encoding="utf-8", errors="replace") as _lf:
                    for _line in clean:
                        _lf.write(f"{datetime.now().isoformat(timespec='seconds')} {_line}\n")
                # V20: also mirror outside the install directory so an engine/browser crash cannot
                # take diagnostics away and replacing the ZIP never erases the last failure.
                _raw = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
                _ext = Path(os.environ.get("THUMB_STUDIO_PERSIST_ROOT") or (Path(_raw) / "HDMaster" / "ThumbnailStudio")) / "thumbnail_studio_live.log"
                _ext.parent.mkdir(parents=True, exist_ok=True)
                with _ext.open("a", encoding="utf-8", errors="replace") as _ef:
                    for _line in clean:
                        _ef.write(f"{datetime.now().isoformat(timespec='seconds')} {_line}\n")
            except Exception:
                pass
        except Exception:
            pass

        try:
            max_lines = int(globals().get("LOG_BATCH_MAX_LINES_PER_TICK", 300))
        except Exception:
            max_lines = 300
        if max_lines > 0 and len(clean) > max_lines:
            dropped = len(clean) - max_lines
            clean = [f"[ui] lược bớt {dropped} dòng log quá dày để tránh treo giao diện"] + clean[-max_lines:]

        try:
            log_widget = getattr(self, "log", None)
            if log_widget is not None:
                log_widget.appendPlainText("\n".join(clean))
        except RuntimeError:
            # Widget có thể đã bị destroy khi tool đang đóng; bỏ qua để tránh crash phụ.
            pass
        except Exception:
            # Log UI không được phép làm chết worker/dashboard.
            pass
    # v13.15 FIX_QUEUE_SLOT_MAX_BOOT: restore queue slot limit removed by previous hotfix
    QUEUE_SLOT_MAX = 5

    def _empty_queue_item(self):
        return {"root": "", "logo": "", "status": "trống", "total": "?", "done": 0, "error": 0, "skip": 0}

    def _queue_item_valid(self, item):
        try:
            root = str((item or {}).get("root") or "").strip()
            # v12.77: Queue hợp lệ chỉ cần thư mục. Logo trống/mất file = chạy không logo.
            return bool(root and Path(root).exists())
        except Exception:
            return False

    def _ensure_project_queue_slots(self):
        try:
            cleaned = []
            for it in list(getattr(self, "project_queue", []) or []):
                if not isinstance(it, dict):
                    continue
                item = dict(self._empty_queue_item())
                item.update(it)
                cleaned.append(item)
                if len(cleaned) >= self.QUEUE_SLOT_MAX:
                    break
            while len(cleaned) < self.QUEUE_SLOT_MAX:
                cleaned.append(self._empty_queue_item())
            self.project_queue = cleaned[:self.QUEUE_SLOT_MAX]
        except Exception:
            self.project_queue = [self._empty_queue_item() for _ in range(self.QUEUE_SLOT_MAX)]

    def _first_empty_queue_slot(self):
        self._ensure_project_queue_slots()
        for i, item in enumerate(self.project_queue):
            if not self._queue_item_valid(item):
                return i
        return -1

    def _valid_project_queue_indices(self):
        self._ensure_project_queue_slots()
        return [i for i, item in enumerate(self.project_queue) if self._queue_item_valid(item)]

    def _queue_item_title(self, item, idx=None):
        try:
            root = Path(str(item.get("root") or ""))
            logo = Path(str(item.get("logo") or ""))
            status = str(item.get("status") or "chờ")
            total = item.get("total", "?")
            done = item.get("done", 0)
            err = item.get("error", 0)
            prefix = f"#{idx+1} " if idx is not None else ""
            return f"{prefix}[{status}] {root.name or root} • logo: {logo.name or '-'} • {done}/{total} xong • lỗi {err}"
        except Exception:
            return str(item)

    def _select_project_queue_index(self, idx):
        try:
            idx = int(idx)
            total = len(getattr(self, "project_queue", []) or [])
            if idx < 0 or idx >= total:
                return
            self.selected_queue_index = idx
            if hasattr(self, "project_queue_list"):
                self.project_queue_list.setCurrentRow(idx)
            item = self.project_queue[idx]
            # Đồng bộ dự án đang chọn vào root/logo ẩn để Quét file/Tạo thumb cũ vẫn dùng được.
            self.root_edit.blockSignals(True); self.logo_edit.blockSignals(True)
            self.root_edit.setText(str(item.get("root") or ""))
            self.logo_edit.setText(str(item.get("logo") or ""))
            self.root_edit.blockSignals(False); self.logo_edit.blockSignals(False)
            self._refresh_project_queue_ui()
        except Exception as e:
            try: self.append_log(f"[queue] chọn card lỗi nhẹ: {e}")
            except Exception: pass

    def _clear_project_queue_cards(self):
        try:
            if not hasattr(self, "project_queue_cards_layout"):
                return
            while self.project_queue_cards_layout.count() > 0:
                item = self.project_queue_cards_layout.takeAt(0)
                w = item.widget()
                if w is not None:
                    w.deleteLater()
        except Exception:
            pass

    def _pick_queue_root(self, idx):
        try:
            if idx < 0 or idx >= len(self.project_queue):
                return
            root = QFileDialog.getExistingDirectory(self, "Chọn thư mục quét cho dự án")
            if not root:
                return
            self.project_queue[idx]["root"] = normalize_path(root)
            self._select_project_queue_index(idx)
            self.schedule_save_state()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def _pick_queue_logo(self, idx):
        try:
            if idx < 0 or idx >= len(self.project_queue):
                return
            logo, _ = QFileDialog.getOpenFileName(self, "Chọn logo PNG cho dự án", "", "PNG files (*.png);;All files (*.*)")
            if not logo:
                return
            self.project_queue[idx]["logo"] = normalize_path(logo)
            self._select_project_queue_index(idx)
            self.schedule_save_state()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def _queue_item_has_any_path(self, item):
        try:
            return bool(str((item or {}).get("root") or "").strip() or str((item or {}).get("logo") or "").strip())
        except Exception:
            return False

    def _set_queue_path_from_edit(self, idx, field, edit):
        """v12.57: cho phép gõ trực tiếp đường dẫn thư mục/logo trong từng Queue."""
        try:
            idx = int(idx)
            if field not in ("root", "logo") or idx < 0 or idx >= len(self.project_queue):
                return
            raw = str(edit.text() or "").strip().strip('"')
            value = normalize_path(raw) if raw else ""
            self.project_queue[idx][field] = value
            if field == "root":
                self.project_queue[idx]["total"] = "?"
                self.project_queue[idx]["done"] = 0
                self.project_queue[idx]["error"] = 0
                self.project_queue[idx]["skip"] = 0
            if self._queue_item_valid(self.project_queue[idx]):
                self.project_queue[idx]["status"] = self.project_queue[idx].get("status") or "chờ"
            else:
                self.project_queue[idx]["status"] = "chờ" if self._queue_item_has_any_path(self.project_queue[idx]) else "trống"
            self.selected_queue_index = idx
            try:
                self.project_queue_list.setCurrentRow(idx)
            except Exception:
                pass
            try:
                self.root_edit.blockSignals(True); self.logo_edit.blockSignals(True)
                self.root_edit.setText(str(self.project_queue[idx].get("root") or ""))
                self.logo_edit.setText(str(self.project_queue[idx].get("logo") or ""))
                self.root_edit.blockSignals(False); self.logo_edit.blockSignals(False)
            except Exception:
                pass
            self.schedule_save_state()
            QTimer.singleShot(0, self._refresh_project_queue_ui)
        except Exception as e:
            try: self.append_log(f"[queue] cập nhật đường dẫn ô {idx+1} lỗi: {e}")
            except Exception: pass

    def add_project_queue_item_to_slot(self, idx, root, logo, status="chờ"):
        root = normalize_path(root) if str(root or "").strip() else ""
        logo = normalize_path(logo) if str(logo or "").strip() else ""
        if not root or not Path(root).exists():
            raise ValueError("Thư mục quét không tồn tại")
        # v12.77: Logo không bắt buộc. Nếu truyền logo nhưng file không còn tồn tại hoặc không phải PNG thì tự bỏ qua.
        if logo and ((not Path(logo).exists()) or (not str(logo).lower().endswith(".png"))):
            try:
                self.append_log(f"[logo-optional] Queue #{int(idx)+1}: bỏ qua logo không hợp lệ/mất file: {logo}")
            except Exception:
                pass
            logo = ""
        self._ensure_project_queue_slots()
        idx = int(idx)
        if idx < 0 or idx >= self.QUEUE_SLOT_MAX:
            raise ValueError("Ô Queue không hợp lệ")
        if self.queue_running and idx == self.current_queue_index:
            raise ValueError("Không sửa ô Queue đang chạy")
        self.project_queue[idx] = {"root": root, "logo": logo, "status": status, "total": "?", "done": 0, "error": 0, "skip": 0}
        self.selected_queue_index = idx
        self._refresh_project_queue_ui()
        try: self.project_queue_list.setCurrentRow(idx)
        except Exception: pass
        self.schedule_save_state()
        return self.project_queue[idx]

    def add_project_queue_item_dialog_at(self, idx):
        # v12.77: bấm + chỉ chọn thư mục. Logo chọn riêng bằng nút Chọn ở dòng Logo.
        try:
            idx = int(idx)
        except Exception:
            idx = self._first_empty_queue_slot()
        root = QFileDialog.getExistingDirectory(self, f"Chọn thư mục quét cho Queue #{idx+1}")
        if not root:
            return
        try:
            self.add_project_queue_item_to_slot(idx, root, "")
            self.root_edit.setText(root)
            self.logo_edit.setText("")
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def remove_project_queue_item_at(self, idx, ask=True):
        try:
            idx = int(idx)
            self._ensure_project_queue_slots()
            if idx < 0 or idx >= len(self.project_queue):
                return
            if self.queue_running and idx == self.current_queue_index:
                QMessageBox.information(self, APP_TITLE, "Không xóa Queue đang chạy.")
                return
            item = self.project_queue[idx]
            if ask and self._queue_item_has_any_path(item):
                name = Path(str(item.get("root") or "")).name or f"Queue #{idx+1}"
                if QMessageBox.question(self, APP_TITLE, f"Xóa Queue #{idx+1}: {name}?\nChỉ xóa khỏi danh sách queue, không xóa file trong thư mục.") != QMessageBox.Yes:
                    return
            self.project_queue[idx] = self._empty_queue_item()
            # Xóa luôn job hiển thị thuộc Queue này để Danh sách job không còn lẫn dự án đã bỏ.
            try:
                def _job_qi(j):
                    v = j.get("queue_index", -1)
                    return int(v) if str(v).lstrip("-").isdigit() else -1
                self.jobs = [j for j in (self.jobs or []) if _job_qi(j) != idx]
                self.refresh_stats()
                self.request_preview_refresh(force=True)
            except Exception:
                pass
            if int(getattr(self, "selected_queue_index", -1) or -1) == idx:
                self.selected_queue_index = -1
            if int(getattr(self, "current_queue_index", -1) or -1) == idx:
                self.current_queue_index = -1
            self.schedule_save_state()
            self._refresh_project_queue_ui()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def _make_project_queue_card(self, item, idx):
        card = QFrame()
        card.setObjectName("QueueCard")
        selected = idx == int(getattr(self, "selected_queue_index", -1) or -1)
        running = bool(getattr(self, "queue_running", False) and idx == int(getattr(self, "current_queue_index", -1) or -1))
        card.setProperty("selected", "true" if selected else "false")
        card.setProperty("active", "true" if running else "false")
        # v12.78: mỗi card co giãn đều; hàng trên gồm 4 queue thumb + 1 card Sửa mô tả.
        card.setMinimumWidth(230)
        card.setMaximumWidth(9999)
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        card.setMinimumHeight(138)
        root = str((item or {}).get("root") or "")
        logo = str((item or {}).get("logo") or "")
        has_any_path = self._queue_item_has_any_path(item)

        # v12.57: ô trống chỉ hiện dấu + để thêm queue, không chiếm chỗ bằng form rỗng.
        if not has_any_path:
            card.setProperty("empty", "true")
            lay = QVBoxLayout(card); lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(6)
            lay.addStretch(1)
            btn_add = QPushButton("+")
            btn_add.setObjectName("QueueAddButton")
            btn_add.setCursor(Qt.PointingHandCursor)
            btn_add.setToolTip(f"Thêm Queue #{idx+1}")
            btn_add.setMinimumHeight(54)
            btn_add.setEnabled(not self.running)
            btn_add.clicked.connect(lambda _=False, i=idx: self.add_project_queue_item_dialog_at(i))
            lay.addWidget(btn_add)
            hint = QLabel(f"Queue #{idx+1}")
            hint.setObjectName("QueueStats")
            hint.setAlignment(Qt.AlignCenter)
            lay.addWidget(hint)
            lay.addStretch(1)
            return card

        # v12.55/v12.57: nới card và hạ nội dung xuống một chút để title/nút không bị cắt chữ.
        lay = QVBoxLayout(card); lay.setContentsMargins(10, 10, 10, 9); lay.setSpacing(4)
        total = item.get("total", "?")
        done = item.get("done", 0)
        err = item.get("error", 0)
        skip = item.get("skip", 0)

        title_row = QHBoxLayout(); title_row.setContentsMargins(0, 0, 0, 0); title_row.setSpacing(5)
        title = QLabel(f"#{idx+1}  {Path(root).name or 'Chưa chọn'}")
        title.setObjectName("QueueCardTitle")
        title.setToolTip(root or "Chưa chọn thư mục")
        title_row.addWidget(title, 1)
        btn_del = QPushButton("×")
        btn_del.setObjectName("QueueDeleteButton")
        btn_del.setCursor(Qt.PointingHandCursor)
        btn_del.setFixedSize(24, 22)
        btn_del.setToolTip(f"Xóa Queue #{idx+1}")
        btn_del.setEnabled(not (self.queue_running and idx == self.current_queue_index))
        btn_del.clicked.connect(lambda _=False, i=idx: self.remove_project_queue_item_at(i, ask=True))
        title_row.addWidget(btn_del, 0)
        lay.addLayout(title_row)

        def mini_row(label, value, field, slot):
            row = QHBoxLayout(); row.setContentsMargins(0, 0, 0, 0); row.setSpacing(5)
            lb = QLabel(label); lb.setObjectName("QueueMiniLabel"); lb.setFixedWidth(54)
            edit = QLineEdit(value)
            # v12.57: không ReadOnly nữa; có thể dán/gõ đường dẫn trực tiếp.
            edit.setReadOnly(False)
            edit.setObjectName("QueueMiniEdit")
            edit.setToolTip(value or "Có thể gõ/dán đường dẫn hoặc bấm Chọn")
            edit.setPlaceholderText("Gõ/dán đường dẫn...")
            edit.setMinimumWidth(92)
            edit.setFixedHeight(25)
            edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            edit.editingFinished.connect(lambda i=idx, f=field, e=edit: self._set_queue_path_from_edit(i, f, e))
            btn = QPushButton("Chọn"); btn.setObjectName("QueueMiniButton"); btn.setFixedWidth(58); btn.setFixedHeight(25)
            btn.clicked.connect(slot)
            row.addWidget(lb); row.addWidget(edit, 1); row.addWidget(btn)
            return row

        lay.addLayout(mini_row("Thư mục", root, "root", lambda _=False, i=idx: self._pick_queue_root(i)))
        lay.addLayout(mini_row("Logo", logo, "logo", lambda _=False, i=idx: self._pick_queue_logo(i)))
        stats = QLabel(f"{done}/{total} xong • lỗi {err} • bỏ qua {skip}")
        stats.setObjectName("QueueStats")
        lay.addWidget(stats)

        card_has_root = bool(root and Path(root).exists())
        action_row = QHBoxLayout(); action_row.setContentsMargins(0, 0, 0, 0); action_row.setSpacing(6)

        btn_thumb = QPushButton("Tạo thumb")
        btn_thumb.setObjectName("AccentButton")
        btn_thumb.setCursor(Qt.PointingHandCursor)
        btn_thumb.setFixedHeight(28)
        btn_thumb.setStyleSheet("font-size:8pt; padding:3px 4px; font-weight:900;")
        btn_thumb.setEnabled(card_has_root and (not self.running) and (not getattr(self, "desc_running", False)))
        btn_thumb.clicked.connect(lambda _=False, i=idx: self.create_thumbs_for_queue(i))
        action_row.addWidget(btn_thumb, 1)

        btn_restore_q = QPushButton("Phục hồi")
        btn_restore_q.setObjectName("WarnButton")
        btn_restore_q.setCursor(Qt.PointingHandCursor)
        btn_restore_q.setFixedHeight(28)
        btn_restore_q.setStyleSheet("font-size:8pt; padding:3px 4px; font-weight:900;")
        btn_restore_q.setEnabled(card_has_root and (not self.running) and (not getattr(self, "desc_running", False)))
        btn_restore_q.clicked.connect(lambda _=False, i=idx: self.restore_thumbs_for_queue(i))
        action_row.addWidget(btn_restore_q, 1)

        lay.addLayout(action_row)
        return card


    # ---------- Description rewrite (v12.79) ----------
    def _description_prompt(self, original_text):
        original = str(original_text or "").strip()
        return "\n".join([
            "Rewrite the ORIGINAL_DESCRIPTION below for a YouTube video.",
            "",
            "CRITICAL LANGUAGE RULES:",
            "- First identify the language from ORIGINAL_DESCRIPTION only.",
            "- Ignore the language used in these instructions and in the Gemini interface.",
            "- Return the rewritten description in exactly the same dominant language as ORIGINAL_DESCRIPTION.",
            "- NEVER answer in Vietnamese unless ORIGINAL_DESCRIPTION itself is predominantly Vietnamese.",
            "- English original: English only. Spanish original: Spanish only. Portuguese original: Portuguese only.",
            "- If the original mixes languages, use the language that makes up most of the original text.",
            "",
            "CONTENT RULES:",
            "- Return only the rewritten description. No greeting, heading, explanation, or quotation marks.",
            "- Make it clearer, more attractive, natural, and suitable for YouTube while preserving the meaning.",
            "- Remove every channel name, brand name, website name, fan page, competitor name, and private signature.",
            "- Remove all URLs, email addresses, contact details, donation links, social links, subscription links, and channel links.",
            "- Remove lines such as Welcome to [channel], Buy Me a Coffee, Subscribe, Contact, Email, Facebook, Instagram, Website, Support us, Donate, or branded copyright notices.",
            "- Do not invent facts or add [Insert Link], new links, email addresses, or brand/channel names.",
            "- Keep only generic copyright notices, appropriate usage warnings, generic hashtags, music/visual descriptions, and entertainment-purpose notes.",
            "",
            "ORIGINAL_DESCRIPTION:",
            "<<<START>>>",
            original,
            "<<<END>>>",
            "",
            "Return only the rewritten description now, using the original description's language.",
        ])

    def _description_norm_brand_key(self, s):
        return re.sub(r"[^a-z0-9]+", "", str(s or "").lower())

    def _description_extract_forbidden_brands(self, original_text):
        """v12.90: rút ra tên kênh/thương hiệu bất kỳ từ mô tả gốc để hậu lọc.
        Không hard-code Soft Rock Legends; tự lấy từ Welcome to..., Copyrighted by..., URL/@handle/hashtag.
        """
        src = str(original_text or "")
        brands = set()

        def add_brand(v):
            v = re.sub(r"[\s\-–—_:|/\\]+$", "", str(v or "").strip(" .,:;!?()[]{}<>\"'“”‘’"))
            v = re.sub(r"^(the\s+)?(official\s+)?", "", v, flags=re.I).strip()
            if not v:
                return
            # Cắt bớt phần mô tả sau tên kênh.
            v = re.split(r"\b(your|tu|o seu|sua|where|which|that|for|with|complete|ultimate|official)\b", v, maxsplit=1, flags=re.I)[0].strip(" .,:;!-–—")
            if 2 <= len(v) <= 80:
                k = self._description_norm_brand_key(v)
                if len(k) >= 4:
                    brands.add(k)

        for line in src.splitlines():
            l = line.strip()
            if not l:
                continue
            # Welcome to / Bienvenidos a / Bem-vindo ao / Chào mừng đến với...
            m = re.search(r"(?:welcome\s+to|bienvenid[oa]s?\s+(?:a|al)|bem[-\s]?vind[oa]s?\s+(?:a|ao|à)|bienvenue\s+(?:à|sur)|chào\s+mừng\s+(?:đến\s+với|tới))\s+([^,\n.!]+)", l, flags=re.I)
            if m:
                add_brand(m.group(1))
            # Copyrighted by / Copyright by / © ... by
            m = re.search(r"(?:copyright(?:ed)?\s+by|©\s*(?:video\s+is\s+)?copyright(?:ed)?\s+by)\s+([^,\n.!]+)", l, flags=re.I)
            if m:
                add_brand(m.group(1))
            # Các URL/handle thường chứa tên kênh.
            for m in re.finditer(r"(?:youtube\.com/@|@|buymeacoffee\.com/|patreon\.com/|facebook\.com/|instagram\.com/|tiktok\.com/@?)([A-Za-z0-9_.-]{4,60})", l, flags=re.I):
                add_brand(m.group(1))
            # Hashtag có thể là tên brand; thêm vào danh sách để xóa đúng hashtag đó nếu Gemini giữ lại.
            for m in re.finditer(r"#([A-Za-z0-9_]{5,60})", l):
                tag = m.group(1)
                # Chỉ coi hashtag dài, dính chữ, có khả năng là tên kênh/thương hiệu.
                if len(tag) >= 10:
                    add_brand(tag)

        return brands

    def _description_remove_unwanted_brand_lines(self, text, original_text=None):
        """v12.90: hậu lọc mô tả để xoá link/email/donate/subscribe/contact và mọi brand/kênh rút từ mô tả gốc.
        Prompt đôi khi vẫn để sót các dòng như Buy Me a Coffee, Subscribe URL, Contact email,
        Welcome to [channel], hoặc © Video is Copyrighted by [channel]. Hàm này chặn ngay trước khi ghi description.txt.
        """
        t = str(text or "")
        out = []
        forbidden_brands = self._description_extract_forbidden_brands(original_text) if original_text else set()
        url_re = re.compile(r"(https?://|www\.|youtube\.com|youtu\.be|buymeacoffee\.com|patreon\.com|paypal\.me|linktr\.ee|tiktok\.com|facebook\.com|instagram\.com|twitter\.com|x\.com)", re.I)
        email_re = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I)
        bad_words_re = re.compile(r"\b(buy\s*me\s*a\s*coffee|subscribe|sub_confirmation|contact|email|gmail|support\s+us|donate|patreon|paypal|website|follow\s+us|facebook|instagram|tiktok|telegram|whatsapp)\b", re.I)
        branded_copyright_re = re.compile(r"^\s*[©\(c\)]*\s*(video\s+is\s+)?copyright(ed)?\s+by\b", re.I)
        welcome_brand_re = re.compile(r"^\s*(👋\s*)?(welcome\s+to|bienvenid[oa]s?\s+(?:a|al)|bem[-\s]?vind[oa]s?\s+(?:a|ao|à)|bienvenue\s+(?:à|sur)|chào\s+mừng\s+(?:đến\s+với|tới))\b", re.I)

        for raw in t.splitlines():
            line = raw.rstrip()
            compact = line.strip()
            if not compact:
                out.append(line)
                continue
            # Xoá dòng chứa link/email hoặc CTA/liên hệ/donate/subscribe rõ ràng.
            if url_re.search(compact) or email_re.search(compact) or bad_words_re.search(compact):
                continue
            # Xoá dòng mở đầu kiểu Welcome to [tên kênh].
            if welcome_brand_re.search(compact):
                continue
            # Xoá copyright gắn với tên kênh/thương hiệu; giữ các dòng chung như © All rights reserved.
            if branded_copyright_re.search(compact):
                continue

            line_key = self._description_norm_brand_key(compact)
            # Xoá dòng còn sót tên brand/kênh đã rút từ bản gốc.
            if forbidden_brands and any((b and len(b) >= 4 and b in line_key) for b in forbidden_brands):
                # Nếu chỉ là hashtag brand nằm chung với hashtag khác, xóa riêng hashtag brand thay vì bỏ cả dòng.
                if "#" in compact:
                    kept_parts = []
                    for part in compact.split():
                        if part.startswith("#"):
                            pk = self._description_norm_brand_key(part.lstrip("#"))
                            if any((b and len(b) >= 4 and (b in pk or pk in b)) for b in forbidden_brands):
                                continue
                        kept_parts.append(part)
                    compact2 = " ".join(kept_parts).strip()
                    if compact2:
                        out.append(compact2)
                    continue
                continue
            out.append(line)
        cleaned = "\n".join(out)
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
        return cleaned

    @staticmethod
    def _description_root_key(raw):
        try:
            value = normalize_path(str(raw or "").strip())
            if not value:
                return ""
            return os.path.normcase(os.path.normpath(value))
        except Exception:
            return str(raw or "").strip().lower()

    def _description_thumbnail_roots(self):
        """Các nguồn tự động đang được cấu hình tại trang Tạo Thumbnail."""
        self._ensure_project_queue_slots()
        roots, seen = [], set()
        for item in (getattr(self, "project_queue", []) or []):
            root = str((item or {}).get("root") or "").strip()
            key = self._description_root_key(root)
            if root and key and Path(normalize_path(root)).exists() and key not in seen:
                roots.append(root); seen.add(key)
        for raw in (getattr(self, "current_root_folder", None), self.root_edit.text().strip() if hasattr(self, "root_edit") else ""):
            root = str(raw or "").strip()
            key = self._description_root_key(root)
            if root and key and Path(normalize_path(root)).exists() and key not in seen:
                roots.append(root); seen.add(key)
        return roots

    def _description_queue_roots(self):
        """v13.11: hợp nhất nguồn Thumbnail + các dòng nhập thêm, loại trùng và bỏ đường dẫn không tồn tại."""
        roots, seen = [], set()
        for raw in self._description_thumbnail_roots() + list(getattr(self, "desc_custom_roots", []) or []):
            root = str(raw or "").strip().strip('"')
            key = self._description_root_key(root)
            try:
                exists = bool(root and Path(normalize_path(root)).exists())
            except Exception:
                exists = False
            if exists and key and key not in seen:
                roots.append(root); seen.add(key)
        return roots

    def _description_source_editor_changed(self):
        if bool(getattr(self, "_desc_source_editor_syncing", False)):
            return
        try:
            self.desc_source_summary.setText("Đã thay đổi đường dẫn • bấm Áp dụng đường dẫn hoặc Quét mô tả")
        except Exception:
            pass

    def _description_apply_roots_editor(self, show_message=False):
        """Đọc ô nhiều dòng; nguồn Thumbnail luôn tự động giữ, các dòng khác lưu vào desc_custom_roots."""
        if not hasattr(self, "desc_source_editor"):
            return list(getattr(self, "desc_custom_roots", []) or [])
        raw_lines = self.desc_source_editor.toPlainText().replace("\r\n", "\n").replace("\r", "\n").split("\n")
        thumb_roots = self._description_thumbnail_roots()
        thumb_keys = {self._description_root_key(x) for x in thumb_roots}
        custom, seen = [], set(thumb_keys)
        invalid = []
        for line in raw_lines:
            root = str(line or "").strip().strip('"').strip()
            if not root:
                continue
            key = self._description_root_key(root)
            if not key or key in seen:
                continue
            seen.add(key)
            custom.append(root)
            try:
                if not Path(normalize_path(root)).is_dir():
                    invalid.append(root)
            except Exception:
                invalid.append(root)
        old_keys = {self._description_root_key(x) for x in list(getattr(self, "desc_custom_roots", []) or [])}
        new_keys = {self._description_root_key(x) for x in custom}
        self.desc_custom_roots = custom
        if old_keys != new_keys:
            with self.desc_lock:
                self.desc_jobs = []
                self.desc_stats = {"total": 0, "done": 0, "error": 0, "running": 0, "queued": 0, "skipped": 0}
            self.desc_last_message = "Nguồn thư mục đã thay đổi • hãy Quét mô tả"
        self.schedule_save_state()
        self._refresh_description_sources_ui(force=True)
        if show_message:
            active = len(self._description_queue_roots())
            msg = f"Đã áp dụng {active} thư mục Crawl"
            if invalid:
                msg += f" • {len(invalid)} đường dẫn chưa tồn tại"
            self.statusBar().showMessage(msg, 3000)
        return custom

    def _refresh_description_sources_ui(self, force=False):
        if not hasattr(self, "desc_source_editor"):
            return
        try:
            thumb_roots = self._description_thumbnail_roots()
            custom_roots = list(getattr(self, "desc_custom_roots", []) or [])
            thumb_keys = {self._description_root_key(x) for x in thumb_roots}
            combined, seen = [], set()
            for root in thumb_roots + custom_roots:
                root = str(root or "").strip()
                key = self._description_root_key(root)
                if root and key and key not in seen:
                    combined.append(root); seen.add(key)

            # Không ghi đè khi người dùng đang gõ, trừ khi vừa bấm Áp dụng/Chọn/Xóa.
            if force or not self.desc_source_editor.hasFocus():
                text = "\n".join(combined)
                if self.desc_source_editor.toPlainText().strip() != text.strip():
                    self._desc_source_editor_syncing = True
                    try:
                        self.desc_source_editor.setPlainText(text)
                    finally:
                        self._desc_source_editor_syncing = False

            custom_active, invalid_count = 0, 0
            for root in custom_roots:
                if self._description_root_key(root) in thumb_keys:
                    continue
                try:
                    if Path(normalize_path(root)).is_dir():
                        custom_active += 1
                    else:
                        invalid_count += 1
                except Exception:
                    invalid_count += 1
            total = len(self._description_queue_roots())
            if total:
                suffix = f" • không tồn tại: {invalid_count}" if invalid_count else ""
                self.desc_source_summary.setText(
                    f"Đang dùng {total} thư mục • tự động từ Thumbnail: {len(thumb_roots)} • nhập thêm: {custom_active}{suffix}"
                )
            else:
                self.desc_source_summary.setText("Chưa có nguồn • mỗi thư mục Crawl nhập trên một dòng")

            busy = bool(getattr(self, "desc_running", False) or getattr(self, "running", False))
            self.desc_add_roots_btn.setEnabled(not busy)
            self.desc_apply_roots_btn.setEnabled(not busy)
            self.desc_clear_roots_btn.setEnabled(not busy and bool(custom_roots))
            self.desc_source_editor.setReadOnly(busy)
        except Exception as e:
            try:
                self.desc_source_summary.setText(f"Không đọc được nguồn: {e}")
            except Exception:
                pass

    def _description_pick_custom_roots(self):
        if getattr(self, "running", False) or getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Hãy đợi công việc hiện tại hoàn tất rồi chọn thêm thư mục Crawl.")
            return
        dialog = QFileDialog(self, "Chọn một hoặc nhiều thư mục Crawl")
        dialog.setFileMode(QFileDialog.Directory)
        dialog.setOption(QFileDialog.ShowDirsOnly, True)
        dialog.setOption(QFileDialog.DontUseNativeDialog, True)
        try:
            for view in dialog.findChildren(QListView) + dialog.findChildren(QTreeView):
                view.setSelectionMode(QAbstractItemView.ExtendedSelection)
        except Exception:
            pass
        if dialog.exec() != QDialog.Accepted:
            return
        selected = [str(x or "").strip() for x in dialog.selectedFiles()]
        selected = [x for x in selected if x and Path(normalize_path(x)).is_dir()]
        if not selected:
            return
        current = list(getattr(self, "desc_custom_roots", []) or [])
        keys = {self._description_root_key(x) for x in self._description_thumbnail_roots() + current}
        added = 0
        for root in selected:
            key = self._description_root_key(root)
            if key and key not in keys:
                current.append(root); keys.add(key); added += 1
        self.desc_custom_roots = current
        self._refresh_description_sources_ui(force=True)
        self.schedule_save_state()
        self.statusBar().showMessage(f"Đã thêm {added} thư mục Crawl", 2200)

    def _description_remove_selected_roots(self):
        # Giữ tên hàm để tương thích code cũ; giao diện v13.11 dùng ô văn bản nên người dùng xóa trực tiếp dòng rồi bấm Áp dụng.
        self._description_apply_roots_editor(show_message=True)

    def _description_clear_custom_roots(self):
        if not list(getattr(self, "desc_custom_roots", []) or []):
            return
        if QMessageBox.question(self, APP_TITLE, "Xóa toàn bộ các thư mục Crawl nhập thêm?\nNguồn bên Tạo Thumbnail vẫn được giữ tự động.") != QMessageBox.Yes:
            return
        self.desc_custom_roots = []
        self._refresh_description_sources_ui(force=True)
        self.schedule_save_state()

    @staticmethod
    def _description_compare_text(text):
        """Chuẩn hóa nhẹ để so mô tả hiện tại với bản gốc đã backup."""
        value = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
        value = "\n".join(line.rstrip() for line in value.split("\n"))
        return value.strip()

    def _description_persisted_status(self, desc_path, current_text):
        """
        Nhận lại trạng thái sau khi bấm Quét hoặc mở lại tool.

        - Có backup gốc và nội dung hiện tại khác bản gốc: đã sửa (done).
        - Nội dung hiện tại giống bản gốc / chưa có backup: đang chờ sửa (queued).

        Không tạo thêm thư mục khi quét, nên chỉ đọc trạng thái đã có trên ổ đĩa.
        """
        try:
            desc_path = Path(desc_path)
            # v13.17: nhận diện file đã bị bản cũ ghi nhầm trạng thái "Translating...".
            current_low = str(current_text or "").strip().lower()
            placeholder_lines = [x.strip() for x in current_low.splitlines() if x.strip()]
            placeholder_set = {"translating", "translating...", "translation", "translation results", ".", "..", "...", "....", ".....", "......"}
            if placeholder_lines and all(x in placeholder_set for x in placeholder_lines):
                return "error", "Bản dịch lỗi chỉ có trạng thái Translating • dùng Hoàn tác dịch rồi dịch lại"
            backup_dir = desc_path.parent / "_description_before_rewrite"
            first_path = backup_dir / "description_FIRST_ORIGINAL.txt"

            original_path = None
            if first_path.is_file():
                original_path = first_path
            elif backup_dir.is_dir():
                # Hỗ trợ backup của các bản cũ chưa có FIRST_ORIGINAL.
                old_baks = [p for p in backup_dir.glob("*.bak.txt") if p.is_file()]
                old_baks.sort(key=lambda x: (x.name.lower(), x.stat().st_mtime if x.exists() else 0))
                if old_baks:
                    original_path = old_baks[0]

            if original_path is None:
                return "queued", "Chưa sửa"

            original = original_path.read_text(encoding="utf-8-sig", errors="ignore")
            current_key = self._description_compare_text(current_text)
            original_key = self._description_compare_text(original)

            if current_key and original_key and current_key != original_key:
                return "done", f"Đã sửa trước đó • gốc: {original_path.name}"
            return "queued", f"Đang là mô tả gốc • gốc: {original_path.name}"
        except Exception as e:
            return "queued", f"Không đọc được trạng thái cũ: {str(e)[:120]}"

    def _scan_description_jobs_sync(self):
        roots = self._description_queue_roots()
        thumb_re = re.compile(r"^thumbnail-original-(\d+)-final\.(png|jpg|jpeg|webp)$", re.I)
        ignore_names = {"_debug", "_v11_dashboard_runs", "_simple_parallel_runs", "outputs", "__pycache__", "_gemini_before_overwrite", "_description_before_rewrite"}
        jobs = []
        seen = set()
        for root_raw in roots:
            root = Path(normalize_path(root_raw))
            if not root.exists():
                continue
            for desc in root.rglob("description.txt"):
                try:
                    if not desc.is_file():
                        continue
                    parts_lower = {str(part).lower() for part in desc.parts}
                    if any(name.lower() in parts_lower for name in ignore_names):
                        continue
                    has_thumb = any(p.is_file() and (thumb_re.match(p.name) or p.name.lower() == "thumbnail.jpg") for p in desc.parent.iterdir())
                    if not has_thumb:
                        continue
                    key = str(desc.resolve()).lower()
                    if key in seen:
                        continue
                    seen.add(key)
                    txt = desc.read_text(encoding="utf-8-sig", errors="ignore")
                    if not txt.strip():
                        jobs.append({"description_path": str(desc), "folder": str(desc.parent), "status": "skipped", "note": "description.txt trống"})
                    else:
                        persisted_status, persisted_note = self._description_persisted_status(desc, txt)
                        jobs.append({
                            "description_path": str(desc),
                            "folder": str(desc.parent),
                            "status": persisted_status,
                            "note": persisted_note,
                            "size": len(txt),
                        })
                except Exception as e:
                    jobs.append({"description_path": str(desc), "folder": str(getattr(desc, 'parent', '')), "status": "error", "note": f"scan lỗi: {e}"})
        jobs.sort(key=lambda j: str(j.get("description_path") or "").lower())
        return jobs

    def _desc_compute_stats(self):
        jobs = list(getattr(self, "desc_jobs", []) or [])
        return {
            "total": len(jobs),
            "done": sum(1 for j in jobs if j.get("status") == "done"),
            "error": sum(1 for j in jobs if j.get("status") == "error"),
            "running": sum(1 for j in jobs if j.get("status") == "running"),
            "queued": sum(1 for j in jobs if j.get("status") == "queued"),
            "skipped": sum(1 for j in jobs if j.get("status") == "skipped"),
        }

    def _description_backup_dir(self, desc_path):
        return Path(desc_path).parent / "_description_before_rewrite"

    def _description_first_backup_path(self, desc_path, create_from_text=None):
        """Return/create the first-original backup.
        v12.79: restore must always go back to the very first description, even after many rewrites.
        If old v12.78 timestamp backups already exist, use the oldest one as the first original.
        """
        desc_path = Path(desc_path)
        backup_dir = self._description_backup_dir(desc_path)
        first_path = backup_dir / "description_FIRST_ORIGINAL.txt"
        try:
            if first_path.exists() and first_path.is_file():
                return first_path
        except Exception:
            pass
        try:
            backup_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            return None
        # Migrate from v12.78 timestamp backups: oldest backup is the first original.
        try:
            old_baks = [p for p in backup_dir.glob("*.bak.txt") if p.is_file()]
            old_baks.sort(key=lambda x: (x.name.lower(), x.stat().st_mtime if x.exists() else 0))
            if old_baks:
                txt = old_baks[0].read_text(encoding="utf-8-sig", errors="ignore")
                first_path.write_text(txt.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
                return first_path
        except Exception:
            pass
        if create_from_text is not None:
            try:
                first_path.write_text(str(create_from_text).rstrip("\n") + "\n", encoding="utf-8", errors="replace")
                return first_path
            except Exception:
                return None
        return first_path if first_path.exists() else None

    def restore_original_descriptions(self):
        if getattr(self, "running", False):
            QMessageBox.information(self, APP_TITLE, "Đang vẽ thumb, hãy đợi xong hoặc bấm Dừng trước khi khôi phục mô tả gốc.")
            return
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa/khôi phục mô tả, hãy đợi xong.")
            return
        self._description_apply_roots_editor(show_message=False)
        roots = self._description_queue_roots()
        if not roots:
            QMessageBox.information(self, APP_TITLE, "Chưa có nguồn thư mục Crawl để khôi phục description.txt.")
            return
        try:
            jobs = self._scan_description_jobs_sync()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không quét được description.txt:\n{e}")
            return
        if not jobs:
            QMessageBox.information(self, APP_TITLE, "Không tìm thấy description.txt trong các thư mục có thumbnail.")
            return
        if QMessageBox.question(
            self,
            APP_TITLE,
            f"Khôi phục mô tả gốc cho {len(jobs)} file description.txt?\n"
            "Tool sẽ lấy bản mô tả đầu tiên trong _description_before_rewrite/description_FIRST_ORIGINAL.txt.\n"
            "Nếu file từng được sửa bằng v12.78, tool sẽ tự lấy backup cũ nhất làm mô tả đầu tiên."
        ) != QMessageBox.Yes:
            return
        with self.desc_lock:
            self.desc_jobs = list(jobs)
            for j in self.desc_jobs:
                j["status"] = "queued"
                j["note"] = "Chờ khôi phục mô tả gốc"
            self.desc_stats = self._desc_compute_stats()
        self.desc_running = True
        self.desc_last_message = f"Đang khôi phục {len(jobs)} mô tả gốc"
        self.ui_queue.put(("desc_progress", self.desc_stats, self.desc_last_message))
        self.append_log(f"[desc-restore] ▶ bắt đầu khôi phục mô tả gốc • jobs={len(jobs)}")

        def _work():
            try:
                for job in list(self.desc_jobs):
                    desc_path = Path(str(job.get("description_path") or ""))
                    folder_name = desc_path.parent.name if desc_path else "?"
                    try:
                        with self.desc_lock:
                            job["status"] = "running"
                            job["note"] = "Đang khôi phục mô tả đầu tiên"
                            stats = self._desc_compute_stats()
                        self.ui_queue.put(("desc_progress", stats, f"Khôi phục: {folder_name}"))
                        first_path = self._description_first_backup_path(desc_path, create_from_text=None)
                        if not first_path or not Path(first_path).exists():
                            raise FileNotFoundError("Chưa có backup mô tả gốc để khôi phục")
                        original = Path(first_path).read_text(encoding="utf-8-sig", errors="ignore")
                        if not original.strip():
                            raise RuntimeError("Backup mô tả gốc trống")
                        desc_path.write_text(original.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
                        with self.desc_lock:
                            job["status"] = "done"
                            job["note"] = f"Đã khôi phục: {Path(first_path).name}"
                            stats = self._desc_compute_stats()
                        self.ui_queue.put(("desc_progress", stats, f"OK restore: {folder_name}"))
                        self.ui_queue.put(("log", f"[desc-restore] OK • {desc_path}"))
                    except Exception as e:
                        with self.desc_lock:
                            job["status"] = "skipped"
                            job["note"] = str(e)[:240]
                            stats = self._desc_compute_stats()
                        self.ui_queue.put(("desc_progress", stats, f"Bỏ qua: {folder_name}"))
                        self.ui_queue.put(("log", f"[desc-restore] SKIP • {desc_path} • {e}"))
                stats = self._desc_compute_stats()
                self.ui_queue.put(("desc_done_all", stats, f"Khôi phục mô tả gốc xong • {stats.get('done',0)}/{stats.get('total',0)}"))
            except Exception as e:
                self.ui_queue.put(("desc_error_all", f"Khôi phục mô tả gốc lỗi: {e}"))
        threading.Thread(target=_work, daemon=True).start()

    def scan_description_jobs_only(self):
        if getattr(self, "running", False):
            QMessageBox.information(self, APP_TITLE, "Đang vẽ thumb, hãy đợi xong hoặc bấm Dừng trước khi quét mô tả.")
            return
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, chưa thể quét lại.")
            return
        self._description_apply_roots_editor(show_message=False)
        self._refresh_description_sources_ui(force=True)
        roots = self._description_queue_roots()
        if not roots:
            QMessageBox.information(self, APP_TITLE, "Chưa có nguồn để quét. Hãy chọn một hoặc nhiều thư mục Crawl tại trang Sửa mô tả, hoặc cấu hình thư mục ở Tạo Thumbnail.")
            return
        self.desc_last_message = "Đang quét description.txt..."
        self._refresh_project_queue_ui()
        self._refresh_description_workspace()
        self.append_log(f"[desc] quét mô tả trong {len(roots)} thư mục Crawl (Thumbnail + chọn thêm)")
        def _work():
            try:
                jobs = self._scan_description_jobs_sync()
                with self.desc_lock:
                    self.desc_jobs = jobs
                    self.desc_stats = self._desc_compute_stats()
                done = int(self.desc_stats.get("done", 0) or 0)
                queued = int(self.desc_stats.get("queued", 0) or 0)
                skipped = int(self.desc_stats.get("skipped", 0) or 0)
                self.ui_queue.put((
                    "desc_progress",
                    self.desc_stats,
                    f"Đã quét {len(jobs)} description.txt • đã sửa {done} • chờ {queued}",
                ))
                self.ui_queue.put((
                    "log",
                    f"[desc] quét xong • tổng={len(jobs)} • đã sửa={done} • chờ sửa={queued} • bỏ qua={skipped}",
                ))
            except Exception as e:
                self.ui_queue.put(("desc_error_all", f"Quét mô tả lỗi: {e}"))
        threading.Thread(target=_work, daemon=True).start()

    def _make_description_queue_card(self):
        card = QFrame()
        card.setObjectName("QueueCard")
        card.setProperty("selected", "false")
        card.setProperty("active", "true" if getattr(self, "desc_running", False) else "false")
        card.setMinimumWidth(230)
        card.setMaximumWidth(9999)
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        card.setMinimumHeight(138)
        lay = QVBoxLayout(card); lay.setContentsMargins(10, 10, 10, 9); lay.setSpacing(5)
        title_row = QHBoxLayout(); title_row.setContentsMargins(0, 0, 0, 0); title_row.setSpacing(5)
        title = QLabel("Sửa mô tả")
        title.setObjectName("QueueCardTitle")
        title.setToolTip("Đọc description.txt trong các thư mục có thumbnail, gửi prompt Gemini và ghi lại mô tả mới")
        title_row.addWidget(title, 1)
        badge = QLabel("TXT")
        badge.setObjectName("QueueBadge")
        badge.setAlignment(Qt.AlignCenter)
        title_row.addWidget(badge, 0)
        lay.addLayout(title_row)
        stats = dict(getattr(self, "desc_stats", {}) or {})
        total = int(stats.get("total") or 0)
        done = int(stats.get("done") or 0)
        err = int(stats.get("error") or 0)
        running = int(stats.get("running") or 0)
        skipped = int(stats.get("skipped") or 0)
        msg = str(getattr(self, "desc_last_message", "") or "Chưa quét mô tả")
        if len(msg) > 54:
            msg = msg[:51] + "..."
        status = QLabel(f"{done}/{total} xong • đang {running} • lỗi {err}" + (f" • bỏ {skipped}" if skipped else ""))
        status.setObjectName("QueueStats")
        lay.addWidget(status)
        progress = QProgressBar()
        progress.setFixedHeight(18)
        progress.setRange(0, max(1, total))
        progress.setValue(min(max(0, done + skipped), max(1, total)))
        progress.setFormat(f"{int(((done + skipped) / total) * 100) if total else 0}%")
        lay.addWidget(progress)
        note = QLabel(msg)
        note.setObjectName("QueueStats")
        note.setToolTip(str(getattr(self, "desc_last_message", "") or ""))
        lay.addWidget(note)
        # v12.81: 3 nút Sửa mô tả nằm cùng 1 hàng, dùng chữ ngắn để không bị cắt.
        action_row = QHBoxLayout(); action_row.setContentsMargins(0, 0, 0, 0); action_row.setSpacing(5)
        btn_scan = QPushButton("Quét")
        btn_scan.setObjectName("QueueMiniButton")
        btn_scan.setCursor(Qt.PointingHandCursor)
        btn_scan.setFixedHeight(29)
        btn_scan.setStyleSheet("font-size:7.6pt; padding:3px 3px; font-weight:900;")
        btn_scan.setToolTip("Quét mô tả")
        btn_scan.setEnabled((not getattr(self, "running", False)) and (not getattr(self, "desc_running", False)))
        btn_scan.clicked.connect(self.scan_description_jobs_only)
        action_row.addWidget(btn_scan, 1)
        btn_run = QPushButton("Sửa")
        btn_run.setObjectName("AccentButton")
        btn_run.setCursor(Qt.PointingHandCursor)
        btn_run.setFixedHeight(29)
        btn_run.setStyleSheet("font-size:7.6pt; padding:3px 3px; font-weight:900;")
        btn_run.setToolTip("Sửa mô tả")
        btn_run.setEnabled((not getattr(self, "running", False)) and (not getattr(self, "desc_running", False)) and (total > 0 or bool(self._description_queue_roots())))
        btn_run.clicked.connect(self.start_description_rewrite)
        action_row.addWidget(btn_run, 1)
        btn_restore = QPushButton("Khôi phục gốc")
        btn_restore.setObjectName("WarnButton")
        btn_restore.setCursor(Qt.PointingHandCursor)
        btn_restore.setFixedHeight(29)
        btn_restore.setStyleSheet("font-size:7.4pt; padding:3px 3px; font-weight:900;")
        btn_restore.setToolTip("Khôi phục description.txt về bản mô tả đầu tiên trước lần sửa đầu tiên")
        btn_restore.setEnabled((not getattr(self, "running", False)) and (not getattr(self, "desc_running", False)) and bool(self._description_queue_roots()))
        btn_restore.clicked.connect(self.restore_original_descriptions)
        action_row.addWidget(btn_restore, 2)
        lay.addLayout(action_row)
        return card

    def _description_profile_is_usable(self, account_no):
        """v12.99: chỉ tạo worker mô tả khi profile thật đã tồn tại.
        Không tạo profile trống rồi vẫn cho worker nhận job như quy trình cũ.
        """
        try:
            profile = self.backend_dir / "profiles" / f"google_{int(account_no)}"
            if not profile.is_dir():
                return False, profile, "không có thư mục profile"
            default_dir = profile / "Default"
            if not default_dir.is_dir():
                return False, profile, "profile chưa có thư mục Default"
            # Chỉ cần có Preferences/Cookies/Local State là profile đã từng được Chromium dùng.
            signals = [
                profile / "Local State",
                default_dir / "Preferences",
                default_dir / "Network" / "Cookies",
                default_dir / "Cookies",
            ]
            if not any(x.exists() for x in signals):
                return False, profile, "profile chưa có dữ liệu đăng nhập Chromium"
            return True, profile, "OK"
        except Exception as e:
            return False, self.backend_dir / "profiles" / f"google_{account_no}", str(e)

    def _description_is_network_path(self, value):
        """Nhận diện UNC và ổ mạng đã map trên Windows."""
        try:
            s = str(Path(value))
            if s.startswith("\\\\") or s.startswith("//"):
                return True
            if os.name == "nt":
                anchor = Path(s).anchor
                if anchor:
                    DRIVE_REMOTE = 4
                    return int(ctypes.windll.kernel32.GetDriveTypeW(str(anchor))) == DRIVE_REMOTE
        except Exception:
            pass
        return False

    def _description_copy_runtime_dir(self, source_dir, target_dir):
        """Copy runtime bằng robocopy trên Windows; chỉ chạy lần đầu hoặc khi cache đổi."""
        source_dir = Path(source_dir)
        target_dir = Path(target_dir)
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        temp_dir = target_dir.parent / f".{target_dir.name}.copying_{os.getpid()}"
        shutil.rmtree(temp_dir, ignore_errors=True)
        temp_dir.mkdir(parents=True, exist_ok=True)
        try:
            copied = False
            if os.name == "nt":
                try:
                    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                    cp = subprocess.run(
                        [
                            "robocopy", str(source_dir), str(temp_dir), "/E", "/R:1", "/W:1",
                            "/NFL", "/NDL", "/NJH", "/NJS", "/NP", "/XJ",
                            "/XD", "Crashpad", "User Data", "Temp", "Cache",
                        ],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        errors="replace",
                        timeout=900,
                        creationflags=flags,
                    )
                    # Robocopy 0..7 đều là thành công/có khác biệt đã copy.
                    if int(cp.returncode) < 8:
                        copied = True
                    else:
                        raise RuntimeError(f"robocopy lỗi code={cp.returncode}: {(cp.stdout or '')[-500:]}")
                except FileNotFoundError:
                    copied = False
            if not copied:
                shutil.rmtree(temp_dir, ignore_errors=True)
                shutil.copytree(source_dir, temp_dir, dirs_exist_ok=True)
            shutil.rmtree(target_dir, ignore_errors=True)
            os.replace(temp_dir, target_dir)
        except Exception:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise

    def _description_prepare_local_browser_runtime(self):
        """v12.99: Chrome không chạy trực tiếp từ thư mục LAN/UNC.
        Cache Chromium + ChromeDriver vào LOCALAPPDATA của từng máy và tái sử dụng.
        """
        src_chrome = Path(self.chrome_binary)
        src_driver = Path(self.driver_binary)
        if not src_chrome.exists() or not src_driver.exists():
            raise FileNotFoundError(f"Thiếu Chromium/driver: {src_chrome} | {src_driver}")

        chrome_network = self._description_is_network_path(src_chrome)
        driver_network = self._description_is_network_path(src_driver)
        if not chrome_network and not driver_network:
            self._desc_chrome_binary = src_chrome
            self._desc_driver_binary = src_driver
            self.ui_queue.put(("log", f"[desc-runtime] Chrome/Driver đã ở ổ máy • {src_chrome}"))
            return src_chrome, src_driver

        local_base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or str(self.backend_dir))
        cache_root = local_base / "ToolThumbnail" / "desc_browser_cache"
        cache_root.mkdir(parents=True, exist_ok=True)

        def _fingerprint(path):
            st = path.stat()
            raw = f"{path}|{int(st.st_size)}|{int(st.st_mtime)}"
            return hashlib.sha1(raw.encode("utf-8", errors="ignore")).hexdigest()[:12]

        chrome_dst_dir = cache_root / f"chromium_{_fingerprint(src_chrome)}"
        chrome_dst = chrome_dst_dir / src_chrome.name
        driver_dst_dir = cache_root / f"driver_{_fingerprint(src_driver)}"
        driver_dst = driver_dst_dir / src_driver.name

        if chrome_network and not chrome_dst.exists():
            self.ui_queue.put(("log", "[desc-runtime] Lần đầu: đang copy Chromium từ LAN về ổ máy; các lần sau sẽ dùng cache local"))
            self._description_copy_runtime_dir(src_chrome.parent, chrome_dst_dir)
        elif not chrome_network:
            chrome_dst = src_chrome

        if driver_network and not driver_dst.exists():
            self.ui_queue.put(("log", "[desc-runtime] đang copy ChromeDriver về ổ máy"))
            self._description_copy_runtime_dir(src_driver.parent, driver_dst_dir)
        elif not driver_network:
            driver_dst = src_driver

        if not chrome_dst.exists() or not driver_dst.exists():
            raise RuntimeError(f"Cache runtime chưa đầy đủ: {chrome_dst} | {driver_dst}")
        self._desc_chrome_binary = chrome_dst
        self._desc_driver_binary = driver_dst
        # Giữ tối đa 2 cache Chromium/Driver gần nhất để ổ máy không phình dần.
        try:
            for prefix, current in (("chromium_", chrome_dst_dir), ("driver_", driver_dst_dir)):
                items = sorted(
                    [x for x in cache_root.iterdir() if x.is_dir() and x.name.startswith(prefix)],
                    key=lambda x: x.stat().st_mtime,
                    reverse=True,
                )
                for old_dir in items[2:]:
                    if old_dir != current:
                        shutil.rmtree(old_dir, ignore_errors=True)
        except Exception:
            pass
        self.ui_queue.put(("log", f"[desc-runtime] dùng runtime local • Chrome={chrome_dst} • Driver={driver_dst}"))
        return chrome_dst, driver_dst

    def _description_preflight_cleanup(self):
        """v12.97: trước khi sửa mô tả, dọn sạch Chrome/ChromeDriver còn sót từ thumb/bg-login.
        Mục tiêu: tránh Chrome desc crash vì profile Local State/DevToolsActivePort bị khóa.
        Không dọn/xoá profiles/google_* trong lúc desc đang chạy; desc worker chỉ dùng profile clone local trong LOCALAPPDATA/ToolThumbnail/desc_runs.
        """
        try:
            self._desc_profile_prune_guard = True
        except Exception:
            pass
        killed = 0
        try:
            self.append_log("[desc-cleanup] dọn Chrome/thumb/background-login trước khi sửa mô tả")
        except Exception:
            pass
        try:
            self._release_chrome_background_guard(grace=0.0)
        except Exception:
            pass
        try:
            killed = int(self._cleanup_leftover_worker_processes(timeout=1.8) or 0)
        except Exception as e:
            try:
                self.append_log(f"[desc-cleanup] dọn process lỗi nhẹ: {e}")
            except Exception:
                pass
        # Chrome/Chromedriver cần một nhịp để nhả lock Local State/SingletonLock.
        try:
            time.sleep(float(os.environ.get("GEMINI_DESC_PREFLIGHT_SLEEP", "1.2") or 1.2))
        except Exception:
            time.sleep(1.0)
        try:
            self.append_log(f"[desc-cleanup] OK • đã dọn {killed} process còn sót; desc sẽ dùng profile clone LOCAL riêng")
        except Exception:
            pass
        return killed

    def start_description_rewrite(self):
        self._description_apply_roots_editor(show_message=False)
        if getattr(self, "running", False):
            QMessageBox.information(self, APP_TITLE, "Đang vẽ thumb, hãy đợi xong hoặc bấm Dừng trước khi sửa mô tả.")
            return
        if getattr(self, "desc_running", False):
            return
        if not (self.chrome_binary and Path(self.chrome_binary).exists() and self.driver_binary and Path(self.driver_binary).exists()):
            QMessageBox.critical(self, APP_TITLE, f"Thiếu Chromium/chromedriver:\nChrome: {self.chrome_binary}\nDriver: {self.driver_binary}")
            return
        try:
            if not getattr(self, "desc_jobs", None):
                self.desc_jobs = self._scan_description_jobs_sync()
            with self.desc_lock:
                for j in self.desc_jobs:
                    if j.get("status") == "error":
                        j["status"] = "queued"
                        j["note"] = "Chạy lại lỗi mô tả"
                jobs_to_run = [j for j in self.desc_jobs if j.get("status") == "queued"]
                self.desc_stats = self._desc_compute_stats()
            if not jobs_to_run:
                QMessageBox.information(self, APP_TITLE, "Không có description.txt nào cần sửa. Bấm Quét nếu vừa đổi thư mục.")
                self._refresh_project_queue_ui()
                return
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không quét được description.txt:\n{e}")
            return

        # v13.44: chỉ kiểm tra pool account thật sự của máy này (thường 20 account),
        # không quét toàn bộ hàng A1..A500 trong giao diện rồi ghi hàng trăm dòng profile thiếu.
        requested_accounts = []
        try:
            requested_accounts = list(dict.fromkeys(int(x) for x in (self._configured_accounts() or [])))
        except Exception:
            requested_accounts = []
        # Bổ sung trực tiếp các thư mục profile thật đang tồn tại trên máy. Cách này vẫn không
        # quét A1..A500, nhưng không làm mất các profile tốt như A9 chỉ vì không nằm trong pool vẽ ảnh.
        try:
            existing = []
            profiles_root = self.backend_dir / "profiles"
            for folder in profiles_root.glob("google_*") if profiles_root.exists() else []:
                m = re.fullmatch(r"google_(\d+)", folder.name, re.I)
                if m and (folder / "Default").exists():
                    existing.append(int(m.group(1)))
            for acc in sorted(set(existing)):
                if acc not in requested_accounts:
                    requested_accounts.append(acc)
        except Exception:
            pass
        if not requested_accounts:
            QMessageBox.warning(self, APP_TITLE, "Không tìm thấy profile Google nào trên máy để sửa mô tả.")
            return
        self.append_log("[desc-preflight] kiểm tra pool máy: " + ",".join(f"A{x}" for x in requested_accounts))

        # v12.99: loại profile thiếu ngay từ đầu. Worker thiếu profile tuyệt đối không được lấy job.
        valid_accounts, invalid_accounts = [], []
        for acc in requested_accounts:
            ok, profile, reason = self._description_profile_is_usable(acc)
            if ok:
                valid_accounts.append(acc)
            else:
                invalid_accounts.append((acc, reason))
        if invalid_accounts:
            preview_invalid = ", ".join(f"A{a} ({r})" for a, r in invalid_accounts[:8])
            suffix = f" • và {len(invalid_accounts)-8} profile khác" if len(invalid_accounts) > 8 else ""
            self.append_log("[desc-preflight] bỏ profile không dùng được: " + preview_invalid + suffix)
        if not valid_accounts:
            QMessageBox.warning(
                self,
                APP_TITLE,
                "Không có profile Google hợp lệ để sửa mô tả.\n"
                "Hãy đăng nhập/kiểm tra tài khoản trước rồi chạy lại.",
            )
            return

        requested_workers = max(1, int(self.worker_spin.value() if hasattr(self, "worker_spin") else 1))
        stable_cap = max(1, int(os.environ.get("GEMINI_DESC_MAX_WORKERS", "4") or 4))
        workers = max(1, min(requested_workers, stable_cap, len(valid_accounts), len(jobs_to_run)))
        accounts = valid_accounts[:workers]
        failover_accounts = valid_accounts[workers:] + accounts
        if requested_workers > workers:
            self.append_log(
                f"[desc-preflight] yêu cầu {requested_workers} luồng; dùng {workers} luồng ổn định "
                f"(profile hợp lệ={len(valid_accounts)}, giới hạn desc={stable_cap})"
            )

        self._description_preflight_cleanup()
        local_base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or str(self.backend_dir))
        run_root = local_base / "ToolThumbnail" / "desc_runs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        try:
            run_root.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không tạo được thư mục chạy mô tả local:\n{run_root}\n{e}")
            return
        self._desc_current_run_root = run_root

        self.desc_running = True
        self.desc_operation = "rewrite"
        self.desc_stop_event.clear()
        self.desc_last_message = f"Đang chuẩn bị sửa {len(jobs_to_run)} mô tả bằng {workers} luồng"
        self.ui_queue.put(("desc_progress", self.desc_stats, self.desc_last_message))
        self.append_log(
            f"[desc] ▶ chuẩn bị sửa mô tả • jobs={len(jobs_to_run)} • workers={workers} "
            f"• profile hợp lệ={len(valid_accounts)}/{len(requested_accounts)} • profile clone LOCAL"
        )
        self.status_label.setText(f"Đang chuẩn bị sửa mô tả • {len(jobs_to_run)} file • {workers} luồng")
        desc_q = queue.Queue()
        for j in jobs_to_run:
            desc_q.put(j)

        def _run_worker_batch(batch_accounts, q_obj, wid_prefix="", attempts_override=None, timeout_override=None):
            threads = []
            startup_gap = max(0.2, float(os.environ.get("GEMINI_DESC_WORKER_START_GAP", "1.4") or 1.4))
            for idx, acc in enumerate(batch_accounts, 1):
                if self.desc_stop_event.is_set():
                    break
                wid = f"{wid_prefix}{idx}" if wid_prefix else idx
                t = threading.Thread(
                    target=self._description_worker_loop,
                    args=(wid, acc, q_obj, run_root, attempts_override, timeout_override),
                    daemon=True,
                )
                t.start()
                threads.append(t)
                if idx < len(batch_accounts):
                    time.sleep(startup_gap)
            for t in threads:
                try:
                    t.join()
                except Exception:
                    pass

        def _run_all():
            desc_run_started = time.time()
            try:
                # Copy/cache runtime trên background thread, không làm treo giao diện.
                self._description_prepare_local_browser_runtime()
                self.ui_queue.put(("log", f"[desc] bắt đầu worker • accounts={','.join('A'+str(a) for a in accounts)}"))
                _run_worker_batch(accounts, desc_q, wid_prefix="", attempts_override=None)
                stopped = self.desc_stop_event.is_set()

                # Worker nào không qua preflight sẽ không lấy job. Dùng account dự phòng vét phần queue còn nguyên.
                if not stopped:
                    with self.desc_lock:
                        queued_after_main = [j for j in self.desc_jobs if j.get("status") == "queued"]
                    if queued_after_main:
                        fallback_worker_count = max(1, min(len(queued_after_main), len(failover_accounts), workers))
                        fallback_accounts = failover_accounts[:fallback_worker_count]
                        self.ui_queue.put(("desc_progress", self._desc_compute_stats(), f"Đổi worker khỏe • còn {len(queued_after_main)} file"))
                        self.ui_queue.put(("log", f"[desc] còn {len(queued_after_main)} job chưa được lấy • thử account dự phòng={','.join('A'+str(a) for a in fallback_accounts)}"))
                        _run_worker_batch(fallback_accounts, desc_q, wid_prefix="F", attempts_override=1)

                # v13.44: vòng cứu cuối dùng account KHÁC nhóm chính và timeout riêng 60 giây.
                if not stopped:
                    try:
                        with self.desc_lock:
                            rescue_jobs = [j for j in self.desc_jobs if j.get("status") == "error"]
                            for j in rescue_jobs:
                                j["status"] = "queued"
                                j["note"] = "Cứu lỗi cuối • account khác • timeout 60 giây"
                            self.desc_stats = self._desc_compute_stats()
                        if rescue_jobs:
                            rescue_q = queue.Queue()
                            for j in rescue_jobs:
                                rescue_q.put(j)
                            unused_accounts = [a for a in valid_accounts if a not in accounts]
                            rotated_accounts = unused_accounts + list(reversed(accounts))
                            rescue_workers = max(1, min(len(rescue_jobs), len(rotated_accounts), workers))
                            rescue_accounts = rotated_accounts[:rescue_workers]
                            self.ui_queue.put(("desc_progress", self.desc_stats, f"Cứu lỗi cuối • {len(rescue_jobs)} file • timeout 60 giây"))
                            self.ui_queue.put(("log", f"[desc-rescue] vòng cuối 60s • jobs={len(rescue_jobs)} • account khác={','.join('A'+str(a) for a in rescue_accounts)}"))
                            _run_worker_batch(rescue_accounts, rescue_q, wid_prefix="R", attempts_override=1, timeout_override=60)
                    except Exception as e:
                        self.ui_queue.put(("log", f"[desc-rescue] lỗi nhẹ: {e}"))

                # Nếu tất cả worker chết trước khi lấy job, không để queue treo mãi.
                with self.desc_lock:
                    untouched = [j for j in self.desc_jobs if j.get("status") == "queued"]
                    if untouched and not self.desc_stop_event.is_set():
                        for j in untouched:
                            j["status"] = "error"
                            j["note"] = "Không còn worker Chrome hoạt động"
                    stats = self._desc_compute_stats()
                stopped = self.desc_stop_event.is_set()
                msg = "Đã dừng sửa mô tả" if stopped else f"Sửa mô tả xong • {stats.get('done',0)}/{stats.get('total',0)} • lỗi {stats.get('error',0)}"
                self.ui_queue.put(("desc_done_all", stats, msg))
                total_elapsed = time.time() - desc_run_started
                avg_done = total_elapsed / max(1, int(stats.get("done", 0) or 0)) if int(stats.get("done", 0) or 0) else 0
                self.ui_queue.put(("log", f"[desc] {'STOP' if stopped else 'DONE'} • tổng {self._desc_fmt_sec(total_elapsed)} • TB/OK {self._desc_fmt_sec(avg_done)} • done={stats.get('done',0)} error={stats.get('error',0)} total={stats.get('total',0)}"))
            except Exception as e:
                with self.desc_lock:
                    for j in self.desc_jobs:
                        if j.get("status") in ("queued", "running"):
                            j["status"] = "error"
                            j["note"] = f"Không chuẩn bị được runtime sửa mô tả: {str(e)[:180]}"
                    stats = self._desc_compute_stats()
                self.ui_queue.put(("log", f"[desc-runtime] ERROR • {type(e).__name__}: {e}"))
                self.ui_queue.put(("desc_done_all", stats, f"Sửa mô tả lỗi • không mở được Chrome local: {e}"))
            finally:
                try:
                    self._desc_profile_prune_guard = False
                except Exception:
                    pass
                # Chỉ dọn profile clone của phiên này; profile thật không bị đụng tới.
                try:
                    shutil.rmtree(run_root, ignore_errors=True)
                except Exception:
                    pass
                self._desc_current_run_root = None
                self.desc_operation = "idle"

        threading.Thread(target=_run_all, daemon=True).start()

    def _description_translation_target(self):
        display = str(getattr(self, "desc_translate_language", "English") or "English").strip()
        mapping = {
            "Tiếng Việt": ("Vietnamese", "vi"), "Español": ("Spanish", "es"),
            "Português": ("Portuguese", "pt"), "Italiano": ("Italian", "it"),
            "Deutsch": ("German", "de"), "Français": ("French", "fr"),
            "日本語": ("Japanese", "ja"), "한국어": ("Korean", "ko"),
            "Русский": ("Russian", "ru"), "العربية": ("Arabic", "ar"),
            "हिन्दी": ("Hindi", "hi"), "Bahasa Indonesia": ("Indonesian", "id"),
            "ภาษาไทย": ("Thai", "th"), "English": ("English", "en"),
        }
        target_name, target_code = mapping.get(display, (display or "English", ""))
        if not target_code:
            aliases = {
                "vietnamese": "vi", "english": "en", "spanish": "es", "portuguese": "pt",
                "italian": "it", "german": "de", "french": "fr", "japanese": "ja",
                "korean": "ko", "russian": "ru", "arabic": "ar", "hindi": "hi",
                "indonesian": "id", "thai": "th", "chinese": "zh-CN", "simplified chinese": "zh-CN",
                "traditional chinese": "zh-TW", "dutch": "nl", "polish": "pl", "turkish": "tr",
            }
            key = str(target_name or "").strip().lower()
            target_code = aliases.get(key, key if re.fullmatch(r"[A-Za-z]{2,3}(?:-[A-Za-z]{2,4})?", key) else "")
        return target_name or "English", display or "English", target_code

    @staticmethod
    def _description_translation_clean_text(text):
        value = str(text or "").strip()
        if value.startswith("```") and value.endswith("```"):
            lines = value.splitlines()
            if len(lines) >= 3:
                value = "\n".join(lines[1:-1]).strip()
        return value.strip()

    @staticmethod
    def _google_translate_protect_text(text):
        """Giữ nguyên URL, email, hashtag và @mention khi dịch bằng giao diện Google Translate."""
        value = str(text or "")
        mapping = {}
        pattern = re.compile(
            r"https?://[^\s<>]+|www\.[^\s<>]+|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|(?<!\w)#[\w.-]+|(?<!\w)@[\w.-]+",
            re.I | re.UNICODE,
        )
        serial = 0
        def repl(match):
            nonlocal serial
            serial += 1
            token = f"QZXGT{serial:05d}XZQ"
            mapping[token] = match.group(0)
            return token
        return pattern.sub(repl, value), mapping

    @staticmethod
    def _google_translate_restore_text(text, mapping):
        value = str(text or "")
        for token, original in (mapping or {}).items():
            value = re.sub(re.escape(token), lambda _m, v=original: v, value, flags=re.I)
            spaced = r"\s*".join(map(re.escape, token))
            value = re.sub(spaced, lambda _m, v=original: v, value, flags=re.I)
        return value

    @staticmethod
    def _google_translate_split_text(text, max_chars=4500):
        """Chia mô tả dài theo đoạn, luôn dưới giới hạn giao diện Google Translate."""
        src = str(text or "")
        if len(src) <= max_chars:
            return [src]
        blocks = re.split(r"(\n{2,})", src)
        chunks, current = [], ""
        for block in blocks:
            if not block:
                continue
            if len(current) + len(block) <= max_chars:
                current += block
                continue
            if current:
                chunks.append(current)
                current = ""
            if len(block) <= max_chars:
                current = block
                continue
            lines = block.splitlines(keepends=True) or [block]
            for line in lines:
                while len(line) > max_chars:
                    cut = line.rfind(" ", 0, max_chars)
                    if cut < max_chars // 2:
                        cut = max_chars
                    chunks.append(line[:cut])
                    line = line[cut:]
                if len(current) + len(line) > max_chars and current:
                    chunks.append(current)
                    current = ""
                current += line
        if current:
            chunks.append(current)
        return chunks or [src]

    def _description_build_translation_batches(self, jobs):
        batches = []
        serial = 0
        for job in jobs:
            path = Path(str(job.get("description_path") or ""))
            try:
                text = path.read_text(encoding="utf-8-sig", errors="ignore").strip()
            except Exception:
                text = ""
            if not text:
                with self.desc_lock:
                    job["status"] = "skipped"
                    job["note"] = "description.txt trống"
                continue
            serial += 1
            batches.append([{"id": f"T{serial:04d}", "job": job, "path": path, "text": text}])
        return batches

    @staticmethod
    def _google_translate_target_language_label(target_code):
        mapping = {
            "vi": "Vietnamese", "en": "English", "es": "Spanish", "pt": "Portuguese",
            "it": "Italian", "de": "German", "fr": "French", "ja": "Japanese",
            "ko": "Korean", "ru": "Russian", "ar": "Arabic", "hi": "Hindi",
            "id": "Indonesian", "th": "Thai", "zh-cn": "Chinese", "zh-tw": "Chinese",
            "nl": "Dutch", "pl": "Polish", "tr": "Turkish",
        }
        return mapping.get(str(target_code or "").strip().lower(), "")

    def _google_translate_source_is_target(self, text, target_code):
        source_label = self._description_detect_language_label(text)
        target_label = self._google_translate_target_language_label(target_code)
        return bool(target_label and source_label == target_label), source_label, target_label

    @staticmethod
    def _google_translate_has_translatable_text(text):
        value = str(text or "")
        value = re.sub(r"https?://\S+|www\.\S+|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", " ", value, flags=re.I)
        value = re.sub(r"(?<!\w)[#@][\w.-]+", " ", value, flags=re.UNICODE)
        words = re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿĀ-žăđơưĂĐƠƯА-Яа-яЁёء-يก-๙ऀ-ॿ가-힣ぁ-んァ-ン一-龯]{2,}", value)
        return len(words) >= 2

    def _google_translate_force_detect_language(self, drv, target_code):
        """Luôn giữ ngôn ngữ nguồn ở Detect language và giữ đúng ngôn ngữ đích."""
        target_code = str(target_code or "en").strip() or "en"
        expected = f"https://translate.google.com/?sl=auto&tl={target_code}&op=translate"
        try:
            current_url = str(getattr(drv, "current_url", "") or "")
            low = current_url.lower()
            if "translate.google.com" not in low or "sl=auto" not in low or f"tl={target_code.lower()}" not in low:
                drv.get(expected)
                from selenium.webdriver.common.by import By
                from selenium.webdriver.support.ui import WebDriverWait
                from selenium.webdriver.support import expected_conditions as EC
                WebDriverWait(drv, 20).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'textarea[aria-label="Source text"]')))
        except Exception:
            try:
                drv.get(expected)
            except Exception:
                pass
        try:
            drv.execute_script(r"""
                const selectors = [
                  'button[data-language-code="auto"]',
                  '[role="tab"][data-language-code="auto"]',
                  'button[aria-label*="Detect language"]',
                  'button[aria-label*="Phát hiện ngôn ngữ"]'
                ];
                for (const sel of selectors) {
                  const el = document.querySelector(sel);
                  if (el) { try { el.click(); } catch(e) {} return true; }
                }
                return false;
            """)
        except Exception:
            pass
        try:
            drv._gt_source_mode = "auto"
            drv._gt_target_code = target_code
        except Exception:
            pass
        return True

    def _description_translation_mark_already_target(self, row, target_display, target_code, source_label, wid):
        job = row["job"]
        path = Path(row["path"])
        with self.desc_lock:
            job["status"] = "done"
            job["note"] = f"Đã là {target_display} • không cần dịch"
            job["size"] = len(str(row.get("text") or ""))
            try:
                checked = set(getattr(self, "desc_checked_paths", set()) or set())
                checked.discard(str(path).lower())
                self.desc_checked_paths = checked
            except Exception:
                pass
            stats = self._desc_compute_stats()
        self.ui_queue.put(("log", f"[gtranslate-W{wid}] BỎ QUA • nguồn={source_label} (Detect language) → đích={target_display} • đã đúng ngôn ngữ • {path}"))
        self.ui_queue.put(("desc_progress", stats, f"Đã đúng {target_display}: {path.parent.name}"))
        return True

    def _description_translation_write_result(self, row, translated, target_display, wid):
        job = row["job"]
        path = Path(row["path"])
        original_current = str(row.get("text") or "")
        translated = self._description_translation_clean_text(translated)
        # Lớp chặn cuối trước khi ghi file: tuyệt đối không cho placeholder/loading lọt qua.
        valid, cleaned_or_reason = self._google_translate_result_is_valid(translated, original_current, "")
        if not valid:
            raise RuntimeError(f"Không ghi bản dịch chưa hoàn chỉnh: {cleaned_or_reason}")
        translated = cleaned_or_reason
        self._description_first_backup_path(path, create_from_text=original_current)
        backup = self._description_backup_before_translation(path, original_current, wid=str(wid))
        tmp = path.with_name(path.name + f".translate_{os.getpid()}_{threading.get_ident()}.tmp")
        tmp.write_text(translated.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
        os.replace(tmp, path)
        with self.desc_lock:
            job["status"] = "done"
            job["note"] = f"Detect language → {target_display} • backup: {backup.name}"
            job["size"] = len(translated)
            try:
                checked = set(getattr(self, "desc_checked_paths", set()) or set())
                checked.discard(str(path).lower())
                self.desc_checked_paths = checked
            except Exception:
                pass
            stats = self._desc_compute_stats()
        self.ui_queue.put(("desc_progress", stats, f"Đã dịch: {path.parent.name}"))
        return backup

    def _google_translate_open_driver(self, wid, run_root, target_code, headless=True):
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC

        profile_dir = Path(run_root) / f"google_translate_worker_{wid}"
        profile_dir.mkdir(parents=True, exist_ok=True)
        chrome_bin = Path(getattr(self, "_desc_chrome_binary", None) or self.chrome_binary)
        driver_bin = Path(getattr(self, "_desc_driver_binary", None) or self.driver_binary)
        opts = webdriver.ChromeOptions()
        opts.binary_location = normalize_path(chrome_bin)
        opts.add_argument(f"--user-data-dir={normalize_path(profile_dir)}")
        opts.add_argument("--profile-directory=Default")
        if headless:
            opts.add_argument("--headless=new")
        else:
            opts.add_argument("--window-position=-32000,-32000")
            opts.add_argument("--start-minimized")
        opts.add_argument("--window-size=1365,900")
        opts.add_argument("--remote-debugging-port=0")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--disable-backgrounding-occluded-windows")
        opts.add_argument("--disable-renderer-backgrounding")
        opts.add_argument("--no-first-run")
        opts.add_argument("--no-default-browser-check")
        opts.add_argument("--disable-notifications")
        opts.add_argument("--disable-popup-blocking")
        opts.add_argument("--disable-sync")
        opts.add_argument("--disable-extensions")
        opts.add_argument("--lang=en-US")
        opts.add_experimental_option("excludeSwitches", ["enable-automation"])
        opts.add_experimental_option("useAutomationExtension", False)
        _drv_path = Path(driver_bin) if driver_bin else None
        if _drv_path is not None and _drv_path.is_file():
            drv = webdriver.Chrome(service=Service(normalize_path(_drv_path)), options=opts)
        else:
            drv = webdriver.Chrome(options=opts)
        drv.set_page_load_timeout(float(os.environ.get("GOOGLE_TRANSLATE_PAGE_TIMEOUT", "30") or 30))
        drv.get(f"https://translate.google.com/?sl=auto&tl={target_code}&op=translate")
        WebDriverWait(drv, 25).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'textarea[aria-label="Source text"]')))
        self._google_translate_force_detect_language(drv, target_code)
        return drv

    @staticmethod
    def _google_translate_extract_result(drv):
        """Lấy riêng phần bản dịch thật, tránh text trạng thái như Translating..."""
        script = r"""
        const visible = (e) => {
          if (!e) return false;
          const s = getComputedStyle(e), r = e.getBoundingClientRect();
          return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0' && r.width > 1 && r.height > 1;
        };
        const clean = (v) => String(v || '').replace(/\u00a0/g, ' ').replace(/\r/g, '').trim();
        const bad = (t) => {
          const x = clean(t).toLowerCase();
          if (!x) return true;
          if (/^(translation|translation results|translating(?:\.\.\.)?|loading(?:\.\.\.)?|please wait(?:\.\.\.)?|busy(?:\.\.\.)?|\.{1,6})$/.test(x)) return true;
          if (/^(copy translation|listen|rate this translation|send feedback|share translation)$/.test(x)) return true;
          return false;
        };
        const region = document.querySelector('c-wiz[role="region"]');
        if (!region) return '';
        const preferred = [
          '[data-result-index] span.ryNqvb',
          '[data-result-index] span[jsname="W297wb"]',
          'span.ryNqvb',
          'span[jsname="W297wb"]',
          '[jsname="OQxAnd"] span',
          '[jsname="OQxAnd"]'
        ];
        for (const sel of preferred) {
          const nodes = [...region.querySelectorAll(sel)].filter(visible);
          const values = [];
          for (const n of nodes) {
            const t = clean(n.innerText || n.textContent);
            if (!bad(t) && !values.includes(t)) values.push(t);
          }
          if (values.length) return values.join('\n');
        }
        const leaves = [...region.querySelectorAll('span,div')].filter(e => {
          if (!visible(e)) return false;
          const t = clean(e.innerText || e.textContent);
          if (bad(t)) return false;
          return ![...e.children].some(c => clean(c.innerText || c.textContent) === t);
        });
        const values = [];
        for (const e of leaves) {
          const t = clean(e.innerText || e.textContent);
          if (!bad(t) && !values.includes(t)) values.push(t);
        }
        return values.join('\n');
        """
        try:
            return str(drv.execute_script(script) or "").strip()
        except Exception:
            return ""

    @staticmethod
    def _google_translate_result_is_valid(result, source_text="", target_code=""):
        """Không cho ghi placeholder/loading hoặc kết quả quá ngắn vào description.txt."""
        value = str(result or "").replace("\r", "").strip()
        source = str(source_text or "").strip()
        if not value:
            return False, "kết quả trống"
        lines = [ln.strip() for ln in value.splitlines() if ln.strip()]
        bad_exact = {
            "translation", "translation results", "translating", "translating...",
            "loading", "loading...", "please wait", "please wait...", "busy", "busy...",
            ".", "..", "...", "....", ".....", "......",
        }
        meaningful = [ln for ln in lines if ln.lower() not in bad_exact]
        if not meaningful:
            return False, "Google Translate vẫn đang xử lý"
        value = "\n".join(meaningful).strip()
        low = value.lower()
        if "translating..." in low or low.startswith("translating"):
            return False, "Google Translate vẫn đang Translating"
        if not re.search(r"[A-Za-zÀ-ÖØ-öø-ÿĀ-ž぀-ヿ㐀-鿿가-힯]", value):
            return False, "kết quả chỉ có ký hiệu"
        src_len = len(re.sub(r"\s+", "", source))
        out_len = len(re.sub(r"\s+", "", value))
        if src_len >= 80 and out_len < max(24, int(src_len * 0.12)):
            return False, f"kết quả quá ngắn ({out_len}/{src_len})"
        if src_len >= 40 and value == source:
            return False, "kết quả vẫn giống nguyên văn nguồn"
        # Khi dịch sang ngôn ngữ Latin, không nhận kết quả gần như vẫn toàn Nhật/Hàn/Trung.
        if str(target_code or "").lower() in {"en", "es", "pt", "it", "de", "fr", "vi", "id", "nl", "pl", "tr"}:
            asian = len(re.findall(r"[぀-ヿ㐀-鿿가-힯]", value))
            letters = len(re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿĀ-ž぀-ヿ㐀-鿿가-힯]", value))
            if letters >= 40 and asian / max(1, letters) > 0.72:
                return False, "kết quả chưa chuyển sang ngôn ngữ đích"
        return True, value

    def _google_translate_one_chunk(self, drv, source_text, target_code="", timeout=25):
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC

        self._google_translate_force_detect_language(drv, target_code)
        textarea = WebDriverWait(drv, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'textarea[aria-label="Source text"]')))
        setter_script = r"""
        const el = arguments[0], value = arguments[1];
        const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        setter.call(el, value);
        el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:value}));
        el.dispatchEvent(new Event('change', {bubbles:true}));
        el.focus();
        return el.value;
        """
        source_text = str(source_text or "")
        # Nội dung trùng hệt lượt trước thì dùng cache, tránh phụ thuộc animation của website.
        if getattr(drv, "_gt_last_source", None) == source_text:
            cached = str(getattr(drv, "_gt_last_result", "") or "")
            ok, cleaned = self._google_translate_result_is_valid(cached, source_text, target_code)
            if ok:
                return cleaned

        previous = self._google_translate_extract_result(drv)
        drv.execute_script(setter_script, textarea, "")
        # Chờ vùng kết quả rời bản dịch cũ hoặc chuyển sang trạng thái loading.
        clear_until = time.time() + 1.6
        cleared = False
        while time.time() < clear_until:
            probe = self._google_translate_extract_result(drv)
            ok_probe, _ = self._google_translate_result_is_valid(probe, source_text, target_code)
            if not probe or not ok_probe or probe != previous:
                cleared = True
                break
            time.sleep(0.08)

        drv.execute_script(setter_script, textarea, source_text)
        try:
            WebDriverWait(drv, 5).until(lambda d: str(d.find_element(By.CSS_SELECTOR, 'textarea[aria-label="Source text"]').get_attribute("value") or "") == source_text)
        except Exception:
            pass

        end = time.time() + float(timeout)
        last, stable = "", 0
        last_reason = "chưa có kết quả"
        while time.time() < end and not self.desc_stop_event.is_set():
            current = self._google_translate_extract_result(drv)
            ok, cleaned_or_reason = self._google_translate_result_is_valid(current, source_text, target_code)
            if ok:
                current = cleaned_or_reason
                # Tránh nhận bản dịch cũ của job trước. Trường hợp trùng nguồn đã dùng cache ở trên.
                if previous and not cleared and current == previous:
                    last_reason = "vẫn là kết quả cũ"
                else:
                    if current == last:
                        stable += 1
                    else:
                        last, stable = current, 0
                    # Chờ ổn định lâu hơn để Google kết thúc animation Translating.
                    if stable >= 4:
                        setattr(drv, "_gt_last_source", source_text)
                        setattr(drv, "_gt_last_result", current)
                        return current
            else:
                last_reason = cleaned_or_reason
                last, stable = "", 0
            time.sleep(0.22)
        raise RuntimeError(f"Google Translate chưa có bản dịch hoàn chỉnh sau {int(timeout)}s • {last_reason}")

    def _google_translate_text(self, drv, text, target_code=""):
        """Dịch một mô tả bằng Google Translate theo đúng mã ngôn ngữ đích."""
        protected, mapping = self._google_translate_protect_text(text)
        limit = max(1000, int(os.environ.get("GOOGLE_TRANSLATE_CHUNK_CHARS", "4500") or 4500))
        chunks = self._google_translate_split_text(protected, max_chars=limit)
        translated_chunks = []
        for chunk in chunks:
            if self.desc_stop_event.is_set():
                raise RuntimeError("Đã dừng dịch")
            timeout = float(os.environ.get("GOOGLE_TRANSLATE_RESULT_TIMEOUT", "25") or 25)
            translated_chunks.append(self._google_translate_one_chunk(drv, chunk, target_code=target_code, timeout=timeout))
        merged = "".join(translated_chunks)
        return self._google_translate_restore_text(merged, mapping).strip()

    def _description_translation_worker_loop(self, wid, batch_q, run_root, target_code, target_display):
        drv = None
        max_attempts = max(1, int(os.environ.get("GOOGLE_TRANSLATE_RETRIES", "2") or 2))
        try:
            try:
                drv = self._google_translate_open_driver(wid, run_root, target_code, headless=True)
            except Exception as first_error:
                self.ui_queue.put(("log", f"[gtranslate-W{wid}] headless lỗi, thử cửa sổ ẩn • {str(first_error)[:160]}"))
                self._description_close_driver_fast(drv, reason=f"GTranslate W{wid} headless lỗi", timeout=0.2)
                drv = self._google_translate_open_driver(wid, run_root, target_code, headless=False)

            while not self.desc_stop_event.is_set():
                try:
                    batch = batch_q.get_nowait()
                except queue.Empty:
                    break
                row = batch[0]
                job = row["job"]
                with self.desc_lock:
                    job["status"] = "running"
                    job["worker"] = f"GT{wid}"
                    job["note"] = f"Đang dịch miễn phí → {target_display}"
                    stats = self._desc_compute_stats()
                self.ui_queue.put(("desc_progress", stats, f"GT{wid}: {row['path'].parent.name}"))
                started = time.time()
                last_error = None
                translated = ""
                source_is_target, source_label, target_label = self._google_translate_source_is_target(row.get("text"), target_code)
                if source_is_target or not self._google_translate_has_translatable_text(row.get("text")):
                    display_source = source_label if source_label != "Không xác định" else "Không có nội dung cần dịch"
                    self._description_translation_mark_already_target(row, target_display, target_code, display_source, wid)
                    try: batch_q.task_done()
                    except Exception: pass
                    continue
                self.ui_queue.put(("log", f"[gtranslate-W{wid}] nguồn={source_label} (Detect language) → đích={target_display}/{target_code} • {row['path'].parent.name}"))
                for attempt in range(1, max_attempts + 1):
                    if self.desc_stop_event.is_set():
                        break
                    try:
                        if drv is None:
                            drv = self._google_translate_open_driver(wid, run_root, target_code, headless=(attempt == 1))
                        translated = self._google_translate_text(
                            drv,
                            row["text"],
                            target_code=target_code,
                        )
                        if translated:
                            break
                    except Exception as e:
                        last_error = e
                        self.ui_queue.put(("log", f"[gtranslate-W{wid}] {row['path'].parent.name} lỗi {attempt}/{max_attempts} • {str(e)[:180]}"))
                        self._description_close_driver_fast(drv, reason=f"GTranslate W{wid} lỗi", timeout=0.2)
                        drv = None
                        if attempt < max_attempts:
                            time.sleep(0.35)
                try:
                    if self.desc_stop_event.is_set():
                        with self.desc_lock:
                            job["status"] = "queued"
                            job["note"] = "Đã dừng • chưa ghi bản dịch"
                    elif not translated:
                        raise RuntimeError(str(last_error or "Google Translate không trả bản dịch"))
                    else:
                        self._description_translation_write_result(row, translated, target_display, wid)
                        self.ui_queue.put(("log", f"[gtranslate-W{wid}] OK • {self._desc_fmt_sec(time.time()-started)} • {row['path']}"))
                except Exception as e:
                    with self.desc_lock:
                        job["status"] = "error"
                        job["note"] = f"Dịch lỗi: {str(e)[:210]}"
                        stats = self._desc_compute_stats()
                    self.ui_queue.put(("desc_progress", stats, f"Dịch lỗi: {row['path'].parent.name}"))
                finally:
                    try: batch_q.task_done()
                    except Exception: pass
        except Exception as e:
            self.ui_queue.put(("log", f"[gtranslate-W{wid}] worker lỗi: {e}"))
        finally:
            self._description_close_driver_fast(drv, reason=f"Google Translate W{wid} kết thúc", timeout=0.25)

    def start_description_translation(self, selected_only=False):
        if getattr(self, "running", False):
            QMessageBox.information(self, APP_TITLE, "Đang tạo Thumbnail, hãy đợi xong hoặc bấm Dừng trước khi dịch mô tả.")
            return
        if getattr(self, "desc_running", False):
            return
        if not (self.chrome_binary and Path(self.chrome_binary).exists() and self.driver_binary and Path(self.driver_binary).exists()):
            QMessageBox.critical(self, APP_TITLE, f"Thiếu Chromium/chromedriver:\nChrome: {self.chrome_binary}\nDriver: {self.driver_binary}")
            return
        self._description_apply_roots_editor(show_message=False)
        try:
            if not getattr(self, "desc_jobs", None):
                self.desc_jobs = self._scan_description_jobs_sync()
            selection_mode = "multi" if selected_only == "multi" else ("current" if selected_only else "all")
            if selection_mode == "multi":
                selected_paths = [p for p in self._description_checked_paths() if p and p.is_file()]
            elif selection_mode == "current":
                current_path = self._description_selected_path()
                selected_paths = [current_path] if current_path and current_path.is_file() else []
            else:
                selected_paths = []

            if selection_mode in ("multi", "current"):
                wanted = {str(p).lower(): p for p in selected_paths}
                jobs_to_run = [
                    j for j in self.desc_jobs
                    if str(j.get("description_path") or "").lower() in wanted
                    and j.get("status") != "skipped"
                    and Path(str(j.get("description_path") or "")).is_file()
                ]
                existing = {str(j.get("description_path") or "").lower() for j in jobs_to_run}
                for selected_path in selected_paths:
                    key = str(selected_path).lower()
                    if key not in existing:
                        job = {"description_path": str(selected_path), "folder": str(selected_path.parent), "status": "queued", "note": "Chờ dịch"}
                        self.desc_jobs.append(job)
                        jobs_to_run.append(job)
                        existing.add(key)
            else:
                jobs_to_run = [j for j in self.desc_jobs if j.get("status") != "skipped" and Path(str(j.get("description_path") or "")).is_file()]

            if not jobs_to_run:
                if selection_mode == "multi":
                    QMessageBox.information(self, APP_TITLE, "Hãy tích ô Chọn ở đầu những mô tả bị sai ngôn ngữ, rồi bấm Dịch mô tả đã chọn.")
                elif selection_mode == "current":
                    QMessageBox.information(self, APP_TITLE, "Hãy chọn một mô tả cần dịch trong danh sách.")
                else:
                    QMessageBox.information(self, APP_TITLE, "Không có description.txt hợp lệ để dịch. Hãy bấm Quét mô tả trước.")
                return
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không chuẩn bị được danh sách dịch:\n{e}")
            return

        target_language, target_display, target_code = self._description_translation_target()
        if not target_code:
            QMessageBox.warning(
                self, APP_TITLE,
                f"Google Translate chưa nhận diện được mã cho ngôn ngữ: {target_display}\n\n"
                "Hãy chọn một ngôn ngữ có sẵn, hoặc nhập mã như en, vi, ja, ko, es."
            )
            return
        count = len(jobs_to_run)
        mode_text = f"{count} mô tả đã tích chọn" if selected_only == "multi" else ("mục đang xem" if selected_only else f"{count} mô tả")
        if QMessageBox.question(
            self, APP_TITLE,
            f"Dịch {mode_text} sang {target_display} bằng Google Translate miễn phí?\n\nNguồn: Phát hiện ngôn ngữ tự động\n"
            "Không dùng tài khoản Gemini, không mất lượt Gemini.\n"
            "Tool tạo bản sao trước khi ghi để có thể Hoàn tác dịch."
        ) != QMessageBox.Yes:
            return

        with self.desc_lock:
            for job in jobs_to_run:
                job["status"] = "queued"
                job["note"] = f"Chờ Google Translate → {target_display}"
            self.desc_stats = self._desc_compute_stats()
        batches = self._description_build_translation_batches(jobs_to_run)
        if not batches:
            QMessageBox.information(self, APP_TITLE, "Các description.txt được chọn đều trống.")
            self._refresh_description_workspace()
            return

        requested_workers = max(1, int(self.worker_spin.value() if hasattr(self, "worker_spin") else 1))
        stable_cap = max(1, int(os.environ.get("GOOGLE_TRANSLATE_MAX_WORKERS", "4") or 4))
        workers = max(1, min(requested_workers, stable_cap, len(batches)))
        self._description_preflight_cleanup()
        local_base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or str(self.backend_dir))
        run_root = local_base / "ToolThumbnail" / "google_translate_runs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        try:
            run_root.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không tạo được thư mục chạy dịch local:\n{run_root}\n{e}")
            return

        self._desc_current_run_root = run_root
        self.desc_running = True
        self.desc_operation = "translate"
        self.desc_stop_event.clear()
        self.desc_last_message = f"Google Translate • {len(jobs_to_run)} mô tả → {target_display} • {workers} luồng"
        self.ui_queue.put(("desc_progress", self.desc_stats, self.desc_last_message))
        self.append_log(f"[gtranslate] ▶ bắt đầu • source=Detect language/auto • jobs={len(jobs_to_run)} • workers={workers} • target={target_display}/{target_code}")
        batch_q = queue.Queue()
        for batch in batches:
            batch_q.put(batch)

        def _run_workers(q_obj, prefix=""):
            threads = []
            gap = max(0.15, float(os.environ.get("GOOGLE_TRANSLATE_WORKER_START_GAP", "0.45") or 0.45))
            for idx in range(1, workers + 1):
                if self.desc_stop_event.is_set():
                    break
                wid = f"{prefix}{idx}" if prefix else idx
                t = threading.Thread(target=self._description_translation_worker_loop, args=(wid, q_obj, run_root, target_code, target_display), daemon=True)
                t.start()
                threads.append(t)
                if idx < workers:
                    time.sleep(gap)
            for t in threads:
                try: t.join()
                except Exception: pass

        def _run_all():
            started = time.time()
            try:
                self._description_prepare_local_browser_runtime()
                _run_workers(batch_q)
                if not self.desc_stop_event.is_set():
                    with self.desc_lock:
                        errors = [j for j in jobs_to_run if j.get("status") == "error"]
                        for j in errors:
                            j["status"] = "queued"
                            j["note"] = "Google Translate thử lại lần cuối"
                    if errors:
                        rescue_q = queue.Queue()
                        for b in self._description_build_translation_batches(errors):
                            rescue_q.put(b)
                        self.ui_queue.put(("log", f"[gtranslate] cứu hộ {len(errors)} mục lỗi"))
                        _run_workers(rescue_q, prefix="R")

                with self.desc_lock:
                    for j in jobs_to_run:
                        if j.get("status") in ("queued", "running"):
                            j["status"] = "error" if not self.desc_stop_event.is_set() else "queued"
                            j["note"] = "Không còn worker Google Translate" if not self.desc_stop_event.is_set() else "Đã dừng • chưa dịch"
                    stats = self._desc_compute_stats()
                translated_ok = sum(1 for j in jobs_to_run if j.get("status") == "done")
                translated_err = sum(1 for j in jobs_to_run if j.get("status") == "error")
                stopped = self.desc_stop_event.is_set()
                msg = "Đã dừng dịch mô tả" if stopped else f"Google Translate xong → {target_display} • thành công {translated_ok}/{len(jobs_to_run)} • lỗi {translated_err}"
                self.ui_queue.put(("desc_done_all", stats, msg))
                self.ui_queue.put(("log", f"[gtranslate] {'STOP' if stopped else 'DONE'} • {self._desc_fmt_sec(time.time()-started)} • ok={translated_ok} error={translated_err} total={len(jobs_to_run)}"))
            except Exception as e:
                with self.desc_lock:
                    for j in jobs_to_run:
                        if j.get("status") in ("queued", "running"):
                            j["status"] = "error"
                            j["note"] = f"Google Translate runtime lỗi: {str(e)[:180]}"
                    stats = self._desc_compute_stats()
                self.ui_queue.put(("log", f"[gtranslate-runtime] ERROR • {type(e).__name__}: {e}"))
                self.ui_queue.put(("desc_done_all", stats, f"Dịch Google Translate lỗi • {e}"))
            finally:
                self.desc_operation = "idle"
                self._desc_profile_prune_guard = False
                try: shutil.rmtree(run_root, ignore_errors=True)
                except Exception: pass
                self._desc_current_run_root = None

        threading.Thread(target=_run_all, daemon=True).start()

    def _description_prepare_profile_clone(self, account_no, temp_profile, wid=None):
        """v12.99: clone profile thật về thư mục local; thiếu profile thì loại worker."""
        temp_profile = Path(temp_profile)
        if temp_profile.exists() and (temp_profile / "Default").exists():
            return temp_profile
        src_profile = self.backend_dir / "profiles" / f"google_{int(account_no)}"
        ok, _profile, reason = self._description_profile_is_usable(account_no)
        if not ok:
            raise FileNotFoundError(f"profile google_{account_no} không hợp lệ: {reason}")
        try:
            sem = getattr(self, "_desc_clone_semaphore", None)
            if sem is None:
                clone_profile_fast(src_profile, temp_profile)
            else:
                with sem:
                    clone_profile_fast(src_profile, temp_profile)
        except Exception as e:
            raise RuntimeError(f"clone profile A{account_no} lỗi: {e}") from e

        # Không mang lock/session chết từ profile nguồn sang clone mới.
        stale_names = {"DevToolsActivePort", "SingletonLock", "SingletonCookie", "SingletonSocket", "LOCK"}
        for root in (temp_profile, temp_profile / "Default"):
            try:
                if not root.exists():
                    continue
                for name in stale_names:
                    try:
                        (root / name).unlink(missing_ok=True)
                    except Exception:
                        pass
            except Exception:
                pass
        return temp_profile

    def _description_driver_pid(self, drv):
        try:
            return int(getattr(getattr(drv, "service", None), "process", None).pid)
        except Exception:
            return None

    def _description_close_driver_fast(self, drv, reason="", timeout=0.45):
        """v12.86: đóng Chrome/ChromeDriver kiểu không treo.
        Lỗi 87% ở v12.85 xảy ra vì webdriver command/quit có thể kẹt sau khi watchdog kill Chrome.
        Bản này kill process tree trước, rồi quit trong daemon thread có join timeout ngắn.
        """
        if drv is None:
            return
        pid = self._description_driver_pid(drv)
        if pid:
            try:
                self._kill_process_tree(pid, timeout=max(0.15, float(timeout or 0.3)))
            except Exception:
                pass
        def _quit_driver():
            try:
                drv.quit()
            except Exception:
                pass
        try:
            t = threading.Thread(target=_quit_driver, daemon=True)
            t.start()
            t.join(max(0.05, min(float(timeout or 0.3), 0.5)))
        except Exception:
            pass
        try:
            prof = getattr(drv, "_desc_profile_dir", None)
            run_root = getattr(self, "_desc_current_run_root", None)
            can_remove = False
            if prof and run_root:
                try:
                    can_remove = os.path.commonpath([str(Path(prof).resolve()), str(Path(run_root).resolve())]) == str(Path(run_root).resolve())
                except Exception:
                    can_remove = "desc_runs" in str(prof).lower() or "_desc_rewrite_runs" in str(prof).lower()
            if prof and can_remove:
                shutil.rmtree(prof, ignore_errors=True)
        except Exception:
            pass
        if reason:
            try:
                self.ui_queue.put(("log", f"[desc] reset Chrome mô tả • {reason}"))
            except Exception:
                pass

    def _desc_fmt_sec(self, seconds):
        try:
            x = float(seconds or 0)
        except Exception:
            x = 0.0
        if x >= 60:
            m = int(x // 60)
            r = int(round(x - m * 60))
            return f"{m}m{r:02d}s"
        return f"{x:.1f}s"

    def _desc_mark_stage(self, stage_ref, name):
        """v12.87: ghi thời gian từng bước sửa mô tả để soi chậm ở đâu."""
        try:
            now = time.time()
            if not isinstance(stage_ref, dict):
                return
            prev = stage_ref.get("name")
            prev_since = float(stage_ref.get("since") or now)
            if prev:
                durs = stage_ref.setdefault("durations", {})
                durs[str(prev)] = float(durs.get(str(prev), 0.0) or 0.0) + max(0.0, now - prev_since)
            stage_ref["name"] = str(name)
            stage_ref["since"] = now
        except Exception:
            pass

    def _desc_finalize_stage(self, stage_ref):
        try:
            self._desc_mark_stage(stage_ref, str((stage_ref or {}).get("name") or "kết thúc"))
        except Exception:
            pass

    def _desc_stage_summary(self, stage_ref, limit=7):
        try:
            durs = dict((stage_ref or {}).get("durations") or {})
            cur = str((stage_ref or {}).get("name") or "")
            if cur:
                durs[cur] = float(durs.get(cur, 0.0) or 0.0) + max(0.0, time.time() - float((stage_ref or {}).get("since") or time.time()))
            order = [
                "đọc description.txt", "mở tab Gemini mới", "chờ ô nhập Gemini",
                "nhập prompt", "bấm gửi", "chờ Gemini trả mô tả",
                "đang nhận text Gemini", "lọc kết quả"
            ]
            parts = []
            seen = set()
            for k in order:
                if k in durs:
                    parts.append(f"{k} {self._desc_fmt_sec(durs[k])}")
                    seen.add(k)
            rest = [(k, v) for k, v in durs.items() if k not in seen]
            rest.sort(key=lambda kv: float(kv[1] or 0), reverse=True)
            for k, v in rest[:max(0, int(limit) - len(parts))]:
                parts.append(f"{k} {self._desc_fmt_sec(v)}")
            return " | ".join(parts[:limit])
        except Exception:
            return ""

    def _description_open_driver_fast_retry(self, wid, account_no, temp_profile, old_drv=None, reason=""):
        """v12.97: tắt browser cũ rồi mở browser mới bằng profile clone riêng.
        Mỗi lần mở dùng một thư mục clone mới để tránh Local State/SingletonLock còn kẹt từ Chrome cũ.
        """
        if old_drv is not None:
            self._description_close_driver_fast(old_drv, reason=reason or f"W{wid} mở lại browser", timeout=0.45)
        t0 = time.time()
        base_profile = Path(temp_profile)
        session_profile = base_profile.parent / f"{base_profile.name}_session_{int(time.time()*1000)}_{os.getpid()}_{random.randint(1000,9999)}"
        self._description_prepare_profile_clone(account_no, session_profile, wid=wid)
        drv = self._description_open_driver(account_no, session_profile)
        try:
            setattr(drv, "_desc_profile_dir", str(session_profile))
        except Exception:
            pass
        self.ui_queue.put(("log", f"[desc-W{wid}] mở Gemini bằng A{account_no} OK • profile clone riêng • {self._desc_fmt_sec(time.time()-t0)}"))
        return drv

    def _description_worker_loop(self, wid, account_no, desc_q, run_root, max_attempts_override=None, job_timeout_override=None):
        """v12.87: chống đứng 87% + log thời gian chi tiết.
        Điểm lỗi v12.85: watchdog kill Chrome nhưng lệnh Selenium đang chờ response vẫn có thể treo trong thread worker,
        khiến job vẫn ở trạng thái running và tổng tiến trình đứng 87%.
        Bản này chạy phần gửi prompt/lấy text trong thread phụ; worker chính chỉ đợi tối đa 40s.
        Quá timeout thì kill Chrome, bỏ thread phụ cũ, mở Chrome mới và retry ngay.
        """
        drv = None
        temp_profile = Path(run_root) / f"worker_{wid}_google_{account_no}"
        job_timeout = float(job_timeout_override if job_timeout_override is not None else (os.environ.get("GEMINI_DESC_JOB_TIMEOUT", "40") or 40))
        max_attempts = max(1, int(max_attempts_override if max_attempts_override is not None else (os.environ.get("GEMINI_DESC_JOB_RETRIES", "2") or 2)))
        try:
            try:
                Path(temp_profile).mkdir(parents=True, exist_ok=True)
            except Exception:
                pass

            # v12.99: worker phải mở được Gemini TRƯỚC khi lấy job.
            # Worker lỗi khởi động sẽ tự loại, không làm oan một description.txt thành lỗi.
            startup_retries = max(1, int(os.environ.get("GEMINI_DESC_START_RETRIES", "2") or 2))
            startup_error = None
            for startup_attempt in range(1, startup_retries + 1):
                if self.desc_stop_event.is_set():
                    return
                try:
                    drv = self._description_open_driver_fast_retry(wid, account_no, temp_profile, old_drv=drv, reason=f"W{wid} preflight")
                    startup_error = None
                    break
                except Exception as e:
                    startup_error = e
                    self.ui_queue.put(("log", f"[desc-W{wid}] preflight A{account_no} lỗi {startup_attempt}/{startup_retries} • {str(e)[:220]}"))
                    try:
                        self._description_close_driver_fast(drv, reason=f"W{wid} preflight lỗi", timeout=0.3)
                    except Exception:
                        pass
                    drv = None
                    if startup_attempt < startup_retries:
                        time.sleep(1.0)
            if drv is None:
                self.ui_queue.put(("log", f"[desc-W{wid}] TẮT worker A{account_no} • không mở được Chrome/Gemini • {startup_error}"))
                return

            while not self.desc_stop_event.is_set():
                try:
                    job = desc_q.get_nowait()
                except queue.Empty:
                    break

                desc_path = Path(str(job.get("description_path") or ""))
                folder_name = desc_path.parent.name if desc_path else "?"
                job_started = time.time()
                success_stage_summary = ""
                success_attempt_elapsed = 0.0
                success_attempt = 0
                with self.desc_lock:
                    job["status"] = "running"
                    job["worker"] = f"W{wid}/A{account_no}"
                    job["note"] = "Đang gửi prompt Gemini"
                    stats = self._desc_compute_stats()
                self.ui_queue.put(("desc_progress", stats, f"W{wid}: {folder_name}"))

                last_error = None
                success = False
                result = ""
                original = ""

                for attempt in range(1, max_attempts + 1):
                    if self.desc_stop_event.is_set():
                        last_error = RuntimeError("Đã dừng trước khi sửa mô tả")
                        break
                    try:
                        if drv is None:
                            drv = self._description_open_driver_fast_retry(wid, account_no, temp_profile, old_drv=None, reason=f"W{wid} start")
                    except Exception as e:
                        last_error = e
                        try:
                            self._description_close_driver_fast(drv, reason=f"W{wid} mở Chrome lỗi lần {attempt}/{max_attempts}: {str(e)[:120]}", timeout=0.25)
                        except Exception:
                            pass
                        drv = None
                        if attempt < max_attempts and not self.desc_stop_event.is_set():
                            time.sleep(0.5)
                            continue
                        break

                    with self.desc_lock:
                        job["note"] = f"Đang sửa mô tả • lần {attempt}/{max_attempts}"
                        stats = self._desc_compute_stats()
                    self.ui_queue.put(("desc_progress", stats, f"W{wid}: {folder_name}"))

                    attempt_started = time.time()
                    stage_ref = {"name": "chuẩn bị", "since": time.time(), "durations": {}}
                    result_q = queue.Queue(maxsize=1)
                    drv_for_attempt = drv

                    def _attempt_body():
                        try:
                            self._desc_mark_stage(stage_ref, "đọc description.txt")
                            ori = desc_path.read_text(encoding="utf-8-sig", errors="ignore")
                            prm = self._description_prompt(ori)
                            res = self._description_send_prompt_get_text(drv_for_attempt, prm, self.desc_stop_event, stage_ref=stage_ref)
                            self._desc_mark_stage(stage_ref, "lọc kết quả")
                            res = self._description_clean_result(res, original_text=ori)
                            src_lang = self._description_detect_language_label(ori)
                            out_lang = self._description_detect_language_label(res)
                            self.ui_queue.put(("log", f"[desc-lang] W{wid} • {folder_name} • gốc={src_lang} → kết quả={out_lang}"))
                            bad_language, bad_reason = self._description_language_mismatch(ori, res)
                            if bad_language:
                                raise RuntimeError(f"Gemini trả sai ngôn ngữ: {bad_reason}; không ghi file và sẽ chạy lại")
                            self._desc_finalize_stage(stage_ref)
                            if not res or len(res.strip()) < 5:
                                raise RuntimeError("Gemini không trả mô tả hợp lệ")
                            try:
                                result_q.put_nowait(("ok", ori, res))
                            except Exception:
                                pass
                        except Exception as e:
                            try:
                                result_q.put_nowait(("err", e, None))
                            except Exception:
                                pass

                    t = threading.Thread(target=_attempt_body, daemon=True)
                    t.start()
                    started = time.time()
                    got = None
                    while (time.time() - started) < job_timeout and not self.desc_stop_event.is_set():
                        try:
                            got = result_q.get(timeout=0.12)
                            break
                        except queue.Empty:
                            continue

                    if got and got[0] == "ok":
                        original, result = got[1], got[2]
                        success = True
                        success_attempt = attempt
                        success_attempt_elapsed = time.time() - attempt_started
                        success_stage_summary = self._desc_stage_summary(stage_ref)
                        break

                    if got and got[0] == "err":
                        last_error = got[1]
                        self.ui_queue.put(("log", f"[desc-W{wid}] LỖI lần {attempt}/{max_attempts} • {folder_name} • {self._desc_fmt_sec(time.time()-attempt_started)} • {self._desc_stage_summary(stage_ref)} • {str(last_error)[:160]}"))
                        try:
                            self._description_close_driver_fast(drv, reason=f"W{wid} lỗi job lần {attempt}/{max_attempts}: {str(last_error)[:120]}", timeout=0.25)
                        except Exception:
                            pass
                        drv = None
                        if attempt < max_attempts and not self.desc_stop_event.is_set():
                            with self.desc_lock:
                                job["note"] = f"Lỗi lần {attempt}, đang mở lại Chrome để chạy lại"
                                stats = self._desc_compute_stats()
                            self.ui_queue.put(("desc_progress", stats, f"Retry W{wid}: {folder_name}"))
                            time.sleep(0.45)
                            continue
                        break

                    # Timeout hoặc dừng: không chờ thread phụ nữa; kill Chrome và retry bằng browser mới.
                    try:
                        st = str(stage_ref.get("name") or "?")
                        spent = max(0, int(time.time() - float(stage_ref.get("since") or time.time())))
                    except Exception:
                        st, spent = "?", 0
                    if self.desc_stop_event.is_set():
                        last_error = RuntimeError("Đã dừng trước khi Gemini trả mô tả")
                    else:
                        last_error = RuntimeError(f"Timeout quá {int(job_timeout)}s tại '{st}'")
                        self.ui_queue.put(("log", f"[desc-W{wid}] TIMEOUT {int(job_timeout)}s tại '{st}' ({spent}s) • job {self._desc_fmt_sec(time.time()-job_started)} • lần {attempt}/{max_attempts} • {self._desc_stage_summary(stage_ref)} • bỏ thread Selenium kẹt, đóng Chrome và chạy lại: {folder_name}"))
                    try:
                        self._description_close_driver_fast(drv_for_attempt, reason=f"W{wid} timeout job lần {attempt}/{max_attempts}: {folder_name}", timeout=0.25)
                    except Exception:
                        pass
                    drv = None
                    if attempt < max_attempts and not self.desc_stop_event.is_set():
                        with self.desc_lock:
                            job["note"] = f"Timeout lần {attempt}, đang mở lại Chrome để chạy lại"
                            stats = self._desc_compute_stats()
                        self.ui_queue.put(("desc_progress", stats, f"Retry W{wid}: {folder_name}"))
                        time.sleep(0.45)
                        continue
                    break

                try:
                    if success:
                        backup_dir = self._description_backup_dir(desc_path)
                        backup_dir.mkdir(parents=True, exist_ok=True)
                        first_backup_path = self._description_first_backup_path(desc_path, create_from_text=original)
                        backup_path = backup_dir / f"description_{datetime.now().strftime('%Y%m%d_%H%M%S')}_W{wid}.bak.txt"
                        backup_path.write_text(original.rstrip("\n") + "\n", encoding="utf-8", errors="replace")
                        desc_path.write_text(result.strip() + "\n", encoding="utf-8", errors="replace")
                        src_lang = self._description_detect_language_label(original)
                        out_lang = self._description_detect_language_label(result)
                        with self.desc_lock:
                            job["status"] = "done"
                            job["source_language"] = src_lang
                            job["result_language"] = out_lang
                            first_name = Path(first_backup_path).name if first_backup_path else "chưa tạo được FIRST"
                            job["note"] = f"OK • {src_lang} → {out_lang} • gốc: {first_name} • backup: {backup_path.name}"
                            stats = self._desc_compute_stats()
                        self.ui_queue.put(("desc_progress", stats, f"OK: {folder_name}"))
                        self.ui_queue.put(("log", f"[desc-W{wid}] OK • {src_lang} → {out_lang} • job {self._desc_fmt_sec(time.time()-job_started)} • lần {success_attempt}/{max_attempts} {self._desc_fmt_sec(success_attempt_elapsed)} • {success_stage_summary} • {desc_path}"))
                    else:
                        with self.desc_lock:
                            if self.desc_stop_event.is_set():
                                job["status"] = "queued"
                                job["note"] = "Đã dừng • chưa ghi mô tả"
                            else:
                                job["status"] = "error"
                                job["note"] = str(last_error or "lỗi mô tả")[:240]
                            stats = self._desc_compute_stats()
                        self.ui_queue.put(("desc_progress", stats, f"Lỗi: {folder_name}"))
                        self.ui_queue.put(("log", f"[desc-W{wid}] ERROR • job {self._desc_fmt_sec(time.time()-job_started)} • {desc_path} • {last_error}"))
                finally:
                    try:
                        desc_q.task_done()
                    except Exception:
                        pass
        except Exception as e:
            self.ui_queue.put(("log", f"[desc-W{wid}] worker lỗi: {e}"))
            try:
                with self.desc_lock:
                    stats = self._desc_compute_stats()
                self.ui_queue.put(("desc_progress", stats, f"Worker W{wid} lỗi"))
            except Exception:
                pass
        finally:
            self._description_close_driver_fast(drv, reason=f"W{wid} kết thúc", timeout=0.25)

    def _description_open_driver(self, account_no, profile_dir):
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        _prepare_chromium_no_browser_signin_profile(profile_dir, log_fn=lambda m: self.ui_queue.put(("log", f"[desc-A{account_no}] {m}")))
        opts = webdriver.ChromeOptions()
        desc_chrome = Path(getattr(self, "_desc_chrome_binary", None) or self.chrome_binary)
        desc_driver = Path(getattr(self, "_desc_driver_binary", None) or self.driver_binary)
        opts.binary_location = normalize_path(desc_chrome)
        opts.add_argument(f"--user-data-dir={normalize_path(profile_dir)}")
        opts.add_argument("--profile-directory=Default")
        opts.add_argument("--window-position=-32000,-32000")
        opts.add_argument("--window-size=1280,900")
        opts.add_argument("--start-minimized")
        opts.add_argument("--remote-debugging-port=0")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--disable-backgrounding-occluded-windows")
        opts.add_argument("--disable-renderer-backgrounding")
        opts.add_argument("--no-first-run")
        opts.add_argument("--no-default-browser-check")
        opts.add_argument("--disable-notifications")
        opts.add_argument("--disable-popup-blocking")
        opts.add_argument("--disable-extensions")
        opts.add_argument("--disable-component-extensions-with-background-pages")
        opts.add_argument("--disable-default-apps")
        opts.add_argument("--disable-sync")
        opts.add_argument("--disable-session-crashed-bubble")
        opts.add_argument("--hide-crash-restore-bubble")
        opts.add_argument("--disable-signin-scoped-device-id")
        opts.add_argument("--disable-features=ChromeSigninIntercept,SigninInterceptBubble,AccountConsistency,SigninProfileCreation,PasswordManagerOnboarding,UnoDesktop,DiceWebSigninInterception,SigninProfileCreation,SyncPromoAfterSigninIntercept,ExplicitBrowserSigninUIOnDesktop,ChromeSignIn")
        opts.add_argument("--password-store=basic")
        try:
            px = self._proxy_value_for_account(account_no)
            parsed = _dash_parse_proxy_value(px) if px else None
            if parsed and not (parsed.get("username") or parsed.get("password")):
                opts.add_argument(f"--proxy-server={parsed.get('scheme') or 'http'}://{parsed.get('host')}:{int(parsed.get('port'))}")
                opts.add_argument("--proxy-bypass-list=<-loopback>")
            elif parsed:
                self.ui_queue.put(("log", f"[desc-A{account_no}] proxy có user/pass: bỏ qua cho nhánh mô tả để tránh popup auth"))
        except Exception:
            pass
        opts.add_experimental_option("excludeSwitches", ["enable-automation"])
        opts.add_experimental_option("useAutomationExtension", False)
        try:
            opts.add_experimental_option("prefs", {
                "session.restore_on_startup": 0,
                "profile.exit_type": "Normal",
                "profile.exited_cleanly": True,
                "signin.allowed": False,
                "sync_promo.show_on_first_run_allowed": False,
                "sync_promo.user_skipped": True,
                "credentials_enable_service": False,
                "profile.password_manager_enabled": False,
            })
        except Exception:
            pass
        _drv_path = Path(desc_driver) if desc_driver else None
        if _drv_path is not None and _drv_path.is_file():
            drv = webdriver.Chrome(service=Service(normalize_path(_drv_path)), options=opts)
        else:
            drv = webdriver.Chrome(options=opts)
        drv.set_page_load_timeout(float(os.environ.get("GEMINI_DESC_PAGE_TIMEOUT", "35") or 35))
        try:
            drv.set_window_rect(-32000, -32000, 1280, 900)
        except Exception:
            pass
        drv.get("https://gemini.google.com/app/new")
        time.sleep(1.0)
        try:
            _dismiss_chromium_profile_signin_prompt(drv, log_fn=lambda m: self.ui_queue.put(("log", f"[desc-A{account_no}] {m}")), max_rounds=5)
        except Exception:
            pass
        try:
            _gemini_finish_onboarding_driver(drv, log_fn=lambda m: self.ui_queue.put(("log", f"[desc-A{account_no}] {m}")), stop_event=self.desc_stop_event, max_seconds=int(os.environ.get("GEMINI_DESC_ONBOARD_TIMEOUT", "20") or 20))
        except Exception:
            pass
        if not self._description_wait_editor_ready(drv, timeout=float(os.environ.get("GEMINI_DESC_READY_TIMEOUT", "28") or 28)):
            raise RuntimeError("Không thấy ô nhập Gemini; có thể profile chưa đăng nhập hoặc bị checkpoint")
        return drv

    def _description_wait_editor_ready(self, drv, timeout=45):
        end = time.time() + float(timeout)
        while time.time() < end and not self.desc_stop_event.is_set():
            try:
                if _gemini_prompt_editor_ready_driver(drv):
                    return True
            except Exception:
                pass
            time.sleep(0.35)
        return False

    def _description_find_editor_element(self, drv, timeout=30):
        end = time.time() + float(timeout)
        last = None
        while time.time() < end and not self.desc_stop_event.is_set():
            try:
                el = drv.execute_script(r'''
                    function visible(el){
                        if(!el) return false;
                        const r=el.getBoundingClientRect(); const st=getComputedStyle(el);
                        return st.display!=='none' && st.visibility!=='hidden' && r.width>40 && r.height>20 && r.bottom>0 && r.right>0;
                    }
                    const sels = [
                        'rich-textarea div[contenteditable="true"]',
                        'div[role="textbox"][contenteditable="true"]',
                        'div[contenteditable="true"]',
                        'textarea',
                        'rich-textarea'
                    ];
                    for (const sel of sels){
                        for (const el of Array.from(document.querySelectorAll(sel))){
                            if(visible(el)) return el;
                        }
                    }
                    return null;
                ''')
                if el:
                    return el
            except Exception as e:
                last = e
            time.sleep(0.25)
        raise RuntimeError(f"Không tìm thấy ô nhập prompt Gemini{': '+str(last)[:120] if last else ''}")

    def _description_write_prompt(self, drv, prompt):
        '''v12.85: nhập prompt nhanh và ổn định hơn.
        Timeout lẻ thường do send_keys gõ prompt dài quá chậm hoặc Gemini refresh DOM làm element bị stale.
        Vì vậy ưu tiên Chrome DevTools Input.insertText, fallback JS/send_keys nếu cần.
        '''
        from selenium.webdriver.common.keys import Keys
        from selenium.webdriver.common.action_chains import ActionChains
        prompt = str(prompt or "")
        el = self._description_find_editor_element(drv, timeout=30)
        try:
            drv.execute_script("arguments[0].scrollIntoView({block:'center'}); arguments[0].focus();", el)
        except Exception:
            pass
        try:
            el.click()
        except Exception:
            try:
                drv.execute_script("arguments[0].click(); arguments[0].focus();", el)
            except Exception:
                pass
        time.sleep(0.08)
        try:
            ActionChains(drv).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.DELETE).perform()
            time.sleep(0.04)
        except Exception:
            pass

        # Fast path 1: CDP insertText. Nhanh hơn nhiều so với Selenium send_keys khi description dài.
        try:
            drv.execute_cdp_cmd("Input.insertText", {"text": prompt})
            time.sleep(0.18)
            ok = drv.execute_script(r'''
                const txt = arguments[0] || '';
                const body = document.body && document.body.innerText || '';
                const sels = ['rich-textarea div[contenteditable="true"]','div[role="textbox"][contenteditable="true"]','div[contenteditable="true"]','textarea','rich-textarea'];
                for (const sel of sels){
                    for (const el of Array.from(document.querySelectorAll(sel))){
                        const v = (el.value || el.innerText || el.textContent || '').trim();
                        if (v && v.length >= Math.min(80, txt.trim().length)) return true;
                    }
                }
                return body.includes((txt || '').slice(0,80));
            ''', prompt)
            if ok:
                return
        except Exception:
            pass

        # Fast path 2: set content bằng JS + input event, tránh stale element bằng cách lấy lại editor.
        try:
            el = self._description_find_editor_element(drv, timeout=8)
            drv.execute_script(r'''
                const el = arguments[0], txt = arguments[1];
                el.focus();
                if (el.tagName && el.tagName.toLowerCase()==='textarea') {
                    el.value = txt;
                    el.dispatchEvent(new Event('input', {bubbles:true}));
                    el.dispatchEvent(new Event('change', {bubbles:true}));
                } else {
                    el.textContent = txt;
                    el.dispatchEvent(new InputEvent('beforeinput', {bubbles:true, inputType:'insertText', data:txt}));
                    el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:txt}));
                    el.dispatchEvent(new Event('change', {bubbles:true}));
                }
            ''', el, prompt)
            time.sleep(0.18)
            return
        except Exception:
            pass

        # Last resort: Selenium typing. Lấy lại element vì Gemini hay render lại ô nhập.
        el = self._description_find_editor_element(drv, timeout=8)
        try:
            el.click()
        except Exception:
            pass
        el.send_keys(prompt)
        time.sleep(0.2)

    def _description_click_send(self, drv, timeout=8):
        end = time.time() + float(timeout)
        while time.time() < end and not self.desc_stop_event.is_set():
            try:
                btn = drv.execute_script(r'''
                    function visible(el){
                        if(!el) return false;
                        const r=el.getBoundingClientRect(); const st=getComputedStyle(el);
                        return st.display!=='none' && st.visibility!=='hidden' && r.width>12 && r.height>12 && !el.disabled;
                    }
                    const sels = [
                        'button[aria-label*="Gửi"]', 'button[aria-label*="Send"]',
                        'button[aria-label*="Submit"]', 'button[aria-label*="Tạo"]',
                        'button[aria-label*="Generate"]', '[role="button"][aria-label*="Send"]',
                        '[role="button"][aria-label*="Gửi"]'
                    ];
                    for (const sel of sels){
                        for (const b of Array.from(document.querySelectorAll(sel))){
                            if(visible(b)) return b;
                        }
                    }
                    const buttons = Array.from(document.querySelectorAll('button,[role="button"]')).filter(visible);
                    return buttons.reverse().find(b => {
                        const t=((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')+' '+(b.getAttribute('data-test-id')||'')).toLowerCase();
                        return t.includes('send') || t.includes('gửi');
                    }) || null;
                ''')
                if btn:
                    try: drv.execute_script("arguments[0].click();", btn)
                    except Exception: btn.click()
                    return True
            except Exception:
                pass
            time.sleep(0.15)
        raise RuntimeError("Không tìm thấy/bấm được nút Gửi Gemini")

    def _description_collect_response_state(self, drv):
        try:
            return drv.execute_script(r'''
                function visible(el){
                    if(!el) return false;
                    const r=el.getBoundingClientRect(); const st=getComputedStyle(el);
                    return st.display!=='none' && st.visibility!=='hidden' && r.width>30 && r.height>15 && r.bottom>0 && r.right>0;
                }
                const bodyText = (document.body && document.body.innerText || '').toLowerCase();
                const busyText = ['responding','thinking','đang trả lời','đang suy nghĩ','đang tạo','generating','working on it'].some(x => bodyText.includes(x));
                const spinners = Array.from(document.querySelectorAll('[role="progressbar"], mat-progress-bar, .spinner, .loading')).filter(visible).length;
                const stopBtns = Array.from(document.querySelectorAll('button,[role="button"]')).filter(b => {
                    if(!visible(b)) return false;
                    const t=((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')).toLowerCase();
                    return t.includes('stop') || t.includes('dừng') || t.includes('hủy');
                }).length;
                const sels = [
                    'message-content', '.message-content', '.model-response', '.response-container',
                    'div[data-test-id*="response"]', 'article'
                ];
                const raw = [];
                for (const sel of sels){
                    for (const el of Array.from(document.querySelectorAll(sel))){
                        if(!visible(el)) continue;
                        let t = (el.innerText || el.textContent || '').trim();
                        t = t.replace(/\n{3,}/g, '\n\n').trim();
                        if(t && t.length > 4) raw.push(t);
                    }
                }
                const out = [];
                const seen = new Set();
                for(const t of raw){
                    const k=t.slice(0,500);
                    if(!seen.has(k)){ seen.add(k); out.push(t); }
                }
                return {busy: !!(busyText || spinners || stopBtns), texts: out, body: (document.body && document.body.innerText || '').slice(0,12000)};
            ''') or {"busy": False, "texts": []}
        except Exception:
            return {"busy": False, "texts": []}

    def _description_pick_response_text(self, state, prompt):
        texts = list((state or {}).get("texts") or [])
        prompt_l = (prompt or "")[:500].lower()
        bad_markers = [
            "vui lòng viết lại phần mô tả sau",
            "quy tắc bắt buộc",
            "mô tả gốc",
            "không chào hỏi",
            "critical language rules",
            "original_description",
            "content rules",
        ]
        candidates = []
        for t in texts:
            clean = self._description_clean_result(t)
            low = clean.lower()
            if not clean or len(clean) < 5:
                continue
            if any(m in low for m in bad_markers):
                continue
            if prompt_l and low.startswith(prompt_l[:120]):
                continue
            if clean.count("\n") <= 1 and len(clean) < 20:
                continue
            candidates.append(clean)
        return candidates[-1] if candidates else ""

    def _description_send_prompt_get_text(self, drv, prompt, stop_event, stage_ref=None, keep_current_conversation=False):
        def _stage(name):
            try:
                if stage_ref is not None:
                    self._desc_mark_stage(stage_ref, str(name))
            except Exception:
                pass
        if not keep_current_conversation:
            try:
                _stage("mở tab Gemini mới")
                drv.get("https://gemini.google.com/app/new")
                time.sleep(0.8)
            except Exception:
                pass
        else:
            _stage("giữ cuộc trò chuyện Gemini hiện tại")
        _stage("chờ ô nhập Gemini")
        if not self._description_wait_editor_ready(drv, timeout=float(os.environ.get("GEMINI_DESC_READY_TIMEOUT", "25") or 25)):
            raise RuntimeError("Gemini chưa sẵn sàng ô nhập prompt")
        _stage("nhập prompt")
        self._description_write_prompt(drv, prompt)
        _stage("bấm gửi")
        self._description_click_send(drv, timeout=float(os.environ.get("GEMINI_DESC_SEND_TIMEOUT", "7") or 7))
        _stage("chờ Gemini trả mô tả")
        end = time.time() + float(os.environ.get("GEMINI_DESC_RESPONSE_TIMEOUT", "70") or 70)
        last_text = ""
        stable_since = 0.0
        saw_any = False
        while time.time() < end and not stop_event.is_set():
            state = self._description_collect_response_state(drv)
            text = self._description_pick_response_text(state, prompt)
            busy = bool((state or {}).get("busy"))
            if text:
                saw_any = True
                if text != last_text:
                    last_text = text
                    stable_since = time.time()
                    _stage("đang nhận text Gemini")
                else:
                    stable_for = time.time() - stable_since
                    min_stable = float(os.environ.get("GEMINI_DESC_TEXT_STABLE_SECONDS", "0.9") or 0.9)
                    enough_text = len(text.strip()) >= 80 or text.count("\n") >= 2
                    # v13.44: Gemini thường vẫn giữ nút Stop/Thinking vài chục giây sau khi phần mô tả
                    # đã hiện đầy đủ. Khi text không đổi đủ lâu thì lấy ngay, không đợi busy=False.
                    if enough_text and stable_for >= min_stable:
                        _stage("đã lấy text ổn định")
                        return text
                    if (not busy) and stable_for >= 0.55:
                        _stage("đã lấy mô tả")
                        return text
            time.sleep(0.35)
        if stop_event.is_set():
            raise RuntimeError("Đã dừng trước khi Gemini trả mô tả")
        if saw_any and last_text:
            _stage("lấy text cuối trước timeout response")
            return last_text
        raise RuntimeError("Gemini không trả text mô tả trong thời gian chờ")

    def _description_clean_result(self, text, original_text=None):
        t = str(text or "").strip()
        if t.startswith("```") and t.endswith("```"):
            lines = t.splitlines()
            if len(lines) >= 3:
                t = "\n".join(lines[1:-1]).strip()
        # v12.90: Selenium có thể lấy cả nhãn header của Gemini vào câu trả lời.
        # Tuyệt đối không ghi các nhãn như "Gemini said" / "Gemini đã nói" vào description.txt.
        gemini_label_patterns = [
            r"^\s*gemini\s+(said|says)\s*[:：-]?\s*",
            r"^\s*gemini\s+(đã\s+)?nói\s*[:：-]?\s*",
            r"^\s*gemini\s+(đã\s+)?trả\s+lời\s*[:：-]?\s*",
            r"^\s*gemini\s+(responded|answered)\s*[:：-]?\s*",
            r"^\s*gemini\s*[:：-]\s*",
        ]
        changed = True
        while changed:
            changed = False
            for pat in gemini_label_patterns:
                nt = re.sub(pat, "", t, flags=re.I).strip()
                if nt != t:
                    t = nt
                    changed = True
        lines = t.splitlines()
        while lines:
            first = lines[0].strip()
            if not first:
                lines.pop(0)
                continue
            if any(re.fullmatch(pat.replace('^\\s*', '').replace('\\s*$', ''), first, flags=re.I) for pat in [
                r"gemini\s+(said|says)\s*[:：-]?",
                r"gemini\s+(đã\s+)?nói\s*[:：-]?",
                r"gemini\s+(đã\s+)?trả\s+lời\s*[:：-]?",
                r"gemini\s+(responded|answered)\s*[:：-]?",
                r"gemini\s*[:：-]?",
            ]):
                lines.pop(0)
                continue
            break
        t = "\n".join(lines).strip()
        for prefix in ("Mô tả mới:", "Mô tả viết lại:", "Descrição reescrita:", "Rewritten description:", "New description:"):
            if t.lower().startswith(prefix.lower()):
                t = t[len(prefix):].strip()
        t = t.strip().strip('"').strip()
        t = self._description_remove_unwanted_brand_lines(t, original_text=original_text)
        return t.strip()

    def _refresh_project_queue_ui(self):
        try:
            if not hasattr(self, "project_queue_list"):
                return
            self._ensure_project_queue_slots()
            total = len(getattr(self, "project_queue", []) or [])
            if total == 0:
                self.selected_queue_index = -1
            elif int(getattr(self, "selected_queue_index", -1) or -1) >= total:
                self.selected_queue_index = total - 1

            self.project_queue_list.clear()
            for idx, item in enumerate(getattr(self, "project_queue", []) or []):
                li = QListWidgetItem(self._queue_item_title(item, idx))
                li.setToolTip(f"Folder: {item.get('root','')}\nLogo: {item.get('logo','')}")
                self.project_queue_list.addItem(li)
            if 0 <= int(getattr(self, "selected_queue_index", -1) or -1) < total:
                self.project_queue_list.setCurrentRow(int(self.selected_queue_index))

            self._clear_project_queue_cards()
            if hasattr(self, "project_queue_cards_layout"):
                for idx, item in enumerate(getattr(self, "project_queue", []) or []):
                    self.project_queue_cards_layout.addWidget(self._make_project_queue_card(item, idx), 1)
                if hasattr(self, "project_queue_cards_body"):
                    self.project_queue_cards_body.adjustSize()

            if hasattr(self, "queue_status_label"):
                valid_count = len(self._valid_project_queue_indices())
                cur = int(getattr(self, "current_queue_index", -1) or -1)
                if getattr(self, "queue_running", False) and 0 <= cur < total:
                    self.queue_status_label.setText(f"Đang chạy ô {cur+1}/4 • {Path(self.project_queue[cur].get('root','')).name}")
                else:
                    self.queue_status_label.setText(f"Đã chọn {valid_count}/4 queue thumbnail")
        except Exception as e:
            try: self.append_log(f"[queue] refresh UI lỗi: {e}")
            except Exception: pass


    def _sync_project_queue_stats_from_jobs(self):
        """v12.54: đồng bộ thống kê 5 queue từ self.jobs theo queue_index."""
        try:
            self._ensure_project_queue_slots()
            valid = set(self._valid_project_queue_indices())
            for idx, item in enumerate(self.project_queue):
                if idx not in valid:
                    item["total"] = "?"
                    item["done"] = 0
                    item["error"] = 0
                    item["skip"] = 0
                    if not self._queue_item_valid(item):
                        item["status"] = "chờ"
                    continue
                qjobs = [j for j in (self.jobs or []) if int(j.get("queue_index", -1) if str(j.get("queue_index", "")).lstrip("-").isdigit() else -1) == idx]
                if not qjobs:
                    continue
                item["total"] = len(qjobs)
                item["done"] = sum(1 for j in qjobs if j.get("status") == "done")
                item["error"] = sum(1 for j in qjobs if j.get("status") == "error")
                item["skip"] = sum(1 for j in qjobs if j.get("status") == "skipped")
                active = sum(1 for j in qjobs if j.get("status") in ("queued", "reserved", "running"))
                if active:
                    item["status"] = "đang chạy" if getattr(self, "running", False) else "sẵn sàng"
                else:
                    item["status"] = "done" if int(item.get("error") or 0) == 0 else "done+lỗi"
            try:
                self._refresh_project_queue_ui()
            except Exception:
                pass
        except Exception as e:
            try: self.append_log(f"[queue] sync stats lỗi nhẹ: {e}")
            except Exception: pass

    def add_project_queue_item(self, root, logo, status="chờ"):
        root = normalize_path(root)
        logo = normalize_path(logo)
        if not root or not Path(root).exists():
            raise ValueError("Thư mục quét không tồn tại")
        if not logo or not Path(logo).exists():
            raise ValueError("Logo PNG không tồn tại")
        self._ensure_project_queue_slots()
        slot = self._first_empty_queue_slot()
        if slot < 0:
            raise ValueError("Tối đa 4 queue thumb. Ô ngoài cùng bên phải dành cho Sửa mô tả.")
        item = {"root": root, "logo": logo, "status": status, "total": "?", "done": 0, "error": 0, "skip": 0}
        self.project_queue[slot] = item
        self.selected_queue_index = slot
        self._refresh_project_queue_ui()
        try: self.project_queue_list.setCurrentRow(self.selected_queue_index)
        except Exception: pass
        self.schedule_save_state()
        return item

    def add_project_queue_item_dialog(self):
        root = QFileDialog.getExistingDirectory(self, "Chọn thư mục quét cho dự án")
        if not root:
            return
        logo, _ = QFileDialog.getOpenFileName(self, "Chọn logo PNG cho thư mục này", "", "PNG files (*.png);;All files (*.*)")
        if not logo:
            return
        try:
            self.add_project_queue_item(root, logo)
            self.root_edit.setText(root)
            self.logo_edit.setText(logo)
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def import_project_queue_txt(self):
        f, _ = QFileDialog.getOpenFileName(self, "Nhập queue TXT: mỗi dòng root|logo hoặc root<TAB>logo", "", "Text files (*.txt);;All files (*.*)")
        if not f:
            return
        ok = bad = 0
        try:
            lines = Path(f).read_text(encoding="utf-8-sig", errors="ignore").splitlines()
            for raw in lines:
                line = raw.strip().strip('"')
                if not line or line.startswith("#") or line.startswith(";"):
                    continue
                if "|" in line:
                    root, logo = [x.strip().strip('"') for x in line.split("|", 1)]
                elif "\t" in line:
                    root, logo = [x.strip().strip('"') for x in line.split("\t", 1)]
                else:
                    parts = line.split()
                    if len(parts) >= 2:
                        root, logo = " ".join(parts[:-1]), parts[-1]
                    else:
                        bad += 1; continue
                try:
                    self.add_project_queue_item(root, logo)
                    ok += 1
                except Exception:
                    bad += 1
            self.append_log(f"[queue] nhập TXT xong • OK {ok} • lỗi/bỏ qua {bad}")
            if ok:
                self._refresh_project_queue_ui(); self.schedule_save_state()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, f"Không đọc được queue TXT:\n{e}")

    def remove_selected_project_queue_item(self):
        row = self.project_queue_list.currentRow() if hasattr(self, "project_queue_list") else -1
        if row < 0:
            row = int(getattr(self, "selected_queue_index", -1) or -1)
        self.remove_project_queue_item_at(row, ask=True)

    def move_selected_project_queue_item(self, delta):
        row = self.project_queue_list.currentRow() if hasattr(self, "project_queue_list") else -1
        if row < 0:
            row = int(getattr(self, "selected_queue_index", -1) or -1)
        new = row + int(delta)
        if row < 0 or new < 0 or new >= len(self.project_queue):
            return
        self.project_queue[row], self.project_queue[new] = self.project_queue[new], self.project_queue[row]
        self.selected_queue_index = new
        self._refresh_project_queue_ui()
        try: self.project_queue_list.setCurrentRow(new)
        except Exception: pass
        self.schedule_save_state()

    def scan_project_queue_only(self):
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, hãy đợi xong hoặc bấm Dừng trước khi quét queue thumb.")
            return
        self._ensure_project_queue_slots()
        valid_indices = self._valid_project_queue_indices()
        if not valid_indices:
            QMessageBox.information(self, APP_TITLE, "Chưa có queue thumb hợp lệ. Hãy chọn thư mục cho ít nhất 1 ô Queue.")
            return
        if getattr(self, "_scan_running", False):
            self.append_log("[queue] đang có scan khác, vui lòng đợi")
            return
        self._scan_running = True
        try: self.btn_queue_scan.setEnabled(False)
        except Exception: pass
        try: self.btn_scan.setEnabled(False)
        except Exception: pass
        self.status_label.setText("Đang quét toàn bộ queue...")
        self.append_log(f"[queue] bắt đầu quét {len(valid_indices)} dự án hợp lệ / 4 ô")
        def _work():
            try:
                all_jobs = []
                total_skipped = 0
                parent_roots = set()
                for idx in valid_indices:
                    item = self.project_queue[idx]
                    root = item.get("root", "")
                    logo = item.get("logo", "")
                    try:
                        jobs, skipped = scan_jobs(root, logo_path=logo)
                        for j in jobs:
                            try:
                                j["queue_index"] = idx
                                j["queue_root"] = root
                                j["queue_logo"] = logo
                            except Exception:
                                pass
                        all_jobs.extend(jobs)
                        total_skipped += int(skipped or 0)
                        parent_roots.update(str(j.get("direct_parent_root") or j.get("parent_root") or "") for j in jobs if j.get("image_path"))
                        item["total"] = len(jobs)
                        item["skip"] = int(skipped or 0)
                        item["done"] = sum(1 for j in jobs if j.get("status") == "done")
                        item["error"] = sum(1 for j in jobs if j.get("status") == "error")
                        item["status"] = "sẵn sàng" if jobs else "trống"
                        self.ui_queue.put(("log", f"[queue] #{idx+1} scan OK • jobs={len(jobs)} • skip={skipped} • {root}"))
                    except Exception as e:
                        item["status"] = "lỗi scan"
                        self.ui_queue.put(("log", f"[queue] #{idx+1} scan lỗi • {root} • {e}"))
                self.ui_queue.put(("queue_scan_done", all_jobs, total_skipped, len([x for x in parent_roots if x])))
            except Exception as e:
                self.ui_queue.put(("queue_scan_error", str(e)))
        threading.Thread(target=_work, daemon=True).start()

    def start_project_queue(self):
        """v12.54: Chạy Queue thông minh.
        Quét/nhận toàn bộ queue hợp lệ, ưu tiên queue trước nhưng worker rảnh được lấy queue sau.
        """
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, hãy đợi xong hoặc bấm Dừng trước khi chạy thumb.")
            return
        if self.running:
            return self.start_run()
        self._ensure_project_queue_slots()
        valid_indices = self._valid_project_queue_indices()
        if not valid_indices:
            QMessageBox.information(self, APP_TITLE, "Chưa có queue thumb hợp lệ. Hãy chọn thư mục cho ít nhất 1 ô Queue.")
            return

        # Nếu chưa quét queue hoặc danh sách job không còn khớp queue, quét trước rồi tự chạy.
        try:
            has_queue_jobs = bool(self.jobs) and any(
                int(j.get("queue_index", -1) if str(j.get("queue_index", "")).lstrip("-").isdigit() else -1) in valid_indices
                for j in (self.jobs or [])
            )
        except Exception:
            has_queue_jobs = False
        if not has_queue_jobs:
            self._queue_autostarting = True
            self.append_log("[queue] chưa có job queue trong danh sách • quét toàn bộ 5 queue rồi tự chạy")
            return self.scan_project_queue_only()

        self.queue_running = True
        self.queue_smart_parallel = True
        self._queue_advance_pending = False
        self.current_queue_index = valid_indices[0]
        first = self.project_queue[self.current_queue_index]
        try:
            self.root_edit.setText(str(first.get("root") or ""))
            self.logo_edit.setText(str(first.get("logo") or ""))
        except Exception:
            pass
        # Đưa tất cả lỗi của lần trước về queued để chạy lại, giữ done/skipped.
        retry_errors = 0
        for j in self.jobs:
            try:
                if int(j.get("queue_index", -1) if str(j.get("queue_index", "")).lstrip("-").isdigit() else -1) in valid_indices:
                    if j.get("status") == "error":
                        j["status"] = "queued"
                        j["worker"] = ""
                        j["note"] = "Queue smart: đưa lỗi cũ vào chạy lại"
                        retry_errors += 1
            except Exception:
                pass
        for idx in valid_indices:
            try:
                self.project_queue[idx]["status"] = "đang chạy"
            except Exception:
                pass
        self._sync_project_queue_stats_from_jobs()
        self.append_log(f"[queue] ▶ Smart Queue: chạy {len(valid_indices)}/4 ô • worker rảnh sẽ lấy queue sau nếu queue trước còn ít job" + (f" • đưa lại {retry_errors} job lỗi" if retry_errors else ""))
        return self.start_run()

    def _advance_project_queue(self):
        """Giữ tương thích nút/cơ chế cũ. v12.54 dùng Smart Queue nên chuyển sang start_project_queue."""
        return self.start_project_queue()

    def _maybe_advance_project_queue(self):
        if not getattr(self, "queue_running", False):
            return
        if getattr(self, "_queue_advance_pending", False):
            return
        try:
            if not self._jobs_all_terminal_success():
                return
        except Exception:
            return
        self._queue_advance_pending = True
        def _finish_queue_smart():
            try:
                self._sync_project_queue_stats_from_jobs()
                for idx in self._valid_project_queue_indices():
                    qjobs = [j for j in (self.jobs or []) if int(j.get("queue_index", -1) if str(j.get("queue_index", "")).lstrip("-").isdigit() else -1) == idx]
                    if qjobs:
                        self.project_queue[idx]["status"] = "done" if not any(j.get("status") == "error" for j in qjobs) else "done+lỗi"
                self.queue_running = False
                self.queue_smart_parallel = False
                self.current_queue_index = -1
                self._queue_advance_pending = False
                self.status_label.setText("Hoàn tất toàn bộ Queue")
                self.append_log("[queue] ✅ Hoàn tất toàn bộ 5 Queue • đã xử lý hết job")
                self._refresh_project_queue_ui(); self.schedule_save_state()
            except Exception as e:
                self._queue_advance_pending = False
                try: self.append_log(f"[queue] finish smart lỗi nhẹ: {e}")
                except Exception: pass
        QTimer.singleShot(600, _finish_queue_smart)


    def _active_live_worker_count(self):
        """v12.59: đếm ACTIVE DISPATCH worker, không chỉ process đã Popen.
        Worker đang login/chưa có proc vẫn phải tính là đang chiếm slot, nếu không cuối batch
        scheduler sẽ sinh thêm W30/W40 vượt số luồng đã chọn.
        """
        live = 0
        now = time.monotonic()
        for w in list(getattr(self, "workers", []) or []):
            try:
                if getattr(w, "finished", False) or getattr(w, "terminate_requested", False):
                    continue
                proc = getattr(w, "proc", None)
                if proc is None:
                    # Thread đang chuẩn bị/login/clone profile, vẫn chiếm slot. Nếu kẹt launch quá lâu mới bỏ qua.
                    st = float(getattr(w, "started_at", 0.0) or 0.0)
                    if st <= 0 or now - st < 20 * 60:
                        live += 1
                    continue
                if proc.poll() is None:
                    live += 1
            except Exception:
                pass
        return live

    def _active_worker_accounts(self, exclude_state=None):
        """v13.44: account thật sự đang bị worker sống giữ, kể cả active_accounts bị nhả sớm."""
        out = set()
        now = time.monotonic()
        for w in list(getattr(self, "workers", []) or []):
            try:
                if w is exclude_state or getattr(w, "finished", False) or getattr(w, "terminate_requested", False):
                    continue
                proc = getattr(w, "proc", None)
                live = False
                if proc is None:
                    st = float(getattr(w, "started_at", 0.0) or 0.0)
                    live = (st <= 0 or now - st < 20 * 60)
                else:
                    live = (proc.poll() is None)
                if not live:
                    continue
                vals = list(getattr(w, "account_map", []) or []) + [getattr(w, "account_no", None)]
                for a in vals:
                    try:
                        if a is not None:
                            out.add(int(a))
                    except Exception:
                        pass
            except Exception:
                pass
        return out

    def _active_dispatch_worker_ids(self):
        ids = set()
        now = time.monotonic()
        for w in list(getattr(self, "workers", []) or []):
            try:
                if getattr(w, "finished", False) or getattr(w, "terminate_requested", False):
                    continue
                proc = getattr(w, "proc", None)
                if proc is None:
                    st = float(getattr(w, "started_at", 0.0) or 0.0)
                    if st <= 0 or now - st < 20 * 60:
                        ids.add(int(getattr(w, "worker_id", -1)))
                    continue
                if proc.poll() is None:
                    ids.add(int(getattr(w, "worker_id", -1)))
            except Exception:
                pass
        return ids

    def _job_queue_index(self, job, default=9999):
        try:
            v = job.get("queue_index", default)
            return int(v)
        except Exception:
            return default

    def _smart_queue_current_index(self):
        """v12.54: queue hiện tại = queue nhỏ nhất còn queued/reserved/running."""
        try:
            active_status = ("queued", "reserved", "running")
            vals = [self._job_queue_index(j) for j in (self.jobs or []) if j.get("status") in active_status and self._job_queue_index(j) < 9999]
            return min(vals) if vals else None
        except Exception:
            return None

    def _filter_runnable_for_queue_priority(self, runnable):
        """v12.77: ưu tiên Queue hiện tại nhưng KHÔNG để thiếu luồng.
        Nếu Queue hiện tại còn ít hơn/sấp xỉ số luồng đang chọn, cho Queue sau tràn vào slot trống.
        Ví dụ chọn 8 luồng, Q1 còn 5 job thì chạy 5 job Q1 + 3 job Q2, không tụt xuống 2 luồng.
        """
        try:
            if not getattr(self, "queue_running", False):
                return list(runnable or [])
            active_status = ("queued", "reserved", "running")
            cur = self._smart_queue_current_index()
            if cur is None:
                return list(runnable or [])
            cur_left = [j for j in (self.jobs or []) if self._job_queue_index(j) == cur and j.get("status") in active_status]
            try:
                target_workers = int(getattr(self, "current_requested_workers_count", 0) or 0)
                if target_workers <= 0 and hasattr(self, "worker_spin"):
                    target_workers = int(self.worker_spin.value() or 1)
            except Exception:
                target_workers = 1
            spill_limit = max(max(0, int(QUEUE_SPILLOVER_THRESHOLD or 2)), max(1, target_workers))
            if len(cur_left) > spill_limit:
                return [j for j in (runnable or []) if self._job_queue_index(j) == cur]
            # Còn ít job ở queue hiện tại: cho queue sau dùng slot trống, nhưng vẫn sort ưu tiên queue trước.
            return sorted(list(runnable or []), key=lambda j: (self._job_queue_index(j), str(j.get("image_path") or "").lower()))
        except Exception:
            return list(runnable or [])

    # ---------- run/worker management ----------
    # ---------- run/worker management ----------
    def _has_live_worker_process(self):
        for w in list(getattr(self, "workers", []) or []):
            try:
                if w.proc and w.proc.poll() is None:
                    return True
            except Exception:
                pass
        return False

    def _startup_cleanup_async(self):
        """Dọn process cũ ở nền để bấm Bắt đầu không bị Not Responding."""
        def _work():
            try:
                killed = self._cleanup_leftover_worker_processes(timeout=0.15)
                if killed:
                    self.ui_queue.put(("log", f"[startup-cleanup] dọn nền {killed} process cũ"))
            except Exception as e:
                self.ui_queue.put(("log", f"[startup-cleanup] bỏ qua lỗi dọn nền: {e}"))
        try:
            threading.Thread(target=_work, daemon=True).start()
        except Exception:
            pass

    def _set_proxy_compact_text(self, detail_text):
        """v12.54: cập nhật ô Proxy riêng dưới Thời gian chạy."""
        text = str(detail_text or "")
        try:
            enabled = self._is_proxy_enabled()
        except Exception:
            enabled = bool(getattr(self, "proxy_enabled", False))
        try:
            count = len(_dash_proxy_raw_list(self.backend_dir))
        except Exception:
            count = 0
        compact = (f"BẬT ({count} proxy)" if count else "BẬT (chưa có proxy)") if enabled else "TẮT (IP Gốc)"
        if "Đang kiểm tra" in text:
            compact = "Đang kiểm tra proxy..."
        try:
            self.proxy_status_label.setText(compact)
            self.proxy_status_label.setToolTip(text or compact)
            self.proxy_status_label.setProperty("active", "true" if enabled else "false")
            self.proxy_status_label.style().unpolish(self.proxy_status_label); self.proxy_status_label.style().polish(self.proxy_status_label)
        except Exception:
            pass

    def _format_proxy_check_summary(self, results):
        total = len(results or [])
        ok_count = sum(1 for r in (results or []) if r.get("ok"))
        dup_ips = {}
        for r in results or []:
            ip = (r.get("ip") or "").strip()
            if ip:
                dup_ips.setdefault(ip, []).append(r.get("acc"))
        duplicate_lines = []
        for ip, accs in dup_ips.items():
            if len(accs) > 1:
                duplicate_lines.append(f"trùng IP {ip}: " + ", ".join(f"A{x}" for x in accs))
        lines = [f"Proxy OK: {ok_count}/{total}"]
        for r in (results or [])[:6]:
            flag = "✅" if r.get("ok") else "❌"
            acc = r.get("acc")
            px = r.get("proxy_mask") or "-"
            ip = f" → {r.get('ip')}" if r.get("ip") else ""
            lines.append(f"{flag} A{acc}: {px}{ip}")
        if len(results or []) > 6:
            lines.append(f"... +{len(results)-6} proxy")
        if duplicate_lines:
            lines.append("⚠ " + " | ".join(duplicate_lines[:2]))
        return "\n".join(lines)

    def _proxy_check_worker(self, accounts, auto_start=False):
        """v5.2: Check TOÀN BỘ proxy trong proxy_accounts.txt.
        Proxy live sẽ được đưa vào pool rồi gắn cho các account/worker cần chạy Flow.
        Account không được gắn proxy vẫn có thể chạy Gemini không proxy.
        """
        import concurrent.futures
        entries = _dash_load_proxy_entries(self.backend_dir)
        results = []
        def one(entry):
            pv = entry.get("proxy") or ""
            ok, msg, ip = _dash_check_proxy_value(pv, timeout=8)
            return {
                "acc": entry.get("acc"),
                "key": entry.get("key") or "proxy",
                "ok": bool(ok),
                "proxy_value": pv,
                "proxy_mask": _dash_mask_proxy_value(pv),
                "ip": ip,
                "msg": msg,
            }
        try:
            if not entries:
                self.ui_queue.put(("proxy_check_done", False, [], auto_start, False))
                return
            max_workers = max(1, min(10, len(entries)))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
                futs = {ex.submit(one, ent): ent for ent in entries}
                for fut in concurrent.futures.as_completed(futs):
                    try:
                        r = fut.result()
                    except Exception as e:
                        ent = futs.get(fut) or {}
                        r = {"acc": ent.get("acc"), "key": ent.get("key") or "?", "ok": False, "proxy_value": ent.get("proxy") or "", "proxy_mask": _dash_mask_proxy_value(ent.get("proxy") or ""), "ip": "", "msg": str(e)}
                    results.append(r)
                    label = f"A{r.get('acc')}" if r.get('acc') is not None else str(r.get('key') or '?')
                    self.ui_queue.put(("log", f"[proxy-check] {label}: {'OK' if r.get('ok') else 'FAIL'} • {r.get('proxy_mask')} • {r.get('msg')}" + (f" • ip={r.get('ip')}" if r.get('ip') else "")))
                    self.ui_queue.put(("proxy_status", self._format_proxy_check_summary(sorted(results, key=lambda x: int(x.get('acc') or 999999)))))
            results = sorted(results, key=lambda x: int(x.get("acc") or 999999))
            ips = [r.get("ip") for r in results if r.get("ok") and r.get("ip")]
            duplicate_ip = len(ips) != len(set(ips)) if ips else False
            # ok flag chỉ dùng báo trạng thái tổng, không chặn chạy.
            self.ui_queue.put(("proxy_check_done", any(r.get("ok") for r in results), results, auto_start, duplicate_ip))
        except Exception as e:
            self.ui_queue.put(("proxy_check_done", False, [{"acc":"?", "key":"?", "ok":False, "proxy_value":"", "proxy_mask":"-", "ip":"", "msg":str(e)}], auto_start, False))

    def _delete_run_dirs_quiet(self, also_reset_current=True):
        """Xóa sạch thư mục _simple_parallel_runs/run_*.
        Dùng khi bấm Quét file để lần chạy sau luôn tạo run mới sạch.
        Hàm này không đụng Qt trực tiếp để chạy được trong background thread.
        """
        deleted = 0
        errors = []
        runs_root = self.backend_dir / "_simple_parallel_runs"
        try:
            if runs_root.exists():
                folders = [p for p in runs_root.iterdir() if p.is_dir() and p.name.startswith("run_")]
                for old in folders:
                    try:
                        shutil.rmtree(old, ignore_errors=True)
                        if not old.exists():
                            deleted += 1
                        else:
                            errors.append(str(old))
                    except Exception as e:
                        errors.append(f"{old}: {e}")
            if also_reset_current:
                self.run_dir = None
                self.run_manifest_path = None
                self.current_workers_root = None
        except Exception as e:
            errors.append(str(e))
        return deleted, errors


    def _cleanup_stale_upload_lock_before_run(self):
        """v12.54: dọn lock upload cũ trước khi start run, tránh tất cả worker đứng chờ mãi."""
        try:
            import tempfile, shutil, time
            lock_file = os.environ.get("GEMINI_UPLOAD_LOCK_FILE") or os.path.join(tempfile.gettempdir(), "gemini_upload_serial.lock")
            lock_dir = lock_file + ".dir"
            if not os.path.exists(lock_dir):
                return
            owner = os.path.join(lock_dir, "owner.txt")
            owner_pid = None
            try:
                if os.path.exists(owner):
                    import re as _re
                    data = open(owner, "r", encoding="utf-8", errors="ignore").read()
                    m = _re.search(r"pid=(\d+)", data)
                    if m:
                        owner_pid = int(m.group(1))
            except Exception:
                owner_pid = None

            alive = False
            if owner_pid:
                try:
                    if os.name == "nt":
                        import ctypes
                        h = ctypes.windll.kernel32.OpenProcess(0x1000 | 0x00100000, False, int(owner_pid))
                        if h:
                            try:
                                code = ctypes.c_ulong()
                                if ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code)):
                                    alive = (code.value == 259)
                            finally:
                                ctypes.windll.kernel32.CloseHandle(h)
                    else:
                        os.kill(int(owner_pid), 0); alive = True
                except Exception:
                    alive = False

            if owner_pid and alive:
                self.append_log(f"[upload-lock] vẫn có process giữ lock pid={owner_pid}, không dọn")
                return

            try:
                shutil.rmtree(lock_dir, ignore_errors=True)
                self.append_log("[upload-lock] đã dọn khóa upload serial cũ trước khi chạy")
            except Exception as e:
                self.append_log(f"[upload-lock] dọn khóa cũ lỗi nhẹ: {e}")
        except Exception:
            pass


    def start_run(self):
        if getattr(self, "desc_running", False):
            QMessageBox.information(self, APP_TITLE, "Đang sửa mô tả, hãy đợi xong hoặc bấm Dừng trước khi chạy thumb.")
            return
        # v6.0 Gemini One Machine Max:
        # Bỏ hoàn toàn Flow/proxy-check khi chạy. Mục tiêu là chạy Gemini trực tiếp đủ worker trên 1 máy,
        # tránh mất thời gian check proxy hoặc chờ Flow lane.
        if getattr(self, "_inside_auto_rerun", False):
            return self._start_run_core()
        if self.running:
            return self._start_run_core()
        # v13.51: đây là một lần bấm Chạy queue mới của người dùng. Cho toàn bộ
        # account từng chạm quota được thử lại 1 lần trước khi chia worker.
        try:
            self._enable_manual_quota_recheck()
        except Exception as _quota_retry_e:
            self.append_log(f"[daily-quota-recheck] chuẩn bị thử lại quota lỗi nhẹ: {_quota_retry_e}")
        # v13.54 FULL VAULT: một lần bấm Chạy queue là một sweep mới thật sự.
        # Xóa cooldown runtime ngắn của lượt trước để mọi mail lại có cơ hội được thử;
        # KHÔNG xóa lịch sử health score, nên mail tốt vẫn luôn được ưu tiên trước.
        try:
            _all_vault = list(self._vault_account_numbers() or [])
            for _acc in _all_vault:
                try:
                    _perf = self._get_account_perf(_acc)
                    _perf["cooldown_until"] = 0.0
                except Exception:
                    pass
            if RUN_READY_ONLY_NO_LOGIN:
                self.append_log(f"[V22-READY-SWEEP] bấm Chạy → chỉ dùng pool READY; vault={len(_all_vault)} • AUTO-LOGIN=OFF")
            else:
                self.append_log(f"[account-sweep] bấm Chạy queue mới → mở sweep toàn bộ {len(_all_vault)} mail; mail tốt chạy trước, mail xấu/lỗi chạy sau")
        except Exception as _sweep_e:
            self.append_log(f"[account-sweep] reset cooldown lượt mới lỗi nhẹ: {_sweep_e}")
        try:
            self._proxy_check_in_progress = False
            self._proxy_has_config_for_run = False
            self._proxy_approved_proxy_values = []
            self._proxy_assigned_by_account = {}
            self._set_proxy_compact_text("Gemini direct • No proxy")
        except Exception:
            pass
        # V20 WEB SAFETY: never perform executable-wide Chrome cleanup before drawing.  When
        # chrome_binary points at the user's normal Google Chrome, the old cleanup matched every
        # chrome.exe by EXE path and could close unrelated tabs/windows, including 3T UI.
        # Stale tool processes are handled only by profile/run-root ownership in the safe cleanup
        # function below, and live workers are terminated by their tracked process trees.
        try:
            if str(os.environ.get("THUMBNAIL_WEB_MODE", "0")).strip().lower() in ("1", "true", "yes", "on"):
                killed_ext = 0
                self.append_log("[V20-PROCESS-SAFETY] bỏ global Chrome cleanup trước khi chạy • không đụng Chrome ngoài Thumbnail Studio")
            else:
                killed_ext = int(self._cleanup_leftover_worker_processes(timeout=0.45) or 0)
                self.append_log(f"[thumb-extension-guard] đã đóng {killed_ext} process cũ có ownership rõ ràng trước khi chạy")
        except Exception as _ext_cleanup_e:
            self.append_log(f"[V20-PROCESS-SAFETY] cleanup an toàn lỗi nhẹ: {_ext_cleanup_e}")
        self._cleanup_stale_upload_lock_before_run()
        self.append_log("[v13.30] Thumbnail Extension Guard: tắt McAfee/WebAdvisor extension + không auto-login nền 20 tài khoản")
        self.append_log("[profile-cache] v13.54 FULL VAULT • giữ lại profile của toàn bộ mail trong vault; scheduler không còn giới hạn 20 mail")
        if RUN_READY_ONLY_NO_LOGIN:
            self.append_log("[V22-NO-LOGIN] Queue không đăng nhập tài khoản • chỉ mở Gemini headless bằng profile READY đã có trong Kho")
        else:
            self.append_log(f"[login-parallel] lần đầu/máy mới: đăng nhập tối đa {ACCOUNT_POOL_LOGIN_PARALLEL} TK cùng lúc; muốn đổi thì set GEMINI_POOL_LOGIN_PARALLEL=2/3/4")
        return self._start_run_core()

    def _start_run_core(self):
        if not getattr(self, "_inside_auto_rerun", False):
            self.auto_rerun_round = 0
        try:
            self._refresh_daily_quota_holds(log=True)
        except Exception as _quota_load_e:
            self.append_log(f"[daily-quota] đọc file giữ quota lỗi nhẹ: {_quota_load_e}")
        if self.running:
            # v68: nếu worker đã chết/lỗi hết nhưng cờ running còn kẹt, cho phép chạy tiếp job đang chờ.
            if not self._has_live_worker_process():
                self.running = False
                self.active_accounts = set()
                self.exhausted_accounts = set(self._daily_quota_held_accounts())
                self.status_label.setText("Đã reset trạng thái chạy kẹt • có thể bấm Bắt đầu lại")
                self.append_log("[manager] reset running bị kẹt vì không còn worker sống")
            else:
                QMessageBox.information(self, APP_TITLE, "Đang chạy rồi."); return
        try:
            root, logo, workers_count, accounts = self.validate()
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e)); return
        # V21 Web strict READY gate: chạy chỉ dùng account đã READY trong Kho; nếu ít hơn số luồng thì tự hạ luồng theo số READY.
        if RUN_READY_ONLY_NO_LOGIN:
            ready_accounts = self._strict_ready_account_numbers()
            if not ready_accounts:
                msg = ("Không có tài khoản READY nào dùng được. "
                       "Hãy đăng nhập/kiểm tra thêm trong Kho tài khoản.")
                self.append_log(f"[V21-RUN-GATE] BLOCK • {msg}")
                QMessageBox.warning(self, APP_TITLE, msg)
                return
            if len(ready_accounts) < int(workers_count):
                workers_count = len(ready_accounts)
            accounts = ready_accounts
            self.append_log(f"[V21-RUN-GATE] PASS • READY={len(ready_accounts)} • workers={workers_count} • AUTO-LOGIN=OFF")
        # lấy account và chuẩn bị nhóm cho worker.
        account_maps = self._build_account_maps_for_workers(accounts, workers_count)
        if not account_maps:
            self.append_log("[V21-RUN-GATE] Không đủ account READY dùng được. Không chạy và không auto-login.")
            QMessageBox.warning(self, APP_TITLE, "Không đủ account READY dùng được. Hãy vào Kho tài khoản → Đăng nhập/Kiểm tra thêm rồi chạy lại.")
            return
        workers_count = len(account_maps)
        try:
            self._setup_initial_login_barrier([m[0] for m in account_maps if m])
        except Exception as _bar_e:
            self.append_log(f"[first-run-login] setup chờ login lỗi nhẹ: {_bar_e}")
        flat_selected_accounts = [a for g in account_maps for a in g]
        try:
            if hasattr(self, "account_pool_label"):
                self.account_pool_label.setText(f"Kho đầy đủ: {len(accounts)} mail • khởi động {len(flat_selected_accounts)} account cho {workers_count} luồng • failover dùng toàn bộ vault")
        except Exception:
            pass
        self.append_log("[account-pool] worker khởi đầu (mail tốt nhất trước): " + " | ".join(f"W{i+1}:" + ",".join("A"+str(a) for a in g) for i, g in enumerate(account_maps)))
        self.append_log("[account-pool] V21 Web: Chạy chỉ dùng account READY trong Kho; failover cũng chỉ READY; AUTO-LOGIN runtime=OFF")
        self.append_log(f"[profile-cache] lần sau ưu tiên dùng lại marker/profile trong {self.backend_dir / 'profiles'}")
        accounts = [g[0] for g in account_maps]
        # v12.61: Proxy Safe Mode. Chỉ gắn proxy đã check sống; login/check profile vẫn dùng IP gốc để tránh Google checkpoint.
        raw_proxy_pool = _dash_proxy_raw_list(self.backend_dir) if self._is_proxy_enabled() else []
        proxy_pool = self._filter_live_proxy_pool_for_run(raw_proxy_pool) if raw_proxy_pool else []
        self._run_live_proxy_pool = list(proxy_pool or [])
        proxy_has_config = bool(proxy_pool)
        try:
            self._update_proxy_toggle_text()
        except Exception:
            pass
        unique_accounts, seen = [], set()
        for acc in accounts:
            if acc not in seen:
                seen.add(acc); unique_accounts.append(acc)
        accounts = unique_accounts
        self._proxy_assigned_by_account = {}
        if proxy_has_config and proxy_pool:
            for acc in accounts:
                pv = self._proxy_value_for_account(acc)
                if pv:
                    self._proxy_assigned_by_account[int(acc)] = pv
            with_proxy = [a for a in accounts if int(a) in self._proxy_assigned_by_account]
            no_proxy = [a for a in accounts if int(a) not in self._proxy_assigned_by_account]
            self.append_log("[proxy-pool] Proxy ON • gắn cho: " + (", ".join(f"A{x}" for x in with_proxy) if with_proxy else "không có"))
            if no_proxy:
                self.append_log("[proxy-pool] Không có proxy cho: " + ", ".join(f"A{x}" for x in no_proxy))
            self._set_proxy_compact_text(f"Proxy ON • {len(with_proxy)}/{len(accounts)}")
        else:
            self.append_log("[proxy-pool] Proxy OFF hoặc chưa có proxy hợp lệ • Gemini chạy IP gốc")
            self._set_proxy_compact_text("Proxy OFF")
        if accounts:
            capped = min(workers_count, len(accounts))
            if capped != workers_count:
                self.append_log(f"[manager] auto giảm số luồng {workers_count} -> {capped} vì chỉ có {len(accounts)} tài khoản; không dùng trùng account")
                workers_count = capped
        # v1.7: không dọn process cũ đồng bộ ở UI thread nữa để tránh Not Responding khi bấm Bắt đầu.
        # Dọn nhẹ ở nền; nếu muốn dọn sạch run thì bấm Quét file trước.
        self._startup_cleanup_async()

        if not self.jobs:
            self.jobs, skipped = scan_jobs(root, logo_path=logo)
            self._apply_latest_manifest(root)
            self.stat_cards["total"].set_value(len(self.jobs))
            self.stat_cards["skip"].set_value(skipped)
        runnable_all = [j for j in self.jobs if j.get("status") == "queued"]
        runnable = self._filter_runnable_for_queue_priority(runnable_all)
        if len(runnable) != len(runnable_all):
            try: self.append_log(f"[queue-priority] giữ Queue hiện tại trước • chọn {len(runnable)}/{len(runnable_all)} job queued để chạy")
            except Exception: pass
        if not runnable:
            QMessageBox.warning(self, APP_TITLE, "Không có job nào để chạy."); return

        # v2.9: bấm Bắt đầu vẫn giữ lọc "Chờ" để ẩn Bỏ qua, nhưng chế độ này sẽ hiện:
        # - Chờ
        # - Đang chạy
        # - Xong
        # để vừa mượt vừa vẫn thấy thumb hoàn thành ngay trong lúc vẽ.
        try:
            if hasattr(self, "job_filter_combo"):
                self.job_filter_combo.blockSignals(True)
                self.job_filter_combo.setCurrentText("Chờ")
                self.job_filter_combo.blockSignals(False)
        except Exception:
            pass

        self.stop_requested = False
        self._check_stop_event.clear()
        old_events = self._purge_pending_ui_events()
        self._reset_runtime_view(keep_jobs=True)
        if old_events:
            self.append_log(f"[manager] dọn {old_events} event UI cũ trước khi chạy")

        # v12.54: Queue priority có thể chỉ chọn vài job Queue #1; không mở quá số job đã chọn.
        if len(runnable) < workers_count:
            self.append_log(f"[queue-priority] auto giảm worker {workers_count} -> {len(runnable)} vì Queue hiện tại chỉ còn {len(runnable)} job được phép chạy")
            workers_count = max(1, len(runnable))
        # v12.77: không auto giảm luồng kiểu turbo nữa.
        # Người dùng chọn 8 thì cố giữ 8 nếu còn đủ job/profile; Queue sau sẽ tràn vào slot trống.
        self.current_requested_workers_count = workers_count
        # v2.1: nếu quét thư mục tổng có nhiều logo khác nhau, hiện cảnh báo nhẹ.
        try:
            logo_set = {str(j.get("logo_path") or "") for j in runnable if j.get("logo_path")}
            if len(logo_set) > 1:
                self.append_log(f"[scan] phát hiện {len(logo_set)} logo trong các job • sẽ dùng logo_path riêng nếu job có, nếu không dùng logo dự án")
        except Exception:
            pass
        self.running = True
        self._acquire_chrome_background_guard("đang chạy worker")
        self.active_accounts = set()
        self.exhausted_accounts = set(self._daily_quota_held_accounts())
        self._account_issue_once = set()
        self.current_root_folder = root; self.current_logo_path = logo
        # v1.7: run cũ đã được xoá khi bấm Quét file; Start chỉ tạo run mới.
        run_dir = safe_mkdir(self.backend_dir / "_simple_parallel_runs" / f"run_{now_ts()}")
        # v12.55: _simple_parallel_runs chỉ giữ đúng 1 run mới nhất.
        self.prune_old_run_dirs_async(keep=RUN_HISTORY_KEEP, reason="start-run")
        self.run_dir = str(run_dir)
        self.run_manifest_path = str(run_dir / "job_manifest.json")
        self.run_started_at = time.monotonic()
        self.run_finished_at = None
        self._update_runtime_label()
        self.run_done_baseline = sum(1 for j in self.jobs if j.get("status") == "done")
        self.error_stats = {}
        workers_root = safe_mkdir(run_dir / "workers")
        self.current_workers_root = workers_root
        self.workers = []; self.next_runtime_worker_id = 1
        try:
            if self.worker_tree is not None:
                self.worker_tree.clear()
        except Exception:
            pass
        self._worker_items.clear(); self._last_worker_values.clear(); self._clear_worker_cards()
        # v12.56: CHỐT LOGO THEO QUEUE ngay từ lần chia worker đầu tiên.
        # Bản cũ chia bằng _bucket_jobs_by_parent_folder(runnable, workers_count) rồi truyền root/logo hiện tại
        # vào mọi worker, nên khi chạy Smart Queue nhiều ô thì worker Queue #2/#3 vẫn nhận logo của Queue #1.
        # Ở đây mỗi bucket luôn kèm queue_index/root/logo riêng; _launch_worker chỉ nhận đúng logo của bucket đó.
        queue_job_mode = bool(getattr(self, "queue_running", False)) or any(self._job_queue_index(j, 9999) < 9999 for j in runnable)
        if queue_job_mode:
            bucket_records = self._bucket_jobs_for_queue_workers(runnable, workers_count)
        else:
            plain_buckets = self._bucket_jobs_by_parent_folder(runnable, workers_count)
            bucket_records = [
                {"queue_index": None, "root": root, "logo": logo, "jobs": b}
                for b in plain_buckets if b
            ]

        bucket_records = [b for b in (bucket_records or []) if b and b.get("jobs")]
        if not bucket_records:
            QMessageBox.warning(self, APP_TITLE, "Không chia được job cho worker."); return
        if len(bucket_records) != workers_count:
            self.append_log(f"[queue-logo] auto chỉnh worker {workers_count} -> {len(bucket_records)} theo bucket Queue/thư mục thực tế")
        workers_count = len(bucket_records)
        self.current_requested_workers_count = workers_count

        self.track_top.setText(f"Gemini Headless • {workers_count} worker • Profile Reuse")
        self.status_label.setText("Đang chạy • Gemini Headless • Không hiện Chrome")
        self.append_log(f"[manager] start {workers_count} worker • FULL VAULT • candidate={len(self._configured_accounts())}/{len(self._vault_account_numbers())} account")
        for i, bucket in enumerate(bucket_records):
            wid = i + 1
            jobs = list(bucket.get("jobs") or [])
            if not jobs:
                continue
            worker_root = normalize_path(bucket.get("root") or root)
            worker_logo = normalize_path(bucket.get("logo") or logo)
            qidx = bucket.get("queue_index", None)
            acc_map = list(account_maps[i]) if i < len(account_maps) else [accounts[i % len(accounts)]]
            acc = acc_map[0] if acc_map else 1
            state = WorkerState(wid, acc, jobs)
            state.account_map = acc_map; state.account_no = acc
            state.queue_index = qidx
            state.worker_root = worker_root
            state.worker_logo = worker_logo
            with self.run_lock:
                self.workers.append(state)
                for _a in acc_map:
                    self.active_accounts.add(_a)
            qtxt = f"Q{int(qidx)+1}" if isinstance(qidx, int) or str(qidx).lstrip('-').isdigit() else "NoQ"
            self._upsert_worker_row(wid, acc, "🚀 Khởi động", f"Chuẩn bị • {qtxt}", f"0/{len(jobs)}", "-", "-")
            for job in jobs:
                try:
                    if qidx is not None and str(qidx).lstrip('-').isdigit():
                        job["queue_index"] = int(qidx)
                    job["queue_root"] = worker_root
                    job["queue_logo"] = worker_logo
                    if worker_logo:
                        job["logo_path"] = worker_logo
                except Exception:
                    pass
                job["worker"] = self._display_worker_label(wid, acc); job["note"] = f"{qtxt} • logo: {Path(worker_logo).name if worker_logo else 'Không logo'} • Pool rotate • " + ",".join(self._display_tk_label(a) for a in acc_map); job["status"] = "reserved"
            self.append_log(f"[queue-logo] W{wid}/{self._display_tk_label(acc)} nhận {qtxt} • jobs={len(jobs)} • root={worker_root} • logo={worker_logo or 'Không chèn logo'}")
            threading.Thread(target=self._launch_worker, args=(state, worker_root, worker_logo, workers_root), daemon=True).start()
        try:
            self._start_background_bootstrap_remaining_profiles(self._configured_accounts(), selected_accounts=[m[0] for m in account_maps if m])
        except Exception as _bg_e:
            self.append_log(f"[bg-login-20] start lỗi nhẹ: {_bg_e}")
        self.refresh_stats(); self.request_preview_refresh(force=False)

    def stop_all(self, silent=False):
        # v113/v114: dừng thật sự, không cho failover/auto-rerun tự bật lại sau khi kill process.
        self.stop_requested = True
        self.queue_running = False
        self._queue_advance_pending = False
        try:
            if getattr(self, "desc_running", False):
                self.desc_stop_event.set()
                self.desc_last_message = "Đã yêu cầu dừng sửa mô tả"
                self._refresh_project_queue_ui()
        except Exception:
            pass
        if self.run_started_at and self.run_finished_at is None:
            self.run_finished_at = time.monotonic()
        self.running = False
        self._check_stop_event.set()
        self._checking_all = False
        killed = 0
        for w in list(self.workers):
            try:
                w.terminate_requested = True
                if w.proc and w.proc.poll() is None:
                    self._kill_process_tree(w.proc.pid, timeout=0.8)
                    killed += 1
            except Exception:
                try:
                    if w.proc and w.proc.poll() is None:
                        w.proc.kill()
                        killed += 1
                except Exception:
                    pass
        try:
            killed += self._cleanup_leftover_worker_processes(timeout=0.8)
        except Exception:
            pass
        try:
            self.active_accounts = set()
            self.exhausted_accounts = set(self._daily_quota_held_accounts())
            self._save_account_selection_history(force=True)
        except Exception:
            pass
        try:
            self._inside_auto_rerun = False
            self._cooldown_schedule_pending = False
            self._scan_running = False
            self.btn_scan.setEnabled(True)
        except Exception:
            pass
        try:
            for job in self.jobs:
                if job.get("status") in ("running", "reserved"):
                    job["status"] = "queued"
                    job["worker"] = ""
                    job["note"] = "Đã dừng • sẵn sàng chạy lại"
        except Exception:
            pass
        purged = self._purge_pending_ui_events()
        self._reset_runtime_view(keep_jobs=True)
        self._release_chrome_background_guard(grace=0.0)
        self.refresh_stats(); self.request_preview_refresh(force=True)
        if not silent:
            extra = f" • dọn {purged} event UI cũ" if purged else ""
            self.append_log(f"[manager] đã dừng tất cả worker/Chrome/check còn sót: {killed}{extra}")
        self.status_label.setText(f"Đã dừng tất cả: {killed} process liên quan")

    def open_run_dir(self):
        if not self.run_dir:
            return
        try:
            if os.name == "nt": os.startfile(self.run_dir)
            else: subprocess.Popen(["xdg-open", self.run_dir])
        except Exception as e:
            QMessageBox.critical(self, APP_TITLE, str(e))

    def prune_old_profile_dirs(self, keep=PROFILE_HISTORY_KEEP):
        """v13.54: dọn profile rác không thuộc vault; profile của mail trong vault được bảo vệ để FULL VAULT có thể tái sử dụng.
        Khi đang chạy, không xoá profile đang thuộc active_accounts/checking để tránh đụng profile worker đang dùng.
        """
        def _safe_log(msg):
            try:
                if threading.current_thread() is threading.main_thread():
                    self.append_log(msg)
                else:
                    self.ui_queue.put(("log", msg))
            except Exception:
                pass
        try:
            keep = max(1, int(keep))
        except Exception:
            keep = max(1, int(MACHINE_ACCOUNT_POOL_LIMIT or 20))
        try:
            keep = max(keep, int(MACHINE_ACCOUNT_POOL_LIMIT or 20))
        except Exception:
            pass
        try:
            profiles_root = self.backend_dir / "profiles"
            if not profiles_root.exists():
                return 0
            # v12.97: tuyệt đối không xoá profiles khi worker/login hoặc desc đang chạy.
            # Desc dùng profile clone riêng, nhưng cleanup profiles đúng lúc Chrome đang mở vẫn có thể khóa Local State/DevToolsActivePort.
            try:
                if (getattr(self, "running", False) and not getattr(self, "stop_requested", False)) or getattr(self, "desc_running", False) or getattr(self, "_desc_profile_prune_guard", False):
                    return 0
            except Exception:
                pass
            protected = set()
            try:
                protected.update(int(x) for x in getattr(self, "active_accounts", set()) or set())
            except Exception:
                pass
            try:
                protected.update(int(x) for x in getattr(self, "_checking_account_nos", set()) or set())
            except Exception:
                pass
            try:
                # v13.54: profile của TOÀN BỘ mail trong vault không bị dọn.
                # Mục tiêu: mail tốt đã login luôn được ưu tiên và có thể tái sử dụng ở các lần chạy sau.
                if PROFILE_NEVER_PRUNE_MACHINE_POOL:
                    protected.update(int(x) for x in self._machine_account_pool(self._vault_account_numbers()) or [])
            except Exception:
                pass
            folders = []
            for p in profiles_root.glob("google_*"):
                try:
                    if not p.is_dir():
                        continue
                    m = re.search(r"google_(\d+)$", p.name)
                    if not m:
                        continue
                    acc_no = int(m.group(1))
                    folders.append((p, acc_no, p.stat().st_mtime if p.exists() else 0))
                except Exception:
                    continue
            folders.sort(key=lambda x: x[2], reverse=True)
            keep_paths = {str(x[0]) for x in folders[:keep]}
            deleted = 0
            skipped_protected = 0
            for old, acc_no, _mtime in folders[keep:]:
                if acc_no in protected:
                    skipped_protected += 1
                    continue
                try:
                    shutil.rmtree(old, ignore_errors=True)
                    if not old.exists():
                        deleted += 1
                except Exception as e:
                    _safe_log(f"[profiles] xoá profile cũ lỗi: {old.name}: {e}")
            if deleted:
                extra = f" • bỏ qua {skipped_protected} profile đang dùng" if skipped_protected else ""
                _safe_log(f"[profiles] giữ {keep} profile mới nhất • đã xoá {deleted} profile cũ{extra}")
            return deleted
        except Exception as e:
            _safe_log(f"[profiles] cleanup lỗi: {e}")
            return 0

    def prune_old_run_dirs_async(self, keep=RUN_HISTORY_KEEP, reason=""):
        """v12.77: dọn _simple_parallel_runs ở thread nền để UI không trắng khi rmtree nhiều file."""
        def _work():
            try:
                self.prune_old_run_dirs(keep=keep)
                try:
                    self.ui_queue.put(("log", f"[cleanup] dọn run cũ nền OK{(' • ' + reason) if reason else ''}"))
                except Exception:
                    pass
            except Exception as e:
                try:
                    self.ui_queue.put(("log", f"[cleanup] dọn run cũ nền lỗi nhẹ: {e}"))
                except Exception:
                    pass
        try:
            threading.Thread(target=_work, name="PruneOldRuns", daemon=True).start()
        except Exception:
            try:
                self.prune_old_run_dirs(keep=keep)
            except Exception:
                pass

    def prune_old_run_dirs(self, keep=RUN_HISTORY_KEEP):
        try:
            runs_root = self.backend_dir / "_simple_parallel_runs"
            if not runs_root.exists():
                return
            folders = [p for p in runs_root.iterdir() if p.is_dir() and p.name.startswith("run_")]
            folders.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            for old in folders[max(0, keep):]:
                shutil.rmtree(old, ignore_errors=True)
        except Exception as e:
            self.append_log(f"[manager] cleanup old runs lỗi: {e}")

    def delete_all_old_runs(self):
        if self.running:
            QMessageBox.information(self, APP_TITLE, "Đang chạy, chưa thể xoá run cũ."); return
        runs_root = self.backend_dir / "_simple_parallel_runs"
        if not runs_root.exists():
            QMessageBox.information(self, APP_TITLE, "Chưa có thư mục _simple_parallel_runs."); return
        folders = [p for p in runs_root.iterdir() if p.is_dir() and p.name.startswith("run_")]
        if not folders:
            QMessageBox.information(self, APP_TITLE, "Không có run cũ để xoá."); return
        if QMessageBox.question(self, APP_TITLE, f"Xoá sạch {len(folders)} thư mục run cũ?") != QMessageBox.Yes:
            return
        deleted = 0
        for old in folders:
            shutil.rmtree(old, ignore_errors=True)
            if not old.exists(): deleted += 1
        self.run_dir = None; self.run_manifest_path = None; self.current_workers_root = None
        self.append_log(f"[manager] đã xoá {deleted}/{len(folders)} run cũ")

    def _make_worker_template_copy(self, template_path, worker_home):
        """Copy backend vào worker_home. Hybrid cần thêm backend con Flow + Gemini."""
        worker_home = Path(worker_home); worker_home.mkdir(parents=True, exist_ok=True)
        target = worker_home / Path(template_path).name
        shutil.copy2(template_path, target)
        for helper_name in (
            "flow_auto_router_project_x4_complete.py",
            "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py",
        ):
            src = self.backend_dir / helper_name
            if src.exists():
                try:
                    shutil.copy2(src, worker_home / helper_name)
                except Exception as e:
                    self.ui_queue.put(("log", f"[hybrid] copy helper lỗi {helper_name}: {e}"))
        return target

    def _prepare_independent_worker_home(self, worker_home, accounts):
        worker_home = Path(worker_home)
        profiles_root = worker_home / "profiles"; profiles_root.mkdir(parents=True, exist_ok=True)
        for idx, actual_acc in enumerate(accounts, start=1):
            src = self.backend_dir / "profiles" / f"google_{actual_acc}"
            dst = profiles_root / f"google_{idx}"
            # v12.62: không để worker crash vì profile google_N chưa tồn tại.
            # Nếu login ngầm bị captcha/mất mạng thì vẫn tạo profile rỗng đã tắt sign-in/sync prompt; worker sẽ báo logged-out thay vì chết WinError 3.
            try:
                if not src.exists():
                    src.mkdir(parents=True, exist_ok=True)
                    try:
                        _prepare_chromium_no_browser_signin_profile(src, log_fn=lambda m: self.ui_queue.put(("log", m)))
                    except Exception:
                        pass
                clone_profile_fast(src, dst)
                try:
                    _prepare_chromium_no_browser_signin_profile(dst, log_fn=lambda m, _a=actual_acc: self.ui_queue.put(("log", f"[thumb-A{_a}] {m}")))
                except Exception:
                    pass
            except Exception as e:
                try:
                    self.ui_queue.put(("log", f"[profile-reuse] A{actual_acc}: clone profile lỗi nhẹ, tạo profile worker rỗng: {type(e).__name__}: {str(e)[:120]}"))
                except Exception:
                    pass
                try:
                    if dst.exists():
                        shutil.rmtree(dst, ignore_errors=True)
                    dst.mkdir(parents=True, exist_ok=True)
                    _prepare_chromium_no_browser_signin_profile(dst, log_fn=None)
                except Exception:
                    pass
        with open(worker_home / "accounts.json", "w", encoding="utf-8") as f:
            json.dump({"num_accounts": len(accounts)}, f)
        # v5.2: gắn proxy từ proxy pool live, không phụ thuộc google_N trong file.
        try:
            assigned = getattr(self, "_proxy_assigned_by_account", {}) or {}
            lines = ["# Worker local proxy map. Format: google_1=ip:port:user:pass"]
            attached = 0
            for idx, actual_acc in enumerate(accounts, start=1):
                pv = assigned.get(int(actual_acc)) or ""
                if pv:
                    lines.append(f"google_{idx}={pv}"); attached += 1
            if attached > 0:
                (worker_home / "proxy_accounts.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
                self.ui_queue.put(("log", f"[proxy] worker {worker_home.name}: đã gắn {attached} proxy LIVE từ proxy pool"))
            else:
                self.ui_queue.put(("log", f"[proxy] worker {worker_home.name}: không gắn proxy • Gemini chạy mạng hiện tại"))
        except Exception as e:
            self.ui_queue.put(("log", f"[proxy] ghi proxy worker lỗi: {e}"))
        (worker_home / "_debug").mkdir(parents=True, exist_ok=True)
        # v79: KHÔNG copy chrome-win64/chromedriver-win64 vào từng worker nữa.
        # Backend nhận --chrome-binary/--driver-path trỏ về bản shared ở thư mục tool chính,
        # giúp worker khởi động nhanh hơn và giảm ghi đĩa rất nhiều.

    def _account_mode_cache_for_actual_account(self, account_no):
        """Đọc mode cache để truyền vào backend, bỏ bước detect mode tốn thời gian."""
        try:
            cache_path = self.backend_dir / "profiles" / f"google_{int(account_no)}" / ".gemini_account_mode.json"
            if cache_path.is_file():
                data = json.loads(cache_path.read_text(encoding="utf-8"))
                mode = str(data.get("mode") or "").strip().lower()
                if mode in ("regular", "pro"):
                    return mode
        except Exception:
            pass
        # Mặc định regular an toàn; nếu cache chưa có thì lần check/account trước đó có thể tạo cache.
        return "regular"

    def _account_modes_for_worker(self, account_map):
        return [self._account_mode_cache_for_actual_account(acc) for acc in (account_map or [])]

    def _launch_worker(self, state, root_folder, logo, workers_root):
        try:
            # v12.59: đánh dấu ngay từ lúc thread launch để scheduler/tail watchdog tính là đang chiếm slot.
            try:
                state.started_at = time.monotonic()
                state.finished = False
            except Exception:
                pass
            # v12.56: chốt lại lần cuối root/logo theo WorkerState để không bị fallback về Queue #1.
            root_folder = normalize_path(getattr(state, "worker_root", None) or root_folder)
            logo = normalize_path(getattr(state, "worker_logo", None) or logo)
            try:
                _q = getattr(state, "queue_index", None)
                _qtxt = f"Q{int(_q)+1}" if _q is not None and str(_q).lstrip('-').isdigit() else "NoQ"
                self.ui_queue.put(("log", f"[queue-logo] W{state.worker_id}: launch {_qtxt} • root={root_folder} • logo={logo}"))
            except Exception:
                pass
            worker_home = safe_mkdir(Path(workers_root) / f"worker_{state.worker_id}_independent")
            jobs_root = safe_mkdir(worker_home / "jobs")
            launch_jobs = [job for job in state.jobs if job.get("status") not in ("done", "error", "skipped")]
            for _job in launch_jobs:
                try:
                    self._assign_dispatch_lease(state, _job)
                    _job["status"] = "reserved"
                    _job["worker"] = self._display_worker_label(state.worker_id, state.account_no)
                except Exception:
                    pass
            state.path_pairs = [(job["image_path"], copy_job_for_worker(jobs_root, job["image_path"], root_folder)) for job in launch_jobs]
            state.current_worker_path = None; state.current_original_path = None
            state.started_at = time.monotonic(); state.current_job_started_at = 0.0; state.completed_events = 0; state.last_job_duration = 0.0; state.last_output_ts = time.monotonic()
            state.json_mode = True
            state.quota_exhausted = False; state.failover_requested = False; state.failover_reason = ""; state.failover_exhaust_current = False; state.failover_handled = False; state.terminate_requested = False
            # v12.1: chia wave khởi động. Ví dụ chọn 8 luồng: W1-W5 chạy ngay, W6-W8 đợi khoảng 2-3s.
            # Mục tiêu: giảm spike CPU/RAM và giảm nhảy nhiều cửa sổ Chrome login cùng lúc.
            try:
                _wave_size = max(1, int(START_WAVE_SIZE))
                _wid = int(getattr(state, "worker_id", 1) or 1)
                if _wid > _wave_size:
                    _wave_index = (_wid - 1) // _wave_size
                    _inner = (_wid - 1) % _wave_size
                    _delay = float(START_WAVE_DELAY_SECONDS) * _wave_index + float(START_WAVE_INNER_STAGGER_SECONDS) * _inner
                    self.ui_queue.put(("log", f"[staged-start] W{state.worker_id}: wave {_wave_index+1}, chờ {_delay:.1f}s rồi mới mở Gemini headless"))
                    time.sleep(max(0.0, _delay))
            except Exception:
                pass

            # v12.61: không login ngầm lại nếu profile đã vào được Gemini.
            # Chỉ khi profile thiếu dữ liệu / hidden-check thấy mất phiên mới login lại, và login mặc định dùng IP gốc.
            blocked_login_accounts = set()
            if RUN_READY_ONLY_NO_LOGIN:
                # V21: worker tuyệt đối không gọi Google login. READY/account selection đã do Kho tài khoản quyết định.
                # Worker chỉ dùng profile đã lưu; nếu Gemini báo SESSION_FAIL thì manager đổi sang READY account khác.
                self.ui_queue.put(("log", f"[V21-NO-LOGIN] W{state.worker_id}: dùng profile READY " + ",".join("A"+str(a) for a in state.account_map) + " • không gọi _auto_google_login_once"))
            else:
                try:
                    self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}: kiểm tra profile reuse cho {len(state.account_map)} account"))
                    for _acc in list(state.account_map or []):
                        if getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
                            break
                        try:
                            _need_login, _why = self._account_needs_auto_login(_acc)
                        except Exception as _chk_e:
                            _need_login, _why = True, f"check lỗi: {type(_chk_e).__name__}: {str(_chk_e)[:120]}"
                        if not _need_login:
                            self.ui_queue.put(("log", f"[profile-reuse] W{state.worker_id}/A{_acc}: dùng lại profile, không login lại • {_why}"))
                            continue
                        # v12.93: nếu profile/mail cũ đã bị worker báo mất phiên/đăng xuất, không cố login lại mail đó.
                        # Lấy mail khác trong kho để bù vào slot worker cho nhanh, profile cũ giữ marker lỗi và bị loại khỏi pool.
                        try:
                            _why_low = str(_why or '').lower()
                            if any(_x in _why_low for _x in ("worker báo mất phiên", "mất phiên", "đăng xuất", "session_fail", "logged out")):
                                _old_acc = int(_acc)
                                self._mark_account_exhausted(_old_acc, reason_type="session", message=_why)
                                _new_acc = self._replace_account_in_machine_pool(_old_acc, "profile mất phiên → bù mail khác")
                                blocked_login_accounts.add(_old_acc)
                                if _new_acc:
                                    try:
                                        with self.run_lock:
                                            self.active_accounts.discard(_old_acc)
                                            self.active_accounts.add(int(_new_acc))
                                    except Exception:
                                        pass
                                    state.account_map = [int(_new_acc) if int(a) == _old_acc else int(a) for a in list(state.account_map or [])]
                                    state.account_no = int(_new_acc)
                                    _acc = int(_new_acc)
                                    self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}: A{_old_acc} mất phiên → bù A{_acc} từ kho mail và login mail mới ngay"))
                                    try:
                                        _need_login, _why = self._account_needs_auto_login(_acc)
                                    except Exception as _chk2_e:
                                        _need_login, _why = True, f"check mail bù lỗi: {type(_chk2_e).__name__}: {str(_chk2_e)[:120]}"
                                    if not _need_login:
                                        self.ui_queue.put(("log", f"[profile-reuse] W{state.worker_id}/A{_acc}: mail bù đã sẵn profile • {_why}"))
                                        continue
                                else:
                                    self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}/A{_old_acc}: mất phiên nhưng chưa tìm được mail bù rảnh → bỏ account này"))
                                    continue
                        except Exception as _rot_e:
                            self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}/A{_acc}: đổi mail bù lỗi nhẹ: {_rot_e}"))
                        _email, _pwd, _recovery_email = self._get_login_credential(_acc)
                        if not _email or not _pwd:
                            self.ui_queue.put(("log", f"[profile-reuse] W{state.worker_id}/A{_acc}: cần login nhưng thiếu credential • {_why}"))
                            continue
                        try:
                            sem = getattr(self, "_pool_login_semaphore", None)
                            if sem is None:
                                sem = threading.Semaphore(max(1, int(ACCOUNT_POOL_LOGIN_PARALLEL)))
                                self._pool_login_semaphore = sem
                            self.ui_queue.put(("log", f"[safe-login] W{state.worker_id}/A{_acc}: cần login lại vì {_why} • tối đa {ACCOUNT_POOL_LOGIN_PARALLEL} Chrome login cùng lúc"))
                            with sem:
                                if getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
                                    break
                                try:
                                    time.sleep(max(0.0, float(ACCOUNT_POOL_LOGIN_STAGGER_SECONDS)) * ((int(state.worker_id) - 1) % max(1, ACCOUNT_POOL_LOGIN_PARALLEL)))
                                except Exception:
                                    pass
                                _visible_debug = str(os.environ.get("GEMINI_VISIBLE_DEBUG", "0")).strip().lower() in ("1", "true", "yes", "on")
                                _login_proxy = self._proxy_value_for_account(_acc) if LOGIN_USE_PROXY else ""
                                if self._is_proxy_enabled() and not LOGIN_USE_PROXY:
                                    self.ui_queue.put(("log", f"[safe-login] W{state.worker_id}/A{_acc}: login/check dùng IP gốc, proxy chỉ thử ở worker sau khi profile OK"))
                                _ok, _msg = _auto_google_login_once(self.chrome_binary, self.driver_binary, self.backend_dir / "profiles" / f"google_{_acc}", _email, _pwd, _recovery_email, log_fn=lambda m, q=self.ui_queue: q.put(("log", m)), stop_event=self._check_stop_event, hidden=(not _visible_debug), proxy_value=_login_proxy)
                                if _ok:
                                    self._mark_account_login_ok(_acc, _msg)
                                elif _qt_is_account_verify_message(_msg):
                                    blocked_login_accounts.add(int(_acc))
                                    try:
                                        self._mark_account_force_login(_acc, _msg)
                                        self._mark_account_exhausted(_acc, reason_type="verify", message=_msg)
                                        self._replace_account_in_machine_pool(_acc, "Google verify required")
                                    except Exception:
                                        pass
                                    self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}/A{_acc}: BỎ QUA • Google yêu cầu xác minh danh tính, chuyển tài khoản khác"))
                        except Exception as _login_e:
                            _ok, _msg = False, f"login ngầm lỗi: {type(_login_e).__name__}: {str(_login_e)[:160]}"
                        if (not _ok) and _qt_is_account_verify_message(_msg):
                            blocked_login_accounts.add(int(_acc))
                            try:
                                self._mark_account_force_login(_acc, _msg)
                                self._mark_account_exhausted(_acc, reason_type="verify", message=_msg)
                                self._replace_account_in_machine_pool(_acc, "Google verify required")
                            except Exception:
                                pass
                        self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}/A{_acc}: {'OK' if _ok else 'WARN'} • {_msg}"))
                    if blocked_login_accounts:
                        state.account_map = [a for a in list(state.account_map or []) if int(a) not in blocked_login_accounts]
                        if state.account_map:
                            state.account_no = int(state.account_map[0])
                            self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}: bỏ {len(blocked_login_accounts)} account bị Google Verify, còn dùng: " + ",".join("A"+str(a) for a in state.account_map)))
                        else:
                            raise RuntimeError("ACCOUNT_VERIFY_REQUIRED: toàn bộ account của worker bị Google yêu cầu xác minh danh tính")
                except Exception as _e:
                    self.ui_queue.put(("log", f"[account-pool] W{state.worker_id}: profile reuse/login lỗi nhẹ: {_e}"))
                    if _qt_is_account_verify_message(_e):
                        raise
            # v12.77: máy mới/lần đầu chạy: chờ đủ các worker đã login/check xong rồi mới vào engine vẽ.
            try:
                self._initial_login_barrier_arrive_and_wait(state)
            except Exception as _be:
                self.ui_queue.put(("log", f"[first-run-login] W{state.worker_id}: barrier bỏ qua do lỗi nhẹ: {_be}"))
            # v12.1: đã stagger theo wave trước login; chỉ giữ lệch rất nhỏ để tránh bấm upload cùng 1 mili giây.
            try:
                _mini = float(os.environ.get("GEMINI_WORKER_MINI_STAGGER_SECONDS", "0.08") or 0.08) * ((int(state.worker_id) - 1) % max(1, START_WAVE_SIZE))
                if _mini > 0:
                    time.sleep(min(0.5, max(0.0, _mini)))
            except Exception:
                pass
            self._prepare_independent_worker_home(worker_home, state.account_map)
            # v11.2: chạy engine cũ GỐC. File root gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py đã được thay bằng bản Tool_Gemini(4) chưa vá upload mới.
            old_engine_src = self.backend_dir / "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py"
            if not old_engine_src.exists():
                self.ui_queue.put(("log", f"[old-engine] thiếu file engine cũ: {old_engine_src}"))
                raise FileNotFoundError(str(old_engine_src))
            worker_script = self._make_worker_template_copy(old_engine_src, worker_home)
            worker_manifest = worker_home / "job_manifest.json"
            cmd = [
                sys.executable, "-u", str(worker_script),
                "--root", normalize_path(jobs_root),
                "--logo", (normalize_path(logo) if str(logo or "").strip() not in ("", ".") else ""),
                "--num-accounts", str(len(state.account_map)),
                "--chrome-binary", normalize_path(self.chrome_binary),
                "--driver-path", normalize_path(self.driver_binary),
                "--account-modes", ",".join(self._account_modes_for_worker(state.account_map)),
                "--manifest", str(worker_manifest),
                "--events", "1",
                "--final-min-mb", str(FINAL_MIN_MB),
                "--input-skip-over-mb", str(SIZE_LIMIT_MB),
                "--headless-regular", "1",
                "--headless-pro", "1",
                "--hide-style", ("" if (str(os.environ.get("GEMINI_VISIBLE_DEBUG", "0")).strip().lower() in ("1", "true", "yes", "on") or str(os.environ.get("GEMINI_NPT_EXACT_9999", "0")).strip().lower() in ("1", "true", "yes", "on")) else os.environ.get("GEMINI_WORKER_HIDE_STYLE", os.environ.get("GEMINI_HIDE_STYLE", "hide"))),
                "--validate-min-width", "1280",
                "--validate-min-height", "720",
                "--max-job-retries", "1",
                "--result-stable-rounds", "1",
                "--result-stable-seconds", "0.55",
                "--auto-upscale-final", "1",
                "--proxy-list", "||".join(self._proxy_list_for_account_map(state.account_map)),
                "--target-model", str(self._selected_thumbnail_model()),
            ]
            self.ui_queue.put(("log", f"[HEADLESS-GEMINI] W{state.worker_id}: TRUE HEADLESS • Chrome UI=OFF • profile reuse=ON • accounts={','.join('A'+str(a) for a in state.account_map)} • model={self._selected_thumbnail_model()}"))
            env = os.environ.copy(); env["PYTHONUTF8"] = "1"; env["PYTHONUNBUFFERED"] = "1"; env["PYTHONIOENCODING"] = "utf-8"; env["PYTHONUNBUFFERED"] = "1"; env["GEMINI_THUMB_HEADLESS"] = "1"; env["GEMINI_HEADLESS_BROWSER_UI"] = "1"; env["GEMINI_NPT_EXACT_9999"] = "0"; env["GEMINI_FINAL_MIN_MB"] = str(FINAL_MIN_MB); env["GEMINI_EVENTS"] = "1"; env["GEMINI_MAX_JOB_RETRIES"] = "1"; env["GEMINI_AUTO_UPSCALE_FINAL"] = "1"; env["GEMINI_EXTRA_CAPTURE_WAIT"] = "5"; env["GEMINI_RANDOM_ACCOUNT_SWITCH"] = "0"; env["GEMINI_PROXY_ENABLED"] = "1" if self._is_proxy_enabled() else "0"; env["GEMINI_FAST_REUSE_MODE"] = "1"; env["GEMINI_FAST_READY_ONLY"] = "1"; env["GEMINI_TARGET_MODEL"] = str(self._selected_thumbnail_model()); env["GEMINI_UPLOAD_PREVIEW_TIMEOUT"] = "18"; env["GEMINI_UPLOAD_SETTLE_TIMEOUT"] = "6.5"; env["GEMINI_UPLOAD_SETTLE_ROUNDS"] = "6"; env["GEMINI_PRE_SEND_UPLOAD_CONFIRM_TIMEOUT"] = "12"; env["GEMINI_PRE_SEND_UPLOAD_SETTLE_TIMEOUT"] = "5.0"; env["GEMINI_WRITE_PROMPT_EDITOR_TIMEOUT"] = "22"; env["GEMINI_UPLOAD_MENU_TIMEOUT"] = "8"; env["GEMINI_AFTER_MENU_INPUT_TIMEOUT"] = "5"; env["GEMINI_REGULAR_DOM_INPUT_TIMEOUT"] = "10"; env["GEMINI_PRO_DOM_INPUT_TIMEOUT"] = "14"; env["GEMINI_AFTER_UPLOAD_ITEM_CLICK_WAIT"] = "0.35"; env["GEMINI_UPLOAD_LOCK_STALE_SECONDS"] = "45"; env["GEMINI_UPLOAD_SERIAL_LOCK"] = "0"; env["GEMINI_UPLOAD_SERIAL_LOCK"] = "0"; env["GEMINI_READY_PROFILE_FAST_START"] = os.environ.get("GEMINI_READY_PROFILE_FAST_START", "1"); env["GEMINI_PAGE_READY_SETTLE_SECONDS"] = os.environ.get("GEMINI_PAGE_READY_SETTLE_SECONDS", "0.65"); env["GEMINI_FAST_PAGE_LOAD_STRATEGY"] = os.environ.get("GEMINI_FAST_PAGE_LOAD_STRATEGY", "eager"); env["GEMINI_WORKER_PROFILE_ALREADY_PREPARED"] = "1"
            _visible_worker = str(os.environ.get("GEMINI_VISIBLE_DEBUG", "0")).strip().lower() in ("1", "true", "yes", "on")
            creationflags = 0 if _visible_worker else _no_window_creationflags()
            startupinfo = None if _visible_worker else _make_no_window_startupinfo()
            state.proc = subprocess.Popen(cmd, cwd=str(worker_home), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace", bufsize=1, universal_newlines=True, creationflags=creationflags, startupinfo=startupinfo, env=env)
            worker_headless_log = worker_home / "_debug" / "headless_worker.log"
            _ext_worker_log = None
            try:
                worker_headless_log.parent.mkdir(parents=True, exist_ok=True)
                worker_headless_log.write_text(f"HEADLESS-GEMINI W{state.worker_id} START\n", encoding="utf-8")
                _raw_root = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
                _ext_worker_dir = Path(os.environ.get("THUMB_STUDIO_PERSIST_ROOT") or (Path(_raw_root) / "HDMaster" / "ThumbnailStudio")) / "workers"
                _ext_worker_dir.mkdir(parents=True, exist_ok=True)
                _ext_worker_log = _ext_worker_dir / f"worker_{state.worker_id}.log"
                _ext_worker_log.write_text(f"HEADLESS-GEMINI W{state.worker_id} START {datetime.now().isoformat(timespec='seconds')}\n", encoding="utf-8")
            except Exception:
                _ext_worker_log = None
            self.ui_queue.put(("log", f"[HEADLESS-GEMINI] W{state.worker_id} started • browser UI=OFF • log={worker_headless_log}" + (f" • external={_ext_worker_log}" if _ext_worker_log else "")))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "▶ Headless", "Gemini ẩn", f"{state.ok+state.err+state.skip}/{state.total}", state.current or "-", state.last_error))
            for raw in state.proc.stdout:
                state.last_output_ts = time.monotonic()
                line = raw.rstrip()
                try:
                    with worker_headless_log.open("a", encoding="utf-8", errors="replace") as _lf:
                        _lf.write(line + "\n")
                    if _ext_worker_log is not None:
                        with _ext_worker_log.open("a", encoding="utf-8", errors="replace") as _ef:
                            _ef.write(line + "\n")
                except Exception:
                    pass
                if line.startswith(EVENT_MARKER):
                    self._parse_worker_line(state, line)
                    continue
                if self._should_show_worker_log(state, line):
                    self.ui_queue.put(("log", f"[W{state.worker_id}] {line}"))
                self._parse_worker_line(state, line)
            rc = state.proc.wait()
            state.finished = True
            if getattr(self, "stop_requested", False) or getattr(state, "terminate_requested", False) or getattr(self, "_closing_now", False):
                self._release_state_accounts(state)
                state.phase = "Đã dừng"
                self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "■ Đã dừng", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, "Dừng thủ công"))
                return
            try:
                time.sleep(0.8)
                reports = []
                if PROFILE_SYNC_BACK_ALWAYS:
                    for local_idx, actual_acc in enumerate(getattr(state, "account_map", []) or [], start=1):
                        src_prof = Path(worker_home) / "profiles" / f"google_{local_idx}"
                        dst_prof = self.backend_dir / "profiles" / f"google_{actual_acc}"
                        copied = sync_profile_fast(src_prof, dst_prof)
                        reports.append(f"A{actual_acc}:{copied} file")
                    if reports:
                        self.ui_queue.put(("log", "[manager] sync profile back • " + " | ".join(reports) + " • đã lưu profile để lần sau dùng nhanh"))
                else:
                    self.ui_queue.put(("log", "[manager] bỏ sync profile back vì GEMINI_PROFILE_SYNC_BACK_ALWAYS=0"))
                # v12.55: sau khi sync profile worker về, dọn profiles chỉ còn 5 cái gần nhất.
                try:
                    deleted_profiles = self.prune_old_profile_dirs(keep=PROFILE_HISTORY_KEEP)
                    if deleted_profiles:
                        self.ui_queue.put(("log", f"[profiles] sau sync giữ {PROFILE_HISTORY_KEEP} profile mới nhất • xoá {deleted_profiles}"))
                except Exception as _pe:
                    self.ui_queue.put(("log", f"[profiles] cleanup sau sync lỗi nhẹ: {_pe}"))
            except Exception as e:
                self.ui_queue.put(("log", f"[manager] sync profile back lỗi: {e}"))
            for original, copied in state.path_pairs:
                job = next((j for j in state.jobs if self._normalize_cmp_path(j.get('image_path')) == self._normalize_cmp_path(original)), None)
                if not job or job.get('status') != 'done':
                    continue
                ok, err = self._copy_back_one(state, original, copied)
                if not ok and err:
                    self.ui_queue.put(("log", f"[manager] copyback failed: {err} | {original}"))
            self._save_account_selection_history(force=True)
            if getattr(state, "failover_handled", False):
                # v69: lỗi đã được nhả job/chuyển tài khoản ngay lúc phát hiện lỗi,
                # không xử lý failover lần 2 sau khi process cũ tắt.
                self.ui_queue.put(("log", f"[manager] W{state.worker_id}/A{state.account_no} đã xử lý failover tức thì"))
                self._schedule_queued_jobs()
                return
            unfinished = [j for j in state.jobs if j.get("status") not in ("done", "skipped", "error") and self._job_owned_by_state(state, j)]
            # V22: worker stale/exit lỗi nhưng KHÔNG còn sở hữu job nào thì tuyệt đối không failover.
            # V21 có thể sinh W13/W14 sau khi queue đã DONE chỉ vì worker cũ exit code != 0.
            if not unfinished:
                if rc != 0 or state.quota_exhausted or state.failover_requested:
                    self.ui_queue.put(("log", f"[V22-NO-GHOST-FAILOVER] W{state.worker_id}/A{state.account_no} kết thúc nhưng không còn lease/job sở hữu → không sinh worker bù"))
                self._release_state_accounts(state)
                state.phase = "Xong"
                self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "✓ Xong", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
                self._schedule_queued_jobs()
                return
            if state.quota_exhausted:
                cause = state.last_error or f"A{state.account_no} hết lượt tạo ảnh"
                self._handle_worker_failover(state, root_folder, logo, workers_root, cause, mark_current_exhausted=True, exhaust_reason="quota")
            elif state.failover_requested:
                cause = state.failover_reason or state.last_error or f"A{state.account_no} gặp lỗi, đổi tài khoản khác"
                self._handle_worker_failover(state, root_folder, logo, workers_root, cause, mark_current_exhausted=True)
            elif rc != 0:
                cause = state.last_error or f"Worker exit code {rc}"
                self._handle_worker_failover(state, root_folder, logo, workers_root, cause, mark_current_exhausted=True)
            elif unfinished:
                cause = f"W{state.worker_id}/A{state.account_no} kết thúc nhưng còn {len(unfinished)} job chưa xong • chuyển tài khoản rảnh"
                self._handle_worker_failover(state, root_folder, logo, workers_root, cause, mark_current_exhausted=False)
            else:
                self._release_state_accounts(state)
                state.phase = "Xong"
                self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "✓ Xong", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
                self._schedule_queued_jobs()
        except Exception as e:
            state.last_error = str(e)
            self.ui_queue.put(("log", f"[manager] worker {state.worker_id} crash: {e}"))
            self._handle_worker_failover(state, root_folder, logo, workers_root, str(e), mark_current_exhausted=True)

    def _next_dispatch_lease_id(self, state, job):
        try:
            self._dispatch_seq = int(getattr(self, "_dispatch_seq", 0) or 0) + 1
            seq = self._dispatch_seq
        except Exception:
            seq = int(time.time() * 1000)
        try:
            base = self._normalize_cmp_path(job.get("image_path") or "")
            short = abs(hash(base)) % 1000000
        except Exception:
            short = seq
        return f"run{int(time.time())}-W{getattr(state, 'worker_id', '?')}-{seq}-{short}"

    def _assign_dispatch_lease(self, state, job):
        """v12.59: mỗi lần một worker nhận job phải có lease riêng.
        Event/copyback từ worker cũ chỉ được nhận nếu lease vẫn khớp, tránh 2 worker cùng ghi đè một ảnh.
        """
        if not job:
            return ""
        lease = self._next_dispatch_lease_id(state, job)
        try:
            job["dispatch_lease_id"] = lease
            job["dispatch_worker_id"] = int(getattr(state, "worker_id", -1))
            job["dispatch_account"] = int(getattr(state, "account_no", 0) or 0)
            job["dispatch_ts"] = time.time()
            state.lease_ids[self._normalize_cmp_path(job.get("image_path"))] = lease
        except Exception:
            pass
        return lease

    def _job_by_original_path(self, original_path):
        wanted = self._normalize_cmp_path(original_path)
        for j in list(getattr(self, "jobs", []) or []):
            try:
                if self._normalize_cmp_path(j.get("image_path")) == wanted:
                    return j
            except Exception:
                pass
        return None

    def _lease_matches_state(self, state, original_path, allow_missing=True):
        if not original_path:
            return bool(allow_missing)
        job = self._job_by_original_path(original_path)
        if job is None:
            return bool(allow_missing)
        key = self._normalize_cmp_path(original_path)
        expected = (getattr(state, "lease_ids", {}) or {}).get(key)
        current = job.get("dispatch_lease_id")
        if not expected or not current:
            return bool(allow_missing)
        return str(expected) == str(current)

    def _normalize_cmp_path(self, p):
        try:
            return os.path.normcase(os.path.normpath(str(p)))
        except Exception:
            return str(p)

    def _resolve_pair_from_worker_path(self, state, worker_path):
        wanted = self._normalize_cmp_path(worker_path)
        for original, copied in state.path_pairs:
            if self._normalize_cmp_path(copied) == wanted:
                return original, copied
        return None, None

    def _recompute_state_counts(self, state):
        state.ok = sum(1 for j in state.jobs if j.get("status") == "done")
        state.err = sum(1 for j in state.jobs if j.get("status") == "error")
        state.skip = sum(1 for j in state.jobs if j.get("status") == "skipped")

    def _mark_job_status(self, state, original_path, status, note):
        if not original_path:
            return
        wanted = self._normalize_cmp_path(original_path)
        for j in state.jobs:
            if self._normalize_cmp_path(j.get("image_path")) == wanted:
                j["status"] = status; j["note"] = note
                break
        self._recompute_state_counts(state)
        self._save_run_manifest(force=False)

    def _copy_back_one(self, state, original_path, copied_path):
        try:
            if not original_path or not copied_path:
                return False, "missing original/copied path"
            if not self._lease_matches_state(state, original_path, allow_missing=True):
                return False, "dispatch lease mismatch; ignore stale worker result"
            src, dst = Path(copied_path), Path(original_path)
            if not src.exists():
                return False, "missing copied path"
            done_key = self._normalize_cmp_path(dst)
            if done_key in getattr(state, "copyback_done", set()):
                return True, None
            src_size = src.stat().st_size
            if src_size < COPYBACK_VERIFY_MIN_BYTES:
                return False, f"copied result too small: {src_size} bytes"
            if Image is not None:
                try:
                    with Image.open(src) as im:
                        im.verify()
                except Exception as e:
                    return False, f"copied result is not a valid image: {e}"
            dst.parent.mkdir(parents=True, exist_ok=True)
            if COPYBACK_BACKUP_ORIGINAL and dst.exists():
                try:
                    backup_dir = dst.parent / COPYBACK_BACKUP_DIRNAME
                    backup_dir.mkdir(parents=True, exist_ok=True)
                    backup_path = backup_dir / f"{dst.stem}__before_gemini_{now_ts()}{dst.suffix}.bak"
                    shutil.copy2(dst, backup_path)
                except Exception as e:
                    self.ui_queue.put(("log", f"[manager] backup trước khi ghi đè lỗi nhẹ: {e} | {dst}"))
            if COPYBACK_ATOMIC:
                tmp = dst.with_name(f".{dst.name}.copyback_tmp_{os.getpid()}_{int(time.time()*1000)}")
                try:
                    shutil.copy2(src, tmp)
                    os.replace(tmp, dst)
                finally:
                    try:
                        if tmp.exists(): tmp.unlink()
                    except Exception: pass
            else:
                shutil.copy2(src, dst)
            final_size = dst.stat().st_size
            if final_size < COPYBACK_VERIFY_MIN_BYTES:
                return False, f"final image too small after overwrite: {final_size} bytes"
            for j in state.jobs:
                if self._normalize_cmp_path(j.get("image_path")) == self._normalize_cmp_path(dst):
                    j["size_mb"] = final_size / (1024 * 1024)
                    break
            try:
                state.copyback_done.add(done_key)
            except Exception:
                pass
            return True, None
        except Exception as e:
            return False, str(e)

    def _local_account_to_actual(self, state, local_idx):
        try:
            i = int(local_idx) - 1
            if 0 <= i < len(getattr(state, "account_map", []) or []):
                return state.account_map[i]
        except Exception:
            pass
        return state.account_no

    def _mark_error_stat(self, key):
        key = str(key or "unknown").strip() or "unknown"
        self.error_stats[key] = int(self.error_stats.get(key, 0) or 0) + 1

    def _get_account_perf(self, account_no):
        try:
            acc = int(account_no)
        except Exception:
            acc = account_no
        perf = self.account_perf.get(acc)
        if not isinstance(perf, dict):
            perf = {
                "jobs_done": 0,
                "job_seconds": 0.0,
                "job_errors": 0,
                "policy_errors": 0,
                "account_errors": 0,
                "quota_hits": 0,
                "cooldown_until": 0.0,
                "last_event": 0.0,
            }
            self.account_perf[acc] = perf
        return perf

    def _record_account_success(self, account_no, duration=None):
        # v13.51: nếu đây là account đang được thử lại sau quota và đã tạo ảnh OK,
        # xác nhận quota đã hồi rồi bỏ hold ngay để các lượt/máy sau dùng bình thường.
        try:
            self._clear_daily_quota_hold_after_success(account_no)
        except Exception:
            pass
        perf = self._get_account_perf(account_no)
        perf["jobs_done"] = int(perf.get("jobs_done", 0) or 0) + 1
        if duration is not None:
            try:
                duration = float(duration)
            except Exception:
                duration = 0.0
            if duration > 0:
                perf["job_seconds"] = float(perf.get("job_seconds", 0.0) or 0.0) + duration
        perf["last_event"] = time.monotonic()
        try:
            entry = self._account_history_entry(account_no)
            entry["successes"] = int(entry.get("successes", 0) or 0) + 1
            entry["last_success_at"] = time.time()
            entry["last_used_at"] = time.time()
            self._account_history_dirty = True
            self._save_account_selection_history(force=False)
        except Exception:
            pass

    def _record_account_error(self, account_no, err_type="", account_level=False, quota=False):
        # v5.3 Max Throughput: lỗi bắt ảnh/UI tạm thời của Gemini không được làm cooldown account dài.
        # Các lỗi này sẽ retry/fallback ở worker; nếu đưa account vào nghỉ 210s sẽ làm giảm ảnh/giờ rất mạnh.
        if str(err_type or "").lower() in {"capture_fail", "transient_ui_fail", "blob_fetch_failed", "screenshot_fallback_failed"} and not account_level and not quota:
            perf = self._get_account_perf(account_no)
            perf["last_event"] = time.monotonic()
            return
        perf = self._get_account_perf(account_no)
        perf["job_errors"] = int(perf.get("job_errors", 0) or 0) + 1
        if str(err_type or "") in FLOW_POLICY_FAILOVER_ERROR_TYPES:
            perf["policy_errors"] = int(perf.get("policy_errors", 0) or 0) + 1
        if account_level:
            perf["account_errors"] = int(perf.get("account_errors", 0) or 0) + 1
        if quota:
            perf["quota_hits"] = int(perf.get("quota_hits", 0) or 0) + 1
        perf["last_event"] = time.monotonic()
        try:
            entry = self._account_history_entry(account_no)
            entry["job_errors"] = int(entry.get("job_errors", 0) or 0) + 1
            if account_level:
                entry["account_errors"] = int(entry.get("account_errors", 0) or 0) + 1
            if quota:
                entry["quota_hits"] = int(entry.get("quota_hits", 0) or 0) + 1
            entry["last_error_type"] = str(err_type or "unknown")[:100]
            entry["last_error_at"] = time.time()
            entry["last_used_at"] = time.time()
            self._account_history_dirty = True
            self._save_account_selection_history(force=bool(account_level or quota))
        except Exception:
            pass
        policy_errors = int(perf.get("policy_errors", 0) or 0)
        generic_errors = int(perf.get("job_errors", 0) or 0)
        if quota:
            # Quota đã được _mark_daily_quota_hold giữ trong lượt hiện tại.
            # Không ghi cooldown; lần người dùng bấm Chạy queue tiếp theo sẽ cho thử lại.
            return
        elif account_level:
            self._set_account_cooldown(account_no, max(ACCOUNT_COOLDOWN_MIN_SECONDS, min(ACCOUNT_COOLDOWN_MAX_SECONDS, ACCOUNT_ERROR_COOLDOWN_SECONDS)), "lỗi account/session")
        elif policy_errors >= max(1, int(ACCOUNT_POLICY_FAIL_COOLDOWN_THRESHOLD or 4)) and policy_errors % max(1, int(ACCOUNT_POLICY_FAIL_COOLDOWN_THRESHOLD or 4)) == 0:
            cooldown = min(ACCOUNT_COOLDOWN_MAX_SECONDS, max(ACCOUNT_COOLDOWN_MIN_SECONDS, ACCOUNT_ERROR_COOLDOWN_SECONDS))
            self._set_account_cooldown(account_no, cooldown, f"Flow lỗi nhiều ({policy_errors})")
        elif generic_errors >= max(1, int(ACCOUNT_GENERIC_FAIL_COOLDOWN_THRESHOLD or 5)) and generic_errors % max(1, int(ACCOUNT_GENERIC_FAIL_COOLDOWN_THRESHOLD or 5)) == 0:
            cooldown = min(ACCOUNT_COOLDOWN_MAX_SECONDS, max(ACCOUNT_COOLDOWN_MIN_SECONDS, ACCOUNT_ERROR_COOLDOWN_SECONDS // 2 or 120))
            self._set_account_cooldown(account_no, cooldown, f"lỗi job nhiều ({generic_errors})")

    def _set_account_cooldown(self, account_no, seconds, reason=""):
        try:
            acc = int(account_no)
        except Exception:
            acc = account_no
        try:
            seconds = max(1.0, float(seconds or 0.0))
        except Exception:
            seconds = float(ACCOUNT_COOLDOWN_MIN_SECONDS or 120)
        until = time.monotonic() + seconds
        perf = self._get_account_perf(acc)
        old_until = float(perf.get("cooldown_until", 0.0) or 0.0)
        if until <= old_until:
            return
        perf["cooldown_until"] = until
        perf["last_event"] = time.monotonic()
        self.ui_queue.put(("log", f"[scheduler] tạm nghỉ A{acc} {int(seconds)}s • {reason or 'cooldown'}"))

    def _account_cooldown_remaining(self, account_no):
        perf = self._get_account_perf(account_no)
        remaining = float(perf.get("cooldown_until", 0.0) or 0.0) - time.monotonic()
        return remaining if remaining > 0 else 0.0

    def _account_avg_job_seconds(self, account_no):
        perf = self._get_account_perf(account_no)
        done = int(perf.get("jobs_done", 0) or 0)
        total = float(perf.get("job_seconds", 0.0) or 0.0)
        if done <= 0 or total <= 0:
            return None
        return total / max(1, done)

    def _account_health_score(self, account_no):
        perf = self._get_account_perf(account_no)
        score = 1000.0
        avg = self._account_avg_job_seconds(account_no)
        if avg is not None:
            score += max(-200.0, 180.0 - min(180.0, float(avg)))
        else:
            score += 15.0
        score -= float(perf.get("job_errors", 0) or 0) * 8.0
        score -= float(perf.get("policy_errors", 0) or 0) * 14.0
        score -= float(perf.get("account_errors", 0) or 0) * 22.0
        score -= float(perf.get("quota_hits", 0) or 0) * 500.0
        try:
            hist = self._account_history_entry(account_no)
            hist_success = int(hist.get("successes", 0) or 0)
            hist_job_errors = int(hist.get("job_errors", 0) or 0)
            hist_account_errors = int(hist.get("account_errors", 0) or 0)
            score += min(240.0, hist_success * 2.0)
            score -= min(240.0, hist_job_errors * 3.0)
            score -= min(600.0, hist_account_errors * 35.0)
            last_success = float(hist.get("last_success_at", 0.0) or 0.0)
            if last_success > 0:
                success_age_days = max(0.0, (time.time() - last_success) / 86400.0)
                if success_age_days <= 7:
                    score += 180.0 - success_age_days * 10.0
            # Trong nhóm cùng chất lượng, account lâu chưa dùng được cộng điểm nhẹ.
            last_selected = float(hist.get("last_selected_at", 0.0) or 0.0)
            if last_selected <= 0:
                score += 160.0
            else:
                age_minutes = max(0.0, (time.time() - last_selected) / 60.0)
                score += min(160.0, age_minutes / 5.0)
        except Exception:
            pass
        # v12.96: TAIL BOOST. Khi còn job chờ ở cuối batch, luôn ưu tiên account
        # đã có profile/marker OK để bơm đủ luồng vẽ ngay. Account thiếu profile hoặc
        # từng mất phiên chỉ dùng sau cùng để login nền, tránh tình trạng chọn 8 luồng
        # nhưng cuối batch chỉ còn 2-3 luồng thật vì slot bị chiếm bởi login.
        try:
            acc = int(account_no)
            prof = self._profile_dir_for_account(acc)
            if self._force_login_marker_path_for_account(acc).is_file():
                score -= 20000.0
            elif prof.exists() and _profile_has_login_data(prof):
                ok_marker, _marker_msg = self._account_login_marker_valid(acc)
                if ok_marker:
                    score += 30000.0
                elif FAST_REUSE_MODE and FAST_REUSE_ASSUME_PROFILE_OK:
                    score += 12000.0
        except Exception:
            pass
        remain = self._account_cooldown_remaining(account_no)
        if remain > 0:
            score -= 5000.0 + remain
        return score

    def _sorted_candidate_accounts(self, accounts):
        uniq = []
        seen = set()
        for a in accounts or []:
            try:
                acc = int(a)
            except Exception:
                acc = a
            if acc in seen:
                continue
            seen.add(acc)
            uniq.append(acc)
        uniq.sort(key=lambda acc: (-self._account_health_score(acc), self._account_cooldown_remaining(acc), acc))
        return uniq

    def _schedule_after_cooldown_check(self, delay_seconds):
        try:
            delay = max(1.0, float(delay_seconds or 1.0))
        except Exception:
            delay = 5.0
        if getattr(self, "_cooldown_schedule_pending", False):
            return
        self._cooldown_schedule_pending = True
        def _fire():
            try:
                self._cooldown_schedule_pending = False
                self._schedule_queued_jobs()
            except Exception:
                self._cooldown_schedule_pending = False
        t = threading.Timer(delay, _fire)
        t.daemon = True
        t.start()


    def _live_error_retry_limit(self):
        try:
            return int(os.environ.get("GEMINI_LIVE_ERROR_RETRY_MAX", "20") or 20)
        except Exception:
            return 20

    def _live_requeue_error_job(self, state, original_path, err_type, msg):
        """v12.54: job lỗi được đưa lại vào hàng chờ ngay, không chờ toàn bộ run kết thúc."""
        if not original_path:
            return False
        wanted = self._normalize_cmp_path(original_path)
        target = None
        try:
            for j in self.jobs:
                if self._normalize_cmp_path(j.get("image_path")) == wanted:
                    target = j
                    break
        except Exception:
            target = None
        if target is None:
            try:
                for j in state.jobs:
                    if self._normalize_cmp_path(j.get("image_path")) == wanted:
                        target = j
                        break
            except Exception:
                pass
        if target is None:
            return False
        cnt = int(target.get("live_error_retry_count", 0) or 0) + 1
        target["live_error_retry_count"] = cnt
        target["last_error_type"] = str(err_type or "")
        target["last_error_message"] = str(msg or "")[:240]
        limit = self._live_error_retry_limit()
        if cnt > limit:
            target["status"] = "error"
            target["worker"] = ""
            target["note"] = f"Đã retry lỗi {limit} lần • dừng để tránh lặp vô hạn • {err_type}"
            self._recompute_state_counts(state)
            self._save_run_manifest(force=False)
            self.ui_queue.put(("log", f"[live-retry] job vượt giới hạn {limit} lần, giữ trạng thái lỗi: {original_path}"))
            return False
        target["status"] = "queued"
        target["worker"] = ""
        target["note"] = f"Live retry {cnt}/{limit} • {err_type} • đẩy lại vẽ ngay"
        try:
            # Nếu object trong state.jobs khác object self.jobs, đồng bộ theo path.
            for j in state.jobs:
                if self._normalize_cmp_path(j.get("image_path")) == wanted:
                    j.update({k: target.get(k) for k in ("status", "worker", "note", "live_error_retry_count", "last_error_type", "last_error_message")})
                    break
        except Exception:
            pass
        self._recompute_state_counts(state)
        self._save_run_manifest(force=False)
        self.ui_queue.put(("log", f"[live-retry] đẩy lại job lỗi ngay vòng {cnt}/{limit}: {original_path}"))
        self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
        try:
            self._schedule_queued_jobs()
        except Exception as e:
            self.ui_queue.put(("log", f"[live-retry] schedule lỗi nhẹ: {e}"))
        return True

    def _handle_worker_json_event(self, state, event):
        try:
            state.json_mode = True
        except Exception:
            pass
        typ = str(event.get("type") or "")
        path = event.get("path") or event.get("root") or ""
        account = event.get("account")
        if account:
            try:
                state.account_no = self._local_account_to_actual(state, int(account))
                # v12.58: nếu worker đổi sang account thứ 2 trong pool thì cũng đánh dấu đang dùng,
                # tránh scheduler lấy trùng; khi worker xong sẽ nhả toàn bộ account_map.
                with self.run_lock:
                    self.active_accounts.add(state.account_no)
            except Exception:
                pass
        if typ == "worker_ready":
            state.phase = "Worker ready"
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "▶ Sẵn sàng", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return True
        if typ == "account_switch":
            state.phase = "Đổi account"
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "🔄 Đổi TK", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return True
        if typ == "job_start":
            original_path, _copied_path = self._resolve_pair_from_worker_path(state, path)
            if original_path and not self._lease_matches_state(state, original_path, allow_missing=True):
                self.ui_queue.put(("log", f"[dispatch-fix] bỏ qua job_start muộn từ W{state.worker_id}: lease không khớp • {original_path}"))
                self._terminate_stale_lease_worker(state, original_path, "job_start")
                return True
            state.current_worker_path = path
            state.current_original_path = original_path
            state.current = str(Path(original_path).parent.name + '/' + Path(original_path).name) if original_path else Path(path).name
            state.current_job_started_at = time.monotonic()
            state.phase = "Bắt đầu job"
            self._mark_job_status(state, original_path, "running", "Đang xử lý • JSON event")
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "▶ Đang chạy", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return True
        if typ == "job_done":
            original_path, copied_path = self._resolve_pair_from_worker_path(state, path)
            if original_path:
                state.current_original_path = original_path
                state.current_worker_path = copied_path or path
            state.phase = "Đã xong"
            final = event.get("final") or {}
            note = "Đã ghi đè file gốc + logo OK"
            if isinstance(final, dict) and final.get("size_mb"):
                note += f" • {final.get('width')}x{final.get('height')} • {final.get('size_mb')}MB"
            if not self._lease_matches_state(state, state.current_original_path, allow_missing=True):
                self.ui_queue.put(("log", f"[dispatch-fix] bỏ qua kết quả muộn từ W{state.worker_id}: lease không còn khớp • {state.current_original_path}"))
                self._terminate_stale_lease_worker(state, state.current_original_path, "job_done")
                return True
            self._mark_job_status(state, state.current_original_path, "done", note)
            duration = 0.0
            try:
                if float(getattr(state, "current_job_started_at", 0.0) or 0.0) > 0:
                    duration = max(0.0, time.monotonic() - float(state.current_job_started_at or 0.0))
            except Exception:
                duration = 0.0
            state.last_job_duration = duration
            state.completed_events = int(getattr(state, "completed_events", 0) or 0) + 1
            self._record_account_success(state.account_no, duration)
            ok, err = self._copy_back_one(state, state.current_original_path, state.current_worker_path)
            if ok:
                self.ui_queue.put(("log", f"[manager] copyback OK atomic • JSON event • {state.current_original_path}"))
            elif err:
                self.ui_queue.put(("log", f"[manager] copyback failed • {err} • {state.current_original_path}"))
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "✓ Xong job", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return True
        if typ == "job_retry":
            msg = str(event.get("message") or "retry")
            err_type = str(event.get("error_type") or "retry")
            attempt = event.get("attempt") or "?"
            max_attempts = event.get("max_attempts") or "?"
            self._mark_error_stat(f"retry:{err_type}")
            original_path, _copied_path = self._resolve_pair_from_worker_path(state, path)
            if original_path and not self._lease_matches_state(state, original_path, allow_missing=True):
                self.ui_queue.put(("log", f"[dispatch-fix] bỏ qua job_retry muộn từ W{state.worker_id}: lease không khớp • {original_path}"))
                self._terminate_stale_lease_worker(state, original_path, "job_retry")
                return True
            if original_path:
                state.current_original_path = original_path
                self._mark_job_status(state, original_path, "running", f"Retry {attempt}/{max_attempts} • {err_type}")
            state.phase = "Retry job"
            state.last_error = f"{err_type}: {msg[:160]}"
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "🔁 Retry", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return True
        if typ in ("job_error", "quota"):
            msg = str(event.get("message") or typ)
            err_type = str(event.get("error_type") or typ)
            account_exhaust = bool(event.get("account_exhaust"))
            if str(err_type).lower() in ("session_fail", "login_fail", "logged_out", "account_verify_required", "robot_check"):
                try:
                    self._mark_account_force_login(state.account_no, msg)
                    if str(err_type).lower() in ("session_fail", "login_fail", "logged_out"):
                        self._mark_account_exhausted(state.account_no, reason_type=str(err_type).lower(), message=msg)
                        _new = self._replace_account_in_machine_pool(state.account_no, "profile mất phiên → bù mail khác")
                        if _new:
                            self.ui_queue.put(("log", f"[account-pool] A{state.account_no}: worker báo mất phiên → bù A{_new} từ kho mail, không login lại mail cũ"))
                        else:
                            self.ui_queue.put(("log", f"[account-pool] A{state.account_no}: worker báo mất phiên → bỏ mail cũ, chờ mail khác rảnh"))
                    else:
                        self.ui_queue.put(("log", f"[profile-reuse] A{state.account_no}: worker báo verify/checkpoint → bỏ account này"))
                except Exception:
                    pass
            self._mark_error_stat(f"A{state.account_no}:{err_type}")
            state.last_error = msg
            if typ == "quota":
                self._mark_account_exhausted(state.account_no, reason_type="quota", message=msg)
                state.quota_exhausted = True
                state.phase = "Hết lượt"
                self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "⏸ Hết lượt", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
                return True
            original_path, _copied_path = self._resolve_pair_from_worker_path(state, path)
            if original_path and not self._lease_matches_state(state, original_path, allow_missing=True):
                self.ui_queue.put(("log", f"[dispatch-fix] bỏ qua job_error muộn từ W{state.worker_id}: lease không khớp • {original_path}"))
                self._terminate_stale_lease_worker(state, original_path, "job_error")
                return True
            if original_path:
                state.current_original_path = original_path
            try:
                for j in state.jobs:
                    if self._normalize_cmp_path(j.get("image_path")) == self._normalize_cmp_path(state.current_original_path):
                        j["error_type"] = err_type
                        break
            except Exception:
                pass
            if account_exhaust:
                self._record_account_error_once(state.account_no, reason_type=err_type, message=msg)
            else:
                self._record_account_error(state.account_no, err_type=err_type, account_level=False, quota=False)
            rotate_now, rotate_reason = self._should_rotate_account_after_error(state.account_no, err_type)
            if rotate_now:
                if not account_exhaust:
                    account_exhaust = True
                try:
                    _new_acc = self._replace_account_in_machine_pool(state.account_no, rotate_reason or err_type)
                except Exception:
                    _new_acc = None
                if _new_acc:
                    self.ui_queue.put(("log", f"[account-pool] A{state.account_no} -> đổi A{_new_acc} từ kho mail • {rotate_reason or err_type}"))
                else:
                    self.ui_queue.put(("log", f"[account-pool] A{state.account_no} -> loại account • {rotate_reason or err_type}"))
            if not account_exhaust:
                # v134.8: FlowGenerationFailed thường là lỗi theo job/prompt/ảnh sau nhiều attempt trong backend.
                # Không khóa tài khoản; nhả RIÊNG job đó sang tài khoản khác và không cho quay lại account vừa lỗi.
                if err_type in FLOW_POLICY_FAILOVER_ERROR_TYPES:
                    moved_job = None
                    for j in state.jobs:
                        if self._normalize_cmp_path(j.get("image_path")) == self._normalize_cmp_path(state.current_original_path):
                            moved_job = j
                            break
                    if moved_job is not None:
                        self._remember_job_policy_fail(moved_job, state.account_no)
                        tried = self._job_tried_accounts(moved_job)
                        max_accounts = max(1, min(int(POLICY_MAX_ACCOUNTS_PER_JOB or 2), len(self._configured_accounts())))
                        if len(tried) >= max_accounts:
                            moved_job["status"] = "error"
                            moved_job["worker"] = ""
                            moved_job["error_type"] = err_type
                            moved_job["note"] = f"Policy guard: lỗi Flow trên {len(tried)} tài khoản {tried} • dừng chuyển để không tốn lượt/thời gian"
                            self._recompute_state_counts(state)
                            self._save_run_manifest(force=False)
                            state.phase = "Policy guard"
                            self.ui_queue.put(("log", f"[policy-guard] job lỗi policy trên {len(tried)} tài khoản {tried} • đánh dấu lỗi, không chuyển tiếp: {state.current_original_path}"))
                            try:
                                self._mark_policy_folder_fast_skip_if_needed(Path(str(state.current_original_path)).parent, "Policy guard: folder có nhiều job bị FlowGenerationFailed")
                            except Exception:
                                pass
                            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "⛔ Policy", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
                            return True
                        else:
                            moved_job["status"] = "queued"
                            moved_job["worker"] = ""
                            moved_job["note"] = f"Flow lỗi {err_type} trên A{state.account_no} • chuyển job sang TK khác lần cuối • đã thử {tried}/{max_accounts}"
                            self._recompute_state_counts(state)
                            self._save_run_manifest(force=False)
                            state.phase = "Chuyển job sang TK khác"
                            self.ui_queue.put(("log", f"[manager] job lỗi Flow trên A{state.account_no} • nhả sang tài khoản khác, giới hạn {max_accounts} TK/job: {state.current_original_path}"))
                            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "↪ Chuyển job", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
                            self._schedule_queued_jobs()
                            return True
                # v12.54: capture/validate/upload fail không khóa account; đẩy lại job ngay để tài khoản/worker rảnh xử lý tiếp.
                state.phase = "Đẩy lại job lỗi"
                if state.current_original_path:
                    requeued = self._live_requeue_error_job(state, state.current_original_path, err_type, msg)
                    if not requeued:
                        self._mark_job_status(state, state.current_original_path, "error", f"Lỗi job sau retry • {err_type}")
                self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "↪ Retry lỗi", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
                return True
            state.failover_requested = True
            state.failover_reason = f"A{state.account_no} lỗi account JSON • {err_type}: {msg[:120]}"
            state.failover_exhaust_current = True
            state.phase = "Lỗi account"
            if state.current_original_path:
                self._mark_job_status(state, state.current_original_path, "queued", f"A{state.account_no} lỗi account • chờ đổi tài khoản • {err_type}")
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "✖ Lỗi TK", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            if not getattr(state, "failover_handled", False):
                try:
                    self._handle_worker_failover(
                        state,
                        self.current_root_folder,
                        self.current_logo_path,
                        self.current_workers_root,
                        state.failover_reason,
                        mark_current_exhausted=True,
                        exhaust_reason=err_type,
                    )
                    state.failover_handled = True
                except Exception as e:
                    self.ui_queue.put(("log", f"[manager] failover JSON lỗi: {e}"))
            self._terminate_worker_process(state, "JSON event lỗi account để chuyển tài khoản")
            return True
        if typ == "job_skipped":
            original_path, _copied_path = self._resolve_pair_from_worker_path(state, path)
            self._mark_job_status(state, original_path, "skipped", str(event.get("reason") or "skipped"))
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            return True
        if typ == "worker_summary":
            self.ui_queue.put(("log", f"[W{state.worker_id}] summary JSON • ok={event.get('success')} err={event.get('failed')} skip={event.get('skipped')}"))
            return True
        return False

    def _parse_worker_line(self, state, line):
        # FIX v12.88: worker có json_mode=True nên log text thường bị bỏ qua.
        # Nhưng lỗi đăng xuất xảy ra ngay lúc khởi động, trước khi worker kịp bắn JSON event.
        # Vì vậy phải bắt SESSION_FAIL bằng text để đánh dấu force-login cho account đó.
        raw_line = str(line or "").strip()
        low_line = raw_line.lower()
        if any(x in low_line for x in ("account_verify_required", "google yêu cầu xác minh", "xác minh danh tính", "verify identity checkpoint", "robot_check")):
            try:
                state.last_error = raw_line
                self._mark_account_force_login(state.account_no, raw_line)
                self.ui_queue.put(("log", f"[account-pool] A{state.account_no}: bị Google Verify/checkpoint → bỏ account này, chuyển tài khoản khác"))
            except Exception:
                pass
            try:
                state.failover_requested = True
                state.failover_reason = f"A{state.account_no} bị Google Verify/checkpoint • đổi tài khoản khác • {raw_line[:120]}"
                state.failover_exhaust_current = True
            except Exception:
                pass
        if any(x in low_line for x in ("session_fail", "manual login popup disabled", "profile mất phiên", "profile logged out")):
            try:
                state.last_error = raw_line
                self._mark_account_force_login(state.account_no, raw_line)
                self._mark_account_exhausted(state.account_no, reason_type="session", message=raw_line)
                _new = self._replace_account_in_machine_pool(state.account_no, "profile mất phiên → bù mail khác")
                if _new:
                    self.ui_queue.put(("log", f"[account-pool] A{state.account_no}: profile mất phiên → bỏ mail này, bù A{_new} từ kho mail"))
                else:
                    self.ui_queue.put(("log", f"[account-pool] A{state.account_no}: profile mất phiên → bỏ mail này, đang chờ mail rảnh trong kho"))
            except Exception:
                pass
            try:
                state.failover_requested = True
                state.failover_reason = f"A{state.account_no} mất phiên/login fail • bù mail khác • {raw_line[:120]}"
                state.failover_exhaust_current = True
            except Exception:
                pass
        if str(line or "").startswith(EVENT_MARKER):
            try:
                event = json.loads(str(line)[len(EVENT_MARKER):])
                if self._handle_worker_json_event(state, event):
                    return
            except Exception as e:
                self.ui_queue.put(("log", f"[manager] JSON event parse lỗi: {e}"))
                return
        if getattr(state, "json_mode", False):
            # Worker v79 có JSON event chuẩn; không parse log text/emoji để tránh failover nhầm khi job retry.
            return
        m_acc = re.search(r"🔄 Chuyển sang account\s+(\d+)", line) or re.search(r"🔑 Đang dùng account:\s*(\d+)", line)
        if m_acc:
            state.account_no = self._local_account_to_actual(state, int(m_acc.group(1)))
        m = re.search(r"🎨 Cần vẽ \(<.*?\): (.+)$", line)
        if m:
            current_worker_path = m.group(1).strip()
            state.current_worker_path = current_worker_path
            original_path, _copied_path = self._resolve_pair_from_worker_path(state, current_worker_path)
            state.current_original_path = original_path
            if original_path and not self._lease_matches_state(state, original_path, allow_missing=True):
                self.ui_queue.put(("log", f"[dispatch-fix] bỏ qua job_start text muộn từ W{state.worker_id}: lease không khớp • {original_path}"))
                self._terminate_stale_lease_worker(state, original_path, "text_job_start")
                return
            state.current = str(Path(original_path).parent.name + '/' + Path(original_path).name) if original_path else Path(current_worker_path).name
            state.phase = "Bắt đầu job"
            self._mark_job_status(state, original_path, "running", "Đang xử lý")
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "▶ Đang chạy", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return
        low = line.lower()
        if "✅ final ok" in low or "✅ đã ghi đè ảnh + chèn logo thành công" in low:
            state.phase = "Đã xong"
            if not self._lease_matches_state(state, state.current_original_path, allow_missing=True):
                self.ui_queue.put(("log", f"[dispatch-fix] bỏ qua kết quả text muộn từ W{state.worker_id}: lease không còn khớp • {state.current_original_path}"))
                self._terminate_stale_lease_worker(state, state.current_original_path, "text_done")
                return
            self._mark_job_status(state, state.current_original_path, "done", "Đã ghi đè file gốc + logo OK")
            ok, err = self._copy_back_one(state, state.current_original_path, state.current_worker_path)
            if ok:
                self.ui_queue.put(("log", f"[manager] copyback OK atomic • đã ghi đè file gốc • {state.current_original_path}"))
            elif err:
                self.ui_queue.put(("log", f"[manager] copyback failed • {err} • {state.current_original_path}"))
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "✓ Xong job", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return
        if "hết lượt tạo ảnh" in low or "hết tài khoản google" in low:
            state.quota_exhausted = True
            state.last_error = line.replace("Hết tài khoản Google", "Hết account cục bộ trong worker hiện tại")
            state.phase = "Hết lượt"
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "⏸ Hết lượt", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            return
        if self._line_is_real_error(line):
            state.last_error = line
            if any(x in low for x in ("chưa đăng nhập", "sign in", "login", "accounts.google.com", "xác minh", "verify")):
                try:
                    self._mark_account_force_login(state.account_no, line)
                    self.ui_queue.put(("log", f"[profile-reuse] A{state.account_no}: log báo mất phiên → lần sau login lại profile này"))
                except Exception:
                    pass
            state.failover_requested = True
            state.failover_reason = f"A{state.account_no} lỗi • đổi tài khoản khác • {line[:120]}"
            state.failover_exhaust_current = True
            state.phase = "Lỗi"
            if state.current_original_path:
                self._mark_job_status(state, state.current_original_path, "queued", f"A{state.account_no} lỗi • chờ đổi tài khoản")
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
            self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "✖ Lỗi", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
            if not getattr(state, "failover_handled", False):
                self.ui_queue.put(("log", f"[manager] W{state.worker_id}/A{state.account_no} lỗi thật • nhả job và tìm tài khoản rảnh NGAY"))
                try:
                    self._handle_worker_failover(
                        state,
                        self.current_root_folder,
                        self.current_logo_path,
                        self.current_workers_root,
                        state.failover_reason,
                        mark_current_exhausted=True,
                    )
                    state.failover_handled = True
                except Exception as e:
                    self.ui_queue.put(("log", f"[manager] failover tức thì lỗi: {e}"))
            self._terminate_worker_process(state, "phát hiện lỗi để chuyển tài khoản")

    def _line_is_real_error(self, line):
        raw = str(line or '').strip(); low = raw.lower()
        if not raw: return False
        if re.match(r"^❌\s*thất bại:\s*\d+\s*$", raw, re.I): return False
        if re.match(r"^traceback \(most recent call last\):$", raw, re.I): return True
        if "💥 lỗi process_image" in low and ("account_exhaust=false" in low or "retryable=true" in low): return False
        if "💥" in raw or "traceback" in low: return True
        if raw.startswith("❌"): return True
        return False

    def _should_show_worker_log(self, state, line):
        raw = str(line or '').strip(); low = raw.lower()
        if not raw: return False
        important = ("🎨 cần vẽ", "✅", "❌", "💥", "⚠", "🔄 chuyển", "🔑 đang dùng", "hết lượt", "quota", "final ok", "đã ghi đè", "traceback", "worker exit", "đăng nhập", "không lấy được ảnh", "lỗi toàn bộ", "headless-gemini", "headless", "browser ui=off")
        if any(tok in low or tok in raw for tok in important): return True
        noisy = ("⏱ gemini state:", "candidate image urls", "url ảnh chọn được", "dom attempt", "retry url attempt", "blob:", "data:image/", "số candidate", "spinners=", "freshresult=")
        now = time.monotonic(); last = float(getattr(state, "last_ui_log_ts", 0.0) or 0.0)
        if any(tok in low for tok in noisy):
            if now - last >= NOISY_LOG_THROTTLE_SECONDS:
                state.last_ui_log_ts = now; return True
            return False
        if now - last >= GENERIC_LOG_THROTTLE_SECONDS:
            state.last_ui_log_ts = now; return True
        return False

    def _kill_process_tree(self, pid, timeout=2.5):
        if not pid or psutil is None: return
        try: root = psutil.Process(pid)
        except Exception: return
        victims = []
        try: victims.extend(root.children(recursive=True))
        except Exception: pass
        victims.append(root)
        ordered, seen = [], set()
        for p in victims:
            try:
                if p.pid not in seen:
                    seen.add(p.pid); ordered.append(p)
            except Exception: pass
        for p in reversed(ordered):
            try: p.terminate()
            except Exception: pass
        try: _, alive = psutil.wait_procs(ordered, timeout=timeout)
        except Exception: alive = ordered
        for p in reversed(alive):
            try: p.kill()
            except Exception: pass

    def _cleanup_leftover_worker_processes(self, timeout=1.0):
        """V20 SAFE cleanup: terminate only processes that prove Thumbnail Studio ownership.

        NEVER match Chrome by executable path alone.  The previous implementation considered
        `exe == self.chrome_binary` sufficient; if self.chrome_binary was normal system Chrome,
        every unrelated Chrome window became a victim.

        Ownership evidence accepted here:
          * command line contains a Thumbnail Studio temporary run/check/description root; or
          * Chrome command line has --user-data-dir inside this addon's profiles/run roots.
        Live workers are normally stopped via their tracked state.proc process tree, so this is
        only a conservative stale-process fallback.
        """
        if psutil is None:
            return 0
        try:
            backend_root = str(self.backend_dir.resolve()).lower()
        except Exception:
            backend_root = str(self.backend_dir).lower()
        owned_roots = []
        for _p in (
            self.backend_dir / "_simple_parallel_runs",
            self.backend_dir / CHECK_CLONE_ROOT_NAME,
            self.backend_dir / "profiles",
            getattr(self, "_desc_current_run_root", None),
        ):
            try:
                if _p:
                    owned_roots.append(str(Path(_p).resolve()).lower())
            except Exception:
                pass
        # Exact worker/script markers are safe even when a user-data-dir flag is absent.
        safe_markers = [
            "_simple_parallel_runs",
            CHECK_CLONE_ROOT_NAME.lower(),
            "toolthumbnail\\desc_runs",
            "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py",
        ]
        candidates = []
        current_pid = os.getpid()
        for proc in psutil.process_iter(["pid", "name", "exe", "cmdline"]):
            try:
                pid = int(proc.info.get("pid") or 0)
                if not pid or pid == current_pid:
                    continue
                name = (proc.info.get("name") or "").lower()
                cmd_parts = [str(x or "") for x in (proc.info.get("cmdline") or [])]
                cmd = " ".join(cmd_parts).lower()
                if not cmd:
                    # No command line means no ownership proof. Leave it alone.
                    continue
                owned = any(m and m in cmd for m in safe_markers)
                if not owned and "--user-data-dir" in cmd:
                    owned = any(r and r in cmd for r in owned_roots)
                if not owned:
                    continue
                if not any(x in name for x in ("chrome", "chromedriver", "python", "pythonw", "cmd")):
                    continue
                candidates.append(proc)
            except Exception:
                pass
        killed = 0
        seen = set()
        for proc in sorted(candidates, key=lambda p: p.pid, reverse=True):
            try:
                if proc.pid in seen:
                    continue
                seen.add(proc.pid)
                self._kill_process_tree(proc.pid, timeout=timeout)
                killed += 1
            except Exception:
                # Do not fall back to broad process-name/exe kill. Safety wins over cleanup.
                pass
        try:
            if killed:
                self.append_log(f"[V20-PROCESS-SAFETY] cleanup ownership-only • killed={killed}")
        except Exception:
            pass
        return killed

    def _terminate_worker_process(self, state, reason=""):

        if getattr(state, "terminate_requested", False): return
        state.terminate_requested = True
        proc = getattr(state, "proc", None)
        if reason:
            self.ui_queue.put(("log", f"[manager] yêu cầu dừng W{state.worker_id} • {reason}"))
        if not proc: return
        try:
            if proc.poll() is None:
                try: proc.terminate()
                except Exception: pass
                time.sleep(0.6)
                if proc.poll() is None:
                    self._kill_process_tree(proc.pid)
        except Exception as e:
            self.ui_queue.put(("log", f"[manager] dừng process lỗi: {e}"))

    def _terminate_stale_lease_worker(self, state, original_path, event_name="stale-event"):
        """V22: một worker đã mất dispatch lease tuyệt đối không được tiếp tục chạy các job local cũ.

        Lease mismatch nghĩa là job đã được giao lại/restore/rescan cho worker khác. Bản V21 chỉ bỏ
        event muộn nhưng để process cũ tiếp tục vẽ, gây tốn lượt Gemini và có thể đụng restore/redraw.
        V22 dừng đúng process tree của worker stale; không đụng Chrome ngoài Thumbnail Studio.
        """
        try:
            if getattr(state, "terminate_requested", False):
                return False
            ptxt = str(original_path or "")
            self.ui_queue.put(("log", f"[V22-STALE-WORKER] W{state.worker_id} mất lease ({event_name}) → dừng worker cũ ngay • {ptxt}"))
            state.last_error = f"stale lease: {event_name}"
            self._terminate_worker_process(state, f"mất dispatch lease • {event_name}")
            return True
        except Exception as e:
            try:
                self.ui_queue.put(("log", f"[V22-STALE-WORKER] dừng W{getattr(state,'worker_id','?')} lỗi nhẹ: {e}"))
            except Exception:
                pass
            return False

    def _remaining_jobs_for_state(self, state):
        # v134.8: chỉ nhả job vẫn thuộc worker này; job đã chuyển sang worker/account khác không kéo ngược lại.
        return [j for j in state.jobs if j.get("status") not in ("done", "skipped", "error") and self._job_owned_by_state(state, j)]

    def _release_active_account(self, account_no):
        acquired = False
        try:
            acquired = self.run_lock.acquire(timeout=0.25)
            if not acquired:
                self.ui_queue.put(("log", f"[lock-fix] bỏ qua nhả A{account_no} tạm thời vì run_lock bận; tail-rescue sẽ thử lại"))
                return
            self.active_accounts.discard(account_no)
        finally:
            if acquired:
                try: self.run_lock.release()
                except Exception: pass

    def _release_state_accounts(self, state, keep_exhausted=None):
        """v12.77: nhả account không được làm UI thread đứng chờ run_lock vô hạn."""
        keep_exhausted = set(keep_exhausted or [])
        try:
            vals = list(getattr(state, "account_map", []) or []) + [getattr(state, "account_no", None)]
        except Exception:
            vals = [getattr(state, "account_no", None)]
        acquired = False
        try:
            acquired = self.run_lock.acquire(timeout=0.25)
            if not acquired:
                try:
                    self.ui_queue.put(("log", f"[lock-fix] run_lock bận khi nhả W{getattr(state,'worker_id','?')}; sẽ retry tick sau"))
                except Exception:
                    pass
                return
            live_elsewhere = self._active_worker_accounts(exclude_state=state)
            for a in vals:
                try:
                    if a in keep_exhausted:
                        continue
                    ai = int(a) if a is not None else None
                    if ai is not None and ai in live_elsewhere:
                        # Không nhả account nếu một worker khác vẫn đang dùng profile đó.
                        self.active_accounts.add(ai)
                        continue
                    self.active_accounts.discard(a)
                except Exception:
                    pass
        finally:
            if acquired:
                try: self.run_lock.release()
                except Exception: pass

    def _cleanup_finished_worker_accounts(self):
        """v12.58: dọn active account bị kẹt từ worker đã kết thúc."""
        changed = 0
        try:
            for w in list(getattr(self, "workers", []) or []):
                proc = getattr(w, "proc", None)
                if proc is not None and proc.poll() is not None:
                    before = len(getattr(self, "active_accounts", set()) or set())
                    self._release_state_accounts(w)
                    after = len(getattr(self, "active_accounts", set()) or set())
                    if after < before:
                        changed += before - after
        except Exception:
            pass
        return changed

    def _live_worker_ids(self):
        # v12.59: dùng active dispatch ids, bao gồm worker đang login/chưa Popen.
        try:
            return self._active_dispatch_worker_ids()
        except Exception:
            return set()

    def _cleanup_stale_reserved_jobs(self):
        """v12.58: nếu job đang reserved/running nhưng worker đó đã chết/xong, đưa lại về queued."""
        live_ids = self._live_worker_ids()
        changed = 0
        for j in list(getattr(self, "jobs", []) or []):
            st = j.get("status")
            if st not in ("reserved", "running"):
                continue
            worker = str(j.get("worker") or "")
            m = re.search(r"W(\d+)/", worker)
            if m:
                try:
                    wid = int(m.group(1))
                except Exception:
                    wid = None
                if wid is not None and wid not in live_ids:
                    j["status"] = "queued"
                    j["worker"] = ""
                    j["note"] = "Dispatch Fix: worker cũ đã dừng, đưa lại hàng chờ"
                    changed += 1
        if changed:
            self.ui_queue.put(("log", f"[dispatch-fix] đưa lại {changed} job bị kẹt reserved/running về Chờ"))
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
        return changed

    def _tail_rescue_tick(self):
        """v12.58: cuối batch thường chỉ còn vài job lỗi capture/DOM được live-retry.
        Tick này đảm bảo khi còn job Chờ và còn slot trống thì scheduler luôn được gọi lại.
        """
        try:
            if not getattr(self, "running", False) or getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
                return
            self._cleanup_finished_worker_accounts()
            stale = self._cleanup_stale_reserved_jobs()
            queued = [j for j in (self.jobs or []) if j.get("status") == "queued"]
            if not queued:
                return
            live = self._active_live_worker_count()
            target = max(1, int(getattr(self, "current_requested_workers_count", self.worker_spin.value() if hasattr(self, "worker_spin") else 1) or 1))
            if stale or live < target:
                now = time.monotonic()
                last = float(getattr(self, "_last_tail_rescue_log_ts", 0.0) or 0.0)
                if now - last > 10:
                    self._last_tail_rescue_log_ts = now
                    self.ui_queue.put(("log", f"[dispatch-fix] còn {len(queued)} job Chờ • live {live}/{target} -> gọi scheduler bơm tiếp"))
                self._schedule_queued_jobs()
        except Exception as e:
            try:
                self.ui_queue.put(("log", f"[dispatch-fix] lỗi nhẹ: {e}"))
            except Exception:
                pass

    def _account_issue_kind(self, reason_type="", message=""):
        low = (str(reason_type or "") + " " + str(message or "")).lower()
        if any(x in low for x in ("quota", "hết lượt", "limit reached", "generation limit")):
            return "quota"
        if any(x in low for x in ("verify", "xác minh", "checkpoint", "robot_check")):
            return "verify"
        if any(x in low for x in ("refusal", "request denied", "từ chối", "policy")):
            return "refusal"
        if any(x in low for x in ("session", "login", "logged out", "đăng xuất", "mất phiên", "accounts.google.com")):
            return "session"
        return "account_error"

    def _record_account_error_once(self, account_no, reason_type="account_error", message=""):
        try:
            acc = int(account_no)
        except Exception:
            acc = account_no
        kind = self._account_issue_kind(reason_type, message)
        key = (acc, kind)
        with self.run_lock:
            if key in self._account_issue_once:
                return False
            self._account_issue_once.add(key)
        self._record_account_error(acc, err_type=kind, account_level=True, quota=(kind == "quota"))
        return True

    def _mark_account_exhausted(self, account_no, reason_type="account_error", message=""):
        try:
            account_no = int(account_no)
        except Exception:
            pass
        kind = self._account_issue_kind(reason_type, message)
        acquired = False
        try:
            acquired = self.run_lock.acquire(timeout=0.5)
            if acquired:
                self.exhausted_accounts.add(account_no); self.active_accounts.discard(account_no)
            else:
                try: self.ui_queue.put(("log", f"[lock-fix] chưa đánh dấu exhausted A{account_no} vì run_lock bận"))
                except Exception: pass
        finally:
            if acquired:
                try: self.run_lock.release()
                except Exception: pass
        if kind == "quota":
            self._mark_daily_quota_hold(account_no, message=message)
        recorded = self._record_account_error_once(account_no, reason_type=kind, message=message)
        if recorded and kind != "quota":
            labels = {
                "session": "lỗi phiên/login",
                "verify": "Google yêu cầu xác minh",
                "refusal": "Gemini từ chối yêu cầu",
                "account_error": "lỗi account",
            }
            try:
                self.ui_queue.put(("log", f"[account-hold] loại A{account_no} trong lượt chạy này • {labels.get(kind, kind)}"))
            except Exception:
                pass
        return recorded

    def _choose_failover_account(self, state=None, exclude=None):
        configured = self._configured_accounts()
        exclude_set = set(exclude or [])
        if state is not None:
            exclude_set.update(getattr(state, "tried_accounts", []) or [])
        with self.run_lock:
            active = set(self.active_accounts) | self._active_worker_accounts()
            exhausted = set(self.exhausted_accounts)
        candidates = []
        for acc in configured:
            if acc in exclude_set or acc in active or acc in exhausted:
                continue
            if self._account_cooldown_remaining(acc) > 0:
                continue
            candidates.append(acc)
        candidates = self._sorted_candidate_accounts(candidates)
        return candidates[0] if candidates else None

    def _prepare_failover_remaining_jobs(self, state, note):
        remaining = self._remaining_jobs_for_state(state)
        for job in remaining:
            job["status"] = "queued"; job["note"] = note; job["worker"] = ""
        self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
        return remaining

    def _available_failover_accounts(self, state=None, exclude=None):
        configured = self._configured_accounts()
        exclude_set = set(exclude or [])
        if state is not None:
            exclude_set.update(getattr(state, "tried_accounts", []) or [])
        with self.run_lock:
            active = set(self.active_accounts) | self._active_worker_accounts()
            exhausted = set(self.exhausted_accounts)
        out = []
        for acc in configured:
            if acc in exclude_set or acc in active or acc in exhausted:
                continue
            if self._account_cooldown_remaining(acc) > 0:
                continue
            if acc not in out:
                out.append(acc)
        return self._sorted_candidate_accounts(out)

    def _handle_worker_failover(self, state, root_folder, logo, workers_root, cause_text, mark_current_exhausted=False, exhaust_reason="account_error"):
        if getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
            try:
                self._release_state_accounts(state)
            except Exception:
                pass
            return False
        failed_acc = state.account_no
        issue_kind = self._account_issue_kind(exhaust_reason, cause_text)
        if mark_current_exhausted:
            self._mark_account_exhausted(failed_acc, reason_type=issue_kind, message=cause_text)
            self._release_state_accounts(state, keep_exhausted={failed_acc})
            try:
                _cause_low = str(cause_text or '').lower()
                if any(_x in _cause_low for _x in ("session_fail", "mất phiên", "đăng xuất", "logged out", "login fail")):
                    _new = self._replace_account_in_machine_pool(failed_acc, "profile mất phiên → bù mail khác")
                    if _new:
                        self.ui_queue.put(("log", f"[account-pool] A{failed_acc}: failover do mất phiên → chọn A{_new} từ FULL VAULT"))
            except Exception:
                pass
        else:
            self._release_state_accounts(state)

        # v12.93 SLOT/ACCOUNT FIX: profile mất phiên thì không login lại mail cũ, thay mail khác từ kho.
        # v12.92 SLOT FIX: nếu worker lỗi ngay ở bước login/check trước khi Popen,
        # state.proc vẫn None. Bản cũ vẫn tính state này là live tới 20 phút,
        # làm UI chỉ chạy 1-2 luồng dù người dùng chọn 5/8. Đánh dấu xong ngay
        # sau khi đã nhả account/job để scheduler bơm tài khoản khác tức thì.
        try:
            state.finished = True
            state.launch_failed = True
        except Exception:
            pass

        remaining = self._prepare_failover_remaining_jobs(state, cause_text)

        if remaining:
            # v13.50 ACCOUNT CLAIM RACE FIX:
            # Nhiều failover có thể chạy gần như đồng thời. Bản cũ lấy `available` TRƯỚC khi
            # vào run_lock nên W106/W107/W108 có thể cùng nhìn thấy A85 là rảnh rồi cùng claim.
            # Từ đây việc chọn + claim account được thực hiện nguyên tử trong cùng run_lock.
            requested_limit = int(getattr(self, "current_requested_workers_count", 1) or 1)
            try:
                live_now = self._active_live_worker_count()
                if not getattr(state, "finished", False) and not getattr(state, "terminate_requested", False):
                    live_now = max(0, live_now - 1)
            except Exception:
                live_now = 0
            free_slots = max(0, max(1, requested_limit) - live_now)
            if free_slots <= 0:
                self.ui_queue.put(("log", f"[dispatch-fix] failover giữ cap {requested_limit} luồng • {len(remaining)} job quay về Chờ, đợi worker rảnh"))
                self._schedule_queued_jobs()
                return False

            launch = []
            with self.run_lock:
                configured_now = self._configured_accounts()
                exclude_now = {failed_acc}
                exclude_now.update(getattr(state, "tried_accounts", []) or [])
                busy_now = set(self.active_accounts) | self._active_worker_accounts()
                exhausted_now = set(self.exhausted_accounts)
                available_now = [
                    a for a in configured_now
                    if a not in exclude_now
                    and a not in busy_now
                    and a not in exhausted_now
                    and self._account_cooldown_remaining(a) <= 0
                ]
                available_now = self._sorted_candidate_accounts(available_now)
                slots = min(len(available_now), len(remaining), free_slots)
                bucket_records = self._bucket_jobs_for_queue_workers(remaining, slots) if slots > 0 else []

                self.next_runtime_worker_id = max(self.next_runtime_worker_id, max([w.worker_id for w in self.workers] + [0]) + 1)
                for idx, acc in enumerate(available_now[:slots]):
                    # Phòng thủ thêm: kiểm tra ngay trước claim trong cùng critical section.
                    live_busy = set(self.active_accounts) | self._active_worker_accounts()
                    if acc in live_busy or acc in self.exhausted_accounts:
                        continue
                    bucket = bucket_records[idx] if idx < len(bucket_records) else {}
                    jobs = list(bucket.get("jobs") or [])
                    if not jobs:
                        continue

                    # Claim account TRƯỚC khi tạo/launch worker để thread failover khác không thể lấy trùng.
                    self.active_accounts.add(acc)
                    wid = self.next_runtime_worker_id
                    self.next_runtime_worker_id += 1
                    new_state = WorkerState(wid, acc, jobs)
                    new_state.account_map = [acc]
                    new_state.account_no = acc
                    new_state.tried_accounts = list(dict.fromkeys((getattr(state, "tried_accounts", []) or []) + [acc]))
                    # v12.56: failover cũng phải giữ đúng Queue/root/logo của bucket, không dùng lại logo fallback Queue #1.
                    new_state.queue_index = bucket.get("queue_index")
                    new_state.worker_root = normalize_path(bucket.get("root") or root_folder)
                    new_state.worker_logo = normalize_path(bucket.get("logo") or logo)
                    self.workers.append(new_state)
                    for job in jobs:
                        try:
                            if new_state.queue_index is not None and str(new_state.queue_index).lstrip('-').isdigit():
                                job["queue_index"] = int(new_state.queue_index)
                            job["queue_root"] = new_state.worker_root
                            job["queue_logo"] = new_state.worker_logo
                            if new_state.worker_logo:
                                job["logo_path"] = new_state.worker_logo
                        except Exception:
                            pass
                        job["status"] = "reserved"
                        job["worker"] = self._display_worker_label(wid, acc)
                        job["note"] = f"Failover từ {self._display_tk_label(failed_acc)} • logo: {Path(getattr(new_state, 'worker_logo', '') or '').name or '-'} • {cause_text}"
                    launch.append((new_state, jobs))

            if launch:
                self.ui_queue.put(("jobs_refresh",))
                self.ui_queue.put(("stats",))
                self.ui_queue.put(("worker_row", state.worker_id, failed_acc, "✖ Đã chuyển", "Đã nhả job", f"{state.ok+state.err+state.skip}/{state.total}", state.current, cause_text))
                reason_labels = {
                    "quota": "Gemini xác nhận hết quota sau Send",
                    "session": "lỗi phiên/login",
                    "verify": "bị Google yêu cầu xác minh",
                    "refusal": "bị Gemini từ chối",
                    "account_error": "lỗi account/worker",
                }
                self.ui_queue.put(("log", f"[manager] A{failed_acc} {reason_labels.get(issue_kind, issue_kind)} • chuyển {len(remaining)} job sang {len(launch)} tài khoản rảnh: " + ", ".join(f"A{s.account_no}" for s, _ in launch)))
                self._mark_accounts_selected([s.account_no for s, _ in launch])

                for new_state, jobs in launch:
                    _q = getattr(new_state, "queue_index", None)
                    _qtxt = f"Q{int(_q)+1}" if _q is not None and str(_q).lstrip('-').isdigit() else "NoQ"
                    self.ui_queue.put(("worker_row", new_state.worker_id, new_state.account_no, "🚀 Khởi động", f"Nhận {len(jobs)} job failover • {_qtxt}", f"0/{len(jobs)}", "-", "-"))
                    self.ui_queue.put(("log", f"[queue-logo] failover W{new_state.worker_id}/A{new_state.account_no} • {_qtxt} • logo={getattr(new_state, 'worker_logo', '')}"))
                    threading.Thread(target=self._launch_worker, args=(new_state, getattr(new_state, "worker_root", root_folder), getattr(new_state, "worker_logo", logo), workers_root), daemon=True).start()
                return True

        if remaining:
            self.ui_queue.put(("log", f"[manager] chưa có tài khoản rảnh để tiếp quản W{state.worker_id} • {len(remaining)} job đã về hàng đợi, sẽ tự chạy khi tài khoản đang bận xong"))
        state.phase = "Chờ tài khoản rảnh" if remaining else state.phase
        state.last_error = cause_text
        self.ui_queue.put(("worker_row", state.worker_id, failed_acc, "⏸ Chờ TK", state.phase, f"{state.ok+state.err+state.skip}/{state.total}", state.current, state.last_error))
        self._schedule_queued_jobs()
        return False

    def _schedule_queued_jobs(self):
        if getattr(self, "stop_requested", False) or getattr(self, "_closing_now", False):
            return
        if not self.running or not self.current_workers_root:
            return
        # v12.58: trước khi tính slot, dọn account/job bị kẹt từ worker đã xong.
        self._cleanup_finished_worker_accounts()
        self._cleanup_stale_reserved_jobs()
        with self.schedule_lock:
            configured = self._configured_accounts()
            with self.run_lock:
                live_workers = self._active_live_worker_count()
                max_workers = max(1, int(getattr(self, "current_requested_workers_count", 1) or 1))
                free_worker_slots = max(0, max_workers - live_workers)
                busy_accounts = set(self.active_accounts) | self._active_worker_accounts()
                # Đồng bộ lại active_accounts để mọi nhánh failover/scheduler cùng thấy account đang dùng.
                self.active_accounts.update(busy_accounts)
                available = [a for a in configured if a not in busy_accounts and a not in self.exhausted_accounts and self._account_cooldown_remaining(a) <= 0]
                available = self._sorted_candidate_accounts(available)
                cooling_accounts = [(a, self._account_cooldown_remaining(a)) for a in configured if a not in busy_accounts and a not in self.exhausted_accounts and self._account_cooldown_remaining(a) > 0]
                queued_all = [j for j in self.jobs if j.get("status") == "queued"]
                queued = self._filter_runnable_for_queue_priority(queued_all)
                if queued_all and not queued:
                    queued = []
                if free_worker_slots <= 0:
                    # v12.54: hard cap đúng số luồng người dùng chọn, không sinh W6/W7... khi đang đủ 5 luồng.
                    if queued_all:
                        self.ui_queue.put(("log", f"[scheduler] giữ đúng {max_workers} luồng • còn {len(queued_all)} job chờ, đợi worker rảnh rồi chạy tiếp"))
                        self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                    return
                # v134.8: nếu không còn job queued nhưng có tài khoản rảnh,
                # tài khoản đó sẽ nhận bớt job CHƯA CHẠY/reserved từ worker khác còn bận.
                if available and not queued and free_worker_slots > 0:
                    if self._steal_work_for_available_accounts(available[:free_worker_slots]):
                        return
                if not available or not queued:
                    # v68: nếu không còn worker sống thì không giữ trạng thái "Đang chạy" bị kẹt.
                    if self._active_live_worker_count() <= 0:
                        if not queued and not any(j.get("status") in ("queued", "reserved", "running") for j in self.jobs):
                            failed_jobs = [j for j in self.jobs if j.get("status") == "error"]
                            if failed_jobs and getattr(self, "auto_rerun_failed_enabled", True) and not getattr(self, "stop_requested", False):
                                next_round = int(getattr(self, "auto_rerun_round", 0) or 0) + 1
                                self.running = False
                                self._release_chrome_background_guard(grace=3.0)
                                self._save_run_manifest(force=True)
                                self.ui_queue.put(("log", f"[manager] vòng hiện tại xong • còn {len(failed_jobs)} job lỗi • đưa lại vào hàng chờ vòng {next_round}"))
                                self.ui_queue.put(("status", f"Tự chạy lại {len(failed_jobs)} lỗi • vòng {next_round}"))
                                self.ui_queue.put(("auto_rerun_failed", next_round, len(failed_jobs)))
                                self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                            else:
                                self.running = False
                                try:
                                    deleted_profiles = self.prune_old_profile_dirs(keep=PROFILE_HISTORY_KEEP)
                                    if deleted_profiles:
                                        self.ui_queue.put(("log", f"[profiles] sau khi run kết thúc giữ {PROFILE_HISTORY_KEEP} profile mới nhất • xoá {deleted_profiles}"))
                                except Exception as _pe:
                                    self.ui_queue.put(("log", f"[profiles] cleanup cuối run lỗi nhẹ: {_pe}"))
                                self._release_chrome_background_guard(grace=5.0)
                                self._save_run_manifest(force=True)
                                if failed_jobs:
                                    self.ui_queue.put(("log", f"[manager] dừng auto-rerun sau {self.auto_rerun_round} vòng • còn {len(failed_jobs)} job lỗi"))
                                    self.ui_queue.put(("status", f"Còn {len(failed_jobs)} job lỗi sau {self.auto_rerun_round} vòng auto-rerun"))
                                else:
                                    self.ui_queue.put(("log", "[manager] HOÀN TẤT TOÀN BỘ"))
                                    self.ui_queue.put(("status", "Hoàn tất toàn bộ"))
                                    self.ui_queue.put(("finish_show_all",))
                                self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                        elif queued and not available:
                            if cooling_accounts:
                                soonest = min(rem for _a, rem in cooling_accounts)
                                who = ", ".join(f"A{a}:{int(rem)}s" for a, rem in sorted(cooling_accounts, key=lambda x: x[1])[:3])
                                self.ui_queue.put(("log", f"[scheduler] còn {len(queued)} job chờ • đang chờ cooldown tài khoản: {who}"))
                                self.ui_queue.put(("status", f"Chờ cooldown tài khoản • còn {len(queued)} job"))
                                self._schedule_after_cooldown_check(max(1.0, min(30.0, soonest + 0.5)))
                                self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                            else:
                                self.running = False
                                self.active_accounts = set()
                                self._release_chrome_background_guard(grace=5.0)
                                self.ui_queue.put(("log", f"[manager] tạm dừng: còn {len(queued)} job chờ nhưng không còn tài khoản rảnh"))
                                self.ui_queue.put(("status", f"Tạm dừng • còn {len(queued)} job chờ • cần tài khoản rảnh"))
                                self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))
                    return
                slots = min(len(available), len(queued), free_worker_slots)
                bucket_records = self._bucket_jobs_for_queue_workers(queued, slots)
                self.next_runtime_worker_id = max(self.next_runtime_worker_id, max([w.worker_id for w in self.workers] + [0]) + 1)
                launch = []
                for idx, acc in enumerate(available[:slots]):
                    bucket = bucket_records[idx] if idx < len(bucket_records) else {}
                    jobs = [j for j in (bucket.get("jobs") or []) if self._job_can_run_on_account(j, acc)]
                    if not jobs: continue
                    wid = self.next_runtime_worker_id; self.next_runtime_worker_id += 1
                    state = WorkerState(wid, acc, jobs); state.account_map = [acc]; state.account_no = acc
                    state.queue_index = bucket.get("queue_index")
                    state.worker_root = normalize_path(bucket.get("root") or self.current_root_folder)
                    state.worker_logo = normalize_path(bucket.get("logo") or self.current_logo_path)
                    self.workers.append(state); self.active_accounts.add(acc)
                    for job in jobs:
                        job["status"] = "reserved"; job["worker"] = self._display_worker_label(wid, acc); job["note"] = f"Requeue • chờ {self._display_tk_label(acc)}"
                    launch.append((state, jobs))
            if queued and free_worker_slots > 0 and not launch:
                self.ui_queue.put(("log", f"[dispatch-fix] scheduler thấy {len(queued)} job Chờ + {free_worker_slots} slot nhưng chưa chia được bucket/account; sẽ thử lại tick sau"))
            for state, jobs in launch:
                self.ui_queue.put(("log", f"[manager] smart-requeue: chuyển {len(jobs)} job sang W{state.worker_id}/A{state.account_no}"))
                self.ui_queue.put(("worker_row", state.worker_id, state.account_no, "🚀 Khởi động", "Requeue", f"0/{len(jobs)}", "-", "-"))
                threading.Thread(target=self._launch_worker, args=(state, getattr(state, "worker_root", self.current_root_folder), getattr(state, "worker_logo", self.current_logo_path), self.current_workers_root), daemon=True).start()
            if launch:
                self._mark_accounts_selected([state.account_no for state, _jobs in launch])
            self.ui_queue.put(("jobs_refresh",)); self.ui_queue.put(("stats",))

    # ---------- UI queue drain ----------
    def _display_tk_label(self, account_no):
        try:
            actual = int(account_no)
        except Exception:
            actual = account_no
        try:
            for idx, row in enumerate(getattr(self, "rows", []) or [], start=1):
                try:
                    if int(row.account_no()) == int(actual):
                        return f"TK{idx}"
                except Exception:
                    pass
        except Exception:
            pass
        return f"TK{actual}"

    def _display_worker_label(self, wid, account_no):
        return f"W{wid}/{self._display_tk_label(account_no)}"

    def _purge_pending_ui_events(self):
        n = 0
        try:
            while True:
                self.ui_queue.get_nowait()
                n += 1
        except queue.Empty:
            pass
        except Exception:
            pass
        return n

    def _reset_runtime_view(self, keep_jobs=True):
        try:
            if self.worker_tree is not None:
                self.worker_tree.clear()
            self._worker_items.clear(); self._last_worker_values.clear(); self._clear_worker_cards()
        except Exception:
            pass
        try:
            self.track_top.setText("Sẵn sàng")
            self.track_chip_workers.setText("Worker: 0")
            self.track_chip_running.setText("Đang chạy: 0")
            self.track_chip_done.setText("Xong: 0")
            self.track_chip_error.setText("Lỗi: 0")
        except Exception:
            pass
        if not keep_jobs:
            try:
                self.jobs = []
                self.preview.clear()
                self._thumb_cache.clear()
            except Exception:
                pass
        try:
            self._update_runtime_label()
        except Exception:
            pass

    def _clear_worker_cards(self):
        try:
            if hasattr(self, "worker_cards_layout"):
                while self.worker_cards_layout.count() > 0:
                    item = self.worker_cards_layout.takeAt(0)
                    w = item.widget()
                    if w is not None:
                        w.setParent(None)
                        w.deleteLater()
                self.worker_cards_layout.addStretch(1)
        except Exception:
            pass
        try:
            self._worker_cards.clear()
        except Exception:
            self._worker_cards = {}

    def _parse_progress_pair(self, prog):
        try:
            m = re.search(r"(\d+)\s*/\s*(\d+)", str(prog or ""))
            if m:
                return int(m.group(1)), max(1, int(m.group(2)))
        except Exception:
            pass
        return 0, 1

    def _make_worker_card(self, wid):
        card = QFrame()
        card.setObjectName("WorkerCard")
        card.setMinimumHeight(82)
        card.setMaximumHeight(96)
        lay = QVBoxLayout(card)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.setSpacing(4)

        top = QHBoxLayout(); top.setContentsMargins(0, 0, 0, 0); top.setSpacing(5)
        title = QLabel(f"W{wid}"); title.setObjectName("WorkerCardTitle")
        tk = QLabel("TK-"); tk.setObjectName("WorkerStatusBadge")
        status = QLabel("Sẵn sàng"); status.setObjectName("WorkerStatusBadge")
        top.addWidget(title, 0)
        top.addWidget(tk, 0)
        top.addWidget(status, 1)
        lay.addLayout(top)

        progress_row = QHBoxLayout(); progress_row.setContentsMargins(0, 0, 0, 0); progress_row.setSpacing(6)
        bar = QProgressBar(); bar.setMinimum(0); bar.setMaximum(1); bar.setValue(0); bar.setTextVisible(False)
        percent = QLabel("0/0"); percent.setObjectName("WorkerCardSub"); percent.setFixedWidth(45)
        progress_row.addWidget(bar, 1); progress_row.addWidget(percent, 0)
        lay.addLayout(progress_row)

        phase = QLabel("Pha: -"); phase.setObjectName("WorkerCardSub")
        file_lb = QLabel("File: -"); file_lb.setObjectName("WorkerCardSub")
        file_lb.setToolTip("-")
        lay.addWidget(phase)
        lay.addWidget(file_lb)

        data = {"card": card, "title": title, "tk": tk, "status": status, "bar": bar, "percent": percent, "phase": phase, "file": file_lb}
        try:
            idx = max(0, self.worker_cards_layout.count() - 1)
            self.worker_cards_layout.insertWidget(idx, card)
        except Exception:
            pass
        self._worker_cards[wid] = data
        return data

    def _upsert_worker_row(self, wid, acc, st, ph, prog, cur, err):
        file_text = str(cur or "-")
        full_file_text = file_text
        if len(file_text) > 34:
            file_text = file_text[:31] + "..."
        tk_text = self._display_tk_label(acc)
        vals = [f"W{wid}", tk_text, str(st or "-"), str(ph or "-"), str(prog or "0/0"), file_text, str(err or "-")]
        prev = self._last_worker_values.get(wid)
        if prev == vals:
            return
        self._last_worker_values[wid] = vals
        card = self._worker_cards.get(wid)
        if card is None:
            card = self._make_worker_card(wid)
        done, total = self._parse_progress_pair(prog)
        try:
            card["title"].setText(f"W{wid}")
            card["tk"].setText(tk_text)
            card["tk"].setToolTip(f"Profile thật: google_{acc}")
            card["status"].setText(str(st or "-"))
            card["status"].setToolTip(str(err or st or "-"))
            card["bar"].setMaximum(max(1, total))
            card["bar"].setValue(max(0, min(done, total)))
            card["percent"].setText(str(prog or f"{done}/{total}"))
            card["phase"].setText(f"Pha: {ph or '-'}")
            card["phase"].setToolTip(str(ph or "-"))
            card["file"].setText(f"File: {file_text}")
            card["file"].setToolTip(f"File: {full_file_text}\nLỗi: {err or '-'}\nPha: {ph or '-'}")
        except Exception:
            pass

    def _drain(self):
        preview_needed = False; stats_needed = False; logs = []; worker_rows = {}; processed = 0; start = time.perf_counter()
        while processed < UI_DRAIN_MAX_EVENTS and (time.perf_counter() - start) < UI_DRAIN_MAX_SECONDS:
            try:
                ev = self.ui_queue.get_nowait()
            except queue.Empty:
                break
            processed += 1
            try:
                typ = ev[0]
                if typ == "log": logs.append(ev[1])
                elif typ == "status": self.status_label.setText(str(ev[1]))
                elif typ == "proxy_status":
                    try:
                        self._set_proxy_compact_text(str(ev[1]))
                    except Exception:
                        pass
                elif typ == "proxy_check_done":
                    _typ, ok, results, auto_start, duplicate_ip = ev
                    self._proxy_check_in_progress = False
                    self._proxy_last_results = results or []
                    try:
                        self.btn_start.setEnabled(True)
                    except Exception:
                        pass

                    # v5.2: Proxy Pool. Dùng TẤT CẢ proxy live trong file, không chỉ proxy khớp account.
                    usable_results = []
                    bad = []
                    duplicate_notes = []
                    seen_ips = set()
                    def _acc_sort_key(x):
                        try: return int(x.get("acc") or 999999)
                        except Exception: return 999999
                    for r in sorted((results or []), key=_acc_sort_key):
                        label = f"A{r.get('acc')}" if r.get('acc') is not None else str(r.get('key') or '?')
                        if not r.get("ok"):
                            bad.append(f"{label}: {r.get('msg') or 'proxy lỗi'}")
                            continue
                        ip = (r.get("ip") or "").strip()
                        if ip and ip in seen_ips:
                            duplicate_notes.append(f"{label}: trùng IP {ip} nhưng vẫn cho vào pool Gemini/Flow nếu cần")
                        if ip:
                            seen_ips.add(ip)
                        usable_results.append(r)
                    self._proxy_approved_proxy_values = [r.get("proxy_value") for r in usable_results if r.get("proxy_value")]
                    self._proxy_approved_accounts = []  # v5.2 không còn khóa proxy theo account_N
                    self._proxy_has_config_for_run = True

                    summary = self._format_proxy_check_summary(results or [])
                    if usable_results:
                        summary += f"\n▶ Proxy pool live: {len(usable_results)}/{len(results or [])}"
                        if duplicate_notes:
                            summary += "\n⚠ Có IP trùng, vẫn dùng nếu cần tốc độ"
                    try:
                        self._set_proxy_compact_text(summary)
                    except Exception:
                        pass

                    if usable_results:
                        logs.append(f"[proxy-pool] OK • {len(usable_results)}/{len(results or [])} proxy live trong file")
                        if bad:
                            logs.append("[proxy-pool] proxy lỗi: " + "; ".join(bad[:8]))
                        if duplicate_notes:
                            logs.append("[proxy-pool] cảnh báo IP trùng: " + "; ".join(duplicate_notes[:5]))
                        self.status_label.setText(f"Proxy pool OK {len(usable_results)}/{len(results or [])} • bắt đầu chạy")
                        if auto_start:
                            logs.append("[proxy-check] check xong -> tự bắt đầu vẽ: gắn proxy live vào account, thiếu thì Gemini không proxy")
                            QTimer.singleShot(150, self._start_run_core)
                    else:
                        logs.append("[proxy-pool] không có proxy live • vẫn chạy Gemini không proxy, bỏ Flow")
                        if bad:
                            logs.append("[proxy-pool] proxy lỗi: " + "; ".join(bad[:8]))
                        self.status_label.setText("Không có proxy live • chạy Gemini không proxy")
                        if auto_start:
                            QTimer.singleShot(150, self._start_run_core)
                elif typ == "account_status":
                    _, rid, ok, msg, email = ev
                    for r in self.rows:
                        if r.row_id == rid:
                            r.set_status(ok, msg, email); break
                elif typ == "worker_row": worker_rows[ev[1]] = ev
                elif typ == "jobs_refresh": preview_needed = True
                elif typ == "finish_show_all":
                    self._show_all_jobs_after_finish("worker-summary-complete")
                    preview_needed = False
                    stats_needed = False
                elif typ == "stats": stats_needed = True
                elif typ == "auto_rerun_failed":
                    round_no = int(ev[1]) if len(ev) > 1 else int(getattr(self, 'auto_rerun_round', 0) or 0) + 1
                    count = int(ev[2]) if len(ev) > 2 else len([j for j in self.jobs if j.get('status') == 'error'])
                    self.status_label.setText(f"Tự chạy lại {count} lỗi • vòng {round_no} • đến khi xong")
                    logs.append(f"[auto-rerun] lên lịch vòng {round_no}: {count} job lỗi")
                    QTimer.singleShot(1000, lambda rn=round_no: self._auto_rerun_failed_now(rn))
                elif typ == "desc_progress":
                    try:
                        if len(ev) > 1 and isinstance(ev[1], dict):
                            self.desc_stats = dict(ev[1])
                        if len(ev) > 2:
                            self.desc_last_message = str(ev[2])
                        self._refresh_project_queue_ui()
                        self._refresh_description_workspace()
                    except Exception:
                        pass
                elif typ == "desc_done_all":
                    try:
                        if len(ev) > 1 and isinstance(ev[1], dict):
                            self.desc_stats = dict(ev[1])
                        if len(ev) > 2:
                            self.desc_last_message = str(ev[2])
                        self.desc_running = False
                        self._desc_profile_prune_guard = False
                        self._refresh_project_queue_ui()
                        self._refresh_description_workspace()
                        ds = getattr(self, "desc_stats", {}) or {}
                        final_msg = str(ev[2]) if len(ev) > 2 else ""
                        if int(ds.get("error", 0) or 0) > 0 and not (final_msg.startswith("Khôi phục") or final_msg.startswith("Dịch")):
                            selected_errors = self._description_check_error_jobs(focus_first=True)
                            logs.append(f"[desc] còn {selected_errors} lỗi • đã tự tích chọn trong bảng")
                        if final_msg.startswith("Khôi phục") or final_msg.startswith("Dịch") or final_msg.startswith("Đã dừng dịch"):
                            self.status_label.setText(final_msg)
                        else:
                            self.status_label.setText(f"Sửa mô tả xong • {ds.get('done',0)}/{ds.get('total',0)} • lỗi {ds.get('error',0)}")
                    except Exception:
                        self.desc_running = False
                        self._desc_profile_prune_guard = False
                elif typ == "desc_error_all":
                    try:
                        self.desc_running = False
                        self._desc_profile_prune_guard = False
                        self.desc_last_message = str(ev[1]) if len(ev) > 1 else "Sửa mô tả lỗi"
                        self._refresh_project_queue_ui()
                        self._refresh_description_workspace()
                        self.status_label.setText("Sửa mô tả lỗi")
                    except Exception:
                        pass
                elif typ == "queue_scan_done":
                    self._scan_running = False
                    jobs = ev[1] if len(ev) > 1 else []
                    skipped = int(ev[2] if len(ev) > 2 else 0)
                    parent_count = int(ev[3] if len(ev) > 3 else len({str(j.get("direct_parent_root") or j.get("parent_root") or "") for j in jobs if j.get("image_path")}))
                    try: self.btn_queue_scan.setEnabled(True)
                    except Exception: pass
                    try: self.btn_scan.setEnabled(True)
                    except Exception: pass
                    self.jobs = list(jobs or [])
                    self._finish_show_all_done = False
                    try:
                        self.stat_cards["total"].set_value(len(self.jobs))
                        self.stat_cards["skip"].set_value(skipped)
                    except Exception: pass
                    try:
                        if hasattr(self, "job_filter_combo"):
                            self.job_filter_combo.blockSignals(True)
                            self.job_filter_combo.setCurrentText("Tất cả")
                            self.job_filter_combo.blockSignals(False)
                    except Exception:
                        pass
                    self._sync_project_queue_stats_from_jobs()
                    self.refresh_stats()
                    self.request_preview_refresh(force=False)
                    self.status_label.setText(f"Quét queue xong • {len(self.jobs)} job • bỏ qua {skipped}")
                    logs.append(f"[queue] quét toàn bộ queue xong • thư mục cha {parent_count} • tổng {len(self.jobs)} • bỏ qua {skipped} • đã hiện job để kiểm tra")
                    self.schedule_save_state()
                    if getattr(self, "_queue_autostarting", False):
                        self._queue_autostarting = False
                        logs.append("[queue] quét xong -> tự chạy Smart Queue")
                        QTimer.singleShot(250, self.start_project_queue)
                elif typ == "queue_scan_error":
                    self._scan_running = False
                    try: self.btn_queue_scan.setEnabled(True)
                    except Exception: pass
                    try: self.btn_scan.setEnabled(True)
                    except Exception: pass
                    self.status_label.setText("Quét queue lỗi")
                    logs.append("[queue] scan lỗi: " + str(ev[1]))
                elif typ == "scan_done":
                    jobs, skipped = ev[1], ev[2]
                    parent_count = ev[3] if len(ev) > 3 else len({str(j.get("direct_parent_root") or j.get("parent_root") or "") for j in jobs if j.get("image_path")})
                    self.jobs = jobs
                    self._finish_show_all_done = False
                    self.stat_cards["total"].set_value(len(self.jobs))
                    self.stat_cards["skip"].set_value(skipped)
                    # v2.5: Sau khi bấm Quét file phải hiện đầy đủ cả Chờ/Xong/Bỏ qua để kiểm tra.
                    # Chỉ khi bấm Bắt đầu mới tự chuyển sang lọc Chờ để không dựng card bỏ qua.
                    try:
                        if hasattr(self, "job_filter_combo"):
                            self.job_filter_combo.blockSignals(True)
                            self.job_filter_combo.setCurrentText("Tất cả")
                            self.job_filter_combo.blockSignals(False)
                    except Exception:
                        pass
                    self.refresh_stats()
                    self.request_preview_refresh(force=False)
                    self.status_label.setText(f"Quét xong • {parent_count} thư mục cha • chạy {len(self.jobs)} • bỏ qua {skipped}")
                    logs.append(f"[scan] quét xong • thư mục cha {parent_count} • tổng {len(self.jobs)} • bỏ qua {skipped} • đã hiện đủ file để kiểm tra")
                    self._scan_running = False
                    try:
                        self.btn_scan.setEnabled(True)
                    except Exception:
                        pass
                elif typ == "scan_error":
                    self._scan_running = False
                    try:
                        self.btn_scan.setEnabled(True)
                    except Exception:
                        pass
                    self.status_label.setText("Quét file lỗi")
                    logs.append("[scan] ERROR • " + str(ev[1]))
            except Exception as e:
                logs.append(f"[ui] lỗi xử lý event: {e}")
        if worker_rows:
            for wid, ev in sorted(worker_rows.items()):
                _, wid, acc, st, ph, prog, cur, err = ev
                self._upsert_worker_row(wid, acc, st, ph, prog, cur, err)
        if logs:
            self.append_logs(logs)
        if stats_needed:
            self.refresh_stats()
        if preview_needed:
            self.request_preview_refresh(force=False)
        # schedule next interval
        self.drain_timer.start(UI_DRAIN_FAST_MS if not self.ui_queue.empty() else UI_DRAIN_NORMAL_MS)

    def resizeEvent(self, event):
        try:
            super().resizeEvent(event)
        finally:
            try:
                viewport_w = int(self.preview.viewport().width() or self.preview.width() or 0)
                if abs(viewport_w - int(getattr(self, "_last_preview_viewport_width", 0) or 0)) >= 18:
                    self.request_preview_refresh(force=False)
            except Exception:
                pass

    def safe_exit_tool(self):
        # v11.9: giữ hàm cho tương thích nội bộ, nhưng không còn nút trên UI.
        self.close()

    def closeEvent(self, event):
        # v11.9: bỏ No Quit Guard/ép closeEvent. Đóng tool theo cơ chế Qt bình thường.
        try:
            self._closing_now = True
            self.stop_requested = True
            self._check_stop_event.set()
        except Exception:
            pass
        try:
            self._chrome_guard_stop.set()
        except Exception:
            pass
        try:
            self._channel_brand_stop_event.set()
        except Exception:
            pass
        try:
            self._channel_brand_close_name_session()
        except Exception:
            pass
        try:
            self.save_state()
        except Exception:
            pass
        try:
            self.stop_all(silent=True)
            self._cleanup_leftover_worker_processes(timeout=0.8)
        except Exception:
            pass
        event.accept()


def main():
    _exit_trace("main() entered", stack=True)
    _hide_own_console_window()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_TITLE)
    win = QtDashboard()
    try:
        app.aboutToQuit.connect(lambda: _exit_trace("QApplication.aboutToQuit", stack=True, win=win))
    except Exception as e:
        _exit_trace("failed to connect aboutToQuit", extra=e)
    try:
        app.lastWindowClosed.connect(lambda: _exit_trace("QApplication.lastWindowClosed", stack=True, win=win))
    except Exception as e:
        _exit_trace("failed to connect lastWindowClosed", extra=e)
    try:
        win.destroyed.connect(lambda *args: _exit_trace("QtDashboard.destroyed signal", stack=True, extra=args))
    except Exception as e:
        _exit_trace("failed to connect win.destroyed", extra=e)
    try:
        heartbeat = QTimer()
        heartbeat.setInterval(15000)
        heartbeat.timeout.connect(lambda: _exit_trace("heartbeat", stack=False, win=win))
        heartbeat.start()
        win._exit_trace_heartbeat = heartbeat
    except Exception as e:
        _exit_trace("failed to start heartbeat", extra=e)
    win.show()
    _exit_trace("main window shown; entering app.exec()", stack=False, win=win)
    rc = app.exec()
    _exit_trace(f"app.exec() returned rc={rc}", stack=True, win=win)
    return rc


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit as _se:
        try:
            _exit_trace(f"SystemExit raised code={getattr(_se, 'code', None)!r}", stack=True)
        except Exception:
            pass
        raise
    except BaseException as e:
        try:
            import traceback
            crash_path = Path(__file__).resolve().parent / ("fatal_crash_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt")
            crash_path.write_text("".join(traceback.format_exception(type(e), e, e.__traceback__)), encoding="utf-8")
            print("FATAL CRASH saved:", crash_path)
        except Exception:
            pass
        raise
