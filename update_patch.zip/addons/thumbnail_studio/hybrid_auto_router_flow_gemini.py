# -*- coding: utf-8 -*-
r"""
Hybrid Auto Router v4.3: Safe Proxy Lane, no duplicate account/proxy, abnormal fast fallback.

- Flow chạy trước để tận dụng tốc độ.
- Nếu Flow lỗi policy/prompt/ảnh, ảnh chưa DONE chuyển sang Gemini fallback.
- Gemini fallback lặp lại các ảnh lỗi/chưa xong cho tới khi DONE/SKIPPED hoặc người dùng bấm Dừng.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
import random
from pathlib import Path

EVENT_MARKER = "__GEMINI_EVENT__"
THUMB_RE = re.compile(r"^thumbnail-original-(\d+)-final\.(png|jpg|jpeg|webp)$", re.I)


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def emit_event(event_type, **payload):
    try:
        data = {"type": str(event_type), "ts": time.time(), **payload}
        print(EVENT_MARKER + json.dumps(data, ensure_ascii=False, separators=(",", ":")), flush=True)
    except Exception:
        pass


def parse_args():
    p = argparse.ArgumentParser(description="Hybrid Flow + Gemini backend worker")
    p.add_argument("--root", default=os.environ.get("GEMINI_ROOT", ""))
    p.add_argument("--logo", default=os.environ.get("GEMINI_LOGO", ""))
    p.add_argument("--num-accounts", type=int, default=int(os.environ.get("GEMINI_NUM_ACCOUNTS", "0") or 0))
    p.add_argument("--chrome-binary", default=os.environ.get("GEMINI_CHROME_BINARY", ""))
    p.add_argument("--driver-path", default=os.environ.get("GEMINI_DRIVER_PATH", ""))
    p.add_argument("--proxy-config", default=os.environ.get("HYBRID_PROXY_CONFIG", ""))
    p.add_argument("--account-modes", default=os.environ.get("GEMINI_ACCOUNT_MODES", ""))
    p.add_argument("--manifest", default=os.environ.get("GEMINI_JOB_MANIFEST", ""))
    p.add_argument("--events", default=os.environ.get("GEMINI_EVENTS", "1"))
    p.add_argument("--final-min-mb", type=float, default=float(os.environ.get("GEMINI_FINAL_MIN_MB", "2.05") or 2.05))
    p.add_argument("--input-skip-over-mb", type=float, default=float(os.environ.get("GEMINI_INPUT_SKIP_OVER_MB", "1.5") or 1.5))
    p.add_argument("--headless-regular", default=os.environ.get("GEMINI_HEADLESS_REGULAR", ""))
    p.add_argument("--headless-pro", default=os.environ.get("GEMINI_HEADLESS_PRO", ""))
    p.add_argument("--hide-style", default=os.environ.get("GEMINI_HIDE_STYLE", "offscreen"))
    p.add_argument("--validate-min-width", type=int, default=int(os.environ.get("GEMINI_VALIDATE_MIN_WIDTH", "1280") or 1280))
    p.add_argument("--validate-min-height", type=int, default=int(os.environ.get("GEMINI_VALIDATE_MIN_HEIGHT", "720") or 720))
    p.add_argument("--validate-aspect-epsilon", type=float, default=float(os.environ.get("GEMINI_VALIDATE_ASPECT_EPS", "0.025") or 0.025))
    p.add_argument("--max-job-retries", type=int, default=int(os.environ.get("GEMINI_MAX_JOB_RETRIES", "0") or 0))
    p.add_argument("--flow-folder-retries", type=int, default=int(os.environ.get("FLOW_FOLDER_RETRIES", "0") or 0))
    p.add_argument("--flow-card-retries", type=int, default=int(os.environ.get("FLOW_CARD_RETRIES", "0") or 0))
    p.add_argument("--flow-safe-delay-min", type=float, default=float(os.environ.get("FLOW_SAFE_DELAY_MIN", "0") or 0))
    p.add_argument("--flow-safe-delay-max", type=float, default=float(os.environ.get("FLOW_SAFE_DELAY_MAX", "0") or 0))
    p.add_argument("--result-stable-seconds", type=float, default=float(os.environ.get("GEMINI_RESULT_STABLE_SECONDS", "0.8") or 0.8))
    p.add_argument("--result-stable-rounds", default=os.environ.get("GEMINI_RESULT_STABLE_ROUNDS", "1"))
    p.add_argument("--auto-upscale-final", default=os.environ.get("GEMINI_AUTO_UPSCALE_FINAL", "1"))
    p.add_argument("--no-hash-validate", action="store_true")
    # Flow-only
    p.add_argument("--flow-url", default=os.environ.get("FLOW_URL", "https://labs.google/fx/vi/tools/flow"))
    p.add_argument("--prompt", default=os.environ.get("FLOW_PROMPT", ""))
    p.add_argument("--create-new-project", default=os.environ.get("FLOW_CREATE_NEW_PROJECT", "1"))
    p.add_argument("--results-per-round", type=int, default=int(os.environ.get("FLOW_RESULTS_PER_ROUND", "4") or 4))
    p.add_argument("--download-timeout", type=int, default=int(os.environ.get("FLOW_DOWNLOAD_TIMEOUT", "90") or 90))
    p.add_argument("--flow-max-consecutive-folder-errors", type=int, default=int(os.environ.get("FLOW_MAX_CONSECUTIVE_FOLDER_ERRORS", "1") or 1))
    # Hybrid repeat loop
    p.add_argument("--hybrid-max-fallback-rounds", type=int, default=int(os.environ.get("HYBRID_MAX_FALLBACK_ROUNDS", "999999") or 999999))
    p.add_argument("--hybrid-no-progress-sleep", type=float, default=float(os.environ.get("HYBRID_NO_PROGRESS_SLEEP", "5") or 5))
    # v3.5 Hybrid Pipeline: chỉ cho 1 Flow lane chạy cùng lúc, các worker còn lại đợi/đẩy Gemini.
    p.add_argument("--hybrid-flow-lanes", type=int, default=int(os.environ.get("HYBRID_FLOW_LANES", "1") or 1))
    p.add_argument("--hybrid-flow-lane-wait-timeout", type=float, default=float(os.environ.get("HYBRID_FLOW_LANE_WAIT_TIMEOUT", "3") or 3))
    p.add_argument("--hybrid-flow-lock-stale-seconds", type=float, default=float(os.environ.get("HYBRID_FLOW_LOCK_STALE_SECONDS", "900") or 900))
    p.add_argument("--hybrid-flow-cooldown-seconds", type=float, default=float(os.environ.get("HYBRID_FLOW_COOLDOWN_SECONDS", "90") or 90))
    p.add_argument("--hybrid-flow-start-jitter-min", type=float, default=float(os.environ.get("HYBRID_FLOW_START_JITTER_MIN", "0") or 0))
    p.add_argument("--hybrid-flow-start-jitter-max", type=float, default=float(os.environ.get("HYBRID_FLOW_START_JITTER_MAX", "0") or 0))
    p.add_argument("--hybrid-pipeline-dir", default=os.environ.get("HYBRID_PIPELINE_DIR", ""),
                   help="Thư mục run chung để các worker share Flow lane lock/cooldown")
    p.add_argument("--hybrid-skip-flow", default=os.environ.get("HYBRID_SKIP_FLOW", "0"),
                   help="1 = bỏ Flow, chạy Gemini fallback/fill trực tiếp. Dùng cho worker không có proxy OK")
    args, unknown = p.parse_known_args()
    if unknown:
        print("ℹ Hybrid bỏ qua tham số không dùng:", " ".join(map(str, unknown)), flush=True)
    return args


def add_arg(cmd, name, value, allow_empty=False):
    if value is None:
        return
    if not allow_empty and str(value) == "":
        return
    cmd.extend([name, str(value)])


def common_args(args, for_gemini=False):
    cmd = []
    add_arg(cmd, "--root", args.root)
    add_arg(cmd, "--logo", args.logo)
    add_arg(cmd, "--num-accounts", args.num_accounts)
    add_arg(cmd, "--chrome-binary", args.chrome_binary)
    add_arg(cmd, "--driver-path", args.driver_path)
    add_arg(cmd, "--proxy-config", args.proxy_config)
    add_arg(cmd, "--account-modes", args.account_modes)
    add_arg(cmd, "--manifest", args.manifest)
    add_arg(cmd, "--events", "1")
    add_arg(cmd, "--final-min-mb", args.final_min_mb)
    add_arg(cmd, "--input-skip-over-mb", args.input_skip_over_mb)
    add_arg(cmd, "--headless-regular", args.headless_regular)
    add_arg(cmd, "--headless-pro", args.headless_pro)
    hide = str(args.hide_style or "").strip().lower()
    if for_gemini and hide == "offscreen":
        hide = "hide"
    add_arg(cmd, "--hide-style", hide)
    add_arg(cmd, "--validate-min-width", args.validate_min_width)
    add_arg(cmd, "--validate-min-height", args.validate_min_height)
    add_arg(cmd, "--validate-aspect-epsilon", args.validate_aspect_epsilon)
    add_arg(cmd, "--max-job-retries", args.max_job_retries)
    add_arg(cmd, "--result-stable-rounds", args.result_stable_rounds)
    add_arg(cmd, "--result-stable-seconds", args.result_stable_seconds)
    add_arg(cmd, "--auto-upscale-final", args.auto_upscale_final)
    if args.no_hash_validate:
        cmd.append("--no-hash-validate")
    return cmd


def flow_args(args):
    cmd = common_args(args, for_gemini=False)
    add_arg(cmd, "--flow-url", args.flow_url)
    add_arg(cmd, "--prompt", args.prompt)
    add_arg(cmd, "--create-new-project", args.create_new_project)
    add_arg(cmd, "--results-per-round", args.results_per_round)
    add_arg(cmd, "--download-timeout", args.download_timeout)
    add_arg(cmd, "--flow-max-consecutive-folder-errors", args.flow_max_consecutive_folder_errors)
    add_arg(cmd, "--flow-folder-retries", args.flow_folder_retries)
    add_arg(cmd, "--flow-card-retries", args.flow_card_retries)
    add_arg(cmd, "--flow-safe-delay-min", args.flow_safe_delay_min)
    add_arg(cmd, "--flow-safe-delay-max", args.flow_safe_delay_max)
    return cmd


def gemini_args(args):
    # v5.4: Gemini chạy DIRECT / NO-PROXY.
    # Proxy chỉ dùng cho Flow lane. Trên máy phụ, proxy live nhưng chậm có thể làm Gemini sinh ảnh
    # không ổn định/no visible result candidate. Bỏ --proxy-config khỏi Gemini để không mất luồng.
    cmd = common_args(args, for_gemini=True)
    try:
        cleaned = []
        skip_next = False
        for item in cmd:
            if skip_next:
                skip_next = False
                continue
            if item == "--proxy-config":
                skip_next = True
                continue
            cleaned.append(item)
        cmd = cleaned
    except Exception:
        pass
    print("[gemini] direct/no-proxy mode: không dùng proxy-config cho Gemini fallback", flush=True)

    def set_or_replace(flag, value):
        for i, v in enumerate(cmd):
            if v == flag and i + 1 < len(cmd):
                cmd[i + 1] = str(value)
                return
        cmd.extend([flag, str(value)])

    try: retry = max(1, int(args.max_job_retries or 0))
    except Exception: retry = 1
    try: rounds = max(2, int(str(args.result_stable_rounds or 1)))
    except Exception: rounds = 2
    try: seconds = max(0.8, float(args.result_stable_seconds or 0.8))
    except Exception: seconds = 0.8
    set_or_replace("--max-job-retries", retry)
    set_or_replace("--result-stable-rounds", rounds)
    set_or_replace("--result-stable-seconds", seconds)
    return cmd


def manifest_key(path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(str(path))))
    except Exception:
        return str(path)


def load_manifest(path):
    try:
        if path and os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                data.setdefault("jobs", {})
                return data
    except Exception as e:
        print(f"⚠ Hybrid không đọc được manifest: {e}", flush=True)
    return {"version": 1, "created_at": _now(), "jobs": {}}


def scan_thumb_paths(root):
    root_p = Path(root)
    if not root_p.exists():
        return []
    skip_dirs = {"_debug", "outputs", "_flow_extra"}
    out = []
    for p in root_p.rglob("*"):
        if not p.is_file() or not THUMB_RE.match(p.name):
            continue
        if any(str(part).lower() in skip_dirs for part in p.parts):
            continue
        out.append(p)
    out.sort(key=lambda p: (str(p.parent).lower(), int(THUMB_RE.match(p.name).group(1)), p.name.lower()))
    return out


def status_for(path, manifest):
    try:
        return str((manifest.get("jobs", {}) or {}).get(manifest_key(path), {}).get("status") or "")
    except Exception:
        return ""


def unfinished_paths(root, manifest_path):
    data = load_manifest(manifest_path)
    paths = []
    for p in scan_thumb_paths(root):
        if status_for(p, data) not in ("done", "skipped"):
            paths.append(p)
    return paths, data


def count_statuses(root, manifest_path):
    data = load_manifest(manifest_path)
    counts = {"total": 0, "done": 0, "error": 0, "skipped": 0, "other": 0}
    for p in scan_thumb_paths(root):
        counts["total"] += 1
        st = status_for(p, data)
        if st == "done": counts["done"] += 1
        elif st == "error": counts["error"] += 1
        elif st == "skipped": counts["skipped"] += 1
        else: counts["other"] += 1
    return counts



def _pipeline_dir(args):
    """Thư mục dùng chung cho Flow lane lock/cooldown.
    v3.6 fix: trước đây mỗi worker dùng manifest riêng trong worker_home nên mỗi worker tự có lock riêng,
    khiến 4 worker vẫn START FLOW cùng lúc. Hàm này ép lock về run_dir chung.
    """
    try:
        custom = str(getattr(args, "hybrid_pipeline_dir", "") or "").strip()
        if custom:
            p = Path(custom).resolve()
            p.mkdir(parents=True, exist_ok=True)
            return p
    except Exception:
        pass
    # Tự dò run_x trong đường dẫn root/manifest nếu dashboard cũ chưa truyền --hybrid-pipeline-dir.
    for raw in (getattr(args, "root", ""), getattr(args, "manifest", "")):
        try:
            parts = Path(raw).resolve().parts
            for i, part in enumerate(parts):
                if str(part).lower() == "_simple_parallel_runs" and i + 1 < len(parts) and str(parts[i+1]).lower().startswith("run_"):
                    return Path(*parts[:i+2])
        except Exception:
            pass
    try:
        if args.manifest:
            return Path(args.manifest).resolve().parent
    except Exception:
        pass
    try:
        return Path(args.root).resolve().parent
    except Exception:
        return Path.cwd()


def _read_json_safe(path):
    try:
        if Path(path).is_file():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _write_json_atomic(path, data):
    try:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except Exception as e:
        print(f"⚠ Pipeline ghi state lỗi nhẹ: {e}", flush=True)


def _cooldown_remaining(args):
    cd_path = _pipeline_dir(args) / "flow_global_cooldown.json"
    data = _read_json_safe(cd_path)
    try:
        until = float(data.get("until") or 0)
    except Exception:
        until = 0
    rem = until - time.time()
    if rem > 0:
        return rem, str(data.get("reason") or "Flow cooldown")
    return 0, ""


def _set_flow_cooldown(args, reason):
    seconds = max(0, float(getattr(args, "hybrid_flow_cooldown_seconds", 0) or 0))
    if seconds <= 0:
        return
    cd_path = _pipeline_dir(args) / "flow_global_cooldown.json"
    data = {"until": time.time() + seconds, "seconds": seconds, "reason": str(reason or "Flow abnormal"), "ts": _now(), "pid": os.getpid()}
    _write_json_atomic(cd_path, data)
    print(f"[pipeline] Flow cooldown toàn cục {int(seconds)}s • lý do: {reason}", flush=True)
    emit_event("job_retry", path="", error_type="FlowGlobalCooldown", message=f"Flow cooldown {int(seconds)}s: {reason}", attempt="cooldown", max_attempts="gemini")


def _acquire_flow_lane(args):
    """Chỉ 1 worker được chạy Flow cùng lúc. Trả (acquired, token, reason)."""
    lanes = max(1, int(getattr(args, "hybrid_flow_lanes", 1) or 1))
    # Hiện tại dùng 1 lock file cho lane an toàn nhất. Nếu sau này cần 2 lane có thể mở rộng nhiều lock.
    if lanes > 1:
        lanes = 1
    rem, reason = _cooldown_remaining(args)
    if rem > 0:
        return False, None, f"Flow đang cooldown {int(rem)}s • {reason}"

    lock_path = _pipeline_dir(args) / "flow_lane_1.lock"
    token = f"{os.getpid()}-{time.time()}-{random.randint(1000,9999)}"
    deadline = time.time() + max(1.0, float(getattr(args, "hybrid_flow_lane_wait_timeout", 90) or 90))
    stale_after = max(30.0, float(getattr(args, "hybrid_flow_lock_stale_seconds", 900) or 900))
    announced = False
    while True:
        rem, reason = _cooldown_remaining(args)
        if rem > 0:
            return False, None, f"Flow vừa vào cooldown {int(rem)}s • {reason}"
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump({"token": token, "pid": os.getpid(), "ts": time.time(), "time": _now()}, f, ensure_ascii=False)
            return True, token, ""
        except FileExistsError:
            try:
                st = lock_path.stat()
                if time.time() - st.st_mtime > stale_after:
                    print("[pipeline] Xóa flow lane lock cũ/stale", flush=True)
                    lock_path.unlink(missing_ok=True)
                    continue
            except Exception:
                pass
            if not announced:
                print("[pipeline] Flow lane đang bận • worker này chờ, không spam Flow song song", flush=True)
                announced = True
            if time.time() >= deadline:
                return False, None, "Chờ Flow lane quá lâu; chuyển Gemini để không kẹt"
            time.sleep(random.uniform(1.5, 3.5))
        except Exception as e:
            return False, None, f"Không lấy được Flow lane lock: {e}"


def _release_flow_lane(args, token):
    if not token:
        return
    lock_path = _pipeline_dir(args) / "flow_lane_1.lock"
    try:
        data = _read_json_safe(lock_path)
        if not data or data.get("token") == token:
            lock_path.unlink(missing_ok=True)
            print("[pipeline] Đã nhả Flow lane", flush=True)
    except Exception as e:
        print(f"⚠ Không nhả được Flow lane: {e}", flush=True)


def _flow_jitter(args):
    try:
        lo = float(getattr(args, "hybrid_flow_start_jitter_min", 0) or 0)
        hi = float(getattr(args, "hybrid_flow_start_jitter_max", lo) or lo)
        if hi < lo:
            hi = lo
        delay = random.uniform(max(0, lo), max(0, hi))
        if delay > 0:
            print(f"[pipeline] Giãn nhịp trước Flow {delay:.1f}s để tránh hành vi đồng loạt", flush=True)
            time.sleep(delay)
    except Exception:
        pass


def _new_flow_stats():
    return {
        "abnormal": False,
        "content_policy": False,
        "technical": False,
        "error_count": 0,
        "abnormal_count": 0,
        "policy_count": 0,
        "technical_count": 0,
    }


def _classify_flow_line(line, stats):
    low = str(line or "").lower()
    # v4.2: tách rõ lỗi để không đổ mọi thứ cho proxy.
    # Abnormal => account/proxy/session cần cooldown Flow.
    # Policy/content failed => chuyển Gemini sớm, không cooldown proxy.
    # Technical/UI => retry Flow/project được.
    abnormal_keys = [
        "hoạt động bất thường", "hoat dong bat thuong", "abnormal activity", "unusual activity",
        "suspicious", "tạm thời bị hạn chế", "tam thoi bi han che",
    ]
    policy_keys = [
        "flow tạo ảnh không thành công", "flow tao anh khong thanh cong", "không thành công", "khong thanh cong",
        "có thể bị policy", "co the bi policy", "có thể vi phạm", "co the vi pham",
        "chính sách", "chinh sach", "try another prompt", "generation failed",
    ]
    technical_keys = [
        "không tìm thấy input", "khong tim thay input", "upload ảnh chưa xong", "upload anh chua xong",
        "timeout", "timed out", "stale element", "element click intercepted", "chrome not reachable",
    ]
    if any(k in low for k in abnormal_keys):
        stats["abnormal"] = True
        stats["abnormal_count"] = int(stats.get("abnormal_count", 0)) + 1
        stats["error_count"] = int(stats.get("error_count", 0)) + 1
    elif any(k in low for k in policy_keys):
        stats["content_policy"] = True
        stats["policy_count"] = int(stats.get("policy_count", 0)) + 1
        stats["error_count"] = int(stats.get("error_count", 0)) + 1
    elif any(k in low for k in technical_keys):
        stats["technical"] = True
        stats["technical_count"] = int(stats.get("technical_count", 0)) + 1
        stats["error_count"] = int(stats.get("error_count", 0)) + 1


def run_child(label, script_path, args_list, filter_flow_errors=False):
    stats = _new_flow_stats() if str(label).lower().startswith("flow") else {}
    if not Path(script_path).exists():
        print(f"⚠ Hybrid không thấy backend {label}: {script_path}", flush=True)
        return 127, stats
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    if str(label).lower().startswith("flow"):
        env["FLOW_MAX_ROUND_RETRY"] = "0"
    cmd = [sys.executable, "-u", str(script_path)] + list(args_list)
    print(f"\n[hybrid] ===== START {label.upper()} =====", flush=True)
    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(Path(script_path).resolve().parent),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            universal_newlines=True,
            env=env,
        )
    except Exception as e:
        print(f"✖ Hybrid không chạy được {label}: {e}", flush=True)
        return 126, stats

    for raw in proc.stdout:
        line = raw.rstrip("\r\n")
        if stats is not None:
            _classify_flow_line(line, stats)
        if filter_flow_errors and line.startswith(EVENT_MARKER):
            try:
                event = json.loads(line[len(EVENT_MARKER):])
                typ = str(event.get("type") or "")
                if typ in ("job_error", "quota"):
                    path = event.get("path") or ""
                    msg = str(event.get("message") or typ)
                    err_type = str(event.get("error_type") or typ)
                    account = event.get("account")
                    print(f"[hybrid] Flow chưa xử lý được, chuyển Gemini fallback • {err_type}: {msg[:180]} • {path}", flush=True)
                    emit_event(
                        "job_retry",
                        path=path,
                        account=account,
                        error_type="FlowFallback",
                        message=f"Flow lỗi {err_type}; chuyển sang Gemini fallback: {msg[:180]}",
                        attempt="Flow",
                        max_attempts="Gemini",
                        account_exhaust=False,
                    )
                    continue
                if typ == "worker_summary":
                    print(f"[hybrid] Flow summary: ok={event.get('success')} err={event.get('failed')} skip={event.get('skipped')}", flush=True)
                    continue
            except Exception as e:
                print(f"[hybrid] parse event Flow lỗi nhẹ: {e}", flush=True)
        print(line, flush=True)
    rc = proc.wait()
    print(f"[hybrid] ===== END {label.upper()} rc={rc} =====\n", flush=True)
    return rc, stats


def main():
    args = parse_args()
    base = Path(__file__).resolve().parent
    flow_script = base / "flow_auto_router_project_x4_complete.py"
    gemini_script = base / "gemini_auto_router_by_account_mode_fixed_v53_auto_rerun_gridfix.py"

    print("🚀 Gemini One Machine Max v6.0 • Gemini-only direct/no-proxy")
    print("📁 Root:", args.root)
    print("🧩 Chiến lược: bỏ Flow/proxy; chạy Gemini direct đủ worker trên 1 máy")
    emit_event("config", root=args.root, logo=args.logo, hybrid="max_throughput", final_min_mb=args.final_min_mb, input_skip_over_mb=args.input_skip_over_mb)
    print(f"[pipeline] shared_dir={_pipeline_dir(args)}", flush=True)

    skip_flow = str(getattr(args, "hybrid_skip_flow", "0") or "0").strip().lower() in ("1", "true", "yes", "on")
    if skip_flow:
        acquired, flow_token, flow_skip_reason = False, None, "Gemini-only v6.0: bỏ Flow"
    else:
        acquired, flow_token, flow_skip_reason = _acquire_flow_lane(args)
    rc_flow = 0
    flow_stats = {}
    if acquired:
        try:
            _flow_jitter(args)
            rc_flow, flow_stats = run_child("flow", flow_script, flow_args(args), filter_flow_errors=True)
        finally:
            _release_flow_lane(args, flow_token)
        if flow_stats.get("abnormal"):
            _set_flow_cooldown(args, f"Flow abnormal activity {flow_stats.get('abnormal_count', 0)} lần trong worker")
        elif flow_stats.get("content_policy"):
            print(f"[classifier] FlowContentPolicy: {flow_stats.get('policy_count', 0)} dấu hiệu policy/content • không cooldown proxy, chuyển Gemini fallback", flush=True)
        elif flow_stats.get("technical"):
            print(f"[classifier] FlowTechnicalUI: {flow_stats.get('technical_count', 0)} dấu hiệu kỹ thuật/UI • có thể retry Flow/project", flush=True)
    else:
        print(f"[throughput] Bỏ qua Flow cho worker này: {flow_skip_reason}", flush=True)
        emit_event("job_retry", path="", error_type="FlowLaneSkipped", message=f"{flow_skip_reason}; chuyển Gemini fallback", attempt="FlowLane", max_attempts="Gemini")

    last_done = -1
    rc_gemini = 0
    max_rounds = max(1, int(args.hybrid_max_fallback_rounds or 999999))
    for round_no in range(1, max_rounds + 1):
        todo, _data = unfinished_paths(args.root, args.manifest)
        if not todo:
            print("[hybrid] Không còn ảnh lỗi/chưa xong trong worker này", flush=True)
            break
        counts_before = count_statuses(args.root, args.manifest)
        print(f"[hybrid] Fallback vòng {round_no}: còn {len(todo)} ảnh chưa DONE -> chạy Gemini", flush=True)
        emit_event("job_retry", path=str(todo[0]) if todo else "", error_type="HybridRepeatFallback", message=f"Fallback vòng {round_no}: còn {len(todo)} ảnh, tiếp tục chia/vẽ lại đến khi xong", attempt=round_no, max_attempts="until_done")
        for p in todo[:30]:
            print(f"[hybrid] retry queue: {p}", flush=True)
        if len(todo) > 30:
            print(f"[hybrid] ... và {len(todo)-30} ảnh khác", flush=True)
        rc_gemini, _gem_stats = run_child(f"gemini round {round_no}", gemini_script, gemini_args(args), filter_flow_errors=False)
        counts_after = count_statuses(args.root, args.manifest)
        if counts_after["done"] <= counts_before["done"]:
            print(f"[hybrid] Vòng {round_no} chưa tăng số DONE ({counts_before['done']} -> {counts_after['done']}); vẫn tiếp tục sau {args.hybrid_no_progress_sleep}s nếu còn job", flush=True)
            try:
                time.sleep(max(0.5, float(args.hybrid_no_progress_sleep)))
            except Exception:
                time.sleep(5)
        last_done = counts_after["done"]
    else:
        print(f"[hybrid] Đạt giới hạn vòng fallback {max_rounds}; nếu vẫn còn lỗi hãy bấm Chạy lại lỗi hoặc tăng HYBRID_MAX_FALLBACK_ROUNDS", flush=True)

    counts = count_statuses(args.root, args.manifest)
    print(f"📊 Tổng kết Hybrid: total={counts['total']} done={counts['done']} error={counts['error']} skipped={counts['skipped']} other={counts['other']}", flush=True)
    emit_event("worker_summary", success=counts["done"], failed=counts["error"] + counts["other"], skipped=counts["skipped"], rc_flow=rc_flow, rc_gemini=rc_gemini)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
