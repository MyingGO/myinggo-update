"""MyingGo • tuỳ chọn vẽ thumbnail dùng chung cho worker trình duyệt (Gemini web / Flow) và Gemini API.

File cấu hình: biến môi trường MYINGGO_THUMB_OPTIONS (JSON) do MyingGo ghi:
{
  "variation": 30,                 # % khác so với ảnh gốc (0-100) mặc định
  "remove_logos": true,            # xoá logo/watermark không liên quan trong ảnh gốc
  "artist_restyle": true,          # đổi tư thế & trang phục nghệ sĩ (giữ khuôn mặt)
  "nature_mode": false,            # chế độ ảnh thiên nhiên/cảnh vật/sấm sét (không thêm người, không thêm chữ)
  "nature_add_text": false,        # nút phụ cho chế độ thiên nhiên: cho phép thêm text tạo thumb hấp dẫn
  "nature_custom_text": "",        # nội dung chữ tuỳ chọn cho ảnh thiên nhiên (để trống = AI tự tạo/làm mới)
  "folders": {                     # cấu hình riêng theo thư mục (Queue / thư mục con)
     "d:\\nhac\\latin": {"style": "neon cyberpunk", "variation": 60}
  }
}
Style để trống => giữ nguyên phong cách gốc. Không có file => giữ nguyên prompt gốc (tương thích 3T Master).
"""
import json
import os
import time
from pathlib import Path

_CACHE = {"path": "", "mtime": 0.0, "data": None, "checked": 0.0}


def options_path():
    return str(os.environ.get("MYINGGO_THUMB_OPTIONS") or "").strip()


def load_all():
    p = options_path()
    if not p:
        return None
    now = time.time()
    if _CACHE["path"] == p and now - _CACHE["checked"] < 2.0:
        return _CACHE["data"]
    _CACHE.update(path=p, checked=now)
    try:
        mt = os.path.getmtime(p)
        if _CACHE["data"] is not None and mt == _CACHE["mtime"]:
            return _CACHE["data"]
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        _CACHE.update(mtime=mt, data=data if isinstance(data, dict) else None)
    except Exception:
        _CACHE.update(data=None)
    return _CACHE["data"]


def _norm(p):
    return os.path.normcase(os.path.abspath(str(p))).rstrip("\\/")


def options_for(image_path, data=None):
    """Gộp cấu hình chung + cấu hình thư mục gần nhất (khớp tiền tố dài nhất)."""
    data = load_all() if data is None else data
    if not data:
        return None
    out = {
        "variation": data.get("variation", 30),
        "remove_logos": bool(data.get("remove_logos", True)),
        "artist_restyle": bool(data.get("artist_restyle", True)),
        "nature_mode": bool(data.get("nature_mode", False)),
        "nature_add_text": bool(data.get("nature_add_text", False)),
        "nature_custom_text": str(data.get("nature_custom_text") or "").strip(),
        "style": "",
    }
    target = _norm(image_path) if image_path else ""
    best, best_len = None, -1
    if target:
        for key, cfg in (data.get("folders") or {}).items():
            k = _norm(key)
            if (target == k or target.startswith(k + os.sep)) and len(k) > best_len and isinstance(cfg, dict):
                best, best_len = cfg, len(k)
    if best:
        if str(best.get("style") or "").strip():
            out["style"] = str(best["style"]).strip()
        if best.get("variation") not in (None, ""):
            out["variation"] = best["variation"]
        if best.get("remove_logos") is not None:
            out["remove_logos"] = bool(best["remove_logos"])
        if best.get("artist_restyle") is not None:
            out["artist_restyle"] = bool(best["artist_restyle"])
        if best.get("nature_mode") is not None:
            out["nature_mode"] = bool(best["nature_mode"])
        if best.get("nature_add_text") is not None:
            out["nature_add_text"] = bool(best["nature_add_text"])
        if best.get("nature_custom_text") is not None:
            out["nature_custom_text"] = str(best.get("nature_custom_text") or "").strip()
    try:
        out["variation"] = max(0, min(100, int(out["variation"])))
    except Exception:
        out["variation"] = 30
    return out


def variation_text(v, nature_mode=False, nature_add_text=False, artist_restyle=True):
    v = int(v)
    if nature_mode:
        if v <= 10:
            level = (
                "Make only MINIMAL changes to the natural scenery: keep the composition, lighting and colour palette "
                "almost identical to the original; only enhance clarity, atmosphere and fine environmental details."
            )
        elif v <= 30:
            level = (
                "Make SUBTLE changes to the natural scene: keep the same overall mood and subject, but create a fresh "
                "variation of the clouds, lightning, water, foliage or lighting effects."
            )
        elif v <= 55:
            level = (
                "Make MODERATE changes: noticeably reimagine the landscape details, sky/storm patterns, lighting direction "
                "and atmospheric depth while keeping the same nature theme."
            )
        elif v <= 80:
            level = (
                "Make STRONG changes: create a distinctly different composition, dramatic weather/sky dynamics, lighting "
                "and colour intensity for this natural scene."
            )
        else:
            level = (
                "Make a COMPLETELY NEW version of this nature/atmospheric scene: a totally fresh camera angle, dramatic "
                "sky/storm/landscape arrangement, lighting and colour mood while staying 100% faithful to the nature theme."
            )
        if not nature_add_text:
            level += " Do NOT add any people, singers, faces, or any text/words/letters."
        else:
            level += " Do NOT add any people, singers, or faces; include bold, cinematic thumbnail typography."
        return f"Target roughly {v}% visual difference from the original image. {level}"

    if artist_restyle:
        if v <= 10:
            level = (
                "Make only MINIMAL changes: keep the background and colour palette very close to the original, lightly "
                "refresh the typography, and make subtle adjustments to the singer/artist's pose and outfit while keeping "
                "their exact face."
            )
        elif v <= 30:
            level = (
                "Make SUBTLE changes: refresh the background details and typography, and give the singer/artist a slightly "
                "updated pose, expression and refreshed clothing/outfit while keeping their exact facial identity."
            )
        elif v <= 55:
            level = (
                "Make MODERATE changes: noticeably redesign the background, lighting and typography, and change the "
                "singer/artist's pose, body posture and outfit/wardrobe into a fresh new look while preserving their exact face."
            )
        elif v <= 80:
            level = (
                "Make STRONG changes: create a clearly different background, lighting and typography design, and transform "
                "the singer/artist's pose, hand/body gesture, camera framing and clothing/outfit into a bold new style "
                "while keeping the exact same face and identity."
            )
        else:
            level = (
                "Make a COMPLETELY NEW design: a totally different background scene, lighting, colour palette and "
                "typography, AND give the singer/artist a completely new pose, dynamic posture/framing, and a brand-new "
                "stylish outfit/wardrobe (preserving only the artist's exact facial identity, likeness and hair)."
            )
        return f"Target roughly {v}% visual difference from the original image. {level}"

    if v <= 10:
        level = ("Make only MINIMAL changes: keep the background, composition, lighting and colour palette almost identical "
                 "to the original; only clean up and lightly refresh the typography.")
    elif v <= 30:
        level = ("Make SUBTLE changes: keep the same composition and overall look, refresh the background details and "
                 "typography slightly so it looks like a new version of the same design.")
    elif v <= 55:
        level = ("Make MODERATE changes: redesign the background and typography noticeably while keeping a similar layout "
                 "and mood.")
    elif v <= 80:
        level = ("Make STRONG changes: create a clearly different background, lighting and typography design; the layout "
                 "may change.")
    else:
        level = ("Make a COMPLETELY NEW design: a totally different background scene, lighting, colour palette and "
                 "typography; only the singer stays the same.")
    return f"Target roughly {v}% visual difference from the original image. {level}"


LOGO_TEXT = ("Before editing, scan the original image for unrelated logos, watermarks, channel badges, TV station marks, "
             "social media icons, URLs or brand marks (anything that is not part of the main subject or main title) and "
             "remove them completely, filling those areas naturally to match the surroundings.")


ARTIST_RESTYLE_BASE_PROMPT = (
    "Edit the uploaded image into a finished realistic music thumbnail. "
    "If there is a singer, artist, or person in the uploaded image: preserve their exact facial identity, face structure, "
    "likeness, skin tone, and hair so it is unmistakably the same person, BUT change and redesign their pose, body posture, "
    "gesture, and clothing/outfit into a fresh, stylish new look that harmonises with the new scene. "
    "Redesign the background style and typography/font. If any visible year such as 2024 or 2025 appears in the image, "
    "replace it with 2026. Return only the final edited image, no explanation and no text response."
)

NATURE_PURE_BASE_PROMPT = (
    "Edit the uploaded nature, landscape, sky, storm, lightning, weather, or atmospheric scenery image into a finished, "
    "photorealistic, visually striking new version of the scene. "
    "CRITICAL RULES: "
    "1. STRICTLY DO NOT add any people, singers, artists, human figures, silhouettes, portraits, or faces anywhere in the image. "
    "2. STRICTLY DO NOT add any text, words, letters, titles, numbers, or typography anywhere in the image. If the original "
    "image has any text or watermark, remove it cleanly and fill with natural scenery. "
    "Focus 100% on the natural environment, lighting, sky/atmosphere, and scenery. "
    "Return only the final edited image, no explanation and no text response."
)

NATURE_WITH_TEXT_BASE_PROMPT = (
    "Edit the uploaded nature, landscape, sky, storm, lightning, weather, or atmospheric scenery image into a high-impact, "
    "cinematic YouTube thumbnail. "
    "CRITICAL RULES: "
    "1. STRICTLY DO NOT add any people, singers, artists, human figures, portraits, or faces anywhere in the image. Keep the "
    "visual scene 100% focused on the natural scenery and atmosphere. "
    "2. Add or redesign bold, cinematic, eye-catching thumbnail typography/title text with dramatic contrast, glow, or 3D depth "
    "that makes the nature thumbnail compelling and clickable. If any visible year such as 2024 or 2025 appears, replace it with 2026. "
    "Return only the final edited image, no explanation and no text response."
)


def build_prompt(base_prompt, image_path=None, opts=None):
    """Trả về prompt đã gắn chế độ (Nghệ sĩ đổi tư thế/trang phục hoặc Thiên nhiên) + % khác gốc + style + xoá logo."""
    opts = opts if opts is not None else (options_for(image_path) if image_path else load_all())
    if not opts:
        return base_prompt

    nature_mode = bool(opts.get("nature_mode", False))
    nature_add_text = bool(opts.get("nature_add_text", False))
    nature_custom_text = str(opts.get("nature_custom_text") or "").strip()
    artist_restyle = bool(opts.get("artist_restyle", True))
    variation = opts.get("variation", 30)

    if nature_mode:
        if nature_add_text:
            core_prompt = NATURE_WITH_TEXT_BASE_PROMPT
            if nature_custom_text:
                core_prompt += f' Use this exact text for the thumbnail title: "{nature_custom_text}".'
        else:
            core_prompt = NATURE_PURE_BASE_PROMPT
    elif artist_restyle:
        core_prompt = ARTIST_RESTYLE_BASE_PROMPT
    else:
        core_prompt = str(base_prompt or "").strip()

    parts = [core_prompt]
    parts.append(
        variation_text(
            variation,
            nature_mode=nature_mode,
            nature_add_text=nature_add_text,
            artist_restyle=artist_restyle,
        )
    )
    style = str(opts.get("style") or "").strip()
    if style:
        if nature_mode and not nature_add_text:
            parts.append(f"Apply this visual style to the natural scenery and atmosphere (without adding any text or people): {style}.")
        else:
            parts.append(f"Apply this visual style to the scene and design: {style}.")
    else:
        parts.append(
            "Keep the overall genre and mood coherent with the original image (colour feeling, atmosphere and visual quality)."
        )
    if opts.get("remove_logos"):
        parts.append(LOGO_TEXT)
    return " ".join(p for p in parts if p)
