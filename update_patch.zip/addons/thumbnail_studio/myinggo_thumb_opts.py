"""MyingGo • tuỳ chọn vẽ thumbnail dùng chung cho worker trình duyệt (Gemini web / Flow) và Gemini API.

File cấu hình: biến môi trường MYINGGO_THUMB_OPTIONS (JSON) do MyingGo ghi:
{
  "variation": 30,                 # % khác so với ảnh gốc (0-100) mặc định
  "remove_logos": true,            # xoá logo/watermark không liên quan trong ảnh gốc
  "artist_restyle": true,          # đổi tư thế & trang phục nghệ sĩ (giữ khuôn mặt)
  "nature_mode": false,            # chế độ ảnh thiên nhiên/cảnh vật/sấm sét (không thêm người, không thêm chữ)
  "nature_add_text": false,        # nút phụ cho chế độ thiên nhiên: cho phép thêm text tạo thumb hấp dẫn
  "nature_custom_text": "",        # nội dung chữ tuỳ chọn cho ảnh thiên nhiên (để trống = AI tự tạo/làm mới)
  "folders": {                     # cấu hình riêng theo thư mục (Queue / thư mục con)
     "d:\\nhac\\latin": {"style": "neon cyberpunk", "variation": 60}
  }
}
Style để trống => giữ nguyên phong cách gốc. Không có file => giữ nguyên prompt gốc (tương thích 3T Master).
"""
import json
import os
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path

_CACHE = {"path": "", "mtime": 0.0, "data": None, "checked": 0.0}
_TRANS_CACHE = {}


def _clean_vi_typos(text: str) -> str:
    """Làm sạch ký tự gõ Telex dư ở cuối từ đã có dấu tiếng Việt (VD: 'sống độngj' -> 'sống động')."""
    s = re.sub(r"\s+", " ", str(text or "")).strip()
    # Nếu một từ có ký tự tiếng Việt có dấu nhưng kết thúc bằng phím dấu Telex dư (j, f, r, x, s, w)
    def _fix_word(m):
        w = m.group(0)
        if any(ord(c) > 127 for c in w[:-1]) and w[-1].lower() in ("j", "f", "r", "x", "w"):
            return w[:-1]
        return w
    return re.sub(r"\b\w+\b", _fix_word, s)


def _to_english_directive(text: str) -> str:
    """Chuyển prompt tiếng Việt của người dùng sang tiếng Anh tự nhiên để tránh bộ lọc an toàn tiếng Việt
    của Gemini Web bắt nhầm từ khóa và giúp Imagen/Nano Banana hiểu chính xác 100%."""
    cleaned = _clean_vi_typos(text)
    if not cleaned:
        return ""
    if cleaned in _TRANS_CACHE:
        return _TRANS_CACHE[cleaned]
    # Kiểm tra xem có phải tiếng Việt không (có dấu hoặc từ tiếng Việt thông dụng)
    has_vi = any(ord(c) > 127 for c in cleaned) or bool(
        re.search(r"\b(tạo|ảnh|hình|chân thật|sống động|mưa|đêm|sáng|đẹp|xóa|thêm|đổi|màu|nền|cảnh|người)\b", cleaned, re.I)
    )
    if not has_vi:
        _TRANS_CACHE[cleaned] = cleaned
        return cleaned
    try:
        url = (
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=vi&tl=en&dt=t&q="
            + urllib.parse.quote(cleaned)
        )
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            en = "".join(seg[0] for seg in (data[0] or []) if seg and seg[0]).strip()
            if en:
                en = en.rstrip(".").strip()
                _TRANS_CACHE[cleaned] = en
                return en
    except Exception:
        pass
    _TRANS_CACHE[cleaned] = cleaned
    return cleaned


def options_path():
    return str(os.environ.get("MYINGGO_THUMB_OPTIONS") or "").strip()


def load_all():
    p = options_path()
    if not p:
        return None
    now = time.time()
    if _CACHE["path"] == p and now - _CACHE["checked"] < 2.0:
        return _CACHE["data"]
    _CACHE.update(path=p, checked=now)
    try:
        mt = os.path.getmtime(p)
        if _CACHE["data"] is not None and mt == _CACHE["mtime"]:
            return _CACHE["data"]
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        _CACHE.update(mtime=mt, data=data if isinstance(data, dict) else None)
    except Exception:
        _CACHE.update(data=None)
    return _CACHE["data"]


def _norm(p):
    return os.path.normcase(os.path.abspath(str(p))).rstrip("\\/")


def options_for(image_path, data=None):
    """Gộp cấu hình chung + cấu hình thư mục gần nhất (khớp tiền tố dài nhất)."""
    data = load_all() if data is None else data
    if not data:
        return None
    out = {
        "variation": data.get("variation", 30),
        "remove_logos": bool(data.get("remove_logos", True)),
        "artist_restyle": bool(data.get("artist_restyle", True)),
        "nature_mode": bool(data.get("nature_mode", False)),
        "nature_add_text": bool(data.get("nature_add_text", False)),
        "nature_custom_text": str(data.get("nature_custom_text") or "").strip(),
        "style": "",
    }
    target = _norm(image_path) if image_path else ""
    best, best_len = None, -1
    folders_map = data.get("folders") or {}
    if target and folders_map:
        for key, cfg in folders_map.items():
            k = _norm(key)
            if (target == k or target.startswith(k + os.sep)) and len(k) > best_len and isinstance(cfg, dict):
                best, best_len = cfg, len(k)
        if best is None:
            env_qroot = str(os.environ.get("MYINGGO_QUEUE_ROOT") or "").strip()
            if env_qroot:
                eq = _norm(env_qroot)
                for key, cfg in folders_map.items():
                    k = _norm(key)
                    if (eq == k or eq.startswith(k + os.sep)) and len(k) > best_len and isinstance(cfg, dict):
                        best, best_len = cfg, len(k)
        if best is None and image_path:
            try:
                sub_name = Path(image_path).parent.name
                if sub_name:
                    for key, cfg in folders_map.items():
                        if isinstance(cfg, dict) and (Path(key) / sub_name).is_dir() and len(str(key)) > best_len:
                            best, best_len = cfg, len(str(key))
            except Exception:
                pass
    if best:
        if str(best.get("style") or "").strip():
            out["style"] = str(best["style"]).strip()
        if best.get("variation") not in (None, ""):
            out["variation"] = best["variation"]
        if best.get("remove_logos") is not None:
            out["remove_logos"] = bool(best["remove_logos"])
        if best.get("artist_restyle") is not None:
            out["artist_restyle"] = bool(best["artist_restyle"])
        if best.get("nature_mode") is not None:
            out["nature_mode"] = bool(best["nature_mode"])
        if best.get("nature_add_text") is not None:
            out["nature_add_text"] = bool(best["nature_add_text"])
        if best.get("nature_custom_text") is not None:
            out["nature_custom_text"] = str(best.get("nature_custom_text") or "").strip()
    try:
        out["variation"] = max(0, min(100, int(out["variation"])))
    except Exception:
        out["variation"] = 30
    return out


def variation_text(v, nature_mode=False, nature_add_text=False, artist_restyle=True):
    v = int(v)
    if nature_mode:
        if v <= 10:
            level = (
                "Keep the composition, camera angle, and scene elements very close to the original image while dramatically "
                "upgrading sharpness, lighting, reflections, colour richness, and cinematic depth."
            )
        elif v <= 30:
            level = (
                "Keep the same core subject, theme, and mood as the original image, creating a fresh, ultra-crisp, cinematic "
                "thumbnail version with richer lighting, reflections, and atmospheric detail."
            )
        elif v <= 55:
            level = (
                "Reimagine the scene details, lighting direction, reflections, and atmospheric depth into a visually striking, "
                "high-impact new thumbnail version while staying faithful to the original image's subject and mood."
            )
        elif v <= 80:
            level = (
                "Create a bold, dynamic new composition and dramatic cinematic lighting for this scene while preserving "
                "the core subject and theme of the original image."
            )
        else:
            level = (
                "Create a completely fresh, breathtaking cinematic thumbnail version inspired by the original image's subject "
                "and mood with dramatic lighting, depth, and colour."
            )
        if not nature_add_text:
            level += " If the original image has NO people, STRICTLY DO NOT add any person or human figure. Do NOT add any text, words, or channel name."
        else:
            level += " If the original image has NO people, STRICTLY DO NOT add any person or human figure."
        return f"Target roughly {v}% visual difference from the original image. {level}"

    if artist_restyle:
        if v <= 10:
            level = (
                "Make only MINIMAL changes: keep the background and colour palette very close to the original, lightly "
                "refresh the typography, and make subtle studio portrait angle and stage styling refinements while keeping "
                "the featured artist recognizable."
            )
        elif v <= 30:
            level = (
                "Make SUBTLE changes: refresh the background details and typography, and present the featured artist in a "
                "slightly refreshed studio portrait angle and coordinated stage styling while keeping the same face and hair."
            )
        elif v <= 55:
            level = (
                "Make MODERATE changes: noticeably redesign the background, lighting and typography, and present the "
                "featured artist in a fresh studio portrait framing and coordinated stage attire while keeping the same face and hair."
            )
        elif v <= 80:
            level = (
                "Make STRONG changes: create a clearly different background, lighting and typography design, and present "
                "the featured artist in a dynamic studio portrait composition and fresh stage styling while keeping the same face and hair."
            )
        else:
            level = (
                "Make a COMPLETELY NEW design: a totally different background scene, lighting, colour palette and "
                "typography, with the featured artist in a fresh studio portrait framing and stage styling while keeping the same face and hair."
            )
        return f"Target roughly {v}% visual difference from the original image. {level}"

    if v <= 10:
        level = ("Make only MINIMAL changes: keep the background, composition, lighting and colour palette almost identical "
                 "to the original; only clean up and lightly refresh the typography.")
    elif v <= 30:
        level = ("Make SUBTLE changes: keep the same composition and overall look, refresh the background details and "
                 "typography slightly so it looks like a new version of the same design.")
    elif v <= 55:
        level = ("Make MODERATE changes: redesign the background and typography noticeably while keeping a similar layout "
                 "and mood.")
    elif v <= 80:
        level = ("Make STRONG changes: create a clearly different background, lighting and typography design; the layout "
                 "may change.")
    else:
        level = ("Make a COMPLETELY NEW design: a totally different background scene, lighting, colour palette and "
                 "typography; only the singer stays the same.")
    return f"Target roughly {v}% visual difference from the original image. {level}"


LOGO_TEXT = (
    "Clean up any small corner badges, stray corner icons, or unrelated small corner graphics "
    "so the layout is clean and uncluttered, blending seamlessly with the surrounding background."
)


ARTIST_RESTYLE_BASE_PROMPT = (
    "Create a polished, realistic music album thumbnail based on the uploaded cover image. "
    "Keep the featured artist recognizable with the same face and hair, presented in a fresh, natural studio portrait "
    "framing and coordinated stage styling that harmonises with the new scene. "
    "Redesign the background style, lighting atmosphere, and title typography/font. If any visible year such as 2024 or 2025 "
    "appears in the image, update it to 2026. Return only the final image, no explanation and no text response."
)


SAFE_FALLBACK_PROMPT = (
    "Redesign the background scenery, lighting atmosphere, colour grading, and title typography of this music cover thumbnail "
    "into a fresh, polished new studio version while keeping the foreground subject intact. "
    "If any visible year such as 2024 or 2025 appears, update it to 2026. Return only the final image."
)

NATURE_PURE_BASE_PROMPT = (
    "Create a stunning, ultra-sharp, cinematic YouTube thumbnail version for this uploaded image. "
    "Preserve the main subject, scene theme, and atmosphere of the original image while dramatically enhancing lighting, "
    "clarity, reflections, contrast, and colour depth so it looks like a professional, eye-catching thumbnail. "
    "Important guidelines: "
    "1. Subject rule: Inspect the uploaded original image carefully. If the original image shows only scenery, rain, nature, "
    "trees, street, vehicles, or interiors without people, keep it purely as scenery and do not add any person or human figure. "
    "Only include a person if a person is already clearly present in the uploaded original image. "
    "2. Typography rule: Keep the scene completely free of any text, words, letters, subtitles, or numbers (such as 2026), "
    "and clean up any stray corner text or small badges seamlessly with the background scene. "
    "Return only the final edited image, no explanation and no text response."
)

NATURE_WITH_TEXT_BASE_PROMPT = (
    "Create a stunning, ultra-sharp, cinematic YouTube thumbnail version for this uploaded image. "
    "Preserve the main subject, scene theme, and atmosphere of the original image while dramatically enhancing lighting, "
    "clarity, reflections, contrast, and colour depth so it looks like a professional, eye-catching thumbnail. "
    "Important guidelines: "
    "1. Subject rule: Inspect the uploaded original image carefully. If the original image shows only scenery, rain, nature, "
    "trees, street, vehicles, or interiors without people, keep it purely as scenery and do not add any person or human figure. "
    "Only include a person if a person is already clearly present in the uploaded original image. "
    "2. Typography rule: Render only the specified channel title text cleanly and legibly on the thumbnail (such as in the corner). "
    "Do not add any extra subtitles, slogans, or years (such as 2026). "
    "Return only the final edited image, no explanation and no text response."
)


def _build_custom_primary_prompt(style, opts, safe_fallback=False):
    """Khi người dùng nhập prompt riêng (style/custom_prompt), đặt prompt đó làm PROMPT CHÍNH;
    các nút Tạo thumb đẹp từ gốc / Đổi dáng / Xoá logo / Tên kênh chỉ đóng vai trò bổ trợ phụ."""
    nature_mode = bool(opts.get("nature_mode", False))
    nature_custom_text = str(opts.get("nature_custom_text") or "").strip()
    nature_add_text = bool(opts.get("nature_add_text", False))
    artist_restyle = bool(opts.get("artist_restyle", False))
    remove_logos = bool(opts.get("remove_logos", False))
    variation = opts.get("variation", 30)

    en_style = _to_english_directive(style)
    parts = [
        f"Edit this uploaded image into a polished new YouTube thumbnail following this main creative direction: {en_style}.",
        "Make this creative direction the primary visual transformation and central focus of the edited image.",
    ]

    if not safe_fallback:
        parts.append(
            f"Target roughly {variation}% visual difference from the original image while staying true to the main creative direction above."
        )

    if nature_mode:
        parts.append(
            "Enhance lighting, clarity, reflections, contrast, and cinematic depth. "
            "If the original image shows scenery without people and the main direction does not ask for people, keep it as pure scenery without adding any human figure."
        )
    if artist_restyle:
        parts.append(
            "If a featured artist or person is present, refresh their studio framing and styling naturally while keeping their face and hair recognizable."
        )
    if nature_add_text and nature_custom_text:
        parts.append(
            f'Include the channel title text "{nature_custom_text}" cleanly and legibly on the thumbnail (without adding extra subtitles or years).'
        )
    elif nature_mode and not nature_add_text:
        parts.append(
            "Unless the main creative direction asks for text, keep the image free of extra text or years."
        )
    if remove_logos:
        if nature_add_text and nature_custom_text:
            parts.append(
                f'Clean up any small corner badges, stray corner icons, or unrelated small corner graphics so the layout is clean, keeping only the channel text "{nature_custom_text}".'
            )
        else:
            parts.append(LOGO_TEXT)

    parts.append("Return only the final edited image, no explanation and no text response.")
    return " ".join(p for p in parts if p)


def build_prompt(base_prompt, image_path=None, opts=None, safe_fallback=False):
    """Trả về prompt đã gắn chế độ. Nếu có prompt người dùng nhập (style), prompt đó là PROMPT CHÍNH;
    các nút Tạo thumb đẹp / Đổi dáng / Xoá logo là phụ."""
    opts = opts if opts is not None else (options_for(image_path) if image_path else load_all())
    style = str((opts or {}).get("style") or "").strip()
    if style and opts is not None:
        return _build_custom_primary_prompt(style, opts, safe_fallback=safe_fallback)

    if safe_fallback:
        if opts and bool(opts.get("nature_mode", False)):
            p = NATURE_WITH_TEXT_BASE_PROMPT if bool(opts.get("nature_add_text", False)) else NATURE_PURE_BASE_PROMPT
            ct = str(opts.get("nature_custom_text") or "").strip()
            if bool(opts.get("nature_add_text", False)) and ct:
                p += f' Render ONLY this exact channel name text cleanly on the thumbnail: "{ct}".'
        else:
            p = SAFE_FALLBACK_PROMPT
        return p
    if not opts:
        return base_prompt

    nature_mode = bool(opts.get("nature_mode", False))
    nature_custom_text = str(opts.get("nature_custom_text") or "").strip()
    nature_add_text = bool(opts.get("nature_add_text", False))
    artist_restyle = bool(opts.get("artist_restyle", True))
    variation = opts.get("variation", 30)

    if nature_mode:
        if nature_add_text:
            core_prompt = NATURE_WITH_TEXT_BASE_PROMPT
            if nature_custom_text:
                core_prompt += (
                    f' Render ONLY this exact channel/logo text cleanly on the thumbnail (such as in the corner): "{nature_custom_text}".'
                )
        else:
            core_prompt = NATURE_PURE_BASE_PROMPT
    elif artist_restyle:
        core_prompt = ARTIST_RESTYLE_BASE_PROMPT
    else:
        core_prompt = str(base_prompt or "").strip()

    parts = [core_prompt]
    parts.append(
        variation_text(
            variation,
            nature_mode=nature_mode,
            nature_add_text=nature_add_text,
            artist_restyle=artist_restyle,
        )
    )
    parts.append(
        "Keep the overall genre and mood coherent with the original image (colour feeling, atmosphere and visual quality)."
    )
    if opts.get("remove_logos"):
        if nature_mode and nature_add_text and nature_custom_text:
            parts.append(
                f'Clean up any small corner badges, stray corner icons, or unrelated small corner graphics so the layout is clean, keeping only the channel text "{nature_custom_text}".'
            )
        else:
            parts.append(LOGO_TEXT)
    return " ".join(p for p in parts if p)
