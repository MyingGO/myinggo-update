"""MyingGo • tuỳ chọn vẽ thumbnail dùng chung cho worker trình duyệt (Gemini web) và Gemini API.

File cấu hình: biến môi trường MYINGGO_THUMB_OPTIONS (JSON) do MyingGo ghi:
{
  "variation": 30,                 # % khác so với ảnh gốc (0-100) mặc định
  "remove_logos": true,            # xoá logo/watermark không liên quan trong ảnh gốc
  "folders": {                     # cấu hình riêng theo thư mục (Queue / thư mục con)
     "d:\\nhac\\latin": {"style": "neon cyberpunk", "variation": 60}
  }
}
Style để trống => giữ nguyên phong cách gốc. Không có file => giữ nguyên prompt gốc (tương thích 3T Master).
"""
import json
import os
import time
from pathlib import Path

_CACHE = {"path": "", "mtime": 0.0, "data": None, "checked": 0.0}


def options_path():
    return str(os.environ.get("MYINGGO_THUMB_OPTIONS") or "").strip()


def load_all():
    p = options_path()
    if not p:
        return None
    now = time.time()
    if _CACHE["path"] == p and now - _CACHE["checked"] < 2.0:
        return _CACHE["data"]
    _CACHE.update(path=p, checked=now)
    try:
        mt = os.path.getmtime(p)
        if _CACHE["data"] is not None and mt == _CACHE["mtime"]:
            return _CACHE["data"]
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        _CACHE.update(mtime=mt, data=data if isinstance(data, dict) else None)
    except Exception:
        _CACHE.update(data=None)
    return _CACHE["data"]


def _norm(p):
    return os.path.normcase(os.path.abspath(str(p))).rstrip("\\/")


def options_for(image_path, data=None):
    """Gộp cấu hình chung + cấu hình thư mục gần nhất (khớp tiền tố dài nhất)."""
    data = load_all() if data is None else data
    if not data:
        return None
    out = {"variation": data.get("variation", 30), "remove_logos": bool(data.get("remove_logos", True)), "style": ""}
    target = _norm(image_path)
    best, best_len = None, -1
    for key, cfg in (data.get("folders") or {}).items():
        k = _norm(key)
        if (target == k or target.startswith(k + os.sep)) and len(k) > best_len and isinstance(cfg, dict):
            best, best_len = cfg, len(k)
    if best:
        if str(best.get("style") or "").strip():
            out["style"] = str(best["style"]).strip()
        if best.get("variation") not in (None, ""):
            out["variation"] = best["variation"]
        if best.get("remove_logos") is not None:
            out["remove_logos"] = bool(best["remove_logos"])
    try:
        out["variation"] = max(0, min(100, int(out["variation"])))
    except Exception:
        out["variation"] = 30
    return out


def variation_text(v):
    v = int(v)
    if v <= 10:
        level = ("Make only MINIMAL changes: keep the background, composition, lighting and colour palette almost identical "
                 "to the original; only clean up and lightly refresh the typography.")
    elif v <= 30:
        level = ("Make SUBTLE changes: keep the same composition and overall look, refresh the background details and "
                 "typography slightly so it looks like a new version of the same design.")
    elif v <= 55:
        level = ("Make MODERATE changes: redesign the background and typography noticeably while keeping a similar layout "
                 "and mood.")
    elif v <= 80:
        level = ("Make STRONG changes: create a clearly different background, lighting and typography design; the layout "
                 "may change.")
    else:
        level = ("Make a COMPLETELY NEW design: a totally different background scene, lighting, colour palette and "
                 "typography; only the singer stays the same.")
    return f"Target roughly {v}% visual difference from the original image. {level}"


LOGO_TEXT = ("Before editing, scan the original image for unrelated logos, watermarks, channel badges, TV station marks, "
             "social media icons, URLs or brand marks (anything that is not part of the singer or the song title) and "
             "remove them completely, filling those areas naturally to match the surroundings.")


def build_prompt(base_prompt, image_path=None, opts=None):
    """Trả về prompt đã gắn % khác gốc + style + xoá logo. Không có cấu hình => trả nguyên base_prompt."""
    opts = opts if opts is not None else (options_for(image_path) if image_path else None)
    if not opts:
        return base_prompt
    parts = [str(base_prompt or "").strip()]
    parts.append(variation_text(opts.get("variation", 30)))
    style = str(opts.get("style") or "").strip()
    if style:
        parts.append(f"Apply this visual style to the background and typography: {style}.")
    else:
        parts.append("Keep the original visual style of the image (colour palette, mood, type of background and font "
                     "feeling); do not switch to a different art style.")
    if opts.get("remove_logos"):
        parts.append(LOGO_TEXT)
    return " ".join(p for p in parts if p)
