# -*- coding: utf-8 -*-
"""Small local HTTP/HTTPS proxy forwarder that authenticates to an upstream proxy.
Browser connects to 127.0.0.1 without auth, this process adds Proxy-Authorization upstream.
Used to avoid Chrome proxy auth popup in automated Chrome/Chrome for Testing.
"""
import argparse, base64, json, select, socket, socketserver, sys, threading, time

BUFFER = 65536

class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

class ProxyHandler(socketserver.BaseRequestHandler):
    upstream_host = ""
    upstream_port = 0
    auth_header = ""

    def _read_headers(self):
        data = b""
        self.request.settimeout(20)
        while b"\r\n\r\n" not in data and len(data) < 1024 * 1024:
            chunk = self.request.recv(8192)
            if not chunk:
                break
            data += chunk
        if not data:
            return b"", b""
        head, sep, rest = data.partition(b"\r\n\r\n")
        return head + sep, rest

    def _connect_upstream(self):
        s = socket.create_connection((self.upstream_host, int(self.upstream_port)), timeout=25)
        s.settimeout(None)
        return s

    def _tunnel(self, a, b, initial_b=b""):
        try:
            if initial_b:
                b.sendall(initial_b)
        except Exception:
            return
        sockets = [a, b]
        while True:
            try:
                r, _, _ = select.select(sockets, [], [], 60)
                if not r:
                    continue
                for s in r:
                    other = b if s is a else a
                    data = s.recv(BUFFER)
                    if not data:
                        return
                    other.sendall(data)
            except Exception:
                return

    def handle(self):
        try:
            header, rest = self._read_headers()
            if not header:
                return
            lines = header.split(b"\r\n")
            first = lines[0].decode("latin-1", "ignore")
            upstream = self._connect_upstream()
            if first.upper().startswith("CONNECT "):
                target = first.split(" ", 2)[1]
                req = (
                    f"CONNECT {target} HTTP/1.1\r\n"
                    f"Host: {target}\r\n"
                    f"Proxy-Authorization: {self.auth_header}\r\n"
                    f"Proxy-Connection: Keep-Alive\r\n"
                    f"Connection: Keep-Alive\r\n\r\n"
                ).encode("latin-1")
                upstream.sendall(req)
                resp = b""
                upstream.settimeout(25)
                while b"\r\n\r\n" not in resp and len(resp) < 1024 * 1024:
                    chunk = upstream.recv(8192)
                    if not chunk:
                        break
                    resp += chunk
                self.request.sendall(resp)
                if b" 200" in resp.split(b"\r\n", 1)[0]:
                    upstream.settimeout(None)
                    self._tunnel(self.request, upstream, rest)
                else:
                    try: upstream.close()
                    except Exception: pass
                return
            # Plain HTTP: forward original request but inject Proxy-Authorization.
            out_lines = []
            inserted = False
            for line in lines:
                if not line:
                    continue
                if line.lower().startswith(b"proxy-authorization:"):
                    if not inserted:
                        out_lines.append(("Proxy-Authorization: " + self.auth_header).encode("latin-1"))
                        inserted = True
                else:
                    out_lines.append(line)
            if not inserted:
                out_lines.insert(1, ("Proxy-Authorization: " + self.auth_header).encode("latin-1"))
            upstream.sendall(b"\r\n".join(out_lines) + b"\r\n\r\n" + rest)
            self._tunnel(self.request, upstream)
        except Exception:
            try:
                self.request.close()
            except Exception:
                pass

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--upstream-host", required=True)
    ap.add_argument("--upstream-port", required=True, type=int)
    ap.add_argument("--username", default="")
    ap.add_argument("--password", default="")
    ap.add_argument("--listen-host", default="127.0.0.1")
    ap.add_argument("--listen-port", default="0", type=int)
    ap.add_argument("--ready-file", default="")
    args = ap.parse_args()
    token = (args.username + ":" + args.password).encode("utf-8", "ignore")
    ProxyHandler.upstream_host = args.upstream_host
    ProxyHandler.upstream_port = int(args.upstream_port)
    ProxyHandler.auth_header = "Basic " + base64.b64encode(token).decode("ascii")
    with ThreadingTCPServer((args.listen_host, int(args.listen_port)), ProxyHandler) as srv:
        host, port = srv.server_address[:2]
        if args.ready_file:
            try:
                with open(args.ready_file, "w", encoding="utf-8") as f:
                    json.dump({"host": host, "port": int(port), "upstream": f"{args.upstream_host}:{args.upstream_port}"}, f)
            except Exception:
                pass
        print(json.dumps({"host": host, "port": int(port)}), flush=True)
        srv.serve_forever(poll_interval=0.5)

if __name__ == "__main__":
    main()
