"""AI Gateway dùng chung cho MyingGo / T2MG (ưu tiên 10Router OpenAI-compatible cục bộ).

- Lưu cấu hình riêng tại ai_gateway_config.json (tách biệt hoàn toàn với API miễn phí của Thumbnail Studio).
- Dùng chung cho Quản lý Kênh & Audio Studio và các công cụ mới trong tương lai thông qua:
    ai_gateway.chat_text(...) / ai_gateway.chat_json(...)
"""
from __future__ import annotations

import json
import re
import threading
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE = ROOT / "ai_gateway_config.json"
_LOCK = threading.RLock()

DEFAULTS = {
    "enabled": True,
    "base_url": "http://127.0.0.1:20128/v1",
    "api_keys": [],
    "model": "gemini-flash-latest",
    "direct_gemini_keys": [],
    "timeout_sec": 35,
}


def normalize_base_url(url: str) -> str:
    u = str(url or "").strip().rstrip("/")
    if not u:
        return "http://127.0.0.1:20128/v1"
    if not re.search(r"/v\d+(?:alpha|beta)?$", u, re.I):
        u = f"{u}/v1"
    return u


def _parse_keys(raw) -> list[str]:
    if isinstance(raw, str):
        items = re.split(r"[\r\n,;]+", raw)
    elif isinstance(raw, list):
        items = raw
    else:
        items = []
    out: list[str] = []
    for x in items:
        s = str(x or "").strip()
        if s and s not in out:
            out.append(s)
    return out


def is_google_key(k: str) -> bool:
    s = str(k or "").strip()
    return s.startswith("AIza") or s.startswith("AQ.")


GEMINI_FALLBACK_MODELS = ("gemini-3.5-flash", "gemini-flash-lite-latest", "gemini-flash-latest", "gemini-3.8-flash")
_LAST_GEMINI_MODEL = {"name": ""}
_ROUTER_MODELS_CACHE: dict = {"url": "", "ts": 0.0, "models": []}


def _router_models_cached(base_url: str, api_key: str = "") -> list[str]:
    import time as _t
    c = _ROUTER_MODELS_CACHE
    if c["url"] == base_url and c["models"] and _t.time() - c["ts"] < 300:
        return c["models"]
    try:
        models = list_models(base_url, api_key or None)
    except Exception:
        models = []
    c.update(url=base_url, ts=_t.time(), models=models)
    return models


def _pick_router_model(base_url: str, api_key: str, wanted: str) -> str:
    models = _router_models_cached(base_url, api_key)
    if not models or wanted in models:
        return wanted
    low = wanted.lower()
    for m in models:
        if m.lower().endswith("/" + low) or low in m.lower():
            return m
    for pref in ("flash", "turbo", "pro"):
        for m in models:
            if pref in m.lower():
                return m
    return models[0]


def _mask_key(k: str) -> str:
    s = str(k or "").strip()
    if len(s) <= 10:
        return "***" if s else ""
    return f"{s[:6]}…{s[-4:]}"


def load_config() -> dict:
    with _LOCK:
        cfg = dict(DEFAULTS)
        if CONFIG_FILE.is_file():
            try:
                raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    cfg.update(raw)
            except Exception:
                pass
        cfg["enabled"] = bool(cfg.get("enabled", True))
        cfg["base_url"] = normalize_base_url(cfg.get("base_url") or DEFAULTS["base_url"])
        all_keys = _parse_keys(cfg.get("api_keys"))
        direct = _parse_keys(cfg.get("direct_gemini_keys"))
        # Key Google AI Studio (AIza... / AQ....) không dùng được làm key 10Router -> tự chuyển sang Gemini trực tiếp
        cfg["api_keys"] = [k for k in all_keys if not is_google_key(k)]
        cfg["direct_gemini_keys"] = _parse_keys(direct + [k for k in all_keys if is_google_key(k)])
        cfg["model"] = str(cfg.get("model") or DEFAULTS["model"]).strip() or DEFAULTS["model"]
        try:
            cfg["timeout_sec"] = max(10, min(180, int(cfg.get("timeout_sec") or 35)))
        except Exception:
            cfg["timeout_sec"] = 35
        return {k: cfg[k] for k in DEFAULTS}


def public_config() -> dict:
    cfg = load_config()
    return {
        "enabled": cfg["enabled"],
        "base_url": cfg["base_url"],
        "model": cfg["model"],
        "timeout_sec": cfg["timeout_sec"],
        "api_keys_count": len(cfg["api_keys"]),
        "api_keys_masked": [_mask_key(k) for k in cfg["api_keys"]],
        "direct_gemini_count": len(cfg["direct_gemini_keys"]),
        "direct_gemini_masked": [_mask_key(k) for k in cfg["direct_gemini_keys"]],
    }


def save_config(patch: dict) -> dict:
    with _LOCK:
        cfg = load_config()
        if not isinstance(patch, dict):
            return cfg
        if "enabled" in patch:
            cfg["enabled"] = bool(patch["enabled"])
        if "base_url" in patch:
            cfg["base_url"] = normalize_base_url(patch["base_url"])
        if "model" in patch and str(patch["model"] or "").strip():
            cfg["model"] = str(patch["model"]).strip()
        if "timeout_sec" in patch:
            try:
                cfg["timeout_sec"] = max(10, min(180, int(patch["timeout_sec"] or 35)))
            except Exception:
                pass
        if "api_keys" in patch:
            cfg["api_keys"] = _parse_keys(patch["api_keys"])
        if "direct_gemini_keys" in patch:
            cfg["direct_gemini_keys"] = _parse_keys(patch["direct_gemini_keys"])
        CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return cfg


def _http_json(url: str, method: str = "GET", payload: dict | None = None, api_key: str = "", timeout: int = 25) -> dict:
    headers = {"Accept": "application/json"}
    data = None
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8", "replace")
        return json.loads(raw) if raw.strip() else {}


def list_models(base_url: str | None = None, api_key: str | None = None) -> list[str]:
    cfg = load_config()
    burl = normalize_base_url(base_url or cfg["base_url"])
    keys = _parse_keys(api_key) if api_key is not None and str(api_key).strip() else (cfg["api_keys"] or [""])
    last_err = ""
    for k in keys:
        try:
            d = _http_json(f"{burl}/models", method="GET", api_key=k, timeout=10)
            items = d.get("data") if isinstance(d, dict) else (d if isinstance(d, list) else [])
            models = sorted({str(x.get("id") if isinstance(x, dict) else x).strip() for x in (items or []) if x})
            return [m for m in models if m]
        except urllib.error.HTTPError as he:
            last_err = f"HTTP {he.code}"
        except Exception as e:
            last_err = str(e)
    raise RuntimeError(last_err or "Không kết nối được tới 10Router /models")


def _call_openai_compat(base_url: str, api_key: str, model: str, messages: list[dict], temperature: float, json_mode: bool, timeout: int) -> str:
    payload: dict = {
        "model": model,
        "messages": messages,
        "temperature": float(temperature),
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    try:
        res = _http_json(f"{base_url}/chat/completions", method="POST", payload=payload, api_key=api_key, timeout=timeout)
    except urllib.error.HTTPError as he:
        # Một số provider qua router không hỗ trợ response_format -> thử lại không có response_format
        if json_mode and he.code == 400:
            payload.pop("response_format", None)
            res = _http_json(f"{base_url}/chat/completions", method="POST", payload=payload, api_key=api_key, timeout=timeout)
        else:
            raise
    choices = res.get("choices") or []
    if not choices:
        raise RuntimeError(f"Gateway trả về rỗng: {str(res)[:200]}")
    msg = choices[0].get("message") or {}
    content = msg.get("content")
    if isinstance(content, list):
        content = "".join(str(p.get("text") or "") for p in content if isinstance(p, dict))
    return str(content or "").strip()


def _call_direct_gemini(api_key: str, model: str, prompt: str, system: str, temperature: float, json_mode: bool, timeout: int) -> str:
    m_name = model.split("/")[-1] if "/" in model else model
    candidates: list[str] = []
    if "gemini" in m_name.lower() and m_name not in ("gemini-2.5-flash",):
        candidates.append(m_name)
    candidates += [m for m in GEMINI_FALLBACK_MODELS if m not in candidates]
    body: dict = {
        "contents": [{"parts": [{"text": (f"{system}\n\n{prompt}" if system else prompt)}]}],
        "generationConfig": {"temperature": float(temperature)},
    }
    if json_mode:
        body["generationConfig"]["responseMimeType"] = "application/json"
    last_err: Exception | None = None
    per_call = max(12, min(int(timeout or 30), 30))
    for mn in candidates:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{mn}:generateContent?key={api_key}"
        try:
            res = _http_json(url, method="POST", payload=body, timeout=per_call)
            parts = (res.get("candidates") or [{}])[0].get("content", {}).get("parts", []) or []
            _LAST_GEMINI_MODEL["name"] = mn
            return "".join(str(p.get("text") or "") for p in parts if not p.get("thought")).strip()
        except urllib.error.HTTPError as he:
            last_err = he
            if he.code in (400, 404, 500, 503):  # model không khả dụng/quá tải -> thử model kế tiếp
                continue
            raise
        except (TimeoutError, OSError) as te:  # model phản hồi chậm -> chuyển sang model nhanh hơn
            last_err = te
            continue
    if last_err:
        raise last_err
    raise RuntimeError("Không có model Gemini khả dụng")


def chat_text(prompt: str, system: str = "", model: str | None = None, temperature: float = 0.3, json_mode: bool = False) -> tuple[str, dict]:
    """Gửi yêu cầu AI qua 10Router (ưu tiên) hoặc Direct Gemini dự phòng riêng của AI Gateway."""
    cfg = load_config()
    use_model = str(model or cfg["model"] or "gemini-2.5-flash").strip()
    timeout = int(cfg["timeout_sec"] or 35)
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    errors: list[str] = []
    # Chỉ gọi 10Router khi đã có API Key riêng của 10Router (tránh lỗi 401 Missing/Invalid API key)
    if cfg["enabled"] and cfg["base_url"] and cfg["api_keys"]:
        for k in cfg["api_keys"]:
            r_model = _pick_router_model(cfg["base_url"], k, use_model)
            try:
                txt = _call_openai_compat(cfg["base_url"], k, r_model, messages, temperature, json_mode, timeout)
                return txt, {"provider": "10router", "model": r_model, "base_url": cfg["base_url"]}
            except urllib.error.HTTPError as he:
                err_b = ""
                try:
                    err_b = he.read().decode("utf-8", "replace")[:180]
                except Exception:
                    pass
                errors.append(f"10Router HTTP {he.code}: {err_b or he.reason}")
                if he.code in (401, 403, 429, 502, 503):
                    continue
            except Exception as e:
                errors.append(f"10Router: {e}")

    for gk in cfg["direct_gemini_keys"]:
        try:
            txt = _call_direct_gemini(gk, use_model, prompt, system, temperature, json_mode, timeout)
            return txt, {"provider": "gemini_direct", "model": _LAST_GEMINI_MODEL["name"] or use_model}
        except urllib.error.HTTPError as he:
            err_b = ""
            try:
                err_b = he.read().decode("utf-8", "replace")[:160]
            except Exception:
                pass
            errors.append(f"Gemini HTTP {he.code}: {err_b or he.reason}")
        except Exception as e:
            errors.append(f"Gemini: {e}")

    if not errors:
        raise RuntimeError("Chưa có API Key nào. Vào tab '🔌 10Router AI' dán API Key (key 10Router hoặc key Google AI Studio đều được).")
    raise RuntimeError(" | ".join(errors[-2:]))


def chat_json(prompt: str, system: str = "", model: str | None = None, temperature: float = 0.25) -> tuple[dict, dict]:
    txt, meta = chat_text(prompt, system=system, model=model, temperature=temperature, json_mode=True)
    clean = txt.strip()
    if clean.startswith("```"):
        clean = re.sub(r"^```(?:json)?\s*|\s*```$", "", clean, flags=re.S).strip()
    try:
        parsed = json.loads(clean)
    except Exception:
        m = re.search(r"\{[\s\S]*\}", clean)
        if not m:
            raise RuntimeError(f"AI trả về không phải JSON hợp lệ: {clean[:180]}")
        parsed = json.loads(m.group(0))
    if not isinstance(parsed, dict):
        raise RuntimeError("AI trả về JSON không phải object.")
    return parsed, meta


def test_connection(base_url: str | None = None, api_key: str | None = None, model: str | None = None) -> dict:
    cfg = load_config()
    burl = normalize_base_url(base_url or cfg["base_url"])
    use_model = str(model or cfg["model"] or "gemini-flash-latest").strip()

    models: list[str] = []
    models_err = ""
    try:
        models = list_models(burl, cfg["api_keys"][0] if cfg["api_keys"] else "")
    except Exception as e:
        models_err = str(e)

    try:
        reply, meta = chat_text("Trả lời đúng 1 từ: OK", model=use_model, temperature=0.0)
        return {
            "ok": 1, "base_url": burl, "model": meta.get("model") or use_model,
            "provider": meta.get("provider"), "reply": reply[:80], "models": models,
        }
    except Exception as e:
        hint = ""
        if not cfg["api_keys"] and models:
            hint = " (10Router đang chạy nhưng chưa có API Key của 10Router — tạo key trong dashboard http://127.0.0.1:20128)"
        return {"ok": 0, "base_url": burl, "model": use_model, "models": models, "error": f"{e}{hint}" if str(e) else (models_err or "Không kết nối được")}
