"""Hệ thống cập nhật từ xa qua GitHub cho MyingGo:
- Máy chính (có master_publish.json chứa token): có nút '⬆️ Đẩy bản cập nhật' -> tự tăng version và đẩy gói code nhẹ lên GitHub.
- Máy phụ (hoặc mọi máy): có nút '🔄 Cập nhật' -> kiểm tra version trên GitHub, tải gói code nhẹ về bung đè (giữ nguyên cài đặt riêng) và nạp lại tính năng + nâng cấp nóng máy chủ ngay."""
from __future__ import annotations

import base64
import importlib
import io
import json
import re
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = ROOT / "version.json"
UPDATE_CONFIG_FILE = ROOT / "update_config.json"
MASTER_FILE = ROOT / "master_publish.json"

# Các thư mục/file code được đưa vào gói cập nhật nhẹ (~50-100 KB, không kèm bin/*.exe hay web/photocraft nặng)
CODE_DIRS = ("core", "features", "web", "addons")
CODE_ROOT_FILES = ("main.py", "make_logo.py", "MyingGo.bat", "requirements.txt", "README.md", "version.json", "update_config.json")
SKIP_NAMES = {"__pycache__", "downloader_config.json", "youwee_config.json", "photocraft", "filmcraft", "effectcraft", "trash_logs", "yugioh_config.json"}
PRESERVE_ON_CLIENT = {"settings.json", "features/downloader_config.json", "master_publish.json", "ai_fill_config.json", "yugioh_config.json"}


def get_version_info() -> dict:
    default = {"version": "1.0.1", "build": 1, "updated_at": ""}
    if VERSION_FILE.is_file():
        try:
            default.update(json.loads(VERSION_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return default


def get_update_config() -> dict:
    cfg = {"repo": "", "branch": "main"}
    if UPDATE_CONFIG_FILE.is_file():
        try:
            cfg.update(json.loads(UPDATE_CONFIG_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return cfg


def get_master_info() -> dict:
    if not MASTER_FILE.is_file():
        return {"is_master": False, "token": "", "repo": ""}
    try:
        d = json.loads(MASTER_FILE.read_text(encoding="utf-8"))
        tok = (d.get("token") or "").strip()
        return {"is_master": bool(tok), "token": tok, "repo": (d.get("repo") or "").strip()}
    except Exception:
        return {"is_master": False, "token": "", "repo": ""}


def _gh_request(url: str, token: str = "", method: str = "GET", body: dict | None = None) -> dict:
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "MyingGo-Updater",
    }
    if token:
        headers["Authorization"] = f"token {token}"
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=25) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else {}


def _ensure_repo_and_branch(token: str) -> tuple[str, str]:
    ucfg = get_update_config()
    minfo = get_master_info()
    repo = (minfo.get("repo") or ucfg.get("repo") or "").strip().strip("/")
    branch = (ucfg.get("branch") or "main").strip() or "main"

    if "/" not in repo:
        if not token:
            raise ValueError("Chưa xác định được tài khoản GitHub (thiếu owner/repo trong update_config.json). Hãy bấm '⬆️ Đẩy cập nhật' trên máy chính 1 lần trước.")
        user = _gh_request("https://api.github.com/user", token=token)
        owner = user["login"]
        repo_name = repo or "myinggo-update"
        repo = f"{owner}/{repo_name}"

    if token:
        try:
            rinfo = _gh_request(f"https://api.github.com/repos/{repo}", token=token)
            if rinfo.get("default_branch"):
                branch = rinfo["default_branch"]
        except urllib.error.HTTPError as e:
            if e.code == 404:
                repo_name = repo.split("/", 1)[1]
                created = _gh_request(
                    "https://api.github.com/user/repos",
                    token=token,
                    method="POST",
                    body={"name": repo_name, "private": False, "auto_init": True, "description": "MyingGo Auto Update"},
                )
                repo = created["full_name"]
                branch = created.get("default_branch") or "main"
            else:
                raise

    new_ucfg = dict(ucfg)
    new_ucfg["repo"] = repo
    new_ucfg["branch"] = branch
    if token:
        try:
            from core import ygo_data
            new_ucfg["ygo_sync_cipher"] = ygo_data.encode_sync_cipher(repo, branch, token)
        except Exception:
            pass
    UPDATE_CONFIG_FILE.write_text(json.dumps(new_ucfg, ensure_ascii=False, indent=2), encoding="utf-8")
    if MASTER_FILE.is_file():
        m = json.loads(MASTER_FILE.read_text(encoding="utf-8"))
        if m.get("repo") != repo:
            m["repo"] = repo
            MASTER_FILE.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
    return repo, branch


def _put_github_file(repo: str, branch: str, path: str, raw_bytes: bytes, message: str, token: str):
    url = f"https://api.github.com/repos/{repo}/contents/{path}"
    sha = None
    try:
        cur = _gh_request(f"{url}?ref={branch}", token=token)
        sha = cur.get("sha")
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
    body = {
        "message": message,
        "content": base64.b64encode(raw_bytes).decode("ascii"),
        "branch": branch,
    }
    if sha:
        body["sha"] = sha
    return _gh_request(url, token=token, method="PUT", body=body)


def _get_github_file(repo: str, branch: str, path: str, token: str = "") -> bytes:
    if token:
        url = f"https://api.github.com/repos/{repo}/contents/{path}?ref={branch}"
        info = _gh_request(url, token=token)
        if info.get("content"):
            return base64.b64decode(info["content"])
        if info.get("download_url"):
            req = urllib.request.Request(info["download_url"], headers={"User-Agent": "MyingGo-Updater"})
            with urllib.request.urlopen(req, timeout=25) as r:
                return r.read()
    raw_url = f"https://raw.githubusercontent.com/{repo}/{branch}/{path}?t={int(time.time())}"
    req = urllib.request.Request(raw_url, headers={"User-Agent": "MyingGo-Updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=25) as r:
        return r.read()


def _stamp_index_version(ver: str):
    """Đánh dấu ?v=<version> vào web/index.html để trình duyệt ở máy phụ luôn tải mới CSS/JS, không bao giờ dính cache cũ."""
    idx_file = ROOT / "web" / "index.html"
    if not idx_file.is_file():
        return
    try:
        txt = idx_file.read_text(encoding="utf-8")
        txt = re.sub(r'(/web/style\.css)(?:\?v=[^"\'>\s]+)?', rf'\1?v={ver}', txt)
        txt = re.sub(r'(/web/app\.js)(?:\?v=[^"\'>\s]+)?', rf'\1?v={ver}', txt)
        txt = re.sub(r'(/assets/logo\.png)(?:\?v=[^"\'>\s]+)?', rf'\1?v={ver}', txt)
        txt = re.sub(r'(<div class="ver-badge" id="ver-badge">)[^<]*(</div>)', rf'\g<1>v{ver}\2', txt)
        idx_file.write_text(txt, encoding="utf-8")
    except Exception:
        pass


def build_patch_bytes() -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for dname in CODE_DIRS:
            dpath = ROOT / dname
            if not dpath.is_dir():
                continue
            for p in dpath.rglob("*"):
                if not p.is_file() or p.suffix in (".pyc", ".old"):
                    continue
                if set(p.relative_to(ROOT).parts) & SKIP_NAMES or p.name in SKIP_NAMES:
                    continue
                # addons/*: chỉ gửi code engine, KHÔNG gửi profile Chrome / kho tài khoản / log sinh ra khi chạy
                if dname == "addons" and not (p.suffix == ".py" or p.name == "app_version.json") :
                    continue
                if dname == "addons" and len(p.relative_to(dpath).parts) > 2:
                    continue
                rel = p.relative_to(ROOT).as_posix()
                z.write(p, rel)
        for fname in CODE_ROOT_FILES:
            fpath = ROOT / fname
            if fpath.is_file():
                z.write(fpath, fname)
        for asset_name in ("logo.png", "logo.ico", "artcraft.png", "photocraft.png", "filmcraft.png", "effectcraft.png", "yugioh_combo.png"):
            ap = ROOT / "assets" / asset_name
            if ap.is_file():
                z.write(ap, f"assets/{asset_name}")
    return buf.getvalue()


def publish_update(note: str = "") -> dict:
    minfo = get_master_info()
    if not minfo["is_master"]:
        raise ValueError("Máy này không có quyền máy chính (thiếu master_publish.json).")
    token = minfo["token"]
    repo, branch = _ensure_repo_and_branch(token)

    vinfo = get_version_info()
    new_build = int(vinfo.get("build") or 0) + 1
    parts = str(vinfo.get("version") or "1.0.0").split(".")
    while len(parts) < 3:
        parts.append("0")
    parts[-1] = str(new_build)
    new_ver = ".".join(parts[:3])
    now_str = time.strftime("%Y-%m-%d %H:%M:%S")

    new_vinfo = {
        "version": new_ver,
        "build": new_build,
        "updated_at": now_str,
        "note": note or f"Cập nhật v{new_ver}",
    }
    VERSION_FILE.write_text(json.dumps(new_vinfo, ensure_ascii=False, indent=2), encoding="utf-8")
    _stamp_index_version(new_ver)

    patch_bytes = build_patch_bytes()
    msg = f"Release v{new_ver} ({now_str})"
    _put_github_file(repo, branch, "update_patch.zip", patch_bytes, msg, token)
    _put_github_file(repo, branch, "version.json", VERSION_FILE.read_bytes(), msg, token)

    return {
        "ok": 1,
        "repo": repo,
        "version": new_ver,
        "build": new_build,
        "size_kb": round(len(patch_bytes) / 1024, 1),
        "updated_at": now_str,
    }


def check_remote_version() -> dict:
    local = get_version_info()
    minfo = get_master_info()
    ucfg = get_update_config()
    repo = (ucfg.get("repo") or minfo.get("repo") or "").strip()
    branch = (ucfg.get("branch") or "main").strip() or "main"
    if "/" not in repo and minfo["is_master"]:
        try:
            repo, branch = _ensure_repo_and_branch(minfo["token"])
        except Exception:
            pass
    if "/" not in repo:
        return {"local": local, "remote": None, "has_update": False, "is_master": minfo["is_master"]}
    try:
        raw = _get_github_file(repo, branch, "version.json", token=minfo.get("token", ""))
        remote = json.loads(raw.decode("utf-8"))
        has_up = int(remote.get("build") or 0) > int(local.get("build") or 0)
        return {"local": local, "remote": remote, "has_update": has_up, "is_master": minfo["is_master"], "repo": repo}
    except Exception as e:
        return {"local": local, "remote": None, "has_update": False, "is_master": minfo["is_master"], "error": str(e)}


def hot_upgrade_runtime():
    """Nâng cấp nóng các module core.* và Handler của máy chủ đang chạy trong RAM trên máy phụ,
    để sau khi bấm Cập nhật không cần tắt mở lại app mà giao diện vẫn giống hệt máy chính 100%."""
    try:
        from core import base
        if not hasattr(base.Feature, "group"):
            base.Feature.group = None

        for mod_name in ("core.dialogs", "core.logger", "core.settings", "core.pack", "core.ai_fill", "core.ygo_data"):
            if mod_name in sys.modules:
                importlib.reload(sys.modules[mod_name])
            else:
                importlib.import_module(mod_name)

        srv_mod = sys.modules.get("core.server")
        if srv_mod is not None:
            # Đảm bảo các biến trạng thái mới có mặt trên module core.server đang chạy trong RAM
            if not hasattr(srv_mod, "SUB_PROCS"):
                srv_mod.SUB_PROCS = {}
            if not hasattr(srv_mod, "WIN_STATE"):
                srv_mod.WIN_STATE = {}

            # Đọc file core/server.py mới nhất trên đĩa vào namespace tạm (dùng chung FEATURES, STATE, SUB_PROCS, WIN_STATE)
            srv_file = ROOT / "core" / "server.py"
            if srv_file.is_file():
                ns = dict(vars(srv_mod))
                code = compile(srv_file.read_text(encoding="utf-8"), str(srv_file), "exec")
                exec(code, ns)
                # Giữ nguyên dict FEATURES/STATE đang sống
                ns["FEATURES"] = srv_mod.FEATURES
                ns["STATE"] = srv_mod.STATE
                ns["SUB_PROCS"] = srv_mod.SUB_PROCS
                ns["WIN_STATE"] = srv_mod.WIN_STATE
                for fn_name in ("running_state", "discover", "reload_features", "_browser_cmd", "open_sub_window"):
                    if fn_name in ns:
                        setattr(srv_mod, fn_name, ns[fn_name])
                new_handler = ns.get("Handler")
                old_handler = getattr(srv_mod, "Handler", None)
                if new_handler and old_handler:
                    for mname in ("do_GET", "do_POST", "_send", "_static"):
                        if hasattr(new_handler, mname):
                            setattr(old_handler, mname, getattr(new_handler, mname))
    except Exception:
        pass


def pull_and_apply_update() -> dict:
    minfo = get_master_info()
    ucfg = get_update_config()
    repo = (ucfg.get("repo") or minfo.get("repo") or "").strip()
    branch = (ucfg.get("branch") or "main").strip() or "main"
    if "/" not in repo:
        raise ValueError("Chưa có thông tin kho cập nhật (repo). Hãy lấy bản đóng gói từ máy chính đã đẩy cập nhật ít nhất 1 lần.")

    patch_bytes = _get_github_file(repo, branch, "update_patch.zip", token=minfo.get("token", ""))
    updated_files = 0
    with zipfile.ZipFile(io.BytesIO(patch_bytes), "r") as z:
        for member in z.infolist():
            rel = member.filename.replace("\\", "/").lstrip("/")
            if not rel or rel.endswith("/") or ".." in rel.split("/"):
                continue
            if rel in PRESERVE_ON_CLIENT:
                continue
            dst = ROOT / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(z.read(member))
            updated_files += 1

    vinfo = get_version_info()
    _stamp_index_version(str(vinfo.get("version") or "1.0.4"))
    hot_upgrade_runtime()
    return {
        "ok": 1,
        "version": vinfo.get("version"),
        "build": vinfo.get("build"),
        "updated_files": updated_files,
    }


def status() -> dict:
    local = get_version_info()
    minfo = get_master_info()
    ucfg = get_update_config()
    return {
        "version": local.get("version", "1.0.1"),
        "build": local.get("build", 1),
        "updated_at": local.get("updated_at", ""),
        "is_master": minfo["is_master"],
        "repo": ucfg.get("repo") or minfo.get("repo") or "",
    }
