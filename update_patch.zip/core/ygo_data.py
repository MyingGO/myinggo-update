"""Kho dữ liệu Yu-Gi-Oh offline cho MyingGo: toàn bộ lá bài (kèm Konami ID, tên phụ, Alt Art),
đầy đủ Banlist chuẩn xác (TCG, OCG, OCG Asian-English AE, Master Duel, World, Genesys, OCG-CN, Edison, GOAT),
gói bản in đặc biệt (Overframe / Manga YAC1 / OCG), bộ bài, archetype, sách luật chính thức và hình lá bài.
Lưu trong 1 thư mục có thể đặt sang ổ khác (ví dụ F:\\anhYGO) để không tốn ổ C:."""
from __future__ import annotations

import base64
import hashlib
import json
import re
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE = ROOT / "yugioh_config.json"
API = "https://db.ygoprodeck.com/api/v7"
RULEBOOK_HUB = "https://www.yugioh-card.com/en/rulebook/index.html"
RULEBOOK_FALLBACK = "https://img.yugioh-card.com/en/downloads/rulebook/SD_RuleBook_EN_10.pdf"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 MyingGo-YGO/1.2"}

YAML_YUGI_BASE = "https://dawnbrandbots.github.io/yaml-yugi-limit-regulation"
IGNIS_LFLIST_BASE = "https://raw.githubusercontent.com/ProjectIgnis/LFLists/master"
EDISON_LFLIST_URLS = (
    "https://raw.githubusercontent.com/termitaklk/lflist/master/2010.03%20Edison(Pre%20Errata).lflist.conf",
    "https://raw.githubusercontent.com/termitaklk/lflist/main/2010.03%20Edison(Pre%20Errata).lflist.conf",
)
KONAMI_AE_URL = "https://www.yugioh-card.com/asia/play/forbidden-and-limited-list-ae/"

BANLIST_FORMATS = (
    ("tcg", "TCG (Quốc tế)"),
    ("ocg", "OCG (Nhật / Châu Á)"),
    ("ae", "OCG Asian-English (AE)"),
    ("md", "Master Duel"),
    ("world", "World Championship"),
    ("genesys", "Genesys"),
    ("ocg_cn", "OCG China (CN)"),
    ("edison", "Edison (2010.03)"),
    ("goat", "GOAT (2005)"),
)

WIKI_APIS = (
    "https://yugioh.fandom.com/api.php",
    "https://yugipedia.com/api.php",
)
SPECIAL_GALLERIES = (
    ("Limit Over Collection: The Heroes", "Set Card Galleries:Limit Over Collection: The Heroes (OCG-JP)"),
    ("Limit Over Collection: The Rivals", "Set Card Galleries:Limit Over Collection: The Rivals (OCG-JP)"),
    ("Original Artwork Collection (YAC1)", "Set Card Galleries:Original Artwork Collection (OCG-JP)"),
    ("Quarter Century Art Collection", "Set Card Galleries:Quarter Century Art Collection (OCG-JP)"),
)


def _load_ygo_cfg() -> dict:
    if CONFIG_FILE.is_file():
        try:
            d = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(d, dict):
                return d
        except Exception:
            pass
    return {}


def _save_ygo_cfg(cfg: dict) -> dict:
    cur = _load_ygo_cfg()
    cur.update(cfg)
    CONFIG_FILE.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")
    return cur


def data_dir() -> Path:
    d = ROOT / "data" / "yugioh"
    p = (_load_ygo_cfg().get("dir") or "").strip()
    if p:
        d = Path(p)
    d.mkdir(parents=True, exist_ok=True)
    return d


def set_data_dir(path: str) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    _save_ygo_cfg({"dir": str(p)})
    return p


def _get(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _get_json(url: str, timeout: int = 120):
    return json.loads(_get(url, timeout).decode("utf-8"))


def _write_json(path: Path, obj):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    tmp.replace(path)


_VI_LOCK = threading.Lock()
_VI_MEM_CACHE: dict[str, str] | None = None
_VI_MEM_DIR: Path | None = None


def load_vi_translations() -> dict[str, str]:
    global _VI_MEM_CACHE, _VI_MEM_DIR
    d = data_dir()
    with _VI_LOCK:
        if _VI_MEM_CACHE is not None and _VI_MEM_DIR == d:
            return _VI_MEM_CACHE
        vf = d / "vi_translations.json"
        loaded: dict[str, str] = {}
        if vf.is_file():
            try:
                raw = json.loads(vf.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    loaded = {str(k): str(v) for k, v in raw.items() if v}
            except Exception:
                loaded = {}
        _VI_MEM_CACHE = loaded
        _VI_MEM_DIR = d
        return _VI_MEM_CACHE


def save_vi_translation(cid, text: str) -> str:
    key = str(cid).strip()
    clean = (text or "").strip()
    if not key:
        return clean
    cache = load_vi_translations()
    with _VI_LOCK:
        if clean:
            cache[key] = clean
        else:
            cache.pop(key, None)
        _write_json(data_dir() / "vi_translations.json", cache)
    return clean


_YGO_PRE_SUBS: tuple[tuple[re.Pattern, str], ...] = tuple(
    (re.compile(pat, flags), rep)
    for pat, rep, flags in (
        (r"\[\s*Pendulum Effect\s*\]", "[ Hiệu ứng Pendulum ]", re.I),
        (r"\[\s*Monster Effect\s*\]", "[ Hiệu ứng Quái thú ]", re.I),
        (r"\[\s*Flavor Text\s*\]", "[ Mô tả ]", 0),
        (r"\(\s*Quick Effect\s*\)", "(Hiệu ứng Nhanh)", re.I),
        (r"\bSpell\s*/\s*Trap\s+Cards?\b", "Bài Phép/Bẫy", 0),
        (r"\bSpell\s+or\s+Trap\s+Cards?\b", "Bài Phép hoặc Bẫy", 0),
        (r"\bSpells?\s*/\s*Traps?\b", "Phép/Bẫy", 0),
        (r"\bQuick-Play\s+Spell(?:\s+Cards?)?\b", "Phép Nhanh", 0),
        (r"\bContinuous\s+Spell(?:\s+Cards?)?\b", "Phép Vĩnh cửu", 0),
        (r"\bEquip\s+Spell(?:\s+Cards?)?\b", "Phép Trang bị", 0),
        (r"\bField\s+Spell(?:\s+Cards?)?\b", "Phép Môi trường", 0),
        (r"\bRitual\s+Spell(?:\s+Cards?)?\b", "Phép Nghi thức", 0),
        (r"\bNormal\s+Spell(?:\s+Cards?)?\b", "Phép Thường", 0),
        (r"\bContinuous\s+Trap(?:\s+Cards?)?\b", "Bẫy Vĩnh cửu", 0),
        (r"\bCounter\s+Trap(?:\s+Cards?)?\b", "Bẫy Phản kích", 0),
        (r"\bNormal\s+Trap(?:\s+Cards?)?\b", "Bẫy Thường", 0),
        (r"\bSpell\s+Cards?\b", "Bài Phép", 0),
        (r"\bTrap\s+Cards?\b", "Bài Bẫy", 0),
        (r"\bSpell\s*&\s*Trap\s+Zones?\b", "Vùng Phép & Bẫy", 0),
        (r"\bMain\s+Monster\s+Zones?\b", "Vùng Quái thú Chính", 0),
        (r"\bExtra\s+Monster\s+Zones?\b", "Vùng Quái thú Extra", 0),
        (r"\bPendulum\s+Zones?\b", "Vùng Pendulum", 0),
        (r"\bField\s+Zones?\b", "Vùng Môi trường", 0),
        (r"\bSpells\b", "Bài Phép", 0),
        (r"\bSpell\b", "Bài Phép", 0),
        (r"\bTraps\b", "Bài Bẫy", 0),
        (r"\bTrap\b", "Bài Bẫy", 0),
        (r"\bSpecial\s+Summons?\b", "Triệu hồi Đặc biệt", re.I),
        (r"\bSpecial\s+Summoned\b", "được Triệu hồi Đặc biệt", re.I),
        (r"\bSpecial\s+Summoning\b", "việc Triệu hồi Đặc biệt", re.I),
        (r"\bNormal\s+Summon\s*/\s*Set\b", "Triệu hồi Thường/Úp", re.I),
        (r"\bNormal\s+Summons?\b", "Triệu hồi Thường", re.I),
        (r"\bNormal\s+Summoned\b", "được Triệu hồi Thường", re.I),
        (r"\bFlip\s+Summons?\b", "Triệu hồi Lật", re.I),
        (r"\bFlip\s+Summoned\b", "được Triệu hồi Lật", re.I),
        (r"\bTribute\s+Summons?\b", "Triệu hồi Hiến tế", re.I),
        (r"\bTribute\s+Summoned\b", "được Triệu hồi Hiến tế", re.I),
        (r"\bRitual\s+Summons?\b", "Triệu hồi Nghi thức", re.I),
        (r"\bRitual\s+Summoned\b", "được Triệu hồi Nghi thức", re.I),
        (r"\bFusion\s+Summons?\b", "Triệu hồi Dung hợp", re.I),
        (r"\bFusion\s+Summoned\b", "được Triệu hồi Dung hợp", re.I),
        (r"\bSynchro\s+Summons?\b", "Triệu hồi Synchro", re.I),
        (r"\bSynchro\s+Summoned\b", "được Triệu hồi Synchro", re.I),
        (r"\bXyz\s+Summons?\b", "Triệu hồi Xyz", re.I),
        (r"\bXyz\s+Summoned\b", "được Triệu hồi Xyz", re.I),
        (r"\bLink\s+Summons?\b", "Triệu hồi Link", re.I),
        (r"\bLink\s+Summoned\b", "được Triệu hồi Link", re.I),
        (r"\bPendulum\s+Summons?\b", "Triệu hồi Pendulum", re.I),
        (r"\bPendulum\s+Summoned\b", "được Triệu hồi Pendulum", re.I),
        (r"\bGraveyards?\b", "Mộ", 0),
        (r"\bGYs?\b", "Mộ", 0),
        (r"\bface-down\s+Defense\s+Position\b", "tư thế Thủ úp", re.I),
        (r"\bface-up\s+Attack\s+Position\b", "tư thế Công ngửa", re.I),
        (r"\bface-up\s+Defense\s+Position\b", "tư thế Thủ ngửa", re.I),
        (r"\bAttack\s+Position\b", "tư thế Công", re.I),
        (r"\bDefense\s+Position\b", "tư thế Thủ", re.I),
        (r"\bface-down\b", "úp", re.I),
        (r"\bface-up\b", "ngửa", re.I),
        (r"\bbanished\b", "bị trục xuất", re.I),
        (r"\bbanishes\b", "trục xuất", re.I),
        (r"\bbanishing\b", "trục xuất", re.I),
        (r"\bbanish\b", "trục xuất", re.I),
        (r"\bTributed\b", "được Hiến tế", 0),
        (r"\bTributing\b", "Hiến tế", 0),
        (r"\bTributes?\b", "Hiến tế", 0),
        (r"\bdetach\b", "tách", re.I),
        (r"\bexcavate\b", "lật mở kiểm tra", re.I),
        (r"\bpiercing\s+battle\s+damage\b", "sát thương xuyên thủ", re.I),
        (r"\bon\s+the\s+field\b", "trên sân", re.I),
        (r"\bon\s+either\s+field\b", "trên sân hai bên", re.I),
        (r"\bfrom\s+the\s+field\b", "từ trên sân", re.I),
        (r"\bleaves?\s+the\s+field\b", "rời sân", re.I),
        (r"\bleft\s+the\s+field\b", "đã rời sân", re.I),
        (r"\bSet\s+(?=(?:this|that|it|them|1|2|3|up\s+to)\b)", "Úp ", 0),
        (r"(^|[.:;]\s*)Target\s+", r"\1Chỉ định ", 0),
        (r"(:\s*)target\s+", r"\1chỉ định ", 0),
    )
)


def prepare_ygo_en_for_vi(desc: str) -> tuple[str, list[str]]:
    """Bảo vệ tên lá bài/archetype trong ngoặc kép và thay thế thuật ngữ Yu-Gi-Oh! dễ dịch sai."""
    quotes: list[str] = []

    def _stash(m: re.Match) -> str:
        idx = len(quotes)
        quotes.append(m.group(0))
        return f"ZXQ{idx}X"

    text = desc or ""
    # Bảo vệ cả tên bài có ngoặc kép lồng bên trong như ""A" Cell..." hoặc "Maxx "C""
    text = re.sub(r'""[^"\r\n]{1,60}"[^"\r\n]{0,60}"', _stash, text)
    text = re.sub(r'"[^"\r\n]{1,60}"[^"\r\n]{1,30}""', _stash, text)
    text = re.sub(r'"[^"\r\n]{1,90}"', _stash, text)
    for rx, rep in _YGO_PRE_SUBS:
        text = rx.sub(rep, text)
    return text, quotes


def restore_ygo_vi(vi_text: str, quotes: list[str]) -> str:
    def _unstash(m: re.Match) -> str:
        idx = int(m.group(1))
        return quotes[idx] if 0 <= idx < len(quotes) else m.group(0)

    out = re.sub(r"ZXQ\s*(\d+)\s*X", _unstash, vi_text or "", flags=re.I)
    out = re.sub(r"[ \t]+([,.;:!?])", r"\1", out)
    return out.strip()


def translate_card_vi(cid, desc: str, force: bool = False) -> dict:
    key = str(cid or "").strip()
    src = (desc or "").strip()
    if not src:
        return {"ok": 1, "vi": "", "source": "empty"}
    cache = load_vi_translations()
    if key and not force and key in cache:
        return {"ok": 1, "vi": cache[key], "source": "cache"}

    pre_text, quotes = prepare_ygo_en_for_vi(src)
    try:
        q = urllib.parse.quote(pre_text)
        url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=vi&dt=t&q={q}"
        data = _get_json(url, timeout=12)
        parts = [seg[0] for seg in (data[0] or []) if seg and seg[0]]
        vi_raw = "".join(parts)
        vi_clean = restore_ygo_vi(vi_raw, quotes)
        if not vi_clean:
            return {"ok": 0, "offline": 1}
        if key:
            save_vi_translation(key, vi_clean)
        return {"ok": 1, "vi": vi_clean, "source": "cloud"}
    except Exception as e:
        return {"ok": 0, "offline": 1, "reason": str(e)}


def load_special_arts() -> dict:
    sf = data_dir() / "special_arts.json"
    if sf.is_file():
        try:
            data = json.loads(sf.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def save_special_arts(data: dict):
    _write_json(data_dir() / "special_arts.json", data)


def load_banlists_meta() -> list[dict]:
    bf = data_dir() / "banlists_meta.json"
    if bf.is_file():
        try:
            data = json.loads(bf.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
        except Exception:
            pass
    return []


def status() -> dict:
    d = data_dir()
    meta = {}
    mf = d / "meta.json"
    if mf.is_file():
        try:
            meta = json.loads(mf.read_text(encoding="utf-8"))
        except Exception:
            pass
    img_dir = d / "images" / "small"
    var_dir = d / "images" / "variants"
    cus_dir = d / "images" / "custom"
    n_img = sum(1 for _ in img_dir.glob("*.jpg")) if img_dir.is_dir() else 0
    n_var = (sum(1 for _ in var_dir.glob("*.*")) if var_dir.is_dir() else 0) + (sum(1 for _ in cus_dir.glob("*.*")) if cus_dir.is_dir() else 0)
    sp = load_special_arts()
    n_sp = sum(len(v) for v in sp.values() if isinstance(v, list))
    size = sum(p.stat().st_size for p in d.rglob("*") if p.is_file())
    rb = sorted(d.glob("rulebook*.pdf"))
    bmeta = load_banlists_meta()
    bl_names = [m["id"] for m in bmeta] if bmeta else sorted(p.stem.replace("banlist_", "") for p in d.glob("banlist_*.json"))
    return {
        "dir": str(d),
        "has_cards": (d / "cards.json").is_file(),
        "cards": meta.get("cards", 0),
        "alt_arts": meta.get("alt_arts", 0),
        "special_arts": n_sp,
        "variant_files": n_var,
        "db_version": meta.get("db_version", ""),
        "updated_at": meta.get("updated_at", ""),
        "images": n_img,
        "size_mb": round(size / 1048576, 1),
        "rulebook": rb[-1].name if rb else "",
        "banlists": bl_names,
        "banlists_meta": bmeta,
        "vi_translations": len(load_vi_translations()),
    }


def remote_version() -> dict:
    j = _get_json(f"{API}/checkDBVer.php", 30)
    return j[0] if isinstance(j, list) and j else (j or {})


def _norm_alnum(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _limit_to_status(lim: int) -> str:
    if lim <= 0:
        return "Forbidden"
    if lim == 1:
        return "Limited"
    if lim == 2:
        return "Semi-Limited"
    return "Unlimited"


def _status_to_limit(st) -> int | None:
    if isinstance(st, (int, float)):
        v = int(st)
        return v if 0 <= v <= 3 else None
    s = str(st or "").strip().lower()
    if s in ("0", "forbidden", "banned", "ban"):
        return 0
    if s in ("1", "limited", "limit"):
        return 1
    if s in ("2", "semi-limited", "semi limited", "semilimited", "semi"):
        return 2
    if s in ("3", "unlimited", "unrestricted"):
        return 3
    return None


def _build_card_lookups(cards: list[dict]):
    by_pass = {}
    by_kid = {}
    by_name = {}
    for c in cards:
        cid = c.get("id")
        if cid is not None:
            by_pass[int(cid)] = c
        for iid in c.get("img") or []:
            if iid is not None and int(iid) not in by_pass:
                by_pass[int(iid)] = c
        kid = c.get("kid")
        if kid is not None:
            try:
                by_kid[int(kid)] = c
            except Exception:
                pass
        for nm in (c.get("name"), c.get("beta")):
            nk = _norm_alnum(nm or "")
            if nk and nk not in by_name:
                by_name[nk] = c
    return by_pass, by_kid, by_name


def _resolve_card(identifier, by_pass: dict, by_kid: dict, by_name: dict, prefer_kid: bool = False):
    if identifier is None:
        return None
    s = str(identifier).strip()
    if not s:
        return None
    if s.isdigit():
        num = int(s)
        if prefer_kid or num < 200000:
            return by_kid.get(num) or by_pass.get(num)
        return by_pass.get(num) or by_kid.get(num)
    return by_name.get(_norm_alnum(s))


def _parse_yaml_yugi_vector(j: dict, by_pass: dict, by_kid: dict, by_name: dict, is_genesys: bool = False) -> tuple[dict, str]:
    """Đọc định dạng current.vector.json của DawnbrandBots/yaml-yugi-limit-regulation (khóa 'regulation' ánh xạ Konami ID -> 0/1/2 hoặc điểm Genesys)."""
    out = {}
    eff = str(j.get("date") or j.get("effectiveDate") or j.get("effective_date") or j.get("name") or "")

    # Trường hợp 1: dict ánh xạ Konami ID -> số lượng cho phép (0/1/2) hoặc điểm (Genesys)
    vec = None
    for dict_key in ("regulation", "vector", "limits", "points", "cards"):
        if isinstance(j.get(dict_key), dict):
            vec = j.get(dict_key)
            break
    if vec is None:
        digit_items = {k: v for k, v in j.items() if str(k).isdigit()}
        if digit_items:
            vec = digit_items

    is_points = (
        is_genesys
        or str(j.get("type") or j.get("mode") or "").lower() == "points"
        or ("genesys" in str(j.get("format") or "").lower())
        or (isinstance(vec, dict) and any(isinstance(v, (int, float)) and v > 3 for v in vec.values()))
    )

    if isinstance(vec, dict):
        for raw_k, raw_v in vec.items():
            c = _resolve_card(raw_k, by_pass, by_kid, by_name, prefer_kid=True)
            if not c:
                continue
            if is_points and isinstance(raw_v, (int, float)):
                pts = int(raw_v)
                if pts < 0:
                    out[str(c["id"])] = {"name": c["name"], "status": "Forbidden", "limit": 0}
                elif pts > 0:
                    out[str(c["id"])] = {"name": c["name"], "status": f"{pts} pts", "limit": 3, "points": pts}
                continue
            lim = _status_to_limit(raw_v)
            if lim is None or lim >= 3:
                continue
            out[str(c["id"])] = {"name": c["name"], "status": _limit_to_status(lim), "limit": lim}

    # Trường hợp 2: mảng theo nhóm forbidden / limited / semiLimited
    for key_name, lim in (("forbidden", 0), ("banned", 0), ("limited", 1), ("semiLimited", 2), ("semi_limited", 2), ("semi-limited", 2)):
        arr = j.get(key_name)
        if isinstance(arr, list):
            for item in arr:
                ident = item.get("id") or item.get("konamiId") or item.get("password") or item.get("name") if isinstance(item, dict) else item
                c = _resolve_card(ident, by_pass, by_kid, by_name, prefer_kid=True)
                if c:
                    out[str(c["id"])] = {"name": c["name"], "status": _limit_to_status(lim), "limit": lim}
    return out, eff


def _parse_lflist_conf(text: str, by_pass: dict, by_kid: dict, by_name: dict) -> tuple[dict, str]:
    """Đọc section đầu tiên (mới nhất) của file .lflist.conf chuẩn EDOPro / YGOPro."""
    out = {}
    header = ""
    started = False
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("!"):
            if started:
                break  # dừng ở banlist kế tiếp (cũ hơn)
            started = True
            header = line[1:].strip()
            continue
        if line.startswith("#"):
            if not header and line.startswith("#[") and line.endswith("]"):
                header = line[2:-1].strip()
            continue
        if not started and header:
            started = True
        m = re.match(r"^(\d+)\s+(-?\d+)(?:\s*--\s*(.+))?$", line)
        if not m:
            continue
        started = True
        code, lim_str, comment = m.group(1), m.group(2), (m.group(3) or "").strip()
        lim = int(lim_str)
        if lim < 0 or lim >= 3:
            continue
        c = _resolve_card(code, by_pass, by_kid, by_name, prefer_kid=False)
        if not c and comment:
            c = _resolve_card(comment, by_pass, by_kid, by_name, prefer_kid=False)
        if c:
            out[str(c["id"])] = {"name": c["name"], "status": _limit_to_status(lim), "limit": lim}
    return out, header


def _parse_konami_ae_html(html: str, by_pass: dict, by_kid: dict, by_name: dict) -> tuple[dict, str]:
    """Dự phòng quét trực tiếp trang Forbidden & Limited List (AE) chính thức của Konami Asia."""
    out = {}
    m_date = re.search(r"(?:Effective|Updated)[^0-9]*(\d{4}[./-]\d{1,2}[./-]\d{1,2}|[A-Z][a-z]+ \d{1,2}, \d{4})", html, re.I)
    eff = m_date.group(1) if m_date else ""
    # Tách theo tiêu đề Forbidden / Limited / Semi-Limited
    sections = re.split(r"(?i)<h[1-4][^>]*>\s*(Forbidden|Limited|Semi-Limited)[^<]*</h[1-4]>", html)
    if len(sections) >= 3:
        for i in range(1, len(sections) - 1, 2):
            sec_type = sections[i].strip().lower()
            lim = 0 if "forbidden" in sec_type else (2 if "semi" in sec_type else 1)
            body = sections[i + 1]
            for cid in re.findall(r"cid=(\d+)", body):
                c = by_kid.get(int(cid))
                if c:
                    out[str(c["id"])] = {"name": c["name"], "status": _limit_to_status(lim), "limit": lim}
            for td_name in re.findall(r"<td[^>]*class=[\"'][^\"']*name[^\"']*[\"'][^>]*>(.*?)</td>", body, re.S | re.I):
                plain = re.sub(r"<[^>]+>", "", td_name).strip()
                c = _resolve_card(plain, by_pass, by_kid, by_name)
                if c:
                    out[str(c["id"])] = {"name": c["name"], "status": _limit_to_status(lim), "limit": lim}
    return out, eff


def _fetch_cards_raw(log) -> list[dict]:
    log("⬇ Đang tải toàn bộ kho bài + Konami ID + Alt Art từ YGOPRODeck (misc=yes)...")
    raw = _get_json(f"{API}/cardinfo.php?misc=yes", 300)
    cards = raw.get("data", [])
    if not cards:
        raise RuntimeError("API không trả về lá bài nào")
    compact = []
    extra_arts = 0
    for c in cards:
        imgs = c.get("card_images") or [{}]
        img_ids = [i.get("id") for i in imgs if i.get("id")]
        if len(img_ids) > 1:
            extra_arts += len(img_ids) - 1
        misc = (c.get("misc_info") or [{}])[0]
        rec = {
            "id": c.get("id"),
            "kid": misc.get("konami_id"),
            "name": c.get("name"),
            "type": c.get("type"),
            "frameType": c.get("frameType"),
            "desc": c.get("desc"),
            "atk": c.get("atk"),
            "def": c.get("def"),
            "level": c.get("level"),
            "race": c.get("race"),
            "attribute": c.get("attribute"),
            "archetype": c.get("archetype"),
            "linkval": c.get("linkval"),
            "scale": c.get("scale"),
            "linkmarkers": c.get("linkmarkers"),
            "sets": [{"n": s.get("set_name"), "c": s.get("set_code"), "r": s.get("set_rarity")} for s in (c.get("card_sets") or [])],
            "img": img_ids,
            "small": imgs[0].get("image_url_small"),
            "big": imgs[0].get("image_url"),
            "crop": imgs[0].get("image_url_cropped"),
        }
        if misc.get("beta_name") and misc.get("beta_name") != c.get("name"):
            rec["beta"] = misc.get("beta_name")
        if misc.get("treated_as"):
            rec["alias"] = misc.get("treated_as")
        compact.append(rec)
    _write_json(data_dir() / "cards.json", compact)
    log(f"✔ Đã lưu {len(compact)} lá bài (kèm Konami ID + {extra_arts} Alt Art).")
    return compact


def update_banlists(log, cards: list[dict] | None = None) -> list[dict]:
    """Cập nhật toàn bộ các hệ Banlist chuẩn xác: TCG, OCG, AE (Asian-English), Master Duel, World, Genesys, OCG-CN, Edison, GOAT."""
    d = data_dir()
    cf = d / "cards.json"
    if cards is None:
        if not cf.is_file():
            cards = _fetch_cards_raw(log)
        else:
            cards = json.loads(cf.read_text(encoding="utf-8"))
            # Nếu bản cards.json cũ chưa có trường Konami ID (kid), tự nâng cấp để map chuẩn 100% banlist AE/MD/TCG/OCG
            if cards and not any(c.get("kid") for c in cards[:50]):
                log("🔄 Nâng cấp kho bài bổ sung Konami ID để ánh xạ chuẩn xác Banlist AE / Master Duel / OCG / TCG...")
                cards = _fetch_cards_raw(log)

    by_pass, by_kid, by_name = _build_card_lookups(cards)
    meta_list = []

    def save_fmt(fmt_id: str, label: str, ban_map: dict, eff: str, source: str):
        if not ban_map:
            return False
        _write_json(d / f"banlist_{fmt_id}.json", ban_map)
        c_forb = sum(1 for v in ban_map.values() if v.get("limit") == 0)
        c_lim = sum(1 for v in ban_map.values() if v.get("limit") == 1)
        c_semi = sum(1 for v in ban_map.values() if v.get("limit") == 2)
        c_pts = sum(1 for v in ban_map.values() if v.get("points"))
        info = {
            "id": fmt_id,
            "label": label,
            "effective": eff,
            "source": source,
            "forbidden": c_forb,
            "limited": c_lim,
            "semi": c_semi,
            "points_cards": c_pts,
            "total": len(ban_map),
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        meta_list.append(info)
        detail = f"{c_pts} lá tính điểm" if c_pts and not (c_forb or c_lim or c_semi) else f"Cấm {c_forb} • Limit {c_lim} • Semi {c_semi}"
        log(f"✔ Banlist {label}{f' [{eff}]' if eff else ''}: {len(ban_map)} lá ({detail})")
        return True

    # 1. Các format từ YAML-Yugi (tự động đồng bộ từ Konami DB hằng ngày) + fallback ProjectIgnis / Konami / YGOPRODeck
    yaml_sources = [
        ("tcg", "TCG (Quốc tế)", f"{YAML_YUGI_BASE}/tcg/current.vector.json", f"{IGNIS_LFLIST_BASE}/0TCG.lflist.conf", "tcg"),
        ("ocg", "OCG (Nhật / Châu Á)", f"{YAML_YUGI_BASE}/ocg/current.vector.json", f"{IGNIS_LFLIST_BASE}/OCG.lflist.conf", "ocg"),
        ("ae", "OCG Asian-English (AE)", f"{YAML_YUGI_BASE}/ocg-ae/current.vector.json", "", ""),
        ("md", "Master Duel", f"{YAML_YUGI_BASE}/master-duel/current.vector.json", "", ""),
        ("genesys", "Genesys", f"{YAML_YUGI_BASE}/genesys/current.vector.json", "", ""),
        ("ocg_cn", "OCG China (CN)", f"{YAML_YUGI_BASE}/ocg-cn/current.vector.json", "", ""),
    ]

    for fmt_id, label, yaml_url, lflist_url, ygopro_fmt in yaml_sources:
        ban_map, eff, src_used = {}, "", ""
        # Ưu tiên 1: YAML-Yugi official Konami DB vector
        if yaml_url:
            try:
                j = _get_json(yaml_url, 40)
                ban_map, eff = _parse_yaml_yugi_vector(j, by_pass, by_kid, by_name, is_genesys=(fmt_id == "genesys"))
                src_used = "Konami DB (YAML-Yugi)"
            except Exception as e:
                log(f"   [Thử nguồn phụ cho {fmt_id.upper()}: {e}]")
        # Ưu tiên 2: ProjectIgnis EDOPro .lflist.conf (cho TCG/OCG nếu YAML-Yugi thiếu hoặc cần bổ sung)
        if not ban_map and lflist_url:
            try:
                txt = _get(lflist_url, 40).decode("utf-8", "ignore")
                ban_map, eff = _parse_lflist_conf(txt, by_pass, by_kid, by_name)
                src_used = "ProjectIgnis LFLists"
            except Exception:
                pass
        # Ưu tiên riêng cho AE: quét trang Konami Asia nếu cần
        if not ban_map and fmt_id == "ae":
            try:
                html = _get(KONAMI_AE_URL, 40).decode("utf-8", "ignore")
                ban_map, eff = _parse_konami_ae_html(html, by_pass, by_kid, by_name)
                src_used = "Konami Asia Official"
            except Exception:
                pass
        # Ưu tiên 3: YGOPRODeck API (chuẩn hóa Forbidden -> limit 0)
        if not ban_map and ygopro_fmt:
            try:
                j = _get_json(f"{API}/cardinfo.php?banlist={ygopro_fmt}", 90)
                for c in j.get("data", []):
                    raw_st = (c.get("banlist_info") or {}).get(f"ban_{ygopro_fmt}")
                    lim = _status_to_limit(raw_st)
                    if lim is not None and lim < 3:
                        ban_map[str(c["id"])] = {"name": c.get("name"), "status": _limit_to_status(lim), "limit": lim}
                src_used = "YGOPRODeck"
            except Exception:
                pass
        if not save_fmt(fmt_id, label, ban_map, eff, src_used):
            log(f"[CẢNH BÁO] Chưa lấy được Banlist {label}")

    # 2. World Championship & GOAT từ ProjectIgnis LFLists
    for fmt_id, label, fname, ygopro_fallback in (
        ("world", "World Championship", "World.lflist.conf", ""),
        ("goat", "GOAT (2005)", "GOAT.lflist.conf", "goat"),
    ):
        ban_map, eff, src_used = {}, "", ""
        try:
            txt = _get(f"{IGNIS_LFLIST_BASE}/{fname}", 40).decode("utf-8", "ignore")
            ban_map, eff = _parse_lflist_conf(txt, by_pass, by_kid, by_name)
            src_used = "ProjectIgnis LFLists"
        except Exception:
            pass
        if not ban_map and ygopro_fallback:
            try:
                j = _get_json(f"{API}/cardinfo.php?banlist={ygopro_fallback}", 90)
                for c in j.get("data", []):
                    raw_st = (c.get("banlist_info") or {}).get(f"ban_{ygopro_fallback}")
                    lim = _status_to_limit(raw_st)
                    if lim is not None and lim < 3:
                        ban_map[str(c["id"])] = {"name": c.get("name"), "status": _limit_to_status(lim), "limit": lim}
                src_used = "YGOPRODeck"
            except Exception:
                pass
        save_fmt(fmt_id, label, ban_map, eff, src_used)

    # 3. Edison (2010.03)
    ed_map, ed_eff = {}, "2010.03"
    for ed_url in EDISON_LFLIST_URLS:
        try:
            txt = _get(ed_url, 30).decode("utf-8", "ignore")
            ed_map, ed_eff = _parse_lflist_conf(txt, by_pass, by_kid, by_name)
            if ed_map:
                save_fmt("edison", "Edison (2010.03)", ed_map, ed_eff or "2010.03", "Edison LFList")
                break
        except Exception:
            continue

    if meta_list:
        _write_json(d / "banlists_meta.json", meta_list)
    return meta_list


def update_cards(log) -> dict:
    d = data_dir()
    compact = _fetch_cards_raw(log)
    extra_arts = sum(max(0, len(c.get("img") or []) - 1) for c in compact)

    for fname, url in (("cardsets.json", f"{API}/cardsets.php"), ("archetypes.json", f"{API}/archetypes.php")):
        try:
            _write_json(d / fname, _get_json(url, 60))
            log(f"✔ Đã lưu {fname}")
        except Exception as e:
            log(f"[LỖI] {fname}: {e}")

    update_banlists(log, cards=compact)

    try:
        ver = remote_version()
    except Exception:
        ver = {}
    meta = {
        "cards": len(compact),
        "alt_arts": extra_arts,
        "db_version": ver.get("database_version", ""),
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "remote_update": ver.get("last_update", ""),
    }
    _write_json(d / "meta.json", meta)
    return meta


def _classify_wiki_filename(fname: str) -> tuple[str, str, int]:
    """Phân loại tên file ảnh Wiki/Yugipedia -> (tag, label, priority). Priority càng nhỏ càng ưu tiên lên đầu."""
    clean = re.sub(r"^File:", "", fname, flags=re.I)
    stem = Path(clean).stem
    parts = stem.split("-")
    set_code = parts[1].upper() if len(parts) > 1 else ""
    rest = "-".join(parts[2:]).upper() if len(parts) > 2 else ""
    up = stem.upper()

    if any(x in up for x in ("-OFR", "OVERFRAME", "-GMR", "-ORR")) or (set_code in ("LOCH", "LOCR") and ("OFR" in rest or "GMR" in rest or "UR" in rest or "PSER" in rest)):
        tag = "overframe"
        lbl = f"Overframe ({set_code or 'Special'})" + (" • Grand Master" if "GMR" in up else "")
        return tag, lbl, 1
    if set_code == "YAC1" or "MANGA" in up:
        if "MC" in parts or "COLOR" in up:
            return "manga", "Manga Color (YAC1)", 2
        if "M" in parts or "MR" in parts or "MONO" in up:
            return "manga", "Manga B&W (YAC1)", 2
        return "manga", f"Original Art ({set_code or 'YAC1'})", 3
    if "LART" in set_code:
        return "alt", f"Lost Art ({set_code})", 4
    if set_code in ("QCAC", "QCCP", "QCCU", "PAC1", "RC04", "RA02", "RA03", "RA04", "YAP1", "MVP1", "JMPS", "JUMP", "WJMP", "25LP"):
        return "alt", f"Collector Alt ({set_code} {rest[:8]})".strip(), 5
    return "print", f"{set_code} {rest[:10]}".strip() or stem[:24], 10


def _wiki_gallery_images(page_titles: list[str], timeout: int = 25) -> list[dict]:
    """Lấy danh sách ảnh bản in lá bài từ trang Gallery của Yu-Gi-Oh! Wiki hoặc Yugipedia."""
    results = []
    seen = set()
    for api_base in WIKI_APIS:
        for title in page_titles:
            gimcontinue = ""
            for _ in range(4):
                params = {
                    "action": "query",
                    "titles": title,
                    "generator": "images",
                    "gimlimit": "100",
                    "prop": "imageinfo",
                    "iiprop": "url|size",
                    "format": "json",
                }
                if gimcontinue:
                    params["gimcontinue"] = gimcontinue
                url = f"{api_base}?{urllib.parse.urlencode(params)}"
                try:
                    j = _get_json(url, timeout=timeout)
                except Exception:
                    break
                pages = (j.get("query") or {}).get("pages") or {}
                for p in pages.values():
                    ftitle = p.get("title") or ""
                    if not ftitle or ftitle in seen:
                        continue
                    low = ftitle.lower()
                    if low.endswith((".svg", ".gif")) or "back-" in low or "booster" in low or "box" in low or "logo" in low:
                        continue
                    ii = (p.get("imageinfo") or [{}])[0]
                    img_url = ii.get("url") or ""
                    w = int(ii.get("width") or 0)
                    h = int(ii.get("height") or 0)
                    if not img_url or w < 130 or h < 180:
                        continue
                    ratio = h / max(1, w)
                    if not (1.22 <= ratio <= 1.65):
                        continue
                    seen.add(ftitle)
                    results.append({"file": ftitle, "url": img_url, "w": w, "h": h})
                cont = (j.get("continue") or {}).get("gimcontinue")
                if not cont:
                    break
                gimcontinue = cont
            if results:
                break
        if results:
            break
    return results


def cache_remote_variant(card_id: int | str, remote_url: str, label: str, tag: str = "alt", key: str = "") -> dict:
    """Tải 1 ảnh phiên bản đặc biệt về lưu offline trong images/variants/ và ghi vào special_arts.json."""
    d = data_dir()
    var_dir = d / "images" / "variants"
    var_dir.mkdir(parents=True, exist_ok=True)
    h = hashlib.sha1(remote_url.encode("utf-8")).hexdigest()[:12]
    ext = Path(urllib.parse.urlparse(remote_url).path).suffix.lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp"):
        ext = ".png"
    fname = f"{card_id}_{h}{ext}"
    fpath = var_dir / fname
    if not fpath.is_file():
        raw = _get(remote_url, timeout=35)
        if len(raw) < 512:
            raise RuntimeError("Ảnh tải về không hợp lệ")
        fpath.write_bytes(raw)
    local_url = f"/ygodata/images/variants/{fname}"
    entry = {
        "key": key or f"var_{h}",
        "label": label or "Variant Art",
        "tag": tag or "alt",
        "url": local_url,
        "remote_url": remote_url,
    }
    sp = load_special_arts()
    cid = str(card_id)
    arr = [x for x in sp.get(cid, []) if x.get("key") != entry["key"] and x.get("url") != local_url]
    arr.insert(0, entry)
    sp[cid] = arr
    save_special_arts(sp)
    return entry


def save_custom_art(card_id: int | str, filename: str, data_b64: str, label: str = "", tag: str = "custom") -> dict:
    """Lưu file ảnh tự chọn (Overframe / Manga / Custom) từ máy người dùng vào images/custom/."""
    d = data_dir()
    cus_dir = d / "images" / "custom"
    cus_dir.mkdir(parents=True, exist_ok=True)
    if "," in data_b64:
        data_b64 = data_b64.split(",", 1)[1]
    raw = base64.b64decode(data_b64)
    ext = Path(filename or "art.png").suffix.lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp"):
        ext = ".png"
    h = hashlib.sha1(raw).hexdigest()[:10]
    fname = f"{card_id}_custom_{h}{ext}"
    (cus_dir / fname).write_bytes(raw)
    local_url = f"/ygodata/images/custom/{fname}"
    entry = {
        "key": f"cus_{h}",
        "label": (label or Path(filename or "Custom Art").stem)[:36],
        "tag": tag or "custom",
        "url": local_url,
    }
    sp = load_special_arts()
    cid = str(card_id)
    arr = [x for x in sp.get(cid, []) if x.get("url") != local_url]
    arr.insert(0, entry)
    sp[cid] = arr
    save_special_arts(sp)
    return entry


def delete_special_art(card_id: int | str, key: str) -> list:
    sp = load_special_arts()
    cid = str(card_id)
    arr = [x for x in sp.get(cid, []) if x.get("key") != key]
    if arr:
        sp[cid] = arr
    else:
        sp.pop(cid, None)
    save_special_arts(sp)
    return arr


def fetch_card_gallery_variants(card_id: int | str, card_name: str, max_cache: int = 8) -> list[dict]:
    """Quét trực tiếp trang Card Gallery:<Tên lá bài> để lấy các bản in Overframe, Manga (YAC1), Alt Art, OCG/TCG."""
    norm_target = _norm_alnum(card_name)
    underscore = card_name.replace(" ", "_")
    imgs = _wiki_gallery_images([f"Card Gallery:{card_name}", f"Card_Gallery:{underscore}"], timeout=25)
    scored = []
    for item in imgs:
        clean = re.sub(r"^File:", "", item["file"], flags=re.I)
        prefix = _norm_alnum(clean.split("-", 1)[0])
        if norm_target and prefix and prefix != norm_target and not prefix.startswith(norm_target):
            continue
        tag, label, prio = _classify_wiki_filename(item["file"])
        scored.append((prio, -item["w"], tag, label, item["url"], clean))
    scored.sort(key=lambda x: (x[0], x[1]))

    chosen = []
    seen_labels = set()
    for prio, _, tag, label, rurl, clean in scored:
        if label in seen_labels:
            continue
        seen_labels.add(label)
        chosen.append((tag, label, rurl, clean))
        if len(chosen) >= max_cache:
            break

    saved = []
    for tag, label, rurl, clean in chosen:
        try:
            entry = cache_remote_variant(card_id, rurl, label=label, tag=tag, key="wiki_" + Path(clean).stem[:28])
            saved.append(entry)
        except Exception:
            continue
    sp = load_special_arts()
    return sp.get(str(card_id), saved)


def update_special_arts(log) -> dict:
    """Đồng bộ danh mục Overframe (Limit Over Collection), Manga Style (YAC1) & Collector Alt Arts từ Wiki/Yugipedia."""
    d = data_dir()
    cf = d / "cards.json"
    if not cf.is_file():
        raise RuntimeError("Chưa có cards.json. Hãy cập nhật kho bài trước.")
    cards = json.loads(cf.read_text(encoding="utf-8"))
    by_norm = {}
    for c in cards:
        nk = _norm_alnum(c.get("name") or "")
        if nk and nk not in by_norm:
            by_norm[nk] = c

    sp = load_special_arts()
    added = 0
    for set_label, gtitle in SPECIAL_GALLERIES:
        log(f"🎨 Đang quét bộ sưu tập: {set_label}...")
        imgs = _wiki_gallery_images([gtitle, gtitle.replace(" (OCG-JP)", "")], timeout=30)
        matched_set = 0
        for item in imgs:
            clean = re.sub(r"^File:", "", item["file"], flags=re.I)
            prefix = _norm_alnum(clean.split("-", 1)[0])
            card = by_norm.get(prefix)
            if not card:
                continue
            tag, label, prio = _classify_wiki_filename(item["file"])
            if prio > 5 and "YAC1" not in clean.upper() and "LOCH" not in clean.upper() and "LOCR" not in clean.upper():
                continue
            cid = str(card["id"])
            key = "wiki_" + Path(clean).stem[:28]
            cur_list = sp.setdefault(cid, [])
            if any(x.get("key") == key for x in cur_list):
                continue
            cur_list.append({
                "key": key,
                "label": label,
                "tag": tag,
                "url": "",
                "remote_url": item["url"],
            })
            matched_set += 1
            added += 1
        log(f"   ↳ Khớp {matched_set} phiên bản đặc biệt từ {set_label}.")

    save_special_arts(sp)
    log(f"✔ Đã lưu danh mục {sum(len(v) for v in sp.values())} bản in đặc biệt (mới thêm: {added}).")
    return {"added": added, "total": sum(len(v) for v in sp.values())}


def update_rulebook(log) -> str:
    d = data_dir()
    url = ""
    best = -1
    try:
        hub = _get(RULEBOOK_HUB, 30).decode("utf-8", "ignore")
        for m in re.findall(r'["\']([^"\']*[Rr]ule[Bb]ook[^"\']*EN[^"\']*\.pdf)["\']', hub):
            ver = re.findall(r"(\d+)\.pdf$", m)
            v = int(ver[0]) if ver else 0
            if v > best:
                best = v
                url = m if m.startswith("http") else urllib.request.urljoin(RULEBOOK_HUB, m)
    except Exception as e:
        log(f"[CẢNH BÁO] Không đọc được trang Rulebook: {e}")
    url = url or RULEBOOK_FALLBACK
    log(f"⬇ Đang tải sách luật: {url}")
    data = _get(url, 120)
    if not data.startswith(b"%PDF"):
        raise RuntimeError("File tải về không phải PDF")
    name = "rulebook_" + (Path(url).stem) + ".pdf"
    (d / name).write_bytes(data)
    log(f"✔ Đã lưu {name} ({round(len(data) / 1048576, 1)} MB)")
    return name


def download_images(log, stop_flag, progress) -> dict:
    d = data_dir()
    cf = d / "cards.json"
    if not cf.is_file():
        raise RuntimeError("Chưa có kho bài. Hãy cập nhật kho bài trước.")
    cards = json.loads(cf.read_text(encoding="utf-8"))
    out = d / "images" / "small"
    out.mkdir(parents=True, exist_ok=True)
    todo = []
    seen = set()
    for c in cards:
        for iid in c.get("img", []):
            if iid not in seen:
                seen.add(iid)
                if not (out / f"{iid}.jpg").is_file():
                    todo.append(iid)
    total = len(todo)
    log(f"🖼 Cần tải {total} hình (bao gồm mọi bản Alt Art chính thức; đã có sẵn: {len(seen) - total}).")
    done = fail = 0
    lock = threading.Lock()

    def job(iid):
        nonlocal done, fail
        if stop_flag():
            return
        try:
            data = _get(f"https://images.ygoprodeck.com/images/cards_small/{iid}.jpg", 30)
            (out / f"{iid}.jpg").write_bytes(data)
            ok = True
        except Exception:
            ok = False
        with lock:
            if ok:
                done += 1
            else:
                fail += 1
            progress((done + fail) / max(1, total) * 100, f"Hình {done + fail}/{total}")
        time.sleep(0.35)

    with ThreadPoolExecutor(max_workers=4) as ex:
        list(ex.map(job, todo))
    log(f"✔ Xong: tải {done} hình, lỗi {fail}." + (" (đã dừng)" if stop_flag() else ""))
    return {"done": done, "failed": fail}


# ---------- Đồng bộ tự động 2 chiều (Deck + Sơ đồ Combo + Art + Dịch VI) ----------
_SYNC_LOCK = threading.Lock()
_SYNC_XOR_KEY = b"MyingGo_YGO_Academy_CloudSync_2026"
_CLOUD_CACHE = {
    "etag": "",
    "sha": "",
    "workspace": None,
    "content_hash": "",
    "last_check": 0.0,
    "last_sync_at": "",
    "last_error": "",
}


def encode_sync_cipher(repo: str, branch: str, token: str) -> str:
    payload = json.dumps({"r": repo.strip(), "b": (branch or "main").strip(), "t": token.strip()}, separators=(",", ":")).encode("utf-8")
    xored = bytes(b ^ _SYNC_XOR_KEY[i % len(_SYNC_XOR_KEY)] for i, b in enumerate(payload))
    return "YGS1_" + xored.hex()


def decode_sync_cipher(cipher: str) -> dict:
    s = (cipher or "").strip()
    if s.startswith("YGS1_"):
        s = s[5:]
    try:
        raw = bytes.fromhex(s)
        dec = bytes(b ^ _SYNC_XOR_KEY[i % len(_SYNC_XOR_KEY)] for i, b in enumerate(raw))
        d = json.loads(dec.decode("utf-8"))
        if isinstance(d, dict) and d.get("t"):
            return {"repo": str(d.get("r") or ""), "branch": str(d.get("b") or "main"), "token": str(d.get("t") or "")}
    except Exception:
        pass
    return {}


def get_sync_credentials() -> dict:
    ycfg = _load_ygo_cfg()
    ucfg_file = ROOT / "update_config.json"
    m_file = ROOT / "master_publish.json"
    ucfg = {}
    if ucfg_file.is_file():
        try:
            ucfg = json.loads(ucfg_file.read_text(encoding="utf-8"))
        except Exception:
            ucfg = {}
    minfo = {}
    if m_file.is_file():
        try:
            minfo = json.loads(m_file.read_text(encoding="utf-8"))
        except Exception:
            minfo = {}

    repo = (ycfg.get("sync_repo") or minfo.get("repo") or ucfg.get("repo") or "").strip().strip("/")
    branch = (ycfg.get("sync_branch") or ucfg.get("branch") or "main").strip() or "main"
    token = (minfo.get("token") or "").strip()

    if not token:
        cipher = (ycfg.get("sync_cipher") or ucfg.get("ygo_sync_cipher") or "").strip()
        if cipher:
            dec = decode_sync_cipher(cipher)
            if dec.get("token"):
                token = dec["token"]
                if not repo and dec.get("repo"):
                    repo = dec["repo"]
                if dec.get("branch"):
                    branch = dec["branch"]

    # Nếu máy này có token gốc từ master_publish.json, tự động lưu bản mã hóa vào yugioh_config & update_config
    if token and repo:
        cipher = encode_sync_cipher(repo, branch, token)
        if ycfg.get("sync_cipher") != cipher:
            _save_ygo_cfg({"sync_cipher": cipher, "sync_repo": repo, "sync_branch": branch})
        if isinstance(ucfg, dict) and ucfg.get("ygo_sync_cipher") != cipher:
            try:
                ucfg["ygo_sync_cipher"] = cipher
                ucfg_file.write_text(json.dumps(ucfg, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

    return {
        "repo": repo,
        "branch": branch,
        "token": token,
        "cipher": encode_sync_cipher(repo, branch, token) if (repo and token) else "",
        "can_push": bool(repo and "/" in repo and token),
        "can_pull": bool(repo and "/" in repo),
        "auto_sync": bool(ycfg.get("auto_sync", True)),
    }


def configure_sync_key(raw_key: str, auto_sync: bool | None = None) -> dict:
    s = (raw_key or "").strip()
    updates: dict = {}
    if auto_sync is not None:
        updates["auto_sync"] = bool(auto_sync)
    if s:
        dec = decode_sync_cipher(s)
        if dec.get("token"):
            updates["sync_cipher"] = encode_sync_cipher(dec["repo"] or "MyingGO/myinggo-update", dec["branch"] or "main", dec["token"])
            if dec.get("repo"):
                updates["sync_repo"] = dec["repo"]
            if dec.get("branch"):
                updates["sync_branch"] = dec["branch"]
        elif s.startswith("ghp_") or s.startswith("github_pat_"):
            creds = get_sync_credentials()
            repo = creds.get("repo") or "MyingGO/myinggo-update"
            branch = creds.get("branch") or "main"
            updates["sync_cipher"] = encode_sync_cipher(repo, branch, s)
            updates["sync_repo"] = repo
            updates["sync_branch"] = branch
        else:
            raise ValueError("Mã đồng bộ không hợp lệ (hãy dán Mã đồng bộ YGS1_... hoặc GitHub Token).")
    if updates:
        _save_ygo_cfg(updates)
        _CLOUD_CACHE["etag"] = ""
        _CLOUD_CACHE["last_check"] = 0.0
    return get_sync_credentials()


def _is_empty_placeholder_deck(d: dict) -> bool:
    if not isinstance(d, dict):
        return True
    main = d.get("main") or []
    extra = d.get("extra") or []
    side = d.get("side") or []
    if main or extra or side:
        return False
    nm = str(d.get("name") or "").strip()
    return nm in ("", "Deck mới / New deck")


def _workspace_hash(ws: dict) -> str:
    if not isinstance(ws, dict):
        return ""
    core_obj = {
        "built_decks": ws.get("built_decks") or [],
        "maps": [m for m in (ws.get("maps") or []) if isinstance(m, dict) and not m.get("_seed")],
        "custom_acts": ws.get("custom_acts") or [],
        "art_prefs": ws.get("art_prefs") or {},
        "vi_custom": ws.get("vi_custom") or {},
        "deleted": ws.get("deleted") or {},
    }
    raw = json.dumps(core_obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha1(raw).hexdigest()


def merge_user_workspaces(w1: dict | None, w2: dict | None) -> dict:
    a = w1 if isinstance(w1, dict) else {}
    b = w2 if isinstance(w2, dict) else {}

    now_ms = int(time.time() * 1000)
    cutoff_ms = now_ms - 60 * 86400 * 1000  # giữ lịch sử xóa 60 ngày

    # 1. Gộp bảng đánh dấu xóa (deleted tombstones)
    deleted: dict[str, int] = {}
    for src in (a.get("deleted"), b.get("deleted")):
        if isinstance(src, dict):
            for k, ts in src.items():
                try:
                    ts_num = int(ts or 0)
                except Exception:
                    ts_num = 0
                if ts_num > cutoff_ms and ts_num > deleted.get(str(k), 0):
                    deleted[str(k)] = ts_num

    # 2. Gộp danh sách Deck (built_decks) theo ID + updatedAt
    decks_a = [d for d in (a.get("built_decks") or []) if isinstance(d, dict) and d.get("id")]
    decks_b = [d for d in (b.get("built_decks") or []) if isinstance(d, dict) and d.get("id")]
    has_real_deck = any(not _is_empty_placeholder_deck(d) for d in (decks_a + decks_b))

    deck_map: dict[str, dict] = {}
    deck_order: list[str] = []
    for d in decks_a + decks_b:
        did = str(d.get("id")).strip()
        if not did:
            continue
        if has_real_deck and _is_empty_placeholder_deck(d):
            continue
        upd = int(d.get("updatedAt") or 0)
        if deleted.get(did, 0) > upd:
            continue
        if did not in deck_map:
            deck_map[did] = d
            deck_order.append(did)
        else:
            prev = deck_map[did]
            p_upd = int(prev.get("updatedAt") or 0)
            if upd > p_upd:
                deck_map[did] = d
            elif upd == p_upd:
                c_len = len(d.get("main") or []) + len(d.get("extra") or []) + len(d.get("side") or [])
                p_len = len(prev.get("main") or []) + len(prev.get("extra") or []) + len(prev.get("side") or [])
                if c_len > p_len:
                    deck_map[did] = d

    merged_decks = [deck_map[did] for did in deck_order if did in deck_map]

    # 3. Gộp danh sách Sơ đồ Combo (maps) theo ID + updatedAt
    maps_a = [m for m in (a.get("maps") or []) if isinstance(m, dict) and m.get("id") and not m.get("_seed")]
    maps_b = [m for m in (b.get("maps") or []) if isinstance(m, dict) and m.get("id") and not m.get("_seed")]
    map_dict: dict[str, dict] = {}
    map_order: list[str] = []
    for m in maps_a + maps_b:
        mid = str(m.get("id")).strip()
        if not mid:
            continue
        upd = int(m.get("updatedAt") or 0)
        if deleted.get(mid, 0) > upd:
            continue
        if mid not in map_dict:
            map_dict[mid] = m
            map_order.append(mid)
        else:
            prev = map_dict[mid]
            p_upd = int(prev.get("updatedAt") or 0)
            if upd > p_upd:
                map_dict[mid] = m
            elif upd == p_upd:
                c_score = len(m.get("nodes") or []) + len(m.get("edges") or [])
                p_score = len(prev.get("nodes") or []) + len(prev.get("edges") or [])
                if c_score > p_score:
                    map_dict[mid] = m

    merged_maps = [map_dict[mid] for mid in map_order if mid in map_dict]

    # 4. Gộp danh sách Nhãn hành động riêng (custom_acts)
    merged_acts = []
    seen_acts = set()
    for act in (a.get("custom_acts") or []) + (b.get("custom_acts") or []):
        if not isinstance(act, dict) or not act.get("label"):
            continue
        key = (str(act.get("label") or "").strip(), str(act.get("sub") or "").strip(), str(act.get("kind") or "normal").strip())
        if key not in seen_acts:
            seen_acts.add(key)
            merged_acts.append({"label": key[0], "sub": key[1], "kind": key[2]})

    # 5. Gộp thiết lập Art mặc định & Bản dịch Tiếng Việt tự sửa
    art_prefs = {}
    if isinstance(b.get("art_prefs"), dict):
        art_prefs.update(b["art_prefs"])
    if isinstance(a.get("art_prefs"), dict):
        art_prefs.update(a["art_prefs"])

    vi_custom = {}
    if isinstance(b.get("vi_custom"), dict):
        vi_custom.update(b["vi_custom"])
    if isinstance(a.get("vi_custom"), dict):
        vi_custom.update(a["vi_custom"])

    out = {
        "version": 2,
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "built_decks": merged_decks,
        "maps": merged_maps,
        "custom_acts": merged_acts,
        "art_prefs": art_prefs,
        "vi_custom": vi_custom,
        "deleted": deleted,
    }
    out["content_hash"] = _workspace_hash(out)
    return out


def _workspace_file() -> Path:
    return data_dir() / "user_workspace.json"


def load_local_workspace() -> dict:
    wf = _workspace_file()
    if wf.is_file():
        try:
            d = json.loads(wf.read_text(encoding="utf-8"))
            if isinstance(d, dict):
                return d
        except Exception:
            pass
    return {}


def save_local_workspace(ws: dict):
    wf = _workspace_file()
    _write_json(wf, ws)


def _pull_cloud_workspace(creds: dict, force: bool = False) -> dict | None:
    if not creds.get("can_pull"):
        return None
    now = time.time()
    if not force and _CLOUD_CACHE["workspace"] is not None and (now - _CLOUD_CACHE["last_check"] < 6.0):
        return _CLOUD_CACHE["workspace"]

    repo = creds["repo"]
    branch = creds["branch"]
    token = creds.get("token") or ""
    path = "ygo_user_sync.json"

    try:
        if token:
            url = f"https://api.github.com/repos/{repo}/contents/{path}?ref={branch}"
            headers = {
                "Accept": "application/vnd.github+json",
                "User-Agent": "MyingGo-YGO-Sync",
                "Authorization": f"token {token}",
            }
            if _CLOUD_CACHE["etag"] and not force:
                headers["If-None-Match"] = _CLOUD_CACHE["etag"]
            req = urllib.request.Request(url, headers=headers, method="GET")
            try:
                with urllib.request.urlopen(req, timeout=15) as resp:
                    etag = resp.headers.get("ETag") or ""
                    info = json.loads(resp.read().decode("utf-8"))
                    sha = info.get("sha") or ""
                    raw_bytes = b""
                    if info.get("content"):
                        raw_bytes = base64.b64decode(info["content"])
                    elif info.get("download_url"):
                        raw_bytes = _get(info["download_url"], timeout=15)
                    ws = json.loads(raw_bytes.decode("utf-8")) if raw_bytes else {}
                    _CLOUD_CACHE.update(
                        etag=etag,
                        sha=sha,
                        workspace=ws,
                        content_hash=_workspace_hash(ws),
                        last_check=now,
                        last_sync_at=time.strftime("%H:%M:%S"),
                        last_error="",
                    )
                    return ws
            except urllib.error.HTTPError as he:
                if he.code == 304 and _CLOUD_CACHE["workspace"] is not None:
                    _CLOUD_CACHE["last_check"] = now
                    _CLOUD_CACHE["last_sync_at"] = time.strftime("%H:%M:%S")
                    _CLOUD_CACHE["last_error"] = ""
                    return _CLOUD_CACHE["workspace"]
                if he.code == 404:
                    _CLOUD_CACHE.update(etag="", sha="", workspace={}, content_hash="", last_check=now, last_error="")
                    return {}
                raise
        else:
            raw_url = f"https://raw.githubusercontent.com/{repo}/{branch}/{path}?t={int(now)}"
            req = urllib.request.Request(raw_url, headers={"User-Agent": "MyingGo-YGO-Sync", "Cache-Control": "no-cache"})
            try:
                with urllib.request.urlopen(req, timeout=15) as resp:
                    ws = json.loads(resp.read().decode("utf-8"))
                    _CLOUD_CACHE.update(
                        workspace=ws,
                        content_hash=_workspace_hash(ws),
                        last_check=now,
                        last_sync_at=time.strftime("%H:%M:%S"),
                        last_error="",
                    )
                    return ws
            except urllib.error.HTTPError as he:
                if he.code == 404:
                    return {}
                raise
    except Exception as e:
        _CLOUD_CACHE["last_error"] = str(e)
        return _CLOUD_CACHE["workspace"]


def _push_cloud_workspace(creds: dict, ws: dict) -> bool:
    if not creds.get("can_push"):
        return False
    repo = creds["repo"]
    branch = creds["branch"]
    token = creds["token"]
    path = "ygo_user_sync.json"
    url = f"https://api.github.com/repos/{repo}/contents/{path}"
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "MyingGo-YGO-Sync",
        "Authorization": f"token {token}",
        "Content-Type": "application/json",
    }

    sha = _CLOUD_CACHE.get("sha") or ""
    if not sha:
        try:
            req_get = urllib.request.Request(f"{url}?ref={branch}", headers=headers, method="GET")
            with urllib.request.urlopen(req_get, timeout=15) as r:
                info = json.loads(r.read().decode("utf-8"))
                sha = info.get("sha") or ""
        except urllib.error.HTTPError as he:
            if he.code != 404:
                raise

    raw_bytes = json.dumps(ws, ensure_ascii=False, indent=2).encode("utf-8")
    body = {
        "message": f"Sync YGO Decks ({len(ws.get('built_decks') or [])}) & Combos ({len(ws.get('maps') or [])})",
        "content": base64.b64encode(raw_bytes).decode("ascii"),
        "branch": branch,
    }
    if sha:
        body["sha"] = sha

    try:
        req_put = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="PUT")
        with urllib.request.urlopen(req_put, timeout=20) as resp:
            res_json = json.loads(resp.read().decode("utf-8"))
            new_sha = (res_json.get("content") or {}).get("sha") or ""
            _CLOUD_CACHE.update(
                etag="",
                sha=new_sha,
                workspace=ws,
                content_hash=_workspace_hash(ws),
                last_check=time.time(),
                last_sync_at=time.strftime("%H:%M:%S"),
                last_error="",
            )
            return True
    except urllib.error.HTTPError as he:
        if he.code == 409:
            # Xung đột SHA -> kéo bản mới về gộp lại rồi đẩy lần 2
            _CLOUD_CACHE["sha"] = ""
            _CLOUD_CACHE["etag"] = ""
            latest = _pull_cloud_workspace(creds, force=True)
            if latest:
                ws = merge_user_workspaces(ws, latest)
            return False
        _CLOUD_CACHE["last_error"] = f"HTTP {he.code}"
        return False
    except Exception as e:
        _CLOUD_CACHE["last_error"] = str(e)
        return False


def sync_user_workspace(client_ws: dict | None = None, mode: str = "auto", force_cloud: bool = False) -> dict:
    with _SYNC_LOCK:
        creds = get_sync_credentials()
        disk_ws = load_local_workspace()
        client_hash_before = _workspace_hash(client_ws) if isinstance(client_ws, dict) else ""

        # Bước 1: Gộp dữ liệu từ trình duyệt (client) và trên ổ đĩa (disk)
        merged = merge_user_workspaces(client_ws, disk_ws)

        # Bước 2: Kéo dữ liệu từ Cloud về và gộp chung (nếu bật đồng bộ hoặc người dùng bấm đồng bộ)
        cloud_ws = None
        if creds.get("can_pull") and (creds.get("auto_sync") or force_cloud or mode in ("pull", "push", "sync")):
            cloud_ws = _pull_cloud_workspace(creds, force=force_cloud)
            if isinstance(cloud_ws, dict) and cloud_ws:
                merged = merge_user_workspaces(merged, cloud_ws)

        merged_hash = _workspace_hash(merged)
        disk_hash = _workspace_hash(disk_ws)

        # Bước 3: Lưu xuống ổ đĩa nếu có thay đổi
        if merged_hash != disk_hash or not _workspace_file().is_file():
            save_local_workspace(merged)

        # Đồng bộ luôn các bản dịch Tiếng Việt tự sửa vào vi_translations.json
        vi_custom = merged.get("vi_custom") or {}
        if isinstance(vi_custom, dict) and vi_custom:
            cur_vi = load_vi_translations()
            for cid, vtxt in vi_custom.items():
                if vtxt and cur_vi.get(str(cid)) != str(vtxt):
                    save_vi_translation(cid, str(vtxt))

        # Bước 4: Đẩy bản đã gộp lên Cloud nếu có dữ liệu mới hơn trên máy này
        pushed = False
        cloud_hash = _CLOUD_CACHE.get("content_hash") or (_workspace_hash(cloud_ws) if cloud_ws else "")
        has_meaningful_data = bool(
            (merged.get("built_decks") and not all(_is_empty_placeholder_deck(d) for d in merged["built_decks"]))
            or merged.get("maps")
            or merged.get("custom_acts")
            or merged.get("art_prefs")
        )
        should_push = (
            creds.get("can_push")
            and (creds.get("auto_sync") or force_cloud or mode in ("push", "sync"))
            and has_meaningful_data
            and merged_hash != cloud_hash
        )
        if should_push:
            pushed = _push_cloud_workspace(creds, merged)

        return {
            "ok": 1,
            "workspace": merged,
            "content_hash": merged_hash,
            "changed_for_client": bool(client_hash_before and merged_hash != client_hash_before),
            "pushed": pushed,
            "sync_status": {
                "repo": creds.get("repo") or "",
                "can_push": creds.get("can_push", False),
                "can_pull": creds.get("can_pull", False),
                "auto_sync": creds.get("auto_sync", True),
                "cipher": creds.get("cipher") or "",
                "last_sync_at": _CLOUD_CACHE.get("last_sync_at") or time.strftime("%H:%M:%S"),
                "last_error": _CLOUD_CACHE.get("last_error") or "",
                "deck_count": len(merged.get("built_decks") or []),
                "map_count": len(merged.get("maps") or []),
            },
        }

