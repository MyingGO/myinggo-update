"""Lớp cơ sở cho mọi tính năng.

Thêm tính năng mới: tạo features/ten.py (+ features/ten.html là giao diện), class kế thừa Feature.
Các hàm `act_<tên>(self, data)` tự thành API: giao diện gọi MG.call(fid, "<tên>", data).
"""
import threading
from pathlib import Path


class Feature:
    title = "Tính năng"   # tên hiện ở menu bên trái
    order = 100           # số nhỏ hiện trước
    dock = "top"          # "top" = nút ở trên menu, "bottom" = nút ghim xuống đáy menu
    id = None             # tự lấy từ tên file

    def __init__(self):
        self._lines = []
        self._lock = threading.Lock()
        self.running = False

    # ---- giao diện ----
    def html(self, module_file):
        p = Path(module_file).with_suffix(".html")
        return p.read_text(encoding="utf-8") if p.is_file() else "<p>Chưa có giao diện.</p>"

    # ---- log + chạy nền ----
    def log(self, msg):
        with self._lock:
            self._lines.append(str(msg))

    def get_log(self, since=0):
        with self._lock:
            return {"lines": self._lines[since:], "next": len(self._lines), "running": self.running}

    def clear_log(self):
        with self._lock:
            self._lines.clear()

    def run_bg(self, fn, *args):
        if self.running:
            return False
        self.running = True

        def t():
            try:
                fn(*args)
            except Exception as e:  # noqa
                self.log(f"[LỖI] {e}")
            finally:
                self.running = False

        threading.Thread(target=t, daemon=True).start()
        return True
