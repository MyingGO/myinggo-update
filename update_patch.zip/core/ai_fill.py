"""Bộ nhân AI Generative Fill & Smart Object Remove cho PhotoCraft (MyingGo).
Hỗ trợ cả 3 tầng AI:
1. AI Miễn phí tích hợp sẵn (Không cần API Key):
   - Remove (Xóa vật thể): OpenCV Multi-Scale Inpainting + Patch Texture Synthesis (chạy Offline siêu tốc < 1s).
   - Generative Fill (Điền AI theo mô tả tiếng Việt/Anh): Kết nối cụm máy chủ HuggingFace Flux.1-Schnell / Flux-Merged / Qwen-Inpaint miễn phí (không cần Key) + Tự động tách nền chủ thể (GrabCut Matte) & hòa trộn ánh sáng vào ảnh gốc.
2. Google Gemini AI (Nano Banana / Gemini 2.5 Flash Image / Gemini 2.0 Flash):
   - Gửi trực tiếp ảnh vùng chọn + Mask + câu lệnh tiếng Việt lên Google Gemini API.
3. Đa cổng Cloud AI Pro (OpenAI DALL-E / GPT-Image-1 Inpaint & Stability AI SD3 Inpaint/Erase)."""
from __future__ import annotations

import base64
import io
import json
import random
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
AI_CONFIG_FILE = ROOT / "ai_fill_config.json"

DEFAULT_CONFIG = {
    "provider": "auto",          # "auto" | "free" | "gemini" | "openai" | "stability"
    "gemini_key": "",
    "gemini_model": "gemini-2.0-flash-exp-image-generation",
    "openai_key": "",
    "openai_model": "dall-e-2",
    "stability_key": "",
    "feather_px": 10,
    "auto_layer": True,
}


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if AI_CONFIG_FILE.is_file():
        try:
            saved = json.loads(AI_CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                cfg.update(saved)
        except Exception:
            pass
    return cfg


def save_config(patch: dict) -> dict:
    cfg = load_config()
    for k, v in (patch or {}).items():
        if k in DEFAULT_CONFIG:
            cfg[k] = v
    try:
        AI_CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return cfg


def _decode_b64_bytes(b64_str: str) -> bytes:
    if not b64_str:
        return b""
    if "," in b64_str and b64_str.lstrip().startswith("data:"):
        b64_str = b64_str.split(",", 1)[1]
    return base64.b64decode(b64_str)


def _encode_png_b64(rgba_arr: np.ndarray) -> str:
    pil_img = Image.fromarray(rgba_arr)
    buf = io.BytesIO()
    pil_img.save(buf, format="PNG", optimize=False)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


def _pil_from_bytes(raw: bytes) -> Image.Image | None:
    if not raw:
        return None
    try:
        im = Image.open(io.BytesIO(raw))
        im.load()
        return im.convert("RGBA")
    except Exception:
        return None


def translate_vi_to_en(text: str) -> str:
    """Dịch nhanh câu lệnh tiếng Việt sang tiếng Anh để các mô hình Flux / Stable Diffusion hiểu chính xác 100%."""
    text = (text or "").strip()
    if not text:
        return ""
    try:
        q = urllib.parse.quote(text)
        url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q={q}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode("utf-8"))
            translated = "".join(part[0] for part in data[0] if part and part[0])
            return translated.strip() or text
    except Exception:
        return text


def find_document_rect_on_screen(
    screen_rgba: np.ndarray | None,
    doc_rgba: np.ndarray | None,
    canvas_css_w: int,
    canvas_css_h: int,
    hint_rect: dict | None = None,
) -> tuple[float, float, float, float]:
    """Xác định tọa độ (vx, vy, vw, vh) của tài liệu gốc trên khung màn hình #photocraft_canvas."""
    if hint_rect and hint_rect.get("w", 0) > 20 and hint_rect.get("h", 0) > 20:
        return (
            float(hint_rect["x"]),
            float(hint_rect["y"]),
            float(hint_rect["w"]),
            float(hint_rect["h"]),
        )

    left_pad = min(48.0, canvas_css_w * 0.06)
    top_pad = min(68.0, canvas_css_h * 0.10)
    right_pad = min(268.0, canvas_css_w * 0.24) if canvas_css_w > 700 else 12.0
    bottom_pad = min(26.0, canvas_css_h * 0.05)

    work_x = left_pad
    work_y = top_pad
    work_w = max(100.0, canvas_css_w - left_pad - right_pad)
    work_h = max(100.0, canvas_css_h - top_pad - bottom_pad)

    if doc_rgba is None:
        return (0.0, 0.0, float(canvas_css_w), float(canvas_css_h))

    doc_h, doc_w = doc_rgba.shape[:2]

    if screen_rgba is not None and screen_rgba.shape[0] > 80 and screen_rgba.shape[1] > 80:
        sh, sw = screen_rgba.shape[:2]
        scale_x = canvas_css_w / float(sw)
        scale_y = canvas_css_h / float(sh)

        wx1 = int(max(0, work_x / scale_x - 10))
        wy1 = int(max(0, work_y / scale_y - 10))
        wx2 = int(min(sw, (work_x + work_w) / scale_x + 20))
        wy2 = int(min(sh, (work_y + work_h) / scale_y + 10))
        roi = screen_rgba[wy1:wy2, wx1:wx2]

        if roi.shape[0] > 40 and roi.shape[1] > 40:
            roi_gray = cv2.cvtColor(roi, cv2.COLOR_RGBA2GRAY)
            doc_gray = cv2.cvtColor(doc_rgba, cv2.COLOR_RGBA2GRAY)

            ds = max(1.0, max(roi_gray.shape) / 360.0)
            roi_small = cv2.resize(
                roi_gray,
                (max(20, int(roi_gray.shape[1] / ds)), max(20, int(roi_gray.shape[0] / ds))),
            )
            rh, rw = roi_small.shape[:2]

            fit_scale = min(rw / float(doc_w), rh / float(doc_h))
            best_score = -1.0
            best_box = None

            for factor in np.linspace(0.55, 1.18, 18):
                s = fit_scale * factor
                tw = int(round(doc_w * s))
                th = int(round(doc_h * s))
                if tw < 24 or th < 24 or tw >= rw or th >= rh:
                    continue
                tpl = cv2.resize(doc_gray, (tw, th), interpolation=cv2.INTER_AREA)
                res = cv2.matchTemplate(roi_small, tpl, cv2.TM_CCOEFF_NORMED)
                _, max_val, _, max_loc = cv2.minMaxLoc(res)
                if max_val > best_score:
                    best_score = max_val
                    best_box = (max_loc[0], max_loc[1], tw, th)

            if best_score > 0.52 and best_box is not None:
                bx, by, bw, bh = best_box
                vx = (wx1 + bx * ds) * scale_x
                vy = (wy1 + by * ds) * scale_y
                vw = (bw * ds) * scale_x
                vh = (bh * ds) * scale_y
                return (float(vx), float(vy), float(vw), float(vh))

    margin = 0.90
    scale = min((work_w * margin) / float(doc_w), (work_h * margin) / float(doc_h))
    vw = doc_w * scale
    vh = doc_h * scale
    vx = work_x + (work_w - vw) * 0.5
    vy = work_y + (work_h - vh) * 0.5
    return (float(vx), float(vy), float(vw), float(vh))


def inpaint_remove_local(rgb_crop: np.ndarray, mask_crop: np.ndarray) -> np.ndarray:
    """Xóa vật thể & tái tạo hậu cảnh thông minh (Offline, < 1 giây):
    Kết hợp Multi-Scale Telea + Navier-Stokes + Patch Texture Synthesis."""
    h, w = rgb_crop.shape[:2]
    dilate_k = max(3, int(min(h, w) * 0.025) | 1)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dilate_k, dilate_k))
    mask_dilated = cv2.dilate(mask_crop, kernel, iterations=1)

    bgr = cv2.cvtColor(rgb_crop, cv2.COLOR_RGB2BGR)

    scale = min(1.0, 256.0 / max(1, max(h, w)))
    if scale < 0.85:
        sh, sw = max(16, int(h * scale)), max(16, int(w * scale))
        small_bgr = cv2.resize(bgr, (sw, sh), interpolation=cv2.INTER_AREA)
        small_mask = cv2.resize(mask_dilated, (sw, sh), interpolation=cv2.INTER_NEAREST)
        small_ns = cv2.inpaint(small_bgr, small_mask, inpaintRadius=7, flags=cv2.INPAINT_NS)
        small_telea = cv2.inpaint(small_bgr, small_mask, inpaintRadius=7, flags=cv2.INPAINT_TELEA)
        small_base = cv2.addWeighted(small_ns, 0.5, small_telea, 0.5, 0)
        coarse_bgr = cv2.resize(small_base, (w, h), interpolation=cv2.INTER_CUBIC)
    else:
        coarse_bgr = bgr.copy()

    fine_telea = cv2.inpaint(bgr, mask_dilated, inpaintRadius=max(5, int(min(h, w) * 0.03)), flags=cv2.INPAINT_TELEA)
    fine_ns = cv2.inpaint(bgr, mask_dilated, inpaintRadius=max(5, int(min(h, w) * 0.03)), flags=cv2.INPAINT_NS)
    base_inpaint = cv2.addWeighted(fine_telea, 0.6, fine_ns, 0.4, 0)
    if scale < 0.85:
        base_inpaint = cv2.addWeighted(base_inpaint, 0.65, coarse_bgr, 0.35, 0)

    ring_outer = cv2.dilate(mask_dilated, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (35, 35)), iterations=1)
    valid_donor = (ring_outer > 0) & (mask_dilated == 0)
    if not np.any(valid_donor):
        valid_donor = mask_dilated == 0

    if np.any(valid_donor):
        blur_orig = cv2.GaussianBlur(bgr, (0, 0), sigmaX=3.0)
        high_freq = bgr.astype(np.float32) - blur_orig.astype(np.float32)

        donor_ys, donor_xs = np.where(valid_donor)
        target_ys, target_xs = np.where(mask_dilated > 0)

        if len(donor_ys) > 30 and len(target_ys) > 0:
            patch_sz = 12
            step = 8
            tex_layer = base_inpaint.astype(np.float32).copy()
            base_lab = cv2.cvtColor(base_inpaint, cv2.COLOR_BGR2LAB).astype(np.float32)
            orig_lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB).astype(np.float32)

            valid_eroded = cv2.erode((mask_dilated == 0).astype(np.uint8) * 255, np.ones((patch_sz, patch_sz), np.uint8))
            vy, vx = np.where(valid_eroded > 0)
            if len(vy) > 20:
                rng = np.random.default_rng(42)
                sample_idx = rng.choice(len(vy), size=min(180, len(vy)), replace=False)
                cand_ys = vy[sample_idx]
                cand_xs = vx[sample_idx]
                cand_colors = orig_lab[cand_ys, cand_xs]

                ys_box, xs_box = np.where(mask_dilated > 0)
                y0, y1 = int(ys_box.min()), int(ys_box.max())
                x0, x1 = int(xs_box.min()), int(xs_box.max())
                half = patch_sz // 2

                for py in range(max(half, y0), min(h - half, y1 + 1), step):
                    for px in range(max(half, x0), min(w - half, x1 + 1), step):
                        if mask_dilated[py, px] == 0:
                            continue
                        t_col = base_lab[py, px]
                        color_dist = np.sum((cand_colors - t_col) ** 2, axis=1)
                        spatial_dist = ((cand_ys - py) ** 2 + (cand_xs - px) ** 2) * 0.04
                        best_i = int(np.argmin(color_dist + spatial_dist))
                        sy, sx = int(cand_ys[best_i]), int(cand_xs[best_i])

                        hf_patch = high_freq[sy - half : sy + half, sx - half : sx + half]
                        if hf_patch.shape[:2] == (patch_sz, patch_sz):
                            tex_layer[py - half : py + half, px - half : px + half] += hf_patch * 0.65

                base_inpaint = np.clip(tex_layer, 0, 255).astype(np.uint8)

    return cv2.cvtColor(base_inpaint, cv2.COLOR_BGR2RGB)


def _match_color_to_context(generated_rgb: np.ndarray, context_rgb: np.ndarray, mask: np.ndarray, strength: float = 0.45) -> np.ndarray:
    """Hòa trộn ánh sáng & nhiệt độ màu (LAB Transfer) của ảnh AI theo môi trường ảnh gốc."""
    ring = cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41)), iterations=1)
    border_mask = (ring > 0) & (mask == 0)
    if np.count_nonzero(border_mask) < 50:
        border_mask = mask == 0
    if np.count_nonzero(border_mask) < 20:
        return generated_rgb

    gen_lab = cv2.cvtColor(generated_rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
    ctx_lab = cv2.cvtColor(context_rgb, cv2.COLOR_RGB2LAB).astype(np.float32)

    inner_mask = mask > 127
    if np.count_nonzero(inner_mask) < 10:
        inner_mask = np.ones(generated_rgb.shape[:2], dtype=bool)

    out_lab = gen_lab.copy()
    for ch in range(3):
        src_vals = gen_lab[:, :, ch][inner_mask]
        ref_vals = ctx_lab[:, :, ch][border_mask]
        s_mean, s_std = float(np.mean(src_vals)), max(1.0, float(np.std(src_vals)))
        r_mean, r_std = float(np.mean(ref_vals)), max(1.0, float(np.std(ref_vals)))
        w = strength if ch == 0 else strength * 0.7  # giữ màu gốc của vật thể mới, chỉ cân chỉnh ánh sáng & ám màu môi trường
        blend_std = s_std * (1.0 - w) + r_std * w
        blend_mean = s_mean * (1.0 - w) + r_mean * w
        out_lab[:, :, ch] = (gen_lab[:, :, ch] - s_mean) * (blend_std / s_std) + blend_mean

    out_lab = np.clip(out_lab, 0, 255).astype(np.uint8)
    return cv2.cvtColor(out_lab, cv2.COLOR_LAB2RGB)


def _describe_surrounding_context(rgb_crop: np.ndarray, mask_crop: np.ndarray) -> tuple[str, tuple[int, int, int]]:
    """Phân tích độ sáng và tông màu của môi trường xung quanh để mô tả bối cảnh cho Flux AI."""
    valid = mask_crop == 0
    if not np.any(valid):
        valid = np.ones(rgb_crop.shape[:2], dtype=bool)
    pixels = rgb_crop[valid]
    mean_r, mean_g, mean_b = [int(round(x)) for x in np.mean(pixels, axis=0)]
    lum = 0.299 * mean_r + 0.587 * mean_g + 0.114 * mean_b
    light_desc = "bright daylight" if lum > 155 else ("moody dim lighting" if lum < 75 else "natural soft lighting")
    if mean_b > mean_r + 15 and mean_g > mean_r + 10:
        tone_desc = "cool blue-teal glass / water surface background"
    elif mean_g > mean_r + 12 and mean_g > mean_b + 15:
        tone_desc = "natural green foliage background"
    elif mean_r > mean_b + 28:
        tone_desc = "warm earthy outdoor ground background"
    else:
        tone_desc = f"smooth neutral rgb({mean_r},{mean_g},{mean_b}) background"
    return f"{light_desc}, {tone_desc}", (mean_r, mean_g, mean_b)


def _extract_subject_alpha_matte(gen_box_rgb: np.ndarray, feather_px: int = 8) -> np.ndarray | None:
    """Tự động tách nền chủ thể (ví dụ: con bướm, con chim, bông hoa, viên đá...) ra khỏi nền của bức ảnh Flux vừa tạo,
    giúp khi ghép vào PhotoCraft sẽ giữ nguyên nền kính/nước/đất thật của bức ảnh gốc xung quanh vật thể!"""
    bh, bw = gen_box_rgb.shape[:2]
    if bh < 32 or bw < 32:
        return None
    try:
        lab = cv2.cvtColor(gen_box_rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
        border = max(3, int(min(bh, bw) * 0.08))
        b_mask = np.zeros((bh, bw), dtype=bool)
        b_mask[:border, :] = True
        b_mask[-border:, :] = True
        b_mask[:, :border] = True
        b_mask[:, -border:] = True

        bg_pixels = lab[b_mask]
        bg_med = np.median(bg_pixels, axis=0)
        bg_std = float(np.mean(np.std(bg_pixels, axis=0)))

        # Khoảng cách màu của từng pixel so với nền viền
        dist = np.linalg.norm(lab - bg_med[None, None, :], axis=2)

        # Khởi tạo mask cho GrabCut
        gc_mask = np.full((bh, bw), cv2.GC_PR_BGD, dtype=np.uint8)
        gc_mask[b_mask] = cv2.GC_BGD

        # Vùng trung tâm có độ khác biệt màu rõ rệt so với viền là chủ thể (Foreground)
        cy1, cy2 = int(bh * 0.12), int(bh * 0.88)
        cx1, cx2 = int(bw * 0.12), int(bw * 0.88)
        center_zone = np.zeros((bh, bw), dtype=bool)
        center_zone[cy1:cy2, cx1:cx2] = True

        thresh_hi = max(22.0, bg_std * 1.8)
        thresh_lo = max(12.0, bg_std * 1.1)
        gc_mask[center_zone & (dist > thresh_lo)] = cv2.GC_PR_FGD
        gc_mask[center_zone & (dist > thresh_hi)] = cv2.GC_FGD

        if np.count_nonzero(gc_mask == cv2.GC_FGD) < 25:
            return None

        bgd_model = np.zeros((1, 65), np.float64)
        fgd_model = np.zeros((1, 65), np.float64)
        bgr_box = cv2.cvtColor(gen_box_rgb, cv2.COLOR_RGB2BGR)
        cv2.grabCut(bgr_box, gc_mask, None, bgd_model, fgd_model, 3, cv2.GC_INIT_WITH_MASK)

        fg = np.where((gc_mask == cv2.GC_FGD) | (gc_mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
        fg_ratio = np.count_nonzero(fg) / float(bh * bw)
        # Chỉ dùng tách nền chủ thể nếu chủ thể chiếm từ 8% đến 80% diện tích ô chọn
        if fg_ratio < 0.08 or fg_ratio > 0.82:
            return None

        # Làm mịn viền chủ thể và giữ lại bóng đổ mềm quanh chủ thể
        k_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, k_close)
        k_blur = max(3, (feather_px | 1))
        alpha = cv2.GaussianBlur(fg.astype(np.float32) / 255.0, (k_blur, k_blur), sigmaX=feather_px * 0.35)
        # Cho phép 1 lớp hòa trộn rất nhẹ quanh chủ thể để bóng đậu trên kính/nền trông thật hơn
        soft_halo = cv2.GaussianBlur(fg.astype(np.float32) / 255.0, (25, 25), sigmaX=8.0) * 0.22
        return np.clip(np.maximum(alpha, soft_halo), 0.0, 1.0)
    except Exception:
        return None


def _call_hf_gradio_flux(prompt: str, req_w: int, req_h: int) -> Image.Image:
    """Gọi cụm máy chủ HuggingFace Gradio FLUX.1-Schnell / FLUX.1-Merged hoàn toàn miễn phí (không cần API Key)."""
    seed = random.randint(1, 9999999)
    spaces = [
        (
            "https://black-forest-labs-flux-1-schnell.hf.space",
            "/gradio_api/call/infer",
            [prompt, seed, True, req_w, req_h, 4],
        ),
        (
            "https://multimodalart-flux-1-merged.hf.space",
            "/gradio_api/call/infer",
            [prompt, seed, True, req_w, req_h, 3.5, 8],
        ),
    ]
    last_err = None
    for base, ep, data_arr in spaces:
        try:
            call_url = base + ep
            req = urllib.request.Request(
                call_url,
                data=json.dumps({"data": data_arr}).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=18) as r:
                resp_json = json.loads(r.read().decode("utf-8"))
            ev_id = resp_json.get("event_id")
            if not ev_id:
                continue

            with urllib.request.urlopen(f"{call_url}/{ev_id}", timeout=45) as r2:
                sse_text = r2.read().decode("utf-8", errors="ignore")

            img_url = None
            for line in sse_text.splitlines():
                if line.startswith("data:"):
                    raw_d = line[5:].strip()
                    if not raw_d or raw_d == "null":
                        continue
                    try:
                        parsed = json.loads(raw_d)
                        if isinstance(parsed, list) and parsed:
                            first = parsed[0]
                            if isinstance(first, dict):
                                img_url = first.get("url") or (
                                    f"{base}/gradio_api/file={first['path']}" if first.get("path") else None
                                )
                                if img_url:
                                    break
                    except Exception:
                        pass

            if img_url:
                img_req = urllib.request.Request(img_url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(img_req, timeout=25) as ir:
                    im = _pil_from_bytes(ir.read())
                    if im is not None:
                        return im
        except Exception as e:
            last_err = e
            continue

    # Dự phòng cuối: AI Horde (mạng lưới GPU cộng đồng miễn phí không cần Key)
    try:
        horde_body = {
            "prompt": prompt,
            "params": {"width": 512, "height": 512, "steps": 20, "n": 1},
            "nsfw": False,
            "r2": True,
        }
        hreq = urllib.request.Request(
            "https://stablehorde.net/api/v2/generate/async",
            data=json.dumps(horde_body).encode("utf-8"),
            headers={"Content-Type": "application/json", "apikey": "0000000000", "Client-Agent": "MyingGo:1.0:PhotoCraft"},
            method="POST",
        )
        with urllib.request.urlopen(hreq, timeout=15) as hr:
            job_id = json.loads(hr.read().decode("utf-8")).get("id")
        if job_id:
            for _ in range(22):
                time.sleep(2.0)
                sreq = urllib.request.Request(
                    f"https://stablehorde.net/api/v2/generate/status/{job_id}",
                    headers={"Client-Agent": "MyingGo:1.0:PhotoCraft"},
                )
                with urllib.request.urlopen(sreq, timeout=10) as sr:
                    st = json.loads(sr.read().decode("utf-8"))
                if st.get("done") and st.get("generations"):
                    g_img = st["generations"][0].get("img")
                    if g_img:
                        if g_img.startswith("http"):
                            with urllib.request.urlopen(g_img, timeout=20) as gr:
                                im = _pil_from_bytes(gr.read())
                        else:
                            im = _pil_from_bytes(base64.b64decode(g_img))
                        if im is not None:
                            return im
    except Exception as e:
        last_err = e

    raise RuntimeError(f"Các máy chủ AI Miễn phí đang bận ({last_err}). Vui lòng bấm Generate thử lại hoặc nhập Gemini Key miễn phí.")


def generate_fill_free_cloud(rgb_crop: np.ndarray, mask_crop: np.ndarray, prompt: str) -> tuple[np.ndarray, np.ndarray | None]:
    """Generative Fill miễn phí (Không cần API Key) qua cụm HuggingFace FLUX.1-Schnell.
    Trả về (edited_crop_rgb, custom_subject_alpha)."""
    prompt_clean = (prompt or "").strip()
    if not prompt_clean:
        return inpaint_remove_local(rgb_crop, mask_crop), None

    en_prompt = translate_vi_to_en(prompt_clean)
    ctx_desc, _ = _describe_surrounding_context(rgb_crop, mask_crop)
    full_prompt = (
        f"{en_prompt}, centered subject, {ctx_desc}, "
        f"clean unfocused background matching the scene, photorealistic macro photography, natural shadows, 8k"
    )

    ys, xs = np.where(mask_crop > 64)
    if len(ys) < 9:
        return inpaint_remove_local(rgb_crop, mask_crop), None

    my1, my2 = int(ys.min()), int(ys.max()) + 1
    mx1, mx2 = int(xs.min()), int(xs.max()) + 1
    bh, bw = my2 - my1, mx2 - mx1

    # Kích thước chuẩn bội số của 32 cho Flux (từ 512 đến 768)
    aspect = bw / max(1.0, float(bh))
    if aspect >= 1.25:
        req_w, req_h = 768, 512
    elif aspect <= 0.8:
        req_w, req_h = 512, 768
    else:
        req_w, req_h = 512, 512

    im = _call_hf_gradio_flux(full_prompt, req_w, req_h)
    gen_box_rgb = np.array(im.convert("RGB"))
    gen_box_rgb = cv2.resize(gen_box_rgb, (bw, bh), interpolation=cv2.INTER_LANCZOS4)

    # Đặt kết quả vào đúng vị trí hộp chọn trên rgb_crop
    out_crop_rgb = rgb_crop.copy()
    out_crop_rgb[my1:my2, mx1:mx2] = gen_box_rgb
    out_crop_rgb = _match_color_to_context(out_crop_rgb, rgb_crop, mask_crop, strength=0.35)

    # Tách nền chủ thể thông minh (GrabCut Matte) để phần nền kính/cỏ/đất của ảnh gốc giữ nguyên xung quanh vật thể mới
    subj_box_alpha = _extract_subject_alpha_matte(out_crop_rgb[my1:my2, mx1:mx2])
    custom_alpha = None
    if subj_box_alpha is not None:
        custom_alpha = np.zeros(rgb_crop.shape[:2], dtype=np.float32)
        box_mask_f = (mask_crop[my1:my2, mx1:mx2] > 64).astype(np.float32)
        custom_alpha[my1:my2, mx1:mx2] = subj_box_alpha * box_mask_f

    return out_crop_rgb, custom_alpha


def generate_fill_gemini(rgb_crop: np.ndarray, mask_crop: np.ndarray, prompt: str, api_key: str, model: str = "") -> np.ndarray:
    """Generative Fill & Remove bằng Google Gemini AI (Nano Banana / Gemini 2.5 Flash Image / Gemini 2.0 Flash)."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise ValueError("Chưa nhập Google Gemini API Key. Hãy bấm nút ⚙️ Cài đặt AI để dán Key (lấy miễn phí tại aistudio.google.com).")

    h, w = rgb_crop.shape[:2]
    guide_rgb = rgb_crop.copy()
    contours, _ = cv2.findContours(mask_crop, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(guide_rgb, contours, -1, (255, 0, 128), thickness=max(2, int(min(h, w) * 0.008)))

    buf_orig = io.BytesIO()
    Image.fromarray(rgb_crop).save(buf_orig, format="PNG")
    b64_orig = base64.b64encode(buf_orig.getvalue()).decode("ascii")

    buf_guide = io.BytesIO()
    Image.fromarray(guide_rgb).save(buf_guide, format="PNG")
    b64_guide = base64.b64encode(buf_guide.getvalue()).decode("ascii")

    if prompt and prompt.strip():
        instruction = (
            f"Edit the first image ONLY inside the region outlined in pink in the second reference image. "
            f"User request: \"{prompt.strip()}\". "
            f"Keep all pixels outside the outlined region 100% identical in lighting, texture, perspective, and position. "
            f"Do NOT include the pink outline in the final output image."
        )
    else:
        instruction = (
            "Remove the object/content inside the region outlined in pink in the second reference image, "
            "and seamlessly reconstruct the natural background behind it matching the surrounding texture, lighting, and grain. "
            "Do NOT include the pink outline in the final output image."
        )

    models_to_try = [m for m in [model, "gemini-2.0-flash-exp-image-generation", "gemini-2.5-flash-image-preview"] if m]
    seen_m = []
    for m in models_to_try:
        if m not in seen_m:
            seen_m.append(m)

    last_err = None
    for m_name in seen_m:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{m_name}:generateContent?key={api_key}"
        body = {
            "contents": [{
                "parts": [
                    {"text": instruction},
                    {"inlineData": {"mimeType": "image/png", "data": b64_orig}},
                    {"inlineData": {"mimeType": "image/png", "data": b64_guide}},
                ]
            }],
            "generationConfig": {
                "responseModalities": ["TEXT", "IMAGE"],
            },
        }
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "MyingGo-PhotoCraft"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                res = json.loads(resp.read().decode("utf-8"))
            for cand in res.get("candidates") or []:
                for part in (cand.get("content") or {}).get("parts") or []:
                    inline = part.get("inlineData") or part.get("inline_data")
                    if inline and inline.get("data"):
                        im = _pil_from_bytes(base64.b64decode(inline["data"]))
                        if im is not None:
                            out_rgb = np.array(im.convert("RGB"))
                            return cv2.resize(out_rgb, (w, h), interpolation=cv2.INTER_LANCZOS4)
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore")
            last_err = f"HTTP {e.code}: {err_body[:200]}"
        except Exception as e:
            last_err = str(e)
    raise RuntimeError(f"Gemini AI báo lỗi: {last_err}")


def generate_fill_openai(rgb_crop: np.ndarray, mask_crop: np.ndarray, prompt: str, api_key: str, model: str = "dall-e-2") -> np.ndarray:
    """Generative Fill qua OpenAI Image Edits API (/v1/images/edits) sử dụng chuẩn Image + Alpha Mask."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise ValueError("Chưa nhập OpenAI API Key. Hãy bấm nút ⚙️ Cài đặt AI để nhập Key.")

    h, w = rgb_crop.shape[:2]
    sz = 512 if max(h, w) <= 600 else 1024
    sq_rgb = cv2.resize(rgb_crop, (sz, sz), interpolation=cv2.INTER_AREA)
    sq_mask = cv2.resize(mask_crop, (sz, sz), interpolation=cv2.INTER_NEAREST)

    img_rgba = np.dstack([sq_rgb, np.full((sz, sz), 255, dtype=np.uint8)])
    mask_rgba = np.dstack([sq_rgb, np.where(sq_mask > 127, 0, 255).astype(np.uint8)])

    buf_img = io.BytesIO()
    Image.fromarray(img_rgba).save(buf_img, format="PNG")
    buf_msk = io.BytesIO()
    Image.fromarray(mask_rgba).save(buf_msk, format="PNG")

    final_prompt = (prompt or "").strip() or "Seamlessly remove the object and reconstruct the natural background"
    boundary = f"----MyingGoBoundary{int(time.time() * 1000)}"

    parts = []
    def add_field(name: str, val: str):
        parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{val}\r\n".encode("utf-8"))

    def add_file(name: str, filename: str, data: bytes):
        parts.append(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{filename}\"\r\nContent-Type: image/png\r\n\r\n".encode("utf-8")
            + data
            + b"\r\n"
        )

    add_field("model", model or "dall-e-2")
    add_field("prompt", final_prompt)
    add_field("n", "1")
    add_field("size", f"{sz}x{sz}")
    add_field("response_format", "b64_json")
    add_file("image", "image.png", buf_img.getvalue())
    add_file("mask", "mask.png", buf_msk.getvalue())
    parts.append(f"--{boundary}--\r\n".encode("utf-8"))
    body_bytes = b"".join(parts)

    req = urllib.request.Request(
        "https://api.openai.com/v1/images/edits",
        data=body_bytes,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=65) as resp:
        res = json.loads(resp.read().decode("utf-8"))
    b64_out = res["data"][0].get("b64_json")
    im = _pil_from_bytes(base64.b64decode(b64_out))
    out_rgb = np.array(im.convert("RGB"))
    return cv2.resize(out_rgb, (w, h), interpolation=cv2.INTER_LANCZOS4)


def generate_fill_stability(rgb_crop: np.ndarray, mask_crop: np.ndarray, prompt: str, api_key: str, mode: str = "fill") -> np.ndarray:
    """Generative Fill & Erase qua Stability AI REST API v2beta (/stable-image/edit/inpaint hoặc /erase)."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise ValueError("Chưa nhập Stability AI API Key. Hãy bấm nút ⚙️ Cài đặt AI để nhập Key.")

    h, w = rgb_crop.shape[:2]
    buf_img = io.BytesIO()
    Image.fromarray(rgb_crop).save(buf_img, format="PNG")
    buf_msk = io.BytesIO()
    Image.fromarray(mask_crop).save(buf_msk, format="PNG")

    is_erase = mode == "remove" or not (prompt or "").strip()
    endpoint = (
        "https://api.stability.ai/v2beta/stable-image/edit/erase"
        if is_erase
        else "https://api.stability.ai/v2beta/stable-image/edit/inpaint"
    )
    boundary = f"----MyingGoStability{int(time.time() * 1000)}"
    parts = []

    def add_field(name: str, val: str):
        parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{val}\r\n".encode("utf-8"))

    def add_file(name: str, filename: str, data: bytes):
        parts.append(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{filename}\"\r\nContent-Type: image/png\r\n\r\n".encode("utf-8")
            + data
            + b"\r\n"
        )

    add_file("image", "image.png", buf_img.getvalue())
    add_file("mask", "mask.png", buf_msk.getvalue())
    if not is_erase:
        add_field("prompt", translate_vi_to_en(prompt))
    add_field("output_format", "png")
    parts.append(f"--{boundary}--\r\n".encode("utf-8"))

    req = urllib.request.Request(
        endpoint,
        data=b"".join(parts),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Accept": "image/*",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=65) as resp:
        im = _pil_from_bytes(resp.read())
    out_rgb = np.array(im.convert("RGB"))
    return cv2.resize(out_rgb, (w, h), interpolation=cv2.INTER_LANCZOS4)


def run_ai_edit(data: dict) -> dict:
    """Xử lý yêu cầu Generative Fill hoặc Remove từ PhotoCraft và trả về Layer PNG khớp 1:1 với tài liệu."""
    t0 = time.time()
    cfg = load_config()
    action = str(data.get("action") or "fill").lower()  # "fill" | "remove"
    prompt = str(data.get("prompt") or "").strip()
    provider = str(data.get("provider") or cfg.get("provider") or "auto").lower()

    screen_b64 = data.get("screen_b64") or ""
    doc_b64 = data.get("doc_b64") or ""
    mask_b64 = data.get("mask_b64") or ""
    sel_rect = data.get("rect") or {}
    canvas_w = int(data.get("canvas_w") or 1280)
    canvas_h = int(data.get("canvas_h") or 720)

    screen_im = _pil_from_bytes(_decode_b64_bytes(screen_b64))
    doc_im = _pil_from_bytes(_decode_b64_bytes(doc_b64))
    mask_im = _pil_from_bytes(_decode_b64_bytes(mask_b64))

    screen_rgba = np.array(screen_im) if screen_im is not None else None
    doc_rgba = np.array(doc_im) if doc_im is not None else None

    if doc_rgba is None and screen_rgba is None:
        raise ValueError("Chưa chụp được ảnh trên vùng vẽ PhotoCraft. Hãy mở 1 bức ảnh trong PhotoCraft trước!")

    has_true_doc = doc_rgba is not None
    if has_true_doc:
        base_rgba = doc_rgba
        doc_h, doc_w = base_rgba.shape[:2]
        vx, vy, vw, vh = find_document_rect_on_screen(
            screen_rgba, doc_rgba, canvas_w, canvas_h, data.get("doc_screen_rect")
        )
    else:
        base_rgba = screen_rgba
        doc_h, doc_w = base_rgba.shape[:2]
        vx, vy, vw, vh = 0.0, 0.0, float(canvas_w), float(canvas_h)

    doc_mask = np.zeros((doc_h, doc_w), dtype=np.uint8)
    if mask_im is not None:
        mask_arr = np.array(mask_im.convert("L"))
        mh, mw = mask_arr.shape[:2]
        sx1 = max(0, int(round(vx * mw / max(1.0, float(canvas_w)))))
        sy1 = max(0, int(round(vy * mh / max(1.0, float(canvas_h)))))
        sx2 = min(mw, int(round((vx + vw) * mw / max(1.0, float(canvas_w)))))
        sy2 = min(mh, int(round((vy + vh) * mh / max(1.0, float(canvas_h)))))
        if sx2 > sx1 + 4 and sy2 > sy1 + 4:
            sub_mask = mask_arr[sy1:sy2, sx1:sx2]
            doc_mask = cv2.resize(sub_mask, (doc_w, doc_h), interpolation=cv2.INTER_NEAREST)

    if np.count_nonzero(doc_mask > 64) < 16 and sel_rect:
        rx = float(sel_rect.get("x") or 0)
        ry = float(sel_rect.get("y") or 0)
        rw = float(sel_rect.get("w") or 0)
        rh = float(sel_rect.get("h") or 0)
        dx1 = int(round((rx - vx) * doc_w / max(1.0, vw)))
        dy1 = int(round((ry - vy) * doc_h / max(1.0, vh)))
        dx2 = int(round((rx + rw - vx) * doc_w / max(1.0, vw)))
        dy2 = int(round((ry + rh - vy) * doc_h / max(1.0, vh)))
        dx1, dx2 = max(0, min(doc_w - 1, dx1)), max(1, min(doc_w, dx2))
        dy1, dy2 = max(0, min(doc_h - 1, dy1)), max(1, min(doc_h, dy2))
        if dx2 > dx1 + 2 and dy2 > dy1 + 2:
            doc_mask[dy1:dy2, dx1:dx2] = 255

    ys, xs = np.where(doc_mask > 64)
    if len(ys) < 9:
        raise ValueError("Vùng chọn nằm ngoài bức ảnh hoặc quá nhỏ. Hãy kéo khung chọn bên trong bức ảnh cần chỉnh sửa!")

    mx1, mx2 = int(xs.min()), int(xs.max()) + 1
    my1, my2 = int(ys.min()), int(ys.max()) + 1
    mw_box = mx2 - mx1
    mh_box = my2 - my1

    pad = max(48, int(max(mw_box, mh_box) * 0.55))
    cx1 = max(0, mx1 - pad)
    cy1 = max(0, my1 - pad)
    cx2 = min(doc_w, mx2 + pad)
    cy2 = min(doc_h, my2 + pad)

    rgb_full = base_rgba[:, :, :3].copy()
    rgb_crop = rgb_full[cy1:cy2, cx1:cx2].copy()
    mask_crop = ((doc_mask[cy1:cy2, cx1:cx2] > 64).astype(np.uint8)) * 255

    used_engine = ""
    is_remove = action == "remove" or not prompt
    custom_alpha = None

    if provider == "auto":
        if is_remove and not cfg.get("gemini_key") and not cfg.get("stability_key"):
            provider = "free"
        elif cfg.get("gemini_key"):
            provider = "gemini"
        elif cfg.get("openai_key"):
            provider = "openai"
        elif cfg.get("stability_key"):
            provider = "stability"
        else:
            provider = "free"

    if provider == "gemini":
        used_engine = "💎 Google Gemini AI"
        edited_crop_rgb = generate_fill_gemini(
            rgb_crop, mask_crop, "" if is_remove else prompt, cfg.get("gemini_key", ""), cfg.get("gemini_model", "")
        )
    elif provider == "openai":
        used_engine = "🚀 OpenAI Image Edit"
        edited_crop_rgb = generate_fill_openai(
            rgb_crop, mask_crop, "" if is_remove else prompt, cfg.get("openai_key", ""), cfg.get("openai_model", "dall-e-2")
        )
    elif provider == "stability":
        used_engine = "🎨 Stability AI Inpaint"
        edited_crop_rgb = generate_fill_stability(
            rgb_crop, mask_crop, prompt, cfg.get("stability_key", ""), mode="remove" if is_remove else "fill"
        )
    else:
        if is_remove:
            used_engine = "⚡ AI Remove (Multi-Scale Texture Inpaint)"
            edited_crop_rgb = inpaint_remove_local(rgb_crop, mask_crop)
        else:
            used_engine = "⚡ AI Generative Fill (FLUX.1 Free)"
            edited_crop_rgb, custom_alpha = generate_fill_free_cloud(rgb_crop, mask_crop, prompt)

    feather_px = max(3, min(45, int(cfg.get("feather_px") or 10)))
    ksize = (feather_px * 2 + 1) | 1
    dilated_for_feather = cv2.dilate(
        mask_crop, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (max(3, feather_px), max(3, feather_px)))
    )
    alpha_soft = cv2.GaussianBlur(
        dilated_for_feather.astype(np.float32) / 255.0, (ksize, ksize), sigmaX=feather_px * 0.45
    )
    alpha_soft = np.clip(alpha_soft * 1.15, 0.0, 1.0)

    if custom_alpha is not None:
        # Kết hợp mặt nạ tách chủ thể thông minh (giữ nền thật xung quanh con bướm/vật thể) với viền mềm
        alpha_final = np.minimum(alpha_soft, custom_alpha)
    else:
        alpha_final = alpha_soft

    alpha_3 = alpha_final[:, :, None]
    blended_crop_rgb = np.clip(
        edited_crop_rgb.astype(np.float32) * alpha_3 + rgb_crop.astype(np.float32) * (1.0 - alpha_3), 0, 255
    ).astype(np.uint8)

    layer_rgba = np.zeros((doc_h, doc_w, 4), dtype=np.uint8)
    patch_alpha_u8 = np.clip(alpha_final * 255.0, 0, 255).astype(np.uint8)
    layer_rgba[cy1:cy2, cx1:cx2, :3] = edited_crop_rgb if custom_alpha is not None else blended_crop_rgb
    layer_rgba[cy1:cy2, cx1:cx2, 3] = patch_alpha_u8
    layer_rgba[0, 0, :3] = base_rgba[0, 0, :3]
    layer_rgba[0, 0, 3] = 1
    layer_rgba[doc_h - 1, doc_w - 1, :3] = base_rgba[doc_h - 1, doc_w - 1, :3]
    layer_rgba[doc_h - 1, doc_w - 1, 3] = 1

    box_rgb = blended_crop_rgb[my1 - cy1 : my2 - cy1, mx1 - cx1 : mx2 - cx1]
    box_alpha = np.clip(alpha_soft[my1 - cy1 : my2 - cy1, mx1 - cx1 : mx2 - cx1] * 255.0, 245, 255).astype(np.uint8)
    box_rgba = np.dstack([box_rgb, box_alpha])

    elapsed = round(time.time() - t0, 2)
    layer_label = f"AI_Remove_{int(time.time())}.png" if is_remove else f"AI_Fill_{int(time.time())}.png"

    return {
        "ok": 1,
        "engine": used_engine,
        "elapsed_s": elapsed,
        "layer_name": layer_label,
        "layer_png_b64": _encode_png_b64(layer_rgba),
        "patch_png_b64": _encode_png_b64(box_rgba),
        "doc_size": [doc_w, doc_h],
        "has_true_doc": has_true_doc,
    }
