"""Máy chủ web cục bộ + tự quét features/ + mở cửa sổ ứng dụng."""
import importlib
import json
import mimetypes
import pkgutil
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import features
from core import settings
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
STATE = {"last_ping": time.time(), "bye": 0.0, "seen": False}
FEATURES = {}


def discover():
    found = []
    for m in pkgutil.iter_modules(features.__path__):
        if m.name.startswith("_"):
            continue
        try:
            full_name = f"features.{m.name}"
            if full_name in sys.modules:
                mod = importlib.reload(sys.modules[full_name])
            else:
                mod = importlib.import_module(full_name)
        except Exception:
            traceback.print_exc()
            continue
        for obj in vars(mod).values():
            if isinstance(obj, type) and issubclass(obj, Feature) and obj is not Feature and obj.__module__ == mod.__name__:
                inst = obj()
                inst.id = m.name
                inst._file = mod.__file__
                found.append(inst)
    found.sort(key=lambda f: (f.order, f.title))
    return found


def reload_features():
    FEATURES.clear()
    for f in discover():
        FEATURES[f.id] = f


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _static(self, base, rel):
        p = (base / rel).resolve()
        if base.resolve() not in p.parents or not p.is_file():
            return self._send(404, {"error": "not found"})
        ctype = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
        self._send(200, p.read_bytes(), ctype)

    def do_GET(self):
        u = urlparse(self.path)
        path = unquote(u.path)
        if path == "/":
            return self._static(ROOT / "web", "index.html")
        if path.startswith("/web/"):
            return self._static(ROOT / "web", path[5:])
        if path.startswith("/assets/"):
            return self._static(ROOT / "assets", path[8:])
        if path == "/api/features":
            return self._send(200, [{"id": f.id, "title": f.title, "dock": f.dock} for f in FEATURES.values()])
        if path == "/api/settings":
            return self._send(200, settings.load())
        if path == "/api/update/status":
            from core import updater
            return self._send(200, updater.status())
        if path == "/api/update/check":
            from core import updater
            return self._send(200, updater.check_remote_version())
        parts = path.strip("/").split("/")
        if len(parts) == 4 and parts[:2] == ["api", "feature"] and parts[3] == "html":
            f = FEATURES.get(parts[2])
            return self._send(200, f.html(f._file) if f else "", "text/html; charset=utf-8")
        if len(parts) == 3 and parts[0] == "api" and parts[2] == "log" and parts[1] in FEATURES:
            since = int(parse_qs(u.query).get("since", ["0"])[0])
            return self._send(200, FEATURES[parts[1]].get_log(since))
        self._send(404, {"error": "not found"})

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            data = {}
        if path == "/api/ping":
            STATE.update(last_ping=time.time(), seen=True, bye=0.0)
            return self._send(200, {"ok": 1})
        if path == "/api/bye":
            STATE["bye"] = time.time()
            return self._send(200, {"ok": 1})
        if path == "/api/settings":
            return self._send(200, settings.update(data))
        if path == "/api/settings/reset":
            return self._send(200, settings.reset())
        if path == "/api/pack":
            from core import pack
            try:
                res = pack.pack(bool(data.get("tools")))
                subprocess.Popen(["explorer", "/select,", res["path"]])
                return self._send(200, res)
            except Exception as e:
                traceback.print_exc()
                return self._send(500, {"error": str(e)})
        if path == "/api/update/publish":
            from core import updater
            try:
                return self._send(200, updater.publish_update(str(data.get("note") or "")))
            except Exception as e:
                traceback.print_exc()
                return self._send(500, {"error": str(e)})
        if path == "/api/update/pull":
            from core import updater
            try:
                res = updater.pull_and_apply_update()
                reload_features()
                return self._send(200, res)
            except Exception as e:
                traceback.print_exc()
                return self._send(500, {"error": str(e)})
        parts = path.strip("/").split("/")
        if len(parts) == 3 and parts[0] == "api" and parts[1] in FEATURES:
            fn = getattr(FEATURES[parts[1]], "act_" + parts[2], None)
            if not fn:
                return self._send(404, {"error": "no such action"})
            try:
                return self._send(200, fn(data) or {})
            except Exception as e:
                traceback.print_exc()
                return self._send(500, {"error": str(e)})
        self._send(404, {"error": "not found"})


def _browser_cmd(url):
    prof = ROOT / ".profile"
    for exe in (r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"):
        if Path(exe).is_file():
            return [exe, f"--app={url}", f"--user-data-dir={prof}", "--window-size=1240,800",
                    "--no-first-run", "--no-default-browser-check"]
    return None


def run():
    for f in discover():
        FEATURES[f.id] = f
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    url = f"http://127.0.0.1:{srv.server_address[1]}/"
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    cmd = _browser_cmd(url)
    if cmd:
        subprocess.Popen(cmd)
    else:
        webbrowser.open(url)
    start = time.time()
    while True:  # tự thoát khi đóng cửa sổ
        time.sleep(1)
        now = time.time()
        if STATE["bye"] and now - STATE["bye"] > 5:
            break
        if not STATE["seen"] and now - start > 60:
            break
        if STATE["seen"] and now - STATE["last_ping"] > 180:
            break
    srv.shutdown()
    sys.exit(0)
