"""Máy chủ web cục bộ + tự quét features/ + mở cửa sổ ứng dụng."""
import importlib
import json
import mimetypes
import pkgutil
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import features
from core import logger, settings
from core.base import Feature

ROOT = Path(__file__).resolve().parent.parent
STATE = {"last_ping": time.time(), "bye": 0.0, "seen": False}
FEATURES = {}
SUB_PROCS = {}
WIN_STATE = {}  # fid -> timestamp hết hạn heartbeat của cửa sổ mở riêng
mimetypes.add_type("application/wasm", ".wasm")
mimetypes.add_type("text/javascript", ".js")


def running_state():
    now = time.time()
    running_ids = []
    window_ids = []
    for fid, procs in list(SUB_PROCS.items()):
        alive = [p for p in procs if p.poll() is None]
        SUB_PROCS[fid] = alive
        if alive:
            window_ids.append(fid)
    for fid, exp in list(WIN_STATE.items()):
        if now < exp:
            if fid not in window_ids:
                window_ids.append(fid)
        else:
            WIN_STATE.pop(fid, None)
    for fid, f in FEATURES.items():
        if getattr(f, "running", False) or fid in window_ids:
            running_ids.append(fid)
    return {"running": running_ids, "windows": window_ids}


def discover():
    found = []
    for m in pkgutil.iter_modules(features.__path__):
        if m.name.startswith("_"):
            continue
        try:
            full_name = f"features.{m.name}"
            if full_name in sys.modules:
                mod = importlib.reload(sys.modules[full_name])
            else:
                mod = importlib.import_module(full_name)
        except Exception as e:
            traceback.print_exc()
            logger.log_event(m.name, "ERROR", f"Lỗi nạp module {m.name}: {e}", traceback.format_exc())
            continue
        for obj in vars(mod).values():
            if isinstance(obj, type) and issubclass(obj, Feature) and obj is not Feature and obj.__module__ == mod.__name__:
                inst = obj()
                inst.id = m.name
                inst._file = mod.__file__
                try:
                    inst._mtime = Path(mod.__file__).stat().st_mtime
                except OSError:
                    inst._mtime = 0
                found.append(inst)
    found.sort(key=lambda f: (f.order, f.title))
    return found


def reload_features():
    FEATURES.clear()
    for f in discover():
        FEATURES[f.id] = f


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass

    def _static(self, base, rel):
        p = (base / rel).resolve()
        if p.is_dir() and (p / "index.html").is_file():
            p = (p / "index.html").resolve()
        if base.resolve() not in p.parents or not p.is_file():
            return self._send(404, {"error": "not found"})
        ctype = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
        self._send(200, p.read_bytes(), ctype)

    def do_GET(self):
        u = urlparse(self.path)
        path = unquote(u.path)
        if path == "/":
            return self._static(ROOT / "web", "index.html")
        if path.startswith("/web/"):
            return self._static(ROOT / "web", path[5:])
        if path.startswith("/assets/"):
            return self._static(ROOT / "assets", path[8:])
        if path.startswith("/ygodata/"):
            try:
                from core import ygo_data
                return self._static(ygo_data.data_dir(), path[9:])
            except Exception:
                return self._send(404, {"error": "not found"})
        if path == "/api/features":
            return self._send(200, [{"id": f.id, "title": f.title, "dock": f.dock, "group": getattr(f, "group", None)} for f in FEATURES.values()])
        if path == "/api/settings":
            return self._send(200, settings.load())
        if path == "/api/update/status":
            from core import updater
            return self._send(200, updater.status())
        if path == "/api/update/check":
            from core import updater
            return self._send(200, updater.check_remote_version())
        if path == "/api/logs/list":
            q = parse_qs(u.query)
            src = q.get("source", [""])[0]
            since = int(q.get("since", ["0"])[0] or 0)
            only_err = q.get("errors", ["0"])[0] in ("1", "true")
            res = logger.get_logs(src, since, only_err)
            res["running_state"] = running_state()
            return self._send(200, res)
        parts = path.strip("/").split("/")
        if len(parts) == 4 and parts[:2] == ["api", "feature"] and parts[3] == "html":
            f = FEATURES.get(parts[2])
            return self._send(200, f.html(f._file) if f else "", "text/html; charset=utf-8")
        if len(parts) == 3 and parts[0] == "api" and parts[2] == "log" and parts[1] in FEATURES:
            since = int(parse_qs(u.query).get("since", ["0"])[0])
            return self._send(200, FEATURES[parts[1]].get_log(since))
        if len(parts) == 3 and parts[0] == "api" and parts[2] == "file" and parts[1] in FEATURES:
            # Tính năng có thể tự phục vụ file (VD: ảnh xem trước) bằng hàm serve_file(query) -> (bytes, content_type)
            fn = getattr(FEATURES[parts[1]], "serve_file", None)
            if fn:
                try:
                    res = fn(parse_qs(u.query))
                except Exception as e:
                    return self._send(500, {"error": str(e)})
                if res:
                    return self._send(200, res[0], res[1])
        self._send(404, {"error": "not found"})

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            data = {}
        if path == "/api/ping":
            STATE.update(last_ping=time.time(), seen=True, bye=0.0)
            st = running_state()
            st["ok"] = 1
            return self._send(200, st)
        if path == "/api/bye":
            STATE["bye"] = time.time()
            return self._send(200, {"ok": 1})
        if path == "/api/hot_reload":
            from core import updater
            updater.hot_upgrade_runtime()
            reload_features()
            return self._send(200, {"ok": 1})
        if path == "/api/artcraft/window_state":
            fid = str(data.get("fid") or "").strip()
            is_open = bool(data.get("open", True))
            if fid:
                if is_open:
                    WIN_STATE[fid] = time.time() + 5.5
                else:
                    WIN_STATE.pop(fid, None)
                    SUB_PROCS.pop(fid, None)
                    logger.log_event(fid, "SYNC", f"Đã đóng cửa sổ riêng của {fid.upper()} -> tự động chuyển phiên về khung T2MG.")
            return self._send(200, {"ok": 1, "windows": running_state()["windows"]})
        if path == "/api/logs/push":
            entry = logger.log_event(
                str(data.get("source") or "client"),
                str(data.get("level") or "INFO"),
                str(data.get("message") or ""),
                str(data.get("detail") or ""),
            )
            return self._send(200, {"ok": 1, "entry": entry})
        if path == "/api/logs/clear":
            return self._send(200, logger.clear_logs(str(data.get("source") or "")))
        if path == "/api/logs/export":
            res = logger.export_ai_report(str(data.get("source") or ""))
            if data.get("reveal") and res.get("path"):
                subprocess.Popen(["explorer", "/select,", res["path"]])
            return self._send(200, res)
        if path == "/api/settings":
            return self._send(200, settings.update(data))
        if path == "/api/settings/reset":
            return self._send(200, settings.reset())
        if path == "/api/pack":
            from core import pack
            try:
                res = pack.pack(bool(data.get("tools")))
                logger.log_event("system", "INFO", f"📦 Đã đóng gói Zip File thành công ({res['size_mb']} MB)", res["path"])
                subprocess.Popen(["explorer", "/select,", res["path"]])
                return self._send(200, res)
            except Exception as e:
                traceback.print_exc()
                logger.log_event("system", "ERROR", f"Lỗi đóng gói Zip File: {e}", traceback.format_exc())
                return self._send(500, {"error": str(e)})
        if path == "/api/update/publish":
            from core import updater
            try:
                res = updater.publish_update(str(data.get("note") or ""))
                logger.log_event("system", "INFO", f"⬆️ Đã đẩy bản cập nhật v{res.get('version')} lên GitHub ({res.get('repo')})")
                return self._send(200, res)
            except Exception as e:
                traceback.print_exc()
                logger.log_event("system", "ERROR", f"Lỗi đẩy bản cập nhật: {e}", traceback.format_exc())
                return self._send(500, {"error": str(e)})
        if path == "/api/update/pull":
            from core import updater
            try:
                res = updater.pull_and_apply_update()
                reload_features()
                logger.log_event("system", "INFO", f"🔄 Đã cập nhật lên bản v{res.get('version')}")
                return self._send(200, res)
            except Exception as e:
                traceback.print_exc()
                logger.log_event("system", "ERROR", f"Lỗi tải bản cập nhật: {e}", traceback.format_exc())
                return self._send(500, {"error": str(e)})
        parts = path.strip("/").split("/")
        if len(parts) == 3 and parts[0] == "api" and parts[1] in FEATURES:
            feat = FEATURES[parts[1]]
            try:
                if not getattr(feat, "running", False) and Path(feat._file).stat().st_mtime != getattr(feat, "_mtime", 0):
                    reload_features()
                    feat = FEATURES[parts[1]]
            except Exception:
                pass
            fn = getattr(feat, "act_" + parts[2], None)
            if not fn:
                return self._send(404, {"error": "no such action"})
            try:
                return self._send(200, fn(data) or {})
            except Exception as e:
                traceback.print_exc()
                logger.log_event(parts[1], "ERROR", f"Lỗi thực thi {parts[1]}/{parts[2]}: {e}", traceback.format_exc())
                return self._send(500, {"error": str(e)})
        self._send(404, {"error": "not found"})


def _browser_cmd(url, maximized=False):
    # Dùng chung 1 thư mục profile duy nhất trong thư mục File rác & Log để đồng nhất dữ liệu giữa khung trong và cửa sổ riêng
    prof = logger.get_browser_profile_dir()
    for exe in (r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"):
        if Path(exe).is_file():
            args = [exe, f"--app={url}", f"--user-data-dir={prof}",
                    "--no-first-run", "--no-default-browser-check"]
            args.append("--start-maximized" if maximized else "--window-size=1240,800")
            return args
    return None


def open_sub_window(rel_url: str, fid: str = "artcraft"):
    base = STATE.get("url", "http://127.0.0.1:18765/").rstrip("/")
    sep = "&" if "?" in rel_url else "?"
    full_url = f"{base}/{rel_url.lstrip('/')}{sep}standalone=1"
    WIN_STATE[fid] = time.time() + 10.0
    logger.log_event(fid, "SYNC", f"🗖 Mở {fid.upper()} ở màn hình riêng (đồng bộ cùng profile & dữ liệu gốc)", full_url)
    cmd = _browser_cmd(full_url, maximized=True)
    if cmd:
        p = subprocess.Popen(cmd)
        SUB_PROCS.setdefault(fid, []).append(p)
    else:
        webbrowser.open(full_url)
    return full_url


def _bind_server():
    """Ưu tiên cổng cố định 18765 để trình duyệt luôn giữ nguyên Origin (IndexedDB, OPFS, LocalStorage không bị mất sau mỗi lần mở lại)."""
    for port in (18765, 18766, 18767, 18768, 0):
        try:
            return ThreadingHTTPServer(("127.0.0.1", port), Handler)
        except OSError:
            continue
    return ThreadingHTTPServer(("127.0.0.1", 0), Handler)


def run():
    logger.ensure_dirs()
    for f in discover():
        FEATURES[f.id] = f
    srv = _bind_server()
    url = f"http://127.0.0.1:{srv.server_address[1]}/"
    STATE["url"] = url
    logger.log_event("system", "INFO", f"🚀 Khởi động T2MG tại {url}", f"Thư mục File rác & Log: {logger.get_trash_dir()}")
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    cmd = _browser_cmd(url)
    if cmd:
        subprocess.Popen(cmd)
    else:
        webbrowser.open(url)
    start = time.time()
    while True:  # tự thoát khi đóng cửa sổ
        time.sleep(1)
        now = time.time()
        if STATE["bye"] and now - STATE["bye"] > 5 and not running_state()["windows"]:
            break
        if not STATE["seen"] and now - start > 60:
            break
        if STATE["seen"] and now - STATE["last_ping"] > 180 and not running_state()["windows"]:
            break
    srv.shutdown()
    sys.exit(0)
