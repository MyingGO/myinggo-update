"""Đóng gói MyingGo thành 1 file zip đầy đủ (kèm sẵn yt-dlp, ffmpeg, deno) để mang sang máy khác chạy ổn định."""
import os
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKIP_DIRS = {
    ".profile", ".profile_artcraft", "trash_logs", "__pycache__", ".git", "scratch",
    "yt_profiles", "yt_cookies", "audio_repair_temp", "dist",
    "_simple_parallel_runs", "_qt_check_profiles", "_crash_logs", "_debug", "profiles"
}
SKIP_FILES = {"downloader_config.json", "shot.png", "shot1.png", "master_publish.json", "yugioh_config.json", "thumbnail_studio_config.json", "yt_studio_hub.db", "yt_studio_config.json"}  # cấu hình/token gắn riêng với máy chính
TOOL_FILES = {"ffmpeg.exe", "deno.exe"}

README = """T2MG - BẢN MANG ĐI
=====================
1. Giải nén file zip này ra 1 thư mục cố định (ví dụ D:\\T2MG). KHÔNG chạy trực tiếp từ trong file zip.
2. Cài Python 3.10+ (python.org), nhớ tick "Add python to PATH" và giữ mặc định tcl/tk.
3. Bấm đúp CaiDat.bat (hoặc bấm thẳng T2MG.bat, lần đầu nó cũng tự cài thư viện).
4. Bấm đúp T2MG.bat để mở phần mềm.

Bản đóng gói đã kèm sẵn bin\\yt-dlp.exe, bin\\ffmpeg.exe và bin\\deno.exe.
Nếu mạng máy mới bị YouTube báo "Sign in to confirm you're not a bot" / HTTP 429:
- Mở tab "Tải video / MP3" -> mục "Cookies vượt chặn" -> chọn file cookies.txt hoặc trình duyệt.
"""

SETUP_BAT = (
    '@echo off\r\n'
    'cd /d "%~dp0"\r\n'
    'python -m pip install -r requirements.txt\r\n'
    'echo.\r\n'
    'echo Xong. Bay gio mo T2MG.bat\r\n'
    'pause\r\n'
)

LAUNCHER_BAT = (
    '@echo off\r\n'
    'cd /d "%~dp0"\r\n'
    'python -c "import PIL" >nul 2>&1 || python -m pip install -r requirements.txt\r\n'
    'start "" pythonw main.py\r\n'
)


def _real_ffmpeg():
    bundled = ROOT / "bin" / "ffmpeg.exe"
    if bundled.is_file() and bundled.stat().st_size > 10_000_000:
        return bundled
    choco = Path(r"C:\ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin\ffmpeg.exe")
    if choco.is_file() and choco.stat().st_size > 10_000_000:
        return choco
    from features.downloader import FFMPEG_CANDIDATES, find_ffmpeg
    for c in FFMPEG_CANDIDATES:
        if c.is_file() and c.stat().st_size > 10_000_000:
            return c
    f = find_ffmpeg()
    if f and "chocolatey\\bin" not in str(f).lower():
        p = Path(f)
        if p.is_file() and p.stat().st_size > 10_000_000:
            return p
    return None


def _deno():
    from features.downloader import DENO_DIR
    for p in (ROOT / "bin" / "deno.exe", DENO_DIR / "deno.exe"):
        if p.is_file():
            return p
    return None


def pack(with_tools=True, dest_dir=None):
    if dest_dir:
        out_dir = Path(dest_dir)
    else:
        out_dir = Path(os.path.expanduser("~")) / "Desktop"
        try:
            out_dir.mkdir(exist_ok=True)
            _t = out_dir / f".test_{int(time.time())}"
            _t.touch()
            _t.unlink(missing_ok=True)
        except Exception:
            out_dir = ROOT / "dist"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"T2MG_portable_{time.strftime('%Y%m%d_%H%M%S')}.zip"
    notes = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in ROOT.rglob("*"):
            rel = p.relative_to(ROOT)
            if not p.is_file() or set(rel.parts[:-1]) & SKIP_DIRS or any(part.startswith(".profile") for part in rel.parts[:-1]):
                continue
            if rel.parts[:3] == ("data", "yugioh", "images"):
                continue
            # addons/*: chỉ đóng gói code engine, bỏ profile Chrome / kho tài khoản / log của máy này
            if rel.parts[0] == "addons" and (len(rel.parts) > 3 or not (p.suffix == ".py" or p.name == "app_version.json")):
                continue
            if p.suffix in (".pyc", ".old") or p.name in SKIP_FILES or p.name.lower() in TOOL_FILES:
                continue
            if rel.as_posix() in ("MyingGo.bat", "T2MG.bat"):
                continue
            z.write(p, "T2MG/" + rel.as_posix())
        if with_tools:
            ff, dn = _real_ffmpeg(), _deno()
            if ff:
                z.write(ff, "T2MG/bin/ffmpeg.exe")
            else:
                notes.append("không tìm thấy ffmpeg thật để kèm")
            if dn:
                z.write(dn, "T2MG/bin/deno.exe")
            else:
                notes.append("không tìm thấy deno để kèm")
        z.writestr("T2MG/T2MG.bat", LAUNCHER_BAT)
        z.writestr("T2MG/MyingGo.bat", LAUNCHER_BAT)
        z.writestr("T2MG/DOC_TRUOC_KHI_DUNG.txt", README.encode("utf-8-sig"))
        z.writestr("T2MG/CaiDat.bat", SETUP_BAT)
    return {"path": str(out), "size_mb": round(out.stat().st_size / 1048576, 1), "notes": notes}


DESIGN_FEATURE_IDS = {
    "thumbnail_copier",
    "photocraft",
    "filmcraft",
    "effectcraft",
    "thumbnail_studio",
    "appearance",
    "trash_logs",
}

DESIGN_REQUIREMENTS = """Pillow>=10.0.0
requests>=2.28.0
psutil>=5.9.0
pyperclip>=1.8.2
selenium==4.33.0
undetected-chromedriver==3.5.5
selenium-stealth==1.0.6
PySide6>=6.8,<7
"""

DESIGN_README_TEMPLATE = """{app_name} - BỘ CÔNG CỤ THIẾT KẾ ĐỒ HOẠ & THUMBNAIL AI
============================================================
Bộ phần mềm độc lập dành cho Thiết Kế bao gồm:
1. Thumbnail Copier: Sao chép và sắp xếp thumbnail theo cấu trúc thư mục kênh
2. ArtCraft Suite:
   - PhotoCraft: Thiết kế đồ hoạ & hình ảnh AI
   - FilmCraft: Dựng video, biên tập đa lớp
   - EffectCraft: Kỹ xảo hình ảnh & hiệu ứng chuyển động
3. Thumbnail Studio: AI Gemini Studio v13 - Tự động tạo và thiết kế Thumbnail hàng loạt, tự động xoá watermark
4. Giao diện & File rác: Tuỳ biến theme, màu sắc và dọn dẹp cache an toàn

CÁCH SỬ DỤNG:
1. Giải nén file zip này ra 1 thư mục cố định (Ví dụ: D:\\{app_name}). KHÔNG chạy trực tiếp trong file zip.
2. Cài Python 3.10+ (tải từ python.org), nhớ tick vào ô "Add python.exe to PATH".
3. Bấm đúp file CaiDat.bat (lần đầu tiên) để cài đặt các thư viện cần thiết.
4. Bấm đúp file {app_name}.bat để khởi chạy phần mềm!

TÍNH NĂNG ĐỒNG BỘ CẬP NHẬT TỪ XA:
- Khi máy chính cập nhật hoặc sửa lỗi trên GitHub, bạn chỉ cần mở {app_name}, bấm "Kiểm tra cập nhật" ở góc dưới thanh bên -> Bấm Cập nhật để tự động nâng cấp phiên bản mới nhất!
- Tên phần mềm {app_name} và cấu hình thiết kế sẽ luôn được giữ nguyên, không bị ảnh hưởng.
"""


def pack_design_suite(out_name="thuandepzai", app_name="thuandepzai", dest_dir=None):
    import json
    if dest_dir:
        out_dir = Path(dest_dir)
    else:
        out_dir = Path(os.path.expanduser("~")) / "Desktop"
        try:
            out_dir.mkdir(exist_ok=True)
            _t = out_dir / f".test_{int(time.time())}"
            _t.touch()
            _t.unlink(missing_ok=True)
        except Exception:
            out_dir = ROOT / "dist"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{out_name}_portable_{time.strftime('%Y%m%d_%H%M%S')}.zip"
    notes = []

    standalone_cfg = {
        "app_name": app_name,
        "allowed_features": sorted(list(DESIGN_FEATURE_IDS)),
        "allowed_groups": ["ArtCraft"],
        "hide_pack_button": True,
        "badge": "Bản Thiết Kế",
    }

    launcher_bat = (
        f'@echo off\r\n'
        f'title {app_name}\r\n'
        f'cd /d "%~dp0"\r\n'
        f'python -c "import PIL, requests" >nul 2>&1 || python -m pip install -r requirements.txt\r\n'
        f'start "" pythonw main.py\r\n'
    )

    setup_bat = (
        f'@echo off\r\n'
        f'title Cai Dat Thu Vien - {app_name}\r\n'
        f'cd /d "%~dp0"\r\n'
        f'echo ========================================================\r\n'
        f'echo DANG CAI DAT THU VIEN CHO {app_name.upper()}...\r\n'
        f'echo ========================================================\r\n'
        f'python -m pip install -r requirements.txt\r\n'
        f'echo.\r\n'
        f'echo ========================================================\r\n'
        f'echo CAI DAT HOAN TAT! Bay gio hay mo {app_name}.bat de dung.\r\n'
        f'echo ========================================================\r\n'
        f'pause\r\n'
    )

    readme_txt = DESIGN_README_TEMPLATE.format(app_name=app_name)

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in ROOT.rglob("*"):
            rel = p.relative_to(ROOT)
            if not p.is_file() or set(rel.parts[:-1]) & SKIP_DIRS or any(part.startswith(".profile") for part in rel.parts[:-1]):
                continue
            # Bỏ data/*
            if rel.parts[0] == "data":
                continue
            # features: chỉ lấy bộ thiết kế + appearance + trash_logs
            if rel.parts[0] == "features":
                if p.stem not in DESIGN_FEATURE_IDS and p.name != "__init__.py":
                    continue
            # web: bỏ yugioh
            if rel.parts[0] == "web" and len(rel.parts) > 1 and rel.parts[1] == "yugioh":
                continue
            # bin: bỏ qua lúc scan, sẽ kèm riêng ffmpeg
            if rel.parts[0] == "bin":
                continue
            # addons: chỉ lấy addons/thumbnail_studio code
            if rel.parts[0] == "addons":
                if len(rel.parts) < 2 or rel.parts[1] != "thumbnail_studio":
                    continue
                if len(rel.parts) > 3 or not (p.suffix == ".py" or p.name in ("app_version.json", "version.json")):
                    continue
            if p.suffix in (".pyc", ".old") or p.name in SKIP_FILES:
                continue
            if rel.as_posix() in ("MyingGo.bat", "T2MG.bat", "thuandepzai.bat", "Ket_Noi_Google_Drive.bat", "test_douyin.py", "standalone.json", "requirements.txt"):
                continue

            # Đổi thương hiệu trong web/index.html
            if rel.as_posix() == "web/index.html":
                txt = p.read_text(encoding="utf-8")
                txt = txt.replace("<title>T2MG</title>", f"<title>{app_name}</title>")
                txt = txt.replace("<h1>T2MG</h1>", f"<h1>{app_name}</h1>")
                z.writestr(f"{app_name}/web/index.html", txt.encode("utf-8"))
                continue

            z.write(p, f"{app_name}/" + rel.as_posix())

        # Kèm ffmpeg nếu có
        ff = _real_ffmpeg()
        if ff:
            z.write(ff, f"{app_name}/bin/ffmpeg.exe")
        else:
            notes.append("không tìm thấy ffmpeg để kèm")

        # Cấu hình độc lập & launcher
        z.writestr(f"{app_name}/standalone.json", json.dumps(standalone_cfg, ensure_ascii=False, indent=2).encode("utf-8"))
        z.writestr(f"{app_name}/{app_name}.bat", launcher_bat)
        z.writestr(f"{app_name}/T2MG.bat", launcher_bat)
        z.writestr(f"{app_name}/CaiDat.bat", setup_bat)
        z.writestr(f"{app_name}/DOC_TRUOC_KHI_DUNG.txt", readme_txt.encode("utf-8-sig"))
        z.writestr(f"{app_name}/requirements.txt", DESIGN_REQUIREMENTS.encode("utf-8"))

    return {"path": str(out), "size_mb": round(out.stat().st_size / 1048576, 1), "notes": notes}
