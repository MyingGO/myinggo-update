"""Đóng gói MyingGo thành 1 file zip đầy đủ (kèm sẵn yt-dlp, ffmpeg, deno) để mang sang máy khác chạy ổn định."""
import os
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKIP_DIRS = {".profile", ".profile_artcraft", "trash_logs", "__pycache__", ".git", "scratch"}
SKIP_FILES = {"downloader_config.json", "shot.png", "shot1.png", "master_publish.json"}  # cấu hình/token gắn riêng với máy chính
TOOL_FILES = {"ffmpeg.exe", "deno.exe"}

README = """MYINGGO - BẢN MANG ĐI
=====================
1. Giải nén file zip này ra 1 thư mục cố định (ví dụ D:\\MyingGo). KHÔNG chạy trực tiếp từ trong file zip.
2. Cài Python 3.10+ (python.org), nhớ tick "Add python to PATH" và giữ mặc định tcl/tk.
3. Bấm đúp CaiDat.bat (hoặc bấm thẳng MyingGo.bat, lần đầu nó cũng tự cài thư viện).
4. Bấm đúp MyingGo.bat để mở phần mềm.

Bản đóng gói đã kèm sẵn bin\\yt-dlp.exe, bin\\ffmpeg.exe và bin\\deno.exe.
Nếu mạng máy mới bị YouTube báo "Sign in to confirm you're not a bot" / HTTP 429:
- Mở tab "Tải video / MP3" -> mục "Cookies vượt chặn" -> chọn file cookies.txt hoặc trình duyệt.
"""

SETUP_BAT = (
    '@echo off\r\n'
    'cd /d "%~dp0"\r\n'
    'python -m pip install -r requirements.txt\r\n'
    'echo.\r\n'
    'echo Xong. Bay gio mo MyingGo.bat\r\n'
    'pause\r\n'
)

LAUNCHER_BAT = (
    '@echo off\r\n'
    'cd /d "%~dp0"\r\n'
    'python -c "import PIL" >nul 2>&1 || python -m pip install -r requirements.txt\r\n'
    'start "" pythonw main.py\r\n'
)


def _real_ffmpeg():
    from features.downloader import FFMPEG_CANDIDATES, find_ffmpeg
    bundled = ROOT / "bin" / "ffmpeg.exe"
    if bundled.is_file():
        return bundled
    for c in FFMPEG_CANDIDATES:
        if c.is_file():
            return c
    f = find_ffmpeg()
    if f and "chocolatey" not in f.lower():
        return Path(f)
    # Nếu là bản chocolatey shim thì tìm binary thật trong lib\ffmpeg\tools\ffmpeg\bin\ffmpeg.exe
    choco = Path(r"C:\ProgramData\chocolatey\lib\ffmpeg\tools\ffmpeg\bin\ffmpeg.exe")
    if choco.is_file():
        return choco
    return None


def _deno():
    from features.downloader import DENO_DIR
    for p in (ROOT / "bin" / "deno.exe", DENO_DIR / "deno.exe"):
        if p.is_file():
            return p
    return None


def pack(with_tools=True):
    out_dir = Path(os.path.expanduser("~")) / "Desktop"
    out_dir.mkdir(exist_ok=True)
    out = out_dir / f"MyingGo_portable_{time.strftime('%Y%m%d_%H%M%S')}.zip"
    notes = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in ROOT.rglob("*"):
            rel = p.relative_to(ROOT)
            if not p.is_file() or set(rel.parts[:-1]) & SKIP_DIRS or any(part.startswith(".profile") for part in rel.parts[:-1]):
                continue
            if p.suffix in (".pyc", ".old") or p.name in SKIP_FILES or p.name.lower() in TOOL_FILES:
                continue
            if rel.as_posix() == "MyingGo.bat":
                continue
            z.write(p, "MyingGo/" + rel.as_posix())
        if with_tools:
            ff, dn = _real_ffmpeg(), _deno()
            if ff:
                z.write(ff, "MyingGo/bin/ffmpeg.exe")
            else:
                notes.append("không tìm thấy ffmpeg thật để kèm")
            if dn:
                z.write(dn, "MyingGo/bin/deno.exe")
            else:
                notes.append("không tìm thấy deno để kèm")
        z.writestr("MyingGo/MyingGo.bat", LAUNCHER_BAT)
        z.writestr("MyingGo/DOC_TRUOC_KHI_DUNG.txt", README.encode("utf-8-sig"))
        z.writestr("MyingGo/CaiDat.bat", SETUP_BAT)
    return {"path": str(out), "size_mb": round(out.stat().st_size / 1048576, 1), "notes": notes}
