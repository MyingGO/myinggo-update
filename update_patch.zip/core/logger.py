"""Hệ thống quản lý Thư mục File rác / Cache (ngoài ổ C:) & Bảng Log chẩn đoán lỗi AI cho MyingGo + ArtCraft."""
from __future__ import annotations

import os
import platform
import shutil
import threading
import time
from pathlib import Path

from core import settings

ROOT = Path(__file__).resolve().parent.parent
_LOCK = threading.Lock()
_ENTRIES: list[dict] = []
_NEXT_ID = 1
_MAX_ENTRIES = 1200

# Các thư mục cache trình duyệt có thể dọn sạch mà KHÔNG mất dự án/preset (giữ nguyên IndexedDB, Local Storage, File System/OPFS)
SAFE_BROWSER_CACHE_DIRS = (
    "Default/Cache",
    "Default/Code Cache",
    "Default/GPUCache",
    "Default/DawnCache",
    "Default/DawnGraphiteCache",
    "Default/DawnWebGPUCache",
    "Default/Service Worker/CacheStorage",
    "Default/Service Worker/ScriptCache",
    "GrShaderCache",
    "ShaderCache",
    "GraphiteDawnCache",
    "Crashpad",
    "BrowserMetrics",
    "component_crx_cache",
)


def default_trash_dir() -> Path:
    """Ưu tiên ổ D:\\ (hoặc E:\\) nếu có để không tốn dung lượng ổ cứng chính C:\\."""
    for drv in ("D:/", "E:/", "F:/"):
        p = Path(drv)
        if p.is_dir():
            return p / "MyingGo_Trash_Logs"
    return ROOT / "trash_logs"


def get_trash_dir() -> Path:
    cfg = settings.load()
    custom = (cfg.get("trash_dir") or "").strip()
    target = Path(custom) if custom else default_trash_dir()
    try:
        target.mkdir(parents=True, exist_ok=True)
    except Exception:
        target = ROOT / "trash_logs"
        target.mkdir(parents=True, exist_ok=True)
    return target


def ensure_dirs() -> dict[str, Path]:
    base = get_trash_dir()
    prof = base / "browser_profile"
    temp = base / "temp"
    logs = base / "logs"
    for d in (prof, temp, logs):
        d.mkdir(parents=True, exist_ok=True)
    # Chuyển hướng biến môi trường TEMP/TMP của tiến trình con sang thư mục rác đã cấu hình
    os.environ["TEMP"] = str(temp)
    os.environ["TMP"] = str(temp)
    return {"base": base, "profile": prof, "temp": temp, "logs": logs}


def get_browser_profile_dir() -> Path:
    """Dùng chung 1 profile duy nhất cho cả khung trong MyingGo và cửa sổ mở riêng để đồng nhất 100% dữ liệu."""
    dirs = ensure_dirs()
    prof = dirs["profile"]
    # Nếu lần đầu chuyển từ ROOT/.profile sang ổ mới, copy dữ liệu phiên (Local Storage, IndexedDB, File System) sang để không mất bài cũ
    old_prof_default = ROOT / ".profile" / "Default"
    new_prof_default = prof / "Default"
    if old_prof_default.is_dir() and not new_prof_default.exists():
        try:
            new_prof_default.mkdir(parents=True, exist_ok=True)
            for keep in ("Local Storage", "IndexedDB", "File System", "Preferences"):
                src = old_prof_default / keep
                dst = new_prof_default / keep
                if src.is_dir() and not dst.exists():
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                elif src.is_file() and not dst.exists():
                    shutil.copy2(src, dst)
        except Exception:
            pass
    return prof


def log_event(source: str, level: str = "INFO", message: str = "", detail: str = "") -> dict:
    """Ghi 1 dòng log vào bộ nhớ trực tiếp và xuất luôn ra file log trong thư mục File rác & Log."""
    global _NEXT_ID
    source = (source or "system").strip().lower()
    level = (level or "INFO").strip().upper()
    now = time.localtime()
    ts = time.strftime("%H:%M:%S", now)
    full_ts = time.strftime("%Y-%m-%d %H:%M:%S", now)
    msg_str = str(message or "").strip()
    det_str = str(detail or "").strip()

    with _LOCK:
        entry = {
            "id": _NEXT_ID,
            "ts": ts,
            "full_ts": full_ts,
            "source": source,
            "level": level,
            "message": msg_str,
            "detail": det_str,
        }
        _NEXT_ID += 1
        _ENTRIES.append(entry)
        if len(_ENTRIES) > _MAX_ENTRIES:
            del _ENTRIES[: len(_ENTRIES) - _MAX_ENTRIES]

    # Ghi ra file log trên ổ lưu file rác để không mất khi tắt app
    try:
        logs_dir = ensure_dirs()["logs"]
        line = f"[{full_ts}] [{source.upper()}] [{level}] {msg_str}"
        if det_str:
            line += f"\n    Chi tiết: {det_str.replace(chr(10), chr(10) + '    ')}"
        line += "\n"
        with (logs_dir / "myinggo_runtime.log").open("a", encoding="utf-8") as f:
            f.write(line)
        if level in ("ERROR", "WARN", "FATAL") or source in ("photocraft", "filmcraft", "effectcraft"):
            with (logs_dir / "artcraft_diagnostic.log").open("a", encoding="utf-8") as f:
                f.write(line)
    except Exception:
        pass
    return entry


def get_logs(source: str = "", since_id: int = 0, only_errors: bool = False) -> dict:
    src = (source or "").strip().lower()
    with _LOCK:
        items = [
            e for e in _ENTRIES
            if e["id"] > since_id
            and (not src or src == "all" or e["source"] == src)
            and (not only_errors or e["level"] in ("ERROR", "WARN", "FATAL"))
        ]
        err_count = sum(
            1 for e in _ENTRIES
            if (not src or src == "all" or e["source"] == src) and e["level"] in ("ERROR", "FATAL")
        )
        warn_count = sum(
            1 for e in _ENTRIES
            if (not src or src == "all" or e["source"] == src) and e["level"] == "WARN"
        )
        last_id = _ENTRIES[-1]["id"] if _ENTRIES else since_id
    return {
        "entries": items,
        "last_id": last_id,
        "error_count": err_count,
        "warn_count": warn_count,
        "trash_dir": str(get_trash_dir()),
    }


def clear_logs(source: str = "") -> dict:
    src = (source or "").strip().lower()
    with _LOCK:
        if not src or src == "all":
            _ENTRIES.clear()
        else:
            _ENTRIES[:] = [e for e in _ENTRIES if e["source"] != src]
    return {"ok": 1}


def _dir_size_bytes(path: Path) -> int:
    if not path.exists():
        return 0
    if path.is_file():
        try:
            return path.stat().st_size
        except Exception:
            return 0
    total = 0
    try:
        for p in path.rglob("*"):
            if p.is_file():
                try:
                    total += p.stat().st_size
                except Exception:
                    pass
    except Exception:
        pass
    return total


def _drive_free_gb(path: Path) -> dict:
    try:
        target = path if path.exists() else path.parent
        u = shutil.disk_usage(str(target))
        return {
            "drive": path.drive or str(path)[:3],
            "free_gb": round(u.free / (1024 ** 3), 2),
            "total_gb": round(u.total / (1024 ** 3), 2),
            "used_pct": round((u.used / u.total) * 100, 1) if u.total else 0,
        }
    except Exception:
        return {"drive": "", "free_gb": 0, "total_gb": 0, "used_pct": 0}


def disk_and_junk_stats() -> dict:
    dirs = ensure_dirs()
    base = dirs["base"]
    prof = dirs["profile"]
    temp = dirs["temp"]
    logs = dirs["logs"]

    # 1. Dung lượng cache trình duyệt có thể dọn sạch
    cache_bytes = 0
    for rel in SAFE_BROWSER_CACHE_DIRS:
        cache_bytes += _dir_size_bytes(prof / rel)

    # 2. Dung lượng các thư mục .profile* cũ nằm trên ổ C: (trong ROOT)
    legacy_c_bytes = 0
    for p in ROOT.glob(".profile*"):
        if p.is_dir():
            legacy_c_bytes += _dir_size_bytes(p)

    # 3. Dung lượng file tạm + __pycache__
    temp_bytes = _dir_size_bytes(temp)
    for pyc in ROOT.rglob("__pycache__"):
        if pyc.is_dir():
            temp_bytes += _dir_size_bytes(pyc)

    # 4. Dung lượng file log
    logs_bytes = _dir_size_bytes(logs)
    total_profile_bytes = _dir_size_bytes(prof)

    cleanable_bytes = cache_bytes + legacy_c_bytes + temp_bytes
    return {
        "trash_dir": str(base),
        "profile_dir": str(prof),
        "logs_dir": str(logs),
        "temp_dir": str(temp),
        "browser_cache_mb": round(cache_bytes / 1048576, 2),
        "legacy_c_mb": round(legacy_c_bytes / 1048576, 2),
        "temp_mb": round(temp_bytes / 1048576, 2),
        "logs_mb": round(logs_bytes / 1048576, 2),
        "total_profile_mb": round(total_profile_bytes / 1048576, 2),
        "cleanable_mb": round(cleanable_bytes / 1048576, 2),
        "c_drive": _drive_free_gb(ROOT),
        "trash_drive": _drive_free_gb(base),
    }


def _rm_tree_best_effort(path: Path) -> int:
    """Xóa file/thư mục tối đa có thể (kể cả khi trình duyệt đang khóa 1 vài file lock), trả về số byte giải phóng."""
    if not path.exists():
        return 0
    before = _dir_size_bytes(path)
    if path.is_file():
        try:
            path.unlink()
        except Exception:
            pass
    else:
        for p in sorted(path.rglob("*"), key=lambda x: len(x.parts), reverse=True):
            try:
                if p.is_file() or p.is_symlink():
                    p.unlink()
                elif p.is_dir():
                    p.rmdir()
            except Exception:
                pass
        try:
            path.rmdir()
        except Exception:
            pass
    after = _dir_size_bytes(path)
    return max(0, before - after)


def clean_junk(clean_logs: bool = False) -> dict:
    """Dọn sạch các file rác, cache trình duyệt, file tạm và các thư mục .profile* cũ trên ổ C:."""
    dirs = ensure_dirs()
    prof = dirs["profile"]
    temp = dirs["temp"]
    logs = dirs["logs"]
    freed = 0
    details = []

    # 1. Xóa các thư mục .profile* cũ trong ROOT (trên ổ C:)
    for old_p in list(ROOT.glob(".profile*")):
        if old_p.is_dir() and old_p.resolve() != prof.resolve():
            b = _rm_tree_best_effort(old_p)
            if b > 0:
                freed += b
                details.append(f"Đã dọn {old_p.name} trên ổ gốc ({round(b / 1048576, 1)} MB)")

    # 2. Xóa các thư mục Cache / ShaderCache / GPUCache trong browser_profile (giữ nguyên dự án & cài đặt)
    cache_freed = 0
    for rel in SAFE_BROWSER_CACHE_DIRS:
        cache_freed += _rm_tree_best_effort(prof / rel)
    if cache_freed > 0:
        freed += cache_freed
        details.append(f"Đã dọn Cache GPU/WebAssembly trình duyệt ({round(cache_freed / 1048576, 1)} MB)")

    # 3. Xóa thư mục temp và __pycache__
    temp_freed = _rm_tree_best_effort(temp)
    temp.mkdir(parents=True, exist_ok=True)
    for pyc in list(ROOT.rglob("__pycache__")):
        if pyc.is_dir():
            temp_freed += _rm_tree_best_effort(pyc)
    if temp_freed > 0:
        freed += temp_freed
        details.append(f"Đã dọn file tạm & __pycache__ ({round(temp_freed / 1048576, 1)} MB)")

    # 4. Nếu chọn xóa luôn file log cũ
    if clean_logs:
        log_freed = _rm_tree_best_effort(logs)
        logs.mkdir(parents=True, exist_ok=True)
        with _LOCK:
            _ENTRIES.clear()
        if log_freed > 0:
            freed += log_freed
            details.append(f"Đã làm mới file Log ({round(log_freed / 1048576, 1)} MB)")

    freed_mb = round(freed / 1048576, 2)
    log_event(
        "system",
        "INFO",
        f"🧹 Đã dọn dẹp File rác & Cache: giải phóng {freed_mb} MB",
        "; ".join(details) if details else "Hệ thống đã sạch sẵn.",
    )
    res = disk_and_junk_stats()
    res["freed_mb"] = freed_mb
    res["details"] = details
    return res


def set_trash_dir(new_dir: str) -> dict:
    p = Path(new_dir.strip())
    p.mkdir(parents=True, exist_ok=True)
    old_dirs = ensure_dirs()
    settings.update({"trash_dir": str(p)})
    new_dirs = ensure_dirs()
    # Chuyển các file log hiện có sang thư mục mới
    if old_dirs["logs"].resolve() != new_dirs["logs"].resolve() and old_dirs["logs"].is_dir():
        for lf in old_dirs["logs"].glob("*"):
            if lf.is_file():
                try:
                    shutil.copy2(lf, new_dirs["logs"] / lf.name)
                except Exception:
                    pass
    log_event("system", "INFO", f"📂 Đã chuyển thư mục lưu File rác & Log sang: {p}")
    return disk_and_junk_stats()


def build_ai_report_text(source: str = "") -> str:
    stats = disk_and_junk_stats()
    src = (source or "").strip().lower()
    with _LOCK:
        entries = [
            e for e in _ENTRIES
            if not src or src == "all" or e["source"] == src or e["source"] == "system"
        ]
    errors = [e for e in entries if e["level"] in ("ERROR", "WARN", "FATAL")]

    lines = [
        "======================================================================",
        "🤖 BÁO CÁO CHẨN ĐOÁN LỖI & TRẠNG THÁI CHẠY MYINGGO / ARTCRAFT (GỬI AI)",
        "======================================================================",
        f"- Thời gian xuất báo cáo : {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- Hệ điều hành           : {platform.platform()} ({platform.machine()})",
        f"- Phiên bản Python       : {platform.python_version()}",
        f"- Phân hệ đang kiểm tra  : {(source or 'Toàn bộ MyingGo + ArtCraft').upper()}",
        f"- Thư mục File rác & Log : {stats['trash_dir']} (Còn trống {stats['trash_drive']['free_gb']} GB / {stats['trash_drive']['total_gb']} GB)",
        f"- Ổ cứng gốc (C:)        : Còn trống {stats['c_drive']['free_gb']} GB / {stats['c_drive']['total_gb']} GB",
        f"- Dung lượng Cache/Rác   : Cache trình duyệt {stats['browser_cache_mb']} MB | Tạm {stats['temp_mb']} MB | Log {stats['logs_mb']} MB",
        f"- Tổng số dòng Log       : {len(entries)} dòng (Trong đó có {len(errors)} Cảnh báo / Lỗi)",
        "",
        "----------------------------------------------------------------------",
        "1. TÓM TẮT CÁC LỖI & CẢNH BÁO GẦN NHẤT (ERROR / WARN):",
        "----------------------------------------------------------------------",
    ]
    if not errors:
        lines.append("✅ Không ghi nhận lỗi (ERROR/WARN) nào trong phiên hiện tại.")
    else:
        for e in errors[-40:]:
            lines.append(f"[{e['full_ts']}] [{e['source'].upper()}] [{e['level']}] {e['message']}")
            if e["detail"]:
                lines.append(f"   ↳ Chi tiết: {e['detail']}")

    lines.extend([
        "",
        "----------------------------------------------------------------------",
        "2. NHẬT KÝ HOẠT ĐỘNG CHI TIẾT (CHRONOLOGICAL RUNTIME LOGS):",
        "----------------------------------------------------------------------",
    ])
    if not entries:
        lines.append("(Chưa có dòng log nào)")
    else:
        for e in entries[-200:]:
            lines.append(f"[{e['ts']}] [{e['source'].upper()}] [{e['level']}] {e['message']}")
            if e["detail"]:
                lines.append(f"   ↳ {e['detail']}")
    lines.append("======================================================================")
    return "\n".join(lines)


def export_ai_report(source: str = "") -> dict:
    dirs = ensure_dirs()
    text = build_ai_report_text(source)
    tag = (source or "all").strip().lower()
    fname = f"BaoCaoLoi_AI_{tag}_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    out_path = dirs["logs"] / fname
    out_path.write_text(text, encoding="utf-8-sig")
    log_event("system", "INFO", f"📝 Đã xuất file báo cáo Log cho AI: {out_path.name}", str(out_path))
    return {"ok": 1, "path": str(out_path), "text": text}
