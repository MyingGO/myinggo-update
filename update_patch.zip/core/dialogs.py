"""Hộp thoại chọn thư mục/file của Windows (chạy ở tiến trình riêng cho an toàn)."""
import os
import subprocess
import sys

_FLAGS = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _run(code):
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, env=env,
                       creationflags=_FLAGS)
    return r.stdout.decode("utf-8", "replace").strip()


_HEAD = "import tkinter as tk;from tkinter import filedialog as f;r=tk.Tk();r.withdraw();r.attributes('-topmost',True);"


def pick_folder():
    return _run(_HEAD + "print(f.askdirectory())")


def pick_image():
    return _run(_HEAD + "print(f.askopenfilename(filetypes=[('Anh','*.png *.jpg *.jpeg *.bmp *.webp'),('All','*.*')]))")


def pick_exe():
    return _run(_HEAD + "print(f.askopenfilename(filetypes=[('Program','*.exe'),('All','*.*')]))")


def pick_txt():
    return _run(_HEAD + "print(f.askopenfilename(filetypes=[('Cookies TXT','*.txt'),('All','*.*')]))")


def pick_files():
    out = _run(_HEAD + "print(chr(10).join(f.askopenfilenames(filetypes=[('Anh va video','*.png *.jpg *.jpeg *.webp *.bmp *.gif *.tif *.tiff *.ico *.mp4 *.mkv *.webm *.avi *.mov *.flv *.wmv *.m4v *.mpg *.mpeg *.ts *.3gp *.mp3 *.wav *.aac *.m4a *.flac *.ogg *.opus *.wma'),('All','*.*')])))")
    return [l for l in out.splitlines() if l.strip()]
