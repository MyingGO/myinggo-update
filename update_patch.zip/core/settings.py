"""Cài đặt giao diện, lưu trong settings.json."""
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SETTINGS = ROOT / "settings.json"
ASSETS = ROOT / "assets"
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

DEFAULTS = {
    "bg_color": "#1e1e2e",
    "btn_color": "#7c3aed",
    "text_color": "#f1f1f5",
    "bg_image": "",              # tên file trong assets/
    "bg_video": "",              # tên file video nền trong assets/
    "bg_video_poster": "",       # ảnh frame đầu của video nền trong assets/
    "bg_video_quality": "light", # light | balanced | raw
    "bg_video_pause_idle": False,# tạm dừng cả khi bấm sang cửa sổ khác (khi thu nhỏ cửa sổ luôn tự dừng)
    "bg_video_low_blur": True,   # giới hạn blur khi chạy video để không giật lag GPU
    "bg_video_speed": 100,       # % tốc độ phát video (50..150)
    "dim": 25,                   # % phủ màu nền lên ảnh/video nền
    "glass": 45,                 # % trong suốt của khung thao tác
    "blur": 18,                  # px độ mờ kính
    "radius": 24,                # px độ bo tròn khung
    "trash_dir": "",             # thư mục lưu file rác, cache trình duyệt & log lỗi (ưu tiên ổ D: để không tốn ổ C:)
    "ver": 0,
}


def find_ffmpeg() -> str:
    cand = ROOT / "bin" / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
    if cand.is_file():
        return str(cand)
    return shutil.which("ffmpeg") or ""


def _probe_video(ff: str, src: Path) -> dict:
    info = {"w": 0, "h": 0, "fps": 0.0, "codec": "", "pix_fmt": ""}
    if not ff:
        return info
    try:
        cp = subprocess.run(
            [ff, "-hide_banner", "-i", str(src)],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=15, creationflags=_NOWIN,
        )
        err = cp.stderr or ""
        for line in err.splitlines():
            if "Video:" in line:
                clean = re.sub(r"\([^)]*\)", "", line.split("Video:", 1)[1])
                parts = [p.strip() for p in clean.split(",") if p.strip()]
                if parts:
                    info["codec"] = parts[0].split()[0].lower()
                if len(parts) > 1:
                    info["pix_fmt"] = parts[1].split()[0].lower()
                m_dim = re.search(r"\b(\d{2,5})x(\d{2,5})\b", clean)
                if m_dim:
                    info["w"] = int(m_dim.group(1))
                    info["h"] = int(m_dim.group(2))
                m_fps = re.search(r"(\d+(?:\.\d+)?)\s*(?:fps|tbr)\b", clean)
                if m_fps:
                    info["fps"] = float(m_fps.group(1))
                break
    except Exception:
        pass
    return info


def load():
    cfg = dict(DEFAULTS)
    try:
        cfg.update(json.loads(SETTINGS.read_text(encoding="utf-8")))
    except Exception:
        pass
    for key in ("bg_image", "bg_video", "bg_video_poster"):
        val = cfg.get(key) or ""
        if val:
            name = Path(val).name  # tương thích bản cũ lưu đường dẫn đầy đủ
            cfg[key] = name if (ASSETS / name).is_file() else ""
    if cfg.get("bg_video_quality") not in ("light", "balanced", "raw"):
        cfg["bg_video_quality"] = "light"
    cfg["bg_video_pause_idle"] = bool(cfg.get("bg_video_pause_idle", False))
    cfg["bg_video_low_blur"] = bool(cfg.get("bg_video_low_blur", True))
    try:
        spd = int(cfg.get("bg_video_speed", 100))
    except Exception:
        spd = 100
    cfg["bg_video_speed"] = max(50, min(150, spd))
    return {k: cfg[k] for k in DEFAULTS}


def save(cfg):
    SETTINGS.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def update(patch):
    cfg = load()
    for k, v in patch.items():
        if k in DEFAULTS:
            cfg[k] = v
    cfg["ver"] = int(time.time())
    save(cfg)
    return cfg


def reset():
    cfg = dict(DEFAULTS)
    cfg["ver"] = int(time.time())
    save(cfg)
    return cfg


def set_image(src):
    ASSETS.mkdir(exist_ok=True)
    dst = ASSETS / ("bg_user" + Path(src).suffix.lower())
    if Path(src).resolve() != dst.resolve():
        shutil.copyfile(src, dst)
    return update({"bg_image": dst.name, "bg_video": "", "bg_video_poster": ""})


def set_video(src, quality: str = "light") -> dict:
    """Nạp video nền và tối ưu bằng ffmpeg (tắt audio, faststart, giới hạn 720p/24fps hoặc 1080p/30fps)."""
    src_p = Path(src)
    if not src_p.is_file():
        raise FileNotFoundError(f"Không tìm thấy file video: {src}")
    quality = quality if quality in ("light", "balanced", "raw") else "light"
    ASSETS.mkdir(exist_ok=True)
    src_bytes = src_p.stat().st_size
    ext = src_p.suffix.lower()
    ff = find_ffmpeg()
    dst = ASSETS / "bg_user.mp4"
    tmp_dst = ASSETS / "bg_user.tmp.mp4"
    poster = ASSETS / "bg_user_poster.jpg"
    tmp_poster = ASSETS / "bg_user_poster.tmp.jpg"
    mode_used = "copy"

    if ff:
        info = _probe_video(ff, src_p)
        presets = {"light": (1280, 720, 24.0, "25"), "balanced": (1920, 1080, 30.0, "22"), "raw": (1920, 1080, 30.0, "22")}
        max_w, max_h, max_fps, crf = presets[quality]
        browser_safe_codec = info["codec"] in ("h264", "avc1")
        browser_safe_pix = (not info["pix_fmt"]) or ("10le" not in info["pix_fmt"] and "12le" not in info["pix_fmt"] and "yuv420p" in info["pix_fmt"])
        already_compact = (
            ext == ".mp4"
            and browser_safe_codec
            and browser_safe_pix
            and 0 < info["w"] <= max_w
            and 0 < info["h"] <= max_h
            and (info["fps"] == 0 or info["fps"] <= max_fps + 0.5)
            and src_bytes <= 18 * 1024 * 1024
        )
        can_copy = (
            quality == "raw"
            and ext in (".mp4", ".m4v", ".mov")
            and browser_safe_codec
            and browser_safe_pix
        ) or already_compact
        copied_ok = False
        if can_copy:
            cp = subprocess.run(
                [ff, "-y", "-hide_banner", "-loglevel", "error", "-i", str(src_p),
                 "-c:v", "copy", "-an", "-sn", "-dn", "-movflags", "+faststart", str(tmp_dst)],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=120, creationflags=_NOWIN,
            )
            if cp.returncode == 0 and tmp_dst.is_file() and tmp_dst.stat().st_size > 0:
                copied_ok = True
                mode_used = "remux"

        if not copied_ok:
            vf_parts = [
                f"scale='min({max_w},iw)':'min({max_h},ih)':force_original_aspect_ratio=decrease",
                "scale=trunc(iw/2)*2:trunc(ih/2)*2",
            ]
            if info["fps"] == 0 or info["fps"] > max_fps + 0.5:
                vf_parts.append(f"fps={int(max_fps)}")
            vf = ",".join(vf_parts)
            cp = subprocess.run(
                [ff, "-y", "-hide_banner", "-loglevel", "error", "-i", str(src_p),
                 "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", crf,
                 "-pix_fmt", "yuv420p", "-an", "-sn", "-dn", "-movflags", "+faststart", str(tmp_dst)],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=240, creationflags=_NOWIN,
            )
            if cp.returncode != 0 or not tmp_dst.is_file() or tmp_dst.stat().st_size == 0:
                tmp_dst.unlink(missing_ok=True)
                raise RuntimeError(f"FFmpeg tối ưu video thất bại: {(cp.stderr or '').strip()[:300]}")
            mode_used = f"transcode_{quality}"

        os.replace(tmp_dst, dst)
        # Trích 1 frame poster để hiển thị tức thì lúc mới mở app
        poster_ok = False
        for ss in ("0.5", "0"):
            cp_p = subprocess.run(
                [ff, "-y", "-hide_banner", "-loglevel", "error", "-ss", ss, "-i", str(dst),
                 "-frames:v", "1", "-vf", "scale='min(1280,iw)':-2", "-q:v", "4", str(tmp_poster)],
                capture_output=True, timeout=15, creationflags=_NOWIN,
            )
            if cp_p.returncode == 0 and tmp_poster.is_file() and tmp_poster.stat().st_size > 0:
                os.replace(tmp_poster, poster)
                poster_ok = True
                break
            tmp_poster.unlink(missing_ok=True)
    else:
        dst = ASSETS / ("bg_user" + (ext or ".mp4"))
        if src_p.resolve() != dst.resolve():
            shutil.copyfile(src_p, dst)
        poster_ok = False
        mode_used = "direct_no_ffmpeg"

    cfg = update({
        "bg_video": dst.name,
        "bg_video_poster": poster.name if poster_ok else "",
        "bg_video_quality": quality,
        "bg_image": "",
    })
    return {
        "settings": cfg,
        "src_bytes": src_bytes,
        "out_bytes": dst.stat().st_size if dst.is_file() else src_bytes,
        "mode": mode_used,
    }


def ensure_video_browser_safe() -> dict:
    """Đảm bảo bg_user.mp4 hiện tại dùng codec H.264 (yuv420p) để mọi trình duyệt Windows giải mã được (tránh HEVC/bytevc1 bị đứng hình)."""
    cfg = load()
    vname = cfg.get("bg_video") or ""
    if not vname:
        return cfg
    vp = ASSETS / vname
    ff = find_ffmpeg()
    if not vp.is_file() or not ff:
        return cfg
    info = _probe_video(ff, vp)
    safe_codec = info["codec"] in ("h264", "avc1")
    safe_pix = (not info["pix_fmt"]) or ("10le" not in info["pix_fmt"] and "12le" not in info["pix_fmt"] and "yuv420p" in info["pix_fmt"])
    if safe_codec and safe_pix:
        return cfg
    res = set_video(str(vp), quality=cfg.get("bg_video_quality") or "light")
    return res["settings"]
