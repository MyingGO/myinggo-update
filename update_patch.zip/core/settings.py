"""Cài đặt giao diện, lưu trong settings.json."""
import json
import shutil
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SETTINGS = ROOT / "settings.json"
ASSETS = ROOT / "assets"

DEFAULTS = {
    "bg_color": "#1e1e2e",
    "btn_color": "#7c3aed",
    "text_color": "#f1f1f5",
    "bg_image": "",     # tên file trong assets/
    "dim": 25,          # % phủ màu nền lên ảnh nền
    "glass": 45,        # % trong suốt của khung thao tác
    "blur": 18,         # px độ mờ kính
    "radius": 24,       # px độ bo tròn khung
    "trash_dir": "",    # thư mục lưu file rác, cache trình duyệt & log lỗi (ưu tiên ổ D: để không tốn ổ C:)
    "ver": 0,
}


def load():
    cfg = dict(DEFAULTS)
    try:
        cfg.update(json.loads(SETTINGS.read_text(encoding="utf-8")))
    except Exception:
        pass
    img = cfg.get("bg_image") or ""
    if img:
        name = Path(img).name  # tương thích bản cũ lưu đường dẫn đầy đủ
        cfg["bg_image"] = name if (ASSETS / name).is_file() else ""
    return {k: cfg[k] for k in DEFAULTS}


def save(cfg):
    SETTINGS.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def update(patch):
    cfg = load()
    for k, v in patch.items():
        if k in DEFAULTS:
            cfg[k] = v
    cfg["ver"] = int(time.time())
    save(cfg)
    return cfg


def reset():
    cfg = dict(DEFAULTS)
    cfg["ver"] = int(time.time())
    save(cfg)
    return cfg


def set_image(src):
    ASSETS.mkdir(exist_ok=True)
    dst = ASSETS / ("bg_user" + Path(src).suffix.lower())
    if Path(src).resolve() != dst.resolve():
        shutil.copyfile(src, dst)
    return update({"bg_image": dst.name})
