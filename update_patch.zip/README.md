# T2MG
Giao diện web kính mờ, chạy trong cửa sổ riêng (Edge/Chrome ở chế độ app). Chạy: `T2MG.bat` hoặc `python main.py`.
Cần: `pip install -r requirements.txt`.

## Thêm tính năng mới
1. Tạo `features/ten.py`: class kế thừa `core.base.Feature`, đặt `title`, `order`, `dock` (`"top"`/`"bottom"`).
   Mỗi hàm `act_xxx(self, data)` trả về dict là một API.
2. Tạo `features/ten.html`: giao diện + `<script>`. Trong script có sẵn `root`, `fid`, `MG.call(fid, "xxx", data)`,
   `MG.watchLog(...)`, `MG.toast(...)`.
3. Mở lại app, menu tự xuất hiện. Không cần sửa file nào khác.

Xem `features/thumbnail_copier.*` làm mẫu. Giao diện (màu, ảnh nền, kính mờ, bo tròn) chỉnh trong mục **Giao diện**.
