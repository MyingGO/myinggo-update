@echo off
title thuandepzai
cd /d "%~dp0"
python -c "import PIL, requests" >nul 2>&1 || python -m pip install -r requirements.txt
start "" pythonw main.py
