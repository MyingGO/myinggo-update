﻿"""Tạo logo mẫu. Chạy: python make_logo.py  (hoặc tự thay assets/logo.png rồi chạy lại để cập nhật icon .ico)"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

a = Path(__file__).parent / "assets"
p = a / "logo.png"
if not p.exists():
    S = 256
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((8, 8, S - 8, S - 8), 56, fill=(124, 58, 237, 255))
    d.rounded_rectangle((8, 8, S - 8, S // 2), 56, fill=(236, 72, 153, 255))
    d.rectangle((8, S // 4, S - 8, S // 2), fill=(236, 72, 153, 255))
    try:
        f = ImageFont.truetype("segoeuib.ttf", 130)
    except Exception:
        f = ImageFont.load_default()
    d.text((S / 2, S / 2 + 4), "MG", font=f, fill="white", anchor="mm")
    im.save(p)
Image.open(p).convert("RGBA").save(a / "logo.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("ok")
